package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.response.GenreListResponse;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1288m extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23649r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23650s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1288m(J j, d dVar) {
        super(2, dVar);
        this.f23650s = j;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1288m(this.f23650s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1288m) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        J j = this.f23650s;
        p130n6.d dVar = j.f23526b;
        int i9 = this.f23649r;
        if (i9 == 0) {
            u0.F(obj);
            a aVar = j.f23525a;
            String strG = p165r6.a.g(T8.l.u(dVar), o.f18389a.B());
            this.f23649r = 1;
            obj = aVar.r(strG, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        GenreListResponse genreListResponse = (GenreListResponse) obj;
        String strR = o.f18389a.R();
        SharedPreferences.Editor editorEdit = dVar.f21718a.edit();
        editorEdit.putString(strR, dVar.f21719b.a(GenreListResponse.class).d(genreListResponse));
        editorEdit.apply();
        return new b(genreListResponse);
    }
}
