package p182t6;

import B8.A;
import com.maertsno.data.model.request.ContinueWatchRequest;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1282g extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23599r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23600s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ long f23601t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ long f23602u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ int f23603v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ long f23604w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ int f23605x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final /* synthetic */ long f23606y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final /* synthetic */ int f23607z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1282g(J j, long j9, long j10, int i9, long j11, int i10, long j12, int i11, d dVar) {
        super(2, dVar);
        this.f23600s = j;
        this.f23601t = j9;
        this.f23602u = j10;
        this.f23603v = i9;
        this.f23604w = j11;
        this.f23605x = i10;
        this.f23606y = j12;
        this.f23607z = i11;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1282g(this.f23600s, this.f23601t, this.f23602u, this.f23603v, this.f23604w, this.f23605x, this.f23606y, this.f23607z, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1282g) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23599r;
        if (i9 == 0) {
            u0.F(obj);
            J j = this.f23600s;
            a aVar = j.f23525a;
            String strG = p165r6.a.g(T8.l.u(j.f23526b), o.f18389a.r());
            ContinueWatchRequest continueWatchRequest = new ContinueWatchRequest(this.f23601t, this.f23602u, this.f23603v, this.f23604w, this.f23605x, this.f23606y, this.f23607z);
            this.f23599r = 1;
            obj = aVar.q(strG, continueWatchRequest, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
