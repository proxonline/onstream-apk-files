package p182t6;

import B8.A;
import h8.d;
import java.util.LinkedHashMap;
import p039d8.g;
import p039d8.l;
import p048e8.u;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;
import p229z8.e;

/* JADX INFO: renamed from: t6.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1292q extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23673r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f23674s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f23675t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ String f23676u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ J f23677v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ String f23678w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1292q(int i9, int i10, String str, J j, String str2, d dVar) {
        super(2, dVar);
        this.f23674s = i9;
        this.f23675t = i10;
        this.f23676u = str;
        this.f23677v = j;
        this.f23678w = str2;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1292q(this.f23674s, this.f23675t, this.f23676u, this.f23677v, this.f23678w, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1292q) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23673r;
        if (i9 == 0) {
            u0.F(obj);
            LinkedHashMap linkedHashMapP = u.P(new g("page", String.valueOf(this.f23674s)), new g("limit", String.valueOf(this.f23675t)));
            String str = this.f23676u;
            if (str != null && !e.j0(str)) {
                linkedHashMapP.put("filter", str);
            }
            J j = this.f23677v;
            a aVar = j.f23525a;
            String str2 = T8.l.u(j.f23526b) + o.f18389a.k0() + this.f23678w;
            this.f23673r = 1;
            obj = aVar.p(str2, linkedHashMapP, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
