package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.request.PlayerConfigRequest;
import com.maertsno.data.model.response.LoginResponse;
import com.maertsno.data.model.response.PlayerConfigParentResponse;
import com.maertsno.data.model.response.PlayerConfigsResponse;
import h8.d;
import java.util.Calendar;
import p039d8.h;
import p039d8.l;
import p064g6.o;
import p084i8.a;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class L extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23534r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ U f23535s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public L(U u4, d dVar) {
        super(2, dVar);
        this.f23535s = u4;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new L(this.f23535s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((L) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0278  */
    /* JADX WARN: Code duplicated, block: B:111:0x0299  */
    /* JADX WARN: Code duplicated, block: B:115:0x02b9  */
    /* JADX WARN: Code duplicated, block: B:116:0x02cc  */
    /* JADX WARN: Code duplicated, block: B:118:0x02d6  */
    /* JADX WARN: Code duplicated, block: B:119:0x02e9  */
    /* JADX WARN: Code duplicated, block: B:121:0x02f3  */
    /* JADX WARN: Code duplicated, block: B:122:0x0306  */
    /* JADX WARN: Code duplicated, block: B:124:0x0310  */
    /* JADX WARN: Code duplicated, block: B:126:0x0318  */
    /* JADX WARN: Code duplicated, block: B:127:0x031c  */
    /* JADX WARN: Code duplicated, block: B:129:0x0324  */
    /* JADX WARN: Code duplicated, block: B:131:0x032e  */
    /* JADX WARN: Code duplicated, block: B:132:0x0338  */
    /* JADX WARN: Code duplicated, block: B:143:0x0359  */
    /* JADX WARN: Code duplicated, block: B:146:0x035e  */
    /* JADX WARN: Code duplicated, block: B:149:0x037d  */
    /* JADX WARN: Code duplicated, block: B:150:0x038d  */
    /* JADX WARN: Code duplicated, block: B:152:0x0397  */
    /* JADX WARN: Code duplicated, block: B:153:0x03a6  */
    /* JADX WARN: Code duplicated, block: B:155:0x03b0  */
    /* JADX WARN: Code duplicated, block: B:156:0x03c0  */
    /* JADX WARN: Code duplicated, block: B:158:0x03ca  */
    /* JADX WARN: Code duplicated, block: B:160:0x03d0  */
    /* JADX WARN: Code duplicated, block: B:161:0x03d5  */
    /* JADX WARN: Code duplicated, block: B:163:0x03dd  */
    /* JADX WARN: Code duplicated, block: B:165:0x03e7  */
    /* JADX WARN: Code duplicated, block: B:166:0x03f4  */
    /* JADX WARN: Code duplicated, block: B:178:0x0416  */
    /* JADX WARN: Code duplicated, block: B:180:0x041a  */
    /* JADX WARN: Code duplicated, block: B:181:0x041d  */
    /* JADX WARN: Code duplicated, block: B:188:0x044d A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:75:0x01b1  */
    /* JADX WARN: Code duplicated, block: B:82:0x01f5  */
    /* JADX WARN: Code duplicated, block: B:83:0x0209  */
    /* JADX WARN: Code duplicated, block: B:85:0x0213  */
    /* JADX WARN: Code duplicated, block: B:86:0x0227  */
    /* JADX WARN: Code duplicated, block: B:88:0x0231  */
    /* JADX WARN: Code duplicated, block: B:90:0x0240  */
    /* JADX WARN: Code duplicated, block: B:92:0x024a  */
    /* JADX WARN: Code duplicated, block: B:94:0x0252  */
    /* JADX WARN: Code duplicated, block: B:95:0x0256  */
    /* JADX WARN: Code duplicated, block: B:97:0x025c  */
    /* JADX WARN: Code duplicated, block: B:99:0x0266  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [java.lang.Boolean] */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r0v40, types: [java.lang.Boolean] */
    /* JADX WARN: Type inference failed for: r0v41, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r6v13, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r6v4, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r6v40, types: [java.lang.Float] */
    /* JADX WARN: Type inference failed for: r6v41, types: [java.lang.Float] */
    /* JADX WARN: Type inference failed for: r7v10, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v15, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v16 */
    /* JADX WARN: Type inference failed for: r7v25, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v3, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r7v7, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v0, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v11, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v12 */
    /* JADX WARN: Type inference failed for: r8v38, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v4, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v7, types: [java.lang.Long] */
    /* JADX WARN: Type inference failed for: r8v8, types: [java.lang.Long] */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object objM;
        Class cls;
        Object obj2;
        Object objM2;
        PlayerConfigsResponse playerConfigsResponse;
        Calendar calendar;
        SharedPreferences sharedPreferences;
        String strW0;
        ?? l9;
        kotlin.jvm.internal.d dVarA;
        String string;
        Object objM3;
        ?? string2;
        SharedPreferences sharedPreferences2;
        Object objValueOf;
        kotlin.jvm.internal.d dVarA2;
        String string3;
        Object objM4;
        Object string4;
        SharedPreferences sharedPreferences3;
        String strE0;
        kotlin.jvm.internal.d dVarA3;
        String string5;
        Object objM5;
        Object string6;
        int i9;
        Object objB;
        a aVar;
        Integer num;
        int i10 = this.f23534r;
        U u4 = this.f23535s;
        if (i10 == 0) {
            u0.F(obj);
            p130n6.d dVar = u4.f23550c;
            p130n6.d dVar2 = u4.f23550c;
            SharedPreferences sharedPreferences4 = dVar.f21718a;
            String strY0 = o.f18389a.y0();
            ?? l10 = new Long(0L);
            kotlin.jvm.internal.d dVarA4 = kotlin.jvm.internal.p.a(Long.class);
            Class cls2 = Float.TYPE;
            boolean zEquals = dVarA4.equals(kotlin.jvm.internal.p.a(cls2));
            Class cls3 = Boolean.TYPE;
            Class cls4 = Long.TYPE;
            Class cls5 = Integer.TYPE;
            Object obj3 = null;
            if (zEquals) {
                l10 = (Long) new Float(sharedPreferences4.getFloat(strY0, ((Float) l10).floatValue()));
            } else if (dVarA4.equals(kotlin.jvm.internal.p.a(cls5))) {
                l10 = (Long) new Integer(sharedPreferences4.getInt(strY0, ((Integer) l10).intValue()));
            } else if (dVarA4.equals(kotlin.jvm.internal.p.a(cls4))) {
                l10 = new Long(sharedPreferences4.getLong(strY0, l10.longValue()));
            } else if (dVarA4.equals(kotlin.jvm.internal.p.a(String.class))) {
                ?? string7 = sharedPreferences4.getString(strY0, (String) l10);
                if (string7 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Long");
                }
                l10 = (Long) string7;
            } else if (dVarA4.equals(kotlin.jvm.internal.p.a(cls3))) {
                l10 = (Long) Boolean.valueOf(sharedPreferences4.getBoolean(strY0, ((Boolean) l10).booleanValue()));
            } else {
                String string8 = sharedPreferences4.getString(strY0, "");
                if (string8 != null && string8.length() != 0) {
                    try {
                        objM = dVar.f21719b.a(Long.class).b(string8);
                    } catch (Throwable th) {
                        objM = u0.m(th);
                    }
                    if (objM instanceof h) {
                        objM = null;
                    }
                    if (objM != null) {
                        l10 = objM;
                    }
                }
            }
            long jLongValue = ((Number) l10).longValue();
            SharedPreferences sharedPreferences5 = dVar2.f21718a;
            String strX0 = o.f18389a.x0();
            kotlin.jvm.internal.d dVarA5 = kotlin.jvm.internal.p.a(PlayerConfigsResponse.class);
            int iIntValue = 0;
            if (!dVarA5.equals(kotlin.jvm.internal.p.a(cls2))) {
                if (dVarA5.equals(kotlin.jvm.internal.p.a(cls5))) {
                    obj2 = (PlayerConfigsResponse) new Integer(sharedPreferences5.getInt(strX0, 0));
                } else if (dVarA5.equals(kotlin.jvm.internal.p.a(cls4))) {
                    cls = cls2;
                    obj2 = (PlayerConfigsResponse) new Long(sharedPreferences5.getLong(strX0, 0L));
                } else {
                    cls = cls2;
                    if (dVarA5.equals(kotlin.jvm.internal.p.a(String.class))) {
                        Object string9 = sharedPreferences5.getString(strX0, "");
                        if (string9 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.PlayerConfigsResponse");
                        }
                        obj2 = (PlayerConfigsResponse) string9;
                    } else if (dVarA5.equals(kotlin.jvm.internal.p.a(cls3))) {
                        obj2 = (PlayerConfigsResponse) Boolean.valueOf(sharedPreferences5.getBoolean(strX0, false));
                    } else {
                        String string10 = sharedPreferences5.getString(strX0, "");
                        if (string10 == null || string10.length() == 0) {
                            obj2 = null;
                        } else {
                            try {
                                objM2 = dVar2.f21719b.a(PlayerConfigsResponse.class).b(string10);
                            } catch (Throwable th2) {
                                objM2 = u0.m(th2);
                            }
                            if (objM2 instanceof h) {
                                obj2 = null;
                            } else {
                                obj2 = objM2;
                            }
                        }
                    }
                }
                playerConfigsResponse = (PlayerConfigsResponse) obj2;
                calendar = Calendar.getInstance();
                calendar.set(11, 0);
                calendar.set(12, 0);
                calendar.set(13, 0);
                calendar.set(14, 0);
                if (jLongValue >= calendar.getTimeInMillis() || playerConfigsResponse == null) {
                    sharedPreferences = dVar2.f21718a;
                    strW0 = o.f18389a.w0();
                    l9 = new Long(0L);
                    dVarA = kotlin.jvm.internal.p.a(Long.class);
                    if (dVarA.equals(kotlin.jvm.internal.p.a(cls))) {
                        l9 = (Long) new Float(sharedPreferences.getFloat(strW0, ((Float) l9).floatValue()));
                    } else if (dVarA.equals(kotlin.jvm.internal.p.a(cls5))) {
                        l9 = (Long) new Integer(sharedPreferences.getInt(strW0, ((Integer) l9).intValue()));
                    } else {
                        if (dVarA.equals(kotlin.jvm.internal.p.a(cls4))) {
                            objM3 = new Long(sharedPreferences.getLong(strW0, l9.longValue()));
                        } else if (dVarA.equals(kotlin.jvm.internal.p.a(String.class))) {
                            string2 = sharedPreferences.getString(strW0, (String) l9);
                            if (string2 != null) {
                                throw new NullPointerException("null cannot be cast to non-null type kotlin.Long");
                            }
                            l9 = (Long) string2;
                        } else if (dVarA.equals(kotlin.jvm.internal.p.a(cls3))) {
                            l9 = (Long) Boolean.valueOf(sharedPreferences.getBoolean(strW0, ((Boolean) l9).booleanValue()));
                        } else {
                            string = sharedPreferences.getString(strW0, "");
                            if (string != null && string.length() != 0) {
                                try {
                                    objM3 = dVar2.f21719b.a(Long.class).b(string);
                                } catch (Throwable th3) {
                                    objM3 = u0.m(th3);
                                }
                                if (objM3 instanceof h) {
                                    objM3 = null;
                                }
                                if (objM3 != null) {
                                }
                            }
                        }
                        l9 = objM3;
                    }
                    long jLongValue2 = ((Number) l9).longValue();
                    sharedPreferences2 = dVar2.f21718a;
                    objValueOf = Boolean.TRUE;
                    dVarA2 = kotlin.jvm.internal.p.a(Boolean.class);
                    if (dVarA2.equals(kotlin.jvm.internal.p.a(cls))) {
                        objValueOf = (Boolean) new Float(sharedPreferences2.getFloat("FIRST_RUN", ((Float) objValueOf).floatValue()));
                    } else if (dVarA2.equals(kotlin.jvm.internal.p.a(cls5))) {
                        objValueOf = (Boolean) new Integer(sharedPreferences2.getInt("FIRST_RUN", ((Integer) objValueOf).intValue()));
                    } else if (dVarA2.equals(kotlin.jvm.internal.p.a(cls4))) {
                        objValueOf = (Boolean) new Long(sharedPreferences2.getLong("FIRST_RUN", ((Long) objValueOf).longValue()));
                    } else if (dVarA2.equals(kotlin.jvm.internal.p.a(String.class))) {
                        string4 = sharedPreferences2.getString("FIRST_RUN", (String) objValueOf);
                        if (string4 != null) {
                            throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
                        }
                        objValueOf = (Boolean) string4;
                    } else if (dVarA2.equals(kotlin.jvm.internal.p.a(cls3))) {
                        objValueOf = Boolean.valueOf(sharedPreferences2.getBoolean("FIRST_RUN", true));
                    } else {
                        string3 = sharedPreferences2.getString("FIRST_RUN", "");
                        if (string3 != null && string3.length() != 0) {
                            try {
                                objM4 = dVar2.f21719b.a(Boolean.class).b(string3);
                            } catch (Throwable th4) {
                                objM4 = u0.m(th4);
                            }
                            if (objM4 instanceof h) {
                                objM4 = null;
                            }
                            if (objM4 != null) {
                                objValueOf = objM4;
                            }
                        }
                    }
                    boolean zBooleanValue = ((Boolean) objValueOf).booleanValue();
                    sharedPreferences3 = dVar2.f21718a;
                    strE0 = o.f18389a.e0();
                    dVarA3 = kotlin.jvm.internal.p.a(LoginResponse.class);
                    if (dVarA3.equals(kotlin.jvm.internal.p.a(cls))) {
                        obj3 = (LoginResponse) new Float(sharedPreferences3.getFloat(strE0, 0.0f));
                    } else if (dVarA3.equals(kotlin.jvm.internal.p.a(cls5))) {
                        obj3 = (LoginResponse) new Integer(sharedPreferences3.getInt(strE0, 0));
                    } else if (dVarA3.equals(kotlin.jvm.internal.p.a(cls4))) {
                        obj3 = (LoginResponse) new Long(sharedPreferences3.getLong(strE0, 0L));
                    } else if (dVarA3.equals(kotlin.jvm.internal.p.a(String.class))) {
                        string6 = sharedPreferences3.getString(strE0, "");
                        if (string6 != null) {
                            throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.LoginResponse");
                        }
                        obj3 = (LoginResponse) string6;
                    } else if (dVarA3.equals(kotlin.jvm.internal.p.a(cls3))) {
                        obj3 = (LoginResponse) Boolean.valueOf(sharedPreferences3.getBoolean(strE0, false));
                    } else {
                        string5 = sharedPreferences3.getString(strE0, "");
                        if (string5 != null && string5.length() != 0) {
                            try {
                                objM5 = dVar2.f21719b.a(LoginResponse.class).b(string5);
                            } catch (Throwable th5) {
                                objM5 = u0.m(th5);
                            }
                            if (!(objM5 instanceof h)) {
                                obj3 = objM5;
                            }
                        }
                    }
                    if (obj3 != null) {
                        i9 = 1;
                    } else {
                        i9 = 0;
                    }
                    if (playerConfigsResponse != null && (num = playerConfigsResponse.f16139b) != null) {
                        iIntValue = num.intValue();
                    }
                    PlayerConfigRequest playerConfigRequest = new PlayerConfigRequest(jLongValue2, zBooleanValue ? 1 : 0, i9, iIntValue);
                    p175s6.a aVar2 = u4.f23548a;
                    String strG = p165r6.a.g(T8.l.u(dVar2), o.f18389a.z0());
                    this.f23534r = 1;
                    objB = aVar2.b(strG, playerConfigRequest, this);
                    aVar = a.f19475a;
                    if (objB == aVar) {
                        return aVar;
                    }
                }
                return new b(l.f16813a);
            }
            obj2 = (PlayerConfigsResponse) new Float(sharedPreferences5.getFloat(strX0, 0.0f));
            cls = cls2;
            playerConfigsResponse = (PlayerConfigsResponse) obj2;
            calendar = Calendar.getInstance();
            calendar.set(11, 0);
            calendar.set(12, 0);
            calendar.set(13, 0);
            calendar.set(14, 0);
            if (jLongValue >= calendar.getTimeInMillis()) {
            }
            sharedPreferences = dVar2.f21718a;
            strW0 = o.f18389a.w0();
            l9 = new Long(0L);
            dVarA = kotlin.jvm.internal.p.a(Long.class);
            if (dVarA.equals(kotlin.jvm.internal.p.a(cls))) {
                l9 = (Long) new Float(sharedPreferences.getFloat(strW0, ((Float) l9).floatValue()));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(cls5))) {
                l9 = (Long) new Integer(sharedPreferences.getInt(strW0, ((Integer) l9).intValue()));
            } else {
                if (dVarA.equals(kotlin.jvm.internal.p.a(cls4))) {
                    objM3 = new Long(sharedPreferences.getLong(strW0, l9.longValue()));
                } else if (dVarA.equals(kotlin.jvm.internal.p.a(String.class))) {
                    string2 = sharedPreferences.getString(strW0, (String) l9);
                    if (string2 != null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.Long");
                    }
                    l9 = (Long) string2;
                } else if (dVarA.equals(kotlin.jvm.internal.p.a(cls3))) {
                    l9 = (Long) Boolean.valueOf(sharedPreferences.getBoolean(strW0, ((Boolean) l9).booleanValue()));
                } else {
                    string = sharedPreferences.getString(strW0, "");
                    if (string != null) {
                        objM3 = dVar2.f21719b.a(Long.class).b(string);
                        if (objM3 instanceof h) {
                            objM3 = null;
                        }
                        if (objM3 != null) {
                        }
                    }
                }
                l9 = objM3;
            }
            long jLongValue3 = ((Number) l9).longValue();
            sharedPreferences2 = dVar2.f21718a;
            objValueOf = Boolean.TRUE;
            dVarA2 = kotlin.jvm.internal.p.a(Boolean.class);
            if (dVarA2.equals(kotlin.jvm.internal.p.a(cls))) {
                objValueOf = (Boolean) new Float(sharedPreferences2.getFloat("FIRST_RUN", ((Float) objValueOf).floatValue()));
            } else if (dVarA2.equals(kotlin.jvm.internal.p.a(cls5))) {
                objValueOf = (Boolean) new Integer(sharedPreferences2.getInt("FIRST_RUN", ((Integer) objValueOf).intValue()));
            } else if (dVarA2.equals(kotlin.jvm.internal.p.a(cls4))) {
                objValueOf = (Boolean) new Long(sharedPreferences2.getLong("FIRST_RUN", ((Long) objValueOf).longValue()));
            } else if (dVarA2.equals(kotlin.jvm.internal.p.a(String.class))) {
                string4 = sharedPreferences2.getString("FIRST_RUN", (String) objValueOf);
                if (string4 != null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
                }
                objValueOf = (Boolean) string4;
            } else if (dVarA2.equals(kotlin.jvm.internal.p.a(cls3))) {
                objValueOf = Boolean.valueOf(sharedPreferences2.getBoolean("FIRST_RUN", true));
            } else {
                string3 = sharedPreferences2.getString("FIRST_RUN", "");
                if (string3 != null) {
                    objM4 = dVar2.f21719b.a(Boolean.class).b(string3);
                    if (objM4 instanceof h) {
                        objM4 = null;
                    }
                    if (objM4 != null) {
                        objValueOf = objM4;
                    }
                }
            }
            boolean zBooleanValue2 = ((Boolean) objValueOf).booleanValue();
            sharedPreferences3 = dVar2.f21718a;
            strE0 = o.f18389a.e0();
            dVarA3 = kotlin.jvm.internal.p.a(LoginResponse.class);
            if (dVarA3.equals(kotlin.jvm.internal.p.a(cls))) {
                obj3 = (LoginResponse) new Float(sharedPreferences3.getFloat(strE0, 0.0f));
            } else if (dVarA3.equals(kotlin.jvm.internal.p.a(cls5))) {
                obj3 = (LoginResponse) new Integer(sharedPreferences3.getInt(strE0, 0));
            } else if (dVarA3.equals(kotlin.jvm.internal.p.a(cls4))) {
                obj3 = (LoginResponse) new Long(sharedPreferences3.getLong(strE0, 0L));
            } else if (dVarA3.equals(kotlin.jvm.internal.p.a(String.class))) {
                string6 = sharedPreferences3.getString(strE0, "");
                if (string6 != null) {
                    throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.LoginResponse");
                }
                obj3 = (LoginResponse) string6;
            } else if (dVarA3.equals(kotlin.jvm.internal.p.a(cls3))) {
                obj3 = (LoginResponse) Boolean.valueOf(sharedPreferences3.getBoolean(strE0, false));
            } else {
                string5 = sharedPreferences3.getString(strE0, "");
                if (string5 != null) {
                    objM5 = dVar2.f21719b.a(LoginResponse.class).b(string5);
                    if (!(objM5 instanceof h)) {
                        obj3 = objM5;
                    }
                }
            }
            if (obj3 != null) {
                i9 = 1;
            } else {
                i9 = 0;
            }
            if (playerConfigsResponse != null) {
                iIntValue = num.intValue();
            }
            PlayerConfigRequest playerConfigRequest2 = new PlayerConfigRequest(jLongValue3, zBooleanValue2 ? 1 : 0, i9, iIntValue);
            p175s6.a aVar3 = u4.f23548a;
            String strG2 = p165r6.a.g(T8.l.u(dVar2), o.f18389a.z0());
            this.f23534r = 1;
            objB = aVar3.b(strG2, playerConfigRequest2, this);
            aVar = a.f19475a;
            if (objB == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
            objB = obj;
        }
        PlayerConfigsResponse playerConfigsResponse2 = ((PlayerConfigParentResponse) objB).f16135a;
        p130n6.d dVar3 = u4.f23550c;
        o oVar = o.f18389a;
        String strX1 = oVar.x0();
        SharedPreferences.Editor editorEdit = dVar3.f21718a.edit();
        editorEdit.putString(strX1, dVar3.f21719b.a(PlayerConfigsResponse.class).d(playerConfigsResponse2));
        editorEdit.apply();
        p130n6.d dVar4 = u4.f23550c;
        String strY1 = oVar.y0();
        Long l11 = new Long(System.currentTimeMillis());
        SharedPreferences.Editor editorEdit2 = dVar4.f21718a.edit();
        editorEdit2.putLong(strY1, l11.longValue());
        editorEdit2.apply();
        return new b(l.f16813a);
    }
}
