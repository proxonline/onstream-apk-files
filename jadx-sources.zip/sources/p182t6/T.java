package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.response.PlayerConfigsResponse;
import h8.d;
import p039d8.h;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class T extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ U f23547r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public T(U u4, d dVar) {
        super(2, dVar);
        this.f23547r = u4;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new T(this.f23547r, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        T t8 = (T) create((A) obj, (d) obj2);
        l lVar = l.f16813a;
        t8.invokeSuspend(lVar);
        return lVar;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00c1  */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object obj2;
        Object objM;
        u0.F(obj);
        U u4 = this.f23547r;
        p130n6.d dVar = u4.f23550c;
        SharedPreferences sharedPreferences = dVar.f21718a;
        String strX0 = o.f18389a.x0();
        kotlin.jvm.internal.d dVarA = kotlin.jvm.internal.p.a(PlayerConfigsResponse.class);
        if (dVarA.equals(kotlin.jvm.internal.p.a(Float.TYPE))) {
            obj2 = (PlayerConfigsResponse) new Float(sharedPreferences.getFloat(strX0, 0.0f));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Integer.TYPE))) {
            obj2 = (PlayerConfigsResponse) new Integer(sharedPreferences.getInt(strX0, 0));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Long.TYPE))) {
            obj2 = (PlayerConfigsResponse) new Long(sharedPreferences.getLong(strX0, 0L));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(String.class))) {
            Object string = sharedPreferences.getString(strX0, "");
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.PlayerConfigsResponse");
            }
            obj2 = (PlayerConfigsResponse) string;
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Boolean.TYPE))) {
            obj2 = (PlayerConfigsResponse) Boolean.valueOf(sharedPreferences.getBoolean(strX0, false));
        } else {
            String string2 = sharedPreferences.getString(strX0, "");
            if (string2 == null || string2.length() == 0) {
                obj2 = null;
            } else {
                try {
                    objM = dVar.f21719b.a(PlayerConfigsResponse.class).b(string2);
                } catch (Throwable th) {
                    objM = u0.m(th);
                }
                if (objM instanceof h) {
                    obj2 = null;
                } else {
                    obj2 = objM;
                }
            }
        }
        PlayerConfigsResponse playerConfigsResponse = (PlayerConfigsResponse) obj2;
        if (playerConfigsResponse != null) {
            Integer num = playerConfigsResponse.f16139b;
            Integer num2 = playerConfigsResponse.f16138a;
            if (num2 != null && num2.intValue() == 1 && num != null && num.intValue() > 0) {
                p130n6.d dVar2 = u4.f23550c;
                String strX1 = o.f18389a.x0();
                PlayerConfigsResponse playerConfigsResponse2 = new PlayerConfigsResponse(playerConfigsResponse.f16138a, new Integer(num.intValue() - 1), null, 4, null);
                SharedPreferences.Editor editorEdit = dVar2.f21718a.edit();
                editorEdit.putString(strX1, dVar2.f21719b.a(PlayerConfigsResponse.class).d(playerConfigsResponse2));
                editorEdit.apply();
            }
        }
        return l.f16813a;
    }
}
