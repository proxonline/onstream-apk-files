package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class D extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23502r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23503s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ long f23504t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public D(J j, long j9, d dVar) {
        super(2, dVar);
        this.f23503s = j;
        this.f23504t = j9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new D(this.f23503s, this.f23504t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((D) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23502r;
        if (i9 == 0) {
            u0.F(obj);
            J j = this.f23503s;
            a aVar = j.f23525a;
            String str = T8.l.u(j.f23526b) + o.f18389a.I0() + this.f23504t;
            this.f23502r = 1;
            Object objG = aVar.g(str, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (objG == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(l.f16813a);
    }
}
