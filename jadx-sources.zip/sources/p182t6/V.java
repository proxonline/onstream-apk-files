package p182t6;

import B8.A;
import com.maertsno.data.model.request.trakt.TraktWatchlistRequest;
import h8.d;
import p039d8.l;
import p084i8.a;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.k;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class V extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23553r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ d0 f23554s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ TraktWatchlistRequest f23555t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public V(d0 d0Var, TraktWatchlistRequest traktWatchlistRequest, d dVar) {
        super(2, dVar);
        this.f23554s = d0Var;
        this.f23555t = traktWatchlistRequest;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new V(this.f23554s, this.f23555t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((V) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23553r;
        if (i9 == 0) {
            u0.F(obj);
            k kVar = (k) this.f23554s.f23585a.get();
            this.f23553r = 1;
            Object objE = kVar.e(this.f23555t, this);
            a aVar = a.f19475a;
            if (objE == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(l.f16813a);
    }
}
