package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p054f5.b;
import p084i8.a;
import p093j8.i;
import p139o6.e;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class E extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23505r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23506s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ long f23507t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public E(J j, long j9, d dVar) {
        super(2, dVar);
        this.f23506s = j;
        this.f23507t = j9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new E(this.f23506s, this.f23507t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((E) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23505r;
        l lVar = l.f16813a;
        if (i9 == 0) {
            u0.F(obj);
            e eVar = this.f23506s.f23529e;
            this.f23505r = 1;
            Object objC = b.C(eVar.f22119a, this, new p139o6.b(this.f23507t, 0), false, true);
            a aVar = a.f19475a;
            if (objC != aVar) {
                objC = lVar;
            }
            if (objC == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new p100k6.b(lVar);
    }
}
