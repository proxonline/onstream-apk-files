package p182t6;

import B8.A;
import com.maertsno.data.model.request.ReportRequest;
import h8.d;
import java.util.List;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class H extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23516r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23517s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ long f23518t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ List f23519u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ String f23520v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public H(J j, long j9, List list, String str, d dVar) {
        super(2, dVar);
        this.f23517s = j;
        this.f23518t = j9;
        this.f23519u = list;
        this.f23520v = str;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new H(this.f23517s, this.f23518t, this.f23519u, this.f23520v, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((H) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23516r;
        if (i9 == 0) {
            u0.F(obj);
            J j = this.f23517s;
            a aVar = j.f23525a;
            String strG = p165r6.a.g(T8.l.u(j.f23526b), o.f18389a.K0());
            String str = this.f23520v;
            if (str.length() == 0) {
                str = null;
            }
            ReportRequest reportRequest = new ReportRequest(this.f23518t, this.f23519u, str);
            this.f23516r = 1;
            Object objW = aVar.w(strG, reportRequest, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (objW == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(l.f16813a);
    }
}
