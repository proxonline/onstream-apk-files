package p182t6;

import T8.l;
import android.content.SharedPreferences;
import com.maertsno.data.model.request.RefreshTokenRequest;
import com.maertsno.data.model.response.LoginResponse;
import com.maertsno.data.model.response.RefreshTokenResponse;
import com.maertsno.data.model.response.TokenDataResponse;
import com.maertsno.data.model.response.TokenResponse;
import kotlin.jvm.internal.p;
import p039d8.h;
import p064g6.o;
import p130n6.d;
import p139o6.k;
import p175s6.a;
import p175s6.c;
import p195v5.u0;
import p229z8.e;

/* JADX INFO: loaded from: classes.dex */
public final class s0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f23692a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f23693b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d f23694c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final k f23695d;

    public s0(a aVar, c cVar, d dVar, k kVar) {
        this.f23692a = aVar;
        this.f23693b = cVar;
        this.f23694c = dVar;
        this.f23695d = kVar;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x00b3  */
    public final LoginResponse a() {
        Object objM;
        d dVar = this.f23694c;
        SharedPreferences sharedPreferences = dVar.f21718a;
        String strE0 = o.f18389a.e0();
        kotlin.jvm.internal.d dVarA = p.a(LoginResponse.class);
        if (dVarA.equals(p.a(Float.TYPE))) {
            objM = (LoginResponse) Float.valueOf(sharedPreferences.getFloat(strE0, 0.0f));
        } else if (dVarA.equals(p.a(Integer.TYPE))) {
            objM = (LoginResponse) Integer.valueOf(sharedPreferences.getInt(strE0, 0));
        } else if (dVarA.equals(p.a(Long.TYPE))) {
            objM = (LoginResponse) Long.valueOf(sharedPreferences.getLong(strE0, 0L));
        } else if (dVarA.equals(p.a(String.class))) {
            Object string = sharedPreferences.getString(strE0, "");
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.LoginResponse");
            }
            objM = (LoginResponse) string;
        } else if (dVarA.equals(p.a(Boolean.TYPE))) {
            objM = (LoginResponse) Boolean.valueOf(sharedPreferences.getBoolean(strE0, false));
        } else {
            String string2 = sharedPreferences.getString(strE0, "");
            if (string2 == null || string2.length() == 0) {
                objM = null;
            } else {
                try {
                    objM = dVar.f21719b.a(LoginResponse.class).b(string2);
                } catch (Throwable th) {
                    objM = u0.m(th);
                }
                if (objM instanceof h) {
                    objM = null;
                }
            }
        }
        return (LoginResponse) objM;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0015  */
    public final Object b(p093j8.c cVar) {
        g0 g0Var;
        LoginResponse loginResponse;
        if (cVar instanceof g0) {
            g0Var = (g0) cVar;
            int i9 = g0Var.f23611u;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                g0Var.f23611u = i9 - Integer.MIN_VALUE;
            } else {
                g0Var = new g0(this, cVar);
            }
        } else {
            g0Var = new g0(this, cVar);
        }
        Object obj = g0Var.f23609s;
        int i10 = g0Var.f23611u;
        d dVar = this.f23694c;
        try {
            if (i10 == 0) {
                u0.F(obj);
                LoginResponse loginResponseY = l.y(dVar);
                if (loginResponseY != null) {
                    TokenDataResponse tokenDataResponse = loginResponseY.f16087b;
                    TokenResponse tokenResponse = tokenDataResponse.f16220c;
                    if (tokenResponse != null && !e.j0(tokenResponse.f16224a)) {
                        return tokenResponse.f16224a;
                    }
                    String str = tokenDataResponse.f16219b.f16224a;
                    if (!e.j0(str)) {
                        c cVar2 = this.f23693b;
                        String str2 = l.u(dVar) + o.f18389a.E0();
                        RefreshTokenRequest refreshTokenRequest = new RefreshTokenRequest(str);
                        g0Var.f23608r = loginResponseY;
                        g0Var.f23611u = 1;
                        Object objA = cVar2.a(str2, refreshTokenRequest, g0Var);
                        p084i8.a aVar = p084i8.a.f19475a;
                        if (objA == aVar) {
                            return aVar;
                        }
                        loginResponse = loginResponseY;
                        obj = objA;
                    }
                }
                return null;
            }
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            loginResponse = g0Var.f23608r;
            u0.F(obj);
            TokenDataResponse tokenDataResponse2 = ((RefreshTokenResponse) obj).f16163a;
            String str3 = tokenDataResponse2.f16218a.f16224a;
            String str4 = tokenDataResponse2.f16219b.f16224a;
            TokenResponse tokenResponse2 = tokenDataResponse2.f16220c;
            String str5 = tokenResponse2 != null ? tokenResponse2.f16224a : null;
            TokenDataResponse tokenDataResponse3 = loginResponse.f16087b;
            TokenResponse tokenResponse3 = tokenDataResponse3.f16218a;
            kotlin.jvm.internal.h.e(str3, "<set-?>");
            tokenResponse3.f16224a = str3;
            TokenResponse tokenResponse4 = tokenDataResponse3.f16219b;
            kotlin.jvm.internal.h.e(str4, "<set-?>");
            tokenResponse4.f16224a = str4;
            if (str5 == null) {
                tokenDataResponse3.f16220c = null;
            } else {
                TokenResponse tokenResponse5 = tokenDataResponse3.f16220c;
                if (tokenResponse5 != null) {
                    tokenResponse5.f16224a = str5;
                }
            }
            l.O(dVar, loginResponse);
            return str5;
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Code duplicated, block: B:32:0x00b3  */
    public final boolean c() {
        Object objM;
        d dVar = this.f23694c;
        SharedPreferences sharedPreferences = dVar.f21718a;
        String strE0 = o.f18389a.e0();
        kotlin.jvm.internal.d dVarA = p.a(LoginResponse.class);
        if (dVarA.equals(p.a(Float.TYPE))) {
            objM = (LoginResponse) Float.valueOf(sharedPreferences.getFloat(strE0, 0.0f));
        } else if (dVarA.equals(p.a(Integer.TYPE))) {
            objM = (LoginResponse) Integer.valueOf(sharedPreferences.getInt(strE0, 0));
        } else if (dVarA.equals(p.a(Long.TYPE))) {
            objM = (LoginResponse) Long.valueOf(sharedPreferences.getLong(strE0, 0L));
        } else if (dVarA.equals(p.a(String.class))) {
            Object string = sharedPreferences.getString(strE0, "");
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.LoginResponse");
            }
            objM = (LoginResponse) string;
        } else if (dVarA.equals(p.a(Boolean.TYPE))) {
            objM = (LoginResponse) Boolean.valueOf(sharedPreferences.getBoolean(strE0, false));
        } else {
            String string2 = sharedPreferences.getString(strE0, "");
            if (string2 == null || string2.length() == 0) {
                objM = null;
            } else {
                try {
                    objM = dVar.f21719b.a(LoginResponse.class).b(string2);
                } catch (Throwable th) {
                    objM = u0.m(th);
                }
                if (objM instanceof h) {
                    objM = null;
                }
            }
        }
        return objM != null;
    }
}
