package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.response.DownloaderResponse;
import h8.d;
import p039d8.h;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.a;
import p100k6.b;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class P extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ U f23543r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public P(U u4, d dVar) {
        super(2, dVar);
        this.f23543r = u4;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new P(this.f23543r, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((P) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00c1  */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object obj2;
        Object objM;
        u0.F(obj);
        p130n6.d dVar = this.f23543r.f23550c;
        SharedPreferences sharedPreferences = dVar.f21718a;
        String strF = o.f18389a.F();
        kotlin.jvm.internal.d dVarA = kotlin.jvm.internal.p.a(DownloaderResponse.class);
        if (dVarA.equals(kotlin.jvm.internal.p.a(Float.TYPE))) {
            obj2 = (DownloaderResponse) new Float(sharedPreferences.getFloat(strF, 0.0f));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Integer.TYPE))) {
            obj2 = (DownloaderResponse) new Integer(sharedPreferences.getInt(strF, 0));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Long.TYPE))) {
            obj2 = (DownloaderResponse) new Long(sharedPreferences.getLong(strF, 0L));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(String.class))) {
            Object string = sharedPreferences.getString(strF, "");
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.DownloaderResponse");
            }
            obj2 = (DownloaderResponse) string;
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Boolean.TYPE))) {
            obj2 = (DownloaderResponse) Boolean.valueOf(sharedPreferences.getBoolean(strF, false));
        } else {
            String string2 = sharedPreferences.getString(strF, "");
            if (string2 == null || string2.length() == 0) {
                obj2 = null;
            } else {
                try {
                    objM = dVar.f21719b.a(DownloaderResponse.class).b(string2);
                } catch (Throwable th) {
                    objM = u0.m(th);
                }
                if (objM instanceof h) {
                    obj2 = null;
                } else {
                    obj2 = objM;
                }
            }
        }
        DownloaderResponse downloaderResponse = (DownloaderResponse) obj2;
        return downloaderResponse != null ? new b(downloaderResponse) : new a(new p091j6.a(null, null));
    }
}
