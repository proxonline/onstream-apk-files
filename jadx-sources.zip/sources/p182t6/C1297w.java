package p182t6;

import B8.A;
import h8.d;
import java.util.LinkedHashMap;
import p039d8.g;
import p039d8.l;
import p048e8.u;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1297w extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23706r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f23707s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f23708t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ J f23709u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ String f23710v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1297w(int i9, int i10, d dVar, String str, J j) {
        super(2, dVar);
        this.f23707s = i9;
        this.f23708t = i10;
        this.f23709u = j;
        this.f23710v = str;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        J j = this.f23709u;
        return new C1297w(this.f23707s, this.f23708t, dVar, this.f23710v, j);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1297w) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23706r;
        if (i9 == 0) {
            u0.F(obj);
            LinkedHashMap linkedHashMapP = u.P(new g("page", String.valueOf(this.f23707s)), new g("limit", String.valueOf(this.f23708t)));
            J j = this.f23709u;
            a aVar = j.f23525a;
            String str = T8.l.u(j.f23526b) + o.f18389a.C0() + this.f23710v;
            this.f23706r = 1;
            obj = aVar.p(str, linkedHashMapP, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
