package p182t6;

import B8.A;
import com.maertsno.data.model.request.trakt.TraktLogoutRequest;
import com.maertsno.data.model.response.trakt.TraktLoginResponse;
import h8.d;
import p039d8.l;
import p064g6.o;
import p084i8.a;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.k;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class Z extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23563r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ d0 f23564s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Z(d0 d0Var, d dVar) {
        super(2, dVar);
        this.f23564s = d0Var;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new Z(this.f23564s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((Z) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        String str;
        int i9 = this.f23563r;
        d0 d0Var = this.f23564s;
        try {
            if (i9 == 0) {
                u0.F(obj);
                TraktLoginResponse traktLoginResponseX = T8.l.x(d0Var.f23586b);
                if (traktLoginResponseX != null && (str = traktLoginResponseX.f16264a) != null) {
                    k kVar = (k) d0Var.f23585a.get();
                    o oVar = o.f18389a;
                    TraktLogoutRequest traktLogoutRequest = new TraktLogoutRequest(oVar.P0(), oVar.T0(), str);
                    this.f23563r = 1;
                    obj = kVar.d(traktLogoutRequest, this);
                    a aVar = a.f19475a;
                    if (obj == aVar) {
                        return aVar;
                    }
                }
                T8.l.M(d0Var.f23586b, null);
                T8.l.N(d0Var.f23586b, null);
                return new b(l.f16813a);
            }
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        } catch (Throwable th) {
            u0.m(th);
        }
        T8.l.M(d0Var.f23586b, null);
        T8.l.N(d0Var.f23586b, null);
        return new b(l.f16813a);
    }
}
