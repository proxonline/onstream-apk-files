package p182t6;

import B8.A;
import p130n6.d;
import p139o6.e;
import p139o6.i;
import p139o6.k;
import p175s6.a;

/* JADX INFO: loaded from: classes.dex */
public final class J {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f23525a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f23526b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final k f23527c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final i f23528d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final e f23529e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final A f23530f;

    public J(a aVar, d dVar, k kVar, i iVar, e eVar, A a10) {
        this.f23525a = aVar;
        this.f23526b = dVar;
        this.f23527c = kVar;
        this.f23528d = iVar;
        this.f23529e = eVar;
        this.f23530f = a10;
    }
}
