package p182t6;

import B8.A;
import h8.d;
import java.util.List;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class j0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23634r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ s0 f23635s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ List f23636t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j0(s0 s0Var, List list, d dVar) {
        super(2, dVar);
        this.f23635s = s0Var;
        this.f23636t = list;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new j0(this.f23635s, this.f23636t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((j0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23634r;
        if (i9 == 0) {
            u0.F(obj);
            s0 s0Var = this.f23635s;
            a aVar = s0Var.f23692a;
            String strG = p165r6.a.g(T8.l.u(s0Var.f23694c), o.f18389a.Y0());
            this.f23634r = 1;
            obj = aVar.I(strG, this.f23636t, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
