package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1299y extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23715r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23716s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1299y(J j, d dVar) {
        super(2, dVar);
        this.f23716s = j;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1299y(this.f23716s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1299y) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23715r;
        if (i9 == 0) {
            u0.F(obj);
            J j = this.f23716s;
            a aVar = j.f23525a;
            String strG = p165r6.a.g(T8.l.u(j.f23526b), o.f18389a.J0());
            this.f23715r = 1;
            obj = aVar.D(strG, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
