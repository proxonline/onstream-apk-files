package p182t6;

import B8.A;
import h8.d;
import java.util.LinkedHashMap;
import java.util.List;
import p039d8.g;
import p039d8.l;
import p048e8.u;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1285j extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23625r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f23626s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f23627t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ String f23628u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ String f23629v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ List f23630w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ long f23631x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final /* synthetic */ g f23632y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final /* synthetic */ J f23633z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1285j(int i9, int i10, String str, String str2, List list, long j, g gVar, J j9, d dVar) {
        super(2, dVar);
        this.f23626s = i9;
        this.f23627t = i10;
        this.f23628u = str;
        this.f23629v = str2;
        this.f23630w = list;
        this.f23631x = j;
        this.f23632y = gVar;
        this.f23633z = j9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1285j(this.f23626s, this.f23627t, this.f23628u, this.f23629v, this.f23630w, this.f23631x, this.f23632y, this.f23633z, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1285j) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23625r;
        if (i9 == 0) {
            u0.F(obj);
            LinkedHashMap linkedHashMapP = u.P(new g("page", String.valueOf(this.f23626s)), new g("limit", String.valueOf(this.f23627t)));
            linkedHashMapP.put("media_type", this.f23628u);
            linkedHashMapP.put("quality", this.f23629v);
            List<Long> list = this.f23630w;
            if (list.isEmpty()) {
                list = null;
            }
            long j = this.f23631x;
            if (j > -1) {
                linkedHashMapP.put("country", String.valueOf(j));
            }
            g gVar = this.f23632y;
            if (gVar != null) {
                linkedHashMapP.put(gVar.f16805a, gVar.f16806b);
            }
            J j9 = this.f23633z;
            a aVar = j9.f23525a;
            String strG = p165r6.a.g(T8.l.u(j9.f23526b), o.f18389a.A());
            this.f23625r = 1;
            obj = aVar.j(strG, linkedHashMapP, list, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
