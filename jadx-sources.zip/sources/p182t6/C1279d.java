package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p054f5.b;
import p083i7.C0997j;
import p084i8.a;
import p093j8.i;
import p139o6.k;
import p149p6.c;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: renamed from: t6.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1279d extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23582r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23583s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ c f23584t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1279d(J j, c cVar, d dVar) {
        super(2, dVar);
        this.f23583s = j;
        this.f23584t = cVar;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1279d(this.f23583s, this.f23584t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1279d) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23582r;
        l lVar = l.f16813a;
        if (i9 == 0) {
            u0.F(obj);
            k kVar = this.f23583s.f23527c;
            this.f23582r = 1;
            Object objC = b.C(kVar.f22132a, this, new C0997j(kVar, 5, this.f23584t), false, true);
            a aVar = a.f19475a;
            if (objC != aVar) {
                objC = lVar;
            }
            if (objC == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new p100k6.b(lVar);
    }
}
