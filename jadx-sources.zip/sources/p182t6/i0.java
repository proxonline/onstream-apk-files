package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class i0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23621r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ s0 f23622s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f23623t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ int f23624u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i0(s0 s0Var, String str, int i9, d dVar) {
        super(2, dVar);
        this.f23622s = s0Var;
        this.f23623t = str;
        this.f23624u = i9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new i0(this.f23622s, this.f23623t, this.f23624u, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((i0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23621r;
        if (i9 == 0) {
            u0.F(obj);
            s0 s0Var = this.f23622s;
            a aVar = s0Var.f23692a;
            String strG = p165r6.a.g(T8.l.u(s0Var.f23694c), o.f18389a.Z0());
            this.f23621r = 1;
            obj = aVar.H(strG, this.f23623t, this.f23624u, p082i6.a.a(), this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
