package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p054f5.b;
import p084i8.a;
import p093j8.i;
import p139o6.j;
import p139o6.k;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class f0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23596r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ s0 f23597s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f23598t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f0(s0 s0Var, String str, d dVar) {
        super(2, dVar);
        this.f23597s = s0Var;
        this.f23598t = str;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new f0(this.f23597s, this.f23598t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((f0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23596r;
        if (i9 == 0) {
            u0.F(obj);
            k kVar = this.f23597s.f23695d;
            this.f23596r = 1;
            obj = b.C(kVar.f22132a, this, new j(this.f23598t, 0), true, false);
            a aVar = a.f19475a;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new p100k6.b(obj);
    }
}
