package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.request.LoginRequest;
import com.maertsno.data.model.response.LoginResponse;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class l0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23645r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ s0 f23646s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f23647t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ String f23648u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l0(s0 s0Var, String str, String str2, d dVar) {
        super(2, dVar);
        this.f23646s = s0Var;
        this.f23647t = str;
        this.f23648u = str2;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new l0(this.f23646s, this.f23647t, this.f23648u, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((l0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23645r;
        s0 s0Var = this.f23646s;
        if (i9 == 0) {
            u0.F(obj);
            a aVar = s0Var.f23692a;
            String strG = p165r6.a.g(T8.l.u(s0Var.f23694c), o.f18389a.m0());
            LoginRequest loginRequest = new LoginRequest(this.f23647t, this.f23648u);
            this.f23645r = 1;
            obj = aVar.e(strG, loginRequest, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        LoginResponse loginResponse = (LoginResponse) obj;
        p130n6.d dVar = s0Var.f23694c;
        String strE0 = o.f18389a.e0();
        SharedPreferences.Editor editorEdit = dVar.f21718a.edit();
        editorEdit.putString(strE0, dVar.f21719b.a(LoginResponse.class).d(loginResponse));
        editorEdit.apply();
        return new b(loginResponse);
    }
}
