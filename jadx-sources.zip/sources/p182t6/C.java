package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p054f5.b;
import p084i8.a;
import p093j8.i;
import p139o6.k;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class C extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23499r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23500s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ long f23501t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C(J j, long j9, d dVar) {
        super(2, dVar);
        this.f23500s = j;
        this.f23501t = j9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C(this.f23500s, this.f23501t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23499r;
        l lVar = l.f16813a;
        if (i9 == 0) {
            u0.F(obj);
            k kVar = this.f23500s.f23527c;
            this.f23499r = 1;
            Object objC = b.C(kVar.f22132a, this, new p139o6.b(this.f23501t, 1), false, true);
            a aVar = a.f19475a;
            if (objC != aVar) {
                objC = lVar;
            }
            if (objC == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new p100k6.b(lVar);
    }
}
