package p182t6;

import B8.A;
import a9.C0496o;
import a9.N;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class B extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23496r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23497s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ long f23498t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public B(J j, long j9, d dVar) {
        super(2, dVar);
        this.f23497s = j;
        this.f23498t = j9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new B(this.f23497s, this.f23498t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((B) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23496r;
        if (i9 == 0) {
            u0.F(obj);
            J j = this.f23497s;
            a aVar = j.f23525a;
            String str = T8.l.u(j.f23526b) + o.f18389a.r() + "/" + this.f23498t;
            this.f23496r = 1;
            obj = aVar.y(str, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        N n9 = (N) obj;
        if (n9.f10067a.f()) {
            return new b(l.f16813a);
        }
        throw new C0496o(n9);
    }
}
