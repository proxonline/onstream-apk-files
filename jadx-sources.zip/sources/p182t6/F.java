package p182t6;

import B8.A;
import B8.C0042h;
import H0.D;
import H0.E;
import H0.w;
import H0.y;
import H0.z;
import N0.c;
import h8.d;
import h8.f;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;
import kotlin.jvm.internal.h;
import p039d8.l;
import p084i8.a;
import p093j8.i;
import p100k6.b;
import p139o6.e;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class F extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23508r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23509s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ Object f23510t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public F(J j, List list, d dVar) {
        super(2, dVar);
        this.f23509s = j;
        this.f23510t = list;
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [java.lang.Object, java.util.List] */
    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new F(this.f23509s, this.f23510t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((F) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [java.lang.Object, java.util.List] */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object objC;
        int i9 = this.f23508r;
        l lVar = l.f16813a;
        if (i9 == 0) {
            u0.F(obj);
            e eVar = this.f23509s.f23529e;
            this.f23508r = 1;
            w wVar = eVar.f22119a;
            p139o6.d dVar = new p139o6.d(eVar, this.f23510t, null);
            if (wVar.l()) {
                z zVar = new z(new c(wVar, null, dVar), null);
                D d9 = (D) getContext().get(D.f2718c);
                f fVar = d9 != null ? d9.f2719a : null;
                if (fVar != null) {
                    objC = B8.D.C(fVar, zVar, this);
                } else {
                    h8.i context = getContext();
                    C0042h c0042h = new C0042h(1, T8.l.A(this));
                    c0042h.s();
                    try {
                        E e9 = wVar.f2870d;
                        if (e9 == null) {
                            h.j("internalTransactionExecutor");
                            throw null;
                        }
                        e9.execute(new y(context, c0042h, wVar, zVar, 0));
                        objC = c0042h.r();
                    } catch (RejectedExecutionException e10) {
                        c0042h.d(new IllegalStateException("Unable to acquire a thread to perform the database transaction.", e10));
                    }
                }
            } else {
                G8.e eVar2 = wVar.f2867a;
                if (eVar2 == null) {
                    h.j("coroutineScope");
                    throw null;
                }
                objC = B8.D.C(eVar2.f2636a, new N0.f(wVar, null, dVar), this);
            }
            a aVar = a.f19475a;
            if (objC != aVar) {
                objC = lVar;
            }
            if (objC == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(lVar);
    }
}
