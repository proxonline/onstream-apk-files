package p182t6;

import B8.A;
import B8.D;
import B8.M;
import P7.C;
import Q7.c;
import Q7.e;
import com.maertsno.data.model.response.HomeResponse;
import com.maertsno.data.model.response.ResultResponse;
import h8.d;
import java.util.List;
import p039d8.h;
import p039d8.l;
import p048e8.q;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1291p extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23667r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ boolean f23668s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ J f23669t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1291p(boolean z9, J j, d dVar) {
        super(2, dVar);
        this.f23668s = z9;
        this.f23669t = j;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1291p(this.f23668s, this.f23669t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1291p) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object objM;
        int i9 = this.f23667r;
        List list = q.f17244a;
        J j = this.f23669t;
        if (i9 == 0) {
            u0.F(obj);
            if (this.f23668s) {
                p130n6.d dVar = j.f23526b;
                String string = dVar.f21718a.getString(o.f18389a.S(), "");
                c cVarF = C.f(HomeResponse.class);
                if (string != null && string.length() != 0) {
                    try {
                        objM = (List) dVar.f21719b.b(cVarF, e.f6609a, null).b(string);
                    } catch (Throwable th) {
                        objM = u0.m(th);
                    }
                    List list2 = (List) (objM instanceof h ? null : objM);
                    if (list2 != null) {
                        list = list2;
                    }
                }
                return new b(list);
            }
            a aVar = j.f23525a;
            String strG = p165r6.a.g(T8.l.u(j.f23526b), o.f18389a.D());
            this.f23667r = 1;
            obj = aVar.l(strG, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        List list3 = (List) ((ResultResponse) obj).f16166a;
        if (list3 != null) {
            list = list3;
        }
        D.r(j.f23530f, M.f438b, new p120m6.b(10L, new C1290o(j, list, null), null), 2);
        return new b(list);
    }
}
