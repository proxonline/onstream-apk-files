package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p054f5.b;
import p083i7.C0997j;
import p093j8.i;
import p139o6.e;
import p149p6.a;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: renamed from: t6.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1283h extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23612r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23613s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ a f23614t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1283h(J j, a aVar, d dVar) {
        super(2, dVar);
        this.f23613s = j;
        this.f23614t = aVar;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1283h(this.f23613s, this.f23614t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1283h) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23612r;
        l lVar = l.f16813a;
        if (i9 == 0) {
            u0.F(obj);
            e eVar = this.f23613s.f23529e;
            this.f23612r = 1;
            Object objC = b.C(eVar.f22119a, this, new C0997j(eVar, 2, this.f23614t), false, true);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objC != aVar) {
                objC = lVar;
            }
            if (objC == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new p100k6.b(lVar);
    }
}
