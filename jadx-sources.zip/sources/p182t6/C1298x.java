package p182t6;

import B8.A;
import h8.d;
import java.util.List;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1298x extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23711r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23712s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f23713t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ List f23714u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1298x(J j, int i9, List list, d dVar) {
        super(2, dVar);
        this.f23712s = j;
        this.f23713t = i9;
        this.f23714u = list;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1298x(this.f23712s, this.f23713t, this.f23714u, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1298x) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23711r;
        if (i9 == 0) {
            u0.F(obj);
            J j = this.f23712s;
            a aVar = j.f23525a;
            String strG = p165r6.a.g(T8.l.u(j.f23526b), o.f18389a.H0());
            this.f23711r = 1;
            obj = aVar.G(strG, this.f23713t, this.f23714u, 20, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
