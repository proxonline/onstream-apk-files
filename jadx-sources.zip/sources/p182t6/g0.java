package p182t6;

import com.maertsno.data.model.response.LoginResponse;
import p093j8.c;

/* JADX INFO: loaded from: classes.dex */
public final class g0 extends c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public LoginResponse f23608r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f23609s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ s0 f23610t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f23611u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g0(s0 s0Var, c cVar) {
        super(cVar);
        this.f23610t = s0Var;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f23609s = obj;
        this.f23611u |= Integer.MIN_VALUE;
        return this.f23610t.b(this);
    }
}
