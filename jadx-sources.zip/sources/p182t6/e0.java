package p182t6;

import B8.A;
import a9.C0496o;
import a9.N;
import com.maertsno.data.model.request.ChangePasswordRequest;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class e0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23590r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ s0 f23591s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f23592t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ String f23593u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e0(s0 s0Var, String str, String str2, d dVar) {
        super(2, dVar);
        this.f23591s = s0Var;
        this.f23592t = str;
        this.f23593u = str2;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new e0(this.f23591s, this.f23592t, this.f23593u, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((e0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23590r;
        if (i9 == 0) {
            u0.F(obj);
            s0 s0Var = this.f23591s;
            a aVar = s0Var.f23692a;
            String strG = p165r6.a.g(T8.l.u(s0Var.f23694c), o.f18389a.n());
            ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest(this.f23592t, this.f23593u);
            this.f23590r = 1;
            obj = aVar.d(strG, changePasswordRequest, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        N n9 = (N) obj;
        if (n9.f10067a.f()) {
            return new b(l.f16813a);
        }
        throw new C0496o(n9);
    }
}
