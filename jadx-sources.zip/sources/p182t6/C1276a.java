package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p174s5.m;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1276a extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23565r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ m f23566s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1276a(m mVar, d dVar) {
        super(2, dVar);
        this.f23566s = mVar;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1276a(this.f23566s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1276a) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23565r;
        if (i9 == 0) {
            u0.F(obj);
            m mVar = this.f23566s;
            a aVar = (a) mVar.f23113b;
            String strG = p165r6.a.g(T8.l.u((p130n6.d) mVar.f23114c), o.f18389a.k());
            this.f23565r = 1;
            obj = aVar.E(strG, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
