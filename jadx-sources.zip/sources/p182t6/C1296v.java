package p182t6;

import B8.A;
import h8.d;
import java.util.LinkedHashMap;
import p039d8.g;
import p039d8.l;
import p048e8.u;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: renamed from: t6.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1296v extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23701r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f23702s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f23703t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ J f23704u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ String f23705v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1296v(int i9, int i10, d dVar, String str, J j) {
        super(2, dVar);
        this.f23702s = i9;
        this.f23703t = i10;
        this.f23704u = j;
        this.f23705v = str;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        J j = this.f23704u;
        return new C1296v(this.f23702s, this.f23703t, dVar, this.f23705v, j);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1296v) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23701r;
        if (i9 == 0) {
            u0.F(obj);
            LinkedHashMap linkedHashMapP = u.P(new g("page", String.valueOf(this.f23702s)), new g("limit", String.valueOf(this.f23703t)));
            J j = this.f23704u;
            a aVar = j.f23525a;
            String str = T8.l.u(j.f23526b) + o.f18389a.s0() + this.f23705v;
            this.f23701r = 1;
            obj = aVar.p(str, linkedHashMapP, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
