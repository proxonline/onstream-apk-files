package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.response.ListPlayerResponse;
import h8.d;
import p039d8.h;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.a;
import p100k6.b;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class Q extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ U f23544r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Q(U u4, d dVar) {
        super(2, dVar);
        this.f23544r = u4;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new Q(this.f23544r, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((Q) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00c1  */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object obj2;
        Object objM;
        u0.F(obj);
        p130n6.d dVar = this.f23544r.f23550c;
        SharedPreferences sharedPreferences = dVar.f21718a;
        String strW = o.f18389a.W();
        kotlin.jvm.internal.d dVarA = kotlin.jvm.internal.p.a(ListPlayerResponse.class);
        if (dVarA.equals(kotlin.jvm.internal.p.a(Float.TYPE))) {
            obj2 = (ListPlayerResponse) new Float(sharedPreferences.getFloat(strW, 0.0f));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Integer.TYPE))) {
            obj2 = (ListPlayerResponse) new Integer(sharedPreferences.getInt(strW, 0));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Long.TYPE))) {
            obj2 = (ListPlayerResponse) new Long(sharedPreferences.getLong(strW, 0L));
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(String.class))) {
            Object string = sharedPreferences.getString(strW, "");
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.ListPlayerResponse");
            }
            obj2 = (ListPlayerResponse) string;
        } else if (dVarA.equals(kotlin.jvm.internal.p.a(Boolean.TYPE))) {
            obj2 = (ListPlayerResponse) Boolean.valueOf(sharedPreferences.getBoolean(strW, false));
        } else {
            String string2 = sharedPreferences.getString(strW, "");
            if (string2 == null || string2.length() == 0) {
                obj2 = null;
            } else {
                try {
                    objM = dVar.f21719b.a(ListPlayerResponse.class).b(string2);
                } catch (Throwable th) {
                    objM = u0.m(th);
                }
                if (objM instanceof h) {
                    obj2 = null;
                } else {
                    obj2 = objM;
                }
            }
        }
        ListPlayerResponse listPlayerResponse = (ListPlayerResponse) obj2;
        return listPlayerResponse != null ? new b(listPlayerResponse) : new a(new p091j6.a(null, null));
    }
}
