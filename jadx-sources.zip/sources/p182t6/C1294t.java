package p182t6;

import B8.A;
import E1.a;
import h8.d;
import p039d8.l;
import p054f5.b;
import p093j8.i;
import p139o6.e;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: renamed from: t6.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1294t extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23696r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23697s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1294t(J j, d dVar) {
        super(2, dVar);
        this.f23697s = j;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1294t(this.f23697s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1294t) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23696r;
        if (i9 == 0) {
            u0.F(obj);
            e eVar = this.f23697s.f23529e;
            this.f23696r = 1;
            obj = b.C(eVar.f22119a, this, new a(6, eVar), true, false);
            p084i8.a aVar = p084i8.a.f19475a;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new p100k6.b(obj);
    }
}
