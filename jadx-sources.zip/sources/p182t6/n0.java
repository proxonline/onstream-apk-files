package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.request.LogoutRequest;
import com.maertsno.data.model.response.LoginResponse;
import h8.d;
import p039d8.h;
import p039d8.l;
import p064g6.o;
import p091j6.b;
import p093j8.i;
import p100k6.a;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class n0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23658r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ s0 f23659s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n0(s0 s0Var, d dVar) {
        super(2, dVar);
        this.f23659s = s0Var;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new n0(this.f23659s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((n0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code duplicated, block: B:40:0x00d5  */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object obj2;
        Object objM;
        int i9 = this.f23658r;
        s0 s0Var = this.f23659s;
        if (i9 == 0) {
            u0.F(obj);
            p130n6.d dVar = s0Var.f23694c;
            SharedPreferences sharedPreferences = dVar.f21718a;
            String strE0 = o.f18389a.e0();
            kotlin.jvm.internal.d dVarA = kotlin.jvm.internal.p.a(LoginResponse.class);
            if (dVarA.equals(kotlin.jvm.internal.p.a(Float.TYPE))) {
                obj2 = (LoginResponse) new Float(sharedPreferences.getFloat(strE0, 0.0f));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Integer.TYPE))) {
                obj2 = (LoginResponse) new Integer(sharedPreferences.getInt(strE0, 0));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Long.TYPE))) {
                obj2 = (LoginResponse) new Long(sharedPreferences.getLong(strE0, 0L));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(String.class))) {
                Object string = sharedPreferences.getString(strE0, "");
                if (string == null) {
                    throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.LoginResponse");
                }
                obj2 = (LoginResponse) string;
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Boolean.TYPE))) {
                obj2 = (LoginResponse) Boolean.valueOf(sharedPreferences.getBoolean(strE0, false));
            } else {
                String string2 = sharedPreferences.getString(strE0, "");
                if (string2 == null || string2.length() == 0) {
                    obj2 = null;
                } else {
                    try {
                        objM = dVar.f21719b.a(LoginResponse.class).b(string2);
                    } catch (Throwable th) {
                        objM = u0.m(th);
                    }
                    if (objM instanceof h) {
                        obj2 = null;
                    } else {
                        obj2 = objM;
                    }
                }
            }
            LoginResponse loginResponse = (LoginResponse) obj2;
            if (loginResponse == null) {
                return new a(new b());
            }
            String str = loginResponse.f16087b.f16219b.f16224a;
            p175s6.a aVar = s0Var.f23692a;
            String strG = p165r6.a.g(T8.l.u(s0Var.f23694c), o.f18389a.o0());
            LogoutRequest logoutRequest = new LogoutRequest(str);
            this.f23658r = 1;
            obj = aVar.m(strG, logoutRequest, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        p100k6.b bVar = new p100k6.b(obj);
        p130n6.d dVar2 = s0Var.f23694c;
        String key = o.f18389a.e0();
        kotlin.jvm.internal.h.e(key, "key");
        SharedPreferences.Editor editorEdit = dVar2.f21718a.edit();
        editorEdit.remove(key);
        editorEdit.apply();
        return bVar;
    }
}
