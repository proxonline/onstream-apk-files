package p182t6;

import B8.A;
import H0.H;
import h8.d;
import p039d8.l;
import p054f5.b;
import p084i8.a;
import p093j8.i;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: renamed from: t6.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1281f extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23594r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23595s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1281f(J j, d dVar) {
        super(2, dVar);
        this.f23595s = j;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1281f(this.f23595s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1281f) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23594r;
        l lVar = l.f16813a;
        if (i9 == 0) {
            u0.F(obj);
            p139o6.i iVar = this.f23595s.f23528d;
            this.f23594r = 1;
            Object objC = b.C(iVar.f22128a, this, new H(5), false, true);
            a aVar = a.f19475a;
            if (objC != aVar) {
                objC = lVar;
            }
            if (objC == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new p100k6.b(lVar);
    }
}
