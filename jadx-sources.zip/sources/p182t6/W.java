package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p084i8.a;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.k;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class W extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23556r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ d0 f23557s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public W(d0 d0Var, d dVar) {
        super(2, dVar);
        this.f23557s = d0Var;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new W(this.f23557s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((W) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23556r;
        if (i9 == 0) {
            u0.F(obj);
            k kVar = (k) this.f23557s.f23585a.get();
            this.f23556r = 1;
            obj = kVar.i(this);
            a aVar = a.f19475a;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
