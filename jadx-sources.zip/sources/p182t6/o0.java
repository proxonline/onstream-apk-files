package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.request.RegisterRequest;
import com.maertsno.data.model.response.LoginResponse;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class o0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23662r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ s0 f23663s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f23664t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ String f23665u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ String f23666v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o0(s0 s0Var, String str, String str2, String str3, d dVar) {
        super(2, dVar);
        this.f23663s = s0Var;
        this.f23664t = str;
        this.f23665u = str2;
        this.f23666v = str3;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new o0(this.f23663s, this.f23664t, this.f23665u, this.f23666v, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((o0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23662r;
        s0 s0Var = this.f23663s;
        if (i9 == 0) {
            u0.F(obj);
            a aVar = s0Var.f23692a;
            String strG = p165r6.a.g(T8.l.u(s0Var.f23694c), o.f18389a.F0());
            RegisterRequest registerRequest = new RegisterRequest(this.f23664t, this.f23665u, this.f23666v);
            this.f23662r = 1;
            obj = aVar.A(strG, registerRequest, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        LoginResponse loginResponse = (LoginResponse) obj;
        p130n6.d dVar = s0Var.f23694c;
        String strE0 = o.f18389a.e0();
        SharedPreferences.Editor editorEdit = dVar.f21718a.edit();
        editorEdit.putString(strE0, dVar.f21719b.a(LoginResponse.class).d(loginResponse));
        editorEdit.apply();
        return new b(loginResponse);
    }
}
