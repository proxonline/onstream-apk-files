package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p093j8.i;
import p167r8.p;

/* JADX INFO: loaded from: classes.dex */
public final class K extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23531r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ U f23532s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f23533t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public K(U u4, String str, d dVar) {
        super(2, dVar);
        this.f23532s = u4;
        this.f23533t = str;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new K(this.f23532s, this.f23533t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((K) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0240  */
    /* JADX WARN: Code duplicated, block: B:102:0x024a  */
    /* JADX WARN: Code duplicated, block: B:103:0x0254  */
    /* JADX WARN: Code duplicated, block: B:115:0x0276  */
    /* JADX WARN: Code duplicated, block: B:118:0x027b  */
    /* JADX WARN: Code duplicated, block: B:121:0x0289  */
    /* JADX WARN: Code duplicated, block: B:124:0x02a0  */
    /* JADX WARN: Code duplicated, block: B:128:0x02be  */
    /* JADX WARN: Code duplicated, block: B:131:0x02d5  */
    /* JADX WARN: Code duplicated, block: B:143:0x0331  */
    /* JADX WARN: Code duplicated, block: B:147:0x034f  */
    /* JADX WARN: Code duplicated, block: B:159:0x02b3 A[EDGE_INSN: B:159:0x02b3->B:127:0x02b3 BREAK  A[LOOP:0: B:122:0x0299->B:161:0x0299], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:160:0x02af A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:162:0x0299 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:164:0x02e8 A[EDGE_INSN: B:164:0x02e8->B:134:0x02e8 BREAK  A[LOOP:1: B:129:0x02ce->B:166:0x02ce], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:165:0x02e4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:167:0x02ce A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:40:0x00dc  */
    /* JADX WARN: Code duplicated, block: B:82:0x01b4  */
    /* JADX WARN: Code duplicated, block: B:83:0x01b6  */
    /* JADX WARN: Code duplicated, block: B:86:0x01d3  */
    /* JADX WARN: Code duplicated, block: B:87:0x01e7  */
    /* JADX WARN: Code duplicated, block: B:89:0x01f1  */
    /* JADX WARN: Code duplicated, block: B:90:0x0205  */
    /* JADX WARN: Code duplicated, block: B:92:0x020f  */
    /* JADX WARN: Code duplicated, block: B:93:0x0222  */
    /* JADX WARN: Code duplicated, block: B:95:0x022c  */
    /* JADX WARN: Code duplicated, block: B:97:0x0234  */
    /* JADX WARN: Code duplicated, block: B:98:0x0238  */
    /* JADX WARN: Code restructure failed: missing block: B:144:0x0349, code lost:
    
        if (r0 == r8) goto L149;
     */
    /* JADX WARN: Code restructure failed: missing block: B:148:0x0368, code lost:
    
        if (r0 == r8) goto L149;
     */
    @Override // p093j8.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r20) {
        /*
            Method dump skipped, instruction units count: 885
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: p182t6.K.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
