package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.response.trakt.TraktProfileResponse;
import h8.d;
import p039d8.h;
import p039d8.l;
import p064g6.o;
import p084i8.a;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.k;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class a0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23567r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ d0 f23568s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ boolean f23569t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a0(d0 d0Var, boolean z9, d dVar) {
        super(2, dVar);
        this.f23568s = d0Var;
        this.f23569t = z9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new a0(this.f23568s, this.f23569t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((a0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code duplicated, block: B:38:0x00cc  */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object objM;
        d0 d0Var = this.f23568s;
        p130n6.d dVar = d0Var.f23586b;
        int i9 = this.f23567r;
        if (i9 == 0) {
            u0.F(obj);
            SharedPreferences sharedPreferences = dVar.f21718a;
            String strD0 = o.f18389a.d0();
            kotlin.jvm.internal.d dVarA = kotlin.jvm.internal.p.a(TraktProfileResponse.class);
            if (dVarA.equals(kotlin.jvm.internal.p.a(Float.TYPE))) {
                objM = (TraktProfileResponse) Float.valueOf(sharedPreferences.getFloat(strD0, 0.0f));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Integer.TYPE))) {
                objM = (TraktProfileResponse) Integer.valueOf(sharedPreferences.getInt(strD0, 0));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Long.TYPE))) {
                objM = (TraktProfileResponse) Long.valueOf(sharedPreferences.getLong(strD0, 0L));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(String.class))) {
                Object string = sharedPreferences.getString(strD0, "");
                if (string == null) {
                    throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.response.trakt.TraktProfileResponse");
                }
                objM = (TraktProfileResponse) string;
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Boolean.TYPE))) {
                objM = (TraktProfileResponse) Boolean.valueOf(sharedPreferences.getBoolean(strD0, false));
            } else {
                String string2 = sharedPreferences.getString(strD0, "");
                if (string2 == null || string2.length() == 0) {
                    objM = null;
                } else {
                    try {
                        objM = dVar.f21719b.a(TraktProfileResponse.class).b(string2);
                    } catch (Throwable th) {
                        objM = u0.m(th);
                    }
                    if (objM instanceof h) {
                        objM = null;
                    }
                }
            }
            TraktProfileResponse traktProfileResponse = (TraktProfileResponse) objM;
            if (this.f23569t && traktProfileResponse != null) {
                return new b(traktProfileResponse);
            }
            k kVar = (k) d0Var.f23585a.get();
            this.f23567r = 1;
            obj = kVar.c(this);
            a aVar = a.f19475a;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        TraktProfileResponse traktProfileResponse2 = (TraktProfileResponse) obj;
        T8.l.N(dVar, traktProfileResponse2);
        String strN0 = o.f18389a.N0();
        SharedPreferences.Editor editorEdit = dVar.f21718a.edit();
        editorEdit.putBoolean(strN0, false);
        editorEdit.apply();
        return new b(traktProfileResponse2);
    }
}
