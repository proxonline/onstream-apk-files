package p182t6;

import B8.A;
import android.content.SharedPreferences;
import h8.d;
import java.util.List;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: renamed from: t6.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1290o extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ J f23660r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ List f23661s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1290o(J j, List list, d dVar) {
        super(2, dVar);
        this.f23660r = j;
        this.f23661s = list;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1290o(this.f23660r, this.f23661s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        C1290o c1290o = (C1290o) create((A) obj, (d) obj2);
        l lVar = l.f16813a;
        c1290o.invokeSuspend(lVar);
        return lVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        u0.F(obj);
        p130n6.d dVar = this.f23660r.f23526b;
        String strS = o.f18389a.S();
        SharedPreferences.Editor editorEdit = dVar.f21718a.edit();
        Object obj2 = this.f23661s;
        if (obj2 instanceof String) {
            editorEdit.putString(strS, (String) obj2);
        } else if (obj2 instanceof Float) {
            editorEdit.putFloat(strS, ((Number) obj2).floatValue());
        } else if (obj2 instanceof Integer) {
            editorEdit.putInt(strS, ((Number) obj2).intValue());
        } else if (obj2 instanceof Long) {
            editorEdit.putLong(strS, ((Number) obj2).longValue());
        } else if (obj2 instanceof Boolean) {
            editorEdit.putBoolean(strS, ((Boolean) obj2).booleanValue());
        } else {
            editorEdit.putString(strS, dVar.f21719b.a(List.class).d(obj2));
        }
        editorEdit.apply();
        return l.f16813a;
    }
}
