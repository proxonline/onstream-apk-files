package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class r extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23681r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ J f23682s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ long f23683t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(J j, long j9, d dVar) {
        super(2, dVar);
        this.f23682s = j;
        this.f23683t = j9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new r(this.f23682s, this.f23683t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((r) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23681r;
        if (i9 == 0) {
            u0.F(obj);
            J j = this.f23682s;
            a aVar = j.f23525a;
            String strG = p165r6.a.g(T8.l.u(j.f23526b), o.f18389a.j0());
            this.f23681r = 1;
            obj = aVar.n(strG, this.f23683t, 1, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
