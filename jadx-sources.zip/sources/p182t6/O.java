package p182t6;

import B8.A;
import P7.x;
import android.content.SharedPreferences;
import h8.d;
import p039d8.h;
import p039d8.l;
import p064g6.o;
import p084i8.a;
import p093j8.i;
import p100k6.b;
import p100k6.c;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class O extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23540r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ U f23541s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f23542t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public O(U u4, int i9, d dVar) {
        super(2, dVar);
        this.f23541s = u4;
        this.f23542t = i9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new O(this.f23541s, this.f23542t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((O) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r4v1 */
    /* JADX WARN: Type inference failed for: r4v11, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r4v12, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r4v13 */
    /* JADX WARN: Type inference failed for: r4v17, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r4v4, types: [java.lang.Integer] */
    /* JADX WARN: Type inference failed for: r4v7, types: [java.lang.Integer] */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object objM;
        int i9 = this.f23540r;
        if (i9 == 0) {
            u0.F(obj);
            U u4 = this.f23541s;
            p130n6.d dVar = u4.f23550c;
            SharedPreferences sharedPreferences = dVar.f21718a;
            String strY = o.f18389a.Y();
            ?? num = new Integer(0);
            kotlin.jvm.internal.d dVarA = kotlin.jvm.internal.p.a(Integer.class);
            if (dVarA.equals(kotlin.jvm.internal.p.a(Float.TYPE))) {
                num = (Integer) new Float(sharedPreferences.getFloat(strY, ((Float) num).floatValue()));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Integer.TYPE))) {
                num = new Integer(sharedPreferences.getInt(strY, num.intValue()));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Long.TYPE))) {
                num = (Integer) new Long(sharedPreferences.getLong(strY, ((Long) num).longValue()));
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(String.class))) {
                Object string = sharedPreferences.getString(strY, (String) num);
                if (string == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Int");
                }
                num = (Integer) string;
            } else if (dVarA.equals(kotlin.jvm.internal.p.a(Boolean.TYPE))) {
                num = (Integer) Boolean.valueOf(sharedPreferences.getBoolean(strY, ((Boolean) num).booleanValue()));
            } else {
                String string2 = sharedPreferences.getString(strY, "");
                if (string2 != null && string2.length() != 0) {
                    try {
                        objM = dVar.f21719b.a(Integer.class).b(string2);
                    } catch (Throwable th) {
                        objM = u0.m(th);
                    }
                    if (objM instanceof h) {
                        objM = null;
                    }
                    if (objM != null) {
                        num = objM;
                    }
                }
            }
            if (this.f23542t <= ((Number) num).intValue()) {
                return new b(l.f16813a);
            }
            this.f23540r = 1;
            x xVar = p196v6.b.f24714a;
            obj = p196v6.b.a(new N(u4, null), this);
            a aVar = a.f19475a;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return (c) obj;
    }
}
