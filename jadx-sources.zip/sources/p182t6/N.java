package p182t6;

import B8.A;
import com.maertsno.data.model.response.AlterConfigResponse;
import h8.d;
import p039d8.l;
import p064g6.o;
import p084i8.a;
import p093j8.i;
import p100k6.c;
import p167r8.p;
import p175s6.b;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class N extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23538r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ U f23539s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public N(U u4, d dVar) {
        super(2, dVar);
        this.f23539s = u4;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new N(this.f23539s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((N) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23538r;
        U u4 = this.f23539s;
        a aVar = a.f19475a;
        if (i9 == 0) {
            u0.F(obj);
            b bVar = u4.f23549b;
            String strH = o.f18389a.h();
            this.f23538r = 1;
            obj = bVar.a(strH, this);
            if (obj != aVar) {
            }
        }
        if (i9 != 1) {
            if (i9 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
            return obj;
        }
        u0.F(obj);
        String str = ((AlterConfigResponse) obj).f15889a;
        this.f23538r = 2;
        c cVarA = u4.a(str);
        return cVarA == aVar ? aVar : cVarA;
    }
}
