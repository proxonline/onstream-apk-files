package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p093j8.i;
import p167r8.p;

/* JADX INFO: loaded from: classes.dex */
public final class c0 extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23579r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Integer f23580s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ d0 f23581t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c0(Integer num, d0 d0Var, d dVar) {
        super(2, dVar);
        this.f23580s = num;
        this.f23581t = d0Var;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new c0(this.f23580s, this.f23581t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((c0) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x0033, code lost:
    
        if (r5 == r1) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x004e, code lost:
    
        if (r5 == r1) goto L19;
     */
    @Override // p093j8.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r5) {
        /*
            r4 = this;
            t6.d0 r0 = r4.f23581t
            b8.a r0 = r0.f23585a
            int r1 = r4.f23579r
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L1e
            if (r1 == r3) goto L1a
            if (r1 != r2) goto L12
            p195v5.u0.F(r5)
            goto L51
        L12:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L1a:
            p195v5.u0.F(r5)
            goto L36
        L1e:
            p195v5.u0.F(r5)
            java.lang.Integer r5 = r4.f23580s
            i8.a r1 = p084i8.a.f19475a
            if (r5 != 0) goto L3c
            java.lang.Object r5 = r0.get()
            s6.k r5 = (p175s6.k) r5
            r4.f23579r = r3
            java.lang.Object r5 = r5.b(r4)
            if (r5 != r1) goto L36
            goto L50
        L36:
            k6.b r0 = new k6.b
            r0.<init>(r5)
            return r0
        L3c:
            java.lang.Object r0 = r0.get()
            s6.k r0 = (p175s6.k) r0
            int r5 = r5.intValue()
            r4.f23579r = r2
            r2 = 20
            java.lang.Object r5 = r0.a(r5, r2, r4)
            if (r5 != r1) goto L51
        L50:
            return r1
        L51:
            k6.b r0 = new k6.b
            r0.<init>(r5)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p182t6.c0.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
