package p182t6;

import B8.A;
import android.content.SharedPreferences;
import com.maertsno.data.model.response.AllSettingsResponse;
import com.maertsno.data.model.response.ContactLinkResponse;
import com.maertsno.data.model.response.DownloaderResponse;
import com.maertsno.data.model.response.ListPlayerResponse;
import h8.d;
import p039d8.l;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class M extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23536r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ U f23537s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public M(U u4, d dVar) {
        super(2, dVar);
        this.f23537s = u4;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new M(this.f23537s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((M) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23536r;
        U u4 = this.f23537s;
        if (i9 == 0) {
            u0.F(obj);
            a aVar = u4.f23548a;
            String strG = p165r6.a.g(T8.l.u(u4.f23550c), o.f18389a.g());
            this.f23536r = 1;
            obj = aVar.B(strG, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        AllSettingsResponse allSettingsResponse = (AllSettingsResponse) obj;
        p130n6.d dVar = u4.f23550c;
        p130n6.d dVar2 = u4.f23550c;
        o oVar = o.f18389a;
        String strW = oVar.W();
        ListPlayerResponse listPlayerResponse = allSettingsResponse.f15880a;
        SharedPreferences.Editor editorEdit = dVar.f21718a.edit();
        editorEdit.putString(strW, dVar.f21719b.a(ListPlayerResponse.class).d(listPlayerResponse));
        editorEdit.apply();
        String strF = oVar.F();
        DownloaderResponse downloaderResponse = allSettingsResponse.f15881b;
        SharedPreferences.Editor editorEdit2 = dVar2.f21718a.edit();
        editorEdit2.putString(strF, dVar2.f21719b.a(DownloaderResponse.class).d(downloaderResponse));
        editorEdit2.apply();
        String strI = oVar.I();
        ContactLinkResponse contactLinkResponse = allSettingsResponse.f15882c;
        SharedPreferences.Editor editorEdit3 = dVar2.f21718a.edit();
        editorEdit3.putString(strI, dVar2.f21719b.a(ContactLinkResponse.class).d(contactLinkResponse));
        editorEdit3.apply();
        String strP = oVar.P();
        Integer num = new Integer(oVar.a(allSettingsResponse.f15883d));
        SharedPreferences.Editor editorEdit4 = dVar2.f21718a.edit();
        editorEdit4.putInt(strP, num.intValue());
        editorEdit4.apply();
        return new b(l.f16813a);
    }
}
