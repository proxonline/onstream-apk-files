package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p093j8.i;
import p167r8.p;

/* JADX INFO: renamed from: t6.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1289n extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23654r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ String f23655s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ J f23656t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ int f23657u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1289n(String str, J j, int i9, d dVar) {
        super(2, dVar);
        this.f23655s = str;
        this.f23656t = j;
        this.f23657u = i9;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new C1289n(this.f23655s, this.f23656t, this.f23657u, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C1289n) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x003b, code lost:
    
        if (r8 == r4) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0057, code lost:
    
        if (r8 == r4) goto L19;
     */
    @Override // p093j8.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r8) {
        /*
            r7 = this;
            int r0 = r7.f23654r
            r1 = 2
            r2 = 1
            if (r0 == 0) goto L1a
            if (r0 == r2) goto L16
            if (r0 != r1) goto Le
            p195v5.u0.F(r8)
            goto L5a
        Le:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L16:
            p195v5.u0.F(r8)
            goto L3e
        L1a:
            p195v5.u0.F(r8)
            r8 = 0
            int r0 = r7.f23657u
            t6.J r3 = r7.f23656t
            i8.a r4 = p084i8.a.f19475a
            java.lang.String r5 = r7.f23655s
            if (r5 != 0) goto L44
            o6.i r1 = r3.f23528d
            r7.f23654r = r2
            int r3 = p082i6.a.a()
            H0.w r1 = r1.f22128a
            o6.g r5 = new o6.g
            r5.<init>()
            java.lang.Object r8 = p054f5.b.C(r1, r7, r5, r2, r8)
            if (r8 != r4) goto L3e
            goto L59
        L3e:
            k6.b r0 = new k6.b
            r0.<init>(r8)
            return r0
        L44:
            o6.i r3 = r3.f23528d
            r7.f23654r = r1
            int r1 = p082i6.a.a()
            H0.w r3 = r3.f22128a
            o6.f r6 = new o6.f
            r6.<init>()
            java.lang.Object r8 = p054f5.b.C(r3, r7, r6, r2, r8)
            if (r8 != r4) goto L5a
        L59:
            return r4
        L5a:
            k6.b r0 = new k6.b
            r0.<init>(r8)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p182t6.C1289n.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
