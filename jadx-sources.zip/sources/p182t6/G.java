package p182t6;

import B8.A;
import h8.d;
import java.util.LinkedHashMap;
import p039d8.g;
import p039d8.l;
import p048e8.u;
import p064g6.o;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.a;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class G extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23511r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f23512s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f23513t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ String f23514u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ J f23515v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public G(int i9, int i10, d dVar, String str, J j) {
        super(2, dVar);
        this.f23512s = i9;
        this.f23513t = i10;
        this.f23514u = str;
        this.f23515v = j;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new G(this.f23512s, this.f23513t, dVar, this.f23514u, this.f23515v);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((G) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23511r;
        if (i9 == 0) {
            u0.F(obj);
            LinkedHashMap linkedHashMapP = u.P(new g("page", String.valueOf(this.f23512s)), new g("limit", String.valueOf(this.f23513t)), new g("keyword", this.f23514u));
            J j = this.f23515v;
            a aVar = j.f23525a;
            String strG = p165r6.a.g(T8.l.u(j.f23526b), o.f18389a.L0());
            this.f23511r = 1;
            obj = aVar.p(strG, linkedHashMapP, this);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (obj == aVar2) {
                return aVar2;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return new b(obj);
    }
}
