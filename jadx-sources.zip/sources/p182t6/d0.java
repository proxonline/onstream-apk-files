package p182t6;

import T8.l;
import p019b8.a;
import p130n6.d;

/* JADX INFO: loaded from: classes.dex */
public final class d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f23585a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f23586b;

    public d0(a aVar, d dVar) {
        this.f23585a = aVar;
        this.f23586b = dVar;
    }

    public final Boolean a() {
        return Boolean.valueOf(l.x(this.f23586b) != null);
    }
}
