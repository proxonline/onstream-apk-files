package p182t6;

import B8.A;
import P7.x;
import android.content.SharedPreferences;
import android.util.Base64;
import com.maertsno.data.model.response.RawConfigResponse;
import kotlin.jvm.internal.h;
import kotlin.jvm.internal.p;
import p039d8.l;
import p064g6.o;
import p100k6.c;
import p130n6.d;
import p175s6.a;
import p175s6.b;
import p195v5.u0;
import p229z8.e;
import p229z8.m;

/* JADX INFO: loaded from: classes.dex */
public final class U {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f23548a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final b f23549b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d f23550c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final A f23551d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final x f23552e;

    public U(a aVar, b bVar, d dVar, A a10, x xVar) {
        this.f23548a = aVar;
        this.f23549b = bVar;
        this.f23550c = dVar;
        this.f23551d = a10;
        this.f23552e = xVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final c a(String str) {
        Object objM;
        Object num;
        d dVar = this.f23550c;
        SharedPreferences sharedPreferences = dVar.f21718a;
        boolean zJ0 = e.j0(str);
        l lVar = l.f16813a;
        if (zJ0) {
            return new p100k6.b(lVar);
        }
        try {
            o oVar = o.f18389a;
            byte[] bArrDecode = Base64.decode(str, 0);
            h.d(bArrDecode, "decode(...)");
            RawConfigResponse rawConfigResponse = (RawConfigResponse) this.f23552e.a(RawConfigResponse.class).b(m.U(oVar.c(bArrDecode)));
            if (rawConfigResponse != null) {
                String strY = oVar.Y();
                Integer num2 = new Integer(0);
                kotlin.jvm.internal.d dVarA = p.a(Integer.class);
                if (dVarA.equals(p.a(Float.TYPE))) {
                    num = (Integer) new Float(sharedPreferences.getFloat(strY, ((Float) num2).floatValue()));
                } else if (dVarA.equals(p.a(Integer.TYPE))) {
                    num = new Integer(sharedPreferences.getInt(strY, num2.intValue()));
                } else if (dVarA.equals(p.a(Long.TYPE))) {
                    num = (Integer) new Long(sharedPreferences.getLong(strY, ((Long) num2).longValue()));
                } else if (dVarA.equals(p.a(String.class))) {
                    Object string = sharedPreferences.getString(strY, (String) num2);
                    if (string == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.Int");
                    }
                    num = (Integer) string;
                } else if (dVarA.equals(p.a(Boolean.TYPE))) {
                    num = (Integer) Boolean.valueOf(sharedPreferences.getBoolean(strY, ((Boolean) num2).booleanValue()));
                } else {
                    String string2 = sharedPreferences.getString(strY, "");
                    if (string2 != null && string2.length() != 0) {
                        try {
                            num = num2;
                            num = num2;
                            objM = dVar.f21719b.a(Integer.class).b(string2);
                        } catch (Throwable th) {
                            objM = u0.m(th);
                        }
                        if (objM instanceof p039d8.h) {
                            objM = null;
                        }
                        num = objM == null ? num2 : objM;
                    }
                }
                num = num2;
                num = num2;
                num = num2;
                if (rawConfigResponse.f16159d > ((Number) num).intValue()) {
                    o oVar2 = o.f18389a;
                    String strO = oVar2.O();
                    String str2 = rawConfigResponse.f16156a;
                    SharedPreferences.Editor editorEdit = sharedPreferences.edit();
                    editorEdit.putString(strO, str2);
                    editorEdit.apply();
                    String strT = oVar2.T();
                    String str3 = rawConfigResponse.f16157b;
                    SharedPreferences.Editor editorEdit2 = sharedPreferences.edit();
                    editorEdit2.putString(strT, str3);
                    editorEdit2.apply();
                    String strV = oVar2.V();
                    String str4 = rawConfigResponse.f16158c;
                    SharedPreferences.Editor editorEdit3 = sharedPreferences.edit();
                    editorEdit3.putString(strV, str4);
                    editorEdit3.apply();
                    String strY2 = oVar2.Y();
                    Integer num3 = new Integer(rawConfigResponse.f16159d);
                    SharedPreferences.Editor editorEdit4 = sharedPreferences.edit();
                    editorEdit4.putInt(strY2, num3.intValue());
                    editorEdit4.apply();
                }
            }
            return new p100k6.b(lVar);
        } catch (Exception e9) {
            return new p100k6.a(e9);
        }
    }
}
