package p182t6;

import B8.A;
import h8.d;
import p039d8.l;
import p093j8.i;
import p167r8.p;

/* JADX INFO: loaded from: classes.dex */
public final class S extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23545r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ U f23546s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public S(U u4, d dVar) {
        super(2, dVar);
        this.f23546s = u4;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new S(this.f23546s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((S) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:47:0x0107, code lost:
    
        if (r10 == r3) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x0129, code lost:
    
        if (r10 == r3) goto L52;
     */
    @Override // p093j8.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r10) {
        /*
            Method dump skipped, instruction units count: 306
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: p182t6.S.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
