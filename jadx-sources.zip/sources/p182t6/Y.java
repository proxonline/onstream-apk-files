package p182t6;

import B8.A;
import com.maertsno.data.model.request.trakt.TraktLoginRequest;
import com.maertsno.data.model.response.trakt.TraktLoginResponse;
import h8.d;
import p039d8.l;
import p064g6.o;
import p084i8.a;
import p093j8.i;
import p100k6.b;
import p167r8.p;
import p175s6.k;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class Y extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23560r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ d0 f23561s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f23562t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Y(d0 d0Var, String str, d dVar) {
        super(2, dVar);
        this.f23561s = d0Var;
        this.f23562t = str;
    }

    @Override // p093j8.a
    public final d create(Object obj, d dVar) {
        return new Y(this.f23561s, this.f23562t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((Y) create((A) obj, (d) obj2)).invokeSuspend(l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23560r;
        d0 d0Var = this.f23561s;
        if (i9 == 0) {
            u0.F(obj);
            k kVar = (k) d0Var.f23585a.get();
            o oVar = o.f18389a;
            TraktLoginRequest traktLoginRequest = new TraktLoginRequest(oVar.P0(), oVar.T0(), this.f23562t, "authorization_code", oVar.R0());
            this.f23560r = 1;
            obj = kVar.f(traktLoginRequest, this);
            a aVar = a.f19475a;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        T8.l.M(d0Var.f23586b, (TraktLoginResponse) obj);
        return new b(l.f16813a);
    }
}
