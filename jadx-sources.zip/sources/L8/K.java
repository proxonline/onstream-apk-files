package L8;

import java.net.InetSocketAddress;
import java.net.Proxy;

/* JADX INFO: loaded from: classes.dex */
public final class K {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0240a f4339a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Proxy f4340b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final InetSocketAddress f4341c;

    public K(C0240a c0240a, Proxy proxy, InetSocketAddress socketAddress) {
        kotlin.jvm.internal.h.e(socketAddress, "socketAddress");
        this.f4339a = c0240a;
        this.f4340b = proxy;
        this.f4341c = socketAddress;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof K)) {
            return false;
        }
        K k9 = (K) obj;
        return kotlin.jvm.internal.h.a(k9.f4339a, this.f4339a) && kotlin.jvm.internal.h.a(k9.f4340b, this.f4340b) && kotlin.jvm.internal.h.a(k9.f4341c, this.f4341c);
    }

    public final int hashCode() {
        return this.f4341c.hashCode() + ((this.f4340b.hashCode() + ((this.f4339a.hashCode() + 527) * 31)) * 31);
    }

    public final String toString() {
        return "Route{" + this.f4341c + '}';
    }
}
