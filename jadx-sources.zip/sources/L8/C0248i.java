package L8;

import java.util.LinkedHashMap;

/* JADX INFO: renamed from: L8.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0248i {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final m f4380b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C0247h f4381c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final LinkedHashMap f4382d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final C0248i f4383e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final C0248i f4384f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final C0248i f4385g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final C0248i f4386h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final C0248i f4387i;
    public static final C0248i j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final C0248i f4388k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final C0248i f4389l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final C0248i f4390m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C0248i f4391n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final C0248i f4392o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final C0248i f4393p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final C0248i f4394q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final C0248i f4395r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final C0248i f4396s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final C0248i f4397t;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f4398a;

    static {
        m mVar = new m();
        f4380b = mVar;
        f4381c = new C0247h();
        f4382d = new LinkedHashMap();
        m.b(mVar, "SSL_RSA_WITH_NULL_MD5");
        m.b(mVar, "SSL_RSA_WITH_NULL_SHA");
        m.b(mVar, "SSL_RSA_EXPORT_WITH_RC4_40_MD5");
        m.b(mVar, "SSL_RSA_WITH_RC4_128_MD5");
        m.b(mVar, "SSL_RSA_WITH_RC4_128_SHA");
        m.b(mVar, "SSL_RSA_EXPORT_WITH_DES40_CBC_SHA");
        m.b(mVar, "SSL_RSA_WITH_DES_CBC_SHA");
        f4383e = m.b(mVar, "SSL_RSA_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA");
        m.b(mVar, "SSL_DHE_DSS_WITH_DES_CBC_SHA");
        m.b(mVar, "SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA");
        m.b(mVar, "SSL_DHE_RSA_WITH_DES_CBC_SHA");
        m.b(mVar, "SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5");
        m.b(mVar, "SSL_DH_anon_WITH_RC4_128_MD5");
        m.b(mVar, "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA");
        m.b(mVar, "SSL_DH_anon_WITH_DES_CBC_SHA");
        m.b(mVar, "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "TLS_KRB5_WITH_DES_CBC_SHA");
        m.b(mVar, "TLS_KRB5_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "TLS_KRB5_WITH_RC4_128_SHA");
        m.b(mVar, "TLS_KRB5_WITH_DES_CBC_MD5");
        m.b(mVar, "TLS_KRB5_WITH_3DES_EDE_CBC_MD5");
        m.b(mVar, "TLS_KRB5_WITH_RC4_128_MD5");
        m.b(mVar, "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA");
        m.b(mVar, "TLS_KRB5_EXPORT_WITH_RC4_40_SHA");
        m.b(mVar, "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5");
        m.b(mVar, "TLS_KRB5_EXPORT_WITH_RC4_40_MD5");
        f4384f = m.b(mVar, "TLS_RSA_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_DHE_DSS_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_DHE_RSA_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_DH_anon_WITH_AES_128_CBC_SHA");
        f4385g = m.b(mVar, "TLS_RSA_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_DHE_DSS_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_DHE_RSA_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_DH_anon_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_RSA_WITH_NULL_SHA256");
        m.b(mVar, "TLS_RSA_WITH_AES_128_CBC_SHA256");
        m.b(mVar, "TLS_RSA_WITH_AES_256_CBC_SHA256");
        m.b(mVar, "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256");
        m.b(mVar, "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA");
        m.b(mVar, "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA");
        m.b(mVar, "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA");
        m.b(mVar, "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256");
        m.b(mVar, "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256");
        m.b(mVar, "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256");
        m.b(mVar, "TLS_DH_anon_WITH_AES_128_CBC_SHA256");
        m.b(mVar, "TLS_DH_anon_WITH_AES_256_CBC_SHA256");
        m.b(mVar, "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA");
        m.b(mVar, "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA");
        m.b(mVar, "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA");
        m.b(mVar, "TLS_PSK_WITH_RC4_128_SHA");
        m.b(mVar, "TLS_PSK_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "TLS_PSK_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_PSK_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_RSA_WITH_SEED_CBC_SHA");
        f4386h = m.b(mVar, "TLS_RSA_WITH_AES_128_GCM_SHA256");
        f4387i = m.b(mVar, "TLS_RSA_WITH_AES_256_GCM_SHA384");
        m.b(mVar, "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256");
        m.b(mVar, "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384");
        m.b(mVar, "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256");
        m.b(mVar, "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384");
        m.b(mVar, "TLS_DH_anon_WITH_AES_128_GCM_SHA256");
        m.b(mVar, "TLS_DH_anon_WITH_AES_256_GCM_SHA384");
        m.b(mVar, "TLS_EMPTY_RENEGOTIATION_INFO_SCSV");
        m.b(mVar, "TLS_FALLBACK_SCSV");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_NULL_SHA");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_RC4_128_SHA");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_ECDHE_ECDSA_WITH_NULL_SHA");
        m.b(mVar, "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA");
        m.b(mVar, "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_ECDH_RSA_WITH_NULL_SHA");
        m.b(mVar, "TLS_ECDH_RSA_WITH_RC4_128_SHA");
        m.b(mVar, "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_ECDHE_RSA_WITH_NULL_SHA");
        m.b(mVar, "TLS_ECDHE_RSA_WITH_RC4_128_SHA");
        m.b(mVar, "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA");
        j = m.b(mVar, "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA");
        f4388k = m.b(mVar, "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_ECDH_anon_WITH_NULL_SHA");
        m.b(mVar, "TLS_ECDH_anon_WITH_RC4_128_SHA");
        m.b(mVar, "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA");
        m.b(mVar, "TLS_ECDH_anon_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_ECDH_anon_WITH_AES_256_CBC_SHA");
        m.b(mVar, "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256");
        m.b(mVar, "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384");
        m.b(mVar, "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256");
        m.b(mVar, "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384");
        m.b(mVar, "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256");
        m.b(mVar, "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384");
        f4389l = m.b(mVar, "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256");
        f4390m = m.b(mVar, "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256");
        m.b(mVar, "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384");
        f4391n = m.b(mVar, "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256");
        f4392o = m.b(mVar, "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384");
        m.b(mVar, "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256");
        m.b(mVar, "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384");
        m.b(mVar, "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA");
        m.b(mVar, "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA");
        f4393p = m.b(mVar, "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256");
        f4394q = m.b(mVar, "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256");
        m.b(mVar, "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256");
        m.b(mVar, "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256");
        f4395r = m.b(mVar, "TLS_AES_128_GCM_SHA256");
        f4396s = m.b(mVar, "TLS_AES_256_GCM_SHA384");
        f4397t = m.b(mVar, "TLS_CHACHA20_POLY1305_SHA256");
        m.b(mVar, "TLS_AES_128_CCM_SHA256");
        m.b(mVar, "TLS_AES_128_CCM_8_SHA256");
    }

    public C0248i(String str) {
        this.f4398a = str;
    }

    public final String toString() {
        return this.f4398a;
    }
}
