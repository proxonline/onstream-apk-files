package L8;

import Y8.C0467g;
import Y8.InterfaceC0468h;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class o extends F {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final w f4425c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final List f4426a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f4427b;

    static {
        Pattern pattern = w.f4454d;
        f4425c = K3.h.g("application/x-www-form-urlencoded");
    }

    public o(ArrayList encodedNames, ArrayList encodedValues) {
        kotlin.jvm.internal.h.e(encodedNames, "encodedNames");
        kotlin.jvm.internal.h.e(encodedValues, "encodedValues");
        this.f4426a = M8.b.w(encodedNames);
        this.f4427b = M8.b.w(encodedValues);
    }

    @Override // L8.F
    public final long a() {
        return d(null, true);
    }

    @Override // L8.F
    public final w b() {
        return f4425c;
    }

    @Override // L8.F
    public final void c(InterfaceC0468h interfaceC0468h) throws EOFException {
        d(interfaceC0468h, false);
    }

    public final long d(InterfaceC0468h interfaceC0468h, boolean z9) throws EOFException {
        C0467g c0467gC;
        if (z9) {
            c0467gC = new C0467g();
        } else {
            kotlin.jvm.internal.h.b(interfaceC0468h);
            c0467gC = interfaceC0468h.c();
        }
        List list = this.f4426a;
        int size = list.size();
        for (int i9 = 0; i9 < size; i9++) {
            if (i9 > 0) {
                c0467gC.p0(38);
            }
            c0467gC.u0((String) list.get(i9));
            c0467gC.p0(61);
            c0467gC.u0((String) this.f4427b.get(i9));
        }
        if (!z9) {
            return 0L;
        }
        long j = c0467gC.f9475b;
        c0467gC.a();
        return j;
    }
}
