package L8;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class u {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final char[] f4444k = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f4445a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f4446b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f4447c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f4448d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f4449e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ArrayList f4450f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final List f4451g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f4452h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f4453i;
    public final boolean j;

    public u(String scheme, String str, String str2, String host, int i9, ArrayList arrayList, ArrayList arrayList2, String str3, String str4) {
        kotlin.jvm.internal.h.e(scheme, "scheme");
        kotlin.jvm.internal.h.e(host, "host");
        this.f4445a = scheme;
        this.f4446b = str;
        this.f4447c = str2;
        this.f4448d = host;
        this.f4449e = i9;
        this.f4450f = arrayList;
        this.f4451g = arrayList2;
        this.f4452h = str3;
        this.f4453i = str4;
        this.j = scheme.equals("https");
    }

    public final String a() {
        if (this.f4447c.length() == 0) {
            return "";
        }
        int length = this.f4445a.length() + 3;
        String str = this.f4453i;
        String strSubstring = str.substring(p229z8.e.g0(str, ':', length, 4) + 1, p229z8.e.g0(str, '@', 0, 6));
        kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final String b() {
        int length = this.f4445a.length() + 3;
        String str = this.f4453i;
        int iG0 = p229z8.e.g0(str, '/', length, 4);
        String strSubstring = str.substring(iG0, M8.b.g(str, iG0, str.length(), "?#"));
        kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final ArrayList c() {
        int length = this.f4445a.length() + 3;
        String str = this.f4453i;
        int iG0 = p229z8.e.g0(str, '/', length, 4);
        int iG = M8.b.g(str, iG0, str.length(), "?#");
        ArrayList arrayList = new ArrayList();
        while (iG0 < iG) {
            int i9 = iG0 + 1;
            int iF = M8.b.f(str, '/', i9, iG);
            String strSubstring = str.substring(i9, iF);
            kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
            arrayList.add(strSubstring);
            iG0 = iF;
        }
        return arrayList;
    }

    public final String d() {
        if (this.f4451g == null) {
            return null;
        }
        String str = this.f4453i;
        int iG0 = p229z8.e.g0(str, '?', 0, 6) + 1;
        String strSubstring = str.substring(iG0, M8.b.f(str, '#', iG0, str.length()));
        kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final String e() {
        if (this.f4446b.length() == 0) {
            return "";
        }
        int length = this.f4445a.length() + 3;
        String str = this.f4453i;
        String strSubstring = str.substring(length, M8.b.g(str, length, str.length(), ":@"));
        kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof u) && kotlin.jvm.internal.h.a(((u) obj).f4453i, this.f4453i);
    }

    public final t f(String link) {
        kotlin.jvm.internal.h.e(link, "link");
        try {
            t tVar = new t();
            tVar.c(this, link);
            return tVar;
        } catch (IllegalArgumentException unused) {
            return null;
        }
    }

    public final String g() {
        t tVarF = f("/...");
        kotlin.jvm.internal.h.b(tVarF);
        tVarF.f4437b = m.c("", 0, 0, " \"':;<=>@[]^`{}|/\\?#", 251);
        tVarF.f4438c = m.c("", 0, 0, " \"':;<=>@[]^`{}|/\\?#", 251);
        return tVarF.a().f4453i;
    }

    public final URI h() {
        String strSubstring;
        String strReplaceAll;
        t tVar = new t();
        String scheme = this.f4445a;
        tVar.f4436a = scheme;
        tVar.f4437b = e();
        tVar.f4438c = a();
        tVar.f4439d = this.f4448d;
        kotlin.jvm.internal.h.e(scheme, "scheme");
        int i9 = scheme.equals("http") ? 80 : scheme.equals("https") ? 443 : -1;
        int i10 = this.f4449e;
        tVar.f4440e = i10 != i9 ? i10 : -1;
        ArrayList arrayList = tVar.f4441f;
        arrayList.clear();
        arrayList.addAll(c());
        String strD = d();
        tVar.f4442g = strD != null ? m.h(m.c(strD, 0, 0, " \"'<>#", 211)) : null;
        if (this.f4452h == null) {
            strSubstring = null;
        } else {
            String str = this.f4453i;
            strSubstring = str.substring(p229z8.e.g0(str, '#', 0, 6) + 1);
            kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String).substring(startIndex)");
        }
        tVar.f4443h = strSubstring;
        String str2 = tVar.f4439d;
        if (str2 != null) {
            Pattern patternCompile = Pattern.compile("[\"<>^`{|}]");
            kotlin.jvm.internal.h.d(patternCompile, "compile(...)");
            strReplaceAll = patternCompile.matcher(str2).replaceAll("");
            kotlin.jvm.internal.h.d(strReplaceAll, "replaceAll(...)");
        } else {
            strReplaceAll = null;
        }
        tVar.f4439d = strReplaceAll;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            arrayList.set(i11, m.c((String) arrayList.get(i11), 0, 0, "[]", 227));
        }
        ArrayList arrayList2 = tVar.f4442g;
        if (arrayList2 != null) {
            int size2 = arrayList2.size();
            for (int i12 = 0; i12 < size2; i12++) {
                String str3 = (String) arrayList2.get(i12);
                arrayList2.set(i12, str3 != null ? m.c(str3, 0, 0, "\\^`{|}", 195) : null);
            }
        }
        String str4 = tVar.f4443h;
        tVar.f4443h = str4 != null ? m.c(str4, 0, 0, " \"#<>\\^`{|}", 163) : null;
        String string = tVar.toString();
        try {
            return new URI(string);
        } catch (URISyntaxException e9) {
            try {
                Pattern patternCompile2 = Pattern.compile("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]");
                kotlin.jvm.internal.h.d(patternCompile2, "compile(...)");
                String strReplaceAll2 = patternCompile2.matcher(string).replaceAll("");
                kotlin.jvm.internal.h.d(strReplaceAll2, "replaceAll(...)");
                URI uriCreate = URI.create(strReplaceAll2);
                kotlin.jvm.internal.h.d(uriCreate, "{\n      // Unlikely edge…Unexpected!\n      }\n    }");
                return uriCreate;
            } catch (Exception unused) {
                throw new RuntimeException(e9);
            }
        }
    }

    public final int hashCode() {
        return this.f4453i.hashCode();
    }

    public final String toString() {
        return this.f4453i;
    }
}
