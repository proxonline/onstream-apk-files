package L8;

import Y8.InterfaceC0468h;

/* JADX INFO: loaded from: classes.dex */
public final class E extends F {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ w f4307a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f4308b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ byte[] f4309c;

    public E(w wVar, int i9, byte[] bArr) {
        this.f4307a = wVar;
        this.f4308b = i9;
        this.f4309c = bArr;
    }

    @Override // L8.F
    public final long a() {
        return this.f4308b;
    }

    @Override // L8.F
    public final w b() {
        return this.f4307a;
    }

    @Override // L8.F
    public final void c(InterfaceC0468h interfaceC0468h) {
        interfaceC0468h.V(this.f4308b, this.f4309c);
    }
}
