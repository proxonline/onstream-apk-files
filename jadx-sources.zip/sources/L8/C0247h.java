package L8;

import java.util.Comparator;

/* JADX INFO: renamed from: L8.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0247h implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        String a10 = (String) obj;
        String b10 = (String) obj2;
        kotlin.jvm.internal.h.e(a10, "a");
        kotlin.jvm.internal.h.e(b10, "b");
        int iMin = Math.min(a10.length(), b10.length());
        for (int i9 = 4; i9 < iMin; i9++) {
            char cCharAt = a10.charAt(i9);
            char cCharAt2 = b10.charAt(i9);
            if (cCharAt != cCharAt2) {
                return kotlin.jvm.internal.h.g(cCharAt, cCharAt2) < 0 ? -1 : 1;
            }
        }
        int length = a10.length();
        int length2 = b10.length();
        if (length != length2) {
            return length < length2 ? -1 : 1;
        }
        return 0;
    }
}
