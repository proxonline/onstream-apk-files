package L8;

/* JADX INFO: renamed from: L8.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0241b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m f4358a = new m();

    C a(K k9, H h6);
}
