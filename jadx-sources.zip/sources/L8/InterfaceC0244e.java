package L8;

import java.io.IOException;

/* JADX INFO: renamed from: L8.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0244e {
    void k(P8.i iVar, IOException iOException);

    void q(H h6);
}
