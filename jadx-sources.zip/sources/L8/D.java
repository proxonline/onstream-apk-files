package L8;

import Y8.C0470j;
import Y8.InterfaceC0468h;

/* JADX INFO: loaded from: classes.dex */
public final class D extends F {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4304a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final w f4305b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f4306c;

    public D(F f3, w wVar) {
        this.f4306c = f3;
        this.f4305b = wVar;
    }

    public D(w wVar, C0470j c0470j) {
        this.f4305b = wVar;
        this.f4306c = c0470j;
    }

    @Override // L8.F
    public final long a() {
        switch (this.f4304a) {
            case 0:
                return ((C0470j) this.f4306c).c();
            default:
                return ((F) this.f4306c).a();
        }
    }

    @Override // L8.F
    public final w b() {
        switch (this.f4304a) {
            case 0:
                break;
        }
        return this.f4305b;
    }

    @Override // L8.F
    public final void c(InterfaceC0468h interfaceC0468h) {
        switch (this.f4304a) {
            case 0:
                interfaceC0468h.A((C0470j) this.f4306c);
                break;
            default:
                ((F) this.f4306c).c(interfaceC0468h);
                break;
        }
    }
}
