package L8;

import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class w {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Pattern f4454d = Pattern.compile("([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Pattern f4455e = Pattern.compile(";\\s*(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)|\"([^\"]*)\"))?");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f4456a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f4457b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String[] f4458c;

    public w(String str, String str2, String[] strArr) {
        this.f4456a = str;
        this.f4457b = str2;
        this.f4458c = strArr;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof w) && kotlin.jvm.internal.h.a(((w) obj).f4456a, this.f4456a);
    }

    public final int hashCode() {
        return this.f4456a.hashCode();
    }

    public final String toString() {
        return this.f4456a;
    }
}
