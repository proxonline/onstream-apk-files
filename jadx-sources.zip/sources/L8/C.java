package L8;

import com.google.android.gms.internal.measurement.AbstractC0734e2;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class C {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final u f4298a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f4299b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final s f4300c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final F f4301d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Map f4302e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public C0242c f4303f;

    public C(u url, String method, s sVar, F f3, Map map) {
        kotlin.jvm.internal.h.e(url, "url");
        kotlin.jvm.internal.h.e(method, "method");
        this.f4298a = url;
        this.f4299b = method;
        this.f4300c = sVar;
        this.f4301d = f3;
        this.f4302e = map;
    }

    public final C0242c a() {
        C0242c c0242c = this.f4303f;
        if (c0242c != null) {
            return c0242c;
        }
        C0242c c0242c2 = C0242c.f4359n;
        C0242c c0242cW = AbstractC0734e2.w(this.f4300c);
        this.f4303f = c0242cW;
        return c0242cW;
    }

    public final C1.b b() {
        C1.b bVar = new C1.b();
        bVar.f551e = new LinkedHashMap();
        bVar.f547a = this.f4298a;
        bVar.f548b = this.f4299b;
        bVar.f550d = this.f4301d;
        Map map = this.f4302e;
        bVar.f551e = map.isEmpty() ? new LinkedHashMap() : p048e8.u.T(map);
        bVar.f549c = this.f4300c.k();
        return bVar;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Request{method=");
        sb.append(this.f4299b);
        sb.append(", url=");
        sb.append(this.f4298a);
        s sVar = this.f4300c;
        if (sVar.size() != 0) {
            sb.append(", headers=[");
            int i9 = 0;
            for (Object obj : sVar) {
                int i10 = i9 + 1;
                if (i9 < 0) {
                    p048e8.j.Y();
                    throw null;
                }
                p039d8.g gVar = (p039d8.g) obj;
                String str = (String) gVar.f16805a;
                String str2 = (String) gVar.f16806b;
                if (i9 > 0) {
                    sb.append(", ");
                }
                sb.append(str);
                sb.append(':');
                sb.append(str2);
                i9 = i10;
            }
            sb.append(']');
        }
        Map map = this.f4302e;
        if (!map.isEmpty()) {
            sb.append(", tags=");
            sb.append(map);
        }
        sb.append('}');
        String string = sb.toString();
        kotlin.jvm.internal.h.d(string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }
}
