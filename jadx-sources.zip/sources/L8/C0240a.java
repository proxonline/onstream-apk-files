package L8;

import com.google.android.gms.internal.cast.z1;
import com.google.android.gms.internal.measurement.I1;
import j$.util.Objects;
import java.net.ProxySelector;
import java.util.List;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;

/* JADX INFO: renamed from: L8.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0240a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f4349a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final SocketFactory f4350b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final SSLSocketFactory f4351c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final HostnameVerifier f4352d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C0246g f4353e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final InterfaceC0241b f4354f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ProxySelector f4355g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final u f4356h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final List f4357i;
    public final List j;

    public C0240a(String uriHost, int i9, m dns, SocketFactory socketFactory, SSLSocketFactory sSLSocketFactory, HostnameVerifier hostnameVerifier, C0246g c0246g, m proxyAuthenticator, List protocols, List connectionSpecs, ProxySelector proxySelector) {
        kotlin.jvm.internal.h.e(uriHost, "uriHost");
        kotlin.jvm.internal.h.e(dns, "dns");
        kotlin.jvm.internal.h.e(socketFactory, "socketFactory");
        kotlin.jvm.internal.h.e(proxyAuthenticator, "proxyAuthenticator");
        kotlin.jvm.internal.h.e(protocols, "protocols");
        kotlin.jvm.internal.h.e(connectionSpecs, "connectionSpecs");
        kotlin.jvm.internal.h.e(proxySelector, "proxySelector");
        this.f4349a = dns;
        this.f4350b = socketFactory;
        this.f4351c = sSLSocketFactory;
        this.f4352d = hostnameVerifier;
        this.f4353e = c0246g;
        this.f4354f = proxyAuthenticator;
        this.f4355g = proxySelector;
        t tVar = new t();
        String str = sSLSocketFactory != null ? "https" : "http";
        if (str.equalsIgnoreCase("http")) {
            tVar.f4436a = "http";
        } else {
            if (!str.equalsIgnoreCase("https")) {
                throw new IllegalArgumentException("unexpected scheme: ".concat(str));
            }
            tVar.f4436a = "https";
        }
        String strO = I1.O(m.g(0, 0, 7, uriHost));
        if (strO == null) {
            throw new IllegalArgumentException("unexpected host: ".concat(uriHost));
        }
        tVar.f4439d = strO;
        if (1 > i9 || i9 >= 65536) {
            throw new IllegalArgumentException(z1.k("unexpected port: ", i9).toString());
        }
        tVar.f4440e = i9;
        this.f4356h = tVar.a();
        this.f4357i = M8.b.w(protocols);
        this.j = M8.b.w(connectionSpecs);
    }

    public final boolean a(C0240a that) {
        kotlin.jvm.internal.h.e(that, "that");
        return kotlin.jvm.internal.h.a(this.f4349a, that.f4349a) && kotlin.jvm.internal.h.a(this.f4354f, that.f4354f) && kotlin.jvm.internal.h.a(this.f4357i, that.f4357i) && kotlin.jvm.internal.h.a(this.j, that.j) && kotlin.jvm.internal.h.a(this.f4355g, that.f4355g) && kotlin.jvm.internal.h.a(this.f4351c, that.f4351c) && kotlin.jvm.internal.h.a(this.f4352d, that.f4352d) && kotlin.jvm.internal.h.a(this.f4353e, that.f4353e) && this.f4356h.f4449e == that.f4356h.f4449e;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C0240a)) {
            return false;
        }
        C0240a c0240a = (C0240a) obj;
        return kotlin.jvm.internal.h.a(this.f4356h, c0240a.f4356h) && a(c0240a);
    }

    public final int hashCode() {
        return Objects.hashCode(this.f4353e) + ((Objects.hashCode(this.f4352d) + ((Objects.hashCode(this.f4351c) + ((this.f4355g.hashCode() + ((this.j.hashCode() + ((this.f4357i.hashCode() + ((this.f4354f.hashCode() + ((this.f4349a.hashCode() + p165r6.a.f(this.f4356h.f4453i, 527, 31)) * 31)) * 31)) * 31)) * 31)) * 961)) * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Address{");
        u uVar = this.f4356h;
        sb.append(uVar.f4448d);
        sb.append(':');
        sb.append(uVar.f4449e);
        sb.append(", ");
        sb.append("proxySelector=" + this.f4355g);
        sb.append('}');
        return sb.toString();
    }
}
