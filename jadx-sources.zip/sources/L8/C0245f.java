package L8;

import com.google.android.gms.internal.measurement.AbstractC0837z1;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: renamed from: L8.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0245f extends kotlin.jvm.internal.i implements p167r8.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f4373d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C0246g f4374e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f4375f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f4376g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0245f(C0246g c0246g, Object obj, Object obj2, int i9) {
        super(0);
        this.f4373d = i9;
        this.f4374e = c0246g;
        this.f4375f = obj;
        this.f4376g = obj2;
    }

    @Override // p167r8.a
    public final Object invoke() {
        switch (this.f4373d) {
            case 0:
                List<Certificate> listK = (List) this.f4375f;
                AbstractC0837z1 abstractC0837z1 = this.f4374e.f4379b;
                if (abstractC0837z1 != null) {
                    listK = abstractC0837z1.k((String) this.f4376g, listK);
                }
                ArrayList arrayList = new ArrayList(p048e8.k.Z(listK));
                for (Certificate certificate : listK) {
                    kotlin.jvm.internal.h.c(certificate, "null cannot be cast to non-null type java.security.cert.X509Certificate");
                    arrayList.add((X509Certificate) certificate);
                }
                return arrayList;
            default:
                AbstractC0837z1 abstractC0837z2 = this.f4374e.f4379b;
                kotlin.jvm.internal.h.b(abstractC0837z2);
                return abstractC0837z2.k(((C0240a) this.f4376g).f4356h.f4448d, ((q) this.f4375f).a());
        }
    }
}
