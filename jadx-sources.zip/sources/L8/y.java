package L8;

import Y8.C0467g;
import Y8.C0470j;
import Y8.InterfaceC0468h;
import java.io.EOFException;
import java.util.List;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class y extends F {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final w f4461e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final w f4462f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final byte[] f4463g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final byte[] f4464h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final byte[] f4465i;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0470j f4466a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f4467b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final w f4468c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f4469d;

    static {
        Pattern pattern = w.f4454d;
        f4461e = K3.h.g("multipart/mixed");
        K3.h.g("multipart/alternative");
        K3.h.g("multipart/digest");
        K3.h.g("multipart/parallel");
        f4462f = K3.h.g("multipart/form-data");
        f4463g = new byte[]{58, 32};
        f4464h = new byte[]{13, 10};
        f4465i = new byte[]{45, 45};
    }

    public y(C0470j boundaryByteString, w type, List list) {
        kotlin.jvm.internal.h.e(boundaryByteString, "boundaryByteString");
        kotlin.jvm.internal.h.e(type, "type");
        this.f4466a = boundaryByteString;
        this.f4467b = list;
        Pattern pattern = w.f4454d;
        this.f4468c = K3.h.g(type + "; boundary=" + boundaryByteString.p());
        this.f4469d = -1L;
    }

    @Override // L8.F
    public final long a() throws EOFException {
        long j = this.f4469d;
        if (j != -1) {
            return j;
        }
        long jD = d(null, true);
        this.f4469d = jD;
        return jD;
    }

    @Override // L8.F
    public final w b() {
        return this.f4468c;
    }

    @Override // L8.F
    public final void c(InterfaceC0468h interfaceC0468h) throws EOFException {
        d(interfaceC0468h, false);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final long d(InterfaceC0468h interfaceC0468h, boolean z9) throws EOFException {
        C0467g c0467g;
        InterfaceC0468h c0467g2;
        if (z9) {
            c0467g2 = new C0467g();
            c0467g = c0467g2;
        } else {
            c0467g = 0;
            c0467g2 = interfaceC0468h;
        }
        List list = this.f4467b;
        int size = list.size();
        long j = 0;
        int i9 = 0;
        while (true) {
            C0470j c0470j = this.f4466a;
            byte[] bArr = f4465i;
            byte[] bArr2 = f4464h;
            if (i9 >= size) {
                kotlin.jvm.internal.h.b(c0467g2);
                c0467g2.write(bArr);
                c0467g2.A(c0470j);
                c0467g2.write(bArr);
                c0467g2.write(bArr2);
                if (!z9) {
                    return j;
                }
                kotlin.jvm.internal.h.b(c0467g);
                long j9 = j + c0467g.f9475b;
                c0467g.a();
                return j9;
            }
            x xVar = (x) list.get(i9);
            s sVar = xVar.f4459a;
            F f3 = xVar.f4460b;
            kotlin.jvm.internal.h.b(c0467g2);
            c0467g2.write(bArr);
            c0467g2.A(c0470j);
            c0467g2.write(bArr2);
            int size2 = sVar.size();
            for (int i10 = 0; i10 < size2; i10++) {
                c0467g2.Y(sVar.i(i10)).write(f4463g).Y(sVar.m(i10)).write(bArr2);
            }
            w wVarB = f3.b();
            if (wVarB != null) {
                c0467g2.Y("Content-Type: ").Y(wVarB.f4456a).write(bArr2);
            }
            long jA = f3.a();
            if (jA != -1) {
                c0467g2.Y("Content-Length: ").Z(jA).write(bArr2);
            } else if (z9) {
                kotlin.jvm.internal.h.b(c0467g);
                c0467g.a();
                return -1L;
            }
            c0467g2.write(bArr2);
            if (z9) {
                j += jA;
            } else {
                f3.c(c0467g2);
            }
            c0467g2.write(bArr2);
            i9++;
        }
    }
}
