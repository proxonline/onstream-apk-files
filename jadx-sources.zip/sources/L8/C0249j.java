package L8;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: renamed from: L8.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0249j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f4399a = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f4400b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f4401c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Serializable f4402d;

    public C0250k a() {
        return new C0250k(this.f4399a, this.f4400b, (String[]) this.f4401c, (String[]) this.f4402d);
    }

    public void b(C0248i... cipherSuites) {
        kotlin.jvm.internal.h.e(cipherSuites, "cipherSuites");
        if (!this.f4399a) {
            throw new IllegalArgumentException("no cipher suites for cleartext connections");
        }
        ArrayList arrayList = new ArrayList(cipherSuites.length);
        for (C0248i c0248i : cipherSuites) {
            arrayList.add(c0248i.f4398a);
        }
        String[] strArr = (String[]) arrayList.toArray(new String[0]);
        c((String[]) Arrays.copyOf(strArr, strArr.length));
    }

    public void c(String... cipherSuites) {
        kotlin.jvm.internal.h.e(cipherSuites, "cipherSuites");
        if (!this.f4399a) {
            throw new IllegalArgumentException("no cipher suites for cleartext connections");
        }
        if (cipherSuites.length == 0) {
            throw new IllegalArgumentException("At least one cipher suite is required");
        }
        this.f4401c = (String[]) cipherSuites.clone();
    }

    public void d(L... lArr) {
        if (!this.f4399a) {
            throw new IllegalArgumentException("no TLS versions for cleartext connections");
        }
        ArrayList arrayList = new ArrayList(lArr.length);
        for (L l9 : lArr) {
            arrayList.add(l9.f4348a);
        }
        String[] strArr = (String[]) arrayList.toArray(new String[0]);
        e((String[]) Arrays.copyOf(strArr, strArr.length));
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [java.io.Serializable, java.lang.String[]] */
    public void e(String... tlsVersions) {
        kotlin.jvm.internal.h.e(tlsVersions, "tlsVersions");
        if (!this.f4399a) {
            throw new IllegalArgumentException("no TLS versions for cleartext connections");
        }
        if (tlsVersions.length == 0) {
            throw new IllegalArgumentException("At least one TLS version is required");
        }
        this.f4402d = (String[]) tlsVersions.clone();
    }
}
