package L8;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ArrayList f4434a = new ArrayList(20);

    public void a(String name, String value) {
        kotlin.jvm.internal.h.e(name, "name");
        kotlin.jvm.internal.h.e(value, "value");
        I3.a.f(name);
        I3.a.i(value, name);
        c(name, value);
    }

    public void b(Collection collection) {
        if (collection == null) {
            throw new IllegalArgumentException("categories must not be null");
        }
        if (collection.isEmpty()) {
            return;
        }
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            if (str == null) {
                throw new IllegalArgumentException("category must not be null");
            }
            if (this.f4434a == null) {
                this.f4434a = new ArrayList();
            }
            if (!this.f4434a.contains(str)) {
                this.f4434a.add(str);
            }
        }
    }

    public void c(String name, String value) {
        kotlin.jvm.internal.h.e(name, "name");
        kotlin.jvm.internal.h.e(value, "value");
        ArrayList arrayList = this.f4434a;
        arrayList.add(name);
        arrayList.add(p229z8.e.z0(value).toString());
    }

    public void d(String name, String value) {
        kotlin.jvm.internal.h.e(name, "name");
        kotlin.jvm.internal.h.e(value, "value");
        if (name.length() <= 0) {
            throw new IllegalArgumentException("name is empty");
        }
        int length = name.length();
        for (int i9 = 0; i9 < length; i9++) {
            char cCharAt = name.charAt(i9);
            if ('!' > cCharAt || cCharAt >= 127) {
                throw new IllegalArgumentException(M8.b.h("Unexpected char %#04x at %d in header name: %s", Integer.valueOf(cCharAt), Integer.valueOf(i9), name).toString());
            }
        }
        c(name, value);
    }

    public s e() {
        return new s((String[]) this.f4434a.toArray(new String[0]));
    }

    public p190v0.r f() {
        if (this.f4434a == null) {
            return p190v0.r.f24238c;
        }
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("controlCategories", this.f4434a);
        return new p190v0.r(bundle, this.f4434a);
    }

    public void g(String name) {
        ArrayList arrayList = this.f4434a;
        kotlin.jvm.internal.h.e(name, "name");
        int i9 = 0;
        while (i9 < arrayList.size()) {
            if (name.equalsIgnoreCase((String) arrayList.get(i9))) {
                arrayList.remove(i9);
                arrayList.remove(i9);
                i9 -= 2;
            }
            i9 += 2;
        }
    }
}
