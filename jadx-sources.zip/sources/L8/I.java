package L8;

import Y8.C0467g;
import Y8.InterfaceC0469i;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class I extends J {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4335a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f4336b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f4337c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final InterfaceC0469i f4338d;

    public /* synthetic */ I(Object obj, long j, InterfaceC0469i interfaceC0469i, int i9) {
        this.f4335a = i9;
        this.f4337c = obj;
        this.f4336b = j;
        this.f4338d = interfaceC0469i;
    }

    @Override // L8.J
    public final long a() {
        switch (this.f4335a) {
            case 0:
                break;
        }
        return this.f4336b;
    }

    @Override // L8.J
    public final w f() {
        int i9 = this.f4335a;
        Object obj = this.f4337c;
        switch (i9) {
            case 0:
                return (w) obj;
            default:
                String str = (String) obj;
                if (str == null) {
                    return null;
                }
                Pattern pattern = w.f4454d;
                try {
                    return K3.h.g(str);
                } catch (IllegalArgumentException unused) {
                    return null;
                }
        }
    }

    @Override // L8.J
    public final InterfaceC0469i k() {
        switch (this.f4335a) {
            case 0:
                return (C0467g) this.f4338d;
            default:
                return (Y8.C) this.f4338d;
        }
    }
}
