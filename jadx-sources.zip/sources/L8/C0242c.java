package L8;

import java.util.concurrent.TimeUnit;

/* JADX INFO: renamed from: L8.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0242c {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C0242c f4359n = new C0242c(true, false, -1, -1, false, false, false, -1, -1, false, false, false, null);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final C0242c f4360o;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f4361a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f4362b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f4363c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f4364d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f4365e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f4366f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f4367g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f4368h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f4369i;
    public final boolean j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final boolean f4370k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final boolean f4371l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public String f4372m;

    static {
        TimeUnit timeUnit = TimeUnit.SECONDS;
        kotlin.jvm.internal.h.e(timeUnit, "timeUnit");
        long seconds = timeUnit.toSeconds(Integer.MAX_VALUE);
        f4360o = new C0242c(false, false, -1, -1, false, false, false, seconds <= 2147483647L ? (int) seconds : Integer.MAX_VALUE, -1, true, false, false, null);
    }

    public C0242c(boolean z9, boolean z10, int i9, int i10, boolean z11, boolean z12, boolean z13, int i11, int i12, boolean z14, boolean z15, boolean z16, String str) {
        this.f4361a = z9;
        this.f4362b = z10;
        this.f4363c = i9;
        this.f4364d = i10;
        this.f4365e = z11;
        this.f4366f = z12;
        this.f4367g = z13;
        this.f4368h = i11;
        this.f4369i = i12;
        this.j = z14;
        this.f4370k = z15;
        this.f4371l = z16;
        this.f4372m = str;
    }

    public final String toString() {
        String str = this.f4372m;
        if (str != null) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        if (this.f4361a) {
            sb.append("no-cache, ");
        }
        if (this.f4362b) {
            sb.append("no-store, ");
        }
        int i9 = this.f4363c;
        if (i9 != -1) {
            sb.append("max-age=");
            sb.append(i9);
            sb.append(", ");
        }
        int i10 = this.f4364d;
        if (i10 != -1) {
            sb.append("s-maxage=");
            sb.append(i10);
            sb.append(", ");
        }
        if (this.f4365e) {
            sb.append("private, ");
        }
        if (this.f4366f) {
            sb.append("public, ");
        }
        if (this.f4367g) {
            sb.append("must-revalidate, ");
        }
        int i11 = this.f4368h;
        if (i11 != -1) {
            sb.append("max-stale=");
            sb.append(i11);
            sb.append(", ");
        }
        int i12 = this.f4369i;
        if (i12 != -1) {
            sb.append("min-fresh=");
            sb.append(i12);
            sb.append(", ");
        }
        if (this.j) {
            sb.append("only-if-cached, ");
        }
        if (this.f4370k) {
            sb.append("no-transform, ");
        }
        if (this.f4371l) {
            sb.append("immutable, ");
        }
        if (sb.length() == 0) {
            return "";
        }
        sb.delete(sb.length() - 2, sb.length());
        String string = sb.toString();
        kotlin.jvm.internal.h.d(string, "StringBuilder().apply(builderAction).toString()");
        this.f4372m = string;
        return string;
    }
}
