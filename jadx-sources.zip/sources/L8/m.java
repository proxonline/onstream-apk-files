package L8;

import Y8.C0467g;
import java.io.EOFException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class m implements InterfaceC0241b {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final m f4421b = new m();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final m f4422c = new m();

    public static final C0248i b(m mVar, String str) {
        C0248i c0248i = new C0248i(str);
        C0248i.f4382d.put(str, c0248i);
        return c0248i;
    }

    public static String c(String str, int i9, int i10, String str2, int i11) throws EOFException {
        int i12 = (i11 & 1) != 0 ? 0 : i9;
        int length = (i11 & 2) != 0 ? str.length() : i10;
        boolean z9 = (i11 & 8) == 0;
        boolean z10 = (i11 & 16) == 0;
        boolean z11 = (i11 & 32) == 0;
        boolean z12 = (i11 & 64) == 0;
        kotlin.jvm.internal.h.e(str, "<this>");
        int iCharCount = i12;
        while (iCharCount < length) {
            int iCodePointAt = str.codePointAt(iCharCount);
            int i13 = 128;
            int i14 = 32;
            if (iCodePointAt < 32 || iCodePointAt == 127 || ((iCodePointAt >= 128 && !z12) || p229z8.e.b0(str2, (char) iCodePointAt) || ((iCodePointAt == 37 && (!z9 || (z10 && !f(str, iCharCount, length)))) || (iCodePointAt == 43 && z11)))) {
                C0467g c0467g = new C0467g();
                c0467g.v0(str, i12, iCharCount);
                C0467g c0467g2 = null;
                while (iCharCount < length) {
                    int iCodePointAt2 = str.codePointAt(iCharCount);
                    if (!z9 || (iCodePointAt2 != 9 && iCodePointAt2 != 10 && iCodePointAt2 != 12 && iCodePointAt2 != 13)) {
                        if (iCodePointAt2 == 43 && z11) {
                            c0467g.u0(z9 ? "+" : "%2B");
                        } else if (iCodePointAt2 < i14 || iCodePointAt2 == 127 || ((iCodePointAt2 >= i13 && !z12) || p229z8.e.b0(str2, (char) iCodePointAt2) || (iCodePointAt2 == 37 && (!z9 || (z10 && !f(str, iCharCount, length)))))) {
                            if (c0467g2 == null) {
                                c0467g2 = new C0467g();
                            }
                            c0467g2.w0(iCodePointAt2);
                            while (!c0467g2.y()) {
                                byte b10 = c0467g2.readByte();
                                c0467g.p0(37);
                                char[] cArr = u.f4444k;
                                c0467g.p0(cArr[((b10 & 255) >> 4) & 15]);
                                c0467g.p0(cArr[b10 & 15]);
                            }
                        } else {
                            c0467g.w0(iCodePointAt2);
                        }
                    }
                    iCharCount += Character.charCount(iCodePointAt2);
                    i13 = 128;
                    i14 = 32;
                }
                return c0467g.k0();
            }
            iCharCount += Character.charCount(iCodePointAt);
        }
        String strSubstring = str.substring(i12, length);
        kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public static I d(String string) {
        Charset charset = p229z8.a.f26609a;
        C0467g c0467g = new C0467g();
        kotlin.jvm.internal.h.e(charset, "charset");
        int length = string.length();
        kotlin.jvm.internal.h.e(string, "string");
        if (length < 0) {
            throw new IllegalArgumentException(B0.a.m("endIndex < beginIndex: ", length, 0, " < ").toString());
        }
        if (length > string.length()) {
            StringBuilder sbR = B0.a.r("endIndex > string.length: ", length, " > ");
            sbR.append(string.length());
            throw new IllegalArgumentException(sbR.toString().toString());
        }
        if (charset.equals(p229z8.a.f26609a)) {
            c0467g.v0(string, 0, length);
        } else {
            String strSubstring = string.substring(0, length);
            kotlin.jvm.internal.h.d(strSubstring, "substring(...)");
            byte[] bytes = strSubstring.getBytes(charset);
            kotlin.jvm.internal.h.d(bytes, "getBytes(...)");
            c0467g.write(bytes, 0, bytes.length);
        }
        return new I(null, c0467g.f9475b, c0467g, 0);
    }

    public static boolean f(String str, int i9, int i10) {
        int i11 = i9 + 2;
        return i11 < i10 && str.charAt(i9) == '%' && M8.b.q(str.charAt(i9 + 1)) != -1 && M8.b.q(str.charAt(i11)) != -1;
    }

    public static String g(int i9, int i10, int i11, String str) {
        int i12;
        if ((i11 & 1) != 0) {
            i9 = 0;
        }
        if ((i11 & 2) != 0) {
            i10 = str.length();
        }
        boolean z9 = (i11 & 4) == 0;
        kotlin.jvm.internal.h.e(str, "<this>");
        int iCharCount = i9;
        while (iCharCount < i10) {
            char cCharAt = str.charAt(iCharCount);
            if (cCharAt == '%' || (cCharAt == '+' && z9)) {
                C0467g c0467g = new C0467g();
                c0467g.v0(str, i9, iCharCount);
                while (iCharCount < i10) {
                    int iCodePointAt = str.codePointAt(iCharCount);
                    if (iCodePointAt == 37 && (i12 = iCharCount + 2) < i10) {
                        int iQ = M8.b.q(str.charAt(iCharCount + 1));
                        int iQ2 = M8.b.q(str.charAt(i12));
                        if (iQ == -1 || iQ2 == -1) {
                            c0467g.w0(iCodePointAt);
                            iCharCount += Character.charCount(iCodePointAt);
                        } else {
                            c0467g.p0((iQ << 4) + iQ2);
                            iCharCount = Character.charCount(iCodePointAt) + i12;
                        }
                    } else if (iCodePointAt == 43 && z9) {
                        c0467g.p0(32);
                        iCharCount++;
                    } else {
                        c0467g.w0(iCodePointAt);
                        iCharCount += Character.charCount(iCodePointAt);
                    }
                }
                return c0467g.k0();
            }
            iCharCount++;
        }
        String strSubstring = str.substring(i9, i10);
        kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public static ArrayList h(String str) {
        ArrayList arrayList = new ArrayList();
        int i9 = 0;
        while (i9 <= str.length()) {
            int iG0 = p229z8.e.g0(str, '&', i9, 4);
            if (iG0 == -1) {
                iG0 = str.length();
            }
            int iG1 = p229z8.e.g0(str, '=', i9, 4);
            if (iG1 == -1 || iG1 > iG0) {
                String strSubstring = str.substring(i9, iG0);
                kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
                arrayList.add(strSubstring);
                arrayList.add(null);
            } else {
                String strSubstring2 = str.substring(i9, iG1);
                kotlin.jvm.internal.h.d(strSubstring2, "this as java.lang.String…ing(startIndex, endIndex)");
                arrayList.add(strSubstring2);
                String strSubstring3 = str.substring(iG1 + 1, iG0);
                kotlin.jvm.internal.h.d(strSubstring3, "this as java.lang.String…ing(startIndex, endIndex)");
                arrayList.add(strSubstring3);
            }
            i9 = iG0 + 1;
        }
        return arrayList;
    }

    public static void i(List list, StringBuilder sb) {
        kotlin.jvm.internal.h.e(list, "<this>");
        w8.a aVarK = p001a.a.K(p001a.a.M(0, list.size()), 2);
        int i9 = aVarK.f25509a;
        int i10 = aVarK.f25510b;
        int i11 = aVarK.f25511c;
        if ((i11 <= 0 || i9 > i10) && (i11 >= 0 || i10 > i9)) {
            return;
        }
        while (true) {
            String str = (String) list.get(i9);
            String str2 = (String) list.get(i9 + 1);
            if (i9 > 0) {
                sb.append('&');
            }
            sb.append(str);
            if (str2 != null) {
                sb.append('=');
                sb.append(str2);
            }
            if (i9 == i10) {
                return;
            } else {
                i9 += i11;
            }
        }
    }

    @Override // L8.InterfaceC0241b
    public C a(K k9, H response) {
        kotlin.jvm.internal.h.e(response, "response");
        return null;
    }

    public synchronized C0248i e(String javaName) {
        C0248i c0248i;
        String strConcat;
        try {
            kotlin.jvm.internal.h.e(javaName, "javaName");
            LinkedHashMap linkedHashMap = C0248i.f4382d;
            c0248i = (C0248i) linkedHashMap.get(javaName);
            if (c0248i == null) {
                if (p229z8.m.a0(javaName, "TLS_", false)) {
                    String strSubstring = javaName.substring(4);
                    kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String).substring(startIndex)");
                    strConcat = "SSL_".concat(strSubstring);
                } else if (p229z8.m.a0(javaName, "SSL_", false)) {
                    String strSubstring2 = javaName.substring(4);
                    kotlin.jvm.internal.h.d(strSubstring2, "this as java.lang.String).substring(startIndex)");
                    strConcat = "TLS_".concat(strSubstring2);
                } else {
                    strConcat = javaName;
                }
                c0248i = (C0248i) linkedHashMap.get(strConcat);
                if (c0248i == null) {
                    c0248i = new C0248i(javaName);
                }
                linkedHashMap.put(javaName, c0248i);
            }
        } catch (Throwable th) {
            throw th;
        }
        return c0248i;
    }
}
