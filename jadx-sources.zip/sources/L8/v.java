package L8;

/* JADX INFO: loaded from: classes.dex */
public interface v {
    H a(Q8.f fVar);
}
