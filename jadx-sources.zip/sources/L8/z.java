package L8;

import com.google.android.gms.internal.measurement.AbstractC0837z1;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

/* JADX INFO: loaded from: classes.dex */
public final class z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p125n1.g f4470a = new p125n1.g(4);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final V5.c f4471b = new V5.c(12);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f4472c = new ArrayList();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f4473d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C7.q f4474e = new C7.q(13);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f4475f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public InterfaceC0241b f4476g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f4477h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f4478i;
    public final m j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final m f4479k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final m f4480l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final SocketFactory f4481m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public SSLSocketFactory f4482n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public X509TrustManager f4483o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final List f4484p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final List f4485q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public HostnameVerifier f4486r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final C0246g f4487s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public AbstractC0837z1 f4488t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f4489u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f4490v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f4491w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f4492x;

    public z() {
        m mVar = InterfaceC0241b.f4358a;
        this.f4476g = mVar;
        this.f4477h = true;
        this.f4478i = true;
        this.j = m.f4421b;
        this.f4479k = m.f4422c;
        this.f4480l = mVar;
        SocketFactory socketFactory = SocketFactory.getDefault();
        kotlin.jvm.internal.h.d(socketFactory, "getDefault()");
        this.f4481m = socketFactory;
        this.f4484p = A.f4264B;
        this.f4485q = A.f4263A;
        this.f4486r = X8.c.f9153a;
        this.f4487s = C0246g.f4377c;
        this.f4490v = 10000;
        this.f4491w = 10000;
        this.f4492x = 10000;
    }

    public final void a(v interceptor) {
        kotlin.jvm.internal.h.e(interceptor, "interceptor");
        this.f4472c.add(interceptor);
    }

    public final void b(long j, TimeUnit unit) {
        kotlin.jvm.internal.h.e(unit, "unit");
        this.f4489u = M8.b.b(j, unit);
    }

    public final void c(long j, TimeUnit unit) {
        kotlin.jvm.internal.h.e(unit, "unit");
        this.f4491w = M8.b.b(j, unit);
    }

    public final void d(long j, TimeUnit unit) {
        kotlin.jvm.internal.h.e(unit, "unit");
        this.f4492x = M8.b.b(j, unit);
    }
}
