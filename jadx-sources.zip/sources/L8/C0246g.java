package L8;

import com.google.android.gms.internal.measurement.AbstractC0837z1;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: renamed from: L8.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0246g {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C0246g f4377c = new C0246g(p048e8.i.G0(new ArrayList()), null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Set f4378a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final AbstractC0837z1 f4379b;

    public C0246g(Set set, AbstractC0837z1 abstractC0837z1) {
        this.f4378a = set;
        this.f4379b = abstractC0837z1;
    }

    public final void a(String hostname, p167r8.a aVar) {
        kotlin.jvm.internal.h.e(hostname, "hostname");
        Iterator it = this.f4378a.iterator();
        if (it.hasNext()) {
            throw B0.a.i(it);
        }
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C0246g)) {
            return false;
        }
        C0246g c0246g = (C0246g) obj;
        return kotlin.jvm.internal.h.a(c0246g.f4378a, this.f4378a) && kotlin.jvm.internal.h.a(c0246g.f4379b, this.f4379b);
    }

    public final int hashCode() {
        int iHashCode = (this.f4378a.hashCode() + 1517) * 41;
        AbstractC0837z1 abstractC0837z1 = this.f4379b;
        return iHashCode + (abstractC0837z1 != null ? abstractC0837z1.hashCode() : 0);
    }
}
