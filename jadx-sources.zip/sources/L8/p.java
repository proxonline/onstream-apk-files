package L8;

import java.io.File;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;

/* JADX INFO: loaded from: classes.dex */
public final class p extends kotlin.jvm.internal.i implements p167r8.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f4428d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ kotlin.jvm.internal.i f4429e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public p(int i9, p167r8.a aVar) {
        super(0);
        this.f4428d = i9;
        switch (i9) {
            case 1:
                this.f4429e = (kotlin.jvm.internal.i) aVar;
                super(0);
                break;
            default:
                this.f4429e = (kotlin.jvm.internal.i) aVar;
                break;
        }
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [kotlin.jvm.internal.i, r8.a] */
    @Override // p167r8.a
    public final Object invoke() {
        int i9 = this.f4428d;
        ?? r9 = this.f4429e;
        switch (i9) {
            case 0:
                try {
                    return (List) r9.invoke();
                } catch (SSLPeerUnverifiedException unused) {
                    return p048e8.q.f17244a;
                }
            default:
                File file = (File) r9.invoke();
                kotlin.jvm.internal.h.e(file, "<this>");
                String name = file.getName();
                kotlin.jvm.internal.h.d(name, "getName(...)");
                if (p229z8.e.u0(name, '.', "").equals("preferences_pb")) {
                    String str = Y8.y.f9516b;
                    File absoluteFile = file.getAbsoluteFile();
                    kotlin.jvm.internal.h.d(absoluteFile, "file.absoluteFile");
                    return X3.A.f(absoluteFile);
                }
                throw new IllegalStateException(("File extension for file: " + file + " does not match required extension for Preferences file: preferences_pb").toString());
        }
    }
}
