package L8;

import com.google.android.gms.internal.measurement.AbstractC0837z1;
import java.net.ProxySelector;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.List;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

/* JADX INFO: loaded from: classes.dex */
public final class A implements Cloneable, InterfaceC0243d {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final List f4263A = M8.b.k(B.HTTP_2, B.HTTP_1_1);

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public static final List f4264B = M8.b.k(C0250k.f4403e, C0250k.f4404f);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p125n1.g f4265a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final V5.c f4266b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f4267c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f4268d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C7.q f4269e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f4270f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final InterfaceC0241b f4271g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f4272h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f4273i;
    public final m j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final m f4274k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final ProxySelector f4275l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final m f4276m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final SocketFactory f4277n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final SSLSocketFactory f4278o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final X509TrustManager f4279p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final List f4280q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final List f4281r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final HostnameVerifier f4282s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final C0246g f4283t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final AbstractC0837z1 f4284u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f4285v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f4286w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f4287x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f4288y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final p137o3.i f4289z;

    public A() {
        this(new z());
    }

    public A(z zVar) throws NoSuchAlgorithmException, KeyStoreException {
        this.f4265a = zVar.f4470a;
        this.f4266b = zVar.f4471b;
        this.f4267c = M8.b.w(zVar.f4472c);
        this.f4268d = M8.b.w(zVar.f4473d);
        this.f4269e = zVar.f4474e;
        this.f4270f = zVar.f4475f;
        this.f4271g = zVar.f4476g;
        this.f4272h = zVar.f4477h;
        this.f4273i = zVar.f4478i;
        this.j = zVar.j;
        this.f4274k = zVar.f4479k;
        ProxySelector proxySelector = ProxySelector.getDefault();
        this.f4275l = proxySelector == null ? V8.a.f7777a : proxySelector;
        this.f4276m = zVar.f4480l;
        this.f4277n = zVar.f4481m;
        List list = zVar.f4484p;
        this.f4280q = list;
        this.f4281r = zVar.f4485q;
        this.f4282s = zVar.f4486r;
        this.f4285v = zVar.f4489u;
        this.f4286w = zVar.f4490v;
        this.f4287x = zVar.f4491w;
        this.f4288y = zVar.f4492x;
        this.f4289z = new p137o3.i(18, (byte) 0);
        if (list != null && list.isEmpty()) {
            this.f4278o = null;
            this.f4284u = null;
            this.f4279p = null;
            this.f4283t = C0246g.f4377c;
            break;
        }
        Iterator it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                this.f4278o = null;
                this.f4284u = null;
                this.f4279p = null;
                this.f4283t = C0246g.f4377c;
                break;
            }
            if (((C0250k) it.next()).f4405a) {
                SSLSocketFactory sSLSocketFactory = zVar.f4482n;
                if (sSLSocketFactory == null) {
                    T8.n nVar = T8.n.f7369a;
                    X509TrustManager x509TrustManagerM = T8.n.f7369a.m();
                    this.f4279p = x509TrustManagerM;
                    this.f4278o = T8.n.f7369a.l(x509TrustManagerM);
                    AbstractC0837z1 abstractC0837z1B = T8.n.f7369a.b(x509TrustManagerM);
                    this.f4284u = abstractC0837z1B;
                    C0246g c0246g = zVar.f4487s;
                    c0246g.getClass();
                    this.f4283t = kotlin.jvm.internal.h.a(c0246g.f4379b, abstractC0837z1B) ? c0246g : new C0246g(c0246g.f4378a, abstractC0837z1B);
                    break;
                }
                this.f4278o = sSLSocketFactory;
                AbstractC0837z1 abstractC0837z1 = zVar.f4488t;
                kotlin.jvm.internal.h.b(abstractC0837z1);
                this.f4284u = abstractC0837z1;
                X509TrustManager x509TrustManager = zVar.f4483o;
                kotlin.jvm.internal.h.b(x509TrustManager);
                this.f4279p = x509TrustManager;
                C0246g c0246g2 = zVar.f4487s;
                c0246g2.getClass();
                this.f4283t = kotlin.jvm.internal.h.a(c0246g2.f4379b, abstractC0837z1) ? c0246g2 : new C0246g(c0246g2.f4378a, abstractC0837z1);
                break;
            }
        }
        X509TrustManager x509TrustManager2 = this.f4279p;
        AbstractC0837z1 abstractC0837z2 = this.f4284u;
        SSLSocketFactory sSLSocketFactory2 = this.f4278o;
        List list2 = this.f4268d;
        List list3 = this.f4267c;
        kotlin.jvm.internal.h.c(list3, "null cannot be cast to non-null type kotlin.collections.List<okhttp3.Interceptor?>");
        if (list3.contains(null)) {
            throw new IllegalStateException(("Null interceptor: " + list3).toString());
        }
        kotlin.jvm.internal.h.c(list2, "null cannot be cast to non-null type kotlin.collections.List<okhttp3.Interceptor?>");
        if (list2.contains(null)) {
            throw new IllegalStateException(("Null network interceptor: " + list2).toString());
        }
        List list4 = this.f4280q;
        if (list4 == null || !list4.isEmpty()) {
            Iterator it2 = list4.iterator();
            while (it2.hasNext()) {
                if (((C0250k) it2.next()).f4405a) {
                    if (sSLSocketFactory2 == null) {
                        throw new IllegalStateException("sslSocketFactory == null");
                    }
                    if (abstractC0837z2 == null) {
                        throw new IllegalStateException("certificateChainCleaner == null");
                    }
                    if (x509TrustManager2 == null) {
                        throw new IllegalStateException("x509TrustManager == null");
                    }
                    return;
                }
            }
        }
        if (sSLSocketFactory2 != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (abstractC0837z2 != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (x509TrustManager2 != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (!kotlin.jvm.internal.h.a(this.f4283t, C0246g.f4377c)) {
            throw new IllegalStateException("Check failed.");
        }
    }

    public final Object clone() {
        return super.clone();
    }
}
