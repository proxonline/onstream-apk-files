package L8;

import java.io.Closeable;

/* JADX INFO: loaded from: classes.dex */
public final class H implements Closeable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C f4322a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final B f4323b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f4324c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f4325d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final q f4326e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final s f4327f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final J f4328g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final H f4329h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final H f4330i;
    public final H j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final long f4331k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final long f4332l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final G4.k f4333m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public C0242c f4334n;

    public H(C request, B protocol, String message, int i9, q qVar, s sVar, J j, H h6, H h9, H h10, long j9, long j10, G4.k kVar) {
        kotlin.jvm.internal.h.e(request, "request");
        kotlin.jvm.internal.h.e(protocol, "protocol");
        kotlin.jvm.internal.h.e(message, "message");
        this.f4322a = request;
        this.f4323b = protocol;
        this.f4324c = message;
        this.f4325d = i9;
        this.f4326e = qVar;
        this.f4327f = sVar;
        this.f4328g = j;
        this.f4329h = h6;
        this.f4330i = h9;
        this.j = h10;
        this.f4331k = j9;
        this.f4332l = j10;
        this.f4333m = kVar;
    }

    public static String a(H h6, String str) {
        h6.getClass();
        String strE = h6.f4327f.e(str);
        if (strE == null) {
            return null;
        }
        return strE;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        J j = this.f4328g;
        if (j == null) {
            throw new IllegalStateException("response is not eligible for a body and must not be closed");
        }
        j.close();
    }

    public final boolean f() {
        int i9 = this.f4325d;
        return 200 <= i9 && i9 < 300;
    }

    public final G k() {
        G g4 = new G();
        g4.f4310a = this.f4322a;
        g4.f4311b = this.f4323b;
        g4.f4312c = this.f4325d;
        g4.f4313d = this.f4324c;
        g4.f4314e = this.f4326e;
        g4.f4315f = this.f4327f.k();
        g4.f4316g = this.f4328g;
        g4.f4317h = this.f4329h;
        g4.f4318i = this.f4330i;
        g4.j = this.j;
        g4.f4319k = this.f4331k;
        g4.f4320l = this.f4332l;
        g4.f4321m = this.f4333m;
        return g4;
    }

    public final String toString() {
        return "Response{protocol=" + this.f4323b + ", code=" + this.f4325d + ", message=" + this.f4324c + ", url=" + this.f4322a.f4298a + '}';
    }
}
