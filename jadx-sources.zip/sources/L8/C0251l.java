package L8;

import java.text.DateFormat;
import java.util.Date;
import java.util.regex.Pattern;

/* JADX INFO: renamed from: L8.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0251l {
    public static final Pattern j = Pattern.compile("(\\d{2,4})[^\\d]*");

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final Pattern f4409k = Pattern.compile("(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*");

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final Pattern f4410l = Pattern.compile("(\\d{1,2})[^\\d]*");

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final Pattern f4411m = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[^\\d]*");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f4412a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f4413b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f4414c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f4415d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f4416e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f4417f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f4418g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f4419h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f4420i;

    public C0251l(String str, String str2, long j9, String str3, String str4, boolean z9, boolean z10, boolean z11, boolean z12) {
        this.f4412a = str;
        this.f4413b = str2;
        this.f4414c = j9;
        this.f4415d = str3;
        this.f4416e = str4;
        this.f4417f = z9;
        this.f4418g = z10;
        this.f4419h = z11;
        this.f4420i = z12;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C0251l)) {
            return false;
        }
        C0251l c0251l = (C0251l) obj;
        return kotlin.jvm.internal.h.a(c0251l.f4412a, this.f4412a) && kotlin.jvm.internal.h.a(c0251l.f4413b, this.f4413b) && c0251l.f4414c == this.f4414c && kotlin.jvm.internal.h.a(c0251l.f4415d, this.f4415d) && kotlin.jvm.internal.h.a(c0251l.f4416e, this.f4416e) && c0251l.f4417f == this.f4417f && c0251l.f4418g == this.f4418g && c0251l.f4419h == this.f4419h && c0251l.f4420i == this.f4420i;
    }

    public final int hashCode() {
        int iF = p165r6.a.f(this.f4413b, p165r6.a.f(this.f4412a, 527, 31), 31);
        long j9 = this.f4414c;
        return ((((((p165r6.a.f(this.f4416e, p165r6.a.f(this.f4415d, (iF + ((int) (j9 ^ (j9 >>> 32)))) * 31, 31), 31) + (this.f4417f ? 1231 : 1237)) * 31) + (this.f4418g ? 1231 : 1237)) * 31) + (this.f4419h ? 1231 : 1237)) * 31) + (this.f4420i ? 1231 : 1237);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f4412a);
        sb.append('=');
        sb.append(this.f4413b);
        if (this.f4419h) {
            long j9 = this.f4414c;
            if (j9 == Long.MIN_VALUE) {
                sb.append("; max-age=0");
            } else {
                sb.append("; expires=");
                String str = ((DateFormat) Q8.c.f6616a.get()).format(new Date(j9));
                kotlin.jvm.internal.h.d(str, "STANDARD_DATE_FORMAT.get().format(this)");
                sb.append(str);
            }
        }
        if (!this.f4420i) {
            sb.append("; domain=");
            sb.append(this.f4415d);
        }
        sb.append("; path=");
        sb.append(this.f4416e);
        if (this.f4417f) {
            sb.append("; secure");
        }
        if (this.f4418g) {
            sb.append("; httponly");
        }
        String string = sb.toString();
        kotlin.jvm.internal.h.d(string, "toString()");
        return string;
    }
}
