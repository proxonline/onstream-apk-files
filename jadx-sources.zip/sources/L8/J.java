package L8;

import Y8.InterfaceC0469i;
import java.io.Closeable;

/* JADX INFO: loaded from: classes.dex */
public abstract class J implements Closeable {
    public abstract long a();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        M8.b.d(k());
    }

    public abstract w f();

    public abstract InterfaceC0469i k();
}
