package L8;

import com.google.android.gms.internal.measurement.I1;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f4436a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f4439d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ArrayList f4441f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ArrayList f4442g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f4443h;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f4437b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f4438c = "";

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f4440e = -1;

    public t() {
        ArrayList arrayList = new ArrayList();
        this.f4441f = arrayList;
        arrayList.add("");
    }

    public final u a() {
        ArrayList arrayList;
        String str = this.f4436a;
        if (str == null) {
            throw new IllegalStateException("scheme == null");
        }
        String strG = m.g(0, 0, 7, this.f4437b);
        String strG2 = m.g(0, 0, 7, this.f4438c);
        String str2 = this.f4439d;
        if (str2 == null) {
            throw new IllegalStateException("host == null");
        }
        int iB = b();
        ArrayList arrayList2 = this.f4441f;
        ArrayList arrayList3 = new ArrayList(p048e8.k.Z(arrayList2));
        int size = arrayList2.size();
        int i9 = 0;
        while (i9 < size) {
            Object obj = arrayList2.get(i9);
            i9++;
            arrayList3.add(m.g(0, 0, 7, (String) obj));
        }
        ArrayList arrayList4 = this.f4442g;
        if (arrayList4 != null) {
            arrayList = new ArrayList(p048e8.k.Z(arrayList4));
            int size2 = arrayList4.size();
            int i10 = 0;
            while (i10 < size2) {
                Object obj2 = arrayList4.get(i10);
                i10++;
                String str3 = (String) obj2;
                arrayList.add(str3 != null ? m.g(0, 0, 3, str3) : null);
            }
        } else {
            arrayList = null;
        }
        String str4 = this.f4443h;
        return new u(str, strG, strG2, str2, iB, arrayList3, arrayList, str4 != null ? m.g(0, 0, 7, str4) : null, toString());
    }

    public final int b() {
        int i9 = this.f4440e;
        if (i9 != -1) {
            return i9;
        }
        String str = this.f4436a;
        kotlin.jvm.internal.h.b(str);
        if (str.equals("http")) {
            return 80;
        }
        return str.equals("https") ? 443 : -1;
    }

    /* JADX WARN: Code duplicated, block: B:39:0x007d  */
    public final void c(u uVar, String input) {
        int i9;
        int iG;
        int i10;
        char cCharAt;
        kotlin.jvm.internal.h.e(input, "input");
        byte[] bArr = M8.b.f4773a;
        int iM = M8.b.m(input, 0, input.length());
        int iN = M8.b.n(input, iM, input.length());
        if (iN - iM < 2) {
            i9 = -1;
            break;
        }
        char cCharAt2 = input.charAt(iM);
        if ((kotlin.jvm.internal.h.g(cCharAt2, 97) < 0 || kotlin.jvm.internal.h.g(cCharAt2, 122) > 0) && (kotlin.jvm.internal.h.g(cCharAt2, 65) < 0 || kotlin.jvm.internal.h.g(cCharAt2, 90) > 0)) {
            i9 = -1;
            break;
        }
        i9 = iM + 1;
        while (true) {
            if (i9 < iN) {
                char cCharAt3 = input.charAt(i9);
                if (('a' > cCharAt3 || cCharAt3 >= '{') && (('A' > cCharAt3 || cCharAt3 >= '[') && !(('0' <= cCharAt3 && cCharAt3 < ':') || cCharAt3 == '+' || cCharAt3 == '-' || cCharAt3 == '.'))) {
                    if (cCharAt3 != ':') {
                        break;
                    } else {
                        break;
                    }
                }
                i9++;
            }
            i9 = -1;
            break;
        }
        if (i9 == -1) {
            if (uVar == null) {
                throw new IllegalArgumentException(p165r6.a.s("Expected URL scheme 'http' or 'https' but no scheme was found for ", input.length() > 6 ? p229z8.e.w0(6, input).concat("...") : input));
            }
            this.f4436a = uVar.f4445a;
        } else if (p229z8.m.Z(input, "https:", iM, true)) {
            this.f4436a = "https";
            iM += 6;
        } else {
            if (!p229z8.m.Z(input, "http:", iM, true)) {
                StringBuilder sb = new StringBuilder("Expected URL scheme 'http' or 'https' but was '");
                String strSubstring = input.substring(0, i9);
                kotlin.jvm.internal.h.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
                sb.append(strSubstring);
                sb.append('\'');
                throw new IllegalArgumentException(sb.toString());
            }
            this.f4436a = "http";
            iM += 5;
        }
        int i11 = 0;
        for (int i12 = iM; i12 < iN && ((cCharAt = input.charAt(i12)) == '\\' || cCharAt == '/'); i12++) {
            i11++;
        }
        ArrayList arrayList = this.f4441f;
        char c10 = '#';
        if (i11 >= 2 || uVar == null || !kotlin.jvm.internal.h.a(uVar.f4445a, this.f4436a)) {
            int i13 = iM + i11;
            boolean z9 = false;
            boolean z10 = false;
            while (true) {
                iG = M8.b.g(input, i13, iN, "@/\\?#");
                byte bCharAt = iG != iN ? input.charAt(iG) : (byte) -1;
                if (bCharAt == -1 || bCharAt == c10 || bCharAt == 47 || bCharAt == 92 || bCharAt == 63) {
                    break;
                }
                if (bCharAt == 64) {
                    if (z9) {
                        this.f4438c += "%40" + m.c(input, i13, iG, " \"':;<=>@[]^`{}|/\\?#", 240);
                        z9 = z9;
                    } else {
                        boolean z11 = z9;
                        int iF = M8.b.f(input, ':', i13, iG);
                        String strC = m.c(input, i13, iF, " \"':;<=>@[]^`{}|/\\?#", 240);
                        if (z10) {
                            strC = this.f4437b + "%40" + strC;
                        }
                        this.f4437b = strC;
                        if (iF != iG) {
                            this.f4438c = m.c(input, iF + 1, iG, " \"':;<=>@[]^`{}|/\\?#", 240);
                            z9 = true;
                        } else {
                            z9 = z11;
                        }
                        z10 = true;
                    }
                    i13 = iG + 1;
                    c10 = '#';
                }
            }
            int i14 = i13;
            while (true) {
                if (i14 >= iG) {
                    i14 = iG;
                    break;
                }
                char cCharAt4 = input.charAt(i14);
                if (cCharAt4 != '[') {
                    if (cCharAt4 == ':') {
                        break;
                    }
                } else {
                    do {
                        i14++;
                        if (i14 >= iG) {
                            break;
                        }
                    } while (input.charAt(i14) != ']');
                }
                i14++;
            }
            int i15 = i14 + 1;
            if (i15 < iG) {
                this.f4439d = I1.O(m.g(i13, i14, 4, input));
                try {
                    i10 = Integer.parseInt(m.c(input, i15, iG, "", 248));
                    if (1 > i10 || i10 >= 65536) {
                        i10 = -1;
                    }
                } catch (NumberFormatException unused) {
                }
                this.f4440e = i10;
                if (i10 == -1) {
                    StringBuilder sb2 = new StringBuilder("Invalid URL port: \"");
                    String strSubstring2 = input.substring(i15, iG);
                    kotlin.jvm.internal.h.d(strSubstring2, "this as java.lang.String…ing(startIndex, endIndex)");
                    sb2.append(strSubstring2);
                    sb2.append('\"');
                    throw new IllegalArgumentException(sb2.toString().toString());
                }
            } else {
                this.f4439d = I1.O(m.g(i13, i14, 4, input));
                String str = this.f4436a;
                kotlin.jvm.internal.h.b(str);
                this.f4440e = str.equals("http") ? 80 : str.equals("https") ? 443 : -1;
            }
            if (this.f4439d == null) {
                StringBuilder sb3 = new StringBuilder("Invalid URL host: \"");
                String strSubstring3 = input.substring(i13, i14);
                kotlin.jvm.internal.h.d(strSubstring3, "this as java.lang.String…ing(startIndex, endIndex)");
                sb3.append(strSubstring3);
                sb3.append('\"');
                throw new IllegalArgumentException(sb3.toString().toString());
            }
            iM = iG;
        } else {
            this.f4437b = uVar.e();
            this.f4438c = uVar.a();
            this.f4439d = uVar.f4448d;
            this.f4440e = uVar.f4449e;
            arrayList.clear();
            arrayList.addAll(uVar.c());
            if (iM == iN || input.charAt(iM) == '#') {
                String strD = uVar.d();
                this.f4442g = strD != null ? m.h(m.c(strD, 0, 0, " \"'<>#", 211)) : null;
            }
        }
        int iG2 = M8.b.g(input, iM, iN, "?#");
        if (iM != iG2) {
            char cCharAt5 = input.charAt(iM);
            if (cCharAt5 == '/' || cCharAt5 == '\\') {
                arrayList.clear();
                arrayList.add("");
                iM++;
            } else {
                arrayList.set(arrayList.size() - 1, "");
            }
            while (iM < iG2) {
                int iG3 = M8.b.g(input, iM, iG2, "/\\");
                boolean z12 = iG3 < iG2;
                String strC2 = m.c(input, iM, iG3, " \"<>^`{}|/\\?#", 240);
                if (!strC2.equals(".") && !strC2.equalsIgnoreCase("%2e")) {
                    if (!strC2.equals("..") && !strC2.equalsIgnoreCase("%2e.") && !strC2.equalsIgnoreCase(".%2e") && !strC2.equalsIgnoreCase("%2e%2e")) {
                        if (((CharSequence) arrayList.get(arrayList.size() - 1)).length() == 0) {
                            arrayList.set(arrayList.size() - 1, strC2);
                        } else {
                            arrayList.add(strC2);
                        }
                        if (z12) {
                            arrayList.add("");
                        }
                    } else if (((String) arrayList.remove(arrayList.size() - 1)).length() != 0 || arrayList.isEmpty()) {
                        arrayList.add("");
                    } else {
                        arrayList.set(arrayList.size() - 1, "");
                    }
                }
                iM = z12 ? iG3 + 1 : iG3;
            }
        }
        if (iG2 < iN && input.charAt(iG2) == '?') {
            int iF2 = M8.b.f(input, '#', iG2, iN);
            this.f4442g = m.h(m.c(input, iG2 + 1, iF2, " \"'<>#", 208));
            iG2 = iF2;
        }
        if (iG2 >= iN || input.charAt(iG2) != '#') {
            return;
        }
        this.f4443h = m.c(input, iG2 + 1, iN, "", 176);
    }

    /* JADX WARN: Code duplicated, block: B:34:0x008b  */
    public final String toString() {
        StringBuilder sb = new StringBuilder();
        String str = this.f4436a;
        if (str != null) {
            sb.append(str);
            sb.append("://");
        } else {
            sb.append("//");
        }
        if (this.f4437b.length() > 0 || this.f4438c.length() > 0) {
            sb.append(this.f4437b);
            if (this.f4438c.length() > 0) {
                sb.append(':');
                sb.append(this.f4438c);
            }
            sb.append('@');
        }
        String str2 = this.f4439d;
        if (str2 != null) {
            if (p229z8.e.b0(str2, ':')) {
                sb.append('[');
                sb.append(this.f4439d);
                sb.append(']');
            } else {
                sb.append(this.f4439d);
            }
        }
        int i9 = -1;
        if (this.f4440e != -1 || this.f4436a != null) {
            int iB = b();
            String str3 = this.f4436a;
            if (str3 == null) {
                sb.append(':');
                sb.append(iB);
            } else {
                if (str3.equals("http")) {
                    i9 = 80;
                } else if (str3.equals("https")) {
                    i9 = 443;
                }
                if (iB != i9) {
                    sb.append(':');
                    sb.append(iB);
                }
            }
        }
        ArrayList arrayList = this.f4441f;
        kotlin.jvm.internal.h.e(arrayList, "<this>");
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            sb.append('/');
            sb.append((String) arrayList.get(i10));
        }
        if (this.f4442g != null) {
            sb.append('?');
            ArrayList arrayList2 = this.f4442g;
            kotlin.jvm.internal.h.b(arrayList2);
            m.i(arrayList2, sb);
        }
        if (this.f4443h != null) {
            sb.append('#');
            sb.append(this.f4443h);
        }
        String string = sb.toString();
        kotlin.jvm.internal.h.d(string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }
}
