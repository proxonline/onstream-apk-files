package L8;

import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final L f4430a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0248i f4431b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f4432c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p039d8.j f4433d;

    public q(L l9, C0248i c0248i, List list, p167r8.a aVar) {
        this.f4430a = l9;
        this.f4431b = c0248i;
        this.f4432c = list;
        this.f4433d = p162r3.e.x(new p(0, aVar));
    }

    public final List a() {
        return (List) this.f4433d.getValue();
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return qVar.f4430a == this.f4430a && kotlin.jvm.internal.h.a(qVar.f4431b, this.f4431b) && kotlin.jvm.internal.h.a(qVar.a(), a()) && kotlin.jvm.internal.h.a(qVar.f4432c, this.f4432c);
    }

    public final int hashCode() {
        return this.f4432c.hashCode() + ((a().hashCode() + ((this.f4431b.hashCode() + ((this.f4430a.hashCode() + 527) * 31)) * 31)) * 31);
    }

    public final String toString() {
        String type;
        String type2;
        List<Certificate> listA = a();
        ArrayList arrayList = new ArrayList(p048e8.k.Z(listA));
        for (Certificate certificate : listA) {
            if (certificate instanceof X509Certificate) {
                type2 = ((X509Certificate) certificate).getSubjectDN().toString();
            } else {
                type2 = certificate.getType();
                kotlin.jvm.internal.h.d(type2, "type");
            }
            arrayList.add(type2);
        }
        String string = arrayList.toString();
        StringBuilder sb = new StringBuilder("Handshake{tlsVersion=");
        sb.append(this.f4430a);
        sb.append(" cipherSuite=");
        sb.append(this.f4431b);
        sb.append(" peerCertificates=");
        sb.append(string);
        sb.append(" localCertificates=");
        List<Certificate> list = this.f4432c;
        ArrayList arrayList2 = new ArrayList(p048e8.k.Z(list));
        for (Certificate certificate2 : list) {
            if (certificate2 instanceof X509Certificate) {
                type = ((X509Certificate) certificate2).getSubjectDN().toString();
            } else {
                type = certificate2.getType();
                kotlin.jvm.internal.h.d(type, "type");
            }
            arrayList2.add(type);
        }
        sb.append(arrayList2);
        sb.append('}');
        return sb.toString();
    }
}
