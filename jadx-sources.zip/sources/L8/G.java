package L8;

/* JADX INFO: loaded from: classes.dex */
public final class G {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C f4310a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public B f4311b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f4313d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public q f4314e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public J f4316g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public H f4317h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public H f4318i;
    public H j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public long f4319k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public long f4320l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public G4.k f4321m;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f4312c = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public r f4315f = new r();

    public static void b(H h6, String str) {
        if (h6 != null) {
            if (h6.f4328g != null) {
                throw new IllegalArgumentException(str.concat(".body != null").toString());
            }
            if (h6.f4329h != null) {
                throw new IllegalArgumentException(str.concat(".networkResponse != null").toString());
            }
            if (h6.f4330i != null) {
                throw new IllegalArgumentException(str.concat(".cacheResponse != null").toString());
            }
            if (h6.j != null) {
                throw new IllegalArgumentException(str.concat(".priorResponse != null").toString());
            }
        }
    }

    public final H a() {
        int i9 = this.f4312c;
        if (i9 < 0) {
            throw new IllegalStateException(("code < 0: " + this.f4312c).toString());
        }
        C c10 = this.f4310a;
        if (c10 == null) {
            throw new IllegalStateException("request == null");
        }
        B b10 = this.f4311b;
        if (b10 == null) {
            throw new IllegalStateException("protocol == null");
        }
        String str = this.f4313d;
        if (str != null) {
            return new H(c10, b10, str, i9, this.f4314e, this.f4315f.e(), this.f4316g, this.f4317h, this.f4318i, this.j, this.f4319k, this.f4320l, this.f4321m);
        }
        throw new IllegalStateException("message == null");
    }
}
