package L8;

import Y8.InterfaceC0468h;

/* JADX INFO: loaded from: classes.dex */
public abstract class F {
    public abstract long a();

    public abstract w b();

    public abstract void c(InterfaceC0468h interfaceC0468h);
}
