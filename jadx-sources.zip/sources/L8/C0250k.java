package L8;

import j$.util.Objects;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.net.ssl.SSLSocket;

/* JADX INFO: renamed from: L8.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0250k {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final C0250k f4403e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final C0250k f4404f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f4405a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f4406b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String[] f4407c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String[] f4408d;

    static {
        C0248i c0248i = C0248i.f4395r;
        C0248i c0248i2 = C0248i.f4396s;
        C0248i c0248i3 = C0248i.f4397t;
        C0248i c0248i4 = C0248i.f4389l;
        C0248i c0248i5 = C0248i.f4391n;
        C0248i c0248i6 = C0248i.f4390m;
        C0248i c0248i7 = C0248i.f4392o;
        C0248i c0248i8 = C0248i.f4394q;
        C0248i c0248i9 = C0248i.f4393p;
        C0248i[] c0248iArr = {c0248i, c0248i2, c0248i3, c0248i4, c0248i5, c0248i6, c0248i7, c0248i8, c0248i9};
        C0248i[] c0248iArr2 = {c0248i, c0248i2, c0248i3, c0248i4, c0248i5, c0248i6, c0248i7, c0248i8, c0248i9, C0248i.j, C0248i.f4388k, C0248i.f4386h, C0248i.f4387i, C0248i.f4384f, C0248i.f4385g, C0248i.f4383e};
        C0249j c0249j = new C0249j();
        c0249j.b((C0248i[]) Arrays.copyOf(c0248iArr, 9));
        L l9 = L.TLS_1_3;
        L l10 = L.TLS_1_2;
        c0249j.d(l9, l10);
        if (!c0249j.f4399a) {
            throw new IllegalArgumentException("no TLS extensions for cleartext connections");
        }
        c0249j.f4400b = true;
        c0249j.a();
        C0249j c0249j2 = new C0249j();
        c0249j2.b((C0248i[]) Arrays.copyOf(c0248iArr2, 16));
        c0249j2.d(l9, l10);
        if (!c0249j2.f4399a) {
            throw new IllegalArgumentException("no TLS extensions for cleartext connections");
        }
        c0249j2.f4400b = true;
        f4403e = c0249j2.a();
        C0249j c0249j3 = new C0249j();
        c0249j3.b((C0248i[]) Arrays.copyOf(c0248iArr2, 16));
        c0249j3.d(l9, l10, L.TLS_1_1, L.TLS_1_0);
        if (!c0249j3.f4399a) {
            throw new IllegalArgumentException("no TLS extensions for cleartext connections");
        }
        c0249j3.f4400b = true;
        c0249j3.a();
        f4404f = new C0250k(false, false, null, null);
    }

    public C0250k(boolean z9, boolean z10, String[] strArr, String[] strArr2) {
        this.f4405a = z9;
        this.f4406b = z10;
        this.f4407c = strArr;
        this.f4408d = strArr2;
    }

    public final List a() {
        String[] strArr = this.f4407c;
        if (strArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(strArr.length);
        for (String str : strArr) {
            arrayList.add(C0248i.f4380b.e(str));
        }
        return p048e8.i.D0(arrayList);
    }

    public final boolean b(SSLSocket sSLSocket) {
        if (!this.f4405a) {
            return false;
        }
        String[] strArr = this.f4408d;
        if (strArr != null && !M8.b.i(strArr, sSLSocket.getEnabledProtocols(), p066g8.a.f18429b)) {
            return false;
        }
        String[] strArr2 = this.f4407c;
        return strArr2 == null || M8.b.i(strArr2, sSLSocket.getEnabledCipherSuites(), C0248i.f4381c);
    }

    public final List c() {
        String[] strArr = this.f4408d;
        if (strArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(strArr.length);
        for (String str : strArr) {
            arrayList.add(T8.l.s(str));
        }
        return p048e8.i.D0(arrayList);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C0250k)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        C0250k c0250k = (C0250k) obj;
        boolean z9 = c0250k.f4405a;
        boolean z10 = this.f4405a;
        if (z10 != z9) {
            return false;
        }
        if (z10) {
            return Arrays.equals(this.f4407c, c0250k.f4407c) && Arrays.equals(this.f4408d, c0250k.f4408d) && this.f4406b == c0250k.f4406b;
        }
        return true;
    }

    public final int hashCode() {
        if (!this.f4405a) {
            return 17;
        }
        String[] strArr = this.f4407c;
        int iHashCode = (527 + (strArr != null ? Arrays.hashCode(strArr) : 0)) * 31;
        String[] strArr2 = this.f4408d;
        return ((iHashCode + (strArr2 != null ? Arrays.hashCode(strArr2) : 0)) * 31) + (!this.f4406b ? 1 : 0);
    }

    public final String toString() {
        if (!this.f4405a) {
            return "ConnectionSpec()";
        }
        return "ConnectionSpec(cipherSuites=" + Objects.toString(a(), "[all enabled]") + ", tlsVersions=" + Objects.toString(c(), "[all enabled]") + ", supportsTlsExtensions=" + this.f4406b + ')';
    }
}
