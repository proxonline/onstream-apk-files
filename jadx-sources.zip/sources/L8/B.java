package L8;

/* JADX INFO: loaded from: classes.dex */
public enum B {
    HTTP_1_0("http/1.0"),
    HTTP_1_1("http/1.1"),
    SPDY_3("spdy/3.1"),
    HTTP_2("h2"),
    H2_PRIOR_KNOWLEDGE("h2_prior_knowledge"),
    QUIC("quic");


    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f4297a;

    B(String str) {
        this.f4297a = str;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return this.f4297a;
    }
}
