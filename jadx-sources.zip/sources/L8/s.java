package L8;

import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public final class s implements Iterable, p176s8.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String[] f4435a;

    public s(String[] strArr) {
        this.f4435a = strArr;
    }

    public final String e(String name) {
        kotlin.jvm.internal.h.e(name, "name");
        String[] strArr = this.f4435a;
        int length = strArr.length - 2;
        int iT = p001a.a.t(length, 0, -2);
        if (iT > length) {
            return null;
        }
        while (!name.equalsIgnoreCase(strArr[length])) {
            if (length == iT) {
                return null;
            }
            length -= 2;
        }
        return strArr[length + 1];
    }

    public final boolean equals(Object obj) {
        if (obj instanceof s) {
            return Arrays.equals(this.f4435a, ((s) obj).f4435a);
        }
        return false;
    }

    public final Date g(String str) {
        String strE = e(str);
        if (strE == null) {
            return null;
        }
        K3.j jVar = Q8.c.f6616a;
        if (strE.length() == 0) {
            return null;
        }
        ParsePosition parsePosition = new ParsePosition(0);
        Date date = ((DateFormat) Q8.c.f6616a.get()).parse(strE, parsePosition);
        if (parsePosition.getIndex() == strE.length()) {
            return date;
        }
        String[] strArr = Q8.c.f6617b;
        synchronized (strArr) {
            try {
                int length = strArr.length;
                for (int i9 = 0; i9 < length; i9++) {
                    DateFormat[] dateFormatArr = Q8.c.f6618c;
                    DateFormat simpleDateFormat = dateFormatArr[i9];
                    if (simpleDateFormat == null) {
                        simpleDateFormat = new SimpleDateFormat(Q8.c.f6617b[i9], Locale.US);
                        simpleDateFormat.setTimeZone(M8.b.f4777e);
                        dateFormatArr[i9] = simpleDateFormat;
                    }
                    parsePosition.setIndex(0);
                    Date date2 = simpleDateFormat.parse(strE, parsePosition);
                    if (parsePosition.getIndex() != 0) {
                        return date2;
                    }
                }
                return null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f4435a);
    }

    public final String i(int i9) {
        return this.f4435a[i9 * 2];
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        int size = size();
        p039d8.g[] gVarArr = new p039d8.g[size];
        for (int i9 = 0; i9 < size; i9++) {
            gVarArr[i9] = new p039d8.g(i(i9), m(i9));
        }
        return kotlin.jvm.internal.r.d(gVarArr);
    }

    public final r k() {
        r rVar = new r();
        ArrayList arrayList = rVar.f4434a;
        kotlin.jvm.internal.h.e(arrayList, "<this>");
        String[] elements = this.f4435a;
        kotlin.jvm.internal.h.e(elements, "elements");
        arrayList.addAll(p048e8.h.P(elements));
        return rVar;
    }

    public final TreeMap l() {
        Comparator CASE_INSENSITIVE_ORDER = String.CASE_INSENSITIVE_ORDER;
        kotlin.jvm.internal.h.d(CASE_INSENSITIVE_ORDER, "CASE_INSENSITIVE_ORDER");
        TreeMap treeMap = new TreeMap(CASE_INSENSITIVE_ORDER);
        int size = size();
        for (int i9 = 0; i9 < size; i9++) {
            String strI = i(i9);
            Locale US = Locale.US;
            kotlin.jvm.internal.h.d(US, "US");
            String lowerCase = strI.toLowerCase(US);
            kotlin.jvm.internal.h.d(lowerCase, "this as java.lang.String).toLowerCase(locale)");
            List arrayList = (List) treeMap.get(lowerCase);
            if (arrayList == null) {
                arrayList = new ArrayList(2);
                treeMap.put(lowerCase, arrayList);
            }
            arrayList.add(m(i9));
        }
        return treeMap;
    }

    public final String m(int i9) {
        return this.f4435a[(i9 * 2) + 1];
    }

    public final int size() {
        return this.f4435a.length / 2;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        int size = size();
        for (int i9 = 0; i9 < size; i9++) {
            String strI = i(i9);
            String strM = m(i9);
            sb.append(strI);
            sb.append(": ");
            if (M8.b.p(strI)) {
                strM = "██";
            }
            sb.append(strM);
            sb.append("\n");
        }
        String string = sb.toString();
        kotlin.jvm.internal.h.d(string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }
}
