package L8;

/* JADX INFO: loaded from: classes.dex */
public final class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final s f4459a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final F f4460b;

    public x(s sVar, F f3) {
        this.f4459a = sVar;
        this.f4460b = f3;
    }
}
