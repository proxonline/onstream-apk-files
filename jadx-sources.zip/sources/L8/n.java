package L8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class n implements U2.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f4423a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f4424b;

    public n() {
        this.f4423a = new ArrayList();
        this.f4424b = new ArrayList();
    }

    public n(ArrayList arrayList, ArrayList arrayList2) {
        this.f4423a = arrayList;
        this.f4424b = arrayList2;
    }

    @Override // U2.f
    public int Q() {
        return this.f4424b.size();
    }

    @Override // U2.f
    public int a(long j) {
        int i9;
        Long lValueOf = Long.valueOf(j);
        int i10 = p071h3.y.f18900a;
        ArrayList arrayList = this.f4424b;
        int iBinarySearch = Collections.binarySearch(arrayList, lValueOf);
        if (iBinarySearch < 0) {
            i9 = ~iBinarySearch;
        } else {
            int size = arrayList.size();
            do {
                iBinarySearch++;
                if (iBinarySearch >= size) {
                    break;
                }
            } while (((Comparable) arrayList.get(iBinarySearch)).compareTo(lValueOf) == 0);
            i9 = iBinarySearch;
        }
        if (i9 < arrayList.size()) {
            return i9;
        }
        return -1;
    }

    @Override // U2.f
    public long n(int i9) {
        p071h3.a.h(i9 >= 0);
        ArrayList arrayList = this.f4424b;
        p071h3.a.h(i9 < arrayList.size());
        return ((Long) arrayList.get(i9)).longValue();
    }

    @Override // U2.f
    public List z(long j) {
        int iC = p071h3.y.c(this.f4424b, Long.valueOf(j), false);
        return iC == -1 ? Collections.EMPTY_LIST : (List) this.f4423a.get(iC);
    }
}
