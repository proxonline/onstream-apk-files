package p135o1;

import Y4.i;
import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.impl.foreground.SystemForegroundService;
import com.google.android.gms.internal.cast.RunnableC0647d;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import p060g1.j;
import p060g1.q;
import p069h1.a;
import p069h1.k;
import p105l1.c;

/* JADX INFO: loaded from: classes.dex */
public final class b implements p105l1.b, a {
    public static final String j = q.h("SystemFgDispatcher");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k f22029a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p170s1.a f22030b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f22031c = new Object();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f22032d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final LinkedHashMap f22033e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final HashMap f22034f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final HashSet f22035g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final c f22036h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public SystemForegroundService f22037i;

    public b(Context context) {
        k kVarQ = k.Q(context);
        this.f22029a = kVarQ;
        i iVar = kVarQ.f18548k;
        this.f22030b = iVar;
        this.f22032d = null;
        this.f22033e = new LinkedHashMap();
        this.f22035g = new HashSet();
        this.f22034f = new HashMap();
        this.f22036h = new c(context, iVar, this);
        kVarQ.f18550m.b(this);
    }

    public static Intent b(Context context, String str, j jVar) {
        Intent intent = new Intent(context, (Class<?>) SystemForegroundService.class);
        intent.setAction("ACTION_NOTIFY");
        intent.putExtra("KEY_NOTIFICATION_ID", jVar.f18120a);
        intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", jVar.f18121b);
        intent.putExtra("KEY_NOTIFICATION", jVar.f18122c);
        intent.putExtra("KEY_WORKSPEC_ID", str);
        return intent;
    }

    public static Intent d(Context context, String str, j jVar) {
        Intent intent = new Intent(context, (Class<?>) SystemForegroundService.class);
        intent.setAction("ACTION_START_FOREGROUND");
        intent.putExtra("KEY_WORKSPEC_ID", str);
        intent.putExtra("KEY_NOTIFICATION_ID", jVar.f18120a);
        intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", jVar.f18121b);
        intent.putExtra("KEY_NOTIFICATION", jVar.f18122c);
        intent.putExtra("KEY_WORKSPEC_ID", str);
        return intent;
    }

    @Override // p069h1.a
    public final void a(String str, boolean z9) {
        Map.Entry entry;
        synchronized (this.f22031c) {
            try {
                p144p1.j jVar = (p144p1.j) this.f22034f.remove(str);
                if (jVar != null ? this.f22035g.remove(jVar) : false) {
                    this.f22036h.c(this.f22035g);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        j jVar2 = (j) this.f22033e.remove(str);
        if (str.equals(this.f22032d) && this.f22033e.size() > 0) {
            Iterator it = this.f22033e.entrySet().iterator();
            Object next = it.next();
            while (true) {
                entry = (Map.Entry) next;
                if (!it.hasNext()) {
                    break;
                } else {
                    next = it.next();
                }
            }
            this.f22032d = (String) entry.getKey();
            if (this.f22037i != null) {
                j jVar3 = (j) entry.getValue();
                SystemForegroundService systemForegroundService = this.f22037i;
                systemForegroundService.f11344b.post(new c(systemForegroundService, jVar3.f18120a, jVar3.f18122c, jVar3.f18121b));
                SystemForegroundService systemForegroundService2 = this.f22037i;
                systemForegroundService2.f11344b.post(new E4.c(jVar3.f18120a, 5, systemForegroundService2));
            }
        }
        SystemForegroundService systemForegroundService3 = this.f22037i;
        if (jVar2 == null || systemForegroundService3 == null) {
            return;
        }
        q qVarC = q.c();
        String str2 = j;
        int i9 = jVar2.f18120a;
        int i10 = jVar2.f18121b;
        StringBuilder sb = new StringBuilder("Removing Notification (id: ");
        sb.append(i9);
        sb.append(", workSpecId: ");
        sb.append(str);
        sb.append(" ,notificationType: ");
        qVarC.a(str2, p165r6.a.j(sb, i10, ")"), new Throwable[0]);
        systemForegroundService3.f11344b.post(new E4.c(jVar2.f18120a, 5, systemForegroundService3));
    }

    @Override // p105l1.b
    public final void c(List list) {
        if (list.isEmpty()) {
            return;
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            String str = (String) it.next();
            q.c().a(j, p165r6.a.s("Constraints unmet for WorkSpec ", str), new Throwable[0]);
            k kVar = this.f22029a;
            kVar.f18548k.k(new p153q1.j(kVar, str, true));
        }
    }

    @Override // p105l1.b
    public final void e(List list) {
    }

    public final void f(Intent intent) {
        int i9 = 0;
        int intExtra = intent.getIntExtra("KEY_NOTIFICATION_ID", 0);
        int intExtra2 = intent.getIntExtra("KEY_FOREGROUND_SERVICE_TYPE", 0);
        String stringExtra = intent.getStringExtra("KEY_WORKSPEC_ID");
        Notification notification = (Notification) intent.getParcelableExtra("KEY_NOTIFICATION");
        q qVarC = q.c();
        StringBuilder sb = new StringBuilder("Notifying with (id: ");
        sb.append(intExtra);
        sb.append(", workSpecId: ");
        sb.append(stringExtra);
        sb.append(", notificationType: ");
        qVarC.a(j, p165r6.a.j(sb, intExtra2, ")"), new Throwable[0]);
        if (notification == null || this.f22037i == null) {
            return;
        }
        j jVar = new j(intExtra, notification, intExtra2);
        LinkedHashMap linkedHashMap = this.f22033e;
        linkedHashMap.put(stringExtra, jVar);
        if (TextUtils.isEmpty(this.f22032d)) {
            this.f22032d = stringExtra;
            SystemForegroundService systemForegroundService = this.f22037i;
            systemForegroundService.f11344b.post(new c(systemForegroundService, intExtra, notification, intExtra2));
            return;
        }
        SystemForegroundService systemForegroundService2 = this.f22037i;
        systemForegroundService2.f11344b.post(new RunnableC0647d(systemForegroundService2, intExtra, notification, 6));
        if (intExtra2 == 0 || Build.VERSION.SDK_INT < 29) {
            return;
        }
        Iterator it = linkedHashMap.entrySet().iterator();
        while (it.hasNext()) {
            i9 |= ((j) ((Map.Entry) it.next()).getValue()).f18121b;
        }
        j jVar2 = (j) linkedHashMap.get(this.f22032d);
        if (jVar2 != null) {
            SystemForegroundService systemForegroundService3 = this.f22037i;
            systemForegroundService3.f11344b.post(new c(systemForegroundService3, jVar2.f18120a, jVar2.f18122c, i9));
        }
    }

    public final void g() {
        this.f22037i = null;
        synchronized (this.f22031c) {
            this.f22036h.d();
        }
        this.f22029a.f18550m.f(this);
    }
}
