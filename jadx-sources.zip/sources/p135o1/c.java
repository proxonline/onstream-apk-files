package p135o1;

import android.app.Notification;
import android.os.Build;
import androidx.work.impl.foreground.SystemForegroundService;

/* JADX INFO: loaded from: classes.dex */
public final class c implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f22038a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Notification f22039b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f22040c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ SystemForegroundService f22041d;

    public c(SystemForegroundService systemForegroundService, int i9, Notification notification, int i10) {
        this.f22041d = systemForegroundService;
        this.f22038a = i9;
        this.f22039b = notification;
        this.f22040c = i10;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i9 = Build.VERSION.SDK_INT;
        Notification notification = this.f22039b;
        int i10 = this.f22038a;
        SystemForegroundService systemForegroundService = this.f22041d;
        if (i9 >= 29) {
            systemForegroundService.startForeground(i10, notification, this.f22040c);
        } else {
            systemForegroundService.startForeground(i10, notification);
        }
    }
}
