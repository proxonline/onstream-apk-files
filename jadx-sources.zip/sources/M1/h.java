package M1;

import androidx.lifecycle.EnumC0546o;
import androidx.lifecycle.InterfaceC0536e;
import androidx.lifecycle.InterfaceC0551u;

/* JADX INFO: loaded from: classes.dex */
public final class h extends D.o {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final h f4550b = new h(3);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final g f4551c = new g();

    @Override // D.o
    public final void X(InterfaceC0551u interfaceC0551u) {
        if (!(interfaceC0551u instanceof InterfaceC0536e)) {
            throw new IllegalArgumentException((interfaceC0551u + " must implement androidx.lifecycle.DefaultLifecycleObserver.").toString());
        }
        InterfaceC0536e interfaceC0536e = (InterfaceC0536e) interfaceC0551u;
        g gVar = f4551c;
        interfaceC0536e.k(gVar);
        interfaceC0536e.E(gVar);
        interfaceC0536e.a(gVar);
    }

    @Override // D.o
    public final EnumC0546o c0() {
        return EnumC0546o.f10798e;
    }

    @Override // D.o
    public final void k0(InterfaceC0551u interfaceC0551u) {
    }

    public final String toString() {
        return "coil.request.GlobalLifecycle";
    }
}
