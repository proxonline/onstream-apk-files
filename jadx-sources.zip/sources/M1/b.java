package M1;

/* JADX INFO: loaded from: classes.dex */
public enum b {
    ENABLED(true, true),
    /* JADX INFO: Fake field, exist only in values array */
    READ_ONLY(true, false),
    /* JADX INFO: Fake field, exist only in values array */
    WRITE_ONLY(false, true),
    DISABLED(false, false);


    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f4533a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f4534b;

    b(boolean z9, boolean z10) {
        this.f4533a = z9;
        this.f4534b = z10;
    }
}
