package M1;

import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: classes.dex */
public final class f extends k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Drawable f4547a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f4548b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Throwable f4549c;

    public f(Drawable drawable, j jVar, Throwable th) {
        this.f4547a = drawable;
        this.f4548b = jVar;
        this.f4549c = th;
    }

    @Override // M1.k
    public final Drawable a() {
        return this.f4547a;
    }

    @Override // M1.k
    public final j b() {
        return this.f4548b;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return kotlin.jvm.internal.h.a(this.f4547a, fVar.f4547a) && kotlin.jvm.internal.h.a(this.f4548b, fVar.f4548b) && kotlin.jvm.internal.h.a(this.f4549c, fVar.f4549c);
    }

    public final int hashCode() {
        Drawable drawable = this.f4547a;
        return this.f4549c.hashCode() + ((this.f4548b.hashCode() + ((drawable != null ? drawable.hashCode() : 0) * 31)) * 31);
    }
}
