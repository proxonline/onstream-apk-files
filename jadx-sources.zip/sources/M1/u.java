package M1;

import B8.B0;
import android.view.View;
import androidx.lifecycle.InterfaceC0551u;

/* JADX INFO: loaded from: classes.dex */
public final class u implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final View f4626a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public A5.g f4627b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public B0 f4628c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public s f4629d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f4630e;

    public u(View view) {
        this.f4626a = view;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        s sVar = this.f4629d;
        if (sVar == null) {
            return;
        }
        this.f4630e = true;
        sVar.f4620a.b(sVar.f4621b);
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        s sVar = this.f4629d;
        if (sVar != null) {
            D.o oVar = sVar.f4623d;
            sVar.f4624e.f(null);
            O1.a aVar = sVar.f4622c;
            if (aVar instanceof InterfaceC0551u) {
                oVar.k0(aVar);
            }
            oVar.k0(sVar);
        }
    }
}
