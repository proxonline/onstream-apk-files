package M1;

import androidx.lifecycle.InterfaceC0536e;

/* JADX INFO: loaded from: classes.dex */
public interface p extends InterfaceC0536e {
    void start();

    void w();

    void z();
}
