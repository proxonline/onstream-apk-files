package M1;

import B8.B0;
import B8.C0029a0;
import B8.D;
import B8.InterfaceC0047j0;
import B8.M;
import androidx.lifecycle.InterfaceC0551u;
import androidx.lifecycle.InterfaceC0552v;
import java.util.concurrent.CancellationException;

/* JADX INFO: loaded from: classes.dex */
public final class s implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C1.l f4620a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f4621b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final O1.a f4622c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final D.o f4623d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final InterfaceC0047j0 f4624e;

    public s(C1.l lVar, j jVar, O1.a aVar, D.o oVar, InterfaceC0047j0 interfaceC0047j0) {
        this.f4620a = lVar;
        this.f4621b = jVar;
        this.f4622c = aVar;
        this.f4623d = oVar;
        this.f4624e = interfaceC0047j0;
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final void E(InterfaceC0552v owner) {
        kotlin.jvm.internal.h.e(owner, "owner");
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final /* synthetic */ void J(InterfaceC0552v interfaceC0552v) {
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final void a(InterfaceC0552v owner) {
        kotlin.jvm.internal.h.e(owner, "owner");
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final void f(InterfaceC0552v interfaceC0552v) {
        u uVarC = Q1.f.c(this.f4622c.f5510b);
        synchronized (uVarC) {
            try {
                B0 b10 = uVarC.f4628c;
                if (b10 != null) {
                    b10.f(null);
                }
                C0029a0 c0029a0 = C0029a0.f460a;
                I8.e eVar = M.f437a;
                uVarC.f4628c = D.r(c0029a0, G8.o.f2662a.f867d, new t(uVarC, null), 2);
                uVarC.f4627b = null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final void k(InterfaceC0552v owner) {
        kotlin.jvm.internal.h.e(owner, "owner");
    }

    @Override // M1.p
    public final void start() {
        D.o oVar = this.f4623d;
        oVar.X(this);
        O1.a aVar = this.f4622c;
        if (aVar instanceof InterfaceC0551u) {
            O1.a aVar2 = aVar;
            oVar.k0(aVar2);
            oVar.X(aVar2);
        }
        u uVarC = Q1.f.c(aVar.f5510b);
        s sVar = uVarC.f4629d;
        if (sVar != null) {
            D.o oVar2 = sVar.f4623d;
            sVar.f4624e.f(null);
            O1.a aVar3 = sVar.f4622c;
            if (aVar3 instanceof InterfaceC0551u) {
                oVar2.k0(aVar3);
            }
            oVar2.k0(sVar);
        }
        uVarC.f4629d = this;
    }

    @Override // M1.p
    public final /* synthetic */ void w() {
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final /* synthetic */ void y(InterfaceC0552v interfaceC0552v) {
    }

    @Override // M1.p
    public final void z() {
        O1.a aVar = this.f4622c;
        if (aVar.f5510b.isAttachedToWindow()) {
            return;
        }
        u uVarC = Q1.f.c(aVar.f5510b);
        s sVar = uVarC.f4629d;
        if (sVar != null) {
            D.o oVar = sVar.f4623d;
            sVar.f4624e.f(null);
            O1.a aVar2 = sVar.f4622c;
            if (aVar2 instanceof InterfaceC0551u) {
                oVar.k0(aVar2);
            }
            oVar.k0(sVar);
        }
        uVarC.f4629d = this;
        throw new CancellationException("'ViewTarget.view' must be attached to a window.");
    }
}
