package M1;

import B8.InterfaceC0047j0;
import androidx.lifecycle.InterfaceC0552v;

/* JADX INFO: loaded from: classes.dex */
public final class a implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final D.o f4528a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final InterfaceC0047j0 f4529b;

    public a(D.o oVar, InterfaceC0047j0 interfaceC0047j0) {
        this.f4528a = oVar;
        this.f4529b = interfaceC0047j0;
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final void E(InterfaceC0552v owner) {
        kotlin.jvm.internal.h.e(owner, "owner");
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final /* synthetic */ void J(InterfaceC0552v interfaceC0552v) {
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final void a(InterfaceC0552v owner) {
        kotlin.jvm.internal.h.e(owner, "owner");
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final void f(InterfaceC0552v interfaceC0552v) {
        this.f4529b.f(null);
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final void k(InterfaceC0552v owner) {
        kotlin.jvm.internal.h.e(owner, "owner");
    }

    @Override // M1.p
    public final void start() {
        this.f4528a.X(this);
    }

    @Override // M1.p
    public final void w() {
        this.f4528a.k0(this);
    }

    @Override // androidx.lifecycle.InterfaceC0536e
    public final /* synthetic */ void y(InterfaceC0552v interfaceC0552v) {
    }

    @Override // M1.p
    public final /* synthetic */ void z() {
    }
}
