package M1;

import B8.AbstractC0062w;
import android.content.Context;
import android.graphics.Bitmap;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final c f4567A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f4568a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f4569b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final O1.b f4570c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Bitmap.Config f4571d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final N1.d f4572e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final List f4573f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final P1.d f4574g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final L8.s f4575h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final r f4576i;
    public final boolean j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final boolean f4577k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final boolean f4578l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final boolean f4579m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final b f4580n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final b f4581o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final b f4582p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final AbstractC0062w f4583q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final AbstractC0062w f4584r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final AbstractC0062w f4585s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final AbstractC0062w f4586t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final D.o f4587u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final N1.i f4588v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final N1.g f4589w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final o f4590x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final Integer f4591y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final d f4592z;

    public j(Context context, Object obj, O1.b bVar, Bitmap.Config config, N1.d dVar, List list, P1.d dVar2, L8.s sVar, r rVar, boolean z9, boolean z10, boolean z11, boolean z12, b bVar2, b bVar3, b bVar4, AbstractC0062w abstractC0062w, AbstractC0062w abstractC0062w2, AbstractC0062w abstractC0062w3, AbstractC0062w abstractC0062w4, D.o oVar, N1.i iVar, N1.g gVar, o oVar2, Integer num, d dVar3, c cVar) {
        this.f4568a = context;
        this.f4569b = obj;
        this.f4570c = bVar;
        this.f4571d = config;
        this.f4572e = dVar;
        this.f4573f = list;
        this.f4574g = dVar2;
        this.f4575h = sVar;
        this.f4576i = rVar;
        this.j = z9;
        this.f4577k = z10;
        this.f4578l = z11;
        this.f4579m = z12;
        this.f4580n = bVar2;
        this.f4581o = bVar3;
        this.f4582p = bVar4;
        this.f4583q = abstractC0062w;
        this.f4584r = abstractC0062w2;
        this.f4585s = abstractC0062w3;
        this.f4586t = abstractC0062w4;
        this.f4587u = oVar;
        this.f4588v = iVar;
        this.f4589w = gVar;
        this.f4590x = oVar2;
        this.f4591y = num;
        this.f4592z = dVar3;
        this.f4567A = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        return kotlin.jvm.internal.h.a(this.f4568a, jVar.f4568a) && this.f4569b.equals(jVar.f4569b) && kotlin.jvm.internal.h.a(this.f4570c, jVar.f4570c) && this.f4571d == jVar.f4571d && this.f4572e == jVar.f4572e && kotlin.jvm.internal.h.a(this.f4573f, jVar.f4573f) && kotlin.jvm.internal.h.a(this.f4574g, jVar.f4574g) && kotlin.jvm.internal.h.a(this.f4575h, jVar.f4575h) && this.f4576i.equals(jVar.f4576i) && this.j == jVar.j && this.f4577k == jVar.f4577k && this.f4578l == jVar.f4578l && this.f4579m == jVar.f4579m && this.f4580n == jVar.f4580n && this.f4581o == jVar.f4581o && this.f4582p == jVar.f4582p && kotlin.jvm.internal.h.a(this.f4583q, jVar.f4583q) && kotlin.jvm.internal.h.a(this.f4584r, jVar.f4584r) && kotlin.jvm.internal.h.a(this.f4585s, jVar.f4585s) && kotlin.jvm.internal.h.a(this.f4586t, jVar.f4586t) && kotlin.jvm.internal.h.a(this.f4591y, jVar.f4591y) && kotlin.jvm.internal.h.a(this.f4587u, jVar.f4587u) && this.f4588v.equals(jVar.f4588v) && this.f4589w == jVar.f4589w && this.f4590x.equals(jVar.f4590x) && this.f4592z.equals(jVar.f4592z) && kotlin.jvm.internal.h.a(this.f4567A, jVar.f4567A);
    }

    public final int hashCode() {
        int iHashCode = (this.f4569b.hashCode() + (this.f4568a.hashCode() * 31)) * 31;
        O1.b bVar = this.f4570c;
        int iHashCode2 = (this.f4590x.f4610a.hashCode() + ((this.f4589w.hashCode() + ((this.f4588v.hashCode() + ((this.f4587u.hashCode() + ((this.f4586t.hashCode() + ((this.f4585s.hashCode() + ((this.f4584r.hashCode() + ((this.f4583q.hashCode() + ((this.f4582p.hashCode() + ((this.f4581o.hashCode() + ((this.f4580n.hashCode() + ((((((((((this.f4576i.f4619a.hashCode() + ((((this.f4574g.hashCode() + ((this.f4573f.hashCode() + ((this.f4572e.hashCode() + ((this.f4571d.hashCode() + ((iHashCode + (bVar != null ? bVar.hashCode() : 0)) * 923521)) * 961)) * 29791)) * 31)) * 31) + Arrays.hashCode(this.f4575h.f4435a)) * 31)) * 31) + (this.j ? 1231 : 1237)) * 31) + (this.f4577k ? 1231 : 1237)) * 31) + (this.f4578l ? 1231 : 1237)) * 31) + (this.f4579m ? 1231 : 1237)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 923521;
        Integer num = this.f4591y;
        return this.f4567A.hashCode() + ((this.f4592z.hashCode() + ((iHashCode2 + (num != null ? num.hashCode() : 0)) * 923521)) * 31);
    }
}
