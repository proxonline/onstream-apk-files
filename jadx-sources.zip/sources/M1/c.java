package M1;

import B8.AbstractC0062w;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AbstractC0062w f4535a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final AbstractC0062w f4536b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final AbstractC0062w f4537c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final AbstractC0062w f4538d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final P1.d f4539e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final N1.d f4540f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Bitmap.Config f4541g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Drawable f4542h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final b f4543i;
    public final b j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final b f4544k;

    public c(AbstractC0062w abstractC0062w, AbstractC0062w abstractC0062w2, AbstractC0062w abstractC0062w3, AbstractC0062w abstractC0062w4, P1.d dVar, N1.d dVar2, Bitmap.Config config, Drawable drawable, b bVar, b bVar2, b bVar3) {
        this.f4535a = abstractC0062w;
        this.f4536b = abstractC0062w2;
        this.f4537c = abstractC0062w3;
        this.f4538d = abstractC0062w4;
        this.f4539e = dVar;
        this.f4540f = dVar2;
        this.f4541g = config;
        this.f4542h = drawable;
        this.f4543i = bVar;
        this.j = bVar2;
        this.f4544k = bVar3;
    }

    public static c a(c cVar, P1.d dVar, Drawable drawable, int i9) {
        AbstractC0062w abstractC0062w = cVar.f4535a;
        AbstractC0062w abstractC0062w2 = cVar.f4536b;
        AbstractC0062w abstractC0062w3 = cVar.f4537c;
        AbstractC0062w abstractC0062w4 = cVar.f4538d;
        if ((i9 & 16) != 0) {
            dVar = cVar.f4539e;
        }
        P1.d dVar2 = dVar;
        N1.d dVar3 = cVar.f4540f;
        Bitmap.Config config = cVar.f4541g;
        cVar.getClass();
        cVar.getClass();
        cVar.getClass();
        if ((i9 & 1024) != 0) {
            drawable = cVar.f4542h;
        }
        cVar.getClass();
        b bVar = cVar.f4543i;
        b bVar2 = cVar.j;
        b bVar3 = cVar.f4544k;
        cVar.getClass();
        return new c(abstractC0062w, abstractC0062w2, abstractC0062w3, abstractC0062w4, dVar2, dVar3, config, drawable, bVar, bVar2, bVar3);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return kotlin.jvm.internal.h.a(this.f4535a, cVar.f4535a) && kotlin.jvm.internal.h.a(this.f4536b, cVar.f4536b) && kotlin.jvm.internal.h.a(this.f4537c, cVar.f4537c) && kotlin.jvm.internal.h.a(this.f4538d, cVar.f4538d) && kotlin.jvm.internal.h.a(this.f4539e, cVar.f4539e) && this.f4540f == cVar.f4540f && this.f4541g == cVar.f4541g && kotlin.jvm.internal.h.a(this.f4542h, cVar.f4542h) && this.f4543i == cVar.f4543i && this.j == cVar.j && this.f4544k == cVar.f4544k;
    }

    public final int hashCode() {
        int iHashCode = (((((this.f4541g.hashCode() + ((this.f4540f.hashCode() + ((this.f4539e.hashCode() + ((this.f4538d.hashCode() + ((this.f4537c.hashCode() + ((this.f4536b.hashCode() + (this.f4535a.hashCode() * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31) + 1231) * 31) + 1237) * 961;
        Drawable drawable = this.f4542h;
        return this.f4544k.hashCode() + ((this.j.hashCode() + ((this.f4543i.hashCode() + ((iHashCode + (drawable != null ? drawable.hashCode() : 0)) * 961)) * 31)) * 31);
    }
}
