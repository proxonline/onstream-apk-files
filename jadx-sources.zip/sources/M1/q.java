package M1;

import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: classes.dex */
public final class q extends k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Drawable f4611a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f4612b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final D1.h f4613c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final K1.a f4614d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f4615e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f4616f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f4617g;

    public q(Drawable drawable, j jVar, D1.h hVar, K1.a aVar, String str, boolean z9, boolean z10) {
        this.f4611a = drawable;
        this.f4612b = jVar;
        this.f4613c = hVar;
        this.f4614d = aVar;
        this.f4615e = str;
        this.f4616f = z9;
        this.f4617g = z10;
    }

    @Override // M1.k
    public final Drawable a() {
        return this.f4611a;
    }

    @Override // M1.k
    public final j b() {
        return this.f4612b;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return kotlin.jvm.internal.h.a(this.f4611a, qVar.f4611a) && kotlin.jvm.internal.h.a(this.f4612b, qVar.f4612b) && this.f4613c == qVar.f4613c && kotlin.jvm.internal.h.a(this.f4614d, qVar.f4614d) && kotlin.jvm.internal.h.a(this.f4615e, qVar.f4615e) && this.f4616f == qVar.f4616f && this.f4617g == qVar.f4617g;
    }

    public final int hashCode() {
        int iHashCode = (this.f4613c.hashCode() + ((this.f4612b.hashCode() + (this.f4611a.hashCode() * 31)) * 31)) * 31;
        K1.a aVar = this.f4614d;
        int iHashCode2 = (iHashCode + (aVar != null ? aVar.hashCode() : 0)) * 31;
        String str = this.f4615e;
        return ((((iHashCode2 + (str != null ? str.hashCode() : 0)) * 31) + (this.f4616f ? 1231 : 1237)) * 31) + (this.f4617g ? 1231 : 1237);
    }
}
