package M1;

/* JADX INFO: loaded from: classes.dex */
public final class l implements e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final l f4593b = new l(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4594a;

    public /* synthetic */ l(int i9) {
        this.f4594a = i9;
    }

    public String toString() {
        switch (this.f4594a) {
            case 0:
                return "coil.request.NullRequestData";
            default:
                return super.toString();
        }
    }
}
