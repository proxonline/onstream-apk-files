package M1;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final N1.g f4545a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final P1.d f4546b;

    public d(N1.g gVar, P1.d dVar) {
        this.f4545a = gVar;
        this.f4546b = dVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        dVar.getClass();
        return this.f4545a == dVar.f4545a && kotlin.jvm.internal.h.a(this.f4546b, dVar.f4546b);
    }

    public final int hashCode() {
        N1.g gVar = this.f4545a;
        int iHashCode = (gVar != null ? gVar.hashCode() : 0) * 28629151;
        P1.d dVar = this.f4546b;
        return (iHashCode + (dVar != null ? dVar.hashCode() : 0)) * 1742810335;
    }
}
