package M1;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.os.Build;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f4595a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Bitmap.Config f4596b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ColorSpace f4597c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final N1.h f4598d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final N1.g f4599e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f4600f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f4601g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f4602h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f4603i;
    public final L8.s j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final r f4604k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final o f4605l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final b f4606m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final b f4607n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final b f4608o;

    public n(Context context, Bitmap.Config config, ColorSpace colorSpace, N1.h hVar, N1.g gVar, boolean z9, boolean z10, boolean z11, String str, L8.s sVar, r rVar, o oVar, b bVar, b bVar2, b bVar3) {
        this.f4595a = context;
        this.f4596b = config;
        this.f4597c = colorSpace;
        this.f4598d = hVar;
        this.f4599e = gVar;
        this.f4600f = z9;
        this.f4601g = z10;
        this.f4602h = z11;
        this.f4603i = str;
        this.j = sVar;
        this.f4604k = rVar;
        this.f4605l = oVar;
        this.f4606m = bVar;
        this.f4607n = bVar2;
        this.f4608o = bVar3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n)) {
            return false;
        }
        n nVar = (n) obj;
        if (kotlin.jvm.internal.h.a(this.f4595a, nVar.f4595a) && this.f4596b == nVar.f4596b) {
            return (Build.VERSION.SDK_INT < 26 || kotlin.jvm.internal.h.a(this.f4597c, nVar.f4597c)) && kotlin.jvm.internal.h.a(this.f4598d, nVar.f4598d) && this.f4599e == nVar.f4599e && this.f4600f == nVar.f4600f && this.f4601g == nVar.f4601g && this.f4602h == nVar.f4602h && kotlin.jvm.internal.h.a(this.f4603i, nVar.f4603i) && kotlin.jvm.internal.h.a(this.j, nVar.j) && kotlin.jvm.internal.h.a(this.f4604k, nVar.f4604k) && kotlin.jvm.internal.h.a(this.f4605l, nVar.f4605l) && this.f4606m == nVar.f4606m && this.f4607n == nVar.f4607n && this.f4608o == nVar.f4608o;
        }
        return false;
    }

    public final int hashCode() {
        int iHashCode = (this.f4596b.hashCode() + (this.f4595a.hashCode() * 31)) * 31;
        ColorSpace colorSpace = this.f4597c;
        int iHashCode2 = (((((((this.f4599e.hashCode() + ((this.f4598d.hashCode() + ((iHashCode + (colorSpace != null ? colorSpace.hashCode() : 0)) * 31)) * 31)) * 31) + (this.f4600f ? 1231 : 1237)) * 31) + (this.f4601g ? 1231 : 1237)) * 31) + (this.f4602h ? 1231 : 1237)) * 31;
        String str = this.f4603i;
        return this.f4608o.hashCode() + ((this.f4607n.hashCode() + ((this.f4606m.hashCode() + ((this.f4605l.f4610a.hashCode() + ((this.f4604k.f4619a.hashCode() + ((((iHashCode2 + (str != null ? str.hashCode() : 0)) * 31) + Arrays.hashCode(this.j.f4435a)) * 31)) * 31)) * 31)) * 31)) * 31);
    }
}
