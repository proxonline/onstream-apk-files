package M1;

import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final r f4618b = new r(p048e8.r.f17245a);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Map f4619a;

    public r(Map map) {
        this.f4619a = map;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof r) {
            return kotlin.jvm.internal.h.a(this.f4619a, ((r) obj).f4619a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f4619a.hashCode();
    }

    public final String toString() {
        return "Tags(tags=" + this.f4619a + ')';
    }
}
