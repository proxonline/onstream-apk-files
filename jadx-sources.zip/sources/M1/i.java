package M1;

import B8.AbstractC0062w;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Bitmap;
import android.widget.ImageView;
import androidx.lifecycle.InterfaceC0552v;
import java.util.LinkedHashMap;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f4552a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public c f4553b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f4554c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public O1.b f4555d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final List f4556e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public P1.d f4557f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final L8.r f4558g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final LinkedHashMap f4559h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f4560i;
    public final boolean j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final p137o3.i f4561k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Integer f4562l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public N1.g f4563m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public D.o f4564n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public N1.i f4565o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public N1.g f4566p;

    public i(j jVar, Context context) {
        this.f4552a = context;
        this.f4553b = jVar.f4567A;
        this.f4554c = jVar.f4569b;
        this.f4555d = jVar.f4570c;
        d dVar = jVar.f4592z;
        this.f4556e = jVar.f4573f;
        this.f4557f = dVar.f4546b;
        this.f4558g = jVar.f4575h.k();
        this.f4559h = p048e8.u.T(jVar.f4576i.f4619a);
        this.f4560i = jVar.j;
        this.j = jVar.f4579m;
        this.f4561k = new p137o3.i(jVar.f4590x);
        this.f4562l = jVar.f4591y;
        this.f4563m = dVar.f4545a;
        if (jVar.f4568a == context) {
            this.f4564n = jVar.f4587u;
            this.f4565o = jVar.f4588v;
            this.f4566p = jVar.f4589w;
        } else {
            this.f4564n = null;
            this.f4565o = null;
            this.f4566p = null;
        }
    }

    public i(Context context) {
        this.f4552a = context;
        this.f4553b = Q1.d.f6343a;
        this.f4554c = null;
        this.f4555d = null;
        this.f4556e = p048e8.q.f17244a;
        this.f4557f = null;
        this.f4558g = null;
        this.f4559h = null;
        this.f4560i = true;
        this.j = true;
        this.f4561k = null;
        this.f4562l = null;
        this.f4563m = null;
        this.f4564n = null;
        this.f4565o = null;
        this.f4566p = null;
    }

    /* JADX WARN: Code duplicated, block: B:81:0x0114  */
    public final j a() {
        AbstractC0062w abstractC0062w;
        Object obj;
        Object obj2 = this.f4554c;
        if (obj2 == null) {
            obj2 = l.f4593b;
        }
        Object obj3 = obj2;
        O1.b bVar = this.f4555d;
        c cVar = this.f4553b;
        Bitmap.Config config = cVar.f4541g;
        N1.d dVar = cVar.f4540f;
        P1.d dVar2 = this.f4557f;
        if (dVar2 == null) {
            dVar2 = cVar.f4539e;
        }
        P1.d dVar3 = dVar2;
        L8.r rVar = this.f4558g;
        L8.s sVarE = rVar != null ? rVar.e() : null;
        if (sVarE == null) {
            sVarE = Q1.f.f6347c;
        } else {
            Bitmap.Config[] configArr = Q1.f.f6345a;
        }
        L8.s sVar = sVarE;
        LinkedHashMap linkedHashMap = this.f4559h;
        r rVar2 = linkedHashMap != null ? new r(p054f5.b.M(linkedHashMap)) : null;
        if (rVar2 == null) {
            rVar2 = r.f4618b;
        }
        r rVar3 = rVar2;
        this.f4553b.getClass();
        this.f4553b.getClass();
        c cVar2 = this.f4553b;
        b bVar2 = cVar2.f4543i;
        b bVar3 = cVar2.j;
        b bVar4 = cVar2.f4544k;
        AbstractC0062w abstractC0062w2 = cVar2.f4535a;
        AbstractC0062w abstractC0062w3 = cVar2.f4536b;
        AbstractC0062w abstractC0062w4 = cVar2.f4537c;
        AbstractC0062w abstractC0062w5 = cVar2.f4538d;
        D.o oVarC = this.f4564n;
        Context context = this.f4552a;
        if (oVarC == null) {
            O1.b bVar5 = this.f4555d;
            abstractC0062w = abstractC0062w5;
            Object context2 = bVar5 instanceof O1.a ? ((O1.a) bVar5).f5510b.getContext() : context;
            while (true) {
                if (context2 instanceof InterfaceC0552v) {
                    oVarC = ((InterfaceC0552v) context2).C();
                    break;
                }
                if (!(context2 instanceof ContextWrapper)) {
                    oVarC = null;
                    break;
                }
                context2 = ((ContextWrapper) context2).getBaseContext();
            }
            if (oVarC == null) {
                oVarC = h.f4550b;
            }
        } else {
            abstractC0062w = abstractC0062w5;
        }
        D.o oVar = oVarC;
        N1.i cVar3 = this.f4565o;
        if (cVar3 == null) {
            O1.b bVar6 = this.f4555d;
            if (bVar6 instanceof O1.a) {
                ImageView imageView = ((O1.a) bVar6).f5510b;
                if (imageView != null) {
                    ImageView.ScaleType scaleType = imageView.getScaleType();
                    obj = obj3;
                    if (scaleType == ImageView.ScaleType.CENTER || scaleType == ImageView.ScaleType.MATRIX) {
                        N1.h hVar = N1.h.f4874c;
                        cVar3 = new N1.e();
                    }
                } else {
                    obj = obj3;
                }
                cVar3 = new N1.f(imageView);
            } else {
                obj = obj3;
                cVar3 = new N1.c(context);
            }
        } else {
            obj = obj3;
        }
        N1.i iVar = cVar3;
        N1.g gVar = this.f4563m;
        if (gVar == null && (gVar = this.f4566p) == null) {
            O1.b bVar7 = this.f4555d;
            O1.a aVar = bVar7 instanceof O1.a ? (O1.a) bVar7 : null;
            ImageView imageView2 = aVar != null ? aVar.f5510b : null;
            boolean z9 = imageView2 instanceof ImageView;
            N1.g gVar2 = N1.g.f4872b;
            if (z9) {
                Bitmap.Config[] configArr2 = Q1.f.f6345a;
                ImageView.ScaleType scaleType2 = imageView2.getScaleType();
                int i9 = scaleType2 == null ? -1 : Q1.e.f6344a[scaleType2.ordinal()];
                if (i9 == 1 || i9 == 2 || i9 == 3 || i9 == 4) {
                    gVar = gVar2;
                } else {
                    gVar = N1.g.f4871a;
                }
            } else {
                gVar = gVar2;
            }
        }
        N1.g gVar3 = gVar;
        p137o3.i iVar2 = this.f4561k;
        o oVar2 = iVar2 != null ? new o(p054f5.b.M((LinkedHashMap) iVar2.f22104b)) : null;
        if (oVar2 == null) {
            oVar2 = o.f4609b;
        }
        return new j(context, obj, bVar, config, dVar, this.f4556e, dVar3, sVar, rVar3, this.f4560i, true, false, this.j, bVar2, bVar3, bVar4, abstractC0062w2, abstractC0062w3, abstractC0062w4, abstractC0062w, oVar, iVar, gVar3, oVar2, this.f4562l, new d(this.f4563m, this.f4557f), this.f4553b);
    }

    public final void b(ImageView imageView) {
        this.f4555d = new O1.a(imageView);
        this.f4564n = null;
        this.f4565o = null;
        this.f4566p = null;
    }
}
