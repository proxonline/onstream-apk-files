package M1;

import androidx.lifecycle.InterfaceC0552v;

/* JADX INFO: loaded from: classes.dex */
public final class g implements InterfaceC0552v {
    @Override // androidx.lifecycle.InterfaceC0552v
    public final D.o C() {
        return h.f4550b;
    }
}
