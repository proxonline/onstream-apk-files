package M1;

import B8.A;
import androidx.lifecycle.InterfaceC0551u;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class t extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ u f4625r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t(u uVar, h8.d dVar) {
        super(2, dVar);
        this.f4625r = uVar;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new t(this.f4625r, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        t tVar = (t) create((A) obj, (h8.d) obj2);
        p039d8.l lVar = p039d8.l.f16813a;
        tVar.invokeSuspend(lVar);
        return lVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        u0.F(obj);
        u uVar = this.f4625r;
        s sVar = uVar.f4629d;
        if (sVar != null) {
            D.o oVar = sVar.f4623d;
            sVar.f4624e.f(null);
            O1.a aVar = sVar.f4622c;
            if (aVar instanceof InterfaceC0551u) {
                oVar.k0(aVar);
            }
            oVar.k0(sVar);
        }
        uVar.f4629d = null;
        return p039d8.l.f16813a;
    }
}
