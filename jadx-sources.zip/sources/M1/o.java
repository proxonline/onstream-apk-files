package M1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class o implements Iterable, p176s8.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final o f4609b = new o(p048e8.r.f17245a);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Map f4610a;

    public o(Map map) {
        this.f4610a = map;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof o) {
            return kotlin.jvm.internal.h.a(this.f4610a, ((o) obj).f4610a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f4610a.hashCode();
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        Map map = this.f4610a;
        ArrayList arrayList = new ArrayList(map.size());
        for (Map.Entry entry : map.entrySet()) {
            String str = (String) entry.getKey();
            if (entry.getValue() != null) {
                throw new ClassCastException();
            }
            arrayList.add(new p039d8.g(str, null));
        }
        return arrayList.iterator();
    }

    public final String toString() {
        return "Parameters(entries=" + this.f4610a + ')';
    }
}
