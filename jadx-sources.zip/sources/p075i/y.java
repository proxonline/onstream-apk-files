package p075i;

import H0.E;
import I3.a;
import P.InterfaceC0318k;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import co.notix.R;
import p030d.l;
import p113m.j;

/* JADX INFO: loaded from: classes.dex */
public class y extends l implements InterfaceC0987i {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public w f19131d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final x f19132e;

    /* JADX WARN: Type inference failed for: r2v2, types: [i.x] */
    public y(Context context, int i9) {
        int i10;
        if (i9 == 0) {
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(R.attr.dialogTheme, typedValue, true);
            i10 = typedValue.resourceId;
        } else {
            i10 = i9;
        }
        super(context, i10);
        this.f19132e = new InterfaceC0318k() { // from class: i.x
            @Override // P.InterfaceC0318k
            public final boolean h(KeyEvent keyEvent) {
                return this.f19130a.f(keyEvent);
            }
        };
        l lVarE = e();
        if (i9 == 0) {
            TypedValue typedValue2 = new TypedValue();
            context.getTheme().resolveAttribute(R.attr.dialogTheme, typedValue2, true);
            i9 = typedValue2.resourceId;
        }
        ((w) lVarE).f19111q0 = i9;
        lVarE.d();
    }

    @Override // p030d.l, android.app.Dialog
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        c();
        w wVar = (w) e();
        wVar.v();
        ((ViewGroup) wVar.f19084B.findViewById(android.R.id.content)).addView(view, layoutParams);
        wVar.f19102m.a(wVar.f19100l.getCallback());
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public final void dismiss() {
        super.dismiss();
        e().e();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return a.q(this.f19132e, getWindow().getDecorView(), this, keyEvent);
    }

    public final l e() {
        if (this.f19131d == null) {
            E e9 = l.f19041a;
            this.f19131d = new w(getContext(), getWindow(), this, this);
        }
        return this.f19131d;
    }

    public final boolean f(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Dialog
    public final View findViewById(int i9) {
        w wVar = (w) e();
        wVar.v();
        return wVar.f19100l.findViewById(i9);
    }

    @Override // android.app.Dialog
    public final void invalidateOptionsMenu() {
        w wVar = (w) e();
        if (wVar.f19106o != null) {
            wVar.A();
            wVar.f19106o.getClass();
            wVar.B(0);
        }
    }

    @Override // p030d.l, android.app.Dialog
    public void onCreate(Bundle bundle) {
        e().a();
        super.onCreate(bundle);
        e().d();
    }

    @Override // p030d.l, android.app.Dialog
    public final void onStop() {
        super.onStop();
        w wVar = (w) e();
        wVar.A();
        I i9 = wVar.f19106o;
        if (i9 != null) {
            i9.f18987y = false;
            j jVar = i9.f18986x;
            if (jVar != null) {
                jVar.a();
            }
        }
    }

    @Override // p030d.l, android.app.Dialog
    public void setContentView(int i9) {
        c();
        e().i(i9);
    }

    @Override // p030d.l, android.app.Dialog
    public void setContentView(View view) {
        c();
        e().j(view);
    }

    @Override // p030d.l, android.app.Dialog
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        c();
        e().k(view, layoutParams);
    }

    @Override // android.app.Dialog
    public void setTitle(int i9) {
        super.setTitle(i9);
        e().l(getContext().getString(i9));
    }

    @Override // android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        e().l(charSequence);
    }
}
