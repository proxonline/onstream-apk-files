package p075i;

import P.C0307a0;
import P.G;
import P.S;
import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.PopupWindow;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ViewStubCompat;
import co.notix.R;
import com.google.android.material.appbar.h;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import p113m.a;
import p113m.c;
import p113m.d;
import p113m.l;
import p113m.m;
import p123n.k;
import p125n1.g;

/* JADX INFO: loaded from: classes.dex */
public final class s implements Window.Callback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Window.Callback f19055a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f19056b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f19057c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f19058d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ w f19059e;

    public s(w wVar, Window.Callback callback) {
        this.f19059e = wVar;
        if (callback == null) {
            throw new IllegalArgumentException("Window callback may not be null");
        }
        this.f19055a = callback;
    }

    public final void a(Window.Callback callback) {
        try {
            this.f19056b = true;
            callback.onContentChanged();
        } finally {
            this.f19056b = false;
        }
    }

    public final boolean b(int i9, Menu menu) {
        return this.f19055a.onMenuOpened(i9, menu);
    }

    public final void c(int i9, Menu menu) {
        this.f19055a.onPanelClosed(i9, menu);
    }

    public final void d(List list, Menu menu, int i9) {
        l.a(this.f19055a, list, menu, i9);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        return this.f19055a.dispatchGenericMotionEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean z9 = this.f19057c;
        Window.Callback callback = this.f19055a;
        if (z9) {
            return callback.dispatchKeyEvent(keyEvent);
        }
        return this.f19059e.t(keyEvent) || callback.dispatchKeyEvent(keyEvent);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x003b  */
    /* JADX WARN: Code duplicated, block: B:18:0x003d  */
    /* JADX WARN: Code duplicated, block: B:25:0x0052  */
    /* JADX WARN: Code duplicated, block: B:27:0x0056  */
    @Override // android.view.Window.Callback
    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        v vVar;
        boolean z9;
        boolean zF;
        k kVar;
        boolean zPerformShortcut;
        if (!this.f19055a.dispatchKeyShortcutEvent(keyEvent)) {
            int keyCode = keyEvent.getKeyCode();
            w wVar = this.f19059e;
            wVar.A();
            I i9 = wVar.f19106o;
            if (i9 == null) {
                vVar = wVar.f19097j0;
                if (vVar == null && wVar.F(vVar, keyEvent.getKeyCode(), keyEvent)) {
                    v vVar2 = wVar.f19097j0;
                    if (vVar2 != null) {
                        vVar2.f19074l = true;
                    }
                } else {
                    if (wVar.f19097j0 == null) {
                        v vVarZ = wVar.z(0);
                        wVar.G(vVarZ, keyEvent);
                        zF = wVar.F(vVarZ, keyEvent.getKeyCode(), keyEvent);
                        vVarZ.f19073k = false;
                        if (zF) {
                        }
                    }
                    z9 = false;
                }
                z9 = true;
            } else {
                H h6 = i9.f18976n;
                if (h6 == null || (kVar = h6.f18960d) == null) {
                    zPerformShortcut = false;
                } else {
                    kVar.setQwertyMode(KeyCharacterMap.load(keyEvent.getDeviceId()).getKeyboardType() != 1);
                    zPerformShortcut = kVar.performShortcut(keyCode, keyEvent, 0);
                }
                if (zPerformShortcut) {
                    z9 = true;
                } else {
                    vVar = wVar.f19097j0;
                    if (vVar == null) {
                        if (wVar.f19097j0 == null) {
                            v vVarZ2 = wVar.z(0);
                            wVar.G(vVarZ2, keyEvent);
                            zF = wVar.F(vVarZ2, keyEvent.getKeyCode(), keyEvent);
                            vVarZ2.f19073k = false;
                            if (zF) {
                                z9 = true;
                            }
                        }
                        z9 = false;
                    } else {
                        if (wVar.f19097j0 == null) {
                            v vVarZ3 = wVar.z(0);
                            wVar.G(vVarZ3, keyEvent);
                            zF = wVar.F(vVarZ3, keyEvent.getKeyCode(), keyEvent);
                            vVarZ3.f19073k = false;
                            if (zF) {
                                z9 = true;
                            }
                        }
                        z9 = false;
                    }
                }
            }
            if (!z9) {
                return false;
            }
        }
        return true;
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return this.f19055a.dispatchPopulateAccessibilityEvent(accessibilityEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        return this.f19055a.dispatchTouchEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchTrackballEvent(MotionEvent motionEvent) {
        return this.f19055a.dispatchTrackballEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final void onActionModeFinished(ActionMode actionMode) {
        this.f19055a.onActionModeFinished(actionMode);
    }

    @Override // android.view.Window.Callback
    public final void onActionModeStarted(ActionMode actionMode) {
        this.f19055a.onActionModeStarted(actionMode);
    }

    @Override // android.view.Window.Callback
    public final void onAttachedToWindow() {
        this.f19055a.onAttachedToWindow();
    }

    @Override // android.view.Window.Callback
    public final void onContentChanged() {
        if (this.f19056b) {
            this.f19055a.onContentChanged();
        }
    }

    @Override // android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i9, Menu menu) {
        if (i9 != 0 || (menu instanceof k)) {
            return this.f19055a.onCreatePanelMenu(i9, menu);
        }
        return false;
    }

    @Override // android.view.Window.Callback
    public final View onCreatePanelView(int i9) {
        return this.f19055a.onCreatePanelView(i9);
    }

    @Override // android.view.Window.Callback
    public final void onDetachedFromWindow() {
        this.f19055a.onDetachedFromWindow();
    }

    @Override // android.view.Window.Callback
    public final boolean onMenuItemSelected(int i9, MenuItem menuItem) {
        return this.f19055a.onMenuItemSelected(i9, menuItem);
    }

    @Override // android.view.Window.Callback
    public final boolean onMenuOpened(int i9, Menu menu) {
        b(i9, menu);
        if (i9 == 108) {
            w wVar = this.f19059e;
            wVar.A();
            I i10 = wVar.f19106o;
            if (i10 != null) {
                ArrayList arrayList = i10.f18980r;
                if (true != i10.f18979q) {
                    i10.f18979q = true;
                    if (arrayList.size() > 0) {
                        arrayList.get(0).getClass();
                        throw new ClassCastException();
                    }
                }
            }
        }
        return true;
    }

    @Override // android.view.Window.Callback
    public final void onPanelClosed(int i9, Menu menu) {
        if (this.f19058d) {
            this.f19055a.onPanelClosed(i9, menu);
            return;
        }
        c(i9, menu);
        w wVar = this.f19059e;
        if (i9 != 108) {
            if (i9 == 0) {
                v vVarZ = wVar.z(i9);
                if (vVarZ.f19075m) {
                    wVar.r(vVarZ, false);
                    return;
                }
                return;
            }
            return;
        }
        wVar.A();
        I i10 = wVar.f19106o;
        if (i10 != null) {
            ArrayList arrayList = i10.f18980r;
            if (i10.f18979q) {
                i10.f18979q = false;
                if (arrayList.size() <= 0) {
                    return;
                }
                arrayList.get(0).getClass();
                throw new ClassCastException();
            }
        }
    }

    @Override // android.view.Window.Callback
    public final void onPointerCaptureChanged(boolean z9) {
        m.a(this.f19055a, z9);
    }

    @Override // android.view.Window.Callback
    public final boolean onPreparePanel(int i9, View view, Menu menu) {
        k kVar = menu instanceof k ? (k) menu : null;
        if (i9 == 0 && kVar == null) {
            return false;
        }
        if (kVar != null) {
            kVar.f21506x = true;
        }
        boolean zOnPreparePanel = this.f19055a.onPreparePanel(i9, view, menu);
        if (kVar != null) {
            kVar.f21506x = false;
        }
        return zOnPreparePanel;
    }

    @Override // android.view.Window.Callback
    public final void onProvideKeyboardShortcuts(List list, Menu menu, int i9) {
        k kVar = this.f19059e.z(0).f19071h;
        if (kVar != null) {
            d(list, kVar, i9);
        } else {
            d(list, menu, i9);
        }
    }

    @Override // android.view.Window.Callback
    public final boolean onSearchRequested() {
        return this.f19055a.onSearchRequested();
    }

    @Override // android.view.Window.Callback
    public final boolean onSearchRequested(SearchEvent searchEvent) {
        return p113m.k.a(this.f19055a, searchEvent);
    }

    @Override // android.view.Window.Callback
    public final void onWindowAttributesChanged(WindowManager.LayoutParams layoutParams) {
        this.f19055a.onWindowAttributesChanged(layoutParams);
    }

    @Override // android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z9) {
        this.f19055a.onWindowFocusChanged(z9);
    }

    @Override // android.view.Window.Callback
    public final ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.Window.Callback
    public final ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i9) {
        ViewGroup viewGroup;
        w wVar = this.f19059e;
        if (!wVar.f19128z || i9 != 0) {
            return p113m.k.b(this.f19055a, callback, i9);
        }
        Context context = wVar.f19098k;
        g gVar = new g(context, callback);
        a aVar = wVar.f19118u;
        if (aVar != null) {
            aVar.a();
        }
        h hVar = new h(wVar, gVar, 8, false);
        wVar.A();
        I i10 = wVar.f19106o;
        int i11 = 1;
        if (i10 != null) {
            H h6 = i10.f18976n;
            if (h6 != null) {
                h6.a();
            }
            i10.f18971h.setHideOnContentScrollEnabled(false);
            i10.f18973k.e();
            H h9 = new H(i10, i10.f18973k.getContext(), hVar);
            k kVar = h9.f18960d;
            kVar.w();
            try {
                boolean zQ = ((g) h9.f18961e.f15039b).q(h9, kVar);
                kVar.v();
                if (zQ) {
                    i10.f18976n = h9;
                    h9.i();
                    i10.f18973k.c(h9);
                    i10.W(true);
                } else {
                    h9 = null;
                }
                wVar.f19118u = h9;
            } catch (Throwable th) {
                kVar.v();
                throw th;
            }
        }
        if (wVar.f19118u == null) {
            C0307a0 c0307a0 = wVar.f19126y;
            if (c0307a0 != null) {
                c0307a0.b();
            }
            a aVar2 = wVar.f19118u;
            if (aVar2 != null) {
                aVar2.a();
            }
            if (wVar.f19120v == null) {
                if (wVar.f19093f0) {
                    TypedValue typedValue = new TypedValue();
                    Resources.Theme theme = context.getTheme();
                    theme.resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                    if (typedValue.resourceId != 0) {
                        Resources.Theme themeNewTheme = context.getResources().newTheme();
                        themeNewTheme.setTo(theme);
                        themeNewTheme.applyStyle(typedValue.resourceId, true);
                        c cVar = new c(context, 0);
                        cVar.getTheme().setTo(themeNewTheme);
                        context = cVar;
                    }
                    wVar.f19120v = new ActionBarContextView(context, null);
                    PopupWindow popupWindow = new PopupWindow(context, (AttributeSet) null, R.attr.actionModePopupWindowStyle);
                    wVar.f19122w = popupWindow;
                    popupWindow.setWindowLayoutType(2);
                    wVar.f19122w.setContentView(wVar.f19120v);
                    wVar.f19122w.setWidth(-1);
                    context.getTheme().resolveAttribute(R.attr.actionBarSize, typedValue, true);
                    wVar.f19120v.setContentHeight(TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics()));
                    wVar.f19122w.setHeight(-2);
                    wVar.f19124x = new m(wVar, i11);
                } else {
                    ViewStubCompat viewStubCompat = (ViewStubCompat) wVar.f19084B.findViewById(R.id.action_mode_bar_stub);
                    if (viewStubCompat != null) {
                        wVar.A();
                        I i12 = wVar.f19106o;
                        Context contextX = i12 != null ? i12.X() : null;
                        if (contextX != null) {
                            context = contextX;
                        }
                        viewStubCompat.setLayoutInflater(LayoutInflater.from(context));
                        wVar.f19120v = (ActionBarContextView) viewStubCompat.a();
                    }
                }
            }
            if (wVar.f19120v != null) {
                C0307a0 c0307a1 = wVar.f19126y;
                if (c0307a1 != null) {
                    c0307a1.b();
                }
                wVar.f19120v.e();
                Context context2 = wVar.f19120v.getContext();
                ActionBarContextView actionBarContextView = wVar.f19120v;
                d dVar = new d();
                dVar.f21164c = context2;
                dVar.f21165d = actionBarContextView;
                dVar.f21166e = hVar;
                k kVar2 = new k(actionBarContextView.getContext());
                kVar2.f21494l = 1;
                dVar.f21169h = kVar2;
                kVar2.f21488e = dVar;
                if (((g) hVar.f15039b).q(dVar, kVar2)) {
                    dVar.i();
                    wVar.f19120v.c(dVar);
                    wVar.f19118u = dVar;
                    if (wVar.f19082A && (viewGroup = wVar.f19084B) != null && viewGroup.isLaidOut()) {
                        wVar.f19120v.setAlpha(0.0f);
                        C0307a0 c0307a0A = S.a(wVar.f19120v);
                        c0307a0A.a(1.0f);
                        wVar.f19126y = c0307a0A;
                        c0307a0A.d(new o(i11, wVar));
                    } else {
                        wVar.f19120v.setAlpha(1.0f);
                        wVar.f19120v.setVisibility(0);
                        if (wVar.f19120v.getParent() instanceof View) {
                            View view = (View) wVar.f19120v.getParent();
                            WeakHashMap weakHashMap = S.f5835a;
                            G.c(view);
                        }
                    }
                    if (wVar.f19122w != null) {
                        wVar.f19100l.getDecorView().post(wVar.f19124x);
                    }
                } else {
                    wVar.f19118u = null;
                }
            }
            wVar.I();
            wVar.f19118u = wVar.f19118u;
        }
        wVar.I();
        a aVar3 = wVar.f19118u;
        if (aVar3 != null) {
            return gVar.k(aVar3);
        }
        return null;
    }
}
