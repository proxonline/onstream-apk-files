package p075i;

import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: renamed from: i.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0979a implements AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0983e f18989a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0980b f18990b;

    public C0979a(C0980b c0980b, C0983e c0983e) {
        this.f18990b = c0980b;
        this.f18989a = c0983e;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i9, long j) {
        C0980b c0980b = this.f18990b;
        DialogInterface.OnClickListener onClickListener = c0980b.f19001l;
        C0983e c0983e = this.f18989a;
        onClickListener.onClick(c0983e.f19013b, i9);
        if (c0980b.f19003n) {
            return;
        }
        c0983e.f19013b.dismiss();
    }
}
