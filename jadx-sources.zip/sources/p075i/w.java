package p075i;

import D.RunnableC0078a;
import D.d;
import L.f;
import P.C0307a0;
import P.D;
import P.I;
import P.InterfaceC0318k;
import P.S;
import a9.C0501u;
import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.EnumC0546o;
import androidx.lifecycle.InterfaceC0552v;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.WeakHashMap;
import p054f5.b;
import p113m.a;
import p113m.c;
import p113m.h;
import p123n.g;
import p123n.i;
import p123n.k;
import p123n.m;
import p133o.B;
import p133o.C1212b0;
import p133o.C1221g;
import p133o.C1231l;
import p133o.C1246t;
import p133o.C1252w;
import p133o.InterfaceC1216d0;
import p133o.InterfaceC1218e0;
import p133o.P0;
import p133o.U0;
import p133o.Z0;
import p133o.c1;
import p133o.r;

/* JADX INFO: loaded from: classes.dex */
public final class w extends l implements i, LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: E0, reason: collision with root package name */
    public static final p158r.i f19079E0 = new p158r.i(0);

    /* JADX INFO: renamed from: F0, reason: collision with root package name */
    public static final int[] f19080F0 = {R.attr.windowBackground};

    /* JADX INFO: renamed from: G0, reason: collision with root package name */
    public static final boolean f19081G0 = !"robolectric".equals(Build.FINGERPRINT);

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f19082A;

    /* JADX INFO: renamed from: A0, reason: collision with root package name */
    public Rect f19083A0;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public ViewGroup f19084B;

    /* JADX INFO: renamed from: B0, reason: collision with root package name */
    public B f19085B0;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public TextView f19086C;

    /* JADX INFO: renamed from: C0, reason: collision with root package name */
    public OnBackInvokedDispatcher f19087C0;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public View f19088D;

    /* JADX INFO: renamed from: D0, reason: collision with root package name */
    public OnBackInvokedCallback f19089D0;
    public boolean X;

    /* JADX INFO: renamed from: Y, reason: collision with root package name */
    public boolean f19090Y;
    public boolean Z;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public boolean f19091d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public boolean f19092e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public boolean f19093f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public boolean f19094g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public boolean f19095h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public v[] f19096i0;
    public final Object j;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public v f19097j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Context f19098k;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public boolean f19099k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Window f19100l;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public boolean f19101l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public s f19102m;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public boolean f19103m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Object f19104n;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public boolean f19105n0;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public I f19106o;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public Configuration f19107o0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public h f19108p;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public final int f19109p0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public CharSequence f19110q;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public int f19111q0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public InterfaceC1216d0 f19112r;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public int f19113r0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public C0501u f19114s;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public boolean f19115s0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public n f19116t;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public t f19117t0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public a f19118u;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public t f19119u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public ActionBarContextView f19120v;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public boolean f19121v0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public PopupWindow f19122w;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public int f19123w0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public m f19124x;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public boolean f19127y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public Rect f19129z0;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public C0307a0 f19126y = null;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final boolean f19128z = true;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public final m f19125x0 = new m(this, 0);

    public w(Context context, Window window, InterfaceC0987i interfaceC0987i, Object obj) {
        AbstractActivityC0986h abstractActivityC0986h = null;
        this.f19109p0 = -100;
        this.f19098k = context;
        this.f19104n = interfaceC0987i;
        this.j = obj;
        if (obj instanceof Dialog) {
            while (context != null) {
                if (!(context instanceof AbstractActivityC0986h)) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                } else {
                    abstractActivityC0986h = (AbstractActivityC0986h) context;
                    break;
                }
            }
            if (abstractActivityC0986h != null) {
                this.f19109p0 = ((w) abstractActivityC0986h.T()).f19109p0;
            }
        }
        if (this.f19109p0 == -100) {
            String name = this.j.getClass().getName();
            p158r.i iVar = f19079E0;
            Integer num = (Integer) iVar.get(name);
            if (num != null) {
                this.f19109p0 = num.intValue();
                iVar.remove(this.j.getClass().getName());
            }
        }
        if (window != null) {
            n(window);
        }
        C1246t.d();
    }

    public static f o(Context context) {
        f fVar;
        f fVarB;
        int i9 = Build.VERSION.SDK_INT;
        if (i9 >= 33 || (fVar = l.f19043c) == null) {
            return null;
        }
        L.h hVar = fVar.f3871a;
        f fVarY = y(context.getApplicationContext().getResources().getConfiguration());
        int i10 = 0;
        if (i9 < 24) {
            fVarB = hVar.isEmpty() ? f.f3870b : f.b(p.b(hVar.get(0)));
        } else if (hVar.isEmpty()) {
            fVarB = f.f3870b;
        } else {
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            while (i10 < fVarY.f3871a.size() + hVar.size()) {
                Locale locale = i10 < hVar.size() ? hVar.get(i10) : fVarY.f3871a.get(i10 - hVar.size());
                if (locale != null) {
                    linkedHashSet.add(locale);
                }
                i10++;
            }
            fVarB = f.a((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()]));
        }
        return fVarB.f3871a.isEmpty() ? fVarY : fVarB;
    }

    public static Configuration s(Context context, int i9, f fVar, Configuration configuration, boolean z9) {
        int i10;
        if (i9 == 1) {
            i10 = 16;
        } else if (i9 != 2) {
            i10 = z9 ? 0 : context.getApplicationContext().getResources().getConfiguration().uiMode & 48;
        } else {
            i10 = 32;
        }
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i10 | (configuration2.uiMode & (-49));
        if (fVar != null) {
            L.h hVar = fVar.f3871a;
            if (Build.VERSION.SDK_INT >= 24) {
                q.d(configuration2, fVar);
                return configuration2;
            }
            configuration2.setLocale(hVar.get(0));
            configuration2.setLayoutDirection(hVar.get(0));
        }
        return configuration2;
    }

    public static f y(Configuration configuration) {
        return Build.VERSION.SDK_INT >= 24 ? q.b(configuration) : f.b(p.b(configuration.locale));
    }

    public final void A() {
        v();
        if (this.Z && this.f19106o == null) {
            Object obj = this.j;
            if (obj instanceof Activity) {
                this.f19106o = new I((Activity) obj, this.f19091d0);
            } else if (obj instanceof Dialog) {
                this.f19106o = new I((Dialog) obj);
            }
            I i9 = this.f19106o;
            if (i9 != null) {
                i9.Z(this.f19127y0);
            }
        }
    }

    public final void B(int i9) {
        this.f19123w0 = (1 << i9) | this.f19123w0;
        if (this.f19121v0) {
            return;
        }
        View decorView = this.f19100l.getDecorView();
        WeakHashMap weakHashMap = S.f5835a;
        decorView.postOnAnimation(this.f19125x0);
        this.f19121v0 = true;
    }

    public final int C(Context context, int i9) {
        if (i9 != -100) {
            if (i9 != -1) {
                if (i9 != 0) {
                    if (i9 != 1 && i9 != 2) {
                        if (i9 != 3) {
                            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                        }
                        if (this.f19119u0 == null) {
                            this.f19119u0 = new t(this, context);
                        }
                        return this.f19119u0.h();
                    }
                } else if (((UiModeManager) context.getApplicationContext().getSystemService("uimode")).getNightMode() != 0) {
                    return x(context).h();
                }
            }
            return i9;
        }
        return -1;
    }

    public final boolean D() {
        InterfaceC1218e0 interfaceC1218e0;
        P0 p8;
        boolean z9 = this.f19099k0;
        this.f19099k0 = false;
        v vVarZ = z(0);
        if (!vVarZ.f19075m) {
            a aVar = this.f19118u;
            if (aVar != null) {
                aVar.a();
                return true;
            }
            A();
            I i9 = this.f19106o;
            if (i9 == null || (interfaceC1218e0 = i9.j) == null || (p8 = ((U0) interfaceC1218e0).f21830a.f10410k0) == null || p8.f21809b == null) {
                return false;
            }
            P0 p9 = ((U0) interfaceC1218e0).f21830a.f10410k0;
            m mVar = p9 == null ? null : p9.f21809b;
            if (mVar != null) {
                mVar.collapseActionView();
            }
        } else if (!z9) {
            r(vVarZ, true);
            return true;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x01d2  */
    /* JADX WARN: Code duplicated, block: B:105:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x0175, code lost:
    
        if (r2.f21476f.getCount() > 0) goto L88;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void E(p075i.v r18, android.view.KeyEvent r19) {
        /*
            Method dump skipped, instruction units count: 473
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: p075i.w.E(i.v, android.view.KeyEvent):void");
    }

    public final boolean F(v vVar, int i9, KeyEvent keyEvent) {
        k kVar;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((vVar.f19073k || G(vVar, keyEvent)) && (kVar = vVar.f19071h) != null) {
            return kVar.performShortcut(i9, keyEvent, 1);
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:59:0x00d0  */
    /* JADX WARN: Code duplicated, block: B:64:0x00da  */
    /* JADX WARN: Code duplicated, block: B:68:0x00f9  */
    /* JADX WARN: Code duplicated, block: B:71:0x00fe A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:72:0x0100  */
    /* JADX WARN: Code duplicated, block: B:79:0x0115  */
    public final boolean G(v vVar, KeyEvent keyEvent) {
        k kVar;
        InterfaceC1216d0 interfaceC1216d0;
        InterfaceC1216d0 interfaceC1216d1;
        Resources.Theme themeNewTheme;
        InterfaceC1216d0 interfaceC1216d2;
        InterfaceC1216d0 interfaceC1216d3;
        if (!this.f19105n0) {
            boolean z9 = vVar.f19073k;
            int i9 = vVar.f19064a;
            if (z9) {
                return true;
            }
            v vVar2 = this.f19097j0;
            if (vVar2 != null && vVar2 != vVar) {
                r(vVar2, false);
            }
            Window.Callback callback = this.f19100l.getCallback();
            if (callback != null) {
                vVar.f19070g = callback.onCreatePanelView(i9);
            }
            boolean z10 = i9 == 0 || i9 == 108;
            if (z10 && (interfaceC1216d3 = this.f19112r) != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC1216d3;
                actionBarOverlayLayout.k();
                ((U0) actionBarOverlayLayout.f10296e).f21840l = true;
            }
            if (vVar.f19070g == null) {
                k kVar2 = vVar.f19071h;
                if (kVar2 == null || vVar.f19077o) {
                    if (kVar2 == null) {
                        Context context = this.f19098k;
                        if ((i9 == 0 || i9 == 108) && this.f19112r != null) {
                            TypedValue typedValue = new TypedValue();
                            Resources.Theme theme = context.getTheme();
                            theme.resolveAttribute(co.notix.R.attr.actionBarTheme, typedValue, true);
                            if (typedValue.resourceId != 0) {
                                themeNewTheme = context.getResources().newTheme();
                                themeNewTheme.setTo(theme);
                                themeNewTheme.applyStyle(typedValue.resourceId, true);
                                themeNewTheme.resolveAttribute(co.notix.R.attr.actionBarWidgetTheme, typedValue, true);
                            } else {
                                theme.resolveAttribute(co.notix.R.attr.actionBarWidgetTheme, typedValue, true);
                                themeNewTheme = null;
                            }
                            if (typedValue.resourceId != 0) {
                                if (themeNewTheme == null) {
                                    themeNewTheme = context.getResources().newTheme();
                                    themeNewTheme.setTo(theme);
                                }
                                themeNewTheme.applyStyle(typedValue.resourceId, true);
                            }
                            if (themeNewTheme != null) {
                                c cVar = new c(context, 0);
                                cVar.getTheme().setTo(themeNewTheme);
                                context = cVar;
                            }
                        }
                        k kVar3 = new k(context);
                        kVar3.f21488e = this;
                        k kVar4 = vVar.f19071h;
                        if (kVar3 != kVar4) {
                            if (kVar4 != null) {
                                kVar4.r(vVar.f19072i);
                            }
                            vVar.f19071h = kVar3;
                            g gVar = vVar.f19072i;
                            if (gVar != null) {
                                kVar3.b(gVar, kVar3.f21484a);
                            }
                        }
                        if (vVar.f19071h != null) {
                            if (z10 && (interfaceC1216d1 = this.f19112r) != null) {
                                if (this.f19114s == null) {
                                    this.f19114s = new C0501u(15, this);
                                }
                                ((ActionBarOverlayLayout) interfaceC1216d1).l(vVar.f19071h, this.f19114s);
                            }
                            vVar.f19071h.w();
                            if (callback.onCreatePanelMenu(i9, vVar.f19071h)) {
                                vVar.f19077o = false;
                            } else {
                                kVar = vVar.f19071h;
                                if (kVar != null) {
                                    if (kVar != null) {
                                        kVar.r(vVar.f19072i);
                                    }
                                    vVar.f19071h = null;
                                }
                                if (z10 && (interfaceC1216d0 = this.f19112r) != null) {
                                    ((ActionBarOverlayLayout) interfaceC1216d0).l(null, this.f19114s);
                                }
                            }
                        }
                    } else {
                        if (z10) {
                            if (this.f19114s == null) {
                                this.f19114s = new C0501u(15, this);
                            }
                            ((ActionBarOverlayLayout) interfaceC1216d1).l(vVar.f19071h, this.f19114s);
                        }
                        vVar.f19071h.w();
                        if (callback.onCreatePanelMenu(i9, vVar.f19071h)) {
                            kVar = vVar.f19071h;
                            if (kVar != null) {
                                if (kVar != null) {
                                    kVar.r(vVar.f19072i);
                                }
                                vVar.f19071h = null;
                            }
                            if (z10) {
                                ((ActionBarOverlayLayout) interfaceC1216d0).l(null, this.f19114s);
                            }
                        } else {
                            vVar.f19077o = false;
                        }
                    }
                }
                vVar.f19071h.w();
                Bundle bundle = vVar.f19078p;
                if (bundle != null) {
                    vVar.f19071h.s(bundle);
                    vVar.f19078p = null;
                }
                if (!callback.onPreparePanel(0, vVar.f19070g, vVar.f19071h)) {
                    if (z10 && (interfaceC1216d2 = this.f19112r) != null) {
                        ((ActionBarOverlayLayout) interfaceC1216d2).l(null, this.f19114s);
                    }
                    vVar.f19071h.v();
                    return false;
                }
                vVar.f19071h.setQwertyMode(KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1);
                vVar.f19071h.v();
            }
            vVar.f19073k = true;
            vVar.f19074l = false;
            this.f19097j0 = vVar;
            return true;
        }
        return false;
    }

    public final void H() {
        if (this.f19082A) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    public final void I() {
        OnBackInvokedCallback onBackInvokedCallback;
        if (Build.VERSION.SDK_INT >= 33) {
            boolean z9 = false;
            if (this.f19087C0 != null && (z(0).f19075m || this.f19118u != null)) {
                z9 = true;
            }
            if (z9 && this.f19089D0 == null) {
                this.f19089D0 = r.b(this.f19087C0, this);
            } else {
                if (z9 || (onBackInvokedCallback = this.f19089D0) == null) {
                    return;
                }
                r.c(this.f19087C0, onBackInvokedCallback);
                this.f19089D0 = null;
            }
        }
    }

    @Override // p075i.l
    public final void a() {
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(this.f19098k);
        if (layoutInflaterFrom.getFactory() == null) {
            layoutInflaterFrom.setFactory2(this);
        } else {
            if (layoutInflaterFrom.getFactory2() instanceof w) {
                return;
            }
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    /* JADX WARN: Code duplicated, block: B:20:0x002a  */
    @Override // p123n.i
    public final boolean c(k kVar, MenuItem menuItem) {
        v vVar;
        Window.Callback callback = this.f19100l.getCallback();
        if (callback != null && !this.f19105n0) {
            k kVarK = kVar.k();
            v[] vVarArr = this.f19096i0;
            int length = vVarArr != null ? vVarArr.length : 0;
            for (int i9 = 0; i9 < length; i9++) {
                vVar = vVarArr[i9];
                if (vVar != null && vVar.f19071h == kVarK) {
                    if (vVar != null) {
                        return callback.onMenuItemSelected(vVar.f19064a, menuItem);
                    }
                }
            }
            vVar = null;
            if (vVar != null) {
                return callback.onMenuItemSelected(vVar.f19064a, menuItem);
            }
        }
        return false;
    }

    @Override // p075i.l
    public final void d() {
        String strC;
        this.f19101l0 = true;
        m(false, true);
        w();
        Object obj = this.j;
        if (obj instanceof Activity) {
            try {
                Activity activity = (Activity) obj;
                try {
                    strC = d.c(activity, activity.getComponentName());
                } catch (PackageManager.NameNotFoundException e9) {
                    throw new IllegalArgumentException(e9);
                }
            } catch (IllegalArgumentException unused) {
                strC = null;
            }
            if (strC != null) {
                I i9 = this.f19106o;
                if (i9 == null) {
                    this.f19127y0 = true;
                } else {
                    i9.Z(true);
                }
            }
            synchronized (l.f19048h) {
                l.f(this);
                l.f19047g.add(new WeakReference(this));
            }
        }
        this.f19107o0 = new Configuration(this.f19098k.getResources().getConfiguration());
        this.f19103m0 = true;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x004d  */
    @Override // p075i.l
    public final void e() {
        if (this.j instanceof Activity) {
            synchronized (l.f19048h) {
                l.f(this);
            }
        }
        if (this.f19121v0) {
            this.f19100l.getDecorView().removeCallbacks(this.f19125x0);
        }
        this.f19105n0 = true;
        if (this.f19109p0 != -100) {
            Object obj = this.j;
            if ((obj instanceof Activity) && ((Activity) obj).isChangingConfigurations()) {
                f19079E0.put(this.j.getClass().getName(), Integer.valueOf(this.f19109p0));
            } else {
                f19079E0.remove(this.j.getClass().getName());
            }
        } else {
            f19079E0.remove(this.j.getClass().getName());
        }
        t tVar = this.f19117t0;
        if (tVar != null) {
            tVar.d();
        }
        t tVar2 = this.f19119u0;
        if (tVar2 != null) {
            tVar2.d();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0048, code lost:
    
        if (r6.f() != false) goto L20;
     */
    @Override // p123n.i
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void g(p123n.k r6) {
        /*
            Method dump skipped, instruction units count: 241
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: p075i.w.g(n.k):void");
    }

    @Override // p075i.l
    public final boolean h(int i9) {
        if (i9 == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            i9 = 108;
        } else if (i9 == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i9 = 109;
        }
        if (this.f19094g0 && i9 == 108) {
            return false;
        }
        if (this.Z && i9 == 1) {
            this.Z = false;
        }
        if (i9 == 1) {
            H();
            this.f19094g0 = true;
            return true;
        }
        if (i9 == 2) {
            H();
            this.X = true;
            return true;
        }
        if (i9 == 5) {
            H();
            this.f19090Y = true;
            return true;
        }
        if (i9 == 10) {
            H();
            this.f19092e0 = true;
            return true;
        }
        if (i9 == 108) {
            H();
            this.Z = true;
            return true;
        }
        if (i9 != 109) {
            return this.f19100l.requestFeature(i9);
        }
        H();
        this.f19091d0 = true;
        return true;
    }

    @Override // p075i.l
    public final void i(int i9) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.f19084B.findViewById(R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f19098k).inflate(i9, viewGroup);
        this.f19102m.a(this.f19100l.getCallback());
    }

    @Override // p075i.l
    public final void j(View view) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.f19084B.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f19102m.a(this.f19100l.getCallback());
    }

    @Override // p075i.l
    public final void k(View view, ViewGroup.LayoutParams layoutParams) {
        v();
        ViewGroup viewGroup = (ViewGroup) this.f19084B.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f19102m.a(this.f19100l.getCallback());
    }

    @Override // p075i.l
    public final void l(CharSequence charSequence) {
        this.f19110q = charSequence;
        InterfaceC1216d0 interfaceC1216d0 = this.f19112r;
        if (interfaceC1216d0 != null) {
            interfaceC1216d0.setWindowTitle(charSequence);
            return;
        }
        I i9 = this.f19106o;
        if (i9 == null) {
            TextView textView = this.f19086C;
            if (textView != null) {
                textView.setText(charSequence);
                return;
            }
            return;
        }
        U0 u1 = (U0) i9.j;
        if (u1.f21836g) {
            return;
        }
        Toolbar toolbar = u1.f21830a;
        u1.f21837h = charSequence;
        if ((u1.f21831b & 8) != 0) {
            toolbar.setTitle(charSequence);
            if (u1.f21836g) {
                S.n(toolbar.getRootView(), charSequence);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:72:0x0100  */
    /* JADX WARN: Multi-variable type inference failed */
    public final boolean m(boolean z9, boolean z10) {
        int i9;
        boolean z11;
        boolean z12;
        boolean z13;
        Object obj;
        int i10;
        if (this.f19105n0) {
            return false;
        }
        int i11 = this.f19109p0;
        if (i11 == -100) {
            i11 = l.f19042b;
        }
        Context context = this.f19098k;
        int iC = C(context, i11);
        int i12 = Build.VERSION.SDK_INT;
        Object obj2 = null;
        f fVarO = i12 < 33 ? o(context) : null;
        if (!z10 && fVarO != null) {
            fVarO = y(context.getResources().getConfiguration());
        }
        Configuration configurationS = s(context, iC, fVarO, null, false);
        boolean z14 = this.f19115s0;
        Object obj3 = this.j;
        if (z14 || !(obj3 instanceof Activity)) {
            this.f19115s0 = true;
            i9 = this.f19113r0;
        } else {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                i9 = 0;
            } else {
                if (i12 >= 29) {
                    i10 = 269221888;
                } else {
                    i10 = i12 >= 24 ? 786432 : 0;
                }
                try {
                    ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(context, obj3.getClass()), i10);
                    if (activityInfo != null) {
                        this.f19113r0 = activityInfo.configChanges;
                    }
                } catch (PackageManager.NameNotFoundException e9) {
                    Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e9);
                    this.f19113r0 = 0;
                }
                this.f19115s0 = true;
                i9 = this.f19113r0;
            }
        }
        Configuration configuration = this.f19107o0;
        if (configuration == null) {
            configuration = context.getResources().getConfiguration();
        }
        int i13 = configuration.uiMode & 48;
        int i14 = configurationS.uiMode & 48;
        f fVarY = y(configuration);
        f fVarY2 = fVarO == null ? null : y(configurationS);
        int i15 = i13 != i14 ? 512 : 0;
        if (fVarY2 != null && !fVarY.equals(fVarY2)) {
            i15 |= 8196;
        }
        if (((~i9) & i15) != 0 && z9 && this.f19101l0 && ((f19081G0 || this.f19103m0) && (obj3 instanceof Activity))) {
            Activity activity = (Activity) obj3;
            if (activity.isChild()) {
                z11 = false;
            } else {
                int i16 = Build.VERSION.SDK_INT;
                if (i16 >= 31 && (i15 & 8192) != 0) {
                    activity.getWindow().getDecorView().setLayoutDirection(configurationS.getLayoutDirection());
                }
                if (i16 >= 28) {
                    activity.recreate();
                } else {
                    new Handler(activity.getMainLooper()).post(new RunnableC0078a(0, activity));
                }
                z11 = true;
            }
        } else {
            z11 = false;
        }
        if (z11 || i15 == 0) {
            z12 = z11;
        } else {
            boolean z15 = (i9 & i15) == i15;
            Resources resources = context.getResources();
            Configuration configuration2 = new Configuration(resources.getConfiguration());
            configuration2.uiMode = (resources.getConfiguration().uiMode & (-49)) | i14;
            if (fVarY2 != null) {
                L.h hVar = fVarY2.f3871a;
                if (Build.VERSION.SDK_INT >= 24) {
                    q.d(configuration2, fVarY2);
                } else {
                    configuration2.setLocale(hVar.get(0));
                    configuration2.setLayoutDirection(hVar.get(0));
                }
            }
            resources.updateConfiguration(configuration2, null);
            int i17 = Build.VERSION.SDK_INT;
            if (i17 < 26 && i17 < 28) {
                if (i17 >= 24) {
                    if (!b.j) {
                        try {
                            Field declaredField = Resources.class.getDeclaredField("mResourcesImpl");
                            b.f17855i = declaredField;
                            declaredField.setAccessible(true);
                        } catch (NoSuchFieldException e10) {
                            Log.e("ResourcesFlusher", "Could not retrieve Resources#mResourcesImpl field", e10);
                        }
                        b.j = true;
                    }
                    Field field = b.f17855i;
                    if (field != null) {
                        try {
                            obj = field.get(resources);
                        } catch (IllegalAccessException e11) {
                            Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mResourcesImpl", e11);
                            obj = null;
                        }
                        if (obj != null) {
                            if (!b.f17850d) {
                                try {
                                    Field declaredField2 = obj.getClass().getDeclaredField("mDrawableCache");
                                    b.f17849c = declaredField2;
                                    declaredField2.setAccessible(true);
                                } catch (NoSuchFieldException e12) {
                                    Log.e("ResourcesFlusher", "Could not retrieve ResourcesImpl#mDrawableCache field", e12);
                                }
                                b.f17850d = true;
                            }
                            Field field2 = b.f17849c;
                            if (field2 != null) {
                                try {
                                    obj2 = field2.get(obj);
                                } catch (IllegalAccessException e13) {
                                    Log.e("ResourcesFlusher", "Could not retrieve value from ResourcesImpl#mDrawableCache", e13);
                                }
                            }
                            if (obj2 != null) {
                                b.q(obj2);
                            }
                        }
                    }
                } else {
                    if (!b.f17850d) {
                        try {
                            Field declaredField3 = Resources.class.getDeclaredField("mDrawableCache");
                            b.f17849c = declaredField3;
                            declaredField3.setAccessible(true);
                        } catch (NoSuchFieldException e14) {
                            Log.e("ResourcesFlusher", "Could not retrieve Resources#mDrawableCache field", e14);
                        }
                        b.f17850d = true;
                    }
                    Field field3 = b.f17849c;
                    if (field3 != null) {
                        try {
                            obj2 = field3.get(resources);
                        } catch (IllegalAccessException e15) {
                            Log.e("ResourcesFlusher", "Could not retrieve value from Resources#mDrawableCache", e15);
                        }
                    }
                    if (obj2 != null) {
                        b.q(obj2);
                    }
                }
            }
            int i18 = this.f19111q0;
            if (i18 != 0) {
                context.setTheme(i18);
                z13 = true;
                context.getTheme().applyStyle(this.f19111q0, true);
            } else {
                z13 = true;
            }
            if (z15 && (obj3 instanceof Activity)) {
                Activity activity2 = (Activity) obj3;
                if (activity2 instanceof InterfaceC0552v) {
                    if (((InterfaceC0552v) activity2).C().c0().compareTo(EnumC0546o.f10796c) >= 0) {
                        activity2.onConfigurationChanged(configuration2);
                    }
                } else if (this.f19103m0 && !this.f19105n0) {
                    activity2.onConfigurationChanged(configuration2);
                }
            }
            z12 = z13;
        }
        if (z12 && (obj3 instanceof AbstractActivityC0986h)) {
            if ((i15 & 512) != 0) {
            }
            if ((i15 & 4) != 0) {
            }
        }
        if (fVarY2 != null) {
            f fVarY3 = y(context.getResources().getConfiguration());
            if (Build.VERSION.SDK_INT >= 24) {
                q.c(fVarY3);
            } else {
                Locale.setDefault(fVarY3.f3871a.get(0));
            }
        }
        if (i11 == 0) {
            x(context).q();
        } else {
            t tVar = this.f19117t0;
            if (tVar != null) {
                tVar.d();
            }
        }
        if (i11 == 3) {
            if (this.f19119u0 == null) {
                this.f19119u0 = new t(this, context);
            }
            this.f19119u0.q();
        } else {
            t tVar2 = this.f19119u0;
            if (tVar2 != null) {
                tVar2.d();
            }
        }
        return z12;
    }

    /* JADX WARN: Code duplicated, block: B:35:0x0074  */
    public final void n(Window window) {
        Drawable drawableG;
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        OnBackInvokedCallback onBackInvokedCallback;
        int resourceId;
        if (this.f19100l != null) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        Window.Callback callback = window.getCallback();
        if (callback instanceof s) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        s sVar = new s(this, callback);
        this.f19102m = sVar;
        window.setCallback(sVar);
        Context context = this.f19098k;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, f19080F0);
        if (!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) {
            drawableG = null;
        } else {
            C1246t c1246tA = C1246t.a();
            synchronized (c1246tA) {
                drawableG = c1246tA.f21980a.g(context, resourceId, true);
            }
        }
        if (drawableG != null) {
            window.setBackgroundDrawable(drawableG);
        }
        typedArrayObtainStyledAttributes.recycle();
        this.f19100l = window;
        if (Build.VERSION.SDK_INT < 33 || (onBackInvokedDispatcher = this.f19087C0) != null) {
            return;
        }
        Object obj = this.j;
        if (onBackInvokedDispatcher != null && (onBackInvokedCallback = this.f19089D0) != null) {
            r.c(onBackInvokedDispatcher, onBackInvokedCallback);
            this.f19089D0 = null;
        }
        if (obj instanceof Activity) {
            Activity activity = (Activity) obj;
            if (activity.getWindow() != null) {
                this.f19087C0 = r.a(activity);
            } else {
                this.f19087C0 = null;
            }
        } else {
            this.f19087C0 = null;
        }
        I();
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View appCompatRatingBar;
        View view2 = null;
        if (this.f19085B0 == null) {
            int[] iArr = p067h.a.j;
            Context context2 = this.f19098k;
            TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(iArr);
            String string = typedArrayObtainStyledAttributes.getString(116);
            typedArrayObtainStyledAttributes.recycle();
            if (string == null) {
                this.f19085B0 = new B();
            } else {
                try {
                    this.f19085B0 = (B) context2.getClassLoader().loadClass(string).getDeclaredConstructor(null).newInstance(null);
                } catch (Throwable th) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th);
                    this.f19085B0 = new B();
                }
            }
        }
        B b10 = this.f19085B0;
        int i9 = Z0.f21865a;
        b10.getClass();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, p067h.a.f18454x, 0, 0);
        byte b11 = 4;
        int resourceId = typedArrayObtainStyledAttributes2.getResourceId(4, 0);
        if (resourceId != 0) {
            Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
        }
        typedArrayObtainStyledAttributes2.recycle();
        Context cVar = (resourceId == 0 || ((context instanceof c) && ((c) context).f21159a == resourceId)) ? context : new c(context, resourceId);
        str.getClass();
        switch (str.hashCode()) {
            case -1946472170:
                b11 = !str.equals("RatingBar") ? (byte) -1 : (byte) 0;
                break;
            case -1455429095:
                b11 = !str.equals("CheckedTextView") ? (byte) -1 : (byte) 1;
                break;
            case -1346021293:
                b11 = !str.equals("MultiAutoCompleteTextView") ? (byte) -1 : (byte) 2;
                break;
            case -938935918:
                b11 = !str.equals("TextView") ? (byte) -1 : (byte) 3;
                break;
            case -937446323:
                if (!str.equals("ImageButton")) {
                    b11 = -1;
                }
                break;
            case -658531749:
                b11 = !str.equals("SeekBar") ? (byte) -1 : (byte) 5;
                break;
            case -339785223:
                b11 = !str.equals("Spinner") ? (byte) -1 : (byte) 6;
                break;
            case 776382189:
                b11 = !str.equals("RadioButton") ? (byte) -1 : (byte) 7;
                break;
            case 799298502:
                b11 = !str.equals("ToggleButton") ? (byte) -1 : (byte) 8;
                break;
            case 1125864064:
                b11 = !str.equals("ImageView") ? (byte) -1 : (byte) 9;
                break;
            case 1413872058:
                b11 = !str.equals("AutoCompleteTextView") ? (byte) -1 : (byte) 10;
                break;
            case 1601505219:
                b11 = !str.equals("CheckBox") ? (byte) -1 : (byte) 11;
                break;
            case 1666676343:
                b11 = !str.equals("EditText") ? (byte) -1 : (byte) 12;
                break;
            case 2001146706:
                b11 = !str.equals("Button") ? (byte) -1 : (byte) 13;
                break;
            default:
                b11 = -1;
                break;
        }
        switch (b11) {
            case 0:
                appCompatRatingBar = new AppCompatRatingBar(cVar, attributeSet);
                break;
            case 1:
                appCompatRatingBar = new r(cVar, attributeSet);
                break;
            case 2:
                appCompatRatingBar = new C1252w(cVar, attributeSet);
                break;
            case 3:
                appCompatRatingBar = b10.e(cVar, attributeSet);
                break;
            case 4:
                appCompatRatingBar = new AppCompatImageButton(cVar, attributeSet);
                break;
            case 5:
                appCompatRatingBar = new B(cVar, attributeSet);
                break;
            case 6:
                appCompatRatingBar = new AppCompatSpinner(cVar, attributeSet);
                break;
            case 7:
                appCompatRatingBar = b10.d(cVar, attributeSet);
                break;
            case 8:
                appCompatRatingBar = new C1212b0(cVar, attributeSet);
                break;
            case 9:
                appCompatRatingBar = new AppCompatImageView(cVar, attributeSet);
                break;
            case co.notix.R.styleable.GradientColor_android_endX /* 10 */:
                appCompatRatingBar = b10.a(cVar, attributeSet);
                break;
            case co.notix.R.styleable.GradientColor_android_endY /* 11 */:
                appCompatRatingBar = b10.c(cVar, attributeSet);
                break;
            case 12:
                appCompatRatingBar = new AppCompatEditText(cVar, attributeSet);
                break;
            case 13:
                appCompatRatingBar = b10.b(cVar, attributeSet);
                break;
            default:
                appCompatRatingBar = null;
                break;
        }
        if (appCompatRatingBar != null || context == cVar) {
            view2 = appCompatRatingBar;
        } else {
            Object[] objArr = b10.f18949a;
            if (str.equals("view")) {
                str = attributeSet.getAttributeValue(null, "class");
            }
            try {
                objArr[0] = cVar;
                objArr[1] = attributeSet;
                if (-1 == str.indexOf(46)) {
                    int i10 = 0;
                    while (true) {
                        String[] strArr = B.f18947g;
                        if (i10 < 3) {
                            View viewF = b10.f(cVar, str, strArr[i10]);
                            if (viewF != null) {
                                objArr[0] = null;
                                objArr[1] = null;
                                view2 = viewF;
                            } else {
                                i10++;
                            }
                        } else {
                            objArr[0] = null;
                            objArr[1] = null;
                        }
                    }
                } else {
                    View viewF2 = b10.f(cVar, str, null);
                    objArr[0] = null;
                    objArr[1] = null;
                    view2 = viewF2;
                }
            } catch (Exception unused) {
                objArr[0] = view2;
                objArr[1] = view2;
            } catch (Throwable th2) {
                objArr[0] = view2;
                objArr[1] = view2;
                throw th2;
            }
        }
        if (view2 != null) {
            Context context3 = view2.getContext();
            if ((context3 instanceof ContextWrapper) && view2.hasOnClickListeners()) {
                TypedArray typedArrayObtainStyledAttributes3 = context3.obtainStyledAttributes(attributeSet, B.f18943c);
                String string2 = typedArrayObtainStyledAttributes3.getString(0);
                if (string2 != null) {
                    view2.setOnClickListener(new A(view2, string2));
                }
                typedArrayObtainStyledAttributes3.recycle();
            }
            if (Build.VERSION.SDK_INT <= 28) {
                TypedArray typedArrayObtainStyledAttributes4 = cVar.obtainStyledAttributes(attributeSet, B.f18944d);
                if (typedArrayObtainStyledAttributes4.hasValue(0)) {
                    boolean z9 = typedArrayObtainStyledAttributes4.getBoolean(0, false);
                    WeakHashMap weakHashMap = S.f5835a;
                    new D(co.notix.R.id.tag_accessibility_heading, Boolean.class, 0, 28, 2).f(view2, Boolean.valueOf(z9));
                }
                typedArrayObtainStyledAttributes4.recycle();
                TypedArray typedArrayObtainStyledAttributes5 = cVar.obtainStyledAttributes(attributeSet, B.f18945e);
                if (typedArrayObtainStyledAttributes5.hasValue(0)) {
                    S.n(view2, typedArrayObtainStyledAttributes5.getString(0));
                }
                typedArrayObtainStyledAttributes5.recycle();
                TypedArray typedArrayObtainStyledAttributes6 = cVar.obtainStyledAttributes(attributeSet, B.f18946f);
                if (typedArrayObtainStyledAttributes6.hasValue(0)) {
                    boolean z10 = typedArrayObtainStyledAttributes6.getBoolean(0, false);
                    WeakHashMap weakHashMap2 = S.f5835a;
                    new D(co.notix.R.id.tag_screen_reader_focusable, Boolean.class, 0, 28, 0).f(view2, Boolean.valueOf(z10));
                }
                typedArrayObtainStyledAttributes6.recycle();
            }
        }
        return view2;
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    public final void p(int i9, v vVar, k kVar) {
        if (kVar == null) {
            if (vVar == null && i9 >= 0) {
                v[] vVarArr = this.f19096i0;
                if (i9 < vVarArr.length) {
                    vVar = vVarArr[i9];
                }
            }
            if (vVar != null) {
                kVar = vVar.f19071h;
            }
        }
        if ((vVar == null || vVar.f19075m) && !this.f19105n0) {
            s sVar = this.f19102m;
            Window.Callback callback = this.f19100l.getCallback();
            sVar.getClass();
            try {
                sVar.f19058d = true;
                callback.onPanelClosed(i9, kVar);
            } finally {
                sVar.f19058d = false;
            }
        }
    }

    public final void q(k kVar) {
        C1231l c1231l;
        if (this.f19095h0) {
            return;
        }
        this.f19095h0 = true;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.f19112r;
        actionBarOverlayLayout.k();
        ActionMenuView actionMenuView = ((U0) actionBarOverlayLayout.f10296e).f21830a.f10393a;
        if (actionMenuView != null && (c1231l = actionMenuView.f10321t) != null) {
            c1231l.d();
            C1221g c1221g = c1231l.f21925u;
            if (c1221g != null && c1221g.b()) {
                c1221g.f21557i.dismiss();
            }
        }
        Window.Callback callback = this.f19100l.getCallback();
        if (callback != null && !this.f19105n0) {
            callback.onPanelClosed(108, kVar);
        }
        this.f19095h0 = false;
    }

    public final void r(v vVar, boolean z9) {
        u uVar;
        InterfaceC1216d0 interfaceC1216d0;
        C1231l c1231l;
        if (z9 && vVar.f19064a == 0 && (interfaceC1216d0 = this.f19112r) != null) {
            ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC1216d0;
            actionBarOverlayLayout.k();
            ActionMenuView actionMenuView = ((U0) actionBarOverlayLayout.f10296e).f21830a.f10393a;
            if (actionMenuView != null && (c1231l = actionMenuView.f10321t) != null && c1231l.f()) {
                q(vVar.f19071h);
                return;
            }
        }
        WindowManager windowManager = (WindowManager) this.f19098k.getSystemService("window");
        if (windowManager != null && vVar.f19075m && (uVar = vVar.f19068e) != null) {
            windowManager.removeView(uVar);
            if (z9) {
                p(vVar.f19064a, vVar, null);
            }
        }
        vVar.f19073k = false;
        vVar.f19074l = false;
        vVar.f19075m = false;
        vVar.f19069f = null;
        vVar.f19076n = true;
        if (this.f19097j0 == vVar) {
            this.f19097j0 = null;
        }
        if (vVar.f19064a == 0) {
            I();
        }
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0147  */
    /* JADX WARN: Code duplicated, block: B:104:0x014e A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:21:0x003f  */
    /* JADX WARN: Code duplicated, block: B:23:0x004a A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:24:0x004c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:26:0x0050  */
    /* JADX WARN: Code duplicated, block: B:28:0x0056  */
    /* JADX WARN: Code duplicated, block: B:30:0x005e  */
    /* JADX WARN: Code duplicated, block: B:32:0x0062  */
    /* JADX WARN: Code duplicated, block: B:35:0x006b  */
    /* JADX WARN: Code duplicated, block: B:38:0x006f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:39:0x0071 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:41:0x0075  */
    /* JADX WARN: Code duplicated, block: B:44:0x007b  */
    /* JADX WARN: Code duplicated, block: B:46:0x0085  */
    /* JADX WARN: Code duplicated, block: B:78:0x0105  */
    /* JADX WARN: Code duplicated, block: B:80:0x0109  */
    /* JADX WARN: Code duplicated, block: B:91:0x0123  */
    /* JADX WARN: Code duplicated, block: B:95:0x012d  */
    /* JADX WARN: Code duplicated, block: B:97:0x013b  */
    /* JADX WARN: Code duplicated, block: B:99:0x013f  */
    public final boolean t(KeyEvent keyEvent) {
        View decorView;
        int keyCode;
        v vVarZ;
        InterfaceC1216d0 interfaceC1216d0;
        Context context;
        boolean z9;
        boolean z10;
        boolean zG;
        AudioManager audioManager;
        Toolbar toolbar;
        ActionMenuView actionMenuView;
        C1231l c1231l;
        C1231l c1231l2;
        C1231l c1231l3;
        v vVarZ2;
        Object obj = this.j;
        if ((!(obj instanceof InterfaceC0318k) && !(obj instanceof y)) || (decorView = this.f19100l.getDecorView()) == null || !I3.a.p(decorView, keyEvent)) {
            if (keyEvent.getKeyCode() == 82) {
                s sVar = this.f19102m;
                Window.Callback callback = this.f19100l.getCallback();
                sVar.getClass();
                try {
                    sVar.f19057c = true;
                    boolean zDispatchKeyEvent = callback.dispatchKeyEvent(keyEvent);
                    sVar.f19057c = false;
                    if (!zDispatchKeyEvent) {
                        keyCode = keyEvent.getKeyCode();
                        if (keyEvent.getAction() == 0) {
                            if (keyCode != 4) {
                                this.f19099k0 = (keyEvent.getFlags() & 128) != 0;
                                return false;
                            }
                            if (keyCode == 82) {
                                if (keyEvent.getRepeatCount() == 0) {
                                    vVarZ2 = z(0);
                                    if (!vVarZ2.f19075m) {
                                        G(vVarZ2, keyEvent);
                                        return true;
                                    }
                                }
                            }
                            return false;
                        }
                        if (keyCode != 4) {
                            if (keyCode == 82) {
                                if (this.f19118u == null) {
                                    vVarZ = z(0);
                                    interfaceC1216d0 = this.f19112r;
                                    context = this.f19098k;
                                    if (interfaceC1216d0 != null) {
                                        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC1216d0;
                                        actionBarOverlayLayout.k();
                                        toolbar = ((U0) actionBarOverlayLayout.f10296e).f21830a;
                                        if (toolbar.getVisibility() == 0 || (actionMenuView = toolbar.f10393a) == null || !actionMenuView.f10320s || ViewConfiguration.get(context).hasPermanentMenuKey()) {
                                            z9 = vVarZ.f19075m;
                                            if (!z9 || vVarZ.f19074l) {
                                                r(vVarZ, true);
                                                z10 = z9;
                                            } else {
                                                if (vVarZ.f19073k) {
                                                    if (vVarZ.f19077o) {
                                                        vVarZ.f19073k = false;
                                                        zG = G(vVarZ, keyEvent);
                                                    } else {
                                                        zG = true;
                                                    }
                                                    if (zG) {
                                                        E(vVarZ, keyEvent);
                                                        z10 = true;
                                                    }
                                                }
                                                z10 = false;
                                            }
                                        } else {
                                            ActionBarOverlayLayout actionBarOverlayLayout2 = (ActionBarOverlayLayout) this.f19112r;
                                            actionBarOverlayLayout2.k();
                                            ActionMenuView actionMenuView2 = ((U0) actionBarOverlayLayout2.f10296e).f21830a.f10393a;
                                            if (actionMenuView2 == null || (c1231l2 = actionMenuView2.f10321t) == null || !c1231l2.f()) {
                                                if (!this.f19105n0 && G(vVarZ, keyEvent)) {
                                                    ActionBarOverlayLayout actionBarOverlayLayout3 = (ActionBarOverlayLayout) this.f19112r;
                                                    actionBarOverlayLayout3.k();
                                                    ActionMenuView actionMenuView3 = ((U0) actionBarOverlayLayout3.f10296e).f21830a.f10393a;
                                                    if (actionMenuView3 != null && (c1231l = actionMenuView3.f10321t) != null && c1231l.n()) {
                                                        z10 = true;
                                                    }
                                                }
                                                z10 = false;
                                            } else {
                                                ActionBarOverlayLayout actionBarOverlayLayout4 = (ActionBarOverlayLayout) this.f19112r;
                                                actionBarOverlayLayout4.k();
                                                ActionMenuView actionMenuView4 = ((U0) actionBarOverlayLayout4.f10296e).f21830a.f10393a;
                                                if (actionMenuView4 == null || (c1231l3 = actionMenuView4.f10321t) == null || !c1231l3.d()) {
                                                    z10 = false;
                                                } else {
                                                    z10 = true;
                                                }
                                            }
                                        }
                                    } else {
                                        z9 = vVarZ.f19075m;
                                        if (z9) {
                                        }
                                        r(vVarZ, true);
                                        z10 = z9;
                                    }
                                    if (z10) {
                                        audioManager = (AudioManager) context.getApplicationContext().getSystemService("audio");
                                        if (audioManager != null) {
                                            audioManager.playSoundEffect(0);
                                            return true;
                                        }
                                        Log.w("AppCompatDelegate", "Couldn't get audio manager");
                                        return true;
                                    }
                                }
                            }
                            return false;
                        }
                        if (D()) {
                            return false;
                        }
                    }
                } catch (Throwable th) {
                    sVar.f19057c = false;
                    throw th;
                }
            } else {
                keyCode = keyEvent.getKeyCode();
                if (keyEvent.getAction() == 0) {
                    if (keyCode != 4) {
                        this.f19099k0 = (keyEvent.getFlags() & 128) != 0;
                        return false;
                    }
                    if (keyCode == 82) {
                        if (keyEvent.getRepeatCount() == 0) {
                            vVarZ2 = z(0);
                            if (!vVarZ2.f19075m) {
                                G(vVarZ2, keyEvent);
                                return true;
                            }
                        }
                    }
                    return false;
                }
                if (keyCode != 4) {
                    if (keyCode == 82) {
                        if (this.f19118u == null) {
                            vVarZ = z(0);
                            interfaceC1216d0 = this.f19112r;
                            context = this.f19098k;
                            if (interfaceC1216d0 != null) {
                                ActionBarOverlayLayout actionBarOverlayLayout5 = (ActionBarOverlayLayout) interfaceC1216d0;
                                actionBarOverlayLayout5.k();
                                toolbar = ((U0) actionBarOverlayLayout5.f10296e).f21830a;
                                if (toolbar.getVisibility() == 0) {
                                    z9 = vVarZ.f19075m;
                                    if (z9) {
                                    }
                                    r(vVarZ, true);
                                    z10 = z9;
                                } else {
                                    z9 = vVarZ.f19075m;
                                    if (z9) {
                                    }
                                    r(vVarZ, true);
                                    z10 = z9;
                                }
                            } else {
                                z9 = vVarZ.f19075m;
                                if (z9) {
                                }
                                r(vVarZ, true);
                                z10 = z9;
                            }
                            if (z10) {
                                audioManager = (AudioManager) context.getApplicationContext().getSystemService("audio");
                                if (audioManager != null) {
                                    audioManager.playSoundEffect(0);
                                    return true;
                                }
                                Log.w("AppCompatDelegate", "Couldn't get audio manager");
                                return true;
                            }
                        }
                    }
                    return false;
                }
                if (D()) {
                    return false;
                }
            }
        }
        return true;
    }

    public final void u(int i9) {
        v vVarZ = z(i9);
        if (vVarZ.f19071h != null) {
            Bundle bundle = new Bundle();
            vVarZ.f19071h.t(bundle);
            if (bundle.size() > 0) {
                vVarZ.f19078p = bundle;
            }
            vVarZ.f19071h.w();
            vVarZ.f19071h.clear();
        }
        vVarZ.f19077o = true;
        vVarZ.f19076n = true;
        if ((i9 == 108 || i9 == 0) && this.f19112r != null) {
            v vVarZ2 = z(0);
            vVarZ2.f19073k = false;
            G(vVarZ2, null);
        }
    }

    public final void v() {
        ViewGroup viewGroup;
        if (this.f19082A) {
            return;
        }
        Context context = this.f19098k;
        int[] iArr = p067h.a.j;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(iArr);
        if (!typedArrayObtainStyledAttributes.hasValue(117)) {
            typedArrayObtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
        if (typedArrayObtainStyledAttributes.getBoolean(126, false)) {
            h(1);
        } else if (typedArrayObtainStyledAttributes.getBoolean(117, false)) {
            h(108);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(118, false)) {
            h(109);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(119, false)) {
            h(10);
        }
        this.f19093f0 = typedArrayObtainStyledAttributes.getBoolean(0, false);
        typedArrayObtainStyledAttributes.recycle();
        w();
        this.f19100l.getDecorView();
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
        int i9 = 5;
        if (this.f19094g0) {
            viewGroup = this.f19092e0 ? (ViewGroup) layoutInflaterFrom.inflate(co.notix.R.layout.abc_screen_simple_overlay_action_mode, (ViewGroup) null) : (ViewGroup) layoutInflaterFrom.inflate(co.notix.R.layout.abc_screen_simple, (ViewGroup) null);
        } else if (this.f19093f0) {
            viewGroup = (ViewGroup) layoutInflaterFrom.inflate(co.notix.R.layout.abc_dialog_title_material, (ViewGroup) null);
            this.f19091d0 = false;
            this.Z = false;
        } else if (this.Z) {
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(co.notix.R.attr.actionBarTheme, typedValue, true);
            viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new c(context, typedValue.resourceId) : context).inflate(co.notix.R.layout.abc_screen_toolbar, (ViewGroup) null);
            InterfaceC1216d0 interfaceC1216d0 = (InterfaceC1216d0) viewGroup.findViewById(co.notix.R.id.decor_content_parent);
            this.f19112r = interfaceC1216d0;
            interfaceC1216d0.setWindowCallback(this.f19100l.getCallback());
            if (this.f19091d0) {
                ((ActionBarOverlayLayout) this.f19112r).j(109);
            }
            if (this.X) {
                ((ActionBarOverlayLayout) this.f19112r).j(2);
            }
            if (this.f19090Y) {
                ((ActionBarOverlayLayout) this.f19112r).j(5);
            }
        } else {
            viewGroup = null;
        }
        if (viewGroup == null) {
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.Z + ", windowActionBarOverlay: " + this.f19091d0 + ", android:windowIsFloating: " + this.f19093f0 + ", windowActionModeOverlay: " + this.f19092e0 + ", windowNoTitle: " + this.f19094g0 + " }");
        }
        n nVar = new n(this);
        WeakHashMap weakHashMap = S.f5835a;
        I.l(viewGroup, nVar);
        if (this.f19112r == null) {
            this.f19086C = (TextView) viewGroup.findViewById(co.notix.R.id.title);
        }
        boolean z9 = c1.f21887a;
        try {
            Method method = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", null);
            if (!method.isAccessible()) {
                method.setAccessible(true);
            }
            method.invoke(viewGroup, null);
        } catch (IllegalAccessException e9) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e9);
        } catch (NoSuchMethodException unused) {
            Log.d("ViewUtils", "Could not find method makeOptionalFitsSystemWindows. Oh well...");
        } catch (InvocationTargetException e10) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e10);
        }
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(co.notix.R.id.action_bar_activity_content);
        ViewGroup viewGroup2 = (ViewGroup) this.f19100l.findViewById(R.id.content);
        if (viewGroup2 != null) {
            while (viewGroup2.getChildCount() > 0) {
                View childAt = viewGroup2.getChildAt(0);
                viewGroup2.removeViewAt(0);
                contentFrameLayout.addView(childAt);
            }
            viewGroup2.setId(-1);
            contentFrameLayout.setId(R.id.content);
            if (viewGroup2 instanceof FrameLayout) {
                ((FrameLayout) viewGroup2).setForeground(null);
            }
        }
        this.f19100l.setContentView(viewGroup);
        contentFrameLayout.setAttachListener(new p036d5.h(i9, this));
        this.f19084B = viewGroup;
        Object obj = this.j;
        CharSequence title = obj instanceof Activity ? ((Activity) obj).getTitle() : this.f19110q;
        if (!TextUtils.isEmpty(title)) {
            InterfaceC1216d0 interfaceC1216d1 = this.f19112r;
            if (interfaceC1216d1 != null) {
                interfaceC1216d1.setWindowTitle(title);
            } else {
                I i10 = this.f19106o;
                if (i10 != null) {
                    U0 u1 = (U0) i10.j;
                    if (!u1.f21836g) {
                        Toolbar toolbar = u1.f21830a;
                        u1.f21837h = title;
                        if ((u1.f21831b & 8) != 0) {
                            toolbar.setTitle(title);
                            if (u1.f21836g) {
                                S.n(toolbar.getRootView(), title);
                            }
                        }
                    }
                } else {
                    TextView textView = this.f19086C;
                    if (textView != null) {
                        textView.setText(title);
                    }
                }
            }
        }
        ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.f19084B.findViewById(R.id.content);
        View decorView = this.f19100l.getDecorView();
        contentFrameLayout2.f10370g.set(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        if (contentFrameLayout2.isLaidOut()) {
            contentFrameLayout2.requestLayout();
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(iArr);
        typedArrayObtainStyledAttributes2.getValue(124, contentFrameLayout2.getMinWidthMajor());
        typedArrayObtainStyledAttributes2.getValue(125, contentFrameLayout2.getMinWidthMinor());
        if (typedArrayObtainStyledAttributes2.hasValue(122)) {
            typedArrayObtainStyledAttributes2.getValue(122, contentFrameLayout2.getFixedWidthMajor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(123)) {
            typedArrayObtainStyledAttributes2.getValue(123, contentFrameLayout2.getFixedWidthMinor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(120)) {
            typedArrayObtainStyledAttributes2.getValue(120, contentFrameLayout2.getFixedHeightMajor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(121)) {
            typedArrayObtainStyledAttributes2.getValue(121, contentFrameLayout2.getFixedHeightMinor());
        }
        typedArrayObtainStyledAttributes2.recycle();
        contentFrameLayout2.requestLayout();
        this.f19082A = true;
        v vVarZ = z(0);
        if (this.f19105n0 || vVarZ.f19071h != null) {
            return;
        }
        B(108);
    }

    public final void w() {
        if (this.f19100l == null) {
            Object obj = this.j;
            if (obj instanceof Activity) {
                n(((Activity) obj).getWindow());
            }
        }
        if (this.f19100l == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    public final S4.f x(Context context) {
        if (this.f19117t0 == null) {
            if (Y4.i.f9375e == null) {
                Context applicationContext = context.getApplicationContext();
                Y4.i.f9375e = new Y4.i(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
            }
            this.f19117t0 = new t(this, Y4.i.f9375e);
        }
        return this.f19117t0;
    }

    public final v z(int i9) {
        v[] vVarArr = this.f19096i0;
        if (vVarArr == null || vVarArr.length <= i9) {
            v[] vVarArr2 = new v[i9 + 1];
            if (vVarArr != null) {
                System.arraycopy(vVarArr, 0, vVarArr2, 0, vVarArr.length);
            }
            this.f19096i0 = vVarArr2;
            vVarArr = vVarArr2;
        }
        v vVar = vVarArr[i9];
        if (vVar != null) {
            return vVar;
        }
        v vVar2 = new v();
        vVar2.f19064a = i9;
        vVar2.f19076n = false;
        vVarArr[i9] = vVar2;
        return vVar2;
    }
}
