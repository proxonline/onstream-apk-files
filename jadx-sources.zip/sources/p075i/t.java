package p075i;

import E.d;
import S4.f;
import Y4.i;
import android.content.Context;
import android.content.IntentFilter;
import android.location.Location;
import android.location.LocationManager;
import android.os.PowerManager;
import android.util.Log;
import java.util.Calendar;

/* JADX INFO: loaded from: classes.dex */
public final class t extends f {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f19060c = 1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ w f19061d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f19062e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t(w wVar, i iVar) {
        super(wVar);
        this.f19061d = wVar;
        this.f19062e = iVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t(w wVar, Context context) {
        super(wVar);
        this.f19061d = wVar;
        this.f19062e = (PowerManager) context.getApplicationContext().getSystemService("power");
    }

    @Override // S4.f
    public final IntentFilter e() {
        switch (this.f19060c) {
            case 0:
                IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
                return intentFilter;
            default:
                IntentFilter intentFilter2 = new IntentFilter();
                intentFilter2.addAction("android.intent.action.TIME_SET");
                intentFilter2.addAction("android.intent.action.TIMEZONE_CHANGED");
                intentFilter2.addAction("android.intent.action.TIME_TICK");
                return intentFilter2;
        }
    }

    @Override // S4.f
    public final int h() {
        Location location;
        boolean z9;
        long j;
        Location lastKnownLocation;
        switch (this.f19060c) {
            case 0:
                return p.a((PowerManager) this.f19062e) ? 2 : 1;
            default:
                i iVar = (i) this.f19062e;
                F f3 = (F) iVar.f9379d;
                LocationManager locationManager = (LocationManager) iVar.f9378c;
                if (f3.f18956b <= System.currentTimeMillis()) {
                    Context context = (Context) iVar.f9377b;
                    Location lastKnownLocation2 = null;
                    if (d.b(context, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                        try {
                            lastKnownLocation = locationManager.isProviderEnabled("network") ? locationManager.getLastKnownLocation("network") : null;
                        } catch (Exception e9) {
                            Log.d("TwilightManager", "Failed to get last known location", e9);
                        }
                        location = lastKnownLocation;
                    } else {
                        location = null;
                    }
                    if (d.b(context, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                        try {
                            if (locationManager.isProviderEnabled("gps")) {
                                lastKnownLocation2 = locationManager.getLastKnownLocation("gps");
                            }
                        } catch (Exception e10) {
                            Log.d("TwilightManager", "Failed to get last known location", e10);
                        }
                    }
                    if (lastKnownLocation2 == null || location == null ? lastKnownLocation2 != null : lastKnownLocation2.getTime() > location.getTime()) {
                        location = lastKnownLocation2;
                    }
                    z9 = false;
                    if (location != null) {
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        if (E.f18951d == null) {
                            E.f18951d = new E();
                        }
                        E e11 = E.f18951d;
                        e11.a(location.getLatitude(), location.getLongitude(), jCurrentTimeMillis - 86400000);
                        e11.a(location.getLatitude(), location.getLongitude(), jCurrentTimeMillis);
                        z9 = e11.f18954c == 1;
                        long j9 = e11.f18953b;
                        long j10 = e11.f18952a;
                        e11.a(location.getLatitude(), location.getLongitude(), jCurrentTimeMillis + 86400000);
                        long j11 = e11.f18953b;
                        if (j9 == -1 || j10 == -1) {
                            j = jCurrentTimeMillis + 43200000;
                        } else {
                            if (jCurrentTimeMillis > j10) {
                                j9 = j11;
                            } else if (jCurrentTimeMillis > j9) {
                                j9 = j10;
                            }
                            j = j9 + 60000;
                        }
                        f3.f18955a = z9;
                        f3.f18956b = j;
                    } else {
                        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
                        int i9 = Calendar.getInstance().get(11);
                        if (i9 < 6 || i9 >= 22) {
                            z9 = true;
                        }
                    }
                    break;
                } else {
                    z9 = f3.f18955a;
                }
                return z9 ? 2 : 1;
        }
    }

    @Override // S4.f
    public final void n() {
        switch (this.f19060c) {
            case 0:
                this.f19061d.m(true, true);
                break;
            default:
                this.f19061d.m(true, true);
                break;
        }
    }
}
