package p075i;

import G6.T;
import P.J;
import P.S;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.appcompat.app.AlertController$RecycleListView;
import androidx.core.widget.NestedScrollView;
import co.notix.R;
import java.util.WeakHashMap;
import p133o.C1240p0;

/* JADX INFO: renamed from: i.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class DialogInterfaceC0985g extends y implements DialogInterface {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final C0983e f19039f;

    public DialogInterfaceC0985g(ContextThemeWrapper contextThemeWrapper, int i9) {
        super(contextThemeWrapper, g(contextThemeWrapper, i9));
        this.f19039f = new C0983e(getContext(), this, getWindow());
    }

    public static int g(Context context, int i9) {
        if (((i9 >>> 24) & 255) >= 1) {
            return i9;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    @Override // p075i.y, p030d.l, android.app.Dialog
    public void onCreate(Bundle bundle) {
        int i9;
        ListAdapter listAdapter;
        View viewFindViewById;
        super.onCreate(bundle);
        C0983e c0983e = this.f19039f;
        c0983e.f19013b.setContentView(c0983e.f19035y);
        Context context = c0983e.f19012a;
        Window window = c0983e.f19014c;
        View viewFindViewById2 = window.findViewById(R.id.parentPanel);
        View viewFindViewById3 = viewFindViewById2.findViewById(R.id.topPanel);
        View viewFindViewById4 = viewFindViewById2.findViewById(R.id.contentPanel);
        View viewFindViewById5 = viewFindViewById2.findViewById(R.id.buttonPanel);
        ViewGroup viewGroup = (ViewGroup) viewFindViewById2.findViewById(R.id.customPanel);
        View view = c0983e.f19017f;
        if (view == null) {
            view = null;
        }
        boolean z9 = view != null;
        if (!z9 || !C0983e.a(view)) {
            window.setFlags(131072, 131072);
        }
        if (z9) {
            FrameLayout frameLayout = (FrameLayout) window.findViewById(R.id.custom);
            frameLayout.addView(view, new ViewGroup.LayoutParams(-1, -1));
            if (c0983e.f19018g) {
                frameLayout.setPadding(0, 0, 0, 0);
            }
            if (c0983e.f19016e != null) {
                ((LinearLayout.LayoutParams) ((C1240p0) viewGroup.getLayoutParams())).weight = 0.0f;
            }
        } else {
            viewGroup.setVisibility(8);
        }
        View viewFindViewById6 = viewGroup.findViewById(R.id.topPanel);
        View viewFindViewById7 = viewGroup.findViewById(R.id.contentPanel);
        View viewFindViewById8 = viewGroup.findViewById(R.id.buttonPanel);
        ViewGroup viewGroupB = C0983e.b(viewFindViewById6, viewFindViewById3);
        ViewGroup viewGroupB2 = C0983e.b(viewFindViewById7, viewFindViewById4);
        ViewGroup viewGroupB3 = C0983e.b(viewFindViewById8, viewFindViewById5);
        NestedScrollView nestedScrollView = (NestedScrollView) window.findViewById(R.id.scrollView);
        c0983e.f19027q = nestedScrollView;
        nestedScrollView.setFocusable(false);
        c0983e.f19027q.setNestedScrollingEnabled(false);
        TextView textView = (TextView) viewGroupB2.findViewById(android.R.id.message);
        c0983e.f19031u = textView;
        if (textView != null) {
            textView.setVisibility(8);
            c0983e.f19027q.removeView(c0983e.f19031u);
            if (c0983e.f19016e != null) {
                ViewGroup viewGroup2 = (ViewGroup) c0983e.f19027q.getParent();
                int iIndexOfChild = viewGroup2.indexOfChild(c0983e.f19027q);
                viewGroup2.removeViewAt(iIndexOfChild);
                viewGroup2.addView(c0983e.f19016e, iIndexOfChild, new ViewGroup.LayoutParams(-1, -1));
            } else {
                viewGroupB2.setVisibility(8);
            }
        }
        Button button = (Button) viewGroupB3.findViewById(android.R.id.button1);
        c0983e.f19019h = button;
        T t8 = c0983e.f19011E;
        button.setOnClickListener(t8);
        if (TextUtils.isEmpty(c0983e.f19020i)) {
            c0983e.f19019h.setVisibility(8);
            i9 = 0;
        } else {
            c0983e.f19019h.setText(c0983e.f19020i);
            c0983e.f19019h.setVisibility(0);
            i9 = 1;
        }
        Button button2 = (Button) viewGroupB3.findViewById(android.R.id.button2);
        c0983e.f19021k = button2;
        button2.setOnClickListener(t8);
        if (TextUtils.isEmpty(c0983e.f19022l)) {
            c0983e.f19021k.setVisibility(8);
        } else {
            c0983e.f19021k.setText(c0983e.f19022l);
            c0983e.f19021k.setVisibility(0);
            i9 |= 2;
        }
        Button button3 = (Button) viewGroupB3.findViewById(android.R.id.button3);
        c0983e.f19024n = button3;
        button3.setOnClickListener(t8);
        if (TextUtils.isEmpty(c0983e.f19025o)) {
            c0983e.f19024n.setVisibility(8);
        } else {
            c0983e.f19024n.setText(c0983e.f19025o);
            c0983e.f19024n.setVisibility(0);
            i9 |= 4;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.alertDialogCenterButtons, typedValue, true);
        if (typedValue.data != 0) {
            if (i9 == 1) {
                Button button4 = c0983e.f19019h;
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button4.getLayoutParams();
                layoutParams.gravity = 1;
                layoutParams.weight = 0.5f;
                button4.setLayoutParams(layoutParams);
            } else if (i9 == 2) {
                Button button5 = c0983e.f19021k;
                LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) button5.getLayoutParams();
                layoutParams2.gravity = 1;
                layoutParams2.weight = 0.5f;
                button5.setLayoutParams(layoutParams2);
            } else if (i9 == 4) {
                Button button6 = c0983e.f19024n;
                LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) button6.getLayoutParams();
                layoutParams3.gravity = 1;
                layoutParams3.weight = 0.5f;
                button6.setLayoutParams(layoutParams3);
            }
        }
        if (i9 == 0) {
            viewGroupB3.setVisibility(8);
        }
        if (c0983e.f19032v != null) {
            viewGroupB.addView(c0983e.f19032v, 0, new ViewGroup.LayoutParams(-1, -2));
            window.findViewById(R.id.title_template).setVisibility(8);
        } else {
            c0983e.f19029s = (ImageView) window.findViewById(android.R.id.icon);
            if (TextUtils.isEmpty(c0983e.f19015d) || !c0983e.f19009C) {
                window.findViewById(R.id.title_template).setVisibility(8);
                c0983e.f19029s.setVisibility(8);
                viewGroupB.setVisibility(8);
            } else {
                TextView textView2 = (TextView) window.findViewById(R.id.alertTitle);
                c0983e.f19030t = textView2;
                textView2.setText(c0983e.f19015d);
                Drawable drawable = c0983e.f19028r;
                if (drawable != null) {
                    c0983e.f19029s.setImageDrawable(drawable);
                } else {
                    c0983e.f19030t.setPadding(c0983e.f19029s.getPaddingLeft(), c0983e.f19029s.getPaddingTop(), c0983e.f19029s.getPaddingRight(), c0983e.f19029s.getPaddingBottom());
                    c0983e.f19029s.setVisibility(8);
                }
            }
        }
        boolean z10 = viewGroup.getVisibility() != 8;
        int i10 = (viewGroupB == null || viewGroupB.getVisibility() == 8) ? 0 : 1;
        boolean z11 = viewGroupB3.getVisibility() != 8;
        if (!z11 && (viewFindViewById = viewGroupB2.findViewById(R.id.textSpacerNoButtons)) != null) {
            viewFindViewById.setVisibility(0);
        }
        if (i10 != 0) {
            NestedScrollView nestedScrollView2 = c0983e.f19027q;
            if (nestedScrollView2 != null) {
                nestedScrollView2.setClipToPadding(true);
            }
            View viewFindViewById9 = c0983e.f19016e != null ? viewGroupB.findViewById(R.id.titleDividerNoCustom) : null;
            if (viewFindViewById9 != null) {
                viewFindViewById9.setVisibility(0);
            }
        } else {
            View viewFindViewById10 = viewGroupB2.findViewById(R.id.textSpacerNoTitle);
            if (viewFindViewById10 != null) {
                viewFindViewById10.setVisibility(0);
            }
        }
        AlertController$RecycleListView alertController$RecycleListView = c0983e.f19016e;
        if (alertController$RecycleListView != null) {
            alertController$RecycleListView.getClass();
            if (!z11 || i10 == 0) {
                alertController$RecycleListView.setPadding(alertController$RecycleListView.getPaddingLeft(), i10 != 0 ? alertController$RecycleListView.getPaddingTop() : alertController$RecycleListView.f10229a, alertController$RecycleListView.getPaddingRight(), z11 ? alertController$RecycleListView.getPaddingBottom() : alertController$RecycleListView.f10230b);
            }
        }
        if (!z10) {
            View view2 = c0983e.f19016e;
            if (view2 == null) {
                view2 = c0983e.f19027q;
            }
            if (view2 != null) {
                int i11 = z11 ? 2 : 0;
                View viewFindViewById11 = window.findViewById(R.id.scrollIndicatorUp);
                View viewFindViewById12 = window.findViewById(R.id.scrollIndicatorDown);
                WeakHashMap weakHashMap = S.f5835a;
                J.b(view2, i10 | i11, 3);
                if (viewFindViewById11 != null) {
                    viewGroupB2.removeView(viewFindViewById11);
                }
                if (viewFindViewById12 != null) {
                    viewGroupB2.removeView(viewFindViewById12);
                }
            }
        }
        AlertController$RecycleListView alertController$RecycleListView2 = c0983e.f19016e;
        if (alertController$RecycleListView2 == null || (listAdapter = c0983e.f19033w) == null) {
            return;
        }
        alertController$RecycleListView2.setAdapter(listAdapter);
        int i12 = c0983e.f19034x;
        if (i12 > -1) {
            alertController$RecycleListView2.setItemChecked(i12, true);
            alertController$RecycleListView2.setSelection(i12);
        }
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i9, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f19039f.f19027q;
        if (nestedScrollView == null || !nestedScrollView.i(keyEvent)) {
            return super.onKeyDown(i9, keyEvent);
        }
        return true;
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i9, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f19039f.f19027q;
        if (nestedScrollView == null || !nestedScrollView.i(keyEvent)) {
            return super.onKeyUp(i9, keyEvent);
        }
        return true;
    }

    @Override // p075i.y, android.app.Dialog
    public final void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        C0983e c0983e = this.f19039f;
        c0983e.f19015d = charSequence;
        TextView textView = c0983e.f19030t;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }
}
