package p075i;

import android.view.KeyEvent;
import android.view.MotionEvent;
import androidx.appcompat.widget.ContentFrameLayout;
import p001a.a;
import p113m.c;

/* JADX INFO: loaded from: classes.dex */
public final class u extends ContentFrameLayout {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ w f19063i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u(w wVar, c cVar) {
        super(cVar, null);
        this.f19063i = wVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return this.f19063i.t(keyEvent) || super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            int x5 = (int) motionEvent.getX();
            int y9 = (int) motionEvent.getY();
            if (x5 < -5 || y9 < -5 || x5 > getWidth() + 5 || y9 > getHeight() + 5) {
                w wVar = this.f19063i;
                wVar.r(wVar.z(0), true);
                return true;
            }
        }
        return super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.view.View
    public final void setBackgroundResource(int i9) {
        setBackgroundDrawable(a.s(getContext(), i9));
    }
}
