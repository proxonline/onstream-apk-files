package p075i;

import P.S;
import T8.l;
import android.view.View;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import com.google.android.material.appbar.h;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class G extends l {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ int f18957h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ I f18958i;

    public /* synthetic */ G(I i9, int i10) {
        this.f18957h = i10;
        this.f18958i = i9;
    }

    @Override // P.InterfaceC0309b0
    public final void a() {
        View view;
        int i9 = this.f18957h;
        I i10 = this.f18958i;
        switch (i9) {
            case 0:
                if (i10.f18982t && (view = i10.f18974l) != null) {
                    view.setTranslationY(0.0f);
                    i10.f18972i.setTranslationY(0.0f);
                }
                i10.f18972i.setVisibility(8);
                i10.f18972i.setTransitioning(false);
                i10.f18986x = null;
                h hVar = i10.f18978p;
                if (hVar != null) {
                    hVar.A(i10.f18977o);
                    i10.f18977o = null;
                    i10.f18978p = null;
                }
                ActionBarOverlayLayout actionBarOverlayLayout = i10.f18971h;
                if (actionBarOverlayLayout != null) {
                    WeakHashMap weakHashMap = S.f5835a;
                    P.G.c(actionBarOverlayLayout);
                }
                break;
            default:
                i10.f18986x = null;
                i10.f18972i.requestLayout();
                break;
        }
    }
}
