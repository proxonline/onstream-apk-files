package p075i;

import E0.c;
import L2.f;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.util.SparseArray;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import p079i3.p;
import p190v0.AbstractC1316p;
import p190v0.C1312l;
import p190v0.C1313m;
import p190v0.C1314n;
import p190v0.C1324y;
import p190v0.O;
import p190v0.P;
import p190v0.Q;
import p190v0.S;
import p190v0.U;

/* JADX INFO: renamed from: i.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class HandlerC0981c extends Handler {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f19005a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public WeakReference f19006b;

    public /* synthetic */ HandlerC0981c() {
    }

    public HandlerC0981c(O o4) {
        this.f19006b = new WeakReference(o4);
    }

    @Override // android.os.Handler
    public final void handleMessage(Message message) {
        P p8;
        C1314n c1314n;
        P p9;
        switch (this.f19005a) {
            case 0:
                int i9 = message.what;
                if (i9 == -3 || i9 == -2 || i9 == -1) {
                    ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f19006b.get(), message.what);
                    break;
                } else if (i9 == 1) {
                    ((DialogInterface) message.obj).dismiss();
                    break;
                }
                break;
            default:
                O o4 = (O) this.f19006b.get();
                if (o4 != null) {
                    SparseArray sparseArray = o4.f24144h;
                    U u4 = o4.f24145i;
                    ArrayList arrayList = u4.f24165k;
                    int i10 = message.what;
                    int i11 = message.arg1;
                    int i12 = message.arg2;
                    Object obj = message.obj;
                    Bundle bundlePeekData = message.peekData();
                    int i13 = 0;
                    switch (i10) {
                        case 0:
                            if (i11 == o4.f24143g) {
                                o4.f24143g = 0;
                                if (u4.f24168n == o4) {
                                    if (U.f24163q) {
                                        Log.d("MediaRouteProviderProxy", u4 + ": Service connection error - Registration failed");
                                    }
                                    u4.n();
                                }
                            }
                            if (((Q) sparseArray.get(i11)) != null) {
                                sparseArray.remove(i11);
                                Q.a(null, null);
                            }
                            break;
                        case 2:
                            if (obj == null || (obj instanceof Bundle)) {
                                Bundle bundle = (Bundle) obj;
                                if (o4.f24142f == 0 && i11 == o4.f24143g && i12 >= 1) {
                                    o4.f24143g = 0;
                                    o4.f24142f = i12;
                                    u4.l(o4, f.e(bundle));
                                    if (u4.f24168n == o4) {
                                        u4.f24169o = true;
                                        int size = arrayList.size();
                                        while (i13 < size) {
                                            ((P) arrayList.get(i13)).c(u4.f24168n);
                                            i13++;
                                        }
                                        C1313m c1313m = u4.f24234e;
                                        if (c1313m != null) {
                                            O o9 = u4.f24168n;
                                            int i14 = o9.f24140d;
                                            o9.f24140d = i14 + 1;
                                            o9.b(10, i14, 0, c1313m.f24218a, null);
                                        }
                                    }
                                }
                            }
                            break;
                        case 3:
                            if (obj == null || (obj instanceof Bundle)) {
                                Bundle bundle2 = (Bundle) obj;
                                Q q6 = (Q) sparseArray.get(i11);
                                if (q6 != null) {
                                    sparseArray.remove(i11);
                                    q6.b(bundle2);
                                }
                            }
                            break;
                        case 4:
                            if (obj == null || (obj instanceof Bundle)) {
                                String string = bundlePeekData == null ? null : bundlePeekData.getString("error");
                                Bundle bundle3 = (Bundle) obj;
                                if (((Q) sparseArray.get(i11)) != null) {
                                    sparseArray.remove(i11);
                                    Q.a(string, bundle3);
                                }
                            }
                            break;
                        case 5:
                            if (obj == null || (obj instanceof Bundle)) {
                                Bundle bundle4 = (Bundle) obj;
                                if (o4.f24142f != 0) {
                                    u4.l(o4, f.e(bundle4));
                                }
                            }
                            break;
                        case 6:
                            if (!(obj instanceof Bundle)) {
                                Log.w("MediaRouteProviderProxy", "No further information on the dynamic group controller");
                            } else {
                                Bundle bundle5 = (Bundle) obj;
                                Q q8 = (Q) sparseArray.get(i11);
                                if (bundle5 != null && bundle5.containsKey("routeId")) {
                                    sparseArray.remove(i11);
                                    q8.b(bundle5);
                                } else {
                                    q8.getClass();
                                    Q.a("DynamicGroupRouteController is created without valid route id.", bundle5);
                                }
                            }
                            break;
                        case 7:
                            if (obj == null || (obj instanceof Bundle)) {
                                Bundle bundle6 = (Bundle) obj;
                                if (o4.f24142f != 0) {
                                    Bundle bundle7 = (Bundle) bundle6.getParcelable("groupRoute");
                                    C1312l c1312l = bundle7 != null ? new C1312l(bundle7) : null;
                                    ArrayList parcelableArrayList = bundle6.getParcelableArrayList("dynamicRoutes");
                                    ArrayList arrayList2 = new ArrayList();
                                    int size2 = parcelableArrayList.size();
                                    int i15 = 0;
                                    while (i15 < size2) {
                                        Object obj2 = parcelableArrayList.get(i15);
                                        i15++;
                                        Bundle bundle8 = (Bundle) obj2;
                                        if (bundle8 == null) {
                                            c1314n = null;
                                        } else {
                                            Bundle bundle9 = bundle8.getBundle("mrDescriptor");
                                            c1314n = new C1314n(bundle9 != null ? new C1312l(bundle9) : null, bundle8.getInt("selectionState", 1), bundle8.getBoolean("isUnselectable", false), bundle8.getBoolean("isGroupable", false), bundle8.getBoolean("isTransferable", false));
                                        }
                                        arrayList2.add(c1314n);
                                    }
                                    if (u4.f24168n == o4) {
                                        if (U.f24163q) {
                                            Log.d("MediaRouteProviderProxy", u4 + ": DynamicRouteDescriptors changed, descriptors=" + arrayList2);
                                        }
                                        int size3 = arrayList.size();
                                        while (true) {
                                            if (i13 < size3) {
                                                Object obj3 = arrayList.get(i13);
                                                i13++;
                                                P p10 = (P) obj3;
                                                if (p10.a() == i12) {
                                                    p8 = p10;
                                                }
                                            } else {
                                                p8 = null;
                                            }
                                        }
                                        if (p8 instanceof S) {
                                            ((S) p8).l(c1312l, arrayList2);
                                        }
                                    }
                                }
                            }
                            break;
                        case 8:
                            if (u4.f24168n == o4) {
                                int size4 = arrayList.size();
                                while (true) {
                                    if (i13 < size4) {
                                        Object obj4 = arrayList.get(i13);
                                        i13++;
                                        P p11 = (P) obj4;
                                        if (p11.a() == i12) {
                                            p9 = p11;
                                        }
                                    } else {
                                        p9 = null;
                                    }
                                }
                                p pVar = u4.f24170p;
                                if (pVar != null && (p9 instanceof AbstractC1316p)) {
                                    AbstractC1316p abstractC1316p = (AbstractC1316p) p9;
                                    C1324y c1324y = (C1324y) ((c) pVar.f19269b).f1188c;
                                    if (c1324y.f24270r == abstractC1316p) {
                                        c1324y.h(c1324y.c(), 2);
                                    }
                                }
                                arrayList.remove(p9);
                                p9.b();
                                u4.o();
                            }
                            break;
                    }
                    if (U.f24163q) {
                        Log.d("MediaRouteProviderProxy", "Unhandled message from server: " + message);
                    }
                }
                break;
        }
    }
}
