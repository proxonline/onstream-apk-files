package p075i;

import I7.b;
import android.app.Activity;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import j$.util.Objects;
import p030d.t;

/* JADX INFO: loaded from: classes.dex */
public abstract class r {
    public static OnBackInvokedDispatcher a(Activity activity) {
        return activity.getOnBackInvokedDispatcher();
    }

    public static OnBackInvokedCallback b(Object obj, w wVar) {
        Objects.requireNonNull(wVar);
        t tVar = new t(1, wVar);
        b.i(obj).registerOnBackInvokedCallback(1000000, tVar);
        return tVar;
    }

    public static void c(Object obj, Object obj2) {
        b.i(obj).unregisterOnBackInvokedCallback(b.e(obj2));
    }
}
