package p075i;

/* JADX INFO: loaded from: classes.dex */
public final class F {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f18955a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f18956b;
}
