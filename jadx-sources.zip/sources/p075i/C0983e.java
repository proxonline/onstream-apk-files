package p075i;

import G6.T;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.appcompat.app.AlertController$RecycleListView;
import androidx.core.widget.NestedScrollView;
import co.notix.R;
import java.lang.ref.WeakReference;
import p067h.a;

/* JADX INFO: renamed from: i.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0983e {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final int f19007A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final int f19008B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final boolean f19009C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final HandlerC0981c f19010D;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f19012a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final DialogInterfaceC0985g f19013b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Window f19014c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f19015d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public AlertController$RecycleListView f19016e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public View f19017f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Button f19019h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public CharSequence f19020i;
    public Message j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Button f19021k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public CharSequence f19022l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Message f19023m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Button f19024n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public CharSequence f19025o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Message f19026p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public NestedScrollView f19027q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Drawable f19028r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public ImageView f19029s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public TextView f19030t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public TextView f19031u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public View f19032v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public ListAdapter f19033w;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f19035y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f19036z;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f19018g = false;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f19034x = -1;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final T f19011E = new T(2, this);

    public C0983e(Context context, DialogInterfaceC0985g dialogInterfaceC0985g, Window window) {
        this.f19012a = context;
        this.f19013b = dialogInterfaceC0985g;
        this.f19014c = window;
        HandlerC0981c handlerC0981c = new HandlerC0981c();
        handlerC0981c.f19006b = new WeakReference(dialogInterfaceC0985g);
        this.f19010D = handlerC0981c;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, a.f18436e, R.attr.alertDialogStyle, 0);
        this.f19035y = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.getResourceId(2, 0);
        this.f19036z = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f19007A = typedArrayObtainStyledAttributes.getResourceId(7, 0);
        this.f19008B = typedArrayObtainStyledAttributes.getResourceId(3, 0);
        this.f19009C = typedArrayObtainStyledAttributes.getBoolean(6, true);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        dialogInterfaceC0985g.e().h(1);
    }

    public static boolean a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    public static ViewGroup b(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    public final void c(int i9, CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
        Message messageObtainMessage = onClickListener != null ? this.f19010D.obtainMessage(i9, onClickListener) : null;
        if (i9 == -3) {
            this.f19025o = charSequence;
            this.f19026p = messageObtainMessage;
        } else if (i9 == -2) {
            this.f19022l = charSequence;
            this.f19023m = messageObtainMessage;
        } else {
            if (i9 != -1) {
                throw new IllegalArgumentException("Button does not exist");
            }
            this.f19020i = charSequence;
            this.j = messageObtainMessage;
        }
    }
}
