package p075i;

import android.R;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertController$RecycleListView;
import p123n.l;

/* JADX INFO: renamed from: i.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0984f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0980b f19037a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f19038b;

    public C0984f(Context context) {
        this(context, DialogInterfaceC0985g.g(context, 0));
    }

    public C0984f(Context context, int i9) {
        this.f19037a = new C0980b(new ContextThemeWrapper(context, DialogInterfaceC0985g.g(context, i9)));
        this.f19038b = i9;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r8v1, types: [android.widget.ListAdapter] */
    /* JADX WARN: Type inference failed for: r8v3 */
    /* JADX WARN: Type inference failed for: r8v4 */
    public DialogInterfaceC0985g create() {
        C0980b c0980b = this.f19037a;
        DialogInterfaceC0985g dialogInterfaceC0985g = new DialogInterfaceC0985g(c0980b.f18991a, this.f19038b);
        View view = c0980b.f18995e;
        C0983e c0983e = dialogInterfaceC0985g.f19039f;
        if (view != null) {
            c0983e.f19032v = view;
        } else {
            CharSequence charSequence = c0980b.f18994d;
            if (charSequence != null) {
                c0983e.f19015d = charSequence;
                TextView textView = c0983e.f19030t;
                if (textView != null) {
                    textView.setText(charSequence);
                }
            }
            Drawable drawable = c0980b.f18993c;
            if (drawable != null) {
                c0983e.f19028r = drawable;
                ImageView imageView = c0983e.f19029s;
                if (imageView != null) {
                    imageView.setVisibility(0);
                    c0983e.f19029s.setImageDrawable(drawable);
                }
            }
        }
        CharSequence charSequence2 = c0980b.f18996f;
        if (charSequence2 != null) {
            c0983e.c(-1, charSequence2, c0980b.f18997g);
        }
        CharSequence charSequence3 = c0980b.f18998h;
        if (charSequence3 != null) {
            c0983e.c(-2, charSequence3, c0980b.f18999i);
        }
        if (c0980b.f19000k != null) {
            AlertController$RecycleListView alertController$RecycleListView = (AlertController$RecycleListView) c0980b.f18992b.inflate(c0983e.f19036z, (ViewGroup) null);
            int i9 = c0980b.f19003n ? c0983e.f19007A : c0983e.f19008B;
            Object obj = c0980b.f19000k;
            ?? c0982d = obj;
            if (obj == null) {
                c0982d = new C0982d(c0980b.f18991a, i9, R.id.text1, null);
            }
            c0983e.f19033w = c0982d;
            c0983e.f19034x = c0980b.f19004o;
            if (c0980b.f19001l != null) {
                alertController$RecycleListView.setOnItemClickListener(new C0979a(c0980b, c0983e));
            }
            if (c0980b.f19003n) {
                alertController$RecycleListView.setChoiceMode(1);
            }
            c0983e.f19016e = alertController$RecycleListView;
        }
        View view2 = c0980b.f19002m;
        if (view2 != null) {
            c0983e.f19017f = view2;
            c0983e.f19018g = false;
        }
        dialogInterfaceC0985g.setCancelable(true);
        dialogInterfaceC0985g.setCanceledOnTouchOutside(true);
        dialogInterfaceC0985g.setOnCancelListener(null);
        dialogInterfaceC0985g.setOnDismissListener(null);
        l lVar = c0980b.j;
        if (lVar != null) {
            dialogInterfaceC0985g.setOnKeyListener(lVar);
        }
        return dialogInterfaceC0985g;
    }

    public Context getContext() {
        return this.f19037a.f18991a;
    }

    public C0984f setNegativeButton(int i9, DialogInterface.OnClickListener onClickListener) {
        C0980b c0980b = this.f19037a;
        c0980b.f18998h = c0980b.f18991a.getText(i9);
        c0980b.f18999i = onClickListener;
        return this;
    }

    public C0984f setPositiveButton(int i9, DialogInterface.OnClickListener onClickListener) {
        C0980b c0980b = this.f19037a;
        c0980b.f18996f = c0980b.f18991a.getText(i9);
        c0980b.f18997g = onClickListener;
        return this;
    }

    public C0984f setTitle(CharSequence charSequence) {
        this.f19037a.f18994d = charSequence;
        return this;
    }

    public C0984f setView(View view) {
        this.f19037a.f19002m = view;
        return this;
    }
}
