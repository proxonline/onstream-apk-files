package p075i;

import android.os.Bundle;
import android.view.View;
import p113m.c;
import p123n.g;
import p123n.k;

/* JADX INFO: loaded from: classes.dex */
public final class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f19064a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f19065b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f19066c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f19067d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public u f19068e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public View f19069f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public View f19070g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public k f19071h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public g f19072i;
    public c j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f19073k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f19074l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f19075m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f19076n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f19077o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Bundle f19078p;
}
