package p075i;

import P.C0307a0;
import P.S;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public final class m implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f19050a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ w f19051b;

    public /* synthetic */ m(w wVar, int i9) {
        this.f19050a = i9;
        this.f19051b = wVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ViewGroup viewGroup;
        switch (this.f19050a) {
            case 0:
                w wVar = this.f19051b;
                if ((wVar.f19123w0 & 1) != 0) {
                    wVar.u(0);
                }
                if ((wVar.f19123w0 & 4096) != 0) {
                    wVar.u(108);
                }
                wVar.f19121v0 = false;
                wVar.f19123w0 = 0;
                break;
            default:
                w wVar2 = this.f19051b;
                wVar2.f19122w.showAtLocation(wVar2.f19120v, 55, 0, 0);
                C0307a0 c0307a0 = wVar2.f19126y;
                if (c0307a0 != null) {
                    c0307a0.b();
                }
                if (wVar2.f19082A && (viewGroup = wVar2.f19084B) != null && viewGroup.isLaidOut()) {
                    wVar2.f19120v.setAlpha(0.0f);
                    C0307a0 c0307a0A = S.a(wVar2.f19120v);
                    c0307a0A.a(1.0f);
                    wVar2.f19126y = c0307a0A;
                    c0307a0A.d(new o(0, this));
                } else {
                    wVar2.f19120v.setAlpha(1.0f);
                    wVar2.f19120v.setVisibility(0);
                }
                break;
        }
    }
}
