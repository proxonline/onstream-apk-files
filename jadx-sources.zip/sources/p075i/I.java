package p075i;

import P.C0307a0;
import P.G;
import P.S;
import P.Y;
import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import com.google.android.gms.internal.measurement.I1;
import java.util.ArrayList;
import java.util.WeakHashMap;
import p036d5.h;
import p067h.a;
import p113m.i;
import p113m.j;
import p133o.InterfaceC1215d;
import p133o.InterfaceC1218e0;
import p133o.U0;

/* JADX INFO: loaded from: classes.dex */
public final class I extends I1 implements InterfaceC1215d {

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public static final AccelerateInterpolator f18964D = new AccelerateInterpolator();

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public static final DecelerateInterpolator f18965E = new DecelerateInterpolator();

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final G f18966A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final G f18967B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final h f18968C;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Context f18969f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Context f18970g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ActionBarOverlayLayout f18971h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public ActionBarContainer f18972i;
    public InterfaceC1218e0 j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public ActionBarContextView f18973k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final View f18974l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f18975m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public H f18976n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public H f18977o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public com.google.android.material.appbar.h f18978p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f18979q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final ArrayList f18980r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f18981s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f18982t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f18983u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f18984v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f18985w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public j f18986x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f18987y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f18988z;

    public I(Activity activity, boolean z9) {
        new ArrayList();
        this.f18980r = new ArrayList();
        this.f18981s = 0;
        this.f18982t = true;
        this.f18985w = true;
        this.f18966A = new G(this, 0);
        this.f18967B = new G(this, 1);
        this.f18968C = new h(6, this);
        View decorView = activity.getWindow().getDecorView();
        Y(decorView);
        if (z9) {
            return;
        }
        this.f18974l = decorView.findViewById(R.id.content);
    }

    public I(Dialog dialog) {
        new ArrayList();
        this.f18980r = new ArrayList();
        this.f18981s = 0;
        this.f18982t = true;
        this.f18985w = true;
        this.f18966A = new G(this, 0);
        this.f18967B = new G(this, 1);
        this.f18968C = new h(6, this);
        Y(dialog.getWindow().getDecorView());
    }

    public final void W(boolean z9) {
        C0307a0 c0307a0I;
        C0307a0 c0307a0I2;
        if (z9) {
            if (!this.f18984v) {
                this.f18984v = true;
                ActionBarOverlayLayout actionBarOverlayLayout = this.f18971h;
                if (actionBarOverlayLayout != null) {
                    actionBarOverlayLayout.setShowingForActionMode(true);
                }
                b0(false);
            }
        } else if (this.f18984v) {
            this.f18984v = false;
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f18971h;
            if (actionBarOverlayLayout2 != null) {
                actionBarOverlayLayout2.setShowingForActionMode(false);
            }
            b0(false);
        }
        if (!this.f18972i.isLaidOut()) {
            if (z9) {
                ((U0) this.j).f21830a.setVisibility(4);
                this.f18973k.setVisibility(0);
                return;
            } else {
                ((U0) this.j).f21830a.setVisibility(0);
                this.f18973k.setVisibility(8);
                return;
            }
        }
        if (z9) {
            U0 u1 = (U0) this.j;
            c0307a0I = S.a(u1.f21830a);
            c0307a0I.a(0.0f);
            c0307a0I.c(100L);
            c0307a0I.d(new i(u1, 4));
            c0307a0I2 = this.f18973k.i(200L, 0);
        } else {
            U0 u4 = (U0) this.j;
            C0307a0 c0307a0A = S.a(u4.f21830a);
            c0307a0A.a(1.0f);
            c0307a0A.c(200L);
            c0307a0A.d(new i(u4, 0));
            c0307a0I = this.f18973k.i(100L, 8);
            c0307a0I2 = c0307a0A;
        }
        j jVar = new j();
        ArrayList arrayList = jVar.f21214a;
        arrayList.add(c0307a0I);
        View view = (View) c0307a0I.f5858a.get();
        long duration = view != null ? view.animate().getDuration() : 0L;
        View view2 = (View) c0307a0I2.f5858a.get();
        if (view2 != null) {
            view2.animate().setStartDelay(duration);
        }
        arrayList.add(c0307a0I2);
        jVar.b();
    }

    public final Context X() {
        if (this.f18970g == null) {
            TypedValue typedValue = new TypedValue();
            this.f18969f.getTheme().resolveAttribute(co.notix.R.attr.actionBarWidgetTheme, typedValue, true);
            int i9 = typedValue.resourceId;
            if (i9 != 0) {
                this.f18970g = new ContextThemeWrapper(this.f18969f, i9);
            } else {
                this.f18970g = this.f18969f;
            }
        }
        return this.f18970g;
    }

    public final void Y(View view) {
        InterfaceC1218e0 wrapper;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(co.notix.R.id.decor_content_parent);
        this.f18971h = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        KeyEvent.Callback callbackFindViewById = view.findViewById(co.notix.R.id.action_bar);
        if (callbackFindViewById instanceof InterfaceC1218e0) {
            wrapper = (InterfaceC1218e0) callbackFindViewById;
        } else {
            if (!(callbackFindViewById instanceof Toolbar)) {
                throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById != null ? callbackFindViewById.getClass().getSimpleName() : "null"));
            }
            wrapper = ((Toolbar) callbackFindViewById).getWrapper();
        }
        this.j = wrapper;
        this.f18973k = (ActionBarContextView) view.findViewById(co.notix.R.id.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(co.notix.R.id.action_bar_container);
        this.f18972i = actionBarContainer;
        InterfaceC1218e0 interfaceC1218e0 = this.j;
        if (interfaceC1218e0 == null || this.f18973k == null || actionBarContainer == null) {
            throw new IllegalStateException(I.class.getSimpleName().concat(" can only be used with a compatible window decor layout"));
        }
        Context context = ((U0) interfaceC1218e0).f21830a.getContext();
        this.f18969f = context;
        if ((((U0) this.j).f21831b & 4) != 0) {
            this.f18975m = true;
        }
        int i9 = context.getApplicationInfo().targetSdkVersion;
        this.j.getClass();
        a0(context.getResources().getBoolean(co.notix.R.bool.abc_action_bar_embed_tabs));
        TypedArray typedArrayObtainStyledAttributes = this.f18969f.obtainStyledAttributes(null, a.f18432a, co.notix.R.attr.actionBarStyle, 0);
        if (typedArrayObtainStyledAttributes.getBoolean(14, false)) {
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f18971h;
            if (!actionBarOverlayLayout2.f10298g) {
                throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
            }
            this.f18988z = true;
            actionBarOverlayLayout2.setHideOnContentScrollEnabled(true);
        }
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, 0);
        if (dimensionPixelSize != 0) {
            ActionBarContainer actionBarContainer2 = this.f18972i;
            WeakHashMap weakHashMap = S.f5835a;
            P.I.k(actionBarContainer2, dimensionPixelSize);
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    public final void Z(boolean z9) {
        if (this.f18975m) {
            return;
        }
        int i9 = z9 ? 4 : 0;
        U0 u1 = (U0) this.j;
        int i10 = u1.f21831b;
        this.f18975m = true;
        u1.a((i9 & 4) | (i10 & (-5)));
    }

    public final void a0(boolean z9) {
        if (z9) {
            this.f18972i.setTabContainer(null);
            ((U0) this.j).getClass();
        } else {
            ((U0) this.j).getClass();
            this.f18972i.setTabContainer(null);
        }
        U0 u1 = (U0) this.j;
        u1.getClass();
        u1.f21830a.setCollapsible(false);
        this.f18971h.setHasNonEmbeddedTabs(false);
    }

    public final void b0(boolean z9) {
        boolean z10 = this.f18983u;
        boolean z11 = this.f18984v;
        h hVar = this.f18968C;
        View view = this.f18974l;
        int i9 = 0;
        if (!z11 && z10) {
            if (this.f18985w) {
                this.f18985w = false;
                j jVar = this.f18986x;
                if (jVar != null) {
                    jVar.a();
                }
                int i10 = this.f18981s;
                G g4 = this.f18966A;
                if (i10 != 0 || (!this.f18987y && !z9)) {
                    g4.a();
                    return;
                }
                this.f18972i.setAlpha(1.0f);
                this.f18972i.setTransitioning(true);
                j jVar2 = new j();
                float f3 = -this.f18972i.getHeight();
                if (z9) {
                    int[] iArr = {0, 0};
                    this.f18972i.getLocationInWindow(iArr);
                    f3 -= iArr[1];
                }
                C0307a0 c0307a0A = S.a(this.f18972i);
                c0307a0A.e(f3);
                View view2 = (View) c0307a0A.f5858a.get();
                if (view2 != null) {
                    view2.animate().setUpdateListener(hVar != null ? new Y(hVar, i9, view2) : null);
                }
                boolean z12 = jVar2.f21218e;
                ArrayList arrayList = jVar2.f21214a;
                if (!z12) {
                    arrayList.add(c0307a0A);
                }
                if (this.f18982t && view != null) {
                    C0307a0 c0307a0A2 = S.a(view);
                    c0307a0A2.e(f3);
                    if (!jVar2.f21218e) {
                        arrayList.add(c0307a0A2);
                    }
                }
                boolean z13 = jVar2.f21218e;
                if (!z13) {
                    jVar2.f21216c = f18964D;
                }
                if (!z13) {
                    jVar2.f21215b = 250L;
                }
                if (!z13) {
                    jVar2.f21217d = g4;
                }
                this.f18986x = jVar2;
                jVar2.b();
                return;
            }
            return;
        }
        if (this.f18985w) {
            return;
        }
        this.f18985w = true;
        j jVar3 = this.f18986x;
        if (jVar3 != null) {
            jVar3.a();
        }
        this.f18972i.setVisibility(0);
        int i11 = this.f18981s;
        G g9 = this.f18967B;
        if (i11 == 0 && (this.f18987y || z9)) {
            this.f18972i.setTranslationY(0.0f);
            float f9 = -this.f18972i.getHeight();
            if (z9) {
                int[] iArr2 = {0, 0};
                this.f18972i.getLocationInWindow(iArr2);
                f9 -= iArr2[1];
            }
            this.f18972i.setTranslationY(f9);
            j jVar4 = new j();
            C0307a0 c0307a0A3 = S.a(this.f18972i);
            c0307a0A3.e(0.0f);
            View view3 = (View) c0307a0A3.f5858a.get();
            if (view3 != null) {
                view3.animate().setUpdateListener(hVar != null ? new Y(hVar, i9, view3) : null);
            }
            boolean z14 = jVar4.f21218e;
            ArrayList arrayList2 = jVar4.f21214a;
            if (!z14) {
                arrayList2.add(c0307a0A3);
            }
            if (this.f18982t && view != null) {
                view.setTranslationY(f9);
                C0307a0 c0307a0A4 = S.a(view);
                c0307a0A4.e(0.0f);
                if (!jVar4.f21218e) {
                    arrayList2.add(c0307a0A4);
                }
            }
            boolean z15 = jVar4.f21218e;
            if (!z15) {
                jVar4.f21216c = f18965E;
            }
            if (!z15) {
                jVar4.f21215b = 250L;
            }
            if (!z15) {
                jVar4.f21217d = g9;
            }
            this.f18986x = jVar4;
            jVar4.b();
        } else {
            this.f18972i.setAlpha(1.0f);
            this.f18972i.setTranslationY(0.0f);
            if (this.f18982t && view != null) {
                view.setTranslationY(0.0f);
            }
            g9.a();
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f18971h;
        if (actionBarOverlayLayout != null) {
            WeakHashMap weakHashMap = S.f5835a;
            G.c(actionBarOverlayLayout);
        }
    }
}
