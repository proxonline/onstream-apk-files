package p075i;

import D.A;
import D.d;
import G.b;
import H0.E;
import K4.g;
import L.f;
import O0.a;
import android.R;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import j$.util.Objects;
import p047e7.C0871a;
import p085j0.B;
import p113m.c;
import p113m.h;
import p113m.j;
import p133o.C1246t;
import p133o.U0;
import p133o.Z0;

/* JADX INFO: renamed from: i.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractActivityC0986h extends B implements InterfaceC0987i {

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public w f19040y;

    public AbstractActivityC0986h() {
        ((g) this.f16595e.f3795c).E("androidx:appcompat", new a(this));
        P(new C0871a(this, 1));
    }

    public final l T() {
        if (this.f19040y == null) {
            E e9 = l.f19041a;
            this.f19040y = new w(this, null, this, this);
        }
        return this.f19040y;
    }

    @Override // p030d.k, android.app.Activity
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        Q();
        w wVar = (w) T();
        wVar.v();
        ((ViewGroup) wVar.f19084B.findViewById(R.id.content)).addView(view, layoutParams);
        wVar.f19102m.a(wVar.f19100l.getCallback());
    }

    /* JADX WARN: Code duplicated, block: B:102:0x0181  */
    /* JADX WARN: Code duplicated, block: B:104:0x018f  */
    /* JADX WARN: Code duplicated, block: B:107:0x01ab  */
    /* JADX WARN: Code duplicated, block: B:110:0x01c3  */
    /* JADX WARN: Code duplicated, block: B:113:0x01d2  */
    /* JADX WARN: Code duplicated, block: B:116:0x01dd  */
    /* JADX WARN: Code duplicated, block: B:119:0x01e5  */
    /* JADX WARN: Code duplicated, block: B:122:0x01ed  */
    /* JADX WARN: Code duplicated, block: B:125:0x01f5  */
    /* JADX WARN: Code duplicated, block: B:129:0x020c  */
    /* JADX WARN: Code duplicated, block: B:44:0x0095  */
    /* JADX WARN: Code duplicated, block: B:47:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:50:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:52:0x00d0  */
    /* JADX WARN: Code duplicated, block: B:55:0x00df  */
    /* JADX WARN: Code duplicated, block: B:57:0x00e7  */
    /* JADX WARN: Code duplicated, block: B:60:0x00ef  */
    /* JADX WARN: Code duplicated, block: B:63:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:66:0x00ff  */
    /* JADX WARN: Code duplicated, block: B:67:0x0103  */
    /* JADX WARN: Code duplicated, block: B:69:0x010d  */
    /* JADX WARN: Code duplicated, block: B:72:0x0117  */
    /* JADX WARN: Code duplicated, block: B:75:0x011f  */
    /* JADX WARN: Code duplicated, block: B:78:0x0127  */
    /* JADX WARN: Code duplicated, block: B:81:0x012f  */
    /* JADX WARN: Code duplicated, block: B:84:0x0137  */
    /* JADX WARN: Code duplicated, block: B:87:0x013f  */
    /* JADX WARN: Code duplicated, block: B:90:0x014b  */
    /* JADX WARN: Code duplicated, block: B:93:0x015a  */
    /* JADX WARN: Code duplicated, block: B:96:0x0169  */
    /* JADX WARN: Code duplicated, block: B:99:0x0178  */
    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public final void attachBaseContext(Context context) {
        Configuration configuration;
        Configuration configuration2;
        c cVar;
        float f3;
        float f9;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        int i24;
        int i25;
        int i26;
        int i27;
        int i28;
        int i29;
        int i30;
        int i31;
        int i32;
        int i33;
        int i34;
        int i35;
        int i36;
        int i37;
        int i38;
        int i39;
        int i40;
        int i41;
        int i42;
        int i43;
        int i44;
        int i45;
        w wVar = (w) T();
        wVar.f19101l0 = true;
        int i46 = wVar.f19109p0;
        if (i46 == -100) {
            i46 = l.f19042b;
        }
        int iC = wVar.C(context, i46);
        if (l.b(context) && l.b(context)) {
            if (Build.VERSION.SDK_INT < 33) {
                synchronized (l.f19049i) {
                    try {
                        f fVar = l.f19043c;
                        if (fVar == null) {
                            if (l.f19044d == null) {
                                l.f19044d = f.b(d.e(context));
                            }
                            if (!l.f19044d.f3871a.isEmpty()) {
                                l.f19043c = l.f19044d;
                            }
                        } else if (!fVar.equals(l.f19044d)) {
                            f fVar2 = l.f19043c;
                            l.f19044d = fVar2;
                            d.d(context, fVar2.f3871a.a());
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            } else if (!l.f19046f) {
                l.f19041a.execute(new E0.g(context, 2));
            }
        }
        f fVarO = w.o(context);
        Configuration configuration3 = null;
        if (context instanceof ContextThemeWrapper) {
            try {
                ((ContextThemeWrapper) context).applyOverrideConfiguration(w.s(context, iC, fVarO, null, false));
            } catch (IllegalStateException unused) {
                if (context instanceof c) {
                    try {
                        ((c) context).a(w.s(context, iC, fVarO, null, false));
                    } catch (IllegalStateException unused2) {
                        if (w.f19081G0) {
                            Configuration configuration4 = new Configuration();
                            configuration4.uiMode = -1;
                            configuration4.fontScale = 0.0f;
                            configuration = context.createConfigurationContext(configuration4).getResources().getConfiguration();
                            configuration2 = context.getResources().getConfiguration();
                            configuration.uiMode = configuration2.uiMode;
                            if (!configuration.equals(configuration2)) {
                                configuration3 = new Configuration();
                                configuration3.fontScale = 0.0f;
                                if (configuration.diff(configuration2) != 0) {
                                    f3 = configuration.fontScale;
                                    f9 = configuration2.fontScale;
                                    if (f3 != f9) {
                                        configuration3.fontScale = f9;
                                    }
                                    i9 = configuration.mcc;
                                    i10 = configuration2.mcc;
                                    if (i9 != i10) {
                                        configuration3.mcc = i10;
                                    }
                                    i11 = configuration.mnc;
                                    i12 = configuration2.mnc;
                                    if (i11 != i12) {
                                        configuration3.mnc = i12;
                                    }
                                    i13 = Build.VERSION.SDK_INT;
                                    if (i13 >= 24) {
                                        q.a(configuration, configuration2, configuration3);
                                    } else if (!Objects.equals(configuration.locale, configuration2.locale)) {
                                        configuration3.locale = configuration2.locale;
                                    }
                                    i14 = configuration.touchscreen;
                                    i15 = configuration2.touchscreen;
                                    if (i14 != i15) {
                                        configuration3.touchscreen = i15;
                                    }
                                    i16 = configuration.keyboard;
                                    i17 = configuration2.keyboard;
                                    if (i16 != i17) {
                                        configuration3.keyboard = i17;
                                    }
                                    i18 = configuration.keyboardHidden;
                                    i19 = configuration2.keyboardHidden;
                                    if (i18 != i19) {
                                        configuration3.keyboardHidden = i19;
                                    }
                                    i20 = configuration.navigation;
                                    i21 = configuration2.navigation;
                                    if (i20 != i21) {
                                        configuration3.navigation = i21;
                                    }
                                    i22 = configuration.navigationHidden;
                                    i23 = configuration2.navigationHidden;
                                    if (i22 != i23) {
                                        configuration3.navigationHidden = i23;
                                    }
                                    i24 = configuration.orientation;
                                    i25 = configuration2.orientation;
                                    if (i24 != i25) {
                                        configuration3.orientation = i25;
                                    }
                                    i26 = configuration.screenLayout & 15;
                                    i27 = configuration2.screenLayout & 15;
                                    if (i26 != i27) {
                                        configuration3.screenLayout |= i27;
                                    }
                                    i28 = configuration.screenLayout & 192;
                                    i29 = configuration2.screenLayout & 192;
                                    if (i28 != i29) {
                                        configuration3.screenLayout |= i29;
                                    }
                                    i30 = configuration.screenLayout & 48;
                                    i31 = configuration2.screenLayout & 48;
                                    if (i30 != i31) {
                                        configuration3.screenLayout |= i31;
                                    }
                                    i32 = configuration.screenLayout & 768;
                                    i33 = configuration2.screenLayout & 768;
                                    if (i32 != i33) {
                                        configuration3.screenLayout |= i33;
                                    }
                                    if (i13 >= 26) {
                                        if ((configuration.colorMode & 3) != (configuration2.colorMode & 3)) {
                                            configuration3.colorMode |= configuration2.colorMode & 3;
                                        }
                                        if ((configuration.colorMode & 12) != (configuration2.colorMode & 12)) {
                                            configuration3.colorMode |= configuration2.colorMode & 12;
                                        }
                                    }
                                    i34 = configuration.uiMode & 15;
                                    i35 = configuration2.uiMode & 15;
                                    if (i34 != i35) {
                                        configuration3.uiMode |= i35;
                                    }
                                    i36 = configuration.uiMode & 48;
                                    i37 = configuration2.uiMode & 48;
                                    if (i36 != i37) {
                                        configuration3.uiMode |= i37;
                                    }
                                    i38 = configuration.screenWidthDp;
                                    i39 = configuration2.screenWidthDp;
                                    if (i38 != i39) {
                                        configuration3.screenWidthDp = i39;
                                    }
                                    i40 = configuration.screenHeightDp;
                                    i41 = configuration2.screenHeightDp;
                                    if (i40 != i41) {
                                        configuration3.screenHeightDp = i41;
                                    }
                                    i42 = configuration.smallestScreenWidthDp;
                                    i43 = configuration2.smallestScreenWidthDp;
                                    if (i42 != i43) {
                                        configuration3.smallestScreenWidthDp = i43;
                                    }
                                    i44 = configuration.densityDpi;
                                    i45 = configuration2.densityDpi;
                                    if (i44 != i45) {
                                        configuration3.densityDpi = i45;
                                    }
                                }
                            }
                            Configuration configurationS = w.s(context, iC, fVarO, configuration3, true);
                            cVar = new c(context, co.notix.R.style.Theme_AppCompat_Empty);
                            cVar.a(configurationS);
                            try {
                                if (context.getTheme() != null) {
                                    b.l(cVar.getTheme());
                                }
                            } catch (NullPointerException unused3) {
                            }
                            context = cVar;
                        }
                    }
                } else if (w.f19081G0) {
                    Configuration configuration5 = new Configuration();
                    configuration5.uiMode = -1;
                    configuration5.fontScale = 0.0f;
                    configuration = context.createConfigurationContext(configuration5).getResources().getConfiguration();
                    configuration2 = context.getResources().getConfiguration();
                    configuration.uiMode = configuration2.uiMode;
                    if (!configuration.equals(configuration2)) {
                        configuration3 = new Configuration();
                        configuration3.fontScale = 0.0f;
                        if (configuration.diff(configuration2) != 0) {
                            f3 = configuration.fontScale;
                            f9 = configuration2.fontScale;
                            if (f3 != f9) {
                                configuration3.fontScale = f9;
                            }
                            i9 = configuration.mcc;
                            i10 = configuration2.mcc;
                            if (i9 != i10) {
                                configuration3.mcc = i10;
                            }
                            i11 = configuration.mnc;
                            i12 = configuration2.mnc;
                            if (i11 != i12) {
                                configuration3.mnc = i12;
                            }
                            i13 = Build.VERSION.SDK_INT;
                            if (i13 >= 24) {
                                q.a(configuration, configuration2, configuration3);
                            } else if (!Objects.equals(configuration.locale, configuration2.locale)) {
                                configuration3.locale = configuration2.locale;
                            }
                            i14 = configuration.touchscreen;
                            i15 = configuration2.touchscreen;
                            if (i14 != i15) {
                                configuration3.touchscreen = i15;
                            }
                            i16 = configuration.keyboard;
                            i17 = configuration2.keyboard;
                            if (i16 != i17) {
                                configuration3.keyboard = i17;
                            }
                            i18 = configuration.keyboardHidden;
                            i19 = configuration2.keyboardHidden;
                            if (i18 != i19) {
                                configuration3.keyboardHidden = i19;
                            }
                            i20 = configuration.navigation;
                            i21 = configuration2.navigation;
                            if (i20 != i21) {
                                configuration3.navigation = i21;
                            }
                            i22 = configuration.navigationHidden;
                            i23 = configuration2.navigationHidden;
                            if (i22 != i23) {
                                configuration3.navigationHidden = i23;
                            }
                            i24 = configuration.orientation;
                            i25 = configuration2.orientation;
                            if (i24 != i25) {
                                configuration3.orientation = i25;
                            }
                            i26 = configuration.screenLayout & 15;
                            i27 = configuration2.screenLayout & 15;
                            if (i26 != i27) {
                                configuration3.screenLayout |= i27;
                            }
                            i28 = configuration.screenLayout & 192;
                            i29 = configuration2.screenLayout & 192;
                            if (i28 != i29) {
                                configuration3.screenLayout |= i29;
                            }
                            i30 = configuration.screenLayout & 48;
                            i31 = configuration2.screenLayout & 48;
                            if (i30 != i31) {
                                configuration3.screenLayout |= i31;
                            }
                            i32 = configuration.screenLayout & 768;
                            i33 = configuration2.screenLayout & 768;
                            if (i32 != i33) {
                                configuration3.screenLayout |= i33;
                            }
                            if (i13 >= 26) {
                                if ((configuration.colorMode & 3) != (configuration2.colorMode & 3)) {
                                    configuration3.colorMode |= configuration2.colorMode & 3;
                                }
                                if ((configuration.colorMode & 12) != (configuration2.colorMode & 12)) {
                                    configuration3.colorMode |= configuration2.colorMode & 12;
                                }
                            }
                            i34 = configuration.uiMode & 15;
                            i35 = configuration2.uiMode & 15;
                            if (i34 != i35) {
                                configuration3.uiMode |= i35;
                            }
                            i36 = configuration.uiMode & 48;
                            i37 = configuration2.uiMode & 48;
                            if (i36 != i37) {
                                configuration3.uiMode |= i37;
                            }
                            i38 = configuration.screenWidthDp;
                            i39 = configuration2.screenWidthDp;
                            if (i38 != i39) {
                                configuration3.screenWidthDp = i39;
                            }
                            i40 = configuration.screenHeightDp;
                            i41 = configuration2.screenHeightDp;
                            if (i40 != i41) {
                                configuration3.screenHeightDp = i41;
                            }
                            i42 = configuration.smallestScreenWidthDp;
                            i43 = configuration2.smallestScreenWidthDp;
                            if (i42 != i43) {
                                configuration3.smallestScreenWidthDp = i43;
                            }
                            i44 = configuration.densityDpi;
                            i45 = configuration2.densityDpi;
                            if (i44 != i45) {
                                configuration3.densityDpi = i45;
                            }
                        }
                    }
                    Configuration configurationS2 = w.s(context, iC, fVarO, configuration3, true);
                    cVar = new c(context, co.notix.R.style.Theme_AppCompat_Empty);
                    cVar.a(configurationS2);
                    if (context.getTheme() != null) {
                        b.l(cVar.getTheme());
                    }
                    context = cVar;
                }
            }
        } else if (context instanceof c) {
            ((c) context).a(w.s(context, iC, fVarO, null, false));
        } else if (w.f19081G0) {
            Configuration configuration6 = new Configuration();
            configuration6.uiMode = -1;
            configuration6.fontScale = 0.0f;
            configuration = context.createConfigurationContext(configuration6).getResources().getConfiguration();
            configuration2 = context.getResources().getConfiguration();
            configuration.uiMode = configuration2.uiMode;
            if (!configuration.equals(configuration2)) {
                configuration3 = new Configuration();
                configuration3.fontScale = 0.0f;
                if (configuration.diff(configuration2) != 0) {
                    f3 = configuration.fontScale;
                    f9 = configuration2.fontScale;
                    if (f3 != f9) {
                        configuration3.fontScale = f9;
                    }
                    i9 = configuration.mcc;
                    i10 = configuration2.mcc;
                    if (i9 != i10) {
                        configuration3.mcc = i10;
                    }
                    i11 = configuration.mnc;
                    i12 = configuration2.mnc;
                    if (i11 != i12) {
                        configuration3.mnc = i12;
                    }
                    i13 = Build.VERSION.SDK_INT;
                    if (i13 >= 24) {
                        q.a(configuration, configuration2, configuration3);
                    } else if (!Objects.equals(configuration.locale, configuration2.locale)) {
                        configuration3.locale = configuration2.locale;
                    }
                    i14 = configuration.touchscreen;
                    i15 = configuration2.touchscreen;
                    if (i14 != i15) {
                        configuration3.touchscreen = i15;
                    }
                    i16 = configuration.keyboard;
                    i17 = configuration2.keyboard;
                    if (i16 != i17) {
                        configuration3.keyboard = i17;
                    }
                    i18 = configuration.keyboardHidden;
                    i19 = configuration2.keyboardHidden;
                    if (i18 != i19) {
                        configuration3.keyboardHidden = i19;
                    }
                    i20 = configuration.navigation;
                    i21 = configuration2.navigation;
                    if (i20 != i21) {
                        configuration3.navigation = i21;
                    }
                    i22 = configuration.navigationHidden;
                    i23 = configuration2.navigationHidden;
                    if (i22 != i23) {
                        configuration3.navigationHidden = i23;
                    }
                    i24 = configuration.orientation;
                    i25 = configuration2.orientation;
                    if (i24 != i25) {
                        configuration3.orientation = i25;
                    }
                    i26 = configuration.screenLayout & 15;
                    i27 = configuration2.screenLayout & 15;
                    if (i26 != i27) {
                        configuration3.screenLayout |= i27;
                    }
                    i28 = configuration.screenLayout & 192;
                    i29 = configuration2.screenLayout & 192;
                    if (i28 != i29) {
                        configuration3.screenLayout |= i29;
                    }
                    i30 = configuration.screenLayout & 48;
                    i31 = configuration2.screenLayout & 48;
                    if (i30 != i31) {
                        configuration3.screenLayout |= i31;
                    }
                    i32 = configuration.screenLayout & 768;
                    i33 = configuration2.screenLayout & 768;
                    if (i32 != i33) {
                        configuration3.screenLayout |= i33;
                    }
                    if (i13 >= 26) {
                        if ((configuration.colorMode & 3) != (configuration2.colorMode & 3)) {
                            configuration3.colorMode |= configuration2.colorMode & 3;
                        }
                        if ((configuration.colorMode & 12) != (configuration2.colorMode & 12)) {
                            configuration3.colorMode |= configuration2.colorMode & 12;
                        }
                    }
                    i34 = configuration.uiMode & 15;
                    i35 = configuration2.uiMode & 15;
                    if (i34 != i35) {
                        configuration3.uiMode |= i35;
                    }
                    i36 = configuration.uiMode & 48;
                    i37 = configuration2.uiMode & 48;
                    if (i36 != i37) {
                        configuration3.uiMode |= i37;
                    }
                    i38 = configuration.screenWidthDp;
                    i39 = configuration2.screenWidthDp;
                    if (i38 != i39) {
                        configuration3.screenWidthDp = i39;
                    }
                    i40 = configuration.screenHeightDp;
                    i41 = configuration2.screenHeightDp;
                    if (i40 != i41) {
                        configuration3.screenHeightDp = i41;
                    }
                    i42 = configuration.smallestScreenWidthDp;
                    i43 = configuration2.smallestScreenWidthDp;
                    if (i42 != i43) {
                        configuration3.smallestScreenWidthDp = i43;
                    }
                    i44 = configuration.densityDpi;
                    i45 = configuration2.densityDpi;
                    if (i44 != i45) {
                        configuration3.densityDpi = i45;
                    }
                }
            }
            Configuration configurationS3 = w.s(context, iC, fVarO, configuration3, true);
            cVar = new c(context, co.notix.R.style.Theme_AppCompat_Empty);
            cVar.a(configurationS3);
            if (context.getTheme() != null) {
                b.l(cVar.getTheme());
            }
            context = cVar;
        }
        super.attachBaseContext(context);
    }

    @Override // android.app.Activity
    public final void closeOptionsMenu() {
        ((w) T()).A();
        if (getWindow().hasFeature(0)) {
            super.closeOptionsMenu();
        }
    }

    @Override // D.f, android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        keyEvent.getKeyCode();
        ((w) T()).A();
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Activity
    public final View findViewById(int i9) {
        w wVar = (w) T();
        wVar.v();
        return wVar.f19100l.findViewById(i9);
    }

    @Override // android.app.Activity
    public final MenuInflater getMenuInflater() {
        w wVar = (w) T();
        if (wVar.f19108p == null) {
            wVar.A();
            I i9 = wVar.f19106o;
            wVar.f19108p = new h(i9 != null ? i9.X() : wVar.f19098k);
        }
        return wVar.f19108p;
    }

    @Override // android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final Resources getResources() {
        int i9 = Z0.f21865a;
        return super.getResources();
    }

    @Override // android.app.Activity
    public final void invalidateOptionsMenu() {
        w wVar = (w) T();
        if (wVar.f19106o != null) {
            wVar.A();
            wVar.f19106o.getClass();
            wVar.B(0);
        }
    }

    @Override // p030d.k, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        w wVar = (w) T();
        if (wVar.Z && wVar.f19082A) {
            wVar.A();
            I i9 = wVar.f19106o;
            if (i9 != null) {
                i9.a0(i9.f18969f.getResources().getBoolean(co.notix.R.bool.abc_action_bar_embed_tabs));
            }
        }
        C1246t c1246tA = C1246t.a();
        Context context = wVar.f19098k;
        synchronized (c1246tA) {
            c1246tA.f21980a.l(context);
        }
        wVar.f19107o0 = new Configuration(wVar.f19098k.getResources().getConfiguration());
        wVar.m(false, false);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onContentChanged() {
    }

    @Override // p085j0.B, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        T().e();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i9, KeyEvent keyEvent) {
        Window window;
        if (Build.VERSION.SDK_INT >= 26 || keyEvent.isCtrlPressed() || KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState()) || keyEvent.getRepeatCount() != 0 || KeyEvent.isModifierKey(keyEvent.getKeyCode()) || (window = getWindow()) == null || window.getDecorView() == null || !window.getDecorView().dispatchKeyShortcutEvent(keyEvent)) {
            return super.onKeyDown(i9, keyEvent);
        }
        return true;
    }

    @Override // p085j0.B, p030d.k, android.app.Activity, android.view.Window.Callback
    public final boolean onMenuItemSelected(int i9, MenuItem menuItem) {
        Intent intentB;
        if (!super.onMenuItemSelected(i9, menuItem)) {
            w wVar = (w) T();
            wVar.A();
            I i10 = wVar.f19106o;
            if (menuItem.getItemId() != 16908332 || i10 == null || (((U0) i10.j).f21831b & 4) == 0 || (intentB = d.b(this)) == null) {
                return false;
            }
            if (!shouldUpRecreateTask(intentB)) {
                navigateUpTo(intentB);
                return true;
            }
            A a10 = new A(this);
            Intent intentB2 = d.b(this);
            if (intentB2 == null) {
                intentB2 = d.b(this);
            }
            if (intentB2 != null) {
                ComponentName component = intentB2.getComponent();
                if (component == null) {
                    component = intentB2.resolveActivity(a10.f869b.getPackageManager());
                }
                a10.e(component);
                a10.f868a.add(intentB2);
            }
            a10.g();
            try {
                finishAffinity();
            } catch (IllegalStateException unused) {
                finish();
            }
        }
        return true;
    }

    @Override // android.app.Activity
    public final void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((w) T()).v();
    }

    @Override // p085j0.B, android.app.Activity
    public final void onPostResume() {
        super.onPostResume();
        w wVar = (w) T();
        wVar.A();
        I i9 = wVar.f19106o;
        if (i9 != null) {
            i9.f18987y = true;
        }
    }

    @Override // p085j0.B, android.app.Activity
    public final void onStart() {
        super.onStart();
        ((w) T()).m(true, false);
    }

    @Override // p085j0.B, android.app.Activity
    public final void onStop() {
        super.onStop();
        w wVar = (w) T();
        wVar.A();
        I i9 = wVar.f19106o;
        if (i9 != null) {
            i9.f18987y = false;
            j jVar = i9.f18986x;
            if (jVar != null) {
                jVar.a();
            }
        }
    }

    @Override // android.app.Activity
    public final void onTitleChanged(CharSequence charSequence, int i9) {
        super.onTitleChanged(charSequence, i9);
        T().l(charSequence);
    }

    @Override // android.app.Activity
    public final void openOptionsMenu() {
        ((w) T()).A();
        if (getWindow().hasFeature(0)) {
            super.openOptionsMenu();
        }
    }

    @Override // p030d.k, android.app.Activity
    public final void setContentView(int i9) {
        Q();
        T().i(i9);
    }

    @Override // p030d.k, android.app.Activity
    public void setContentView(View view) {
        Q();
        T().j(view);
    }

    @Override // p030d.k, android.app.Activity
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        Q();
        T().k(view, layoutParams);
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final void setTheme(int i9) {
        super.setTheme(i9);
        ((w) T()).f19111q0 = i9;
    }
}
