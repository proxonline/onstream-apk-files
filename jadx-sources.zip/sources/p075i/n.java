package p075i;

import H.c;
import P.G;
import P.InterfaceC0323p;
import P.J;
import P.S;
import P.j0;
import P.k0;
import P.l0;
import P.m0;
import P.n0;
import P.x0;
import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import androidx.appcompat.widget.ActionBarContextView;
import co.notix.R;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import p123n.k;
import p123n.v;
import p133o.b1;
import p133o.c1;

/* JADX INFO: loaded from: classes.dex */
public final class n implements InterfaceC0323p, v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ w f19052a;

    public /* synthetic */ n(w wVar) {
        this.f19052a = wVar;
    }

    @Override // p123n.v
    public void c(k kVar, boolean z9) {
        v vVar;
        k kVarK = kVar.k();
        int i9 = 0;
        boolean z10 = kVarK != kVar;
        if (z10) {
            kVar = kVarK;
        }
        w wVar = this.f19052a;
        v[] vVarArr = wVar.f19096i0;
        int length = vVarArr != null ? vVarArr.length : 0;
        while (true) {
            if (i9 < length) {
                vVar = vVarArr[i9];
                if (vVar != null && vVar.f19071h == kVar) {
                    break;
                } else {
                    i9++;
                }
            } else {
                vVar = null;
                break;
            }
        }
        if (vVar != null) {
            if (!z10) {
                wVar.r(vVar, z9);
            } else {
                wVar.p(vVar.f19064a, vVar, kVarK);
                wVar.r(vVar, true);
            }
        }
    }

    @Override // p123n.v
    public boolean m(k kVar) {
        Window.Callback callback;
        if (kVar != kVar.k()) {
            return true;
        }
        w wVar = this.f19052a;
        if (!wVar.Z || (callback = wVar.f19100l.getCallback()) == null || wVar.f19105n0) {
            return true;
        }
        callback.onMenuOpened(108, kVar);
        return true;
    }

    @Override // P.InterfaceC0323p
    public x0 u(View view, x0 x0Var) {
        int i9;
        int i10;
        boolean z9;
        x0 x0VarB;
        n0 k0Var;
        boolean z10;
        boolean z11;
        boolean z12;
        int iD = x0Var.d();
        w wVar = this.f19052a;
        Context context = wVar.f19098k;
        int iD2 = x0Var.d();
        ActionBarContextView actionBarContextView = wVar.f19120v;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            i9 = 8;
            i10 = 0;
            z9 = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) wVar.f19120v.getLayoutParams();
            if (wVar.f19120v.isShown()) {
                if (wVar.f19129z0 == null) {
                    wVar.f19129z0 = new Rect();
                    wVar.f19083A0 = new Rect();
                }
                Rect rect = wVar.f19129z0;
                Rect rect2 = wVar.f19083A0;
                rect.set(x0Var.b(), x0Var.d(), x0Var.c(), x0Var.a());
                ViewGroup viewGroup = wVar.f19084B;
                if (Build.VERSION.SDK_INT >= 29) {
                    boolean z13 = c1.f21887a;
                    b1.a(viewGroup, rect, rect2);
                    z11 = true;
                } else {
                    if (!c1.f21887a) {
                        c1.f21887a = true;
                        try {
                            Method declaredMethod = View.class.getDeclaredMethod("computeFitSystemWindows", Rect.class, Rect.class);
                            c1.f21888b = declaredMethod;
                            if (!declaredMethod.isAccessible()) {
                                c1.f21888b.setAccessible(true);
                            }
                        } catch (NoSuchMethodException unused) {
                            Log.d("ViewUtils", "Could not find method computeFitSystemWindows. Oh well.");
                        }
                    }
                    Method method = c1.f21888b;
                    if (method != null) {
                        try {
                            Object[] objArr = new Object[2];
                            objArr[0] = rect;
                            z11 = true;
                            try {
                                objArr[1] = rect2;
                                method.invoke(viewGroup, objArr);
                            } catch (Exception e9) {
                                e = e9;
                                Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", e);
                            }
                        } catch (Exception e10) {
                            e = e10;
                            z11 = true;
                        }
                    } else {
                        z11 = true;
                    }
                }
                int i11 = rect.top;
                int i12 = rect.left;
                int i13 = rect.right;
                ViewGroup viewGroup2 = wVar.f19084B;
                WeakHashMap weakHashMap = S.f5835a;
                x0 x0VarA = J.a(viewGroup2);
                int iB = x0VarA == null ? 0 : x0VarA.b();
                int iC = x0VarA == null ? 0 : x0VarA.c();
                if (marginLayoutParams.topMargin == i11 && marginLayoutParams.leftMargin == i12 && marginLayoutParams.rightMargin == i13) {
                    z12 = false;
                } else {
                    marginLayoutParams.topMargin = i11;
                    marginLayoutParams.leftMargin = i12;
                    marginLayoutParams.rightMargin = i13;
                    z12 = z11;
                }
                if (i11 <= 0 || wVar.f19088D != null) {
                    i9 = 8;
                    View view2 = wVar.f19088D;
                    if (view2 != null) {
                        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view2.getLayoutParams();
                        int i14 = marginLayoutParams2.height;
                        int i15 = marginLayoutParams.topMargin;
                        if (i14 != i15 || marginLayoutParams2.leftMargin != iB || marginLayoutParams2.rightMargin != iC) {
                            marginLayoutParams2.height = i15;
                            marginLayoutParams2.leftMargin = iB;
                            marginLayoutParams2.rightMargin = iC;
                            wVar.f19088D.setLayoutParams(marginLayoutParams2);
                        }
                    }
                } else {
                    View view3 = new View(context);
                    wVar.f19088D = view3;
                    i9 = 8;
                    view3.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                    layoutParams.leftMargin = iB;
                    layoutParams.rightMargin = iC;
                    wVar.f19084B.addView(wVar.f19088D, -1, layoutParams);
                }
                View view4 = wVar.f19088D;
                boolean z14 = view4 != null ? z11 : false;
                if (z14 && view4.getVisibility() != 0) {
                    View view5 = wVar.f19088D;
                    view5.setBackgroundColor((view5.getWindowSystemUiVisibility() & 8192) != 0 ? context.getColor(R.color.abc_decor_view_status_guard_light) : context.getColor(R.color.abc_decor_view_status_guard));
                }
                if (!wVar.f19092e0 && z14) {
                    iD2 = 0;
                }
                z10 = z12;
                z9 = z14;
                i10 = 0;
            } else {
                z10 = true;
                i9 = 8;
                i10 = 0;
                if (marginLayoutParams.topMargin != 0) {
                    marginLayoutParams.topMargin = 0;
                    z9 = false;
                } else {
                    z9 = false;
                    z10 = false;
                }
            }
            if (z10) {
                wVar.f19120v.setLayoutParams(marginLayoutParams);
            }
        }
        View view6 = wVar.f19088D;
        if (view6 != null) {
            if (z9) {
                i9 = i10;
            }
            view6.setVisibility(i9);
        }
        if (iD != iD2) {
            int iB2 = x0Var.b();
            int iC2 = x0Var.c();
            int iA = x0Var.a();
            int i16 = Build.VERSION.SDK_INT;
            if (i16 >= 34) {
                k0Var = new m0(x0Var);
            } else if (i16 >= 30) {
                k0Var = new l0(x0Var);
            } else {
                k0Var = i16 >= 29 ? new k0(x0Var) : new j0(x0Var);
            }
            k0Var.g(c.b(iB2, iD2, iC2, iA));
            x0VarB = k0Var.b();
        } else {
            x0VarB = x0Var;
        }
        WeakHashMap weakHashMap2 = S.f5835a;
        WindowInsets windowInsetsF = x0VarB.f();
        if (windowInsetsF == null) {
            return x0VarB;
        }
        WindowInsets windowInsetsB = G.b(view, windowInsetsF);
        return !windowInsetsB.equals(windowInsetsF) ? x0.g(view, windowInsetsB) : x0VarB;
    }
}
