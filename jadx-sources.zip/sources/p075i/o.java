package p075i;

import P.G;
import P.S;
import T8.l;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import com.google.android.material.appbar.h;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class o extends l {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ int f19053h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ Object f19054i;

    public /* synthetic */ o(int i9, Object obj) {
        this.f19053h = i9;
        this.f19054i = obj;
    }

    @Override // P.InterfaceC0309b0
    public final void a() {
        int i9 = this.f19053h;
        Object obj = this.f19054i;
        switch (i9) {
            case 0:
                w wVar = ((m) obj).f19051b;
                wVar.f19120v.setAlpha(1.0f);
                wVar.f19126y.d(null);
                wVar.f19126y = null;
                break;
            case 1:
                w wVar2 = (w) obj;
                wVar2.f19120v.setAlpha(1.0f);
                wVar2.f19126y.d(null);
                wVar2.f19126y = null;
                break;
            default:
                w wVar3 = (w) ((h) obj).f15040c;
                wVar3.f19120v.setVisibility(8);
                PopupWindow popupWindow = wVar3.f19122w;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (wVar3.f19120v.getParent() instanceof View) {
                    View view = (View) wVar3.f19120v.getParent();
                    WeakHashMap weakHashMap = S.f5835a;
                    G.c(view);
                }
                wVar3.f19120v.e();
                wVar3.f19126y.d(null);
                wVar3.f19126y = null;
                ViewGroup viewGroup = wVar3.f19084B;
                WeakHashMap weakHashMap2 = S.f5835a;
                G.c(viewGroup);
                break;
        }
    }

    @Override // T8.l, P.InterfaceC0309b0
    public void c() {
        int i9 = this.f19053h;
        Object obj = this.f19054i;
        switch (i9) {
            case 0:
                ((m) obj).f19051b.f19120v.setVisibility(0);
                break;
            case 1:
                w wVar = (w) obj;
                wVar.f19120v.setVisibility(0);
                if (wVar.f19120v.getParent() instanceof View) {
                    View view = (View) wVar.f19120v.getParent();
                    WeakHashMap weakHashMap = S.f5835a;
                    G.c(view);
                }
                break;
        }
    }
}
