package p075i;

import H0.E;
import L.f;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import p015b4.p;
import p158r.a;

/* JADX INFO: loaded from: classes.dex */
public abstract class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final E f19041a = new E(new p(1));

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int f19042b = -100;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static f f19043c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static f f19044d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Boolean f19045e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static boolean f19046f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final p158r.f f19047g = new p158r.f(0);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final Object f19048h = new Object();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final Object f19049i = new Object();

    public static boolean b(Context context) {
        if (f19045e == null) {
            try {
                int i9 = D.f18950a;
                Bundle bundle = context.getPackageManager().getServiceInfo(new ComponentName(context, (Class<?>) D.class), Build.VERSION.SDK_INT >= 24 ? C.a() | 128 : 640).metaData;
                if (bundle != null) {
                    f19045e = Boolean.valueOf(bundle.getBoolean("autoStoreLocales"));
                }
            } catch (PackageManager.NameNotFoundException unused) {
                Log.d("AppCompatDelegate", "Checking for metadata for AppLocalesMetadataHolderService : Service not found");
                f19045e = Boolean.FALSE;
            }
        }
        return f19045e.booleanValue();
    }

    public static void f(w wVar) {
        synchronized (f19048h) {
            try {
                p158r.f fVar = f19047g;
                fVar.getClass();
                a aVar = new a(fVar);
                while (aVar.hasNext()) {
                    l lVar = (l) ((WeakReference) aVar.next()).get();
                    if (lVar == wVar || lVar == null) {
                        aVar.remove();
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public abstract void a();

    public abstract void d();

    public abstract void e();

    public abstract boolean h(int i9);

    public abstract void i(int i9);

    public abstract void j(View view);

    public abstract void k(View view, ViewGroup.LayoutParams layoutParams);

    public abstract void l(CharSequence charSequence);
}
