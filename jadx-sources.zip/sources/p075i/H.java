package p075i;

import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import com.google.android.material.appbar.h;
import java.lang.ref.WeakReference;
import p113m.a;
import p123n.i;
import p123n.k;
import p125n1.g;
import p133o.C1231l;

/* JADX INFO: loaded from: classes.dex */
public final class H extends a implements i {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Context f18959c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final k f18960d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public h f18961e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public WeakReference f18962f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ I f18963g;

    public H(I i9, Context context, h hVar) {
        this.f18963g = i9;
        this.f18959c = context;
        this.f18961e = hVar;
        k kVar = new k(context);
        kVar.f21494l = 1;
        this.f18960d = kVar;
        kVar.f21488e = this;
    }

    @Override // p113m.a
    public final void a() {
        I i9 = this.f18963g;
        if (i9.f18976n != this) {
            return;
        }
        if (i9.f18983u) {
            i9.f18977o = this;
            i9.f18978p = this.f18961e;
        } else {
            this.f18961e.A(this);
        }
        this.f18961e = null;
        i9.W(false);
        ActionBarContextView actionBarContextView = i9.f18973k;
        if (actionBarContextView.f10277k == null) {
            actionBarContextView.e();
        }
        i9.f18971h.setHideOnContentScrollEnabled(i9.f18988z);
        i9.f18976n = null;
    }

    @Override // p113m.a
    public final View b() {
        WeakReference weakReference = this.f18962f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // p123n.i
    public final boolean c(k kVar, MenuItem menuItem) {
        h hVar = this.f18961e;
        if (hVar != null) {
            return ((g) hVar.f15039b).p(this, menuItem);
        }
        return false;
    }

    @Override // p113m.a
    public final k d() {
        return this.f18960d;
    }

    @Override // p113m.a
    public final MenuInflater e() {
        return new p113m.h(this.f18959c);
    }

    @Override // p113m.a
    public final CharSequence f() {
        return this.f18963g.f18973k.getSubtitle();
    }

    @Override // p123n.i
    public final void g(k kVar) {
        if (this.f18961e == null) {
            return;
        }
        i();
        C1231l c1231l = this.f18963g.f18973k.f10271d;
        if (c1231l != null) {
            c1231l.n();
        }
    }

    @Override // p113m.a
    public final CharSequence h() {
        return this.f18963g.f18973k.getTitle();
    }

    @Override // p113m.a
    public final void i() {
        if (this.f18963g.f18976n != this) {
            return;
        }
        k kVar = this.f18960d;
        kVar.w();
        try {
            this.f18961e.C(this, kVar);
        } finally {
            kVar.v();
        }
    }

    @Override // p113m.a
    public final boolean j() {
        return this.f18963g.f18973k.f10285s;
    }

    @Override // p113m.a
    public final void k(View view) {
        this.f18963g.f18973k.setCustomView(view);
        this.f18962f = new WeakReference(view);
    }

    @Override // p113m.a
    public final void l(int i9) {
        m(this.f18963g.f18969f.getResources().getString(i9));
    }

    @Override // p113m.a
    public final void m(CharSequence charSequence) {
        this.f18963g.f18973k.setSubtitle(charSequence);
    }

    @Override // p113m.a
    public final void n(int i9) {
        o(this.f18963g.f18969f.getResources().getString(i9));
    }

    @Override // p113m.a
    public final void o(CharSequence charSequence) {
        this.f18963g.f18973k.setTitle(charSequence);
    }

    @Override // p113m.a
    public final void p(boolean z9) {
        this.f21157b = z9;
        this.f18963g.f18973k.setTitleOptional(z9);
    }
}
