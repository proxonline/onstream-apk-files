package p075i;

import android.content.Context;
import android.content.ContextWrapper;
import android.view.View;
import com.google.android.gms.internal.cast.z1;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes.dex */
public final class A implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final View f18938a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f18939b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Method f18940c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Context f18941d;

    public A(View view, String str) {
        this.f18938a = view;
        this.f18939b = str;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        String str;
        Method method;
        if (this.f18940c != null) {
            break;
        }
        View view2 = this.f18938a;
        Context context = view2.getContext();
        while (true) {
            String str2 = this.f18939b;
            if (context == null) {
                int id = view2.getId();
                if (id == -1) {
                    str = "";
                } else {
                    str = " with id '" + view2.getContext().getResources().getResourceEntryName(id) + "'";
                }
                StringBuilder sbO = z1.o("Could not find method ", str2, "(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
                sbO.append(view2.getClass());
                sbO.append(str);
                throw new IllegalStateException(sbO.toString());
            }
            try {
                if (!context.isRestricted() && (method = context.getClass().getMethod(str2, View.class)) != null) {
                    this.f18940c = method;
                    this.f18941d = context;
                    break;
                }
            } catch (NoSuchMethodException unused) {
            }
            context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null;
        }
        try {
            this.f18940c.invoke(this.f18941d, view);
        } catch (IllegalAccessException e9) {
            throw new IllegalStateException("Could not execute non-public method for android:onClick", e9);
        } catch (InvocationTargetException e10) {
            throw new IllegalStateException("Could not execute method for android:onClick", e10);
        }
    }
}
