package p075i;

import android.app.Dialog;
import android.os.Bundle;
import p085j0.DialogInterfaceOnCancelListenerC1194q;

/* JADX INFO: loaded from: classes.dex */
public class z extends DialogInterfaceOnCancelListenerC1194q {
    @Override // p085j0.DialogInterfaceOnCancelListenerC1194q
    public Dialog h0(Bundle bundle) {
        return new y(n(), this.f20545z0);
    }

    @Override // p085j0.DialogInterfaceOnCancelListenerC1194q
    public final void j0(Dialog dialog, int i9) {
        if (!(dialog instanceof y)) {
            super.j0(dialog, i9);
            return;
        }
        y yVar = (y) dialog;
        if (i9 != 1 && i9 != 2) {
            if (i9 != 3) {
                return;
            } else {
                dialog.getWindow().addFlags(24);
            }
        }
        yVar.e().h(1);
    }
}
