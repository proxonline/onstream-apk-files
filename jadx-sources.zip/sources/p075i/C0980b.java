package p075i;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import p123n.l;

/* JADX INFO: renamed from: i.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0980b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ContextThemeWrapper f18991a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final LayoutInflater f18992b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Drawable f18993c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f18994d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public View f18995e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public CharSequence f18996f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public DialogInterface.OnClickListener f18997g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public CharSequence f18998h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public DialogInterface.OnClickListener f18999i;
    public l j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Object f19000k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public DialogInterface.OnClickListener f19001l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public View f19002m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f19003n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f19004o = -1;

    public C0980b(ContextThemeWrapper contextThemeWrapper) {
        this.f18991a = contextThemeWrapper;
        this.f18992b = (LayoutInflater) contextThemeWrapper.getSystemService("layout_inflater");
    }
}
