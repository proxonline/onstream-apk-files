package Q4;

import H0.C;
import X4.u;
import android.support.v4.media.session.z;
import com.google.crypto.tink.shaded.protobuf.AbstractC0840a;
import com.google.crypto.tink.shaded.protobuf.AbstractC0847h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0860v;
import com.google.crypto.tink.shaded.protobuf.B;
import com.google.crypto.tink.shaded.protobuf.C0846g;
import com.google.crypto.tink.shaded.protobuf.C0850k;
import j$.util.DesugarCollections;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Iterator;
import java.util.Map;
import p026c5.W;
import p026c5.X;
import p026c5.Y;
import p026c5.Z;
import p026c5.b0;
import p026c5.d0;
import p026c5.e0;
import p026c5.f0;
import p026c5.g0;
import p026c5.r0;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final f f6561c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final f f6562d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final f f6563e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6564a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f6565b;

    static {
        int i9 = 0;
        f6561c = new f(i9, "ENABLED");
        f6562d = new f(i9, "DISABLED");
        f6563e = new f(i9, "DESTROYED");
    }

    public /* synthetic */ f(int i9, Object obj) {
        this.f6564a = i9;
        this.f6565b = obj;
    }

    public f(C c10, Class cls) {
        this.f6564a = 2;
        if (((Map) c10.f2716b).keySet().contains(cls) || Void.class.equals(cls)) {
            this.f6565b = c10;
            return;
        }
        throw new IllegalArgumentException("Given internalKeyMananger " + c10.toString() + " does not support primitive class " + cls.getName());
    }

    public synchronized void a(b0 b0Var) {
        f0 f0VarE = e(b0Var);
        d0 d0Var = (d0) this.f6565b;
        d0Var.e();
        g0.x((g0) d0Var.f15611b, f0VarE);
    }

    public synchronized f0 b(Y y9, r0 r0Var) {
        e0 e0VarF;
        int iG = g();
        if (r0Var == r0.UNKNOWN_PREFIX) {
            throw new GeneralSecurityException("unknown output prefix type");
        }
        e0VarF = f0.F();
        e0VarF.e();
        f0.w((f0) e0VarF.f15611b, y9);
        e0VarF.e();
        f0.z((f0) e0VarF.f15611b, iG);
        e0VarF.e();
        f0.y((f0) e0VarF.f15611b);
        e0VarF.e();
        f0.x((f0) e0VarF.f15611b, r0Var);
        return (f0) e0VarF.b();
    }

    public synchronized z c() {
        return z.v((g0) ((d0) this.f6565b).b());
    }

    public synchronized boolean d(int i9) {
        Iterator it = DesugarCollections.unmodifiableList(((g0) ((d0) this.f6565b).f15611b).A()).iterator();
        while (it.hasNext()) {
            if (((f0) it.next()).B() == i9) {
                return true;
            }
        }
        return false;
    }

    public synchronized f0 e(b0 b0Var) {
        return b(n.d(b0Var), b0Var.A());
    }

    public Y f(AbstractC0847h abstractC0847h) throws GeneralSecurityException {
        C c10 = (C) this.f6565b;
        try {
            D.o oVarF = c10.f();
            AbstractC0840a abstractC0840aJ0 = oVarF.j0(abstractC0847h);
            oVarF.q0(abstractC0840aJ0);
            AbstractC0840a abstractC0840aZ = oVarF.Z(abstractC0840aJ0);
            W wD = Y.D();
            String strD = c10.d();
            wD.e();
            Y.w((Y) wD.f15611b, strD);
            try {
                int iB = ((AbstractC0860v) abstractC0840aZ).b(null);
                byte[] bArr = new byte[iB];
                C0850k c0850k = new C0850k(iB, bArr);
                abstractC0840aZ.f(c0850k);
                if (c0850k.f15585h - c0850k.f15586i != 0) {
                    throw new IllegalStateException("Did not write as much data as expected.");
                }
                C0846g c0846g = new C0846g(bArr);
                wD.e();
                Y.x((Y) wD.f15611b, c0846g);
                X xG = c10.g();
                wD.e();
                Y.y((Y) wD.f15611b, xG);
                return (Y) wD.b();
            } catch (IOException e9) {
                throw new RuntimeException(abstractC0840aZ.c("ByteString"), e9);
            }
        } catch (B e10) {
            throw new GeneralSecurityException("Unexpected proto", e10);
        }
    }

    public synchronized int g() {
        int iA;
        iA = u.a();
        while (d(iA)) {
            iA = u.a();
        }
        return iA;
    }

    public synchronized void h(int i9) {
        for (int i10 = 0; i10 < ((g0) ((d0) this.f6565b).f15611b).z(); i10++) {
            try {
                f0 f0VarY = ((g0) ((d0) this.f6565b).f15611b).y(i10);
                if (f0VarY.B() == i9) {
                    if (!f0VarY.D().equals(Z.ENABLED)) {
                        throw new GeneralSecurityException("cannot set key as primary because it's not enabled: " + i9);
                    }
                    d0 d0Var = (d0) this.f6565b;
                    d0Var.e();
                    g0.w((g0) d0Var.f15611b, i9);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        throw new GeneralSecurityException("key not found: " + i9);
    }

    public String toString() {
        switch (this.f6564a) {
            case 0:
                return (String) this.f6565b;
            default:
                return super.toString();
        }
    }
}
