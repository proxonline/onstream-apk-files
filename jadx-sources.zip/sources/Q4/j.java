package Q4;

/* JADX INFO: loaded from: classes.dex */
public interface j {
    void a(byte[] bArr, byte[] bArr2);

    byte[] b(byte[] bArr);
}
