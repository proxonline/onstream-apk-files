package Q4;

import java.security.GeneralSecurityException;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: classes.dex */
public abstract class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final CopyOnWriteArrayList f6568a = new CopyOnWriteArrayList();

    public static W4.c a(String str) throws GeneralSecurityException {
        boolean zStartsWith;
        for (W4.c cVar : f6568a) {
            synchronized (cVar) {
                zStartsWith = str.toLowerCase(Locale.US).startsWith("android-keystore://");
            }
            if (zStartsWith) {
                return cVar;
            }
        }
        throw new GeneralSecurityException(p165r6.a.s("No KMS client does support: ", str));
    }
}
