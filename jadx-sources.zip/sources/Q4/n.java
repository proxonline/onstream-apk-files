package Q4;

import H0.C;
import com.google.crypto.tink.shaded.protobuf.AbstractC0840a;
import com.google.crypto.tink.shaded.protobuf.AbstractC0847h;
import com.google.crypto.tink.shaded.protobuf.B;
import com.google.crypto.tink.shaded.protobuf.C0846g;
import j$.util.concurrent.ConcurrentHashMap;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import p026c5.Y;
import p026c5.a0;
import p026c5.b0;
import p026c5.r0;

/* JADX INFO: loaded from: classes.dex */
public abstract class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final AtomicReference f6578a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final ConcurrentHashMap f6579b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final ConcurrentHashMap f6580c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ConcurrentHashMap f6581d;

    static {
        Logger.getLogger(n.class.getName());
        f6578a = new AtomicReference(new e());
        f6579b = new ConcurrentHashMap();
        f6580c = new ConcurrentHashMap();
        new ConcurrentHashMap();
        f6581d = new ConcurrentHashMap();
    }

    public static synchronized void a(String str, Map map, boolean z9) {
        if (z9) {
            try {
                ConcurrentHashMap concurrentHashMap = f6580c;
                if (concurrentHashMap.containsKey(str) && !((Boolean) concurrentHashMap.get(str)).booleanValue()) {
                    throw new GeneralSecurityException("New keys are already disallowed for key type " + str);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (z9) {
            if (((e) f6578a.get()).f6560a.containsKey(str)) {
                for (Map.Entry entry : map.entrySet()) {
                    if (!f6581d.containsKey(entry.getKey())) {
                        throw new GeneralSecurityException("Attempted to register a new key template " + ((String) entry.getKey()) + " from an existing key manager of type " + str);
                    }
                }
            } else {
                for (Map.Entry entry2 : map.entrySet()) {
                    if (f6581d.containsKey(entry2.getKey())) {
                        throw new GeneralSecurityException("Attempted overwrite of a registered key template " + ((String) entry2.getKey()));
                    }
                }
            }
        }
    }

    public static Object b(b bVar, Class cls) throws GeneralSecurityException {
        X4.o oVar = (X4.o) X4.h.f8941b.f8942a.get();
        oVar.getClass();
        X4.n nVar = new X4.n(bVar.getClass(), cls);
        HashMap map = oVar.f8951a;
        if (map.containsKey(nVar)) {
            return ((X4.l) map.get(nVar)).f8948b.c(bVar);
        }
        throw new GeneralSecurityException("No PrimitiveConstructor for " + nVar + " available");
    }

    public static Object c(String str, AbstractC0847h abstractC0847h, Class cls) throws GeneralSecurityException {
        e eVar = (e) f6578a.get();
        eVar.getClass();
        d dVarA = eVar.a(str);
        Set setKeySet = ((Map) dVarA.f6558a.f2716b).keySet();
        C c10 = dVarA.f6558a;
        if (!setKeySet.contains(cls)) {
            StringBuilder sb = new StringBuilder("Primitive type ");
            sb.append(cls.getName());
            sb.append(" not supported by key manager of type ");
            sb.append(c10.getClass());
            sb.append(", supported primitives: ");
            Set<Class> setKeySet2 = ((Map) c10.f2716b).keySet();
            StringBuilder sb2 = new StringBuilder();
            boolean z9 = true;
            for (Class cls2 : setKeySet2) {
                if (!z9) {
                    sb2.append(", ");
                }
                sb2.append(cls2.getCanonicalName());
                z9 = false;
            }
            sb.append(sb2.toString());
            throw new GeneralSecurityException(sb.toString());
        }
        try {
            if (!((Map) c10.f2716b).keySet().contains(cls) && !Void.class.equals(cls)) {
                throw new IllegalArgumentException("Given internalKeyMananger " + c10.toString() + " does not support primitive class " + cls.getName());
            }
            try {
                AbstractC0840a abstractC0840aH = c10.h(abstractC0847h);
                if (Void.class.equals(cls)) {
                    throw new GeneralSecurityException("Cannot create a primitive for Void");
                }
                c10.j(abstractC0840aH);
                return c10.e(abstractC0840aH, cls);
            } catch (B e9) {
                throw new GeneralSecurityException("Failures parsing proto of type ".concat(((Class) c10.f2715a).getName()), e9);
            }
        } catch (IllegalArgumentException e10) {
            throw new GeneralSecurityException("Primitive type not supported", e10);
        }
    }

    public static synchronized Y d(b0 b0Var) {
        f fVar;
        C c10 = ((e) f6578a.get()).a(b0Var.B()).f6558a;
        fVar = new f(c10, (Class) c10.f2717c);
        if (!((Boolean) f6580c.get(b0Var.B())).booleanValue()) {
            throw new GeneralSecurityException("newKey-operation not permitted for key type " + b0Var.B());
        }
        return fVar.f(b0Var.C());
    }

    public static synchronized void e(C c10, boolean z9) {
        try {
            AtomicReference atomicReference = f6578a;
            e eVar = new e((e) atomicReference.get());
            eVar.b(c10);
            String strD = c10.d();
            a(strD, z9 ? c10.f().i0() : Collections.EMPTY_MAP, z9);
            if (!((e) atomicReference.get()).f6560a.containsKey(strD)) {
                f6579b.put(strD, new C4.e(19));
                if (z9) {
                    f(strD, c10.f().i0());
                }
            }
            f6580c.put(strD, Boolean.valueOf(z9));
            atomicReference.set(eVar);
        } catch (Throwable th) {
            throw th;
        }
    }

    public static void f(String str, Map map) {
        r0 r0Var;
        for (Map.Entry entry : map.entrySet()) {
            String str2 = (String) entry.getKey();
            byte[] bArrE = ((AbstractC0840a) ((X4.d) entry.getValue()).f8936a).e();
            int i9 = ((X4.d) entry.getValue()).f8937b;
            a0 a0VarD = b0.D();
            a0VarD.e();
            b0.w((b0) a0VarD.f15611b, str);
            C0846g c0846gI = AbstractC0847h.i(bArrE, 0, bArrE.length);
            a0VarD.e();
            b0.x((b0) a0VarD.f15611b, c0846gI);
            int iB = p183u.e.b(i9);
            if (iB == 0) {
                r0Var = r0.TINK;
            } else if (iB == 1) {
                r0Var = r0.LEGACY;
            } else if (iB == 2) {
                r0Var = r0.RAW;
            } else {
                if (iB != 3) {
                    throw new IllegalArgumentException("Unknown output prefix type");
                }
                r0Var = r0.CRUNCHY;
            }
            a0VarD.e();
            b0.y((b0) a0VarD.f15611b, r0Var);
            f6581d.put(str2, new g((b0) a0VarD.b()));
        }
    }

    public static synchronized void g(m mVar) {
        X4.h.f8941b.c(mVar);
    }
}
