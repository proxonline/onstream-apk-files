package Q4;

import android.support.v4.media.session.z;

/* JADX INFO: loaded from: classes.dex */
public interface m {
    Class a();

    Object b(z zVar);

    Class c();
}
