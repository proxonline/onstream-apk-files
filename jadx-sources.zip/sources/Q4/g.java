package Q4;

import p026c5.b0;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b0 f6566a;

    public g(b0 b0Var) {
        this.f6566a = b0Var;
    }
}
