package Q4;

import H0.C;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C f6558a;

    public d(C c10) {
        this.f6558a = c10;
    }
}
