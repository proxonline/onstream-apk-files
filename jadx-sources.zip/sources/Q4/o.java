package Q4;

import java.nio.charset.Charset;
import p026c5.Z;
import p026c5.f0;
import p026c5.g0;
import p026c5.h0;
import p026c5.i0;
import p026c5.j0;
import p026c5.k0;
import p026c5.r0;

/* JADX INFO: loaded from: classes.dex */
public abstract class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f6582a = 0;

    static {
        Charset.forName("UTF-8");
    }

    public static k0 a(g0 g0Var) {
        h0 h0VarZ = k0.z();
        int iB = g0Var.B();
        h0VarZ.e();
        k0.w((k0) h0VarZ.f15611b, iB);
        for (f0 f0Var : g0Var.A()) {
            i0 i0VarB = j0.B();
            String strB = f0Var.A().B();
            i0VarB.e();
            j0.w((j0) i0VarB.f15611b, strB);
            Z zD = f0Var.D();
            i0VarB.e();
            j0.y((j0) i0VarB.f15611b, zD);
            r0 r0VarC = f0Var.C();
            i0VarB.e();
            j0.x((j0) i0VarB.f15611b, r0VarC);
            int iB2 = f0Var.B();
            i0VarB.e();
            j0.z((j0) i0VarB.f15611b, iB2);
            j0 j0Var = (j0) i0VarB.b();
            h0VarZ.e();
            k0.x((k0) h0VarZ.f15611b, j0Var);
        }
        return (k0) h0VarZ.b();
    }
}
