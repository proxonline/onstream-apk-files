package Q4;

import java.util.Arrays;
import p026c5.Z;
import p026c5.r0;

/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f6569a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f6570b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final byte[] f6571c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Z f6572d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final r0 f6573e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f6574f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f6575g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final b f6576h;

    public k(Object obj, Object obj2, byte[] bArr, Z z9, r0 r0Var, int i9, String str, b bVar) {
        this.f6569a = obj;
        this.f6570b = obj2;
        this.f6571c = Arrays.copyOf(bArr, bArr.length);
        this.f6572d = z9;
        this.f6573e = r0Var;
        this.f6574f = i9;
        this.f6575g = str;
        this.f6576h = bVar;
    }
}
