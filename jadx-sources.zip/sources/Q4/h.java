package Q4;

/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f6567a;

    public h(b bVar) {
        this.f6567a = bVar;
    }
}
