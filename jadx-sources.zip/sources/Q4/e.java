package Q4;

import H0.C;
import j$.util.concurrent.ConcurrentHashMap;
import java.security.GeneralSecurityException;
import java.util.Map;
import java.util.logging.Logger;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Logger f6559b = Logger.getLogger(e.class.getName());

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ConcurrentHashMap f6560a;

    public e() {
        this.f6560a = new ConcurrentHashMap();
    }

    public e(e eVar) {
        this.f6560a = new ConcurrentHashMap(eVar.f6560a);
    }

    public final synchronized d a(String str) {
        if (!this.f6560a.containsKey(str)) {
            throw new GeneralSecurityException("No key manager found for key type " + str);
        }
        return (d) this.f6560a.get(str);
    }

    public final synchronized void b(C c10) {
        int iC = c10.c();
        if (!(iC != 1 ? B0.a.e(iC) : B0.a.d(iC))) {
            throw new GeneralSecurityException("failed to register key manager " + c10.getClass() + " as it is not FIPS compatible.");
        }
        c(new d(c10));
    }

    public final synchronized void c(d dVar) {
        try {
            C c10 = dVar.f6558a;
            Class cls = (Class) c10.f2717c;
            if (!((Map) c10.f2716b).keySet().contains(cls) && !Void.class.equals(cls)) {
                throw new IllegalArgumentException("Given internalKeyMananger " + c10.toString() + " does not support primitive class " + cls.getName());
            }
            String strD = c10.d();
            d dVar2 = (d) this.f6560a.get(strD);
            if (dVar2 != null && !dVar2.f6558a.getClass().equals(dVar.f6558a.getClass())) {
                f6559b.warning("Attempted overwrite of a registered key manager for key type ".concat(strD));
                throw new GeneralSecurityException("typeUrl (" + strD + ") is already registered with " + dVar2.f6558a.getClass().getName() + ", cannot be re-registered with " + dVar.f6558a.getClass().getName());
            }
            this.f6560a.putIfAbsent(strD, dVar);
        } catch (Throwable th) {
            throw th;
        }
    }
}
