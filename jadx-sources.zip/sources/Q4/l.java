package Q4;

import com.google.android.gms.internal.measurement.AbstractC0837z1;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class l implements Comparable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final byte[] f6577a;

    public l(byte[] bArr) {
        this.f6577a = Arrays.copyOf(bArr, bArr.length);
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        l lVar = (l) obj;
        byte[] bArr = this.f6577a;
        int length = bArr.length;
        byte[] bArr2 = lVar.f6577a;
        if (length != bArr2.length) {
            return bArr.length - bArr2.length;
        }
        for (int i9 = 0; i9 < bArr.length; i9++) {
            byte b10 = bArr[i9];
            byte b11 = lVar.f6577a[i9];
            if (b10 != b11) {
                return b10 - b11;
            }
        }
        return 0;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof l) {
            return Arrays.equals(this.f6577a, ((l) obj).f6577a);
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f6577a);
    }

    public final String toString() {
        return AbstractC0837z1.D(this.f6577a);
    }
}
