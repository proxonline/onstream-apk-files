package p159r0;

import M3.b;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.atomic.AtomicBoolean;
import p015b4.n;
import p137o3.d;

/* JADX INFO: loaded from: classes.dex */
public final class a implements Runnable {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static Handler f22724f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ d f22729e;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile int f22726b = 1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final AtomicBoolean f22727c = new AtomicBoolean();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final AtomicBoolean f22728d = new AtomicBoolean();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f22725a = new b(this, new b(3, this));

    public a(d dVar) {
        this.f22729e = dVar;
    }

    public final void a(Object obj) {
        Handler handler;
        synchronized (a.class) {
            try {
                if (f22724f == null) {
                    f22724f = new Handler(Looper.getMainLooper());
                }
                handler = f22724f;
            } catch (Throwable th) {
                throw th;
            }
        }
        handler.post(new n(this, 10, obj));
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f22729e.b();
    }
}
