package p106l2;

import C1.b;
import L8.A;
import L8.E;
import L8.H;
import L8.InterfaceC0243d;
import L8.J;
import L8.t;
import L8.u;
import O4.q;
import P8.i;
import android.net.Uri;
import com.google.android.material.appbar.h;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import p052f2.L;
import p062g3.AbstractC0946g;
import p062g3.C;
import p062g3.C0953n;
import p062g3.C0956q;
import p062g3.F;
import p071h3.y;

/* JADX INFO: loaded from: classes.dex */
public final class a extends AbstractC0946g {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final InterfaceC0243d f21085e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final h f21086f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final h f21087g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public H f21088h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public InputStream f21089i;
    public boolean j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public long f21090k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public long f21091l;

    static {
        L.a("goog.exo.okhttp");
    }

    public a(InterfaceC0243d interfaceC0243d, h hVar) {
        super(true);
        interfaceC0243d.getClass();
        this.f21085e = interfaceC0243d;
        this.f21087g = hVar;
        this.f21086f = new h(6);
    }

    @Override // p062g3.InterfaceC0952m
    public final void close() {
        if (this.j) {
            this.j = false;
            c();
            g();
        }
    }

    public final void g() {
        H h6 = this.f21088h;
        if (h6 != null) {
            J j = h6.f4328g;
            j.getClass();
            j.close();
            this.f21088h = null;
        }
        this.f21089i = null;
    }

    public final void h(long j) throws C {
        if (j == 0) {
            return;
        }
        byte[] bArr = new byte[4096];
        while (j > 0) {
            try {
                int iMin = (int) Math.min(j, 4096);
                InputStream inputStream = this.f21089i;
                int i9 = y.f18900a;
                int i10 = inputStream.read(bArr, 0, iMin);
                if (Thread.currentThread().isInterrupted()) {
                    throw new InterruptedIOException();
                }
                if (i10 == -1) {
                    throw new C(2008);
                }
                j -= (long) i10;
                a(i10);
            } catch (IOException e9) {
                if (!(e9 instanceof C)) {
                    throw new C(2000);
                }
                throw ((C) e9);
            }
        }
    }

    @Override // p062g3.InterfaceC0952m
    public final long l(C0956q c0956q) throws C {
        u uVarA;
        long j;
        b bVar;
        C0953n c0953n;
        E e9;
        this.f21091l = 0L;
        this.f21090k = 0L;
        d();
        long j9 = c0956q.f18324e;
        int i9 = c0956q.f18321b;
        long j10 = c0956q.f18325f;
        String string = c0956q.f18320a.toString();
        kotlin.jvm.internal.h.e(string, "<this>");
        try {
            t tVar = new t();
            tVar.c(null, string);
            uVarA = tVar.a();
        } catch (IllegalArgumentException unused) {
            uVarA = null;
        }
        if (uVarA == null) {
            throw new C("Malformed URL", 1004);
        }
        b bVar2 = new b(1);
        bVar2.f547a = uVarA;
        HashMap map = new HashMap();
        h hVar = this.f21087g;
        if (hVar != null) {
            map.putAll(hVar.x());
        }
        map.putAll(this.f21086f.x());
        map.putAll(c0956q.f18323d);
        for (Map.Entry entry : map.entrySet()) {
            bVar2.B((String) entry.getKey(), (String) entry.getValue());
        }
        String strA = F.a(j9, j10);
        if (strA != null) {
            bVar2.k("Range", strA);
        }
        if ((c0956q.f18327h & 1) != 1) {
            bVar2.k("Accept-Encoding", "identity");
        }
        byte[] bArr = c0956q.f18322c;
        if (bArr != null) {
            int length = bArr.length;
            j = 0;
            bVar = bVar2;
            M8.b.c(bArr.length, 0, length);
            e9 = new E(null, length, bArr);
            c0953n = null;
        } else {
            j = 0;
            bVar = bVar2;
            if (i9 == 2) {
                byte[] content = y.f18905f;
                kotlin.jvm.internal.h.e(content, "content");
                int length2 = content.length;
                M8.b.c(content.length, 0, length2);
                c0953n = null;
                e9 = new E(null, length2, content);
            } else {
                c0953n = null;
                e9 = null;
            }
        }
        String strB = C0956q.b(i9);
        b bVar3 = bVar;
        bVar3.E(strB, e9);
        L8.C cL = bVar3.l();
        A a10 = (A) this.f21085e;
        a10.getClass();
        i iVar = new i(a10, cL);
        try {
            q qVar = new q();
            iVar.d(new p036d5.h(11, qVar));
            try {
                try {
                    H h6 = (H) qVar.get();
                    this.f21088h = h6;
                    J j11 = h6.f4328g;
                    j11.getClass();
                    this.f21089i = j11.k().e0();
                    int i10 = h6.f4325d;
                    if (!h6.f()) {
                        if (i10 == 416 && j9 == F.b(h6.f4327f.e("Content-Range"))) {
                            this.j = true;
                            f(c0956q);
                            return j10 != -1 ? j10 : j;
                        }
                        try {
                            InputStream inputStream = this.f21089i;
                            inputStream.getClass();
                            y.R(inputStream);
                        } catch (IOException unused2) {
                            int i11 = y.f18900a;
                        }
                        TreeMap treeMapL = h6.f4327f.l();
                        g();
                        if (i10 == 416) {
                            c0953n = new C0953n(2008);
                        }
                        throw new p062g3.E(i10, c0953n, treeMapL);
                    }
                    j11.f();
                    if (i10 != 200 || j9 == j) {
                        j9 = j;
                    }
                    if (j10 != -1) {
                        this.f21090k = j10;
                    } else {
                        long jA = j11.a();
                        this.f21090k = jA != -1 ? jA - j9 : -1L;
                    }
                    this.j = true;
                    f(c0956q);
                    try {
                        h(j9);
                        return this.f21090k;
                    } catch (C e10) {
                        g();
                        throw e10;
                    }
                } catch (InterruptedException unused3) {
                    iVar.cancel();
                    throw new InterruptedIOException();
                }
            } catch (ExecutionException e11) {
                throw new IOException(e11);
            }
        } catch (IOException e12) {
            throw C.a(1, e12);
        }
    }

    @Override // p062g3.AbstractC0946g, p062g3.InterfaceC0952m
    public final Map o() {
        H h6 = this.f21088h;
        return h6 == null ? Collections.EMPTY_MAP : h6.f4327f.l();
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0028 A[Catch: IOException -> 0x0032, TRY_LEAVE, TryCatch #0 {IOException -> 0x0032, blocks: (B:5:0x0004, B:7:0x000d, B:10:0x0017, B:11:0x001d, B:14:0x0028), top: B:19:0x0004 }] */
    @Override // p062g3.InterfaceC0949j
    public final int read(byte[] bArr, int i9, int i10) throws C {
        int i11;
        if (i10 == 0) {
            return 0;
        }
        try {
            long j = this.f21090k;
            if (j != -1) {
                long j9 = j - this.f21091l;
                if (j9 != 0) {
                    i10 = (int) Math.min(i10, j9);
                    InputStream inputStream = this.f21089i;
                    int i12 = y.f18900a;
                    i11 = inputStream.read(bArr, i9, i10);
                    if (i11 != -1) {
                        this.f21091l += (long) i11;
                        a(i11);
                        return i11;
                    }
                }
            } else {
                InputStream inputStream2 = this.f21089i;
                int i13 = y.f18900a;
                i11 = inputStream2.read(bArr, i9, i10);
                if (i11 != -1) {
                    this.f21091l += (long) i11;
                    a(i11);
                    return i11;
                }
            }
            return -1;
        } catch (IOException e9) {
            int i14 = y.f18900a;
            throw C.a(2, e9);
        }
    }

    @Override // p062g3.InterfaceC0952m
    public final Uri u() {
        H h6 = this.f21088h;
        if (h6 == null) {
            return null;
        }
        return Uri.parse(h6.f4322a.f4298a.f4453i);
    }
}
