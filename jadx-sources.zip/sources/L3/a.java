package L3;

import android.os.IBinder;
import android.os.IInterface;

/* JADX INFO: loaded from: classes.dex */
public final class a implements c, IInterface {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final IBinder f3977e;

    public a(IBinder iBinder) {
        this.f3977e = iBinder;
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f3977e;
    }
}
