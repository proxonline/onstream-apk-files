package p148p5;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.h;
import p048e8.i;
import p048e8.k;
import p048e8.q;
import p195v5.C1327a0;
import p195v5.D0;
import p195v5.Z;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c f22433a = new c();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final c f22434b = new c();

    public static ArrayList c(Context context) {
        h.e(context, "context");
        int i9 = context.getApplicationInfo().uid;
        String str = context.getApplicationInfo().processName;
        Object systemService = context.getSystemService("activity");
        ActivityManager activityManager = systemService instanceof ActivityManager ? (ActivityManager) systemService : null;
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = activityManager != null ? activityManager.getRunningAppProcesses() : null;
        if (runningAppProcesses == null) {
            runningAppProcesses = q.f17244a;
        }
        ArrayList arrayListH0 = i.h0(runningAppProcesses);
        ArrayList arrayList = new ArrayList();
        int size = arrayListH0.size();
        int i10 = 0;
        int i11 = 0;
        while (i11 < size) {
            Object obj = arrayListH0.get(i11);
            i11++;
            if (((ActivityManager.RunningAppProcessInfo) obj).uid == i9) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = new ArrayList(k.Z(arrayList));
        int size2 = arrayList.size();
        while (i10 < size2) {
            Object obj2 = arrayList.get(i10);
            i10++;
            ActivityManager.RunningAppProcessInfo runningAppProcessInfo = (ActivityManager.RunningAppProcessInfo) obj2;
            Z z9 = new Z();
            String str2 = runningAppProcessInfo.processName;
            if (str2 == null) {
                throw new NullPointerException("Null processName");
            }
            z9.f24500a = str2;
            z9.f24501b = runningAppProcessInfo.pid;
            byte b10 = (byte) (z9.f24504e | 1);
            z9.f24502c = runningAppProcessInfo.importance;
            z9.f24504e = (byte) (b10 | 2);
            z9.f24503d = h.a(str2, str);
            z9.f24504e = (byte) (z9.f24504e | 4);
            arrayList2.add(z9.a());
        }
        return arrayList2;
    }

    public boolean a(int i9) {
        return 4 <= i9 || Log.isLoggable("FirebaseCrashlytics", i9);
    }

    public void b(String str) {
        if (a(3)) {
            Log.d("FirebaseCrashlytics", str, null);
        }
    }

    public D0 d(Context context) {
        Object obj;
        String processName;
        h.e(context, "context");
        int iMyPid = Process.myPid();
        ArrayList arrayListC = c(context);
        int size = arrayListC.size();
        int i9 = 0;
        do {
            if (i9 >= size) {
                obj = null;
                break;
            }
            obj = arrayListC.get(i9);
            i9++;
        } while (((C1327a0) ((D0) obj)).f24510b != iMyPid);
        D0 d9 = (D0) obj;
        if (d9 != null) {
            return d9;
        }
        int i10 = Build.VERSION.SDK_INT;
        if (i10 > 33) {
            processName = Process.myProcessName();
            h.d(processName, "{\n      Process.myProcessName()\n    }");
        } else if (i10 < 28 || (processName = Application.getProcessName()) == null) {
            processName = "";
        }
        h.e(processName, "processName");
        Z z9 = new Z();
        z9.f24500a = processName;
        z9.f24501b = iMyPid;
        byte b10 = (byte) (z9.f24504e | 1);
        z9.f24502c = 0;
        z9.f24503d = false;
        z9.f24504e = (byte) (((byte) (b10 | 2)) | 4);
        return z9.a();
    }

    public void e(String str) {
        if (a(2)) {
            Log.v("FirebaseCrashlytics", str, null);
        }
    }

    public void f(String str, Exception exc) {
        if (a(5)) {
            Log.w("FirebaseCrashlytics", str, exc);
        }
    }
}
