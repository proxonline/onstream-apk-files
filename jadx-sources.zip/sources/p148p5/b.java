package p148p5;

import G.j;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import p007a6.d;
import p007a6.e;
import p048e8.k;
import p186u5.n;
import p218y5.c;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f22432a;

    public b(c cVar) {
        this.f22432a = cVar;
    }

    public final void a(d dVar) {
        c cVar = this.f22432a;
        HashSet hashSet = dVar.f9954a;
        ArrayList arrayList = new ArrayList(k.Z(hashSet));
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            p007a6.c cVar2 = (p007a6.c) ((e) it.next());
            String str = cVar2.f9949b;
            String str2 = cVar2.f9951d;
            String strSubstring = cVar2.f9952e;
            String str3 = cVar2.f9950c;
            long j = cVar2.f9953f;
            V5.c cVar3 = n.f24048a;
            if (strSubstring.length() > 256) {
                strSubstring = strSubstring.substring(0, 256);
            }
            arrayList.add(new p186u5.b(str, str2, strSubstring, str3, j));
        }
        synchronized (((P8.n) cVar.f25986f)) {
            try {
                if (((P8.n) cVar.f25986f).c(arrayList)) {
                    ((t5.d) cVar.f25983c).f23489b.a(new j(cVar, 27, ((P8.n) cVar.f25986f).a()));
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (Log.isLoggable("FirebaseCrashlytics", 3)) {
            Log.d("FirebaseCrashlytics", "Updated Crashlytics Rollout State", null);
        }
    }
}
