package p148p5;

import X5.g;
import android.util.Log;
import java.util.concurrent.atomic.AtomicReference;
import p079i3.p;
import p119m5.n;
import p195v5.C1349l0;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final c f22429c = new c();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n f22430a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final AtomicReference f22431b = new AtomicReference(null);

    public a(n nVar) {
        this.f22430a = nVar;
        nVar.a(new p(9, this));
    }

    public final c a(String str) {
        a aVar = (a) this.f22431b.get();
        return aVar == null ? f22429c : aVar.a(str);
    }

    public final boolean b() {
        a aVar = (a) this.f22431b.get();
        return aVar != null && aVar.b();
    }

    public final boolean c(String str) {
        a aVar = (a) this.f22431b.get();
        return aVar != null && aVar.c(str);
    }

    public final void d(String str, long j, C1349l0 c1349l0) {
        String strS = p165r6.a.s("Deferring native open session: ", str);
        if (Log.isLoggable("FirebaseCrashlytics", 2)) {
            Log.v("FirebaseCrashlytics", strS, null);
        }
        this.f22430a.a(new g(str, j, c1349l0));
    }
}
