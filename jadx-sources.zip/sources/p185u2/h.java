package p185u2;

/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f23810a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f23811b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f23812c;

    public h(int i9, long j, boolean z9) {
        this.f23810a = j;
        this.f23811b = z9;
        this.f23812c = i9;
    }
}
