package p185u2;

import p116m2.u;
import p116m2.v;

/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p f23861a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final s f23862b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final u f23863c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final v f23864d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f23865e;

    public l(p pVar, s sVar, u uVar) {
        this.f23861a = pVar;
        this.f23862b = sVar;
        this.f23863c = uVar;
        this.f23864d = "audio/true-hd".equals(pVar.f23899f.f17509l) ? new v() : null;
    }
}
