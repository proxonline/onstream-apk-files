package p185u2;

import A5.g;
import E3.a;
import K4.c;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class o {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final a f23889d = new a(new g(10, new c(':')));

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a f23890e = new a(new g(10, new c('*')));

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f23891a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f23892b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f23893c;
}
