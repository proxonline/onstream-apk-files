package p185u2;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f23806a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f23807b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f23808c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f23809d;

    public g(int i9, int i10, int i11, int i12) {
        this.f23806a = i9;
        this.f23807b = i10;
        this.f23808c = i11;
        this.f23809d = i12;
    }
}
