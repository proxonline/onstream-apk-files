package p185u2;

import S8.y;

/* JADX INFO: loaded from: classes.dex */
public final class b extends S0.b {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final y f23790c;

    public b(int i9, y yVar) {
        super(i9, 3);
        this.f23790c = yVar;
    }
}
