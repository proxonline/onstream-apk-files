package p185u2;

import G8.w;
import J2.Y;
import K4.e;
import L4.F;
import L4.S;
import S0.b;
import android.util.Pair;
import com.google.android.gms.internal.measurement.AbstractC0837z1;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import p052f2.M;
import p052f2.N;
import p052f2.j0;
import p070h2.AbstractC0965a;
import p071h3.a;
import p071h3.n;
import p071h3.y;
import p087j2.g;
import p116m2.o;

/* JADX INFO: loaded from: classes.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final byte[] f23805a;

    static {
        int i9 = y.f18900a;
        f23805a = "OpusHead".getBytes(e.f3790c);
    }

    public static Y a(int i9, S8.y yVar) {
        yVar.H(i9 + 12);
        yVar.I(1);
        b(yVar);
        yVar.I(2);
        int iX = yVar.x();
        if ((iX & 128) != 0) {
            yVar.I(2);
        }
        if ((iX & 64) != 0) {
            yVar.I(yVar.x());
        }
        if ((iX & 32) != 0) {
            yVar.I(2);
        }
        yVar.I(1);
        b(yVar);
        String strE = n.e(yVar.x());
        if ("audio/mpeg".equals(strE) || "audio/vnd.dts".equals(strE) || "audio/vnd.dts.hd".equals(strE)) {
            return new Y(strE, null, -1L, -1L);
        }
        yVar.I(4);
        long jY = yVar.y();
        long jY2 = yVar.y();
        yVar.I(1);
        int iB = b(yVar);
        long j = jY2;
        byte[] bArr = new byte[iB];
        yVar.h(bArr, 0, iB);
        if (j <= 0) {
            j = -1;
        }
        return new Y(strE, bArr, j, jY > 0 ? jY : -1L);
    }

    public static int b(S8.y yVar) {
        int iX = yVar.x();
        int i9 = iX & 127;
        while ((iX & 128) == 128) {
            iX = yVar.x();
            i9 = (i9 << 7) | (iX & 127);
        }
        return i9;
    }

    public static Pair c(S8.y yVar, int i9, int i10) throws j0 {
        q qVar;
        Pair pairCreate;
        int i11;
        int i12;
        int i13 = yVar.f7099a;
        while (i13 - i9 < i10) {
            yVar.H(i13);
            int i14 = yVar.i();
            AbstractC0837z1.i("childAtomSize must be positive", i14 > 0);
            if (yVar.i() == 1936289382) {
                int i15 = i13 + 8;
                int i16 = 0;
                int i17 = -1;
                Integer numValueOf = null;
                String strV = null;
                while (i15 - i13 < i14) {
                    yVar.H(i15);
                    int i18 = yVar.i();
                    int i19 = yVar.i();
                    if (i19 == 1718775137) {
                        numValueOf = Integer.valueOf(yVar.i());
                    } else if (i19 == 1935894637) {
                        yVar.I(4);
                        strV = yVar.v(4, e.f3790c);
                    } else if (i19 == 1935894633) {
                        i17 = i15;
                        i16 = i18;
                    }
                    i15 += i18;
                }
                byte[] bArr = null;
                if ("cenc".equals(strV) || "cbc1".equals(strV) || "cens".equals(strV) || "cbcs".equals(strV)) {
                    AbstractC0837z1.i("frma atom is mandatory", numValueOf != null);
                    AbstractC0837z1.i("schi atom is mandatory", i17 != -1);
                    int i20 = i17 + 8;
                    while (true) {
                        if (i20 - i17 >= i16) {
                            qVar = null;
                            break;
                        }
                        yVar.H(i20);
                        int i21 = yVar.i();
                        if (yVar.i() == 1952804451) {
                            int iQ = b.q(yVar.i());
                            yVar.I(1);
                            if (iQ == 0) {
                                yVar.I(1);
                                i12 = 0;
                                i11 = 0;
                            } else {
                                int iX = yVar.x();
                                i11 = iX & 15;
                                i12 = (iX & 240) >> 4;
                            }
                            boolean z9 = yVar.x() == 1;
                            int iX2 = yVar.x();
                            byte[] bArr2 = new byte[16];
                            yVar.h(bArr2, 0, 16);
                            if (z9 && iX2 == 0) {
                                int iX3 = yVar.x();
                                byte[] bArr3 = new byte[iX3];
                                yVar.h(bArr3, 0, iX3);
                                bArr = bArr3;
                            }
                            qVar = new q(z9, strV, iX2, bArr2, i12, i11, bArr);
                            break;
                        }
                        i20 += i21;
                    }
                    AbstractC0837z1.i("tenc atom is mandatory", qVar != null);
                    int i22 = y.f18900a;
                    pairCreate = Pair.create(numValueOf, qVar);
                } else {
                    pairCreate = null;
                }
                if (pairCreate != null) {
                    return pairCreate;
                }
            }
            i13 += i14;
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:101:0x02c4 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:103:0x02d3  */
    /* JADX WARN: Code duplicated, block: B:108:0x02f2 A[DONT_INVERT, LOOP:12: B:108:0x02f2->B:112:0x02fd, LOOP_START, PHI: r17
      0x02f2: PHI (r17v4 int) = (r17v3 int), (r17v5 int) binds: [B:107:0x02f0, B:112:0x02fd] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:109:0x02f4  */
    /* JADX WARN: Code duplicated, block: B:112:0x02fd A[LOOP:12: B:108:0x02f2->B:112:0x02fd, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:113:0x0303 A[EDGE_INSN: B:113:0x0303->B:114:0x0305 BREAK  A[LOOP:12: B:108:0x02f2->B:112:0x02fd]] */
    /* JADX WARN: Code duplicated, block: B:115:0x0307 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:120:0x0311  */
    /* JADX WARN: Code duplicated, block: B:122:0x034d  */
    /* JADX WARN: Code duplicated, block: B:123:0x0350  */
    /* JADX WARN: Code duplicated, block: B:128:0x036e  */
    /* JADX WARN: Code duplicated, block: B:130:0x037c  */
    /* JADX WARN: Code duplicated, block: B:132:0x038b  */
    /* JADX WARN: Code duplicated, block: B:160:0x0448  */
    /* JADX WARN: Code duplicated, block: B:161:0x044b  */
    /* JADX WARN: Code duplicated, block: B:164:0x0455  */
    /* JADX WARN: Code duplicated, block: B:166:0x045b  */
    /* JADX WARN: Code duplicated, block: B:169:0x0465 A[LOOP:4: B:167:0x0462->B:169:0x0465, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:172:0x048a  */
    /* JADX WARN: Code duplicated, block: B:174:0x048d  */
    /* JADX WARN: Code duplicated, block: B:175:0x048f  */
    /* JADX WARN: Code duplicated, block: B:179:0x04a2  */
    /* JADX WARN: Code duplicated, block: B:181:0x04ad  */
    /* JADX WARN: Code duplicated, block: B:189:0x04e4  */
    /* JADX WARN: Code duplicated, block: B:190:0x04e6  */
    /* JADX WARN: Code duplicated, block: B:192:0x04ee  */
    /* JADX WARN: Code duplicated, block: B:196:0x0507  */
    /* JADX WARN: Code duplicated, block: B:197:0x0509  */
    /* JADX WARN: Code duplicated, block: B:200:0x050f  */
    /* JADX WARN: Code duplicated, block: B:201:0x0512  */
    /* JADX WARN: Code duplicated, block: B:203:0x0515  */
    /* JADX WARN: Code duplicated, block: B:204:0x0518  */
    /* JADX WARN: Code duplicated, block: B:206:0x051b  */
    /* JADX WARN: Code duplicated, block: B:207:0x051e  */
    /* JADX WARN: Code duplicated, block: B:209:0x0522  */
    /* JADX WARN: Code duplicated, block: B:210:0x0525  */
    /* JADX WARN: Code duplicated, block: B:214:0x0532  */
    /* JADX WARN: Code duplicated, block: B:216:0x053e  */
    /* JADX WARN: Code duplicated, block: B:219:0x054d  */
    /* JADX WARN: Code duplicated, block: B:245:0x02e4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:246:0x025e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:250:0x0256 A[EDGE_INSN: B:250:0x0256->B:78:0x0256 BREAK  A[LOOP:10: B:74:0x0239->B:77:0x0241], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:253:0x0303 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:254:0x02fa A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:70:0x0203  */
    /* JADX WARN: Code duplicated, block: B:73:0x0233  */
    /* JADX WARN: Code duplicated, block: B:75:0x023b  */
    /* JADX WARN: Code duplicated, block: B:77:0x0241 A[LOOP:10: B:74:0x0239->B:77:0x0241, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:81:0x027c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:82:0x027e  */
    /* JADX WARN: Code duplicated, block: B:84:0x0282 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:89:0x029d  */
    /* JADX WARN: Code duplicated, block: B:92:0x02a5  */
    /* JADX WARN: Code duplicated, block: B:93:0x02a8  */
    /* JADX WARN: Code duplicated, block: B:96:0x02ae  */
    /* JADX WARN: Code duplicated, block: B:98:0x02b4  */
    public static s d(p pVar, a aVar, o oVar) throws j0 {
        d dVar;
        boolean z9;
        int iA;
        int iA2;
        int i9;
        int iA3;
        int iA4;
        int i10;
        d dVar2;
        long j;
        S8.y yVar;
        long[] jArr;
        long[] jArr2;
        int i11;
        long j9;
        long[] jArr3;
        int[] iArr;
        long[] jArrCopyOf;
        int[] iArrCopyOf;
        S8.y yVar2;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        long j10;
        long j11;
        int iA5;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        int[] iArrCopyOf2;
        int i24;
        int i25;
        String str;
        long[] jArr4;
        long[] jArr5;
        int[] iArr2;
        int iMax;
        long j12;
        long j13;
        int i26;
        boolean zA;
        int i27;
        int iD;
        int i28;
        int iA6;
        int[] iArr3;
        long jO;
        int i29;
        int i30;
        long j14;
        int[] iArr4;
        long[] jArr6;
        long[] jArr7;
        int i31;
        int i32;
        boolean z10;
        int[] iArr5;
        int[] iArr6;
        int i33;
        boolean z11;
        int i34;
        int i35;
        int i36;
        int[] iArr7;
        int[] iArr8;
        boolean z12;
        boolean z13;
        long[] jArr8;
        int[] iArr9;
        int i37;
        int[] iArr10;
        long[] jArr9;
        int i38;
        int i39;
        int i40;
        long j15;
        long j16;
        int i41;
        int i42;
        int[] iArr11;
        int[] iArr12;
        long j17;
        int i43;
        int i44;
        int i45;
        boolean z14;
        long j18;
        int i46;
        boolean z15;
        N n9 = pVar.f23899f;
        b bVarS = aVar.s(1937011578);
        if (bVarS != null) {
            S8.y yVar3 = new S8.y();
            S8.y yVar4 = bVarS.f23790c;
            yVar3.f7101c = yVar4;
            yVar4.H(12);
            int iA7 = yVar4.A();
            if ("audio/raw".equals(n9.f17509l)) {
                int iX = y.x(n9.f17494A, n9.f17522y);
                if (iA7 == 0 || iA7 % iX != 0) {
                    a.P("AtomParsers", "Audio sample size mismatch. stsd sample size: " + iX + ", stsz sample size: " + iA7);
                    iA7 = iX;
                }
            }
            if (iA7 == 0) {
                iA7 = -1;
            }
            yVar3.f7099a = iA7;
            yVar3.f7100b = yVar4.A();
            dVar = yVar3;
        } else {
            b bVarS2 = aVar.s(1937013298);
            if (bVarS2 == null) {
                throw j0.a("Track has no sample table size information", null);
            }
            e eVar = new e();
            S8.y yVar5 = bVarS2.f23790c;
            eVar.f23804e = yVar5;
            yVar5.H(12);
            eVar.f23801b = yVar5.A() & 255;
            eVar.f23800a = yVar5.A();
            dVar = eVar;
        }
        int iB = dVar.b();
        if (iB == 0) {
            return new s(pVar, new long[0], new int[0], 0, new long[0], new int[0], 0L);
        }
        b bVarS3 = aVar.s(1937007471);
        if (bVarS3 == null) {
            bVarS3 = aVar.s(1668232756);
            bVarS3.getClass();
            z9 = true;
        } else {
            z9 = false;
        }
        S8.y yVar6 = bVarS3.f23790c;
        b bVarS4 = aVar.s(1937011555);
        bVarS4.getClass();
        S8.y yVar7 = bVarS4.f23790c;
        b bVarS5 = aVar.s(1937011827);
        bVarS5.getClass();
        S8.y yVar8 = bVarS5.f23790c;
        b bVarS6 = aVar.s(1937011571);
        S8.y yVar9 = bVarS6 != null ? bVarS6.f23790c : null;
        b bVarS7 = aVar.s(1668576371);
        S8.y yVar10 = bVarS7 != null ? bVarS7.f23790c : null;
        c cVar = new c(yVar7, yVar6, z9);
        yVar8.H(12);
        int iA8 = yVar8.A() - 1;
        int iA9 = yVar8.A();
        int iA10 = yVar8.A();
        if (yVar10 != null) {
            yVar10.H(12);
            iA = yVar10.A();
        } else {
            iA = 0;
        }
        if (yVar9 != null) {
            yVar9.H(12);
            iA2 = yVar9.A();
            if (iA2 > 0) {
                iA3 = yVar9.A() - 1;
                i9 = 0;
            } else {
                i9 = 0;
                yVar9 = null;
            }
            iA4 = dVar.a();
            i10 = pVar.f23895b;
            dVar2 = dVar;
            j = pVar.f23896c;
            yVar = yVar10;
            jArr = pVar.f23902i;
            jArr2 = pVar.f23901h;
            i11 = iA2;
            String str2 = n9.f17509l;
            j9 = 0;
            if (iA4 == -1 && (("audio/raw".equals(str2) || "audio/g711-mlaw".equals(str2) || "audio/g711-alaw".equals(str2)) && iA8 == 0 && iA == 0 && i11 == 0)) {
                int i47 = cVar.f23791a;
                long[] jArr10 = new long[i47];
                int[] iArr13 = new int[i47];
                while (cVar.a()) {
                    int i48 = cVar.f23792b;
                    long[] jArr11 = jArr10;
                    int[] iArr14 = iArr13;
                    jArr11[i48] = cVar.f23794d;
                    iArr14[i48] = cVar.f23793c;
                    jArr10 = jArr11;
                    iArr13 = iArr14;
                }
                long[] jArr12 = jArr10;
                int[] iArr15 = iArr13;
                long j19 = iA10;
                int i49 = 8192 / iA4;
                int i50 = i9;
                int iF = i50;
                while (i50 < i47) {
                    iF += y.f(iArr15[i50], i49);
                    i50++;
                    iA4 = iA4;
                }
                int i51 = iA4;
                long[] jArr13 = new long[iF];
                iArrCopyOf2 = new int[iF];
                long[] jArr14 = new long[iF];
                iArr2 = new int[iF];
                int i52 = i9;
                int i53 = i52;
                iMax = i53;
                int i54 = iMax;
                while (i52 < i47) {
                    int i55 = iArr15[i52];
                    long j20 = jArr12[i52];
                    int i56 = i52;
                    int i57 = i55;
                    while (i57 > 0) {
                        int iMin = Math.min(i49, i57);
                        jArr13[i54] = j20;
                        int i58 = i57;
                        int i59 = i51 * iMin;
                        iArrCopyOf2[i54] = i59;
                        iMax = Math.max(iMax, i59);
                        jArr14[i54] = ((long) i53) * j19;
                        iArr2[i54] = 1;
                        j20 += (long) iArrCopyOf2[i54];
                        i53 += iMin;
                        i57 = i58 - iMin;
                        i54++;
                        i47 = i47;
                    }
                    i52 = i56 + 1;
                }
                j12 = ((long) i53) * j19;
                jArr4 = jArr13;
                jArr5 = jArr14;
            } else {
                jArr3 = new long[iB];
                iArr = new int[iB];
                jArrCopyOf = new long[iB];
                iArrCopyOf = new int[iB];
                yVar2 = yVar9;
                i12 = iA10;
                i13 = i9;
                i14 = i13;
                i15 = i14;
                i16 = i11;
                i17 = iA9;
                j10 = 0;
                j11 = 0;
                iA5 = iA3;
                i18 = i15;
                i19 = iA;
                i20 = iA8;
                i21 = i18;
                while (true) {
                    if (i21 >= iB) {
                        i22 = i20;
                        i23 = i17;
                        iArrCopyOf2 = iArr;
                        i24 = i14;
                        break;
                    }
                    j13 = j11;
                    i26 = i14;
                    zA = true;
                    while (i26 == 0) {
                        zA = cVar.a();
                        if (!zA) {
                            break;
                        }
                        int i60 = i20;
                        long j21 = cVar.f23794d;
                        i26 = cVar.f23793c;
                        j13 = j21;
                        i20 = i60;
                        i17 = i17;
                        iB = iB;
                    }
                    i27 = iB;
                    i22 = i20;
                    i23 = i17;
                    if (!zA) {
                        a.P("AtomParsers", "Unexpected end of chunk data");
                        long[] jArrCopyOf2 = Arrays.copyOf(jArr3, i21);
                        iArrCopyOf2 = Arrays.copyOf(iArr, i21);
                        jArrCopyOf = Arrays.copyOf(jArrCopyOf, i21);
                        iArrCopyOf = Arrays.copyOf(iArrCopyOf, i21);
                        iB = i21;
                        jArr3 = jArrCopyOf2;
                        i24 = i26;
                        break;
                    }
                    if (yVar != null) {
                        iA6 = i15;
                        while (iA6 == 0 && i19 > 0) {
                            iA6 = yVar.A();
                            i18 = yVar.i();
                            i19--;
                        }
                        i15 = iA6 - 1;
                    }
                    jArr3[i21] = j13;
                    iD = dVar2.d();
                    iArr[i21] = iD;
                    if (iD > i13) {
                        i13 = iD;
                    }
                    jArrCopyOf[i21] = j10 + ((long) i18);
                    if (yVar2 == null) {
                        i28 = 1;
                    } else {
                        i28 = i9;
                    }
                    iArrCopyOf[i21] = i28;
                    if (i21 == iA5) {
                        iArrCopyOf[i21] = 1;
                        i16--;
                        if (i16 > 0) {
                            yVar2.getClass();
                            iA5 = yVar2.A() - 1;
                        }
                    }
                    j10 += (long) i12;
                    i17 = i23 - 1;
                    if (i17 == 0 || i22 <= 0) {
                        i20 = i22;
                    } else {
                        int iA11 = yVar8.A();
                        int i61 = yVar8.i();
                        i20 = i22 - 1;
                        i17 = iA11;
                        i12 = i61;
                    }
                    long j22 = j13 + ((long) iArr[i21]);
                    i14 = i26 - 1;
                    i21++;
                    j11 = j22;
                    iB = i27;
                }
                long j23 = j10 + ((long) i18);
                if (yVar == null) {
                    i25 = 1;
                    break;
                }
                while (true) {
                    if (i19 <= 0) {
                        i25 = 1;
                        break;
                    }
                    if (yVar.A() != 0) {
                        i25 = i9;
                        break;
                    }
                    yVar.i();
                    i19--;
                }
                if (i16 == 0 || i23 != 0 || i24 != 0 || i22 != 0 || i15 != 0 || i25 == 0) {
                    StringBuilder sb = new StringBuilder("Inconsistent stbl box for track ");
                    sb.append(pVar.f23894a);
                    sb.append(": remainingSynchronizationSamples ");
                    sb.append(i16);
                    sb.append(", remainingSamplesAtTimestampDelta ");
                    sb.append(i23);
                    sb.append(", remainingSamplesInChunk ");
                    sb.append(i24);
                    sb.append(", remainingTimestampDeltaChanges ");
                    sb.append(i22);
                    sb.append(", remainingSamplesAtTimestampOffset ");
                    sb.append(i15);
                    if (i25 == 0) {
                        str = ", ctts invalid";
                    } else {
                        str = "";
                    }
                    sb.append(str);
                    a.P("AtomParsers", sb.toString());
                }
                jArr4 = jArr3;
                jArr5 = jArrCopyOf;
                iArr2 = iArrCopyOf;
                iMax = i13;
                j12 = j23;
            }
            iArr3 = iArrCopyOf2;
            jO = y.O(j12, 1000000L, pVar.f23896c);
            if (jArr2 == 0) {
                y.P(jArr5, j);
                return new s(pVar, jArr4, iArr3, iMax, jArr5, iArr2, jO);
            }
            int i62 = iMax;
            i29 = iB;
            i30 = i62;
            j14 = j12;
            iArr4 = iArr2;
            jArr6 = jArr5;
            if (jArr7.length == 1) {
                i31 = i10;
                if (i31 == 1 || jArr6.length < 2) {
                    jArr7 = jArr2;
                    jArr7 = jArr2;
                } else {
                    jArr.getClass();
                    long j24 = jArr[i9];
                    long[] jArr15 = jArr4;
                    long jO2 = y.O(jArr7[i9], pVar.f23896c, pVar.f23897d) + j24;
                    int length = jArr6.length - 1;
                    int i63 = i9;
                    int i64 = y.i(4, i63, length);
                    int i65 = y.i(jArr6.length - 4, i63, length);
                    long j25 = jArr6[i63];
                    if (j25 > j24 || j24 >= jArr6[i64] || jArr6[i65] >= jO2 || jO2 > j14) {
                        jArr7 = jArr2;
                        jArr7 = jArr2;
                        jArr7 = jArr2;
                        jArr7 = jArr2;
                        z15 = false;
                    } else {
                        z15 = true;
                    }
                    if (z15) {
                        long jO3 = y.O(j24 - j25, n9.f17523z, pVar.f23896c);
                        long jO4 = y.O(j14 - jO2, n9.f17523z, pVar.f23896c);
                        if (jO3 != 0 || jO4 != 0) {
                            jArr7 = jArr2;
                            jArr7 = jArr2;
                            if (jO3 <= 2147483647L && jO4 <= 2147483647L) {
                                oVar.f21280a = (int) jO3;
                                oVar.f21281b = (int) jO4;
                                y.P(jArr6, j);
                                return new s(pVar, jArr15, iArr3, i30, jArr6, iArr4, y.O(jArr7[0], 1000000L, pVar.f23897d));
                            }
                        }
                        jArr7 = jArr2;
                        iArr4 = iArr4;
                        iArr3 = iArr3;
                        i30 = i30;
                        jArr4 = jArr15;
                    } else {
                        jArr7 = jArr2;
                        jArr4 = jArr15;
                        iArr3 = iArr3;
                        i30 = i30;
                    }
                }
            } else {
                jArr7 = jArr2;
                i31 = i10;
            }
            i32 = 1;
            if (jArr7.length == 1) {
                if (jArr7[0] == 0) {
                    jArr.getClass();
                    j18 = jArr[0];
                    for (i46 = 0; i46 < jArr6.length; i46++) {
                        jArr6[i46] = y.O(jArr6[i46] - j18, 1000000L, pVar.f23896c);
                    }
                    return new s(pVar, jArr4, iArr3, i30, jArr6, iArr4, y.O(j14 - j18, 1000000L, pVar.f23896c));
                }
                i32 = 1;
            }
            if (i31 == i32) {
                z10 = true;
            } else {
                z10 = false;
            }
            iArr5 = new int[jArr7.length];
            iArr6 = new int[jArr7.length];
            jArr.getClass();
            i33 = 0;
            z11 = false;
            i34 = 0;
            i35 = 0;
            while (i33 < jArr7.length) {
                iArr11 = iArr5;
                iArr12 = iArr6;
                j17 = jArr[i33];
                if (j17 != -1) {
                    i43 = i33;
                    boolean z16 = z11;
                    long jO5 = y.O(jArr7[i33], pVar.f23896c, pVar.f23897d);
                    iArr11[i43] = y.e(jArr6, j17, true);
                    iArr12[i43] = y.b(jArr6, j17 + jO5, z10);
                    while (true) {
                        i44 = iArr11[i43];
                        i45 = iArr12[i43];
                        if (i44 >= i45 || (iArr4[i44] & 1) != 0) {
                            break;
                        }
                        iArr11[i43] = i44 + 1;
                    }
                    int i66 = (i45 - i44) + i34;
                    if (i35 != i44) {
                        z14 = true;
                    } else {
                        z14 = false;
                    }
                    z11 = z16 | z14;
                    i35 = i45;
                    i34 = i66;
                } else {
                    i43 = i33;
                }
                i33 = i43 + 1;
                iArr5 = iArr11;
                iArr6 = iArr12;
                i30 = i30;
            }
            i36 = i30;
            iArr7 = iArr5;
            iArr8 = iArr6;
            boolean z17 = z11;
            if (i34 != i29) {
                z12 = true;
            } else {
                z12 = false;
            }
            z13 = z17 | z12;
            if (z13) {
                jArr8 = new long[i34];
            } else {
                jArr8 = jArr4;
            }
            if (z13) {
                iArr9 = new int[i34];
            } else {
                iArr9 = iArr3;
            }
            if (z13) {
                i37 = 0;
            } else {
                i37 = i36;
            }
            if (z13) {
                iArr10 = new int[i34];
            } else {
                iArr10 = iArr4;
            }
            jArr9 = new long[i34];
            i38 = i37;
            i39 = 0;
            i40 = 0;
            j15 = 0;
            while (i39 < jArr7.length) {
                j16 = jArr[i39];
                i41 = iArr7[i39];
                long[] jArr16 = jArr7;
                i42 = iArr8[i39];
                int i67 = i38;
                if (z13) {
                    int i68 = i42 - i41;
                    System.arraycopy(jArr4, i41, jArr8, i40, i68);
                    System.arraycopy(iArr3, i41, iArr9, i40, i68);
                    System.arraycopy(iArr4, i41, iArr10, i40, i68);
                }
                i38 = i67;
                while (i41 < i42) {
                    long[] jArr17 = jArr4;
                    int[] iArr16 = iArr3;
                    long jO6 = y.O(j15, 1000000L, pVar.f23897d);
                    long j26 = jArr6[i41] - j16;
                    long[] jArr18 = jArr6;
                    int[] iArr17 = iArr4;
                    long j27 = j9;
                    jArr9[i40] = jO6 + y.O(Math.max(j27, j26), 1000000L, pVar.f23896c);
                    if (!z13 && iArr9[i40] > i38) {
                        i38 = iArr16[i41];
                    }
                    i40++;
                    i41++;
                    j9 = j27;
                    jArr4 = jArr17;
                    iArr3 = iArr16;
                    iArr4 = iArr17;
                    jArr6 = jArr18;
                }
                j15 += jArr16[i39];
                i39++;
                jArr4 = jArr4;
                iArr3 = iArr3;
                iArr4 = iArr4;
                jArr6 = jArr6;
                jArr7 = jArr16;
            }
            return new s(pVar, jArr8, iArr9, i38, jArr9, iArr10, y.O(j15, 1000000L, pVar.f23897d));
        }
        iA2 = 0;
        i9 = 0;
        iA3 = -1;
        iA4 = dVar.a();
        i10 = pVar.f23895b;
        dVar2 = dVar;
        j = pVar.f23896c;
        yVar = yVar10;
        jArr = pVar.f23902i;
        jArr2 = pVar.f23901h;
        i11 = iA2;
        String str3 = n9.f17509l;
        j9 = 0;
        if (iA4 == -1) {
            jArr3 = new long[iB];
            iArr = new int[iB];
            jArrCopyOf = new long[iB];
            iArrCopyOf = new int[iB];
            yVar2 = yVar9;
            i12 = iA10;
            i13 = i9;
            i14 = i13;
            i15 = i14;
            i16 = i11;
            i17 = iA9;
            j10 = 0;
            j11 = 0;
            iA5 = iA3;
            i18 = i15;
            i19 = iA;
            i20 = iA8;
            i21 = i18;
            while (true) {
                if (i21 >= iB) {
                    i22 = i20;
                    i23 = i17;
                    iArrCopyOf2 = iArr;
                    i24 = i14;
                    break;
                }
                j13 = j11;
                i26 = i14;
                zA = true;
                while (i26 == 0) {
                    zA = cVar.a();
                    if (!zA) {
                        break;
                        break;
                    }
                    int i69 = i20;
                    long j28 = cVar.f23794d;
                    i26 = cVar.f23793c;
                    j13 = j28;
                    i20 = i69;
                    i17 = i17;
                    iB = iB;
                }
                i27 = iB;
                i22 = i20;
                i23 = i17;
                if (!zA) {
                    a.P("AtomParsers", "Unexpected end of chunk data");
                    long[] jArrCopyOf3 = Arrays.copyOf(jArr3, i21);
                    iArrCopyOf2 = Arrays.copyOf(iArr, i21);
                    jArrCopyOf = Arrays.copyOf(jArrCopyOf, i21);
                    iArrCopyOf = Arrays.copyOf(iArrCopyOf, i21);
                    iB = i21;
                    jArr3 = jArrCopyOf3;
                    i24 = i26;
                    break;
                }
                if (yVar != null) {
                    iA6 = i15;
                    while (iA6 == 0) {
                        iA6 = yVar.A();
                        i18 = yVar.i();
                        i19--;
                    }
                    i15 = iA6 - 1;
                }
                jArr3[i21] = j13;
                iD = dVar2.d();
                iArr[i21] = iD;
                if (iD > i13) {
                    i13 = iD;
                }
                jArrCopyOf[i21] = j10 + ((long) i18);
                if (yVar2 == null) {
                    i28 = 1;
                } else {
                    i28 = i9;
                }
                iArrCopyOf[i21] = i28;
                if (i21 == iA5) {
                    iArrCopyOf[i21] = 1;
                    i16--;
                    if (i16 > 0) {
                        yVar2.getClass();
                        iA5 = yVar2.A() - 1;
                    }
                }
                j10 += (long) i12;
                i17 = i23 - 1;
                if (i17 == 0) {
                    i20 = i22;
                } else {
                    i20 = i22;
                }
                long j29 = j13 + ((long) iArr[i21]);
                i14 = i26 - 1;
                i21++;
                j11 = j29;
                iB = i27;
            }
            long j210 = j10 + ((long) i18);
            if (yVar == null) {
                i25 = 1;
                break;
            }
            while (true) {
                if (i19 <= 0) {
                    i25 = 1;
                    break;
                }
                if (yVar.A() != 0) {
                    i25 = i9;
                    break;
                }
                yVar.i();
                i19--;
            }
            if (i16 == 0) {
                StringBuilder sb2 = new StringBuilder("Inconsistent stbl box for track ");
                sb2.append(pVar.f23894a);
                sb2.append(": remainingSynchronizationSamples ");
                sb2.append(i16);
                sb2.append(", remainingSamplesAtTimestampDelta ");
                sb2.append(i23);
                sb2.append(", remainingSamplesInChunk ");
                sb2.append(i24);
                sb2.append(", remainingTimestampDeltaChanges ");
                sb2.append(i22);
                sb2.append(", remainingSamplesAtTimestampOffset ");
                sb2.append(i15);
                if (i25 == 0) {
                    str = ", ctts invalid";
                } else {
                    str = "";
                }
                sb2.append(str);
                a.P("AtomParsers", sb2.toString());
            } else {
                StringBuilder sb3 = new StringBuilder("Inconsistent stbl box for track ");
                sb3.append(pVar.f23894a);
                sb3.append(": remainingSynchronizationSamples ");
                sb3.append(i16);
                sb3.append(", remainingSamplesAtTimestampDelta ");
                sb3.append(i23);
                sb3.append(", remainingSamplesInChunk ");
                sb3.append(i24);
                sb3.append(", remainingTimestampDeltaChanges ");
                sb3.append(i22);
                sb3.append(", remainingSamplesAtTimestampOffset ");
                sb3.append(i15);
                if (i25 == 0) {
                    str = ", ctts invalid";
                } else {
                    str = "";
                }
                sb3.append(str);
                a.P("AtomParsers", sb3.toString());
            }
            jArr4 = jArr3;
            jArr5 = jArrCopyOf;
            iArr2 = iArrCopyOf;
            iMax = i13;
            j12 = j210;
        } else {
            jArr3 = new long[iB];
            iArr = new int[iB];
            jArrCopyOf = new long[iB];
            iArrCopyOf = new int[iB];
            yVar2 = yVar9;
            i12 = iA10;
            i13 = i9;
            i14 = i13;
            i15 = i14;
            i16 = i11;
            i17 = iA9;
            j10 = 0;
            j11 = 0;
            iA5 = iA3;
            i18 = i15;
            i19 = iA;
            i20 = iA8;
            i21 = i18;
            while (true) {
                if (i21 >= iB) {
                    i22 = i20;
                    i23 = i17;
                    iArrCopyOf2 = iArr;
                    i24 = i14;
                    break;
                }
                j13 = j11;
                i26 = i14;
                zA = true;
                while (i26 == 0) {
                    zA = cVar.a();
                    if (!zA) {
                        break;
                        break;
                    }
                    int i610 = i20;
                    long j211 = cVar.f23794d;
                    i26 = cVar.f23793c;
                    j13 = j211;
                    i20 = i610;
                    i17 = i17;
                    iB = iB;
                }
                i27 = iB;
                i22 = i20;
                i23 = i17;
                if (!zA) {
                    a.P("AtomParsers", "Unexpected end of chunk data");
                    long[] jArrCopyOf4 = Arrays.copyOf(jArr3, i21);
                    iArrCopyOf2 = Arrays.copyOf(iArr, i21);
                    jArrCopyOf = Arrays.copyOf(jArrCopyOf, i21);
                    iArrCopyOf = Arrays.copyOf(iArrCopyOf, i21);
                    iB = i21;
                    jArr3 = jArrCopyOf4;
                    i24 = i26;
                    break;
                }
                if (yVar != null) {
                    iA6 = i15;
                    while (iA6 == 0) {
                        iA6 = yVar.A();
                        i18 = yVar.i();
                        i19--;
                    }
                    i15 = iA6 - 1;
                }
                jArr3[i21] = j13;
                iD = dVar2.d();
                iArr[i21] = iD;
                if (iD > i13) {
                    i13 = iD;
                }
                jArrCopyOf[i21] = j10 + ((long) i18);
                if (yVar2 == null) {
                    i28 = 1;
                } else {
                    i28 = i9;
                }
                iArrCopyOf[i21] = i28;
                if (i21 == iA5) {
                    iArrCopyOf[i21] = 1;
                    i16--;
                    if (i16 > 0) {
                        yVar2.getClass();
                        iA5 = yVar2.A() - 1;
                    }
                }
                j10 += (long) i12;
                i17 = i23 - 1;
                if (i17 == 0) {
                    i20 = i22;
                } else {
                    i20 = i22;
                }
                long j212 = j13 + ((long) iArr[i21]);
                i14 = i26 - 1;
                i21++;
                j11 = j212;
                iB = i27;
            }
            long j213 = j10 + ((long) i18);
            if (yVar == null) {
                i25 = 1;
                break;
            }
            while (true) {
                if (i19 <= 0) {
                    i25 = 1;
                    break;
                }
                if (yVar.A() != 0) {
                    i25 = i9;
                    break;
                }
                yVar.i();
                i19--;
            }
            if (i16 == 0) {
                StringBuilder sb4 = new StringBuilder("Inconsistent stbl box for track ");
                sb4.append(pVar.f23894a);
                sb4.append(": remainingSynchronizationSamples ");
                sb4.append(i16);
                sb4.append(", remainingSamplesAtTimestampDelta ");
                sb4.append(i23);
                sb4.append(", remainingSamplesInChunk ");
                sb4.append(i24);
                sb4.append(", remainingTimestampDeltaChanges ");
                sb4.append(i22);
                sb4.append(", remainingSamplesAtTimestampOffset ");
                sb4.append(i15);
                if (i25 == 0) {
                    str = ", ctts invalid";
                } else {
                    str = "";
                }
                sb4.append(str);
                a.P("AtomParsers", sb4.toString());
            } else {
                StringBuilder sb5 = new StringBuilder("Inconsistent stbl box for track ");
                sb5.append(pVar.f23894a);
                sb5.append(": remainingSynchronizationSamples ");
                sb5.append(i16);
                sb5.append(", remainingSamplesAtTimestampDelta ");
                sb5.append(i23);
                sb5.append(", remainingSamplesInChunk ");
                sb5.append(i24);
                sb5.append(", remainingTimestampDeltaChanges ");
                sb5.append(i22);
                sb5.append(", remainingSamplesAtTimestampOffset ");
                sb5.append(i15);
                if (i25 == 0) {
                    str = ", ctts invalid";
                } else {
                    str = "";
                }
                sb5.append(str);
                a.P("AtomParsers", sb5.toString());
            }
            jArr4 = jArr3;
            jArr5 = jArrCopyOf;
            iArr2 = iArrCopyOf;
            iMax = i13;
            j12 = j213;
        }
        iArr3 = iArrCopyOf2;
        jO = y.O(j12, 1000000L, pVar.f23896c);
        if (jArr2 == 0) {
            y.P(jArr5, j);
            return new s(pVar, jArr4, iArr3, iMax, jArr5, iArr2, jO);
        }
        int i611 = iMax;
        i29 = iB;
        i30 = i611;
        j14 = j12;
        iArr4 = iArr2;
        jArr6 = jArr5;
        if (jArr7.length == 1) {
            i31 = i10;
            if (i31 == 1) {
                jArr7 = jArr2;
                jArr7 = jArr2;
            } else {
                jArr7 = jArr2;
                jArr7 = jArr2;
            }
        } else {
            jArr7 = jArr2;
            i31 = i10;
        }
        i32 = 1;
        if (jArr7.length == 1) {
            if (jArr7[0] == 0) {
                jArr.getClass();
                j18 = jArr[0];
                while (i46 < jArr6.length) {
                    jArr6[i46] = y.O(jArr6[i46] - j18, 1000000L, pVar.f23896c);
                }
                return new s(pVar, jArr4, iArr3, i30, jArr6, iArr4, y.O(j14 - j18, 1000000L, pVar.f23896c));
            }
            i32 = 1;
        }
        if (i31 == i32) {
            z10 = true;
        } else {
            z10 = false;
        }
        iArr5 = new int[jArr7.length];
        iArr6 = new int[jArr7.length];
        jArr.getClass();
        i33 = 0;
        z11 = false;
        i34 = 0;
        i35 = 0;
        while (i33 < jArr7.length) {
            iArr11 = iArr5;
            iArr12 = iArr6;
            j17 = jArr[i33];
            if (j17 != -1) {
                i43 = i33;
                boolean z18 = z11;
                long jO7 = y.O(jArr7[i33], pVar.f23896c, pVar.f23897d);
                iArr11[i43] = y.e(jArr6, j17, true);
                iArr12[i43] = y.b(jArr6, j17 + jO7, z10);
                while (true) {
                    i44 = iArr11[i43];
                    i45 = iArr12[i43];
                    if (i44 >= i45) {
                        break;
                    }
                    break;
                    break;
                    iArr11[i43] = i44 + 1;
                }
                int i612 = (i45 - i44) + i34;
                if (i35 != i44) {
                    z14 = true;
                } else {
                    z14 = false;
                }
                z11 = z18 | z14;
                i35 = i45;
                i34 = i612;
            } else {
                i43 = i33;
            }
            i33 = i43 + 1;
            iArr5 = iArr11;
            iArr6 = iArr12;
            i30 = i30;
        }
        i36 = i30;
        iArr7 = iArr5;
        iArr8 = iArr6;
        boolean z19 = z11;
        if (i34 != i29) {
            z12 = true;
        } else {
            z12 = false;
        }
        z13 = z19 | z12;
        if (z13) {
            jArr8 = new long[i34];
        } else {
            jArr8 = jArr4;
        }
        if (z13) {
            iArr9 = new int[i34];
        } else {
            iArr9 = iArr3;
        }
        if (z13) {
            i37 = 0;
        } else {
            i37 = i36;
        }
        if (z13) {
            iArr10 = new int[i34];
        } else {
            iArr10 = iArr4;
        }
        jArr9 = new long[i34];
        i38 = i37;
        i39 = 0;
        i40 = 0;
        j15 = 0;
        while (i39 < jArr7.length) {
            j16 = jArr[i39];
            i41 = iArr7[i39];
            long[] jArr19 = jArr7;
            i42 = iArr8[i39];
            int i613 = i38;
            if (z13) {
                int i614 = i42 - i41;
                System.arraycopy(jArr4, i41, jArr8, i40, i614);
                System.arraycopy(iArr3, i41, iArr9, i40, i614);
                System.arraycopy(iArr4, i41, iArr10, i40, i614);
            }
            i38 = i613;
            while (i41 < i42) {
                long[] jArr110 = jArr4;
                int[] iArr18 = iArr3;
                long jO8 = y.O(j15, 1000000L, pVar.f23897d);
                long j214 = jArr6[i41] - j16;
                long[] jArr111 = jArr6;
                int[] iArr19 = iArr4;
                long j215 = j9;
                jArr9[i40] = jO8 + y.O(Math.max(j215, j214), 1000000L, pVar.f23896c);
                if (!z13) {
                }
                i40++;
                i41++;
                j9 = j215;
                jArr4 = jArr110;
                iArr3 = iArr18;
                iArr4 = iArr19;
                jArr6 = jArr111;
            }
            j15 += jArr19[i39];
            i39++;
            jArr4 = jArr4;
            iArr3 = iArr3;
            iArr4 = iArr4;
            jArr6 = jArr6;
            jArr7 = jArr19;
        }
        return new s(pVar, jArr8, iArr9, i38, jArr9, iArr10, y.O(j15, 1000000L, pVar.f23897d));
    }

    /* JADX WARN: Code duplicated, block: B:132:0x0272  */
    /* JADX WARN: Code duplicated, block: B:327:0x05c1  */
    /* JADX WARN: Code duplicated, block: B:329:0x05cc  */
    /* JADX WARN: Code duplicated, block: B:330:0x05ce  */
    /* JADX WARN: Code duplicated, block: B:333:0x05dd  */
    /* JADX WARN: Code duplicated, block: B:336:0x05fa  */
    /* JADX WARN: Code duplicated, block: B:338:0x0601  */
    /* JADX WARN: Code duplicated, block: B:344:0x061c  */
    /* JADX WARN: Code duplicated, block: B:346:0x0641  */
    /* JADX WARN: Code duplicated, block: B:349:0x0665 A[PHI: r26 r43 r51
      0x0665: PHI (r26v13 f2.N) = (r26v9 f2.N), (r26v14 f2.N) binds: [B:392:0x07b7, B:348:0x0661] A[DONT_GENERATE, DONT_INLINE]
      0x0665: PHI (r43v10 java.lang.String) = (r43v9 java.lang.String), (r43v11 java.lang.String) binds: [B:392:0x07b7, B:348:0x0661] A[DONT_GENERATE, DONT_INLINE]
      0x0665: PHI (r51v9 java.lang.String) = (r51v6 java.lang.String), (r51v10 java.lang.String) binds: [B:392:0x07b7, B:348:0x0661] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:350:0x0669  */
    /* JADX WARN: Code duplicated, block: B:352:0x0670  */
    /* JADX WARN: Code duplicated, block: B:354:0x0699  */
    /* JADX WARN: Code duplicated, block: B:366:0x06c6  */
    /* JADX WARN: Code duplicated, block: B:369:0x06e3  */
    /* JADX WARN: Code duplicated, block: B:371:0x06ea  */
    /* JADX WARN: Code duplicated, block: B:373:0x0701  */
    /* JADX WARN: Code duplicated, block: B:374:0x0705  */
    /* JADX WARN: Code duplicated, block: B:376:0x0720  */
    /* JADX WARN: Code duplicated, block: B:378:0x0725 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:379:0x0727  */
    /* JADX WARN: Code duplicated, block: B:382:0x0742  */
    /* JADX WARN: Code duplicated, block: B:384:0x0747  */
    /* JADX WARN: Code duplicated, block: B:385:0x0765  */
    /* JADX WARN: Code duplicated, block: B:387:0x076a  */
    /* JADX WARN: Code duplicated, block: B:388:0x0783  */
    /* JADX WARN: Code duplicated, block: B:390:0x0788  */
    /* JADX WARN: Code duplicated, block: B:391:0x07b3  */
    /* JADX WARN: Code duplicated, block: B:393:0x07b9  */
    /* JADX WARN: Code duplicated, block: B:395:0x080c  */
    /* JADX WARN: Code duplicated, block: B:397:0x081b  */
    /* JADX WARN: Code duplicated, block: B:399:0x081e  */
    /* JADX WARN: Code duplicated, block: B:401:0x0822  */
    /* JADX WARN: Code duplicated, block: B:403:0x0825  */
    /* JADX WARN: Code duplicated, block: B:407:0x082e  */
    /* JADX WARN: Code duplicated, block: B:409:0x0837  */
    /* JADX WARN: Code duplicated, block: B:410:0x0839  */
    /* JADX WARN: Code duplicated, block: B:414:0x0847 A[LOOP:4: B:405:0x082a->B:414:0x0847, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:417:0x0850  */
    /* JADX WARN: Code duplicated, block: B:419:0x085f  */
    /* JADX WARN: Code duplicated, block: B:421:0x0867  */
    /* JADX WARN: Code duplicated, block: B:422:0x087e  */
    /* JADX WARN: Code duplicated, block: B:424:0x0887  */
    /* JADX WARN: Code duplicated, block: B:426:0x088d  */
    /* JADX WARN: Code duplicated, block: B:433:0x08cb  */
    /* JADX WARN: Code duplicated, block: B:438:0x090c  */
    /* JADX WARN: Code duplicated, block: B:440:0x0916  */
    /* JADX WARN: Code duplicated, block: B:442:0x0920  */
    /* JADX WARN: Code duplicated, block: B:443:0x0924  */
    /* JADX WARN: Code duplicated, block: B:445:0x0937  */
    /* JADX WARN: Code duplicated, block: B:447:0x093e  */
    /* JADX WARN: Code duplicated, block: B:450:0x094c  */
    /* JADX WARN: Code duplicated, block: B:451:0x094f  */
    /* JADX WARN: Code duplicated, block: B:453:0x0954  */
    /* JADX WARN: Code duplicated, block: B:454:0x0956  */
    /* JADX WARN: Code duplicated, block: B:458:0x0977  */
    /* JADX WARN: Code duplicated, block: B:460:0x0986  */
    /* JADX WARN: Code duplicated, block: B:464:0x09a1  */
    /* JADX WARN: Code duplicated, block: B:465:0x09a3  */
    /* JADX WARN: Code duplicated, block: B:468:0x09b2 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:469:0x09b4  */
    /* JADX WARN: Code duplicated, block: B:471:0x09b7  */
    /* JADX WARN: Code duplicated, block: B:474:0x09cb  */
    /* JADX WARN: Code duplicated, block: B:477:0x09eb  */
    /* JADX WARN: Code duplicated, block: B:479:0x09f0 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:480:0x09f2  */
    /* JADX WARN: Code duplicated, block: B:482:0x09f5  */
    /* JADX WARN: Code duplicated, block: B:485:0x0a09  */
    /* JADX WARN: Code duplicated, block: B:487:0x0a10  */
    /* JADX WARN: Code duplicated, block: B:489:0x0a15  */
    /* JADX WARN: Code duplicated, block: B:491:0x0a1a  */
    /* JADX WARN: Code duplicated, block: B:610:0x0c7d  */
    /* JADX WARN: Code duplicated, block: B:614:0x0c9c  */
    /* JADX WARN: Code duplicated, block: B:615:0x0ca1  */
    /* JADX WARN: Code duplicated, block: B:617:0x0cd1  */
    /* JADX WARN: Code duplicated, block: B:619:0x0cd7 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:622:0x0cdc  */
    /* JADX WARN: Code duplicated, block: B:625:0x0ce4  */
    /* JADX WARN: Code duplicated, block: B:626:0x0ce9  */
    /* JADX WARN: Code duplicated, block: B:629:0x0cf1  */
    /* JADX WARN: Code duplicated, block: B:635:0x0d42  */
    /* JADX WARN: Code duplicated, block: B:637:0x0d4d  */
    /* JADX WARN: Code duplicated, block: B:639:0x0d56  */
    /* JADX WARN: Code duplicated, block: B:640:0x0d58  */
    /* JADX WARN: Code duplicated, block: B:642:0x0d72  */
    /* JADX WARN: Code duplicated, block: B:644:0x0d75  */
    /* JADX WARN: Code duplicated, block: B:645:0x0d7a  */
    /* JADX WARN: Code duplicated, block: B:648:0x0d82  */
    /* JADX WARN: Code duplicated, block: B:649:0x0d87  */
    /* JADX WARN: Code duplicated, block: B:652:0x0d94 A[LOOP:7: B:641:0x0d70->B:652:0x0d94, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:657:0x0da9  */
    /* JADX WARN: Code duplicated, block: B:658:0x0db6  */
    /* JADX WARN: Code duplicated, block: B:661:0x0dbe  */
    /* JADX WARN: Code duplicated, block: B:662:0x0dc2  */
    /* JADX WARN: Code duplicated, block: B:672:0x072e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:673:0x0d9b A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:688:0x084c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:689:0x081c A[EDGE_INSN: B:689:0x081c->B:398:0x081c BREAK  A[LOOP:4: B:405:0x082a->B:414:0x0847], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:690:0x0c96 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:72:0x0134  */
    /* JADX WARN: Code duplicated, block: B:75:0x0139  */
    /* JADX WARN: Code duplicated, block: B:76:0x013c  */
    /* JADX WARN: Code duplicated, block: B:79:0x014f  */
    /* JADX WARN: Code duplicated, block: B:80:0x0152  */
    /* JADX WARN: Code duplicated, block: B:84:0x0163  */
    /* JADX WARN: Code duplicated, block: B:87:0x0197  */
    /* JADX WARN: Code duplicated, block: B:88:0x019a  */
    /* JADX WARN: Code duplicated, block: B:91:0x01a5  */
    /* JADX WARN: Code duplicated, block: B:92:0x01a7  */
    /* JADX WARN: Code duplicated, block: B:95:0x0207  */
    /* JADX WARN: Code duplicated, block: B:97:0x0211  */
    /* JADX WARN: Code duplicated, block: B:99:0x0215  */
    public static ArrayList e(a aVar, o oVar, long j, g gVar, boolean z9, boolean z10, K4.f fVar) throws j0 {
        int i9;
        long jY;
        int i10;
        int i11;
        long j9;
        S8.y yVar;
        int i12;
        long jY2;
        int iQ;
        int i13;
        int i14;
        Pair pairCreate;
        S8.y yVar2;
        String str;
        int i15;
        q[] qVarArr;
        long j10;
        int i16;
        N n9;
        int i17;
        int i18;
        ArrayList arrayList;
        ArrayList arrayList2;
        int i19;
        int i20;
        a aVar2;
        Pair pair;
        int i21;
        q[] qVarArr2;
        long[] jArr;
        long[] jArr2;
        p pVar;
        a aVarR;
        b bVarS;
        S8.y yVar3;
        int iQ2;
        int iA;
        long[] jArr3;
        long[] jArr4;
        int i22;
        Pair pairCreate2;
        long jY3;
        long jI;
        int i23;
        int i24;
        boolean z11;
        int i25;
        String str2;
        int i26;
        int i27;
        int i28;
        int iC;
        int iC2;
        int i29;
        int i30;
        int i31;
        g gVarA;
        String str3;
        int i32;
        int i33;
        boolean z12;
        String str4;
        float fA;
        int i34;
        int i35;
        String str5;
        byte[] bArr;
        List listV;
        int i36;
        ByteBuffer byteBufferOrder;
        Y y9;
        int i37;
        int i38;
        int i39;
        int i40;
        float f3;
        int i41;
        byte[] bArr2;
        g gVar2;
        List list;
        M m9;
        int i42;
        int i43;
        int i44;
        byte[] bArrArray;
        int i45;
        int i46;
        boolean z13;
        int i47;
        byte[] bArr3;
        List list2;
        w wVarB;
        int i48;
        byte[] bArrCopyOfRange;
        boolean z14;
        p079i3.e eVarA;
        List list3;
        int i49;
        String str6;
        String str7;
        boolean z15;
        p079i3.a aVarA;
        Pair pairC;
        int iC3;
        int iC4;
        int[] iArr;
        int i50;
        int iRound;
        int i51;
        int i52;
        g gVar3;
        String str8;
        String str9;
        int i53;
        String str10;
        int i54;
        int i55;
        int i56;
        List listV2;
        String str11;
        Y y10;
        List list4;
        int i57;
        String str12;
        M m10;
        int i58;
        boolean z16;
        int i59;
        List list5;
        int i60;
        int i61;
        int i62;
        boolean z17;
        int i63;
        boolean z18;
        Y yA;
        byte[] bArr4;
        int i64;
        N n10;
        int iX;
        int i65;
        String str13;
        int iX2;
        int i66;
        long j11;
        S sV;
        ArrayList arrayList3;
        a aVar3 = aVar;
        ArrayList arrayList4 = aVar3.f23789e;
        ArrayList arrayList5 = new ArrayList();
        int i67 = 0;
        while (i67 < arrayList4.size()) {
            a aVar4 = (a) arrayList4.get(i67);
            if (aVar4.f6888b != 1953653099) {
                arrayList = arrayList4;
                arrayList3 = arrayList5;
                i20 = i67;
            } else {
                b bVarS2 = aVar3.s(1836476516);
                bVarS2.getClass();
                a aVarR2 = aVar4.r(1835297121);
                aVarR2.getClass();
                b bVarS3 = aVarR2.s(1751411826);
                bVarS3.getClass();
                S8.y yVar4 = bVarS3.f23790c;
                yVar4.H(16);
                int i68 = yVar4.i();
                if (i68 == 1936684398) {
                    i9 = 1;
                } else if (i68 == 1986618469) {
                    i9 = 2;
                } else if (i68 == 1952807028 || i68 == 1935832172 || i68 == 1937072756 || i68 == 1668047728) {
                    i9 = 3;
                } else {
                    i9 = i68 == 1835365473 ? 5 : -1;
                }
                int i69 = 3;
                if (i9 == -1) {
                    arrayList = arrayList4;
                    arrayList2 = arrayList5;
                    i20 = i67;
                    pVar = null;
                } else {
                    b bVarS4 = aVar4.s(1953196132);
                    bVarS4.getClass();
                    S8.y yVar5 = bVarS4.f23790c;
                    yVar5.H(8);
                    int iQ3 = b.q(yVar5.i());
                    yVar5.I(iQ3 == 0 ? 8 : 16);
                    int i70 = yVar5.i();
                    yVar5.I(4);
                    int i71 = yVar5.f7099a;
                    int i72 = iQ3 == 0 ? 4 : 8;
                    int i73 = 0;
                    while (true) {
                        if (i73 >= i72) {
                            yVar5.I(i72);
                        } else {
                            if (((byte[]) yVar5.f7101c)[i71 + i73] != -1) {
                                jY = iQ3 == 0 ? yVar5.y() : yVar5.B();
                                if (jY != 0) {
                                    break;
                                }
                                break;
                            }
                            i73++;
                        }
                        jY = -9223372036854775807L;
                        break;
                    }
                    yVar5.I(16);
                    int i74 = yVar5.i();
                    int i75 = yVar5.i();
                    yVar5.I(4);
                    int i76 = yVar5.i();
                    int i77 = yVar5.i();
                    if (i74 == 0 && i75 == 65536) {
                        i10 = -65536;
                        if (i76 == -65536 && i77 == 0) {
                            i11 = 90;
                        }
                        if (j == -9223372036854775807L) {
                            j9 = jY;
                        } else {
                            j9 = j;
                        }
                        yVar = bVarS2.f23790c;
                        yVar.H(8);
                        if (b.q(yVar.i()) == 0) {
                            i12 = 8;
                        } else {
                            i12 = 16;
                        }
                        yVar.I(i12);
                        jY2 = yVar.y();
                        long jO = j9 != -9223372036854775807L ? y.O(j9, 1000000L, jY2) : -9223372036854775807L;
                        a aVarR3 = aVarR2.r(1835626086);
                        aVarR3.getClass();
                        a aVarR4 = aVarR3.r(1937007212);
                        aVarR4.getClass();
                        b bVarS5 = aVarR2.s(1835296868);
                        bVarS5.getClass();
                        S8.y yVar6 = bVarS5.f23790c;
                        yVar6.H(8);
                        iQ = b.q(yVar6.i());
                        if (iQ == 0) {
                            i13 = 8;
                        } else {
                            i13 = 16;
                        }
                        yVar6.I(i13);
                        long jY4 = yVar6.y();
                        if (iQ == 0) {
                            i14 = 4;
                        } else {
                            i14 = 8;
                        }
                        yVar6.I(i14);
                        int iC5 = yVar6.C();
                        pairCreate = Pair.create(Long.valueOf(jY4), "" + ((char) (((iC5 >> 10) & 31) + 96)) + ((char) (((iC5 >> 5) & 31) + 96)) + ((char) ((iC5 & 31) + 96)));
                        b bVarS6 = aVarR4.s(1937011556);
                        bVarS6.getClass();
                        yVar2 = bVarS6.f23790c;
                        str = (String) pairCreate.second;
                        yVar2.H(12);
                        i15 = yVar2.i();
                        qVarArr = new q[i15];
                        j10 = jO;
                        i16 = 0;
                        n9 = null;
                        i17 = 0;
                        i18 = 0;
                        while (i16 < i15) {
                            i23 = yVar2.f7099a;
                            i24 = yVar2.i();
                            ArrayList arrayList6 = arrayList4;
                            if (i24 > 0) {
                                z11 = true;
                            } else {
                                z11 = false;
                            }
                            i25 = i70;
                            str2 = "childAtomSize must be positive";
                            AbstractC0837z1.i("childAtomSize must be positive", z11);
                            i26 = yVar2.i();
                            int i78 = i67;
                            if (i26 != 1635148593 || i26 == 1635148595 || i26 == 1701733238 || i26 == 1831958048 || i26 == 1836070006 || i26 == 1752589105 || i26 == 1751479857 || i26 == 1932670515 || i26 == 1211250227 || i26 == 1987063864 || i26 == 1987063865 || i26 == 1635135537 || i26 == 1685479798 || i26 == 1685479729 || i26 == 1685481573 || i26 == 1685481521) {
                                i27 = i11;
                                arrayList5 = arrayList5;
                                aVar4 = aVar4;
                                pairCreate = pairCreate;
                                i15 = i15;
                                qVarArr = qVarArr;
                                i28 = i16;
                                yVar2.H(i23 + 16);
                                yVar2.I(16);
                                iC = yVar2.C();
                                iC2 = yVar2.C();
                                yVar2.I(50);
                                i29 = yVar2.f7099a;
                                if (i26 == 1701733238) {
                                    i30 = i23;
                                    i31 = i24;
                                    pairC = c(yVar2, i30, i31);
                                    if (pairC != null) {
                                        i26 = ((Integer) pairC.first).intValue();
                                        if (gVar == null) {
                                            gVarA = null;
                                        } else {
                                            gVarA = gVar.a(((q) pairC.second).f23905b);
                                        }
                                        qVarArr[i28] = (q) pairC.second;
                                    } else {
                                        gVarA = gVar;
                                    }
                                    yVar2.H(i29);
                                } else {
                                    i30 = i23;
                                    i31 = i24;
                                    gVarA = gVar;
                                }
                                if (i26 == 1831958048) {
                                    str3 = "video/mpeg";
                                } else if (i26 == 1211250227) {
                                    str3 = "video/3gpp";
                                } else {
                                    str3 = null;
                                }
                                i32 = i29;
                                i33 = i30;
                                str = str;
                                z12 = false;
                                str4 = str3;
                                fA = 1.0f;
                                i34 = i18;
                                i35 = -1;
                                str5 = null;
                                bArr = null;
                                listV = null;
                                i36 = -1;
                                byteBufferOrder = null;
                                y9 = null;
                                i37 = -1;
                                i38 = -1;
                                while (true) {
                                    if (i32 - i33 >= i31) {
                                        i39 = i36;
                                        break;
                                    }
                                    yVar2.H(i32);
                                    i45 = yVar2.f7099a;
                                    int i79 = i32;
                                    i46 = yVar2.i();
                                    i39 = i36;
                                    if (i46 != 0 && yVar2.f7099a - i33 == i31) {
                                        break;
                                    }
                                    if (i46 > 0) {
                                        z13 = true;
                                    } else {
                                        z13 = false;
                                    }
                                    AbstractC0837z1.i(str2, z13);
                                    i47 = yVar2.i();
                                    String str14 = str2;
                                    if (i47 == 1635148611) {
                                        if (str4 == null) {
                                            z15 = true;
                                        } else {
                                            z15 = false;
                                        }
                                        AbstractC0837z1.i(null, z15);
                                        yVar2.H(i45 + 8);
                                        aVarA = p079i3.a.a(yVar2);
                                        list3 = aVarA.f19182a;
                                        i49 = aVarA.f19183b;
                                        if (!z12) {
                                            fA = aVarA.f19186e;
                                        }
                                        str6 = aVarA.f19187f;
                                        str7 = "video/avc";
                                    } else {
                                        if (i47 == 1752589123) {
                                            if (str4 == null) {
                                                z14 = true;
                                            } else {
                                                z14 = false;
                                            }
                                            AbstractC0837z1.i(null, z14);
                                            yVar2.H(i45 + 8);
                                            eVarA = p079i3.e.a(yVar2);
                                            list3 = eVarA.f19206a;
                                            i49 = eVarA.f19207b;
                                            if (!z12) {
                                                fA = eVarA.f19208c;
                                            }
                                            str6 = eVarA.f19209d;
                                            str7 = "video/hevc";
                                        } else {
                                            if (i47 != 1685480259 || i47 == 1685485123) {
                                                i26 = i26;
                                                i35 = i35;
                                                fA = fA;
                                                i31 = i31;
                                                bArr3 = bArr;
                                                gVarA = gVarA;
                                                list2 = listV;
                                                i69 = i69;
                                                wVarB = w.b(yVar2);
                                                if (wVarB != null) {
                                                    str5 = wVarB.f2669b;
                                                    str4 = "video/dolby-vision";
                                                }
                                            } else if (i47 == 1987076931) {
                                                AbstractC0837z1.i(null, str4 == null);
                                                str4 = i26 == 1987063864 ? "video/x-vnd.on2.vp8" : "video/x-vnd.on2.vp9";
                                            } else if (i47 == 1635135811) {
                                                AbstractC0837z1.i(null, str4 == null);
                                                str4 = "video/av01";
                                            } else if (i47 == 1668050025) {
                                                if (byteBufferOrder == null) {
                                                    byteBufferOrder = ByteBuffer.allocate(25).order(ByteOrder.LITTLE_ENDIAN);
                                                }
                                                ByteBuffer byteBuffer = byteBufferOrder;
                                                byteBuffer.position(21);
                                                byteBuffer.putShort(yVar2.t());
                                                byteBuffer.putShort(yVar2.t());
                                                byteBufferOrder = byteBuffer;
                                            } else if (i47 == 1835295606) {
                                                if (byteBufferOrder == null) {
                                                    byteBufferOrder = ByteBuffer.allocate(25).order(ByteOrder.LITTLE_ENDIAN);
                                                }
                                                ByteBuffer byteBuffer2 = byteBufferOrder;
                                                short sT = yVar2.t();
                                                short sT2 = yVar2.t();
                                                i26 = i26;
                                                short sT3 = yVar2.t();
                                                short sT4 = yVar2.t();
                                                short sT5 = yVar2.t();
                                                List list6 = listV;
                                                short sT6 = yVar2.t();
                                                i35 = i35;
                                                short sT7 = yVar2.t();
                                                byte[] bArr5 = bArr;
                                                short sT8 = yVar2.t();
                                                long jY5 = yVar2.y();
                                                long jY6 = yVar2.y();
                                                byteBuffer2.position(1);
                                                byteBuffer2.putShort(sT5);
                                                byteBuffer2.putShort(sT6);
                                                byteBuffer2.putShort(sT);
                                                byteBuffer2.putShort(sT2);
                                                byteBuffer2.putShort(sT3);
                                                byteBuffer2.putShort(sT4);
                                                byteBuffer2.putShort(sT7);
                                                byteBuffer2.putShort(sT8);
                                                byteBuffer2.putShort((short) (jY5 / 10000));
                                                byteBuffer2.putShort((short) (jY6 / 10000));
                                                byteBufferOrder = byteBuffer2;
                                                listV = list6;
                                                bArr = bArr5;
                                            } else {
                                                i26 = i26;
                                                i35 = i35;
                                                fA = fA;
                                                i31 = i31;
                                                bArr3 = bArr;
                                                gVarA = gVarA;
                                                list2 = listV;
                                                if (i47 == 1681012275) {
                                                    AbstractC0837z1.i(null, str4 == null);
                                                    i69 = i69;
                                                    str4 = "video/3gpp";
                                                    listV = list2;
                                                    bArr = bArr3;
                                                } else {
                                                    if (i47 == 1702061171) {
                                                        AbstractC0837z1.i(null, str4 == null);
                                                        Y yA2 = a(i45, yVar2);
                                                        String str15 = (String) yA2.f3454c;
                                                        byte[] bArr6 = (byte[]) yA2.f3455d;
                                                        listV = bArr6 != null ? F.v(bArr6) : list2;
                                                        y9 = yA2;
                                                        str4 = str15;
                                                        i69 = i69;
                                                    } else if (i47 == 1885434736) {
                                                        yVar2.H(i45 + 8);
                                                        fA = yVar2.A() / yVar2.A();
                                                        i69 = i69;
                                                        listV = list2;
                                                        bArr = bArr3;
                                                        z12 = true;
                                                    } else if (i47 == 1937126244) {
                                                        int i80 = i45 + 8;
                                                        while (true) {
                                                            if (i80 - i45 >= i46) {
                                                                bArrCopyOfRange = null;
                                                                break;
                                                            }
                                                            yVar2.H(i80);
                                                            int i81 = yVar2.i();
                                                            if (yVar2.i() == 1886547818) {
                                                                bArrCopyOfRange = Arrays.copyOfRange((byte[]) yVar2.f7101c, i80, i81 + i80);
                                                                break;
                                                            }
                                                            i80 += i81;
                                                        }
                                                        bArr = bArrCopyOfRange;
                                                        i69 = i69;
                                                        listV = list2;
                                                    } else if (i47 == 1936995172) {
                                                        int iX3 = yVar2.x();
                                                        i69 = i69;
                                                        yVar2.I(i69);
                                                        if (iX3 == 0) {
                                                            int iX4 = yVar2.x();
                                                            if (iX4 == 0) {
                                                                i35 = 0;
                                                            } else if (iX4 == 1) {
                                                                i35 = 1;
                                                            } else if (iX4 == 2) {
                                                                i35 = 2;
                                                            } else if (iX4 == i69) {
                                                                i35 = i69;
                                                            }
                                                        }
                                                        listV = list2;
                                                    } else {
                                                        i69 = i69;
                                                        if (i47 == 1668246642) {
                                                            int i82 = yVar2.i();
                                                            if (i82 == 1852009592 || i82 == 1852009571) {
                                                                int iC6 = yVar2.C();
                                                                int iC7 = yVar2.C();
                                                                yVar2.I(2);
                                                                boolean z19 = i46 == 19 && (yVar2.x() & 128) != 0;
                                                                int iA2 = p079i3.b.a(iC6);
                                                                int i83 = z19 ? 1 : 2;
                                                                if (iC7 != 1) {
                                                                    if (iC7 != 16) {
                                                                        i48 = 7;
                                                                        if (iC7 != 18) {
                                                                            if (iC7 != 6 && iC7 != 7) {
                                                                                i48 = -1;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        i48 = 6;
                                                                    }
                                                                    i39 = iA2;
                                                                    i38 = i83;
                                                                    i37 = i48;
                                                                }
                                                                i48 = i69;
                                                                i39 = iA2;
                                                                i38 = i83;
                                                                i37 = i48;
                                                            } else {
                                                                a.P("AtomParsers", "Unsupported color type: " + b.d(i82));
                                                            }
                                                        }
                                                    }
                                                    bArr = bArr3;
                                                }
                                            }
                                            listV = list2;
                                            bArr = bArr3;
                                        }
                                        i32 = i79 + i46;
                                        i69 = i69;
                                        i36 = i39;
                                        str2 = str14;
                                        i26 = i26;
                                        i31 = i31;
                                        gVarA = gVarA;
                                        i35 = i35;
                                        fA = fA;
                                    }
                                    i26 = i26;
                                    i35 = i35;
                                    fA = fA;
                                    i31 = i31;
                                    i34 = i49;
                                    gVarA = gVarA;
                                    str4 = str7;
                                    i69 = i69;
                                    listV = list3;
                                    str5 = str6;
                                    i32 = i79 + i46;
                                    i69 = i69;
                                    i36 = i39;
                                    str2 = str14;
                                    i26 = i26;
                                    i31 = i31;
                                    gVarA = gVarA;
                                    i35 = i35;
                                    fA = fA;
                                }
                                i40 = i35;
                                f3 = fA;
                                i41 = i31;
                                bArr2 = bArr;
                                gVar2 = gVarA;
                                list = listV;
                                i69 = i69;
                                if (str4 == null) {
                                    i11 = i27;
                                } else {
                                    m9 = new M();
                                    m9.f17468a = Integer.toString(i25);
                                    m9.f17477k = str4;
                                    m9.f17475h = str5;
                                    m9.f17482p = iC;
                                    m9.f17483q = iC2;
                                    m9.f17486t = f3;
                                    i11 = i27;
                                    m9.f17485s = i11;
                                    m9.f17487u = bArr2;
                                    m9.f17488v = i40;
                                    m9.f17479m = list;
                                    m9.f17480n = gVar2;
                                    i42 = i39;
                                    if (i42 == -1) {
                                        i44 = i38;
                                        i43 = i37;
                                        if (i44 == -1 || i43 != -1 || byteBufferOrder != null) {
                                        }
                                        if (y9 != null) {
                                            Y y11 = y9;
                                            m9.f17473f = p012b1.a.O(y11.f3452a);
                                            m9.f17474g = p012b1.a.O(y11.f3453b);
                                        }
                                        n9 = new N(m9);
                                    } else {
                                        i43 = i37;
                                        i44 = i38;
                                    }
                                    if (byteBufferOrder != null) {
                                        bArrArray = byteBufferOrder.array();
                                    } else {
                                        bArrArray = null;
                                    }
                                    m9.f17489w = new p079i3.b(i42, i44, i43, bArrArray);
                                    if (y9 != null) {
                                        Y y12 = y9;
                                        m9.f17473f = p012b1.a.O(y12.f3452a);
                                        m9.f17474g = p012b1.a.O(y12.f3453b);
                                    }
                                    n9 = new N(m9);
                                }
                                i18 = i34;
                            } else if (i26 == 1836069985 || i26 == 1701733217 || i26 == 1633889587 || i26 == 1700998451 || i26 == 1633889588 || i26 == 1835823201 || i26 == 1685353315 || i26 == 1685353317 || i26 == 1685353320 || i26 == 1685353324 || i26 == 1685353336 || i26 == 1935764850 || i26 == 1935767394 || i26 == 1819304813 || i26 == 1936684916 || i26 == 1953984371 || i26 == 778924082 || i26 == 778924083 || i26 == 1835557169 || i26 == 1835560241 || i26 == 1634492771 || i26 == 1634492791 || i26 == 1970037111 || i26 == 1332770163 || i26 == 1716281667) {
                                i15 = i15;
                                qVarArr = qVarArr;
                                int[] iArr2 = AbstractC0965a.f18718f;
                                int[] iArr3 = AbstractC0965a.f18716d;
                                yVar2.H(i23 + 16);
                                if (z10) {
                                    iC3 = yVar2.C();
                                    yVar2.I(6);
                                } else {
                                    yVar2.I(8);
                                    iC3 = 0;
                                }
                                if (iC3 == 0 || iC3 == 1) {
                                    iC4 = yVar2.C();
                                    yVar2.I(6);
                                    byte[] bArr7 = (byte[]) yVar2.f7101c;
                                    iArr = iArr2;
                                    int i84 = yVar2.f7099a;
                                    int i85 = i84 + 1;
                                    yVar2.f7099a = i85;
                                    int i86 = (bArr7[i84] & 255) << 8;
                                    yVar2.f7099a = i84 + 2;
                                    int i87 = i86 | (bArr7[i85] & 255);
                                    yVar2.f7099a = i84 + 4;
                                    yVar2.H(i84);
                                    i50 = yVar2.i();
                                    if (iC3 == 1) {
                                        yVar2.I(16);
                                    }
                                    iRound = i87;
                                } else {
                                    if (iC3 == 2) {
                                        yVar2.I(16);
                                        iRound = (int) Math.round(Double.longBitsToDouble(yVar2.q()));
                                        iC4 = yVar2.A();
                                        yVar2.I(20);
                                        iArr = iArr2;
                                        i50 = 0;
                                    } else {
                                        i52 = i11;
                                        arrayList5 = arrayList5;
                                        aVar4 = aVar4;
                                        pairCreate = pairCreate;
                                        i28 = i16;
                                        i33 = i23;
                                        i51 = i24;
                                    }
                                    str = str;
                                    i11 = i52;
                                    i41 = i51;
                                }
                                int i88 = yVar2.f7099a;
                                int i89 = iRound;
                                if (i26 == 1701733217) {
                                    Pair pairC2 = c(yVar2, i23, i24);
                                    if (pairC2 != null) {
                                        int iIntValue = ((Integer) pairC2.first).intValue();
                                        g gVarA2 = gVar == null ? null : gVar.a(((q) pairC2.second).f23905b);
                                        qVarArr[i16] = (q) pairC2.second;
                                        gVar3 = gVarA2;
                                        i26 = iIntValue;
                                    } else {
                                        gVar3 = gVar;
                                    }
                                    yVar2.H(i88);
                                } else {
                                    gVar3 = gVar;
                                }
                                int i90 = iC4;
                                String str16 = "audio/ac3";
                                i28 = i16;
                                if (i26 == 1633889587) {
                                    str9 = "audio/ac3";
                                } else if (i26 == 1700998451) {
                                    str9 = "audio/eac3";
                                } else if (i26 == 1633889588) {
                                    str9 = "audio/ac4";
                                } else {
                                    if (i26 == 1685353315) {
                                        str8 = "audio/vnd.dts";
                                    } else if (i26 == 1685353320 || i26 == 1685353324) {
                                        str8 = "audio/vnd.dts.hd";
                                    } else if (i26 == 1685353317) {
                                        str8 = "audio/vnd.dts.hd;profile=lbr";
                                    } else if (i26 == 1685353336) {
                                        str8 = "audio/vnd.dts.uhd;profile=p2";
                                    } else if (i26 == 1935764850) {
                                        str8 = "audio/3gpp";
                                    } else if (i26 == 1935767394) {
                                        str8 = "audio/amr-wb";
                                    } else {
                                        str9 = "audio/raw";
                                        if (i26 == 1819304813 || i26 == 1936684916) {
                                            i53 = 2;
                                        } else if (i26 == 1953984371) {
                                            i53 = 268435456;
                                        } else if (i26 == 778924082 || i26 == 778924083) {
                                            str8 = "audio/mpeg";
                                        } else if (i26 == 1835557169) {
                                            str8 = "audio/mha1";
                                        } else if (i26 == 1835560241) {
                                            str8 = "audio/mhm1";
                                        } else if (i26 == 1634492771) {
                                            str8 = "audio/alac";
                                        } else if (i26 == 1634492791) {
                                            str8 = "audio/g711-alaw";
                                        } else if (i26 == 1970037111) {
                                            str8 = "audio/g711-mlaw";
                                        } else if (i26 == 1332770163) {
                                            str8 = "audio/opus";
                                        } else if (i26 == 1716281667) {
                                            str8 = "audio/flac";
                                        } else if (i26 == 1835823201) {
                                            str8 = "audio/true-hd";
                                        } else {
                                            i53 = -1;
                                            str9 = null;
                                        }
                                        i52 = i11;
                                        arrayList5 = arrayList5;
                                        aVar4 = aVar4;
                                        pairCreate = pairCreate;
                                        i33 = i23;
                                        str10 = str9;
                                        i54 = i90;
                                        i55 = i89;
                                        i56 = i88;
                                        listV2 = null;
                                        str11 = null;
                                        y10 = null;
                                        while (i56 - i33 < i24) {
                                            yVar2.H(i56);
                                            i58 = yVar2.i();
                                            int i91 = i24;
                                            if (i58 > 0) {
                                                z16 = true;
                                            } else {
                                                z16 = false;
                                            }
                                            AbstractC0837z1.i("childAtomSize must be positive", z16);
                                            i59 = yVar2.i();
                                            list5 = listV2;
                                            if (i59 == 1835557187) {
                                                int i92 = i58 - 13;
                                                byte[] bArr8 = new byte[i92];
                                                i60 = i53;
                                                yVar2.H(i56 + 13);
                                                yVar2.h(bArr8, 0, i92);
                                                listV2 = F.v(bArr8);
                                                str11 = str11;
                                                str16 = str16;
                                            } else {
                                                i60 = i53;
                                                if (i59 != 1702061171) {
                                                    if (z10 || i59 != 2002876005) {
                                                        if (i59 == 1684103987) {
                                                            yVar2.H(i56 + 8);
                                                            String string = Integer.toString(i25);
                                                            int i93 = iArr3[(yVar2.x() & 192) >> 6];
                                                            iX2 = yVar2.x();
                                                            i66 = iArr[(iX2 & 56) >> 3];
                                                            if ((iX2 & 4) != 0) {
                                                                i66++;
                                                            }
                                                            str11 = str11;
                                                            M m11 = new M();
                                                            m11.f17468a = string;
                                                            m11.f17477k = str16;
                                                            m11.f17490x = i66;
                                                            m11.f17491y = i93;
                                                            m11.f17480n = gVar3;
                                                            m11.f17470c = str;
                                                            n9 = new N(m11);
                                                            str16 = str16;
                                                        } else {
                                                            str11 = str11;
                                                            if (i59 == 1684366131) {
                                                                yVar2.H(i56 + 8);
                                                                String string2 = Integer.toString(i25);
                                                                yVar2.I(2);
                                                                int i94 = iArr3[(yVar2.x() & 192) >> 6];
                                                                iX = yVar2.x();
                                                                i65 = iArr[(iX & 14) >> 1];
                                                                if ((iX & 1) != 0) {
                                                                    i65++;
                                                                }
                                                                if (((yVar2.x() & 30) >> 1) > 0 && (yVar2.x() & 2) != 0) {
                                                                    i65 += 2;
                                                                }
                                                                if (yVar2.e() > 0 || (yVar2.x() & 1) == 0) {
                                                                    str13 = "audio/eac3";
                                                                } else {
                                                                    str13 = "audio/eac3-joc";
                                                                }
                                                                str16 = str16;
                                                                M m12 = new M();
                                                                m12.f17468a = string2;
                                                                m12.f17477k = str13;
                                                                m12.f17490x = i65;
                                                                m12.f17491y = i94;
                                                                m12.f17480n = gVar3;
                                                                m12.f17470c = str;
                                                                n10 = new N(m12);
                                                            } else {
                                                                str16 = str16;
                                                                if (i59 == 1684103988) {
                                                                    yVar2.H(i56 + 8);
                                                                    String string3 = Integer.toString(i25);
                                                                    yVar2.I(1);
                                                                    if (((yVar2.x() & 32) >> 5) == 1) {
                                                                        i64 = 48000;
                                                                    } else {
                                                                        i64 = 44100;
                                                                    }
                                                                    M m13 = new M();
                                                                    m13.f17468a = string3;
                                                                    m13.f17477k = "audio/ac4";
                                                                    m13.f17490x = 2;
                                                                    m13.f17491y = i64;
                                                                    m13.f17480n = gVar3;
                                                                    m13.f17470c = str;
                                                                    n10 = new N(m13);
                                                                } else if (i59 == 1684892784) {
                                                                    if (i50 > 0) {
                                                                        throw j0.a("Invalid sample rate for Dolby TrueHD MLP stream: " + i50, null);
                                                                    }
                                                                    i55 = i50;
                                                                    listV2 = list5;
                                                                    i54 = 2;
                                                                } else if (i59 == 1684305011) {
                                                                    M m14 = new M();
                                                                    m14.f17468a = Integer.toString(i25);
                                                                    m14.f17477k = str10;
                                                                    m14.f17490x = i54;
                                                                    m14.f17491y = i55;
                                                                    m14.f17480n = gVar3;
                                                                    m14.f17470c = str;
                                                                    n9 = new N(m14);
                                                                } else if (i59 == 1682927731) {
                                                                    int i95 = i58 - 8;
                                                                    byte[] bArr9 = f23805a;
                                                                    byte[] bArrCopyOf = Arrays.copyOf(bArr9, bArr9.length + i95);
                                                                    yVar2.H(i56 + 8);
                                                                    yVar2.h(bArrCopyOf, bArr9.length, i95);
                                                                    listV2 = AbstractC0965a.c(bArrCopyOf);
                                                                } else if (i59 == 1684425825) {
                                                                    byte[] bArr10 = new byte[i58 - 8];
                                                                    bArr10[0] = 102;
                                                                    bArr10[1] = 76;
                                                                    bArr10[2] = 97;
                                                                    bArr10[i69] = 67;
                                                                    yVar2.H(i56 + 12);
                                                                    yVar2.h(bArr10, 4, i58 - 12);
                                                                    listV2 = F.v(bArr10);
                                                                } else if (i59 == 1634492771) {
                                                                    int i96 = i58 - 12;
                                                                    byte[] bArr11 = new byte[i96];
                                                                    yVar2.H(i56 + 12);
                                                                    yVar2.h(bArr11, 0, i96);
                                                                    S8.y yVar7 = new S8.y(bArr11);
                                                                    yVar7.H(9);
                                                                    int iX5 = yVar7.x();
                                                                    yVar7.H(20);
                                                                    Pair pairCreate3 = Pair.create(Integer.valueOf(yVar7.A()), Integer.valueOf(iX5));
                                                                    int iIntValue2 = ((Integer) pairCreate3.first).intValue();
                                                                    int iIntValue3 = ((Integer) pairCreate3.second).intValue();
                                                                    listV2 = F.v(bArr11);
                                                                    i55 = iIntValue2;
                                                                    i54 = iIntValue3;
                                                                } else {
                                                                    listV2 = list5;
                                                                }
                                                            }
                                                            n9 = n10;
                                                        }
                                                        listV2 = list5;
                                                    } else {
                                                        i61 = 1702061171;
                                                    }
                                                    i56 += i58;
                                                    i53 = i60;
                                                    str11 = str11;
                                                    i24 = i91;
                                                    str16 = str16;
                                                } else {
                                                    i61 = 1702061171;
                                                }
                                                if (i59 == i61) {
                                                    i62 = yVar2.f7099a;
                                                    if (i62 >= i56) {
                                                        z17 = true;
                                                    } else {
                                                        z17 = false;
                                                    }
                                                    AbstractC0837z1.i(null, z17);
                                                    while (true) {
                                                        if (i62 - i56 < i58) {
                                                            i62 = -1;
                                                            break;
                                                        }
                                                        yVar2.H(i62);
                                                        i63 = yVar2.i();
                                                        if (i63 > 0) {
                                                            z18 = true;
                                                        } else {
                                                            z18 = false;
                                                        }
                                                        AbstractC0837z1.i("childAtomSize must be positive", z18);
                                                        if (yVar2.i() == 1702061171) {
                                                            break;
                                                        }
                                                        i62 += i63;
                                                    }
                                                } else {
                                                    i62 = i56;
                                                }
                                                if (i62 != -1) {
                                                    yA = a(i62, yVar2);
                                                    str10 = (String) yA.f3454c;
                                                    bArr4 = (byte[]) yA.f3455d;
                                                    if (bArr4 != null) {
                                                        if ("audio/mp4a-latm".equals(str10)) {
                                                            S8.y yVarI = AbstractC0965a.i(new V2.f(bArr4.length, bArr4), false);
                                                            i55 = yVarI.f7099a;
                                                            int i97 = yVarI.f7100b;
                                                            str11 = (String) yVarI.f7101c;
                                                            i54 = i97;
                                                        }
                                                        y10 = yA;
                                                        listV2 = F.v(bArr4);
                                                    } else {
                                                        y10 = yA;
                                                    }
                                                    i56 += i58;
                                                    i53 = i60;
                                                    str11 = str11;
                                                    i24 = i91;
                                                    str16 = str16;
                                                }
                                                listV2 = list5;
                                                i56 += i58;
                                                i53 = i60;
                                                str11 = str11;
                                                i24 = i91;
                                                str16 = str16;
                                            }
                                            i56 += i58;
                                            i53 = i60;
                                            str11 = str11;
                                            i24 = i91;
                                            str16 = str16;
                                        }
                                        list4 = listV2;
                                        i57 = i53;
                                        str12 = str11;
                                        i51 = i24;
                                        if (n9 == null && str10 != null) {
                                            m10 = new M();
                                            m10.f17468a = Integer.toString(i25);
                                            m10.f17477k = str10;
                                            m10.f17475h = str12;
                                            m10.f17490x = i54;
                                            m10.f17491y = i55;
                                            m10.f17492z = i57;
                                            m10.f17479m = list4;
                                            m10.f17480n = gVar3;
                                            m10.f17470c = str;
                                            if (y10 != null) {
                                                Y y13 = y10;
                                                m10.f17473f = p012b1.a.O(y13.f3452a);
                                                m10.f17474g = p012b1.a.O(y13.f3453b);
                                            }
                                            n9 = new N(m10);
                                        }
                                        str = str;
                                        i11 = i52;
                                        i41 = i51;
                                    }
                                    str9 = str8;
                                }
                                i53 = -1;
                                i52 = i11;
                                arrayList5 = arrayList5;
                                aVar4 = aVar4;
                                pairCreate = pairCreate;
                                i33 = i23;
                                str10 = str9;
                                i54 = i90;
                                i55 = i89;
                                i56 = i88;
                                listV2 = null;
                                str11 = null;
                                y10 = null;
                                while (i56 - i33 < i24) {
                                    yVar2.H(i56);
                                    i58 = yVar2.i();
                                    int i98 = i24;
                                    if (i58 > 0) {
                                        z16 = true;
                                    } else {
                                        z16 = false;
                                    }
                                    AbstractC0837z1.i("childAtomSize must be positive", z16);
                                    i59 = yVar2.i();
                                    list5 = listV2;
                                    if (i59 == 1835557187) {
                                        int i99 = i58 - 13;
                                        byte[] bArr12 = new byte[i99];
                                        i60 = i53;
                                        yVar2.H(i56 + 13);
                                        yVar2.h(bArr12, 0, i99);
                                        listV2 = F.v(bArr12);
                                        str11 = str11;
                                        str16 = str16;
                                    } else {
                                        i60 = i53;
                                        if (i59 != 1702061171) {
                                            if (z10) {
                                            }
                                            if (i59 == 1684103987) {
                                                yVar2.H(i56 + 8);
                                                String string4 = Integer.toString(i25);
                                                int i910 = iArr3[(yVar2.x() & 192) >> 6];
                                                iX2 = yVar2.x();
                                                i66 = iArr[(iX2 & 56) >> 3];
                                                if ((iX2 & 4) != 0) {
                                                    i66++;
                                                }
                                                str11 = str11;
                                                M m15 = new M();
                                                m15.f17468a = string4;
                                                m15.f17477k = str16;
                                                m15.f17490x = i66;
                                                m15.f17491y = i910;
                                                m15.f17480n = gVar3;
                                                m15.f17470c = str;
                                                n9 = new N(m15);
                                                str16 = str16;
                                            } else {
                                                str11 = str11;
                                                if (i59 == 1684366131) {
                                                    yVar2.H(i56 + 8);
                                                    String string5 = Integer.toString(i25);
                                                    yVar2.I(2);
                                                    int i911 = iArr3[(yVar2.x() & 192) >> 6];
                                                    iX = yVar2.x();
                                                    i65 = iArr[(iX & 14) >> 1];
                                                    if ((iX & 1) != 0) {
                                                        i65++;
                                                    }
                                                    if (((yVar2.x() & 30) >> 1) > 0) {
                                                        i65 += 2;
                                                    }
                                                    if (yVar2.e() > 0) {
                                                        str13 = "audio/eac3";
                                                    } else {
                                                        str13 = "audio/eac3";
                                                    }
                                                    str16 = str16;
                                                    M m16 = new M();
                                                    m16.f17468a = string5;
                                                    m16.f17477k = str13;
                                                    m16.f17490x = i65;
                                                    m16.f17491y = i911;
                                                    m16.f17480n = gVar3;
                                                    m16.f17470c = str;
                                                    n10 = new N(m16);
                                                } else {
                                                    str16 = str16;
                                                    if (i59 == 1684103988) {
                                                        yVar2.H(i56 + 8);
                                                        String string6 = Integer.toString(i25);
                                                        yVar2.I(1);
                                                        if (((yVar2.x() & 32) >> 5) == 1) {
                                                            i64 = 48000;
                                                        } else {
                                                            i64 = 44100;
                                                        }
                                                        M m17 = new M();
                                                        m17.f17468a = string6;
                                                        m17.f17477k = "audio/ac4";
                                                        m17.f17490x = 2;
                                                        m17.f17491y = i64;
                                                        m17.f17480n = gVar3;
                                                        m17.f17470c = str;
                                                        n10 = new N(m17);
                                                    } else if (i59 == 1684892784) {
                                                        if (i50 > 0) {
                                                            throw j0.a("Invalid sample rate for Dolby TrueHD MLP stream: " + i50, null);
                                                        }
                                                        i55 = i50;
                                                        listV2 = list5;
                                                        i54 = 2;
                                                    } else if (i59 == 1684305011) {
                                                        M m18 = new M();
                                                        m18.f17468a = Integer.toString(i25);
                                                        m18.f17477k = str10;
                                                        m18.f17490x = i54;
                                                        m18.f17491y = i55;
                                                        m18.f17480n = gVar3;
                                                        m18.f17470c = str;
                                                        n9 = new N(m18);
                                                    } else if (i59 == 1682927731) {
                                                        int i912 = i58 - 8;
                                                        byte[] bArr13 = f23805a;
                                                        byte[] bArrCopyOf2 = Arrays.copyOf(bArr13, bArr13.length + i912);
                                                        yVar2.H(i56 + 8);
                                                        yVar2.h(bArrCopyOf2, bArr13.length, i912);
                                                        listV2 = AbstractC0965a.c(bArrCopyOf2);
                                                    } else if (i59 == 1684425825) {
                                                        byte[] bArr14 = new byte[i58 - 8];
                                                        bArr14[0] = 102;
                                                        bArr14[1] = 76;
                                                        bArr14[2] = 97;
                                                        bArr14[i69] = 67;
                                                        yVar2.H(i56 + 12);
                                                        yVar2.h(bArr14, 4, i58 - 12);
                                                        listV2 = F.v(bArr14);
                                                    } else if (i59 == 1634492771) {
                                                        int i913 = i58 - 12;
                                                        byte[] bArr15 = new byte[i913];
                                                        yVar2.H(i56 + 12);
                                                        yVar2.h(bArr15, 0, i913);
                                                        S8.y yVar8 = new S8.y(bArr15);
                                                        yVar8.H(9);
                                                        int iX6 = yVar8.x();
                                                        yVar8.H(20);
                                                        Pair pairCreate4 = Pair.create(Integer.valueOf(yVar8.A()), Integer.valueOf(iX6));
                                                        int iIntValue4 = ((Integer) pairCreate4.first).intValue();
                                                        int iIntValue5 = ((Integer) pairCreate4.second).intValue();
                                                        listV2 = F.v(bArr15);
                                                        i55 = iIntValue4;
                                                        i54 = iIntValue5;
                                                    } else {
                                                        listV2 = list5;
                                                    }
                                                    i56 += i58;
                                                    i53 = i60;
                                                    str11 = str11;
                                                    i24 = i98;
                                                    str16 = str16;
                                                }
                                                n9 = n10;
                                            }
                                            listV2 = list5;
                                            i56 += i58;
                                            i53 = i60;
                                            str11 = str11;
                                            i24 = i98;
                                            str16 = str16;
                                        } else {
                                            i61 = 1702061171;
                                        }
                                        if (i59 == i61) {
                                            i62 = yVar2.f7099a;
                                            if (i62 >= i56) {
                                                z17 = true;
                                            } else {
                                                z17 = false;
                                            }
                                            AbstractC0837z1.i(null, z17);
                                            while (true) {
                                                if (i62 - i56 < i58) {
                                                    i62 = -1;
                                                    break;
                                                }
                                                yVar2.H(i62);
                                                i63 = yVar2.i();
                                                if (i63 > 0) {
                                                    z18 = true;
                                                } else {
                                                    z18 = false;
                                                }
                                                AbstractC0837z1.i("childAtomSize must be positive", z18);
                                                if (yVar2.i() == 1702061171) {
                                                    break;
                                                    break;
                                                }
                                                i62 += i63;
                                            }
                                        } else {
                                            i62 = i56;
                                        }
                                        if (i62 != -1) {
                                            yA = a(i62, yVar2);
                                            str10 = (String) yA.f3454c;
                                            bArr4 = (byte[]) yA.f3455d;
                                            if (bArr4 != null) {
                                                if ("audio/mp4a-latm".equals(str10)) {
                                                    S8.y yVarI2 = AbstractC0965a.i(new V2.f(bArr4.length, bArr4), false);
                                                    i55 = yVarI2.f7099a;
                                                    int i914 = yVarI2.f7100b;
                                                    str11 = (String) yVarI2.f7101c;
                                                    i54 = i914;
                                                }
                                                y10 = yA;
                                                listV2 = F.v(bArr4);
                                            } else {
                                                y10 = yA;
                                            }
                                            i56 += i58;
                                            i53 = i60;
                                            str11 = str11;
                                            i24 = i98;
                                            str16 = str16;
                                        }
                                        listV2 = list5;
                                        i56 += i58;
                                        i53 = i60;
                                        str11 = str11;
                                        i24 = i98;
                                        str16 = str16;
                                    }
                                    i56 += i58;
                                    i53 = i60;
                                    str11 = str11;
                                    i24 = i98;
                                    str16 = str16;
                                }
                                list4 = listV2;
                                i57 = i53;
                                str12 = str11;
                                i51 = i24;
                                if (n9 == null) {
                                    m10 = new M();
                                    m10.f17468a = Integer.toString(i25);
                                    m10.f17477k = str10;
                                    m10.f17475h = str12;
                                    m10.f17490x = i54;
                                    m10.f17491y = i55;
                                    m10.f17492z = i57;
                                    m10.f17479m = list4;
                                    m10.f17480n = gVar3;
                                    m10.f17470c = str;
                                    if (y10 != null) {
                                        Y y14 = y10;
                                        m10.f17473f = p012b1.a.O(y14.f3452a);
                                        m10.f17474g = p012b1.a.O(y14.f3453b);
                                    }
                                    n9 = new N(m10);
                                }
                                str = str;
                                i11 = i52;
                                i41 = i51;
                            } else {
                                if (i26 == 1414810956 || i26 == 1954034535 || i26 == 2004251764 || i26 == 1937010800 || i26 == 1664495672) {
                                    yVar2.H(i23 + 16);
                                    String str17 = "application/ttml+xml";
                                    if (i26 == 1414810956) {
                                        j11 = Long.MAX_VALUE;
                                        sV = null;
                                    } else if (i26 == 1954034535) {
                                        int i100 = i24 - 16;
                                        byte[] bArr16 = new byte[i100];
                                        yVar2.h(bArr16, 0, i100);
                                        sV = F.v(bArr16);
                                        str17 = "application/x-quicktime-tx3g";
                                        j11 = Long.MAX_VALUE;
                                    } else if (i26 == 2004251764) {
                                        str17 = "application/x-mp4-vtt";
                                        j11 = Long.MAX_VALUE;
                                        sV = null;
                                    } else if (i26 == 1937010800) {
                                        sV = null;
                                        j11 = 0;
                                    } else {
                                        if (i26 != 1664495672) {
                                            throw new IllegalStateException();
                                        }
                                        str17 = "application/x-mp4-cea-608";
                                        j11 = Long.MAX_VALUE;
                                        sV = null;
                                        i17 = 1;
                                    }
                                    M m19 = new M();
                                    m19.f17468a = Integer.toString(i25);
                                    m19.f17477k = str17;
                                    m19.f17470c = str;
                                    m19.f17481o = j11;
                                    m19.f17479m = sV;
                                    n9 = new N(m19);
                                    arrayList5 = arrayList5;
                                } else {
                                    if (i26 == 1835365492) {
                                        yVar2.H(i23 + 16);
                                        if (i26 == 1835365492) {
                                            yVar2.r();
                                            String strR = yVar2.r();
                                            if (strR != null) {
                                                M m20 = new M();
                                                m20.f17468a = Integer.toString(i25);
                                                m20.f17477k = strR;
                                                n9 = new N(m20);
                                            }
                                        }
                                    } else {
                                        if (i26 == 1667329389) {
                                            M m21 = new M();
                                            m21.f17468a = Integer.toString(i25);
                                            m21.f17477k = "application/x-camera-motion";
                                            n9 = new N(m21);
                                        }
                                        i15 = i15;
                                    }
                                    i15 = i15;
                                }
                                i28 = i16;
                                i33 = i23;
                                i41 = i24;
                            }
                            yVar2.H(i33 + i41);
                            i16 = i28 + 1;
                            gVar = gVar;
                            i69 = i69;
                            arrayList4 = arrayList6;
                            i70 = i25;
                            i67 = i78;
                            i15 = i15;
                            str = str;
                            arrayList5 = arrayList5;
                            pairCreate = pairCreate;
                            aVar4 = aVar4;
                            i9 = i9;
                            qVarArr = qVarArr;
                        }
                        arrayList = arrayList4;
                        arrayList2 = arrayList5;
                        i19 = i70;
                        i20 = i67;
                        aVar2 = aVar4;
                        pair = pairCreate;
                        i21 = i9;
                        qVarArr2 = qVarArr;
                        if (z9) {
                            aVar4 = aVar2;
                        } else {
                            aVar4 = aVar2;
                            aVarR = aVar4.r(1701082227);
                            if (aVarR == null) {
                                bVarS = aVarR.s(1701606260);
                                if (bVarS == null) {
                                    pairCreate2 = null;
                                } else {
                                    yVar3 = bVarS.f23790c;
                                    yVar3.H(8);
                                    iQ2 = b.q(yVar3.i());
                                    iA = yVar3.A();
                                    jArr3 = new long[iA];
                                    jArr4 = new long[iA];
                                    for (i22 = 0; i22 < iA; i22++) {
                                        if (iQ2 == 1) {
                                            jY3 = yVar3.B();
                                        } else {
                                            jY3 = yVar3.y();
                                        }
                                        jArr3[i22] = jY3;
                                        if (iQ2 == 1) {
                                            jI = yVar3.q();
                                        } else {
                                            jI = yVar3.i();
                                        }
                                        jArr4[i22] = jI;
                                        if (yVar3.t() == 1) {
                                            throw new IllegalArgumentException("Unsupported media rate.");
                                        }
                                        yVar3.I(2);
                                    }
                                    pairCreate2 = Pair.create(jArr3, jArr4);
                                }
                                if (pairCreate2 != null) {
                                    jArr = (long[]) pairCreate2.first;
                                    jArr2 = (long[]) pairCreate2.second;
                                }
                            }
                            if (n9 == null) {
                                pVar = null;
                            } else {
                                pVar = new p(i19, i21, ((Long) pair.first).longValue(), jY2, j10, n9, i17, qVarArr2, i18, jArr, jArr2);
                            }
                        }
                        jArr = null;
                        jArr2 = null;
                        if (n9 == null) {
                            pVar = null;
                        } else {
                            pVar = new p(i19, i21, ((Long) pair.first).longValue(), jY2, j10, n9, i17, qVarArr2, i18, jArr, jArr2);
                        }
                    } else {
                        i10 = -65536;
                    }
                    if (i74 == 0 && i75 == i10) {
                        if (i76 == 65536 && i77 == 0) {
                            i11 = 270;
                        } else {
                            i10 = -65536;
                            if (i74 != i10) {
                                i11 = 0;
                            } else {
                                i11 = 0;
                            }
                        }
                    } else if (i74 != i10 && i75 == 0 && i76 == 0 && i77 == i10) {
                        i11 = 180;
                    } else {
                        i11 = 0;
                    }
                    if (j == -9223372036854775807L) {
                        j9 = jY;
                    } else {
                        j9 = j;
                    }
                    yVar = bVarS2.f23790c;
                    yVar.H(8);
                    if (b.q(yVar.i()) == 0) {
                        i12 = 8;
                    } else {
                        i12 = 16;
                    }
                    yVar.I(i12);
                    jY2 = yVar.y();
                    if (j9 != -9223372036854775807L) {
                    }
                    a aVarR5 = aVarR2.r(1835626086);
                    aVarR5.getClass();
                    a aVarR6 = aVarR5.r(1937007212);
                    aVarR6.getClass();
                    b bVarS7 = aVarR2.s(1835296868);
                    bVarS7.getClass();
                    S8.y yVar9 = bVarS7.f23790c;
                    yVar9.H(8);
                    iQ = b.q(yVar9.i());
                    if (iQ == 0) {
                        i13 = 8;
                    } else {
                        i13 = 16;
                    }
                    yVar9.I(i13);
                    long jY7 = yVar9.y();
                    if (iQ == 0) {
                        i14 = 4;
                    } else {
                        i14 = 8;
                    }
                    yVar9.I(i14);
                    int iC8 = yVar9.C();
                    pairCreate = Pair.create(Long.valueOf(jY7), "" + ((char) (((iC8 >> 10) & 31) + 96)) + ((char) (((iC8 >> 5) & 31) + 96)) + ((char) ((iC8 & 31) + 96)));
                    b bVarS8 = aVarR6.s(1937011556);
                    bVarS8.getClass();
                    yVar2 = bVarS8.f23790c;
                    str = (String) pairCreate.second;
                    yVar2.H(12);
                    i15 = yVar2.i();
                    qVarArr = new q[i15];
                    j10 = jO;
                    i16 = 0;
                    n9 = null;
                    i17 = 0;
                    i18 = 0;
                    while (i16 < i15) {
                        i23 = yVar2.f7099a;
                        i24 = yVar2.i();
                        ArrayList arrayList7 = arrayList4;
                        if (i24 > 0) {
                            z11 = true;
                        } else {
                            z11 = false;
                        }
                        i25 = i70;
                        str2 = "childAtomSize must be positive";
                        AbstractC0837z1.i("childAtomSize must be positive", z11);
                        i26 = yVar2.i();
                        int i710 = i67;
                        if (i26 != 1635148593) {
                            i27 = i11;
                            arrayList5 = arrayList5;
                            aVar4 = aVar4;
                            pairCreate = pairCreate;
                            i15 = i15;
                            qVarArr = qVarArr;
                            i28 = i16;
                            yVar2.H(i23 + 16);
                            yVar2.I(16);
                            iC = yVar2.C();
                            iC2 = yVar2.C();
                            yVar2.I(50);
                            i29 = yVar2.f7099a;
                            if (i26 == 1701733238) {
                                i30 = i23;
                                i31 = i24;
                                pairC = c(yVar2, i30, i31);
                                if (pairC != null) {
                                    i26 = ((Integer) pairC.first).intValue();
                                    if (gVar == null) {
                                        gVarA = null;
                                    } else {
                                        gVarA = gVar.a(((q) pairC.second).f23905b);
                                    }
                                    qVarArr[i28] = (q) pairC.second;
                                } else {
                                    gVarA = gVar;
                                }
                                yVar2.H(i29);
                            } else {
                                i30 = i23;
                                i31 = i24;
                                gVarA = gVar;
                            }
                            if (i26 == 1831958048) {
                                str3 = "video/mpeg";
                            } else if (i26 == 1211250227) {
                                str3 = "video/3gpp";
                            } else {
                                str3 = null;
                            }
                            i32 = i29;
                            i33 = i30;
                            str = str;
                            z12 = false;
                            str4 = str3;
                            fA = 1.0f;
                            i34 = i18;
                            i35 = -1;
                            str5 = null;
                            bArr = null;
                            listV = null;
                            i36 = -1;
                            byteBufferOrder = null;
                            y9 = null;
                            i37 = -1;
                            i38 = -1;
                            while (true) {
                                if (i32 - i33 >= i31) {
                                    i39 = i36;
                                    break;
                                }
                                yVar2.H(i32);
                                i45 = yVar2.f7099a;
                                int i711 = i32;
                                i46 = yVar2.i();
                                i39 = i36;
                                if (i46 != 0) {
                                }
                                if (i46 > 0) {
                                    z13 = true;
                                } else {
                                    z13 = false;
                                }
                                AbstractC0837z1.i(str2, z13);
                                i47 = yVar2.i();
                                String str18 = str2;
                                if (i47 == 1635148611) {
                                    if (str4 == null) {
                                        z15 = true;
                                    } else {
                                        z15 = false;
                                    }
                                    AbstractC0837z1.i(null, z15);
                                    yVar2.H(i45 + 8);
                                    aVarA = p079i3.a.a(yVar2);
                                    list3 = aVarA.f19182a;
                                    i49 = aVarA.f19183b;
                                    if (!z12) {
                                        fA = aVarA.f19186e;
                                    }
                                    str6 = aVarA.f19187f;
                                    str7 = "video/avc";
                                } else {
                                    if (i47 == 1752589123) {
                                        if (str4 == null) {
                                            z14 = true;
                                        } else {
                                            z14 = false;
                                        }
                                        AbstractC0837z1.i(null, z14);
                                        yVar2.H(i45 + 8);
                                        eVarA = p079i3.e.a(yVar2);
                                        list3 = eVarA.f19206a;
                                        i49 = eVarA.f19207b;
                                        if (!z12) {
                                            fA = eVarA.f19208c;
                                        }
                                        str6 = eVarA.f19209d;
                                        str7 = "video/hevc";
                                    } else if (i47 != 1685480259) {
                                        i26 = i26;
                                        i35 = i35;
                                        fA = fA;
                                        i31 = i31;
                                        bArr3 = bArr;
                                        gVarA = gVarA;
                                        list2 = listV;
                                        i69 = i69;
                                        wVarB = w.b(yVar2);
                                        if (wVarB != null) {
                                            str5 = wVarB.f2669b;
                                            str4 = "video/dolby-vision";
                                        }
                                        listV = list2;
                                        bArr = bArr3;
                                    } else {
                                        i26 = i26;
                                        i35 = i35;
                                        fA = fA;
                                        i31 = i31;
                                        bArr3 = bArr;
                                        gVarA = gVarA;
                                        list2 = listV;
                                        i69 = i69;
                                        wVarB = w.b(yVar2);
                                        if (wVarB != null) {
                                            str5 = wVarB.f2669b;
                                            str4 = "video/dolby-vision";
                                        }
                                        listV = list2;
                                        bArr = bArr3;
                                    }
                                    i32 = i711 + i46;
                                    i69 = i69;
                                    i36 = i39;
                                    str2 = str18;
                                    i26 = i26;
                                    i31 = i31;
                                    gVarA = gVarA;
                                    i35 = i35;
                                    fA = fA;
                                }
                                i26 = i26;
                                i35 = i35;
                                fA = fA;
                                i31 = i31;
                                i34 = i49;
                                gVarA = gVarA;
                                str4 = str7;
                                i69 = i69;
                                listV = list3;
                                str5 = str6;
                                i32 = i711 + i46;
                                i69 = i69;
                                i36 = i39;
                                str2 = str18;
                                i26 = i26;
                                i31 = i31;
                                gVarA = gVarA;
                                i35 = i35;
                                fA = fA;
                            }
                            i40 = i35;
                            f3 = fA;
                            i41 = i31;
                            bArr2 = bArr;
                            gVar2 = gVarA;
                            list = listV;
                            i69 = i69;
                            if (str4 == null) {
                                i11 = i27;
                            } else {
                                m9 = new M();
                                m9.f17468a = Integer.toString(i25);
                                m9.f17477k = str4;
                                m9.f17475h = str5;
                                m9.f17482p = iC;
                                m9.f17483q = iC2;
                                m9.f17486t = f3;
                                i11 = i27;
                                m9.f17485s = i11;
                                m9.f17487u = bArr2;
                                m9.f17488v = i40;
                                m9.f17479m = list;
                                m9.f17480n = gVar2;
                                i42 = i39;
                                if (i42 == -1) {
                                    i44 = i38;
                                    i43 = i37;
                                    if (i44 == -1) {
                                    }
                                    if (y9 != null) {
                                        Y y15 = y9;
                                        m9.f17473f = p012b1.a.O(y15.f3452a);
                                        m9.f17474g = p012b1.a.O(y15.f3453b);
                                    }
                                    n9 = new N(m9);
                                } else {
                                    i43 = i37;
                                    i44 = i38;
                                }
                                if (byteBufferOrder != null) {
                                    bArrArray = byteBufferOrder.array();
                                } else {
                                    bArrArray = null;
                                }
                                m9.f17489w = new p079i3.b(i42, i44, i43, bArrArray);
                                if (y9 != null) {
                                    Y y16 = y9;
                                    m9.f17473f = p012b1.a.O(y16.f3452a);
                                    m9.f17474g = p012b1.a.O(y16.f3453b);
                                }
                                n9 = new N(m9);
                            }
                            i18 = i34;
                        } else {
                            i27 = i11;
                            arrayList5 = arrayList5;
                            aVar4 = aVar4;
                            pairCreate = pairCreate;
                            i15 = i15;
                            qVarArr = qVarArr;
                            i28 = i16;
                            yVar2.H(i23 + 16);
                            yVar2.I(16);
                            iC = yVar2.C();
                            iC2 = yVar2.C();
                            yVar2.I(50);
                            i29 = yVar2.f7099a;
                            if (i26 == 1701733238) {
                                i30 = i23;
                                i31 = i24;
                                pairC = c(yVar2, i30, i31);
                                if (pairC != null) {
                                    i26 = ((Integer) pairC.first).intValue();
                                    if (gVar == null) {
                                        gVarA = null;
                                    } else {
                                        gVarA = gVar.a(((q) pairC.second).f23905b);
                                    }
                                    qVarArr[i28] = (q) pairC.second;
                                } else {
                                    gVarA = gVar;
                                }
                                yVar2.H(i29);
                            } else {
                                i30 = i23;
                                i31 = i24;
                                gVarA = gVar;
                            }
                            if (i26 == 1831958048) {
                                str3 = "video/mpeg";
                            } else if (i26 == 1211250227) {
                                str3 = "video/3gpp";
                            } else {
                                str3 = null;
                            }
                            i32 = i29;
                            i33 = i30;
                            str = str;
                            z12 = false;
                            str4 = str3;
                            fA = 1.0f;
                            i34 = i18;
                            i35 = -1;
                            str5 = null;
                            bArr = null;
                            listV = null;
                            i36 = -1;
                            byteBufferOrder = null;
                            y9 = null;
                            i37 = -1;
                            i38 = -1;
                            while (true) {
                                if (i32 - i33 >= i31) {
                                    i39 = i36;
                                    break;
                                }
                                yVar2.H(i32);
                                i45 = yVar2.f7099a;
                                int i712 = i32;
                                i46 = yVar2.i();
                                i39 = i36;
                                if (i46 != 0) {
                                }
                                if (i46 > 0) {
                                    z13 = true;
                                } else {
                                    z13 = false;
                                }
                                AbstractC0837z1.i(str2, z13);
                                i47 = yVar2.i();
                                String str19 = str2;
                                if (i47 == 1635148611) {
                                    if (str4 == null) {
                                        z15 = true;
                                    } else {
                                        z15 = false;
                                    }
                                    AbstractC0837z1.i(null, z15);
                                    yVar2.H(i45 + 8);
                                    aVarA = p079i3.a.a(yVar2);
                                    list3 = aVarA.f19182a;
                                    i49 = aVarA.f19183b;
                                    if (!z12) {
                                        fA = aVarA.f19186e;
                                    }
                                    str6 = aVarA.f19187f;
                                    str7 = "video/avc";
                                } else {
                                    if (i47 == 1752589123) {
                                        if (str4 == null) {
                                            z14 = true;
                                        } else {
                                            z14 = false;
                                        }
                                        AbstractC0837z1.i(null, z14);
                                        yVar2.H(i45 + 8);
                                        eVarA = p079i3.e.a(yVar2);
                                        list3 = eVarA.f19206a;
                                        i49 = eVarA.f19207b;
                                        if (!z12) {
                                            fA = eVarA.f19208c;
                                        }
                                        str6 = eVarA.f19209d;
                                        str7 = "video/hevc";
                                    } else if (i47 != 1685480259) {
                                        i26 = i26;
                                        i35 = i35;
                                        fA = fA;
                                        i31 = i31;
                                        bArr3 = bArr;
                                        gVarA = gVarA;
                                        list2 = listV;
                                        i69 = i69;
                                        wVarB = w.b(yVar2);
                                        if (wVarB != null) {
                                            str5 = wVarB.f2669b;
                                            str4 = "video/dolby-vision";
                                        }
                                        listV = list2;
                                        bArr = bArr3;
                                    } else {
                                        i26 = i26;
                                        i35 = i35;
                                        fA = fA;
                                        i31 = i31;
                                        bArr3 = bArr;
                                        gVarA = gVarA;
                                        list2 = listV;
                                        i69 = i69;
                                        wVarB = w.b(yVar2);
                                        if (wVarB != null) {
                                            str5 = wVarB.f2669b;
                                            str4 = "video/dolby-vision";
                                        }
                                        listV = list2;
                                        bArr = bArr3;
                                    }
                                    i32 = i712 + i46;
                                    i69 = i69;
                                    i36 = i39;
                                    str2 = str19;
                                    i26 = i26;
                                    i31 = i31;
                                    gVarA = gVarA;
                                    i35 = i35;
                                    fA = fA;
                                }
                                i26 = i26;
                                i35 = i35;
                                fA = fA;
                                i31 = i31;
                                i34 = i49;
                                gVarA = gVarA;
                                str4 = str7;
                                i69 = i69;
                                listV = list3;
                                str5 = str6;
                                i32 = i712 + i46;
                                i69 = i69;
                                i36 = i39;
                                str2 = str19;
                                i26 = i26;
                                i31 = i31;
                                gVarA = gVarA;
                                i35 = i35;
                                fA = fA;
                            }
                            i40 = i35;
                            f3 = fA;
                            i41 = i31;
                            bArr2 = bArr;
                            gVar2 = gVarA;
                            list = listV;
                            i69 = i69;
                            if (str4 == null) {
                                i11 = i27;
                            } else {
                                m9 = new M();
                                m9.f17468a = Integer.toString(i25);
                                m9.f17477k = str4;
                                m9.f17475h = str5;
                                m9.f17482p = iC;
                                m9.f17483q = iC2;
                                m9.f17486t = f3;
                                i11 = i27;
                                m9.f17485s = i11;
                                m9.f17487u = bArr2;
                                m9.f17488v = i40;
                                m9.f17479m = list;
                                m9.f17480n = gVar2;
                                i42 = i39;
                                if (i42 == -1) {
                                    i44 = i38;
                                    i43 = i37;
                                    if (i44 == -1) {
                                    }
                                    if (y9 != null) {
                                        Y y17 = y9;
                                        m9.f17473f = p012b1.a.O(y17.f3452a);
                                        m9.f17474g = p012b1.a.O(y17.f3453b);
                                    }
                                    n9 = new N(m9);
                                } else {
                                    i43 = i37;
                                    i44 = i38;
                                }
                                if (byteBufferOrder != null) {
                                    bArrArray = byteBufferOrder.array();
                                } else {
                                    bArrArray = null;
                                }
                                m9.f17489w = new p079i3.b(i42, i44, i43, bArrArray);
                                if (y9 != null) {
                                    Y y18 = y9;
                                    m9.f17473f = p012b1.a.O(y18.f3452a);
                                    m9.f17474g = p012b1.a.O(y18.f3453b);
                                }
                                n9 = new N(m9);
                            }
                            i18 = i34;
                        }
                        yVar2.H(i33 + i41);
                        i16 = i28 + 1;
                        gVar = gVar;
                        i69 = i69;
                        arrayList4 = arrayList7;
                        i70 = i25;
                        i67 = i710;
                        i15 = i15;
                        str = str;
                        arrayList5 = arrayList5;
                        pairCreate = pairCreate;
                        aVar4 = aVar4;
                        i9 = i9;
                        qVarArr = qVarArr;
                    }
                    arrayList = arrayList4;
                    arrayList2 = arrayList5;
                    i19 = i70;
                    i20 = i67;
                    aVar2 = aVar4;
                    pair = pairCreate;
                    i21 = i9;
                    qVarArr2 = qVarArr;
                    if (z9) {
                        aVar4 = aVar2;
                        aVarR = aVar4.r(1701082227);
                        if (aVarR == null) {
                            bVarS = aVarR.s(1701606260);
                            if (bVarS == null) {
                                pairCreate2 = null;
                            } else {
                                yVar3 = bVarS.f23790c;
                                yVar3.H(8);
                                iQ2 = b.q(yVar3.i());
                                iA = yVar3.A();
                                jArr3 = new long[iA];
                                jArr4 = new long[iA];
                                while (i22 < iA) {
                                    if (iQ2 == 1) {
                                        jY3 = yVar3.B();
                                    } else {
                                        jY3 = yVar3.y();
                                    }
                                    jArr3[i22] = jY3;
                                    if (iQ2 == 1) {
                                        jI = yVar3.q();
                                    } else {
                                        jI = yVar3.i();
                                    }
                                    jArr4[i22] = jI;
                                    if (yVar3.t() == 1) {
                                        throw new IllegalArgumentException("Unsupported media rate.");
                                    }
                                    yVar3.I(2);
                                }
                                pairCreate2 = Pair.create(jArr3, jArr4);
                            }
                            if (pairCreate2 != null) {
                                jArr = (long[]) pairCreate2.first;
                                jArr2 = (long[]) pairCreate2.second;
                            }
                        }
                        if (n9 == null) {
                            pVar = null;
                        } else {
                            pVar = new p(i19, i21, ((Long) pair.first).longValue(), jY2, j10, n9, i17, qVarArr2, i18, jArr, jArr2);
                        }
                    } else {
                        aVar4 = aVar2;
                    }
                    jArr = null;
                    jArr2 = null;
                    if (n9 == null) {
                        pVar = null;
                    } else {
                        pVar = new p(i19, i21, ((Long) pair.first).longValue(), jY2, j10, n9, i17, qVarArr2, i18, jArr, jArr2);
                    }
                }
                p pVar2 = (p) fVar.apply(pVar);
                if (pVar2 == null) {
                    arrayList3 = arrayList2;
                } else {
                    a aVarR7 = aVar4.r(1835297121);
                    aVarR7.getClass();
                    a aVarR8 = aVarR7.r(1835626086);
                    aVarR8.getClass();
                    a aVarR9 = aVarR8.r(1937007212);
                    aVarR9.getClass();
                    s sVarD = d(pVar2, aVarR9, oVar);
                    arrayList3 = arrayList2;
                    arrayList3.add(sVarD);
                }
            }
            i67 = i20 + 1;
            aVar3 = aVar;
            arrayList5 = arrayList3;
            arrayList4 = arrayList;
        }
        return arrayList5;
    }
}
