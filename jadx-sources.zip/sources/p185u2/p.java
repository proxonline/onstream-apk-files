package p185u2;

import p052f2.N;

/* JADX INFO: loaded from: classes.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f23894a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f23895b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f23896c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f23897d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f23898e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final N f23899f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f23900g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long[] f23901h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final long[] f23902i;
    public final int j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final q[] f23903k;

    public p(int i9, int i10, long j, long j9, long j10, N n9, int i11, q[] qVarArr, int i12, long[] jArr, long[] jArr2) {
        this.f23894a = i9;
        this.f23895b = i10;
        this.f23896c = j;
        this.f23897d = j9;
        this.f23898e = j10;
        this.f23899f = n9;
        this.f23900g = i11;
        this.f23903k = qVarArr;
        this.j = i12;
        this.f23901h = jArr;
        this.f23902i = jArr2;
    }
}
