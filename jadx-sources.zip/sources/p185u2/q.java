package p185u2;

import p071h3.a;
import p116m2.t;

/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f23904a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f23905b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final t f23906c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f23907d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final byte[] f23908e;

    public q(boolean z9, String str, int i9, byte[] bArr, int i10, int i11, byte[] bArr2) {
        byte b10 = 0;
        int i12 = 1;
        a.h((i9 == 0) ^ (bArr2 == null));
        this.f23904a = z9;
        this.f23905b = str;
        this.f23907d = i9;
        this.f23908e = bArr2;
        if (str != null) {
            switch (str.hashCode()) {
                case 3046605:
                    if (!str.equals("cbc1")) {
                        b10 = -1;
                    }
                    break;
                case 3046671:
                    b10 = !str.equals("cbcs") ? (byte) -1 : (byte) 1;
                    break;
                case 3049879:
                    b10 = !str.equals("cenc") ? (byte) -1 : (byte) 2;
                    break;
                case 3049895:
                    b10 = !str.equals("cens") ? (byte) -1 : (byte) 3;
                    break;
                default:
                    b10 = -1;
                    break;
            }
            switch (b10) {
                case 0:
                case 1:
                    i12 = 2;
                    break;
                case 2:
                case 3:
                    break;
                default:
                    a.P("TrackEncryptionBox", "Unsupported protection scheme type '" + str + "'. Assuming AES-CTR crypto mode.");
                    break;
            }
        }
        this.f23906c = new t(i12, i10, i11, bArr);
    }
}
