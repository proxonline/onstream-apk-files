package p185u2;

/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f23887a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f23888b;

    public n(long j, int i9) {
        this.f23887a = j;
        this.f23888b = i9;
    }
}
