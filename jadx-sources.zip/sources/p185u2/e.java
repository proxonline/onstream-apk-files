package p185u2;

import S8.y;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class e implements d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f23800a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f23801b = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f23802c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f23803d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f23804e;

    public e() {
        int[] iArr = new int[16];
        this.f23804e = iArr;
        this.f23803d = iArr.length - 1;
    }

    @Override // p185u2.d
    public int a() {
        return -1;
    }

    @Override // p185u2.d
    public int b() {
        return this.f23800a;
    }

    public void c(int i9) {
        int i10 = this.f23802c;
        int[] iArr = (int[]) this.f23804e;
        if (i10 == iArr.length) {
            int length = iArr.length << 1;
            if (length < 0) {
                throw new IllegalStateException();
            }
            int[] iArr2 = new int[length];
            int length2 = iArr.length;
            int i11 = this.f23800a;
            int i12 = length2 - i11;
            System.arraycopy(iArr, i11, iArr2, 0, i12);
            System.arraycopy((int[]) this.f23804e, 0, iArr2, i12, i11);
            this.f23800a = 0;
            this.f23801b = this.f23802c - 1;
            this.f23804e = iArr2;
            this.f23803d = length - 1;
        }
        int i13 = (this.f23801b + 1) & this.f23803d;
        this.f23801b = i13;
        ((int[]) this.f23804e)[i13] = i9;
        this.f23802c++;
    }

    @Override // p185u2.d
    public int d() {
        y yVar = (y) this.f23804e;
        int i9 = this.f23801b;
        if (i9 == 8) {
            return yVar.x();
        }
        if (i9 == 16) {
            return yVar.C();
        }
        int i10 = this.f23802c;
        this.f23802c = i10 + 1;
        if (i10 % 2 != 0) {
            return this.f23803d & 15;
        }
        int iX = yVar.x();
        this.f23803d = iX;
        return (iX & 240) >> 4;
    }

    public int e() {
        int i9 = this.f23802c;
        if (i9 == 0) {
            throw new NoSuchElementException();
        }
        int[] iArr = (int[]) this.f23804e;
        int i10 = this.f23800a;
        int i11 = iArr[i10];
        this.f23800a = (i10 + 1) & this.f23803d;
        this.f23802c = i9 - 1;
        return i11;
    }
}
