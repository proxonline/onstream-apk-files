package p185u2;

import A5.e;
import M2.p;
import S0.b;
import S8.y;
import android.util.Pair;
import android.util.SparseArray;
import com.google.android.gms.internal.cast.z1;
import j$.util.DesugarCollections;
import java.io.EOFException;
import java.io.InterruptedIOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import p052f2.M;
import p052f2.N;
import p052f2.j0;
import p070h2.AbstractC0965a;
import p071h3.a;
import p071h3.x;
import p087j2.f;
import p087j2.g;
import p116m2.k;
import p116m2.l;
import p116m2.m;
import p116m2.o;
import p116m2.r;
import p116m2.u;

/* JADX INFO: loaded from: classes.dex */
public final class j implements p116m2.j {

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public static final byte[] f23824I = {-94, 57, 79, 82, 90, -101, 79, 20, -94, 68, 108, 66, 124, 100, -115, -12};

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public static final N f23825J;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f23826A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f23827B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public int f23828C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public boolean f23829D;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public boolean f23833H;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f23834a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p f23835b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f23836c;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final byte[] f23841h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final y f23842i;
    public final x j;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final u f23847o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f23848p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f23849q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public long f23850r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f23851s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public y f23852t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public long f23853u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f23854v;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public i f23858z;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final e f23843k = new e(1);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final y f23844l = new y(16);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final y f23838e = new y(a.f18823d);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final y f23839f = new y(5);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final y f23840g = new y(5, false);

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayDeque f23845m = new ArrayDeque();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final ArrayDeque f23846n = new ArrayDeque();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final SparseArray f23837d = new SparseArray();

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public long f23856x = -9223372036854775807L;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public long f23855w = -9223372036854775807L;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public long f23857y = -9223372036854775807L;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public l f23830E = l.f21264b0;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public u[] f23831F = new u[0];

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public u[] f23832G = new u[0];

    static {
        M m9 = new M();
        m9.f17477k = "application/x-emsg";
        f23825J = new N(m9);
    }

    public j(int i9, x xVar, p pVar, List list, p pVar2) {
        this.f23834a = i9;
        this.j = xVar;
        this.f23835b = pVar;
        this.f23836c = DesugarCollections.unmodifiableList(list);
        this.f23847o = pVar2;
        byte[] bArr = new byte[16];
        this.f23841h = bArr;
        this.f23842i = new y(bArr);
    }

    public static g c(List list) {
        int size = list.size();
        ArrayList arrayList = null;
        for (int i9 = 0; i9 < size; i9++) {
            b bVar = (b) list.get(i9);
            if (bVar.f6888b == 1886614376) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                byte[] bArr = (byte[]) bVar.f23790c.f7101c;
                E3.a aVarE = k.e(bArr);
                UUID uuid = aVarE == null ? null : (UUID) aVarE.f1302c;
                if (uuid == null) {
                    a.P("FragmentedMp4Extractor", "Skipped pssh atom (failed to extract uuid)");
                } else {
                    arrayList.add(new f(uuid, null, "video/mp4", bArr));
                }
            }
        }
        if (arrayList == null) {
            return null;
        }
        return new g(null, false, (f[]) arrayList.toArray(new f[0]));
    }

    public static void d(y yVar, int i9, r rVar) throws j0 {
        yVar.H(i9 + 8);
        int i10 = yVar.i();
        if ((i10 & 1) != 0) {
            throw j0.c("Overriding TrackEncryptionBox parameters is unsupported.");
        }
        boolean z9 = (i10 & 2) != 0;
        int iA = yVar.A();
        if (iA == 0) {
            Arrays.fill(rVar.f23919l, 0, rVar.f23913e, false);
            return;
        }
        int i11 = rVar.f23913e;
        y yVar2 = rVar.f23921n;
        if (iA != i11) {
            StringBuilder sbR = B0.a.r("Senc sample count ", iA, " is different from fragment sample count");
            sbR.append(rVar.f23913e);
            throw j0.a(sbR.toString(), null);
        }
        Arrays.fill(rVar.f23919l, 0, iA, z9);
        yVar2.E(yVar.e());
        rVar.f23918k = true;
        rVar.f23922o = true;
        yVar.h((byte[]) yVar2.f7101c, 0, yVar2.f7100b);
        yVar2.H(0);
        rVar.f23922o = false;
    }

    @Override // p116m2.j
    public final void a() {
    }

    @Override // p116m2.j
    public final void b(long j, long j9) {
        SparseArray sparseArray = this.f23837d;
        int size = sparseArray.size();
        for (int i9 = 0; i9 < size; i9++) {
            ((i) sparseArray.valueAt(i9)).d();
        }
        this.f23846n.clear();
        this.f23854v = 0;
        this.f23855w = j9;
        this.f23845m.clear();
        this.f23848p = 0;
        this.f23851s = 0;
    }

    @Override // p116m2.j
    public final void e(l lVar) {
        int i9;
        this.f23830E = lVar;
        this.f23848p = 0;
        this.f23851s = 0;
        u[] uVarArr = new u[2];
        this.f23831F = uVarArr;
        u uVar = this.f23847o;
        if (uVar != null) {
            uVarArr[0] = uVar;
            i9 = 1;
        } else {
            i9 = 0;
        }
        int i10 = 100;
        if ((this.f23834a & 4) != 0) {
            uVarArr[i9] = lVar.w(100, 5);
            i10 = 101;
            i9++;
        }
        u[] uVarArr2 = (u[]) p071h3.y.J(i9, this.f23831F);
        this.f23831F = uVarArr2;
        for (u uVar2 : uVarArr2) {
            uVar2.a(f23825J);
        }
        List list = this.f23836c;
        this.f23832G = new u[list.size()];
        int i11 = 0;
        while (i11 < this.f23832G.length) {
            u uVarW = this.f23830E.w(i10, 3);
            uVarW.a((N) list.get(i11));
            this.f23832G[i11] = uVarW;
            i11++;
            i10++;
        }
        p pVar = this.f23835b;
        if (pVar != null) {
            this.f23837d.put(0, new i(lVar.w(0, pVar.f23895b), new s(this.f23835b, new long[0], new int[0], 0, new long[0], new int[0], 0L), new g(0, 0, 0, 0)));
            this.f23830E.g();
        }
    }

    /* JADX WARN: Code duplicated, block: B:268:0x05c1  */
    public final void f(long j) throws j0 {
        g gVar;
        g gVar2;
        ArrayList arrayList;
        ArrayList arrayList2;
        ArrayList arrayList3;
        int i9;
        int i10;
        byte[] bArr;
        int i11;
        boolean z9;
        while (true) {
            ArrayDeque arrayDeque = this.f23845m;
            if (arrayDeque.isEmpty() || ((a) arrayDeque.peek()).f23787c != j) {
                break;
            }
            a aVar = (a) arrayDeque.pop();
            int i12 = aVar.f6888b;
            ArrayList arrayList4 = aVar.f23789e;
            ArrayList arrayList5 = aVar.f23788d;
            int i13 = this.f23834a;
            int i14 = 12;
            p pVar = this.f23835b;
            SparseArray sparseArray = this.f23837d;
            if (i12 == 1836019574) {
                if (!(pVar == null)) {
                    throw new IllegalStateException("Unexpected moov box.");
                }
                g gVarC = c(arrayList5);
                a aVarR = aVar.r(1836475768);
                aVarR.getClass();
                ArrayList arrayList6 = aVarR.f23788d;
                SparseArray sparseArray2 = new SparseArray();
                int size = arrayList6.size();
                int i15 = 0;
                long jY = -9223372036854775807L;
                while (i15 < size) {
                    b bVar = (b) arrayList6.get(i15);
                    int i16 = bVar.f6888b;
                    y yVar = bVar.f23790c;
                    if (i16 == 1953654136) {
                        yVar.H(i14);
                        arrayList = arrayList6;
                        Pair pairCreate = Pair.create(Integer.valueOf(yVar.i()), new g(yVar.i() - 1, yVar.i(), yVar.i(), yVar.i()));
                        sparseArray2.put(((Integer) pairCreate.first).intValue(), (g) pairCreate.second);
                    } else {
                        arrayList = arrayList6;
                        if (i16 == 1835362404) {
                            yVar.H(8);
                            jY = b.q(yVar.i()) == 0 ? yVar.y() : yVar.B();
                        }
                    }
                    i15++;
                    arrayList6 = arrayList;
                    i14 = 12;
                }
                int i17 = 1;
                ArrayList arrayListE = f.e(aVar, new o(), jY, gVarC, (i13 & 16) != 0, false, new p079i3.p(14, this));
                int size2 = arrayListE.size();
                if (sparseArray.size() == 0) {
                    int i18 = 0;
                    while (i18 < size2) {
                        s sVar = (s) arrayListE.get(i18);
                        p pVar2 = sVar.f23925a;
                        l lVar = this.f23830E;
                        int i19 = pVar2.f23895b;
                        int i20 = pVar2.f23894a;
                        u uVarW = lVar.w(i18, i19);
                        if (sparseArray2.size() == i17) {
                            gVar = (g) sparseArray2.valueAt(0);
                        } else {
                            gVar = (g) sparseArray2.get(i20);
                            gVar.getClass();
                        }
                        sparseArray.put(i20, new i(uVarW, sVar, gVar));
                        this.f23856x = Math.max(this.f23856x, pVar2.f23898e);
                        i18++;
                        i17 = 1;
                    }
                    this.f23830E.g();
                } else {
                    a.m(sparseArray.size() == size2);
                    for (int i21 = 0; i21 < size2; i21++) {
                        s sVar2 = (s) arrayListE.get(i21);
                        p pVar3 = sVar2.f23925a;
                        i iVar = (i) sparseArray.get(pVar3.f23894a);
                        int i22 = pVar3.f23894a;
                        if (sparseArray2.size() == 1) {
                            gVar2 = (g) sparseArray2.valueAt(0);
                        } else {
                            gVar2 = (g) sparseArray2.get(i22);
                            gVar2.getClass();
                        }
                        iVar.f23816d = sVar2;
                        iVar.f23817e = gVar2;
                        iVar.f23813a.a(sVar2.f23925a.f23899f);
                        iVar.d();
                    }
                }
            } else {
                int i23 = i13;
                if (i12 == 1836019558) {
                    boolean z10 = pVar != null;
                    int size3 = arrayList4.size();
                    int i24 = 0;
                    while (i24 < size3) {
                        a aVar2 = (a) arrayList4.get(i24);
                        if (aVar2.f6888b == 1953653094) {
                            b bVarS = aVar2.s(1952868452);
                            ArrayList arrayList7 = aVar2.f23788d;
                            bVarS.getClass();
                            y yVar2 = bVarS.f23790c;
                            yVar2.H(8);
                            int i25 = yVar2.i();
                            i iVar2 = (i) (z10 ? sparseArray.valueAt(0) : sparseArray.get(yVar2.i()));
                            if (iVar2 == null) {
                                size3 = size3;
                                iVar2 = null;
                            } else {
                                r rVar = iVar2.f23814b;
                                if ((i25 & 1) != 0) {
                                    long jB = yVar2.B();
                                    rVar.f23910b = jB;
                                    rVar.f23911c = jB;
                                }
                                g gVar3 = iVar2.f23817e;
                                rVar.f23909a = new g((i25 & 2) != 0 ? yVar2.i() - 1 : gVar3.f23806a, (i25 & 8) != 0 ? yVar2.i() : gVar3.f23807b, (i25 & 16) != 0 ? yVar2.i() : gVar3.f23808c, (i25 & 32) != 0 ? yVar2.i() : gVar3.f23809d);
                            }
                            if (iVar2 != null) {
                                r rVar2 = iVar2.f23814b;
                                long j9 = rVar2.f23923p;
                                boolean z11 = rVar2.f23924q;
                                iVar2.d();
                                iVar2.f23823l = true;
                                a aVar3 = aVar2;
                                b bVarS2 = aVar3.s(1952867444);
                                if (bVarS2 == null || (i23 & 2) != 0) {
                                    rVar2.f23923p = j9;
                                    rVar2.f23924q = z11;
                                } else {
                                    y yVar3 = bVarS2.f23790c;
                                    yVar3.H(8);
                                    rVar2.f23923p = b.q(yVar3.i()) == 1 ? yVar3.B() : yVar3.y();
                                    rVar2.f23924q = true;
                                }
                                int size4 = arrayList7.size();
                                int i26 = 0;
                                int i27 = 0;
                                int i28 = 0;
                                while (true) {
                                    i10 = 1953658222;
                                    if (i26 >= size4) {
                                        break;
                                    }
                                    int i29 = i26;
                                    b bVar2 = (b) arrayList7.get(i26);
                                    ArrayList arrayList8 = arrayList4;
                                    if (bVar2.f6888b == 1953658222) {
                                        y yVar4 = bVar2.f23790c;
                                        yVar4.H(12);
                                        int iA = yVar4.A();
                                        if (iA > 0) {
                                            i28 += iA;
                                            i27++;
                                        }
                                    }
                                    i26 = i29 + 1;
                                    arrayList4 = arrayList8;
                                }
                                arrayList2 = arrayList4;
                                iVar2.f23820h = 0;
                                iVar2.f23819g = 0;
                                iVar2.f23818f = 0;
                                rVar2.f23912d = i27;
                                rVar2.f23913e = i28;
                                if (rVar2.f23915g.length < i27) {
                                    rVar2.f23914f = new long[i27];
                                    rVar2.f23915g = new int[i27];
                                }
                                if (rVar2.f23916h.length < i28) {
                                    int i30 = (i28 * 125) / 100;
                                    rVar2.f23916h = new int[i30];
                                    rVar2.f23917i = new long[i30];
                                    rVar2.j = new boolean[i30];
                                    rVar2.f23919l = new boolean[i30];
                                }
                                int i31 = 0;
                                int i32 = 0;
                                int i33 = 0;
                                while (true) {
                                    long j10 = 0;
                                    if (i31 >= size4) {
                                        arrayList3 = arrayList5;
                                        i9 = i23;
                                        a aVar4 = aVar3;
                                        p pVar4 = iVar2.f23816d.f23925a;
                                        g gVar4 = rVar2.f23909a;
                                        gVar4.getClass();
                                        int i34 = gVar4.f23806a;
                                        q[] qVarArr = pVar4.f23903k;
                                        q qVar = qVarArr == null ? null : qVarArr[i34];
                                        b bVarS3 = aVar4.s(1935763834);
                                        if (bVarS3 != null) {
                                            qVar.getClass();
                                            y yVar5 = bVarS3.f23790c;
                                            int i35 = qVar.f23907d;
                                            yVar5.H(8);
                                            if ((yVar5.i() & 1) == 1) {
                                                yVar5.I(8);
                                            }
                                            int iX = yVar5.x();
                                            int iA2 = yVar5.A();
                                            if (iA2 > rVar2.f23913e) {
                                                StringBuilder sbR = B0.a.r("Saiz sample count ", iA2, " is greater than fragment sample count");
                                                sbR.append(rVar2.f23913e);
                                                throw j0.a(sbR.toString(), null);
                                            }
                                            if (iX == 0) {
                                                boolean[] zArr = rVar2.f23919l;
                                                i11 = 0;
                                                for (int i36 = 0; i36 < iA2; i36++) {
                                                    int iX2 = yVar5.x();
                                                    i11 += iX2;
                                                    zArr[i36] = iX2 > i35;
                                                }
                                                z9 = false;
                                            } else {
                                                i11 = iX * iA2;
                                                z9 = false;
                                                Arrays.fill(rVar2.f23919l, 0, iA2, iX > i35);
                                            }
                                            Arrays.fill(rVar2.f23919l, iA2, rVar2.f23913e, z9);
                                            if (i11 > 0) {
                                                rVar2.f23921n.E(i11);
                                                rVar2.f23918k = true;
                                                rVar2.f23922o = true;
                                            }
                                        }
                                        b bVarS4 = aVar4.s(1935763823);
                                        if (bVarS4 != null) {
                                            y yVar6 = bVarS4.f23790c;
                                            yVar6.H(8);
                                            int i37 = yVar6.i();
                                            if ((i37 & 1) == 1) {
                                                yVar6.I(8);
                                            }
                                            int iA3 = yVar6.A();
                                            if (iA3 != 1) {
                                                throw j0.a("Unexpected saio entry count: " + iA3, null);
                                            }
                                            rVar2.f23911c += b.q(i37) == 0 ? yVar6.y() : yVar6.B();
                                        }
                                        b bVarS5 = aVar4.s(1936027235);
                                        if (bVarS5 != null) {
                                            d(bVarS5.f23790c, 0, rVar2);
                                        }
                                        String str = qVar != null ? qVar.f23905b : null;
                                        y yVar7 = null;
                                        y yVar8 = null;
                                        for (int i38 = 0; i38 < arrayList7.size(); i38++) {
                                            b bVar3 = (b) arrayList7.get(i38);
                                            y yVar9 = bVar3.f23790c;
                                            int i39 = bVar3.f6888b;
                                            if (i39 == 1935828848) {
                                                yVar9.H(12);
                                                if (yVar9.i() == 1936025959) {
                                                    yVar7 = yVar9;
                                                }
                                            } else if (i39 == 1936158820) {
                                                yVar9.H(12);
                                                if (yVar9.i() == 1936025959) {
                                                    yVar8 = yVar9;
                                                }
                                            }
                                        }
                                        if (yVar7 != null && yVar8 != null) {
                                            yVar7.H(8);
                                            int iQ = b.q(yVar7.i());
                                            yVar7.I(4);
                                            if (iQ == 1) {
                                                yVar7.I(4);
                                            }
                                            if (yVar7.i() != 1) {
                                                throw j0.c("Entry count in sbgp != 1 (unsupported).");
                                            }
                                            yVar8.H(8);
                                            int iQ2 = b.q(yVar8.i());
                                            yVar8.I(4);
                                            if (iQ2 == 1) {
                                                if (yVar8.y() == 0) {
                                                    throw j0.c("Variable length description in sgpd found (unsupported)");
                                                }
                                            } else if (iQ2 >= 2) {
                                                yVar8.I(4);
                                            }
                                            if (yVar8.y() != 1) {
                                                throw j0.c("Entry count in sgpd != 1 (unsupported).");
                                            }
                                            yVar8.I(1);
                                            int iX3 = yVar8.x();
                                            int i40 = (iX3 & 240) >> 4;
                                            int i41 = iX3 & 15;
                                            boolean z12 = yVar8.x() == 1;
                                            if (z12) {
                                                int iX4 = yVar8.x();
                                                byte[] bArr2 = new byte[16];
                                                yVar8.h(bArr2, 0, 16);
                                                if (iX4 == 0) {
                                                    int iX5 = yVar8.x();
                                                    byte[] bArr3 = new byte[iX5];
                                                    yVar8.h(bArr3, 0, iX5);
                                                    bArr = bArr3;
                                                } else {
                                                    bArr = null;
                                                }
                                                rVar2.f23918k = true;
                                                rVar2.f23920m = new q(z12, str, iX4, bArr2, i40, i41, bArr);
                                            }
                                        }
                                        int size5 = arrayList7.size();
                                        for (int i42 = 0; i42 < size5; i42++) {
                                            b bVar4 = (b) arrayList7.get(i42);
                                            if (bVar4.f6888b == 1970628964) {
                                                y yVar10 = bVar4.f23790c;
                                                yVar10.H(8);
                                                byte[] bArr4 = this.f23841h;
                                                yVar10.h(bArr4, 0, 16);
                                                if (Arrays.equals(bArr4, f23824I)) {
                                                    d(yVar10, 16, rVar2);
                                                }
                                            }
                                        }
                                        break;
                                    }
                                    b bVar5 = (b) arrayList7.get(i31);
                                    int i43 = size4;
                                    if (bVar5.f6888b == i10) {
                                        int i44 = i32 + 1;
                                        y yVar11 = bVar5.f23790c;
                                        yVar11.H(8);
                                        int i45 = yVar11.i();
                                        p pVar5 = iVar2.f23816d.f23925a;
                                        g gVar5 = rVar2.f23909a;
                                        int i46 = p071h3.y.f18900a;
                                        int i47 = i32;
                                        rVar2.f23915g[i47] = yVar11.A();
                                        long[] jArr = rVar2.f23914f;
                                        int i48 = i33;
                                        long j11 = rVar2.f23910b;
                                        jArr[i47] = j11;
                                        if ((i45 & 1) != 0) {
                                            jArr[i47] = j11 + ((long) yVar11.i());
                                        }
                                        boolean z13 = (i45 & 4) != 0;
                                        int i49 = gVar5.f23809d;
                                        if (z13) {
                                            i49 = yVar11.i();
                                        }
                                        boolean z14 = z13;
                                        boolean z15 = (i45 & 256) != 0;
                                        boolean z16 = (i45 & 512) != 0;
                                        boolean z17 = (i45 & 1024) != 0;
                                        boolean z18 = (i45 & 2048) != 0;
                                        boolean z19 = z17;
                                        long[] jArr2 = pVar5.f23901h;
                                        int i50 = i49;
                                        if (jArr2 != null && jArr2.length == 1 && jArr2[0] == 0) {
                                            j10 = pVar5.f23902i[0];
                                        }
                                        int[] iArr = rVar2.f23916h;
                                        long[] jArr3 = rVar2.f23917i;
                                        boolean[] zArr2 = rVar2.j;
                                        boolean z20 = pVar5.f23895b == 2 && (i23 & 1) != 0;
                                        i33 = i48 + rVar2.f23915g[i47];
                                        long j12 = pVar5.f23896c;
                                        long j13 = rVar2.f23923p;
                                        int i51 = i48;
                                        while (i51 < i33) {
                                            int i52 = z15 ? yVar11.i() : gVar5.f23807b;
                                            boolean z21 = z20;
                                            if (i52 < 0) {
                                                throw j0.a("Unexpected negative value: " + i52, null);
                                            }
                                            int i53 = z16 ? yVar11.i() : gVar5.f23808c;
                                            if (i53 < 0) {
                                                throw j0.a("Unexpected negative value: " + i53, null);
                                            }
                                            int i54 = z19 ? yVar11.i() : (i51 == 0 && z14) ? i50 : gVar5.f23809d;
                                            long jO = p071h3.y.O((((long) (z18 ? yVar11.i() : 0)) + j13) - j10, 1000000L, j12);
                                            jArr3[i51] = jO;
                                            if (!rVar2.f23924q) {
                                                jArr3[i51] = jO + iVar2.f23816d.f23932h;
                                            }
                                            iArr[i51] = i53;
                                            zArr2[i51] = ((i54 >> 16) & 1) == 0 && (!z21 || i51 == 0);
                                            j13 += (long) i52;
                                            i51++;
                                            i33 = i33;
                                            z20 = z21;
                                            gVar5 = gVar5;
                                        }
                                        rVar2.f23923p = j13;
                                        i32 = i44;
                                    }
                                    aVar3 = aVar3;
                                    arrayList5 = arrayList5;
                                    i23 = i23;
                                    i10 = 1953658222;
                                    i31++;
                                    size4 = i43;
                                }
                            } else {
                                arrayList2 = arrayList4;
                                arrayList3 = arrayList5;
                                i9 = i23;
                            }
                        } else {
                            size3 = size3;
                            arrayList2 = arrayList4;
                            arrayList3 = arrayList5;
                            i9 = i23;
                        }
                        i24++;
                        arrayList4 = arrayList2;
                        size3 = size3;
                        arrayList5 = arrayList3;
                        i23 = i9;
                    }
                    g gVarC2 = c(arrayList5);
                    if (gVarC2 != null) {
                        int size6 = sparseArray.size();
                        for (int i55 = 0; i55 < size6; i55++) {
                            i iVar3 = (i) sparseArray.valueAt(i55);
                            p pVar6 = iVar3.f23816d.f23925a;
                            g gVar6 = iVar3.f23814b.f23909a;
                            int i56 = p071h3.y.f18900a;
                            int i57 = gVar6.f23806a;
                            q[] qVarArr2 = pVar6.f23903k;
                            q qVar2 = qVarArr2 == null ? null : qVarArr2[i57];
                            g gVarA = gVarC2.a(qVar2 != null ? qVar2.f23905b : null);
                            M mA = iVar3.f23816d.f23925a.f23899f.a();
                            mA.f17480n = gVarA;
                            iVar3.f23813a.a(new N(mA));
                        }
                    }
                    if (this.f23855w != -9223372036854775807L) {
                        int size7 = sparseArray.size();
                        for (int i58 = 0; i58 < size7; i58++) {
                            i iVar4 = (i) sparseArray.valueAt(i58);
                            long j14 = this.f23855w;
                            int i59 = iVar4.f23818f;
                            while (true) {
                                r rVar3 = iVar4.f23814b;
                                if (i59 >= rVar3.f23913e || rVar3.f23917i[i59] >= j14) {
                                    break;
                                }
                                if (rVar3.j[i59]) {
                                    iVar4.f23821i = i59;
                                }
                                i59++;
                            }
                        }
                        this.f23855w = -9223372036854775807L;
                    }
                } else if (!arrayDeque.isEmpty()) {
                    ((a) arrayDeque.peek()).f23789e.add(aVar);
                }
            }
        }
        this.f23848p = 0;
        this.f23851s = 0;
    }

    @Override // p116m2.j
    public final boolean g(k kVar) {
        return k.j(kVar, true, false);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // p116m2.j
    public final int j(k kVar, W5.k kVar2) throws j0, EOFException, InterruptedIOException {
        ArrayDeque arrayDeque;
        x xVar;
        String strR;
        String strR2;
        long j;
        long jA;
        long jO;
        long jY;
        long jB;
        long jB2;
        i iVar;
        char c10;
        int i9;
        ArrayDeque arrayDeque2;
        int iE;
        int i10;
        boolean z9;
        loop0: while (true) {
            while (true) {
                int i11 = this.f23848p;
                ArrayDeque arrayDeque3 = this.f23845m;
                SparseArray sparseArray = this.f23837d;
                char c11 = 2;
                if (i11 == 0) {
                    int i12 = this.f23851s;
                    y yVar = this.f23844l;
                    if (i12 == 0) {
                        if (!((p116m2.g) kVar).i((byte[]) yVar.f7101c, 0, 8, true)) {
                            return -1;
                        }
                        this.f23851s = 8;
                        yVar.H(0);
                        this.f23850r = yVar.y();
                        this.f23849q = yVar.i();
                    }
                    long j9 = this.f23850r;
                    if (j9 == 1) {
                        ((p116m2.g) kVar).i((byte[]) yVar.f7101c, 8, 8, false);
                        this.f23851s += 8;
                        this.f23850r = yVar.B();
                    } else if (j9 == 0) {
                        long j10 = ((p116m2.g) kVar).f21255c;
                        if (j10 == -1 && !arrayDeque3.isEmpty()) {
                            j10 = ((a) arrayDeque3.peek()).f23787c;
                        }
                        if (j10 != -1) {
                            this.f23850r = (j10 - ((p116m2.g) kVar).f21256d) + ((long) this.f23851s);
                        }
                    }
                    long j11 = this.f23850r;
                    int i13 = this.f23851s;
                    if (j11 < i13) {
                        throw j0.c("Atom size less than header length (unsupported).");
                    }
                    long j12 = ((p116m2.g) kVar).f21256d - ((long) i13);
                    int i14 = this.f23849q;
                    if ((i14 == 1836019558 || i14 == 1835295092) && !this.f23833H) {
                        this.f23830E.f(new m(this.f23856x, j12));
                        this.f23833H = true;
                    }
                    if (this.f23849q == 1836019558) {
                        int size = sparseArray.size();
                        for (int i15 = 0; i15 < size; i15++) {
                            r rVar = ((i) sparseArray.valueAt(i15)).f23814b;
                            rVar.getClass();
                            rVar.f23911c = j12;
                            rVar.f23910b = j12;
                        }
                    }
                    int i16 = this.f23849q;
                    if (i16 == 1835295092) {
                        this.f23858z = null;
                        this.f23853u = j12 + this.f23850r;
                        this.f23848p = 2;
                        break;
                    }
                    if (i16 == 1836019574 || i16 == 1953653099 || i16 == 1835297121 || i16 == 1835626086 || i16 == 1937007212 || i16 == 1836019558 || i16 == 1953653094 || i16 == 1836475768 || i16 == 1701082227) {
                        long j13 = (((p116m2.g) kVar).f21256d + this.f23850r) - 8;
                        arrayDeque3.push(new a(j13, i16));
                        if (this.f23850r != this.f23851s) {
                            this.f23848p = 0;
                            this.f23851s = 0;
                            break;
                        }
                        f(j13);
                        break;
                    }
                    if (i16 != 1751411826 && i16 != 1835296868 && i16 != 1836476516 && i16 != 1936286840 && i16 != 1937011556 && i16 != 1937011827 && i16 != 1668576371 && i16 != 1937011555 && i16 != 1937011578 && i16 != 1937013298 && i16 != 1937007471 && i16 != 1668232756 && i16 != 1937011571 && i16 != 1952867444 && i16 != 1952868452 && i16 != 1953196132 && i16 != 1953654136 && i16 != 1953658222 && i16 != 1886614376 && i16 != 1935763834 && i16 != 1935763823 && i16 != 1936027235 && i16 != 1970628964 && i16 != 1935828848 && i16 != 1936158820 && i16 != 1701606260 && i16 != 1835362404 && i16 != 1701671783) {
                        if (this.f23850r > 2147483647L) {
                            throw j0.c("Skipping atom with length > 2147483647 (unsupported).");
                        }
                        this.f23852t = null;
                        this.f23848p = 1;
                        break;
                    }
                    if (this.f23851s != 8) {
                        throw j0.c("Leaf atom defines extended atom size (unsupported).");
                    }
                    long j14 = this.f23850r;
                    if (j14 > 2147483647L) {
                        throw j0.c("Leaf atom with length > 2147483647 (unsupported).");
                    }
                    y yVar2 = new y((int) j14);
                    System.arraycopy((byte[]) yVar.f7101c, 0, (byte[]) yVar2.f7101c, 0, 8);
                    this.f23852t = yVar2;
                    this.f23848p = 1;
                    break;
                }
                arrayDeque = this.f23846n;
                xVar = this.j;
                if (i11 == 1) {
                    int i17 = ((int) this.f23850r) - this.f23851s;
                    y yVar3 = this.f23852t;
                    if (yVar3 != null) {
                        ((p116m2.g) kVar).i((byte[]) yVar3.f7101c, 8, i17, false);
                        int i18 = this.f23849q;
                        b bVar = new b(i18, yVar3);
                        long j15 = ((p116m2.g) kVar).f21256d;
                        if (!arrayDeque3.isEmpty()) {
                            ((a) arrayDeque3.peek()).f23788d.add(bVar);
                        } else if (i18 == 1936286840) {
                            yVar3.H(8);
                            int iQ = b.q(yVar3.i());
                            yVar3.I(4);
                            long jY2 = yVar3.y();
                            if (iQ == 0) {
                                jB = yVar3.y();
                                jB2 = yVar3.y();
                            } else {
                                jB = yVar3.B();
                                jB2 = yVar3.B();
                            }
                            long j16 = jB2 + j15;
                            long j17 = jB;
                            long jO2 = p071h3.y.O(j17, 1000000L, jY2);
                            yVar3.I(2);
                            int iC = yVar3.C();
                            int[] iArr = new int[iC];
                            long[] jArr = new long[iC];
                            long[] jArr2 = new long[iC];
                            long[] jArr3 = new long[iC];
                            long jO3 = jO2;
                            long j18 = j17;
                            int i19 = 0;
                            while (i19 < iC) {
                                int i20 = yVar3.i();
                                if ((i20 & Integer.MIN_VALUE) != 0) {
                                    throw j0.a("Unhandled indirect reference", null);
                                }
                                long jY3 = yVar3.y();
                                iArr[i19] = i20 & Integer.MAX_VALUE;
                                jArr[i19] = j16;
                                jArr3[i19] = jO3;
                                long j19 = j18 + jY3;
                                long[] jArr4 = jArr2;
                                long[] jArr5 = jArr3;
                                int i21 = i19;
                                jO3 = p071h3.y.O(j19, 1000000L, jY2);
                                jArr4[i21] = jO3 - jArr5[i21];
                                yVar3.I(4);
                                j16 += (long) iArr[i21];
                                jArr2 = jArr4;
                                jArr3 = jArr5;
                                i19 = i21 + 1;
                                jO2 = jO2;
                                j18 = j19;
                            }
                            Pair pairCreate = Pair.create(Long.valueOf(jO2), new p116m2.f(iArr, jArr, jArr2, jArr3));
                            this.f23857y = ((Long) pairCreate.first).longValue();
                            this.f23830E.f((r) pairCreate.second);
                            this.f23833H = true;
                        } else if (i18 == 1701671783 && this.f23831F.length != 0) {
                            yVar3.H(8);
                            int iQ2 = b.q(yVar3.i());
                            if (iQ2 == 0) {
                                strR = yVar3.r();
                                strR.getClass();
                                strR2 = yVar3.r();
                                strR2.getClass();
                                long jY4 = yVar3.y();
                                long jO4 = p071h3.y.O(yVar3.y(), 1000000L, jY4);
                                long j20 = this.f23857y;
                                long j21 = j20 != -9223372036854775807L ? j20 + jO4 : -9223372036854775807L;
                                j = jO4;
                                jA = j21;
                                jO = p071h3.y.O(yVar3.y(), 1000L, jY4);
                                jY = yVar3.y();
                            } else if (iQ2 != 1) {
                                z1.u("Skipping unsupported emsg version: ", iQ2, "FragmentedMp4Extractor");
                            } else {
                                long jY5 = yVar3.y();
                                jA = p071h3.y.O(yVar3.B(), 1000000L, jY5);
                                long jO5 = p071h3.y.O(yVar3.y(), 1000L, jY5);
                                long jY6 = yVar3.y();
                                strR = yVar3.r();
                                strR.getClass();
                                strR2 = yVar3.r();
                                strR2.getClass();
                                jO = jO5;
                                jY = jY6;
                                j = -9223372036854775807L;
                            }
                            String str = strR;
                            String str2 = strR2;
                            byte[] bArr = new byte[yVar3.e()];
                            yVar3.h(bArr, 0, yVar3.e());
                            y yVar4 = new y(this.f23843k.h(new B2.a(str, str2, jO, jY, bArr)));
                            int iE2 = yVar4.e();
                            for (u uVar : this.f23831F) {
                                yVar4.H(0);
                                uVar.c(iE2, yVar4);
                            }
                            if (jA == -9223372036854775807L) {
                                arrayDeque.addLast(new h(iE2, j, true));
                                this.f23854v += iE2;
                            } else if (arrayDeque.isEmpty()) {
                                if (xVar != null) {
                                    jA = xVar.a(jA);
                                }
                                long j22 = jA;
                                for (u uVar2 : this.f23831F) {
                                    uVar2.b(j22, 1, iE2, 0, null);
                                }
                            } else {
                                arrayDeque.addLast(new h(iE2, jA, false));
                                this.f23854v += iE2;
                            }
                        }
                    } else {
                        ((p116m2.g) kVar).s(i17);
                    }
                    f(((p116m2.g) kVar).f21256d);
                    break;
                }
                long j23 = Long.MAX_VALUE;
                if (i11 != 2) {
                    iVar = this.f23858z;
                    if (iVar != null) {
                        c10 = 2;
                        i9 = 8;
                        break loop0;
                    }
                    int size2 = sparseArray.size();
                    long j24 = Long.MAX_VALUE;
                    i iVar2 = null;
                    int i22 = 0;
                    while (i22 < size2) {
                        char c12 = c11;
                        i iVar3 = (i) sparseArray.valueAt(i22);
                        boolean z10 = iVar3.f23823l;
                        r rVar2 = iVar3.f23814b;
                        if ((z10 || iVar3.f23818f != iVar3.f23816d.f23926b) && (!z10 || iVar3.f23820h != rVar2.f23912d)) {
                            long j25 = !z10 ? iVar3.f23816d.f23927c[iVar3.f23818f] : rVar2.f23914f[iVar3.f23820h];
                            if (j25 < j24) {
                                iVar2 = iVar3;
                                j24 = j25;
                            }
                        }
                        i22++;
                        c11 = c12;
                    }
                    c10 = c11;
                    i9 = 8;
                    if (iVar2 != null) {
                        int i23 = (int) ((!iVar2.f23823l ? iVar2.f23816d.f23927c[iVar2.f23818f] : iVar2.f23814b.f23914f[iVar2.f23820h]) - ((p116m2.g) kVar).f21256d);
                        if (i23 < 0) {
                            a.P("FragmentedMp4Extractor", "Ignoring negative offset to sample data.");
                            i23 = 0;
                        }
                        ((p116m2.g) kVar).s(i23);
                        this.f23858z = iVar2;
                        iVar = iVar2;
                        break loop0;
                    }
                    int i24 = (int) (this.f23853u - ((p116m2.g) kVar).f21256d);
                    if (i24 < 0) {
                        throw j0.a("Offset to end of mdat was negative.", null);
                    }
                    ((p116m2.g) kVar).s(i24);
                    this.f23848p = 0;
                    this.f23851s = 0;
                } else {
                    int size3 = sparseArray.size();
                    i iVar4 = null;
                    for (int i25 = 0; i25 < size3; i25++) {
                        r rVar3 = ((i) sparseArray.valueAt(i25)).f23814b;
                        if (rVar3.f23922o) {
                            long j26 = rVar3.f23911c;
                            if (j26 < j23) {
                                iVar4 = (i) sparseArray.valueAt(i25);
                                j23 = j26;
                            }
                        }
                    }
                    if (iVar4 == null) {
                        this.f23848p = 3;
                    } else {
                        int i26 = (int) (j23 - ((p116m2.g) kVar).f21256d);
                        if (i26 < 0) {
                            throw j0.a("Offset to encryption data was negative.", null);
                        }
                        p116m2.g gVar = (p116m2.g) kVar;
                        gVar.s(i26);
                        r rVar4 = iVar4.f23814b;
                        y yVar5 = rVar4.f23921n;
                        gVar.i((byte[]) yVar5.f7101c, 0, yVar5.f7100b, false);
                        yVar5.H(0);
                        rVar4.f23922o = false;
                    }
                }
            }
        }
        r rVar5 = iVar.f23814b;
        if (this.f23848p == 3) {
            int i27 = !iVar.f23823l ? iVar.f23816d.f23928d[iVar.f23818f] : rVar5.f23916h[iVar.f23818f];
            this.f23826A = i27;
            if (iVar.f23818f < iVar.f23821i) {
                ((p116m2.g) kVar).s(i27);
                q qVarA = iVar.a();
                if (qVarA != null) {
                    y yVar6 = rVar5.f23921n;
                    int i28 = qVarA.f23907d;
                    if (i28 != 0) {
                        yVar6.I(i28);
                    }
                    int i29 = iVar.f23818f;
                    if (rVar5.f23918k && rVar5.f23919l[i29]) {
                        yVar6.I(yVar6.C() * 6);
                    }
                }
                if (!iVar.b()) {
                    this.f23858z = null;
                }
                this.f23848p = 3;
                return 0;
            }
            if (iVar.f23816d.f23925a.f23900g == 1) {
                this.f23826A = i27 - 8;
                ((p116m2.g) kVar).s(i9);
            }
            if ("audio/ac4".equals(iVar.f23816d.f23925a.f23899f.f17509l)) {
                this.f23827B = iVar.c(this.f23826A, 7);
                int i30 = this.f23826A;
                y yVar7 = this.f23842i;
                AbstractC0965a.e(i30, yVar7);
                iVar.f23813a.c(7, yVar7);
                this.f23827B += 7;
            } else {
                this.f23827B = iVar.c(this.f23826A, 0);
            }
            this.f23826A += this.f23827B;
            this.f23848p = 4;
            this.f23828C = 0;
        }
        s sVar = iVar.f23816d;
        p pVar = sVar.f23925a;
        u uVar3 = iVar.f23813a;
        long jA2 = iVar.f23823l ? rVar5.f23917i[iVar.f23818f] : sVar.f23930f[iVar.f23818f];
        if (xVar != null) {
            jA2 = xVar.a(jA2);
        }
        int i31 = pVar.j;
        N n9 = pVar.f23899f;
        if (i31 == 0) {
            arrayDeque2 = arrayDeque;
            while (true) {
                int i32 = this.f23827B;
                int i33 = this.f23826A;
                if (i32 >= i33) {
                    break;
                }
                this.f23827B += uVar3.e(kVar, i33 - i32, false);
            }
        } else {
            y yVar8 = this.f23839f;
            byte[] bArr2 = (byte[]) yVar8.f7101c;
            bArr2[0] = 0;
            bArr2[1] = 0;
            bArr2[c10] = 0;
            int i34 = i31 + 1;
            int i35 = 4 - i31;
            while (this.f23827B < this.f23826A) {
                int i36 = this.f23828C;
                if (i36 == 0) {
                    ((p116m2.g) kVar).i(bArr2, i35, i34, false);
                    yVar8.H(0);
                    int i37 = yVar8.i();
                    if (i37 < 1) {
                        throw j0.a("Invalid NAL length", null);
                    }
                    this.f23828C = i37 - 1;
                    y yVar9 = this.f23838e;
                    yVar9.H(0);
                    uVar3.c(4, yVar9);
                    uVar3.c(1, yVar8);
                    if (this.f23832G.length > 0) {
                        String str3 = n9.f17509l;
                        byte b10 = bArr2[4];
                        if ("video/avc".equals(str3)) {
                            i10 = i35;
                            if ((b10 & 31) != 6) {
                            }
                            z9 = true;
                            this.f23829D = z9;
                            this.f23827B += 5;
                            this.f23826A += i10;
                            i35 = i10;
                        } else {
                            i10 = i35;
                        }
                        if ("video/hevc".equals(str3) && ((b10 & 126) >> 1) == 39) {
                            z9 = true;
                        }
                        this.f23829D = z9;
                        this.f23827B += 5;
                        this.f23826A += i10;
                        i35 = i10;
                    } else {
                        i10 = i35;
                    }
                    z9 = false;
                    this.f23829D = z9;
                    this.f23827B += 5;
                    this.f23826A += i10;
                    i35 = i10;
                } else {
                    int i38 = i35;
                    if (this.f23829D) {
                        y yVar10 = this.f23840g;
                        yVar10.E(i36);
                        ((p116m2.g) kVar).i((byte[]) yVar10.f7101c, 0, this.f23828C, false);
                        uVar3.c(this.f23828C, yVar10);
                        iE = this.f23828C;
                        int iO = a.O(yVar10.f7100b, (byte[]) yVar10.f7101c);
                        yVar10.H("video/hevc".equals(n9.f17509l) ? 1 : 0);
                        yVar10.G(iO);
                        p012b1.a.i(jA2, yVar10, this.f23832G);
                    } else {
                        iE = uVar3.e(kVar, i36, false);
                    }
                    this.f23827B += iE;
                    this.f23828C -= iE;
                    i35 = i38;
                    i34 = i34;
                    yVar8 = yVar8;
                }
                arrayDeque = arrayDeque;
            }
            arrayDeque2 = arrayDeque;
        }
        int i39 = iVar.f23823l ? rVar5.j[iVar.f23818f] ? 1 : 0 : iVar.f23816d.f23931g[iVar.f23818f];
        if (iVar.a() != null) {
            i39 |= 1073741824;
        }
        int i40 = i39;
        q qVarA2 = iVar.a();
        long j27 = jA2;
        uVar3.b(j27, i40, this.f23826A, 0, qVarA2 != null ? qVarA2.f23906c : null);
        while (!arrayDeque2.isEmpty()) {
            h hVar = (h) arrayDeque2.removeFirst();
            this.f23854v -= hVar.f23812c;
            long jA3 = hVar.f23810a;
            if (hVar.f23811b) {
                jA3 += j27;
            }
            if (xVar != null) {
                jA3 = xVar.a(jA3);
            }
            long j28 = jA3;
            for (u uVar4 : this.f23831F) {
                uVar4.b(j28, 1, hVar.f23812c, this.f23854v, null);
            }
        }
        if (!iVar.b()) {
            this.f23858z = null;
        }
        this.f23848p = 3;
        return 0;
    }
}
