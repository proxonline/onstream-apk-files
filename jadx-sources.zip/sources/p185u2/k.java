package p185u2;

import E2.e;
import E2.j;
import E2.n;
import S0.b;
import S8.y;
import com.google.android.gms.internal.cast.z1;
import java.nio.ByteBuffer;
import java.util.UUID;
import p071h3.a;

/* JADX INFO: loaded from: classes.dex */
public abstract class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String[] f23859a = {"Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise", "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House", "Dance Hall", "Goa", "Drum & Bass", "Club-House", "Hardcore", "Terror", "Indie", "BritPop", "Afro-Punk", "Polsk Punk", "Beat", "Christian Gangsta Rap", "Heavy Metal", "Black Metal", "Crossover", "Contemporary Christian", "Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "Jpop", "Synthpop", "Abstract", "Art Rock", "Baroque", "Bhangra", "Big beat", "Breakbeat", "Chillout", "Downtempo", "Dub", "EBM", "Eclectic", "Electro", "Electroclash", "Emo", "Experimental", "Garage", "Global", "IDM", "Illbient", "Industro-Goth", "Jam Band", "Krautrock", "Leftfield", "Lounge", "Math Rock", "New Romantic", "Nu-Breakz", "Post-Punk", "Post-Rock", "Psytrance", "Shoegaze", "Space Rock", "Trop Rock", "World Music", "Neoclassical", "Audiobook", "Audio theatre", "Neue Deutsche Welle", "Podcast", "Indie-Rock", "G-Funk", "Dubstep", "Garage Rock", "Psybient"};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f23860b = {1769172845, 1769172786, 1769172787, 1769172788, 1769172789, 1769172790, 1769172793, 1635148593, 1752589105, 1751479857, 1635135537, 1836069937, 1836069938, 862401121, 862401122, 862417462, 862417718, 862414134, 862414646, 1295275552, 1295270176, 1714714144, 1801741417, 1295275600, 1903435808, 1297305174, 1684175153, 1769172332, 1885955686};

    public static byte[] a(UUID uuid, UUID[] uuidArr, byte[] bArr) {
        int length = (bArr != null ? bArr.length : 0) + 32;
        if (uuidArr != null) {
            length += (uuidArr.length * 16) + 4;
        }
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(length);
        byteBufferAllocate.putInt(length);
        byteBufferAllocate.putInt(1886614376);
        byteBufferAllocate.putInt(uuidArr != null ? 16777216 : 0);
        byteBufferAllocate.putLong(uuid.getMostSignificantBits());
        byteBufferAllocate.putLong(uuid.getLeastSignificantBits());
        if (uuidArr != null) {
            byteBufferAllocate.putInt(uuidArr.length);
            for (UUID uuid2 : uuidArr) {
                byteBufferAllocate.putLong(uuid2.getMostSignificantBits());
                byteBufferAllocate.putLong(uuid2.getLeastSignificantBits());
            }
        }
        if (bArr != null && bArr.length != 0) {
            byteBufferAllocate.putInt(bArr.length);
            byteBufferAllocate.put(bArr);
        }
        return byteBufferAllocate.array();
    }

    public static e b(int i9, y yVar) {
        int i10 = yVar.i();
        if (yVar.i() == 1684108385) {
            yVar.I(8);
            String strS = yVar.s(i10 - 16);
            return new e("und", strS, strS);
        }
        a.P("MetadataUtil", "Failed to parse comment attribute: " + b.d(i9));
        return null;
    }

    public static E2.a c(y yVar) {
        String str;
        int i9 = yVar.i();
        if (yVar.i() != 1684108385) {
            a.P("MetadataUtil", "Failed to parse cover art attribute");
            return null;
        }
        int i10 = yVar.i() & 16777215;
        if (i10 == 13) {
            str = "image/jpeg";
        } else {
            str = i10 == 14 ? "image/png" : null;
        }
        if (str == null) {
            z1.u("Unrecognized cover art flags: ", i10, "MetadataUtil");
            return null;
        }
        yVar.I(4);
        int i11 = i9 - 16;
        byte[] bArr = new byte[i11];
        yVar.h(bArr, 0, i11);
        return new E2.a(str, null, 3, bArr);
    }

    public static n d(int i9, y yVar, String str) {
        int i10 = yVar.i();
        if (yVar.i() == 1684108385 && i10 >= 22) {
            yVar.I(10);
            int iC = yVar.C();
            if (iC > 0) {
                String strK = z1.k("", iC);
                int iC2 = yVar.C();
                if (iC2 > 0) {
                    strK = strK + "/" + iC2;
                }
                return new n(str, null, strK);
            }
        }
        a.P("MetadataUtil", "Failed to parse index/count attribute: " + b.d(i9));
        return null;
    }

    public static E3.a e(byte[] bArr) {
        y yVar = new y(bArr);
        if (yVar.f7100b >= 32) {
            yVar.H(0);
            if (yVar.i() == yVar.e() + 4 && yVar.i() == 1886614376) {
                int iQ = b.q(yVar.i());
                if (iQ > 1) {
                    z1.u("Unsupported pssh version: ", iQ, "PsshAtomUtil");
                    return null;
                }
                UUID uuid = new UUID(yVar.q(), yVar.q());
                if (iQ == 1) {
                    yVar.I(yVar.A() * 16);
                }
                int iA = yVar.A();
                if (iA == yVar.e()) {
                    byte[] bArr2 = new byte[iA];
                    yVar.h(bArr2, 0, iA);
                    return new E3.a(uuid, iQ, bArr2);
                }
            }
        }
        return null;
    }

    public static byte[] f(byte[] bArr, UUID uuid) {
        E3.a aVarE = e(bArr);
        if (aVarE == null) {
            return null;
        }
        UUID uuid2 = (UUID) aVarE.f1302c;
        if (uuid.equals(uuid2)) {
            return (byte[]) aVarE.f1303d;
        }
        a.P("PsshAtomUtil", "UUID mismatch. Expected: " + uuid + ", got: " + uuid2 + ".");
        return null;
    }

    public static n g(int i9, y yVar, String str) {
        int i10 = yVar.i();
        if (yVar.i() == 1684108385) {
            yVar.I(8);
            return new n(str, null, yVar.s(i10 - 16));
        }
        a.P("MetadataUtil", "Failed to parse text attribute: " + b.d(i9));
        return null;
    }

    public static j h(int i9, String str, y yVar, boolean z9, boolean z10) {
        int i10 = i(yVar);
        if (z10) {
            i10 = Math.min(1, i10);
        }
        if (i10 >= 0) {
            return z9 ? new n(str, null, Integer.toString(i10)) : new e("und", str, Integer.toString(i10));
        }
        a.P("MetadataUtil", "Failed to parse uint8 attribute: " + b.d(i9));
        return null;
    }

    public static int i(y yVar) {
        yVar.I(4);
        if (yVar.i() == 1684108385) {
            yVar.I(8);
            return yVar.x();
        }
        a.P("MetadataUtil", "Failed to parse uint8 attribute value");
        return -1;
    }

    public static boolean j(p116m2.k kVar, boolean z9, boolean z10) {
        boolean z11;
        int i9;
        long length = kVar.getLength();
        long j = -1;
        int i10 = (length > (-1L) ? 1 : (length == (-1L) ? 0 : -1));
        long j9 = 4096;
        if (i10 != 0 && length <= 4096) {
            j9 = length;
        }
        int i11 = (int) j9;
        y yVar = new y(64);
        int i12 = 0;
        int i13 = 0;
        boolean z12 = false;
        while (true) {
            if (i13 < i11) {
                yVar.E(8);
                if (kVar.v((byte[]) yVar.f7101c, i12, 8, true)) {
                    long jY = yVar.y();
                    int i14 = yVar.i();
                    if (jY == 1) {
                        kVar.F((byte[]) yVar.f7101c, 8, 8);
                        yVar.G(16);
                        i9 = 16;
                        jY = yVar.q();
                    } else {
                        if (jY == 0) {
                            long length2 = kVar.getLength();
                            if (length2 != j) {
                                jY = (length2 - kVar.A()) + ((long) 8);
                            }
                        }
                        i9 = 8;
                    }
                    long j10 = i9;
                    if (jY < j10) {
                        return false;
                    }
                    int i15 = i13 + i9;
                    if (i14 == 1836019574) {
                        i11 += (int) jY;
                        if (i10 != 0 && i11 > length) {
                            i11 = (int) length;
                        }
                        i13 = i15;
                    } else {
                        if (i14 == 1836019558 || i14 == 1836475768) {
                            z11 = true;
                            return z12 && z9 == z11;
                        }
                        int i16 = i10;
                        if ((((long) i15) + jY) - j10 < i11) {
                            int i17 = (int) (jY - j10);
                            i13 = i15 + i17;
                            if (i14 == 1718909296) {
                                if (i17 < 8) {
                                    return false;
                                }
                                yVar.E(i17);
                                kVar.F((byte[]) yVar.f7101c, 0, i17);
                                int i18 = i17 / 4;
                                for (int i19 = 0; i19 < i18; i19++) {
                                    if (i19 != 1) {
                                        int i20 = yVar.i();
                                        if ((i20 >>> 8) != 3368816 && (i20 != 1751476579 || !z10)) {
                                            int i21 = 0;
                                            while (true) {
                                                if (i21 >= 29) {
                                                    continue;
                                                } else if (f23860b[i21] != i20) {
                                                    i21++;
                                                }
                                            }
                                        }
                                        z12 = true;
                                        break;
                                    }
                                    yVar.I(4);
                                }
                                if (!z12) {
                                    return false;
                                }
                            } else if (i17 != 0) {
                                kVar.G(i17);
                            }
                            i10 = i16;
                        }
                    }
                    j = -1;
                    i12 = 0;
                }
            }
            z11 = false;
            if (z12) {
                return false;
            }
        }
    }
}
