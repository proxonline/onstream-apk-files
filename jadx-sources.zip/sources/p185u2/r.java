package p185u2;

import S8.y;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public g f23909a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f23910b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f23911c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f23912d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f23913e;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f23918k;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public q f23920m;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f23922o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public long f23923p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f23924q;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long[] f23914f = new long[0];

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int[] f23915g = new int[0];

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int[] f23916h = new int[0];

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public long[] f23917i = new long[0];
    public boolean[] j = new boolean[0];

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean[] f23919l = new boolean[0];

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final y f23921n = new y(5, false);
}
