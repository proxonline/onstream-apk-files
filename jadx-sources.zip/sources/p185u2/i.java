package p185u2;

import S8.y;
import p116m2.u;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final u f23813a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public s f23816d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public g f23817e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f23818f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f23819g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f23820h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f23821i;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f23823l;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final r f23814b = new r();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final y f23815c = new y(5, false);
    public final y j = new y(1);

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final y f23822k = new y(5, false);

    public i(u uVar, s sVar, g gVar) {
        this.f23813a = uVar;
        this.f23816d = sVar;
        this.f23817e = gVar;
        this.f23816d = sVar;
        this.f23817e = gVar;
        uVar.a(sVar.f23925a.f23899f);
        d();
    }

    public final q a() {
        if (this.f23823l) {
            r rVar = this.f23814b;
            g gVar = rVar.f23909a;
            int i9 = p071h3.y.f18900a;
            int i10 = gVar.f23806a;
            q qVar = rVar.f23920m;
            if (qVar == null) {
                q[] qVarArr = this.f23816d.f23925a.f23903k;
                qVar = qVarArr == null ? null : qVarArr[i10];
            }
            if (qVar != null && qVar.f23904a) {
                return qVar;
            }
        }
        return null;
    }

    public final boolean b() {
        this.f23818f++;
        if (!this.f23823l) {
            return false;
        }
        int i9 = this.f23819g + 1;
        this.f23819g = i9;
        int[] iArr = this.f23814b.f23915g;
        int i10 = this.f23820h;
        if (i9 != iArr[i10]) {
            return true;
        }
        this.f23820h = i10 + 1;
        this.f23819g = 0;
        return false;
    }

    public final int c(int i9, int i10) {
        y yVar;
        q qVarA = a();
        if (qVarA == null) {
            return 0;
        }
        int length = qVarA.f23907d;
        r rVar = this.f23814b;
        if (length != 0) {
            yVar = rVar.f23921n;
        } else {
            byte[] bArr = qVarA.f23908e;
            int i11 = p071h3.y.f18900a;
            int length2 = bArr.length;
            y yVar2 = this.f23822k;
            yVar2.F(length2, bArr);
            length = bArr.length;
            yVar = yVar2;
        }
        boolean z9 = rVar.f23918k && rVar.f23919l[this.f23818f];
        boolean z10 = z9 || i10 != 0;
        y yVar3 = this.j;
        ((byte[]) yVar3.f7101c)[0] = (byte) ((z10 ? 128 : 0) | length);
        yVar3.H(0);
        u uVar = this.f23813a;
        uVar.d(1, yVar3);
        uVar.d(length, yVar);
        if (!z10) {
            return length + 1;
        }
        y yVar4 = this.f23815c;
        if (!z9) {
            yVar4.E(8);
            byte[] bArr2 = (byte[]) yVar4.f7101c;
            bArr2[0] = 0;
            bArr2[1] = 1;
            bArr2[2] = (byte) 0;
            bArr2[3] = (byte) (i10 & 255);
            bArr2[4] = (byte) ((i9 >> 24) & 255);
            bArr2[5] = (byte) ((i9 >> 16) & 255);
            bArr2[6] = (byte) ((i9 >> 8) & 255);
            bArr2[7] = (byte) (i9 & 255);
            uVar.d(8, yVar4);
            return length + 9;
        }
        y yVar5 = rVar.f23921n;
        int iC = yVar5.C();
        yVar5.I(-2);
        int i12 = (iC * 6) + 2;
        if (i10 != 0) {
            yVar4.E(i12);
            byte[] bArr3 = (byte[]) yVar4.f7101c;
            yVar5.h(bArr3, 0, i12);
            int i13 = (((bArr3[2] & 255) << 8) | (bArr3[3] & 255)) + i10;
            bArr3[2] = (byte) ((i13 >> 8) & 255);
            bArr3[3] = (byte) (i13 & 255);
        } else {
            yVar4 = yVar5;
        }
        uVar.d(i12, yVar4);
        return length + 1 + i12;
    }

    public final void d() {
        r rVar = this.f23814b;
        rVar.f23912d = 0;
        rVar.f23923p = 0L;
        rVar.f23924q = false;
        rVar.f23918k = false;
        rVar.f23922o = false;
        rVar.f23920m = null;
        this.f23818f = 0;
        this.f23820h = 0;
        this.f23819g = 0;
        this.f23821i = 0;
        this.f23823l = false;
    }
}
