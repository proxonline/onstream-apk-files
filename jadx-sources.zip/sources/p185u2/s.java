package p185u2;

import p071h3.a;
import p071h3.y;

/* JADX INFO: loaded from: classes.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p f23925a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f23926b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long[] f23927c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f23928d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f23929e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long[] f23930f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int[] f23931g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f23932h;

    public s(p pVar, long[] jArr, int[] iArr, int i9, long[] jArr2, int[] iArr2, long j) {
        a.h(iArr.length == jArr2.length);
        a.h(jArr.length == jArr2.length);
        a.h(iArr2.length == jArr2.length);
        this.f23925a = pVar;
        this.f23927c = jArr;
        this.f23928d = iArr;
        this.f23929e = i9;
        this.f23930f = jArr2;
        this.f23931g = iArr2;
        this.f23932h = j;
        this.f23926b = jArr.length;
        if (iArr2.length > 0) {
            int length = iArr2.length - 1;
            iArr2[length] = iArr2[length] | 536870912;
        }
    }

    public final int a(long j) {
        long[] jArr = this.f23930f;
        for (int iB = y.b(jArr, j, true); iB < jArr.length; iB++) {
            if ((this.f23931g[iB] & 1) != 0) {
                return iB;
            }
        }
        return -1;
    }
}
