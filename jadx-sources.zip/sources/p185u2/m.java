package p185u2;

import E2.n;
import F2.b;
import F2.d;
import F2.f;
import K4.e;
import S8.y;
import android.util.Pair;
import com.google.android.gms.internal.cast.z1;
import java.nio.charset.Charset;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import p052f2.M;
import p052f2.N;
import p052f2.j0;
import p070h2.AbstractC0965a;
import p071h3.a;
import p116m2.j;
import p116m2.k;
import p116m2.l;
import p116m2.o;
import p116m2.q;
import p116m2.r;
import p116m2.s;
import p116m2.u;
import p116m2.v;
import p224z2.c;

/* JADX INFO: loaded from: classes.dex */
public final class m implements j, r {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f23874i;
    public long j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f23875k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public y f23876l;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f23878n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f23879o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f23880p;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public long[][] f23883s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f23884t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public long f23885u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f23886v;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f23873h = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final o f23871f = new o();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayList f23872g = new ArrayList();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final y f23869d = new y(16);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ArrayDeque f23870e = new ArrayDeque();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final y f23866a = new y(a.f18823d);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final y f23867b = new y(4);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final y f23868c = new y(5, false);

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f23877m = -1;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public l f23881q = l.f21264b0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public l[] f23882r = new l[0];

    public m(int i9) {
    }

    @Override // p116m2.j
    public final void a() {
    }

    @Override // p116m2.j
    public final void b(long j, long j9) {
        this.f23870e.clear();
        this.f23875k = 0;
        this.f23877m = -1;
        this.f23878n = 0;
        this.f23879o = 0;
        this.f23880p = 0;
        if (j == 0) {
            if (this.f23873h != 3) {
                this.f23873h = 0;
                this.f23875k = 0;
                return;
            } else {
                o oVar = this.f23871f;
                oVar.f23891a.clear();
                oVar.f23892b = 0;
                this.f23872g.clear();
                return;
            }
        }
        for (l lVar : this.f23882r) {
            s sVar = lVar.f23862b;
            int iE = p071h3.y.e(sVar.f23930f, j9, false);
            while (true) {
                if (iE < 0) {
                    iE = -1;
                    break;
                } else if ((sVar.f23931g[iE] & 1) != 0) {
                    break;
                } else {
                    iE--;
                }
            }
            if (iE == -1) {
                iE = sVar.a(j9);
            }
            lVar.f23865e = iE;
            v vVar = lVar.f23864d;
            if (vVar != null) {
                vVar.f21296b = false;
                vVar.f21297c = 0;
            }
        }
    }

    @Override // p116m2.j
    public final void e(l lVar) {
        this.f23881q = lVar;
    }

    @Override // p116m2.r
    public final boolean f() {
        return true;
    }

    @Override // p116m2.j
    public final boolean g(k kVar) {
        return k.j(kVar, false, false);
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0070  */
    /* JADX WARN: Code duplicated, block: B:36:0x0074  */
    /* JADX WARN: Code duplicated, block: B:38:0x0089  */
    /* JADX WARN: Code duplicated, block: B:41:0x0092 A[LOOP:2: B:37:0x0087->B:41:0x0092, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:44:0x0098  */
    /* JADX WARN: Code duplicated, block: B:46:0x009e  */
    /* JADX WARN: Code duplicated, block: B:47:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:50:0x00ad  */
    /* JADX WARN: Code duplicated, block: B:52:0x00b4  */
    /* JADX WARN: Code duplicated, block: B:55:0x00bc A[LOOP:3: B:51:0x00b2->B:55:0x00bc, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:58:0x00c3  */
    /* JADX WARN: Code duplicated, block: B:60:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:61:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:62:0x00d5  */
    /* JADX WARN: Code duplicated, block: B:63:0x00da  */
    /* JADX WARN: Code duplicated, block: B:67:0x00f2  */
    /* JADX WARN: Code duplicated, block: B:69:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:73:0x00e4 A[EDGE_INSN: B:73:0x00e4->B:65:0x00e4 BREAK  A[LOOP:1: B:32:0x006b->B:64:0x00e0], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:78:0x0095 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:79:0x008f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:80:0x00bf A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:81:0x00ba A[EDGE_INSN: B:81:0x00ba->B:54:0x00ba BREAK  A[LOOP:3: B:51:0x00b2->B:55:0x00bc], SYNTHETIC] */
    @Override // p116m2.r
    public final q h(long j) {
        long j9;
        long j10;
        long j11;
        int i9;
        long jMin;
        l[] lVarArr;
        int i10;
        s sVar;
        long[] jArr;
        int[] iArr;
        long[] jArr2;
        int iE;
        int iA;
        int iE2;
        int iA2;
        l[] lVarArr2 = this.f23882r;
        int length = lVarArr2.length;
        s sVar2 = s.f21288c;
        if (length == 0) {
            return new q(sVar2, sVar2);
        }
        int i11 = this.f23884t;
        boolean z9 = false;
        int i12 = -1;
        long jMin2 = -1;
        if (i11 != -1) {
            s sVar3 = lVarArr2[i11].f23862b;
            long[] jArr3 = sVar3.f23930f;
            int iE3 = p071h3.y.e(jArr3, j, false);
            while (true) {
                if (iE3 < 0) {
                    iE3 = -1;
                    break;
                }
                if ((sVar3.f23931g[iE3] & 1) != 0) {
                    break;
                }
                iE3--;
            }
            if (iE3 == -1) {
                iE3 = sVar3.a(j);
            }
            long[] jArr4 = sVar3.f23927c;
            if (iE3 == -1) {
                return new q(sVar2, sVar2);
            }
            j10 = jArr3[iE3];
            j9 = jArr4[iE3];
            if (j10 < j && iE3 < sVar3.f23926b - 1 && (iA2 = sVar3.a(j)) != -1 && iA2 != iE3) {
                j11 = jArr3[iA2];
                jMin2 = jArr4[iA2];
            }
            i9 = 0;
            jMin = j9;
            while (true) {
                lVarArr = this.f23882r;
                if (i9 < lVarArr.length) {
                    break;
                }
                if (i9 != this.f23884t) {
                    sVar = lVarArr[i9].f23862b;
                    jArr = sVar.f23927c;
                    iArr = sVar.f23931g;
                    jArr2 = sVar.f23930f;
                    iE = p071h3.y.e(jArr2, j10, z9);
                    while (true) {
                        if (iE >= 0) {
                            iA = i12;
                            break;
                        }
                        if ((iArr[iE] & 1) != 0) {
                            iA = iE;
                            break;
                        }
                        iE--;
                    }
                    if (iA == i12) {
                        iA = sVar.a(j10);
                    }
                    if (iA == i12) {
                        jMin = Math.min(jArr[iA], jMin);
                    }
                    if (j11 != -9223372036854775807L) {
                        z9 = false;
                        iE2 = p071h3.y.e(jArr2, j11, false);
                        while (true) {
                            if (iE2 >= 0) {
                                iE2 = -1;
                                break;
                            }
                            if ((iArr[iE2] & 1) != 0) {
                                break;
                            }
                            iE2--;
                        }
                        i10 = -1;
                        if (iE2 == -1) {
                            iE2 = sVar.a(j11);
                        }
                        if (iE2 == -1) {
                            jMin2 = jMin2;
                        } else {
                            jMin2 = Math.min(jArr[iE2], jMin2);
                        }
                    } else {
                        jMin2 = jMin2;
                        z9 = false;
                        i10 = -1;
                    }
                } else {
                    i10 = i12;
                }
                i9++;
                i12 = i10;
            }
            s sVar4 = new s(j10, jMin);
            return j11 == -9223372036854775807L ? new q(sVar4, sVar4) : new q(sVar4, new s(j11, jMin2));
        }
        j9 = Long.MAX_VALUE;
        j10 = j;
        j11 = -9223372036854775807L;
        i9 = 0;
        jMin = j9;
        while (true) {
            lVarArr = this.f23882r;
            if (i9 < lVarArr.length) {
                break;
                break;
            }
            if (i9 != this.f23884t) {
                sVar = lVarArr[i9].f23862b;
                jArr = sVar.f23927c;
                iArr = sVar.f23931g;
                jArr2 = sVar.f23930f;
                iE = p071h3.y.e(jArr2, j10, z9);
                while (true) {
                    if (iE >= 0) {
                        iA = i12;
                        break;
                    }
                    if ((iArr[iE] & 1) != 0) {
                        iA = iE;
                        break;
                    }
                    iE--;
                }
                if (iA == i12) {
                    iA = sVar.a(j10);
                }
                if (iA == i12) {
                    jMin = Math.min(jArr[iA], jMin);
                }
                if (j11 != -9223372036854775807L) {
                    z9 = false;
                    iE2 = p071h3.y.e(jArr2, j11, false);
                    while (true) {
                        if (iE2 >= 0) {
                            iE2 = -1;
                            break;
                        }
                        if ((iArr[iE2] & 1) != 0) {
                            break;
                            break;
                        }
                        iE2--;
                    }
                    i10 = -1;
                    if (iE2 == -1) {
                        iE2 = sVar.a(j11);
                    }
                    if (iE2 == -1) {
                        jMin2 = jMin2;
                    } else {
                        jMin2 = Math.min(jArr[iE2], jMin2);
                    }
                } else {
                    jMin2 = jMin2;
                    z9 = false;
                    i10 = -1;
                }
            } else {
                i10 = i12;
            }
            i9++;
            i12 = i10;
        }
        s sVar5 = new s(j10, jMin);
        if (j11 == -9223372036854775807L) {
        }
    }

    @Override // p116m2.r
    public final long i() {
        return this.f23885u;
    }

    /* JADX WARN: Code duplicated, block: B:332:0x0114 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:383:0x014c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:385:0x00ba A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:388:0x015b A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:45:0x00c1  */
    /* JADX WARN: Code duplicated, block: B:46:0x00c4  */
    /* JADX WARN: Code duplicated, block: B:47:0x00c7  */
    /* JADX WARN: Code duplicated, block: B:48:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:49:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:52:0x00d4  */
    /* JADX WARN: Code duplicated, block: B:53:0x00d6  */
    /* JADX WARN: Code duplicated, block: B:62:0x00ea  */
    /* JADX WARN: Code duplicated, block: B:65:0x0100  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // p116m2.j
    public final int j(k kVar, W5.k kVar2) throws j0 {
        int i9;
        y yVar;
        byte b10;
        char c10;
        int i10;
        ArrayList arrayList;
        List listS;
        int i11;
        List listS2;
        boolean z9;
        a aVar;
        while (true) {
            int i12 = this.f23873h;
            ArrayDeque arrayDeque = this.f23870e;
            y yVar2 = this.f23868c;
            int i13 = 4;
            if (i12 != 0) {
                int i14 = 2;
                if (i12 != 1) {
                    if (i12 == 2) {
                        long position = kVar.getPosition();
                        if (this.f23877m == -1) {
                            int i15 = 0;
                            int i16 = -1;
                            int i17 = -1;
                            boolean z10 = true;
                            boolean z11 = true;
                            long j = Long.MAX_VALUE;
                            long j9 = Long.MAX_VALUE;
                            long j10 = Long.MAX_VALUE;
                            while (true) {
                                l[] lVarArr = this.f23882r;
                                if (i15 >= lVarArr.length) {
                                    break;
                                }
                                l lVar = lVarArr[i15];
                                int i18 = lVar.f23865e;
                                s sVar = lVar.f23862b;
                                if (i18 != sVar.f23926b) {
                                    long j11 = sVar.f23927c[i18];
                                    long[][] jArr = this.f23883s;
                                    int i19 = p071h3.y.f18900a;
                                    long j12 = jArr[i15][i18];
                                    long j13 = j11 - position;
                                    boolean z12 = j13 < 0 || j13 >= 262144;
                                    if ((!z12 && z11) || (z12 == z11 && j13 < j10)) {
                                        z11 = z12;
                                        i17 = i15;
                                        j10 = j13;
                                        j9 = j12;
                                    }
                                    if (j12 < j) {
                                        z10 = z12;
                                        i16 = i15;
                                        j = j12;
                                    }
                                }
                                i15++;
                            }
                            if (j == Long.MAX_VALUE || !z10 || j9 < j + 10485760) {
                                i16 = i17;
                            }
                            this.f23877m = i16;
                            if (i16 == -1) {
                                return -1;
                            }
                        }
                        l lVar2 = this.f23882r[this.f23877m];
                        u uVar = lVar2.f23863c;
                        p pVar = lVar2.f23861a;
                        s sVar2 = lVar2.f23862b;
                        int i20 = lVar2.f23865e;
                        long j14 = sVar2.f23927c[i20];
                        int i21 = sVar2.f23928d[i20];
                        v vVar = lVar2.f23864d;
                        int i22 = 0;
                        long j15 = (j14 - position) + ((long) this.f23878n);
                        if (j15 < 0 || j15 >= 262144) {
                            kVar2.f7882a = j14;
                            return 1;
                        }
                        if (pVar.f23900g == 1) {
                            j15 += 8;
                            i21 -= 8;
                        }
                        kVar.s((int) j15);
                        int i23 = pVar.j;
                        if (i23 == 0) {
                            if ("audio/ac4".equals(pVar.f23899f.f17509l)) {
                                if (this.f23879o == 0) {
                                    AbstractC0965a.e(i21, yVar2);
                                    uVar.c(7, yVar2);
                                    this.f23879o += 7;
                                }
                                i21 += 7;
                            } else if (vVar != null) {
                                vVar.c(kVar);
                            }
                            while (true) {
                                int i24 = this.f23879o;
                                if (i24 >= i21) {
                                    break;
                                }
                                int iE = uVar.e(kVar, i21 - i24, false);
                                this.f23878n += iE;
                                this.f23879o += iE;
                                this.f23880p -= iE;
                            }
                        } else {
                            y yVar3 = this.f23867b;
                            byte[] bArr = (byte[]) yVar3.f7101c;
                            bArr[0] = 0;
                            bArr[1] = 0;
                            bArr[2] = 0;
                            int i25 = 4 - i23;
                            while (this.f23879o < i21) {
                                int i26 = this.f23880p;
                                if (i26 == 0) {
                                    kVar.readFully(bArr, i25, i23);
                                    this.f23878n += i23;
                                    int i27 = i22;
                                    yVar3.H(i27);
                                    int i28 = yVar3.i();
                                    if (i28 < 0) {
                                        throw j0.a("Invalid NAL length", null);
                                    }
                                    this.f23880p = i28;
                                    y yVar4 = this.f23866a;
                                    yVar4.H(i27);
                                    uVar.c(4, yVar4);
                                    this.f23879o += 4;
                                    i21 += i25;
                                    i22 = i27;
                                } else {
                                    int iE2 = uVar.e(kVar, i26, i22);
                                    this.f23878n += iE2;
                                    this.f23879o += iE2;
                                    this.f23880p -= iE2;
                                    i22 = 0;
                                }
                            }
                        }
                        int i29 = i21;
                        long j16 = sVar2.f23930f[i20];
                        int i30 = sVar2.f23931g[i20];
                        if (vVar != null) {
                            vVar.b(uVar, j16, i30, i29, 0, null);
                            if (i20 + 1 == sVar2.f23926b) {
                                vVar.a(uVar, null);
                            }
                        } else {
                            uVar.b(j16, i30, i29, 0, null);
                        }
                        lVar2.f23865e++;
                        this.f23877m = -1;
                        this.f23878n = 0;
                        this.f23879o = 0;
                        this.f23880p = 0;
                        return 0;
                    }
                    if (i12 != 3) {
                        throw new IllegalStateException();
                    }
                    o oVar = this.f23871f;
                    ArrayList arrayList2 = oVar.f23891a;
                    int i31 = oVar.f23892b;
                    if (i31 != 0) {
                        if (i31 != 1) {
                            short s9 = 2816;
                            short s10 = 2192;
                            if (i31 == 2) {
                                long length = kVar.getLength();
                                int i32 = oVar.f23893c - 20;
                                y yVar5 = new y(i32);
                                kVar.readFully((byte[]) yVar5.f7101c, 0, i32);
                                int i33 = 0;
                                while (i33 < i32 / 12) {
                                    yVar5.I(i14);
                                    short sM = yVar5.m();
                                    if (sM != s10 && sM != s9 && sM != 2817 && sM != 2819) {
                                        if (sM != 2820) {
                                            yVar5.I(8);
                                            yVar = yVar5;
                                        }
                                        i33++;
                                        yVar5 = yVar;
                                        s10 = 2192;
                                        i14 = 2;
                                        s9 = 2816;
                                    }
                                    yVar = yVar5;
                                    arrayList2.add(new n((length - ((long) oVar.f23893c)) - ((long) yVar.k()), yVar.k()));
                                    i33++;
                                    yVar5 = yVar;
                                    s10 = 2192;
                                    i14 = 2;
                                    s9 = 2816;
                                }
                                if (arrayList2.isEmpty()) {
                                    kVar2.f7882a = 0L;
                                } else {
                                    oVar.f23892b = 3;
                                    kVar2.f7882a = ((n) arrayList2.get(0)).f23887a;
                                }
                            } else {
                                if (i31 != 3) {
                                    throw new IllegalStateException();
                                }
                                long position2 = kVar.getPosition();
                                int length2 = (int) ((kVar.getLength() - kVar.getPosition()) - ((long) oVar.f23893c));
                                y yVar6 = new y(length2);
                                kVar.readFully((byte[]) yVar6.f7101c, 0, length2);
                                int i34 = 0;
                                while (i34 < arrayList2.size()) {
                                    n nVar = (n) arrayList2.get(i34);
                                    yVar6.H((int) (nVar.f23887a - position2));
                                    yVar6.I(i13);
                                    int iK = yVar6.k();
                                    Charset charset = e.f3790c;
                                    String strV = yVar6.v(iK, charset);
                                    switch (strV.hashCode()) {
                                        case -1711564334:
                                            if (strV.equals("SlowMotion_Data")) {
                                                b10 = 0;
                                            }
                                            switch (b10) {
                                                case 0:
                                                    c10 = 2192;
                                                    break;
                                                case 1:
                                                    c10 = 2819;
                                                    break;
                                                case 2:
                                                    c10 = 2816;
                                                    break;
                                                case 3:
                                                    c10 = 2820;
                                                    break;
                                                case 4:
                                                    c10 = 2817;
                                                    break;
                                                default:
                                                    throw j0.a("Invalid SEF name", null);
                                            }
                                            i10 = nVar.f23888b - (iK + 8);
                                            if (c10 != 2192) {
                                                arrayList = new ArrayList();
                                                listS = o.f23890e.s(yVar6.v(i10, charset));
                                                for (i11 = 0; i11 < listS.size(); i11++) {
                                                    listS2 = o.f23889d.s((CharSequence) listS.get(i11));
                                                    if (listS2.size() == 3) {
                                                        throw j0.a(null, null);
                                                    }
                                                    try {
                                                        arrayList.add(new d(1 << (Integer.parseInt((String) listS2.get(2)) - 1), Long.parseLong((String) listS2.get(0)), Long.parseLong((String) listS2.get(1))));
                                                    } catch (NumberFormatException e9) {
                                                        throw j0.a(null, e9);
                                                    }
                                                }
                                                this.f23872g.add(new F2.e(arrayList));
                                            } else if (c10 != 2816 && c10 != 2817 && c10 != 2819 && c10 != 2820) {
                                                throw new IllegalStateException();
                                            }
                                            i34++;
                                            i13 = 4;
                                            break;
                                        case -1332107749:
                                            if (strV.equals("Super_SlowMotion_Edit_Data")) {
                                                b10 = 1;
                                            }
                                            switch (b10) {
                                                case 0:
                                                    c10 = 2192;
                                                    break;
                                                case 1:
                                                    c10 = 2819;
                                                    break;
                                                case 2:
                                                    c10 = 2816;
                                                    break;
                                                case 3:
                                                    c10 = 2820;
                                                    break;
                                                case 4:
                                                    c10 = 2817;
                                                    break;
                                                default:
                                                    throw j0.a("Invalid SEF name", null);
                                            }
                                            i10 = nVar.f23888b - (iK + 8);
                                            if (c10 != 2192) {
                                                arrayList = new ArrayList();
                                                listS = o.f23890e.s(yVar6.v(i10, charset));
                                                while (i11 < listS.size()) {
                                                    listS2 = o.f23889d.s((CharSequence) listS.get(i11));
                                                    if (listS2.size() == 3) {
                                                        throw j0.a(null, null);
                                                    }
                                                    arrayList.add(new d(1 << (Integer.parseInt((String) listS2.get(2)) - 1), Long.parseLong((String) listS2.get(0)), Long.parseLong((String) listS2.get(1))));
                                                }
                                                this.f23872g.add(new F2.e(arrayList));
                                            } else if (c10 != 2816) {
                                                continue;
                                            }
                                            i34++;
                                            i13 = 4;
                                            break;
                                        case -1251387154:
                                            if (strV.equals("Super_SlowMotion_Data")) {
                                                b10 = 2;
                                            }
                                            switch (b10) {
                                                case 0:
                                                    c10 = 2192;
                                                    break;
                                                case 1:
                                                    c10 = 2819;
                                                    break;
                                                case 2:
                                                    c10 = 2816;
                                                    break;
                                                case 3:
                                                    c10 = 2820;
                                                    break;
                                                case 4:
                                                    c10 = 2817;
                                                    break;
                                                default:
                                                    throw j0.a("Invalid SEF name", null);
                                            }
                                            i10 = nVar.f23888b - (iK + 8);
                                            if (c10 != 2192) {
                                                arrayList = new ArrayList();
                                                listS = o.f23890e.s(yVar6.v(i10, charset));
                                                while (i11 < listS.size()) {
                                                    listS2 = o.f23889d.s((CharSequence) listS.get(i11));
                                                    if (listS2.size() == 3) {
                                                        throw j0.a(null, null);
                                                    }
                                                    arrayList.add(new d(1 << (Integer.parseInt((String) listS2.get(2)) - 1), Long.parseLong((String) listS2.get(0)), Long.parseLong((String) listS2.get(1))));
                                                }
                                                this.f23872g.add(new F2.e(arrayList));
                                            } else if (c10 != 2816) {
                                                continue;
                                            }
                                            i34++;
                                            i13 = 4;
                                            break;
                                        case -830665521:
                                            if (strV.equals("Super_SlowMotion_Deflickering_On")) {
                                                b10 = 3;
                                            }
                                            switch (b10) {
                                                case 0:
                                                    c10 = 2192;
                                                    break;
                                                case 1:
                                                    c10 = 2819;
                                                    break;
                                                case 2:
                                                    c10 = 2816;
                                                    break;
                                                case 3:
                                                    c10 = 2820;
                                                    break;
                                                case 4:
                                                    c10 = 2817;
                                                    break;
                                                default:
                                                    throw j0.a("Invalid SEF name", null);
                                            }
                                            i10 = nVar.f23888b - (iK + 8);
                                            if (c10 != 2192) {
                                                arrayList = new ArrayList();
                                                listS = o.f23890e.s(yVar6.v(i10, charset));
                                                while (i11 < listS.size()) {
                                                    listS2 = o.f23889d.s((CharSequence) listS.get(i11));
                                                    if (listS2.size() == 3) {
                                                        throw j0.a(null, null);
                                                    }
                                                    arrayList.add(new d(1 << (Integer.parseInt((String) listS2.get(2)) - 1), Long.parseLong((String) listS2.get(0)), Long.parseLong((String) listS2.get(1))));
                                                }
                                                this.f23872g.add(new F2.e(arrayList));
                                            } else if (c10 != 2816) {
                                                continue;
                                            }
                                            i34++;
                                            i13 = 4;
                                            break;
                                        case 1760745220:
                                            if (strV.equals("Super_SlowMotion_BGM")) {
                                                b10 = 4;
                                            }
                                            switch (b10) {
                                                case 0:
                                                    c10 = 2192;
                                                    break;
                                                case 1:
                                                    c10 = 2819;
                                                    break;
                                                case 2:
                                                    c10 = 2816;
                                                    break;
                                                case 3:
                                                    c10 = 2820;
                                                    break;
                                                case 4:
                                                    c10 = 2817;
                                                    break;
                                                default:
                                                    throw j0.a("Invalid SEF name", null);
                                            }
                                            i10 = nVar.f23888b - (iK + 8);
                                            if (c10 != 2192) {
                                                arrayList = new ArrayList();
                                                listS = o.f23890e.s(yVar6.v(i10, charset));
                                                while (i11 < listS.size()) {
                                                    listS2 = o.f23889d.s((CharSequence) listS.get(i11));
                                                    if (listS2.size() == 3) {
                                                        throw j0.a(null, null);
                                                    }
                                                    arrayList.add(new d(1 << (Integer.parseInt((String) listS2.get(2)) - 1), Long.parseLong((String) listS2.get(0)), Long.parseLong((String) listS2.get(1))));
                                                }
                                                this.f23872g.add(new F2.e(arrayList));
                                            } else if (c10 != 2816) {
                                                continue;
                                            }
                                            i34++;
                                            i13 = 4;
                                            break;
                                    }
                                    b10 = -1;
                                    switch (b10) {
                                        case 0:
                                            c10 = 2192;
                                            break;
                                        case 1:
                                            c10 = 2819;
                                            break;
                                        case 2:
                                            c10 = 2816;
                                            break;
                                        case 3:
                                            c10 = 2820;
                                            break;
                                        case 4:
                                            c10 = 2817;
                                            break;
                                        default:
                                            throw j0.a("Invalid SEF name", null);
                                    }
                                    i10 = nVar.f23888b - (iK + 8);
                                    if (c10 != 2192) {
                                        arrayList = new ArrayList();
                                        listS = o.f23890e.s(yVar6.v(i10, charset));
                                        while (i11 < listS.size()) {
                                            listS2 = o.f23889d.s((CharSequence) listS.get(i11));
                                            if (listS2.size() == 3) {
                                                throw j0.a(null, null);
                                            }
                                            arrayList.add(new d(1 << (Integer.parseInt((String) listS2.get(2)) - 1), Long.parseLong((String) listS2.get(0)), Long.parseLong((String) listS2.get(1))));
                                        }
                                        this.f23872g.add(new F2.e(arrayList));
                                    } else if (c10 != 2816) {
                                        continue;
                                    }
                                    i34++;
                                    i13 = 4;
                                }
                                kVar2.f7882a = 0L;
                            }
                        } else {
                            y yVar7 = new y(8);
                            kVar.readFully((byte[]) yVar7.f7101c, 0, 8);
                            oVar.f23893c = yVar7.k() + 8;
                            if (yVar7.i() != 1397048916) {
                                kVar2.f7882a = 0L;
                            } else {
                                kVar2.f7882a = kVar.getPosition() - ((long) (oVar.f23893c - 12));
                                oVar.f23892b = 2;
                            }
                        }
                        i9 = 1;
                    } else {
                        long length3 = kVar.getLength();
                        kVar2.f7882a = (length3 == -1 || length3 < 8) ? 0L : length3 - 8;
                        i9 = 1;
                        oVar.f23892b = 1;
                    }
                    if (kVar2.f7882a != 0) {
                        return i9;
                    }
                    this.f23873h = 0;
                    this.f23875k = 0;
                    return i9;
                }
                long j17 = this.j - ((long) this.f23875k);
                long position3 = kVar.getPosition() + j17;
                y yVar8 = this.f23876l;
                if (yVar8 != null) {
                    kVar.readFully((byte[]) yVar8.f7101c, this.f23875k, (int) j17);
                    if (this.f23874i == 1718909296) {
                        yVar8.H(8);
                        int i35 = yVar8.i();
                        int i36 = i35 != 1751476579 ? i35 != 1903435808 ? 0 : 1 : 2;
                        if (i36 == 0) {
                            yVar8.I(4);
                            do {
                                if (yVar8.e() <= 0) {
                                    i36 = 0;
                                    break;
                                }
                                int i37 = yVar8.i();
                                i36 = i37 != 1751476579 ? i37 != 1903435808 ? 0 : 1 : 2;
                            } while (i36 == 0);
                        }
                        this.f23886v = i36;
                    } else if (!arrayDeque.isEmpty()) {
                        ((a) arrayDeque.peek()).f23788d.add(new b(this.f23874i, yVar8));
                    }
                } else {
                    if (j17 < 262144) {
                        kVar.s((int) j17);
                    } else {
                        kVar2.f7882a = kVar.getPosition() + j17;
                        z9 = true;
                    }
                    k(position3);
                    if (z9 && this.f23873h != 2) {
                        return 1;
                    }
                }
                z9 = false;
                k(position3);
                if (z9) {
                    continue;
                }
            } else {
                int i38 = this.f23875k;
                y yVar9 = this.f23869d;
                if (i38 == 0) {
                    if (!kVar.i((byte[]) yVar9.f7101c, 0, 8, true)) {
                        return -1;
                    }
                    this.f23875k = 8;
                    yVar9.H(0);
                    this.j = yVar9.y();
                    this.f23874i = yVar9.i();
                }
                long j18 = this.j;
                if (j18 == 1) {
                    kVar.readFully((byte[]) yVar9.f7101c, 8, 8);
                    this.f23875k += 8;
                    this.j = yVar9.B();
                } else if (j18 == 0) {
                    long length4 = kVar.getLength();
                    if (length4 == -1 && (aVar = (a) arrayDeque.peek()) != null) {
                        length4 = aVar.f23787c;
                    }
                    if (length4 != -1) {
                        this.j = (length4 - kVar.getPosition()) + ((long) this.f23875k);
                    }
                }
                long j19 = this.j;
                int i39 = this.f23875k;
                if (j19 < i39) {
                    throw j0.c("Atom size less than header length (unsupported).");
                }
                int i40 = this.f23874i;
                if (i40 == 1836019574 || i40 == 1953653099 || i40 == 1835297121 || i40 == 1835626086 || i40 == 1937007212 || i40 == 1701082227 || i40 == 1835365473) {
                    long position4 = kVar.getPosition();
                    long j20 = this.j;
                    long j21 = this.f23875k;
                    long j22 = (position4 + j20) - j21;
                    if (j20 != j21 && this.f23874i == 1835365473) {
                        yVar2.E(8);
                        kVar.F((byte[]) yVar2.f7101c, 0, 8);
                        byte[] bArr2 = f.f23805a;
                        int i41 = yVar2.f7099a;
                        yVar2.I(4);
                        if (yVar2.i() != 1751411826) {
                            i41 += 4;
                        }
                        yVar2.H(i41);
                        kVar.s(yVar2.f7099a);
                        kVar.r();
                    }
                    arrayDeque.push(new a(j22, this.f23874i));
                    if (this.j == this.f23875k) {
                        k(j22);
                    } else {
                        this.f23873h = 0;
                        this.f23875k = 0;
                    }
                } else if (i40 == 1835296868 || i40 == 1836476516 || i40 == 1751411826 || i40 == 1937011556 || i40 == 1937011827 || i40 == 1937011571 || i40 == 1668576371 || i40 == 1701606260 || i40 == 1937011555 || i40 == 1937011578 || i40 == 1937013298 || i40 == 1937007471 || i40 == 1668232756 || i40 == 1953196132 || i40 == 1718909296 || i40 == 1969517665 || i40 == 1801812339 || i40 == 1768715124) {
                    a.m(i39 == 8);
                    a.m(this.j <= 2147483647L);
                    y yVar10 = new y((int) this.j);
                    System.arraycopy((byte[]) yVar9.f7101c, 0, (byte[]) yVar10.f7101c, 0, 8);
                    this.f23876l = yVar10;
                    this.f23873h = 1;
                } else {
                    long position5 = kVar.getPosition();
                    long j23 = this.f23875k;
                    long j24 = position5 - j23;
                    if (this.f23874i == 1836086884) {
                        new b(0L, j24, -9223372036854775807L, j24 + j23, this.j - j23);
                    }
                    this.f23876l = null;
                    this.f23873h = 1;
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:236:0x0498  */
    /* JADX WARN: Code duplicated, block: B:274:0x0566 A[PHI: r0
      0x0566: PHI (r0v17 z2.c) = (r0v6 z2.c), (r0v6 z2.c), (r0v12 z2.c), (r0v6 z2.c) binds: [B:276:0x056a, B:277:0x056c, B:377:0x0566, B:272:0x055f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:296:0x05ac  */
    /* JADX WARN: Code duplicated, block: B:43:0x00d8  */
    public final void k(long j) throws j0 {
        ArrayDeque arrayDeque;
        int i9;
        c cVar;
        c cVar2;
        c cVar3;
        c cVar4;
        a aVar;
        c cVar5;
        int i10;
        c cVar6;
        p224z2.b[] bVarArr;
        int i11;
        int i12;
        int i13;
        c cVar7;
        c cVar8;
        F2.a aVar2;
        ArrayDeque arrayDeque2;
        int i14;
        int i15;
        E2.j jVarG;
        String str;
        E2.j jVarH;
        while (true) {
            ArrayDeque arrayDeque3 = this.f23870e;
            if (arrayDeque3.isEmpty() || ((a) arrayDeque3.peek()).f23787c != j) {
                break;
            }
            a aVar3 = (a) arrayDeque3.pop();
            if (aVar3.f6888b == 1836019574) {
                ArrayList arrayList = new ArrayList();
                boolean z9 = this.f23886v == 1;
                o oVar = new o();
                b bVarS = aVar3.s(1969517665);
                int i16 = 1751411826;
                int i17 = 4;
                int i18 = 1768715124;
                int i19 = 1835365473;
                int i20 = 8;
                if (bVarS != null) {
                    byte[] bArr = f.f23805a;
                    y yVar = bVarS.f23790c;
                    yVar.H(8);
                    c cVar9 = null;
                    c cVar10 = null;
                    while (yVar.e() >= i20) {
                        int i21 = yVar.f7099a;
                        int i22 = yVar.i();
                        int i23 = yVar.i();
                        if (i23 == i19) {
                            yVar.H(i21);
                            int i24 = i21 + i22;
                            yVar.I(i20);
                            int i25 = yVar.f7099a;
                            yVar.I(i17);
                            if (yVar.i() != i16) {
                                i25 += 4;
                            }
                            yVar.H(i25);
                            while (true) {
                                int i26 = yVar.f7099a;
                                if (i26 < i24) {
                                    int i27 = yVar.i();
                                    if (yVar.i() == i18) {
                                        yVar.H(i26);
                                        int i28 = i26 + i27;
                                        yVar.I(i20);
                                        ArrayList arrayList2 = new ArrayList();
                                        while (true) {
                                            int i29 = yVar.f7099a;
                                            if (i29 >= i28) {
                                                break;
                                            }
                                            int i30 = yVar.i() + i29;
                                            int i31 = i20;
                                            int i32 = yVar.i();
                                            int i33 = (i32 >> 24) & 255;
                                            ArrayDeque arrayDeque4 = arrayDeque3;
                                            if (i33 == 169 || i33 == 253) {
                                                i15 = i28;
                                                int i34 = 16777215 & i32;
                                                if (i34 == 6516084) {
                                                    jVarG = k.b(i32, yVar);
                                                } else if (i34 == 7233901 || i34 == 7631467) {
                                                    jVarG = k.g(i32, yVar, "TIT2");
                                                } else if (i34 == 6516589 || i34 == 7828084) {
                                                    jVarG = k.g(i32, yVar, "TCOM");
                                                } else if (i34 == 6578553) {
                                                    jVarG = k.g(i32, yVar, "TDRC");
                                                } else if (i34 == 4280916) {
                                                    jVarG = k.g(i32, yVar, "TPE1");
                                                } else if (i34 == 7630703) {
                                                    jVarG = k.g(i32, yVar, "TSSE");
                                                } else if (i34 == 6384738) {
                                                    jVarG = k.g(i32, yVar, "TALB");
                                                } else if (i34 == 7108978) {
                                                    jVarG = k.g(i32, yVar, "USLT");
                                                } else if (i34 == 6776174) {
                                                    jVarG = k.g(i32, yVar, "TCON");
                                                } else if (i34 == 6779504) {
                                                    jVarG = k.g(i32, yVar, "TIT1");
                                                } else {
                                                    a.s("MetadataUtil", "Skipped unknown metadata entry: " + S0.b.d(i32));
                                                    yVar.H(i30);
                                                    jVarG = null;
                                                }
                                                yVar.H(i30);
                                            } else {
                                                if (i32 == 1735291493) {
                                                    try {
                                                        int i35 = k.i(yVar);
                                                        if (i35 > 0) {
                                                            String[] strArr = k.f23859a;
                                                            if (i35 <= 192) {
                                                                str = strArr[i35 - 1];
                                                            } else {
                                                                str = null;
                                                            }
                                                        } else {
                                                            str = null;
                                                        }
                                                        if (str != null) {
                                                            jVarG = new n("TCON", null, str);
                                                        } else {
                                                            a.P("MetadataUtil", "Failed to parse standard genre code");
                                                            jVarG = null;
                                                        }
                                                    } catch (Throwable th) {
                                                        yVar.H(i30);
                                                        throw th;
                                                    }
                                                } else if (i32 == 1684632427) {
                                                    jVarG = k.d(i32, yVar, "TPOS");
                                                } else if (i32 == 1953655662) {
                                                    jVarG = k.d(i32, yVar, "TRCK");
                                                } else {
                                                    if (i32 == 1953329263) {
                                                        jVarH = k.h(i32, "TBPM", yVar, true, false);
                                                    } else if (i32 == 1668311404) {
                                                        jVarH = k.h(i32, "TCMP", yVar, true, true);
                                                    } else if (i32 == 1668249202) {
                                                        jVarG = k.c(yVar);
                                                    } else if (i32 == 1631670868) {
                                                        jVarG = k.g(i32, yVar, "TPE2");
                                                    } else if (i32 == 1936682605) {
                                                        jVarG = k.g(i32, yVar, "TSOT");
                                                    } else if (i32 == 1936679276) {
                                                        jVarG = k.g(i32, yVar, "TSO2");
                                                    } else if (i32 == 1936679282) {
                                                        jVarG = k.g(i32, yVar, "TSOA");
                                                    } else if (i32 == 1936679265) {
                                                        jVarG = k.g(i32, yVar, "TSOP");
                                                    } else if (i32 == 1936679791) {
                                                        jVarG = k.g(i32, yVar, "TSOC");
                                                    } else if (i32 == 1920233063) {
                                                        jVarG = k.h(i32, "ITUNESADVISORY", yVar, false, false);
                                                    } else if (i32 == 1885823344) {
                                                        jVarH = k.h(i32, "ITUNESGAPLESS", yVar, false, true);
                                                    } else if (i32 == 1936683886) {
                                                        jVarG = k.g(i32, yVar, "TVSHOWSORT");
                                                    } else if (i32 == 1953919848) {
                                                        jVarG = k.g(i32, yVar, "TVSHOW");
                                                    } else if (i32 == 757935405) {
                                                        String strS = null;
                                                        String strS2 = null;
                                                        int i36 = -1;
                                                        int i37 = -1;
                                                        while (true) {
                                                            int i38 = yVar.f7099a;
                                                            if (i38 >= i30) {
                                                                break;
                                                            }
                                                            int i39 = yVar.i();
                                                            int i40 = yVar.i();
                                                            int i41 = i28;
                                                            yVar.I(4);
                                                            if (i40 == 1835360622) {
                                                                strS = yVar.s(i39 - 12);
                                                            } else if (i40 == 1851878757) {
                                                                strS2 = yVar.s(i39 - 12);
                                                            } else {
                                                                if (i40 == 1684108385) {
                                                                    i36 = i38;
                                                                    i37 = i39;
                                                                }
                                                                yVar.I(i39 - 12);
                                                            }
                                                            i28 = i41;
                                                        }
                                                        i15 = i28;
                                                        if (strS == null || strS2 == null || i36 == -1) {
                                                            jVarG = null;
                                                        } else {
                                                            yVar.H(i36);
                                                            yVar.I(16);
                                                            jVarG = new E2.k(strS, strS2, yVar.s(i37 - 16));
                                                        }
                                                        yVar.H(i30);
                                                    } else {
                                                        i15 = i28;
                                                        a.s("MetadataUtil", "Skipped unknown metadata entry: " + S0.b.d(i32));
                                                        yVar.H(i30);
                                                        jVarG = null;
                                                    }
                                                    yVar.H(i30);
                                                    jVarG = jVarH;
                                                    i15 = i28;
                                                }
                                                yVar.H(i30);
                                                i15 = i28;
                                            }
                                            if (jVarG != null) {
                                                arrayList2.add(jVarG);
                                            }
                                            i20 = i31;
                                            arrayDeque3 = arrayDeque4;
                                            i28 = i15;
                                        }
                                        arrayDeque2 = arrayDeque3;
                                        i14 = i20;
                                        if (!arrayList2.isEmpty()) {
                                            cVar9 = new c(arrayList2);
                                            break;
                                        }
                                    } else {
                                        yVar.H(i26 + i27);
                                        i18 = 1768715124;
                                    }
                                } else {
                                    arrayDeque2 = arrayDeque3;
                                    i14 = i20;
                                }
                                cVar9 = null;
                                break;
                            }
                        } else {
                            arrayDeque2 = arrayDeque3;
                            i14 = i20;
                            if (i23 == 1936553057) {
                                yVar.H(i21);
                                int i42 = i21 + i22;
                                yVar.I(12);
                                while (true) {
                                    int i43 = yVar.f7099a;
                                    if (i43 < i42) {
                                        int i44 = yVar.i();
                                        if (yVar.i() != 1935766900) {
                                            yVar.H(i43 + i44);
                                        } else if (i44 >= 14) {
                                            yVar.I(5);
                                            int iX = yVar.x();
                                            if (iX == 12 || iX == 13) {
                                                float f3 = iX == 12 ? 240.0f : 120.0f;
                                                yVar.I(1);
                                                cVar10 = new c(new f(yVar.x(), f3));
                                                break;
                                            }
                                        }
                                    }
                                    cVar10 = null;
                                    break;
                                }
                            }
                        }
                        yVar.H(i21 + i22);
                        i20 = i14;
                        arrayDeque3 = arrayDeque2;
                        i19 = 1835365473;
                        i16 = 1751411826;
                        i17 = 4;
                        i18 = 1768715124;
                    }
                    arrayDeque = arrayDeque3;
                    i9 = i20;
                    Pair pairCreate = Pair.create(cVar9, cVar10);
                    cVar2 = (c) pairCreate.first;
                    cVar = (c) pairCreate.second;
                    if (cVar2 != null) {
                        oVar.b(cVar2);
                    }
                    i19 = 1835365473;
                } else {
                    arrayDeque = arrayDeque3;
                    i9 = 8;
                    cVar = null;
                    cVar2 = null;
                }
                a aVarR = aVar3.r(i19);
                if (aVarR != null) {
                    byte[] bArr2 = f.f23805a;
                    b bVarS2 = aVarR.s(1751411826);
                    b bVarS3 = aVarR.s(1801812339);
                    b bVarS4 = aVarR.s(1768715124);
                    if (bVarS2 == null || bVarS3 == null || bVarS4 == null) {
                        cVar3 = cVar;
                        cVar4 = cVar2;
                        aVar = aVar3;
                        cVar5 = null;
                    } else {
                        y yVar2 = bVarS2.f23790c;
                        yVar2.H(16);
                        if (yVar2.i() != 1835299937) {
                            cVar3 = cVar;
                            cVar4 = cVar2;
                            aVar = aVar3;
                        } else {
                            y yVar3 = bVarS3.f23790c;
                            yVar3.H(12);
                            int i45 = yVar3.i();
                            String[] strArr2 = new String[i45];
                            for (int i46 = 0; i46 < i45; i46++) {
                                int i47 = yVar3.i();
                                yVar3.I(4);
                                strArr2[i46] = yVar3.v(i47 - 8, e.f3790c);
                            }
                            y yVar4 = bVarS4.f23790c;
                            int i48 = i9;
                            yVar4.H(i48);
                            ArrayList arrayList3 = new ArrayList();
                            while (yVar4.e() > i48) {
                                int i49 = yVar4.f7099a;
                                int i50 = yVar4.i();
                                int i51 = yVar4.i() - 1;
                                if (i51 < 0 || i51 >= i45) {
                                    cVar7 = cVar;
                                    cVar8 = cVar2;
                                    aVar3 = aVar3;
                                    z1.u("Skipped metadata with unknown key index: ", i51, "AtomParsers");
                                } else {
                                    String str2 = strArr2[i51];
                                    int i52 = i49 + i50;
                                    while (true) {
                                        int i53 = yVar4.f7099a;
                                        if (i53 >= i52) {
                                            cVar7 = cVar;
                                            cVar8 = cVar2;
                                            aVar2 = null;
                                            break;
                                        }
                                        int i54 = yVar4.i();
                                        cVar7 = cVar;
                                        cVar8 = cVar2;
                                        if (yVar4.i() == 1684108385) {
                                            int i55 = yVar4.i();
                                            int i56 = yVar4.i();
                                            int i57 = i54 - 16;
                                            byte[] bArr3 = new byte[i57];
                                            yVar4.h(bArr3, 0, i57);
                                            aVar2 = new F2.a(i56, i55, str2, bArr3);
                                            break;
                                        }
                                        yVar4.H(i53 + i54);
                                        cVar = cVar7;
                                        cVar2 = cVar8;
                                    }
                                    if (aVar2 != null) {
                                        arrayList3.add(aVar2);
                                    }
                                }
                                yVar4.H(i49 + i50);
                                cVar = cVar7;
                                cVar2 = cVar8;
                                aVar3 = aVar3;
                                i48 = 8;
                            }
                            cVar3 = cVar;
                            cVar4 = cVar2;
                            aVar = aVar3;
                            if (!arrayList3.isEmpty()) {
                                cVar5 = new c(arrayList3);
                            }
                        }
                        cVar5 = null;
                    }
                } else {
                    cVar3 = cVar;
                    cVar4 = cVar2;
                    aVar = aVar3;
                    cVar5 = null;
                }
                ArrayList arrayListE = f.e(aVar, oVar, -9223372036854775807L, null, false, z9, new p061g2.e(23));
                int size = arrayListE.size();
                int size2 = -1;
                int i58 = 0;
                long j9 = -9223372036854775807L;
                while (i58 < size) {
                    s sVar = (s) arrayListE.get(i58);
                    int i59 = sVar.f23926b;
                    int i60 = sVar.f23929e;
                    if (i59 == 0) {
                        cVar6 = cVar5;
                        i11 = i58;
                    } else {
                        p pVar = sVar.f23925a;
                        long j10 = pVar.f23898e;
                        N n9 = pVar.f23899f;
                        int i61 = pVar.f23895b;
                        if (j10 == -9223372036854775807L) {
                            j10 = sVar.f23932h;
                        }
                        long jMax = Math.max(j9, j10);
                        l lVar = new l(pVar, sVar, this.f23881q.w(i58, i61));
                        int i62 = "audio/true-hd".equals(n9.f17509l) ? i60 * 16 : i60 + 30;
                        M mA = n9.a();
                        mA.f17478l = i62;
                        if (i61 != 2 || j10 <= 0) {
                            i10 = 1;
                        } else {
                            int i63 = sVar.f23926b;
                            i10 = 1;
                            if (i63 > 1) {
                                mA.f17484r = i63 / (j10 / 1000000.0f);
                            }
                        }
                        if (i61 == i10 && (i12 = oVar.f21280a) != -1 && (i13 = oVar.f21281b) != -1) {
                            mA.f17464A = i12;
                            mA.f17465B = i13;
                        }
                        ArrayList arrayList4 = this.f23872g;
                        c[] cVarArr = {cVar3, arrayList4.isEmpty() ? null : new c(arrayList4)};
                        c cVar11 = new c(new p224z2.b[0]);
                        if (i61 != 1) {
                            if (i61 != 2 || cVar5 == null) {
                                cVar6 = cVar5;
                                break;
                            }
                            int i64 = 0;
                            while (true) {
                                p224z2.b[] bVarArr2 = cVar5.f26443a;
                                if (i64 >= bVarArr2.length) {
                                    cVar6 = cVar5;
                                    break;
                                }
                                p224z2.b bVar = bVarArr2[i64];
                                if (bVar instanceof F2.a) {
                                    F2.a aVar4 = (F2.a) bVar;
                                    cVar6 = cVar5;
                                    if ("com.android.capture.fps".equals(aVar4.f1577a)) {
                                        cVar11 = new c(aVar4);
                                        break;
                                    }
                                } else {
                                    cVar6 = cVar5;
                                }
                                i64++;
                                cVar5 = cVar6;
                            }
                        } else if (cVar4 == null) {
                            cVar6 = cVar5;
                            break;
                        } else {
                            cVar6 = cVar5;
                            cVar11 = cVar4;
                        }
                        int i65 = 0;
                        while (true) {
                            bVarArr = cVar11.f26443a;
                            if (i65 >= 2) {
                                break;
                            }
                            c cVar12 = cVarArr[i65];
                            if (cVar12 != null) {
                                p224z2.b[] bVarArr3 = cVar12.f26443a;
                                if (bVarArr3.length != 0) {
                                    long j11 = cVar11.f26444b;
                                    int i66 = p071h3.y.f18900a;
                                    Object[] objArrCopyOf = Arrays.copyOf(bVarArr, bVarArr.length + bVarArr3.length);
                                    System.arraycopy(bVarArr3, 0, objArrCopyOf, bVarArr.length, bVarArr3.length);
                                    cVar11 = new c(j11, (p224z2.b[]) objArrCopyOf);
                                }
                            }
                            i65++;
                            i58 = i58;
                            jMax = jMax;
                        }
                        i11 = i58;
                        long j12 = jMax;
                        if (bVarArr.length > 0) {
                            mA.f17476i = cVar11;
                        }
                        z1.s(mA, lVar.f23863c);
                        if (i61 == 2 && size2 == -1) {
                            size2 = arrayList.size();
                        }
                        arrayList.add(lVar);
                        j9 = j12;
                    }
                    i58 = i11 + 1;
                    arrayListE = arrayListE;
                    size = size;
                    cVar5 = cVar6;
                }
                long j13 = 0;
                this.f23884t = size2;
                this.f23885u = j9;
                l[] lVarArr = (l[]) arrayList.toArray(new l[0]);
                this.f23882r = lVarArr;
                long[][] jArr = new long[lVarArr.length][];
                int[] iArr = new int[lVarArr.length];
                long[] jArr2 = new long[lVarArr.length];
                boolean[] zArr = new boolean[lVarArr.length];
                for (int i67 = 0; i67 < lVarArr.length; i67++) {
                    jArr[i67] = new long[lVarArr[i67].f23862b.f23926b];
                    jArr2[i67] = lVarArr[i67].f23862b.f23930f[0];
                }
                int i68 = 0;
                while (i68 < lVarArr.length) {
                    long j14 = Long.MAX_VALUE;
                    int i69 = -1;
                    for (int i70 = 0; i70 < lVarArr.length; i70++) {
                        if (!zArr[i70]) {
                            long j15 = jArr2[i70];
                            if (j15 <= j14) {
                                i69 = i70;
                                j14 = j15;
                            }
                        }
                    }
                    int i71 = iArr[i69];
                    long[] jArr3 = jArr[i69];
                    jArr3[i71] = j13;
                    s sVar2 = lVarArr[i69].f23862b;
                    j13 += (long) sVar2.f23928d[i71];
                    int i72 = i71 + 1;
                    iArr[i69] = i72;
                    if (i72 < jArr3.length) {
                        jArr2[i69] = sVar2.f23930f[i72];
                    } else {
                        zArr[i69] = true;
                        i68++;
                    }
                }
                this.f23883s = jArr;
                this.f23881q.g();
                this.f23881q.f(this);
                arrayDeque.clear();
                this.f23873h = 2;
            } else if (!arrayDeque3.isEmpty()) {
                ((a) arrayDeque3.peek()).f23789e.add(aVar3);
            }
        }
        if (this.f23873h != 2) {
            this.f23873h = 0;
            this.f23875k = 0;
        }
    }
}
