package p185u2;

import S0.b;
import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class a extends b {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f23787c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f23788d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ArrayList f23789e;

    public a(long j, int i9) {
        super(i9, 3);
        this.f23787c = j;
        this.f23788d = new ArrayList();
        this.f23789e = new ArrayList();
    }

    public final a r(int i9) {
        ArrayList arrayList = this.f23789e;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            a aVar = (a) arrayList.get(i10);
            if (aVar.f6888b == i9) {
                return aVar;
            }
        }
        return null;
    }

    public final b s(int i9) {
        ArrayList arrayList = this.f23788d;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            b bVar = (b) arrayList.get(i10);
            if (bVar.f6888b == i9) {
                return bVar;
            }
        }
        return null;
    }

    @Override // S0.b
    public final String toString() {
        return b.d(this.f6888b) + " leaves: " + Arrays.toString(this.f23788d.toArray()) + " containers: " + Arrays.toString(this.f23789e.toArray());
    }
}
