package p185u2;

import S8.y;
import com.google.android.gms.internal.measurement.AbstractC0837z1;
import p052f2.j0;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f23791a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f23792b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f23793c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f23794d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f23795e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final y f23796f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final y f23797g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f23798h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f23799i;

    public c(y yVar, y yVar2, boolean z9) throws j0 {
        this.f23797g = yVar;
        this.f23796f = yVar2;
        this.f23795e = z9;
        yVar2.H(12);
        this.f23791a = yVar2.A();
        yVar.H(12);
        this.f23799i = yVar.A();
        AbstractC0837z1.i("first_chunk must be 1", yVar.i() == 1);
        this.f23792b = -1;
    }

    public final boolean a() {
        int i9 = this.f23792b + 1;
        this.f23792b = i9;
        if (i9 == this.f23791a) {
            return false;
        }
        boolean z9 = this.f23795e;
        y yVar = this.f23796f;
        this.f23794d = z9 ? yVar.B() : yVar.y();
        if (this.f23792b == this.f23798h) {
            y yVar2 = this.f23797g;
            this.f23793c = yVar2.A();
            yVar2.I(4);
            int i10 = this.f23799i - 1;
            this.f23799i = i10;
            this.f23798h = i10 > 0 ? yVar2.A() - 1 : -1;
        }
        return true;
    }
}
