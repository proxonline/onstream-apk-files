package p041e0;

/* JADX INFO: loaded from: classes.dex */
public interface m {
    Object a();

    boolean b(CharSequence charSequence, int i9, int i10, u uVar);
}
