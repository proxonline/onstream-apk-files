package p041e0;

import android.content.pm.PackageManager;
import android.content.pm.Signature;
import p033d2.b;

/* JADX INFO: loaded from: classes.dex */
public final class c extends b {
    @Override // p033d2.b
    public final Signature[] u(PackageManager packageManager, String str) {
        return packageManager.getPackageInfo(str, 64).signatures;
    }
}
