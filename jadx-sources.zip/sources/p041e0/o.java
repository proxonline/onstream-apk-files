package p041e0;

import Y4.i;
import android.graphics.Bitmap;
import android.media.VolumeProvider;
import android.os.Build;
import android.util.SparseBooleanArray;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import p050f0.a;
import p222z0.b;
import p222z0.c;
import p222z0.e;
import p222z0.f;
import p222z0.g;

/* JADX INFO: loaded from: classes.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16837a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16838b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16839c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f16840d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f16841e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f16842f;

    public o(i iVar, int i9, int i10, int i11, String str) {
        this.f16842f = iVar;
        this.f16837a = i9;
        this.f16838b = i10;
        this.f16839c = i11;
        this.f16840d = str;
    }

    public o(Bitmap bitmap) {
        ArrayList arrayList = new ArrayList();
        this.f16841e = arrayList;
        this.f16837a = 16;
        this.f16838b = 12544;
        this.f16839c = -1;
        ArrayList arrayList2 = new ArrayList();
        this.f16842f = arrayList2;
        if (bitmap.isRecycled()) {
            throw new IllegalArgumentException("Bitmap is not valid");
        }
        arrayList2.add(f.f26420e);
        this.f16840d = bitmap;
        arrayList.add(g.f26425d);
        arrayList.add(g.f26426e);
        arrayList.add(g.f26427f);
        arrayList.add(g.f26428g);
        arrayList.add(g.f26429h);
        arrayList.add(g.f26430i);
    }

    public o(r rVar) {
        this.f16837a = 1;
        this.f16840d = rVar;
        this.f16841e = rVar;
    }

    /* JADX WARN: Code duplicated, block: B:76:0x0177  */
    public f a() {
        int iMax;
        ArrayList arrayList;
        ArrayList arrayList2 = (ArrayList) this.f16842f;
        Bitmap bitmap = (Bitmap) this.f16840d;
        if (bitmap == null) {
            throw new AssertionError();
        }
        int i9 = this.f16839c;
        int i10 = this.f16838b;
        double dSqrt = -1.0d;
        if (i10 > 0) {
            int height = bitmap.getHeight() * bitmap.getWidth();
            if (height > i10) {
                dSqrt = Math.sqrt(((double) i10) / ((double) height));
            }
        } else if (i9 > 0 && (iMax = Math.max(bitmap.getWidth(), bitmap.getHeight())) > i9) {
            dSqrt = ((double) i9) / ((double) iMax);
        }
        int i11 = 0;
        Bitmap bitmapCreateScaledBitmap = dSqrt <= 0.0d ? bitmap : Bitmap.createScaledBitmap(bitmap, (int) Math.ceil(((double) bitmap.getWidth()) * dSqrt), (int) Math.ceil(((double) bitmap.getHeight()) * dSqrt), false);
        int width = bitmapCreateScaledBitmap.getWidth();
        int height2 = bitmapCreateScaledBitmap.getHeight();
        int[] iArr = new int[width * height2];
        bitmapCreateScaledBitmap.getPixels(iArr, 0, width, 0, 0, width, height2);
        b bVar = new b(iArr, this.f16837a, arrayList2.isEmpty() ? null : (c[]) arrayList2.toArray(new c[arrayList2.size()]));
        if (bitmapCreateScaledBitmap != bitmap) {
            bitmapCreateScaledBitmap.recycle();
        }
        ArrayList arrayList3 = (ArrayList) this.f16841e;
        f fVar = new f(bVar.f26406c, arrayList3);
        int size = arrayList3.size();
        int i12 = 0;
        while (true) {
            SparseBooleanArray sparseBooleanArray = fVar.f26423c;
            if (i12 >= size) {
                sparseBooleanArray.clear();
                return fVar;
            }
            g gVar = (g) arrayList3.get(i12);
            float[] fArr = gVar.f26433c;
            float[] fArr2 = gVar.f26431a;
            int length = fArr.length;
            float f3 = 0.0f;
            float f9 = 0.0f;
            for (int i13 = i11; i13 < length; i13++) {
                float f10 = fArr[i13];
                if (f10 > 0.0f) {
                    f9 += f10;
                }
            }
            if (f9 != 0.0f) {
                int length2 = fArr.length;
                for (int i14 = i11; i14 < length2; i14++) {
                    float f11 = fArr[i14];
                    if (f11 > 0.0f) {
                        fArr[i14] = f11 / f9;
                    }
                }
            }
            List list = fVar.f26421a;
            int size2 = list.size();
            int i15 = i11;
            float f12 = 0.0f;
            e eVar = null;
            while (i15 < size2) {
                e eVar2 = (e) list.get(i15);
                float[] fArrB = eVar2.b();
                float f13 = fArrB[1];
                float f14 = f3;
                float[] fArr3 = gVar.f26432b;
                if (f13 < fArr2[i15] || f13 > fArr2[2]) {
                    arrayList = arrayList3;
                } else {
                    float f15 = fArrB[2];
                    if (f15 < fArr3[i15] || f15 > fArr3[2] || sparseBooleanArray.get(eVar2.f26414d)) {
                        arrayList = arrayList3;
                    } else {
                        float[] fArrB2 = eVar2.b();
                        e eVar3 = fVar.f26424d;
                        int i16 = eVar3 != null ? eVar3.f26415e : 1;
                        arrayList = arrayList3;
                        float[] fArr4 = gVar.f26433c;
                        float f16 = fArr4[i15];
                        float fAbs = f16 > f14 ? (1.0f - Math.abs(fArrB2[1] - fArr2[1])) * f16 : f14;
                        float f17 = fArr4[1];
                        float fAbs2 = f17 > f14 ? (1.0f - Math.abs(fArrB2[2] - fArr3[1])) * f17 : f14;
                        float f18 = fArr4[2];
                        float f19 = fAbs + fAbs2 + (f18 > f14 ? (eVar2.f26415e / i16) * f18 : f14);
                        if (eVar == null || f19 > f12) {
                            eVar = eVar2;
                            f12 = f19;
                        }
                    }
                }
                i15++;
                arrayList3 = arrayList;
                f3 = f14;
            }
            ArrayList arrayList4 = arrayList3;
            if (eVar != null) {
                sparseBooleanArray.append(eVar.f26414d, true);
            }
            fVar.f26422b.put(gVar, eVar);
            i12++;
            i11 = i15;
            arrayList3 = arrayList4;
        }
    }

    public VolumeProvider b() {
        o oVar;
        if (((VolumeProvider) this.f16841e) != null) {
            oVar = this;
        } else if (Build.VERSION.SDK_INT >= 30) {
            oVar = this;
            oVar.f16841e = new p169s0.e(oVar, this.f16837a, this.f16838b, this.f16839c, (String) this.f16840d);
        } else {
            oVar = this;
            oVar.f16841e = new p169s0.f(this, oVar.f16837a, oVar.f16838b, oVar.f16839c);
        }
        return (VolumeProvider) oVar.f16841e;
    }

    public void c() {
        this.f16837a = 1;
        this.f16841e = (r) this.f16840d;
        this.f16839c = 0;
    }

    public boolean d() {
        a aVarB = ((r) this.f16841e).f16853b.b();
        int iA = aVarB.a(6);
        return !(iA == 0 || ((ByteBuffer) aVarB.f5827d).get(iA + aVarB.f5824a) == 0) || this.f16838b == 65039;
    }
}
