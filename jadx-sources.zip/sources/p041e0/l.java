package p041e0;

import T8.d;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public abstract class l {
    public static Set<int[]> a() {
        return d.j();
    }
}
