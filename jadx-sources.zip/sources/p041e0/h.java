package p041e0;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {
    public abstract void a();
}
