package p041e0;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class w {
}
