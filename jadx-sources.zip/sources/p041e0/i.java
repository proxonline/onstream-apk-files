package p041e0;

import K3.h;

/* JADX INFO: loaded from: classes.dex */
public interface i {
    void a(h hVar);
}
