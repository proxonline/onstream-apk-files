package p041e0;

/* JADX INFO: loaded from: classes.dex */
public interface g {
}
