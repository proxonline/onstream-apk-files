package p041e0;

import java.nio.ByteBuffer;
import p050f0.a;
import p050f0.b;
import p125n1.g;

/* JADX INFO: loaded from: classes.dex */
public final class u {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ThreadLocal f16858d = new ThreadLocal();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f16859a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g f16860b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile int f16861c = 0;

    public u(g gVar, int i9) {
        this.f16860b = gVar;
        this.f16859a = i9;
    }

    public final int a(int i9) {
        a aVarB = b();
        int iA = aVarB.a(16);
        if (iA == 0) {
            return 0;
        }
        ByteBuffer byteBuffer = (ByteBuffer) aVarB.f5827d;
        int i10 = iA + aVarB.f5824a;
        return byteBuffer.getInt((i9 * 4) + byteBuffer.getInt(i10) + i10 + 4);
    }

    public final a b() {
        ThreadLocal threadLocal = f16858d;
        a aVar = (a) threadLocal.get();
        if (aVar == null) {
            aVar = new a();
            threadLocal.set(aVar);
        }
        b bVar = (b) this.f16860b.f21577b;
        int iA = bVar.a(6);
        if (iA != 0) {
            int i9 = iA + bVar.f5824a;
            int i10 = (this.f16859a * 4) + ((ByteBuffer) bVar.f5827d).getInt(i9) + i9 + 4;
            int i11 = ((ByteBuffer) bVar.f5827d).getInt(i10) + i10;
            ByteBuffer byteBuffer = (ByteBuffer) bVar.f5827d;
            aVar.f5827d = byteBuffer;
            if (byteBuffer != null) {
                aVar.f5824a = i11;
                int i12 = i11 - byteBuffer.getInt(i11);
                aVar.f5825b = i12;
                aVar.f5826c = ((ByteBuffer) aVar.f5827d).getShort(i12);
                return aVar;
            }
            aVar.f5824a = 0;
            aVar.f5825b = 0;
            aVar.f5826c = 0;
        }
        return aVar;
    }

    public final String toString() {
        int i9;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", id:");
        a aVarB = b();
        int iA = aVarB.a(4);
        sb.append(Integer.toHexString(iA != 0 ? ((ByteBuffer) aVarB.f5827d).getInt(iA + aVarB.f5824a) : 0));
        sb.append(", codepoints:");
        a aVarB2 = b();
        int iA2 = aVarB2.a(16);
        if (iA2 != 0) {
            int i10 = iA2 + aVarB2.f5824a;
            i9 = ((ByteBuffer) aVarB2.f5827d).getInt(((ByteBuffer) aVarB2.f5827d).getInt(i10) + i10);
        } else {
            i9 = 0;
        }
        for (int i11 = 0; i11 < i9; i11++) {
            sb.append(Integer.toHexString(a(i11)));
            sb.append(" ");
        }
        return sb.toString();
    }
}
