package p041e0;

import android.util.SparseArray;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SparseArray f16852a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public u f16853b;

    public r(int i9) {
        this.f16852a = new SparseArray(i9);
    }

    public final void a(u uVar, int i9, int i10) {
        int iA = uVar.a(i9);
        SparseArray sparseArray = this.f16852a;
        r rVar = sparseArray == null ? null : (r) sparseArray.get(iA);
        if (rVar == null) {
            rVar = new r(1);
            sparseArray.put(uVar.a(i9), rVar);
        }
        if (i10 > i9) {
            rVar.a(uVar, i9 + 1, i10);
        } else {
            rVar.f16853b = uVar;
        }
    }
}
