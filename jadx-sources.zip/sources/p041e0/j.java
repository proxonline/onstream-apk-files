package p041e0;

import E4.c;
import Y4.i;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import com.google.android.gms.internal.measurement.I1;
import com.google.android.material.appbar.h;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import p036d5.k;
import p158r.f;

/* JADX INFO: loaded from: classes.dex */
public final class j {
    public static final Object j = new Object();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static volatile j f16824k;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ReentrantReadWriteLock f16825a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final f f16826b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile int f16827c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Handler f16828d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final f f16829e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final i f16830f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final k f16831g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f16832h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final d f16833i;

    public j(q qVar) {
        ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();
        this.f16825a = reentrantReadWriteLock;
        this.f16827c = 3;
        i iVar = (i) qVar.f1949b;
        this.f16830f = iVar;
        int i9 = qVar.f1948a;
        this.f16832h = i9;
        this.f16833i = (d) qVar.f1950c;
        this.f16828d = new Handler(Looper.getMainLooper());
        this.f16826b = new f(0);
        this.f16831g = new k(4);
        f fVar = new f(this);
        this.f16829e = fVar;
        reentrantReadWriteLock.writeLock().lock();
        if (i9 == 0) {
            try {
                this.f16827c = 0;
            } catch (Throwable th) {
                this.f16825a.writeLock().unlock();
                throw th;
            }
        }
        reentrantReadWriteLock.writeLock().unlock();
        if (b() == 0) {
            try {
                iVar.a(new e(fVar));
            } catch (Throwable th2) {
                d(th2);
            }
        }
    }

    public static j a() {
        j jVar;
        synchronized (j) {
            try {
                jVar = f16824k;
                if (!(jVar != null)) {
                    throw new IllegalStateException("EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return jVar;
    }

    public final int b() {
        this.f16825a.readLock().lock();
        try {
            return this.f16827c;
        } finally {
            this.f16825a.readLock().unlock();
        }
    }

    public final void c() {
        if (!(this.f16832h == 1)) {
            throw new IllegalStateException("Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        }
        if (b() == 1) {
            return;
        }
        this.f16825a.writeLock().lock();
        try {
            if (this.f16827c == 0) {
                this.f16825a.writeLock().unlock();
                return;
            }
            this.f16827c = 0;
            this.f16825a.writeLock().unlock();
            f fVar = this.f16829e;
            j jVar = (j) fVar.f16823c;
            try {
                jVar.f16830f.a(new e(fVar));
            } catch (Throwable th) {
                jVar.d(th);
            }
        } catch (Throwable th2) {
            this.f16825a.writeLock().unlock();
            throw th2;
        }
    }

    public final void d(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f16825a.writeLock().lock();
        try {
            this.f16827c = 2;
            arrayList.addAll(this.f16826b);
            this.f16826b.clear();
            this.f16825a.writeLock().unlock();
            this.f16828d.post(new c(arrayList, this.f16827c, th));
        } catch (Throwable th2) {
            this.f16825a.writeLock().unlock();
            throw th2;
        }
    }

    /* JADX WARN: Code duplicated, block: B:103:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:105:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:52:0x00a2 A[Catch: all -> 0x0085, TryCatch #0 {all -> 0x0085, blocks: (B:32:0x005d, B:35:0x0062, B:37:0x0066, B:39:0x0073, B:46:0x0092, B:48:0x009c, B:50:0x009f, B:52:0x00a2, B:54:0x00b2, B:55:0x00b5), top: B:94:0x005d }] */
    /* JADX WARN: Code duplicated, block: B:54:0x00b2 A[Catch: all -> 0x0085, TryCatch #0 {all -> 0x0085, blocks: (B:32:0x005d, B:35:0x0062, B:37:0x0066, B:39:0x0073, B:46:0x0092, B:48:0x009c, B:50:0x009f, B:52:0x00a2, B:54:0x00b2, B:55:0x00b5), top: B:94:0x005d }] */
    /* JADX WARN: Code duplicated, block: B:61:0x00ca  */
    /* JADX WARN: Code duplicated, block: B:85:0x0107  */
    public final CharSequence e(CharSequence charSequence, int i9, int i10) throws Throwable {
        Throwable th;
        CharSequence charSequence2;
        int i11;
        int i12;
        v[] vVarArr;
        int spanStart;
        if (!(b() == 1)) {
            throw new IllegalStateException("Not initialized yet");
        }
        if (i9 < 0) {
            throw new IllegalArgumentException("start cannot be negative");
        }
        if (i10 < 0) {
            throw new IllegalArgumentException("end cannot be negative");
        }
        I1.d("start should be <= than end", i9 <= i10);
        z zVar = null;
        if (charSequence == null) {
            return null;
        }
        I1.d("start should be < than charSequence length", i9 <= charSequence.length());
        I1.d("end should be < than charSequence length", i10 <= charSequence.length());
        if (charSequence.length() == 0 || i9 == i10) {
            return charSequence;
        }
        i iVar = (i) this.f16829e.f16821a;
        iVar.getClass();
        boolean z9 = charSequence instanceof t;
        if (z9) {
            ((t) charSequence).a();
        }
        if (z9) {
            zVar = new z((Spannable) charSequence);
            if (zVar != null) {
                for (v vVar : vVarArr) {
                    spanStart = zVar.f16868b.getSpanStart(vVar);
                    int spanEnd = zVar.f16868b.getSpanEnd(vVar);
                    if (spanStart != i10) {
                        zVar.removeSpan(vVar);
                    }
                    i9 = Math.min(spanStart, i9);
                    i10 = Math.max(spanEnd, i10);
                }
            }
            i11 = i9;
            i12 = i10;
            if (i11 != i12) {
                charSequence2 = charSequence;
                if (!z9) {
                    return charSequence2;
                }
            } else {
                charSequence2 = charSequence;
                if (!z9) {
                    return charSequence2;
                }
            }
            ((t) charSequence2).b();
            return charSequence2;
        }
        try {
            if (charSequence instanceof Spannable) {
                try {
                    zVar = new z((Spannable) charSequence);
                } catch (Throwable th2) {
                    th = th2;
                    charSequence2 = charSequence;
                    th = th;
                    if (!z9) {
                        throw th;
                    }
                    ((t) charSequence2).b();
                    throw th;
                }
            } else if ((charSequence instanceof Spanned) && ((Spanned) charSequence).nextSpanTransition(i9 - 1, i10 + 1, v.class) <= i10) {
                zVar = new z();
                zVar.f16867a = false;
                zVar.f16868b = new SpannableString(charSequence);
            }
            if (zVar != null && (vVarArr = (v[]) zVar.f16868b.getSpans(i9, i10, v.class)) != null && vVarArr.length > 0) {
                while (i < r5) {
                    spanStart = zVar.f16868b.getSpanStart(vVar);
                    int spanEnd2 = zVar.f16868b.getSpanEnd(vVar);
                    if (spanStart != i10) {
                        zVar.removeSpan(vVar);
                    }
                    i9 = Math.min(spanStart, i9);
                    i10 = Math.max(spanEnd2, i10);
                }
            }
            i11 = i9;
            i12 = i10;
            if (i11 != i12 || i11 >= charSequence.length()) {
                charSequence2 = charSequence;
                if (!z9) {
                    return charSequence2;
                }
            } else {
                try {
                    charSequence2 = charSequence;
                    try {
                        z zVar2 = (z) iVar.C(charSequence2, i11, i12, Integer.MAX_VALUE, false, new h(zVar, 1, (k) iVar.f9377b));
                        if (zVar2 != null) {
                            Spannable spannable = zVar2.f16868b;
                            if (z9) {
                                ((t) charSequence2).b();
                            }
                            return spannable;
                        }
                        if (!z9) {
                            return charSequence2;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        th = th;
                        if (!z9) {
                            throw th;
                        }
                        ((t) charSequence2).b();
                        throw th;
                    }
                } catch (Throwable th4) {
                    charSequence2 = charSequence;
                    th = th4;
                }
            }
            ((t) charSequence2).b();
            return charSequence2;
        } catch (Throwable th5) {
            th = th5;
            charSequence2 = charSequence;
        }
        if (!z9) {
            throw th;
        }
        ((t) charSequence2).b();
        throw th;
    }

    public final void f(h hVar) {
        I1.f(hVar, "initCallback cannot be null");
        this.f16825a.writeLock().lock();
        try {
            if (this.f16827c == 1 || this.f16827c == 2) {
                this.f16828d.post(new c(Arrays.asList(hVar), this.f16827c, (Throwable) null));
            } else {
                this.f16826b.add(hVar);
            }
        } finally {
            this.f16825a.writeLock().unlock();
        }
    }
}
