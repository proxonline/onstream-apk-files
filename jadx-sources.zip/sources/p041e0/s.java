package p041e0;

import android.os.Build;
import android.text.Editable;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.TextWatcher;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public final class s implements TextWatcher, SpanWatcher {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f16854a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final AtomicInteger f16855b = new AtomicInteger(0);

    public s(Object obj) {
        this.f16854a = obj;
    }

    @Override // android.text.TextWatcher
    public final void afterTextChanged(Editable editable) {
        ((TextWatcher) this.f16854a).afterTextChanged(editable);
    }

    @Override // android.text.TextWatcher
    public final void beforeTextChanged(CharSequence charSequence, int i9, int i10, int i11) {
        ((TextWatcher) this.f16854a).beforeTextChanged(charSequence, i9, i10, i11);
    }

    @Override // android.text.SpanWatcher
    public final void onSpanAdded(Spannable spannable, Object obj, int i9, int i10) {
        if (this.f16855b.get() <= 0 || !(obj instanceof v)) {
            ((SpanWatcher) this.f16854a).onSpanAdded(spannable, obj, i9, i10);
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x001c A[PHI: r11
      0x001c: PHI (r11v1 int) = (r11v0 int), (r11v3 int) binds: [B:8:0x0011, B:12:0x0017] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.text.SpanWatcher
    public final void onSpanChanged(Spannable spannable, Object obj, int i9, int i10, int i11, int i12) {
        int i13;
        int i14;
        if (this.f16855b.get() <= 0 || !(obj instanceof v)) {
            if (Build.VERSION.SDK_INT >= 28) {
                i13 = i9;
                i14 = i11;
            } else {
                if (i9 > i10) {
                    i9 = 0;
                }
                if (i11 > i12) {
                    i13 = i9;
                    i14 = 0;
                } else {
                    i13 = i9;
                    i14 = i11;
                }
            }
            ((SpanWatcher) this.f16854a).onSpanChanged(spannable, obj, i13, i10, i14, i12);
        }
    }

    @Override // android.text.SpanWatcher
    public final void onSpanRemoved(Spannable spannable, Object obj, int i9, int i10) {
        if (this.f16855b.get() <= 0 || !(obj instanceof v)) {
            ((SpanWatcher) this.f16854a).onSpanRemoved(spannable, obj, i9, i10);
        }
    }

    @Override // android.text.TextWatcher
    public final void onTextChanged(CharSequence charSequence, int i9, int i10, int i11) {
        ((TextWatcher) this.f16854a).onTextChanged(charSequence, i9, i10, i11);
    }
}
