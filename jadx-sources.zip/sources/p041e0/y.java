package p041e0;

import G3.d;
import p036d5.k;

/* JADX INFO: loaded from: classes.dex */
public final class y extends k {
    @Override // p036d5.k
    public final boolean D(CharSequence charSequence) {
        return d.z(charSequence);
    }
}
