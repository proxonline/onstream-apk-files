package p041e0;

import android.text.TextPaint;

/* JADX INFO: loaded from: classes.dex */
public final class d implements g {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final ThreadLocal f16818b = new ThreadLocal();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextPaint f16819a;

    public d() {
        TextPaint textPaint = new TextPaint();
        this.f16819a = textPaint;
        textPaint.setTextSize(10.0f);
    }
}
