package p041e0;

import java.util.ArrayList;
import p036d5.k;
import p119m5.n;
import p138o5.a;
import p164r5.b;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public volatile Object f16821a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile Object f16822b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f16823c;

    public f(j jVar) {
        this.f16823c = jVar;
    }

    public f(n nVar) {
        b bVar = new b();
        k kVar = new k(19);
        this.f16822b = bVar;
        this.f16823c = new ArrayList();
        this.f16821a = kVar;
        nVar.a(new a(this));
    }
}
