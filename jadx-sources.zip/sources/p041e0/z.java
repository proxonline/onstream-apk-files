package p041e0;

import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import j$.util.stream.IntStream;
import p036d5.k;

/* JADX INFO: loaded from: classes.dex */
public final class z implements Spannable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f16867a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Spannable f16868b;

    public z(Spannable spannable) {
        this.f16868b = spannable;
    }

    public final void a() {
        Spannable spannable = this.f16868b;
        if (!this.f16867a) {
            if ((Build.VERSION.SDK_INT < 28 ? new k(5) : new y(5)).D(spannable)) {
                this.f16868b = new SpannableString(spannable);
            }
        }
        this.f16867a = true;
    }

    @Override // java.lang.CharSequence
    public final char charAt(int i9) {
        return this.f16868b.charAt(i9);
    }

    @Override // java.lang.CharSequence
    public final IntStream chars() {
        return IntStream.VivifiedWrapper.convert(this.f16868b.chars());
    }

    @Override // java.lang.CharSequence
    public final java.util.stream.IntStream chars() {
        return IntStream.Wrapper.convert(IntStream.VivifiedWrapper.convert(this.f16868b.chars()));
    }

    @Override // java.lang.CharSequence
    public final IntStream codePoints() {
        return IntStream.VivifiedWrapper.convert(this.f16868b.codePoints());
    }

    @Override // java.lang.CharSequence
    public final java.util.stream.IntStream codePoints() {
        return IntStream.Wrapper.convert(IntStream.VivifiedWrapper.convert(this.f16868b.codePoints()));
    }

    @Override // android.text.Spanned
    public final int getSpanEnd(Object obj) {
        return this.f16868b.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public final int getSpanFlags(Object obj) {
        return this.f16868b.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public final int getSpanStart(Object obj) {
        return this.f16868b.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public final Object[] getSpans(int i9, int i10, Class cls) {
        return this.f16868b.getSpans(i9, i10, cls);
    }

    @Override // java.lang.CharSequence
    public final int length() {
        return this.f16868b.length();
    }

    @Override // android.text.Spanned
    public final int nextSpanTransition(int i9, int i10, Class cls) {
        return this.f16868b.nextSpanTransition(i9, i10, cls);
    }

    @Override // android.text.Spannable
    public final void removeSpan(Object obj) {
        a();
        this.f16868b.removeSpan(obj);
    }

    @Override // android.text.Spannable
    public final void setSpan(Object obj, int i9, int i10, int i11) {
        a();
        this.f16868b.setSpan(obj, i9, i10, i11);
    }

    @Override // java.lang.CharSequence
    public final CharSequence subSequence(int i9, int i10) {
        return this.f16868b.subSequence(i9, i10);
    }

    @Override // java.lang.CharSequence
    public final String toString() {
        return this.f16868b.toString();
    }
}
