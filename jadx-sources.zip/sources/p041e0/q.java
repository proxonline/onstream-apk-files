package p041e0;

import G0.N;
import p033d2.b;

/* JADX INFO: loaded from: classes.dex */
public final class q extends N {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final b f16851d = new b(5);
}
