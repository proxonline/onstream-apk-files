package p041e0;

import K3.h;
import java.util.concurrent.ThreadPoolExecutor;
import p125n1.g;

/* JADX INFO: loaded from: classes.dex */
public final class k extends h {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ h f16834m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ ThreadPoolExecutor f16835n;

    public k(h hVar, ThreadPoolExecutor threadPoolExecutor) {
        this.f16834m = hVar;
        this.f16835n = threadPoolExecutor;
    }

    @Override // K3.h
    public final void o(Throwable th) {
        ThreadPoolExecutor threadPoolExecutor = this.f16835n;
        try {
            this.f16834m.o(th);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }

    @Override // K3.h
    public final void p(g gVar) {
        ThreadPoolExecutor threadPoolExecutor = this.f16835n;
        try {
            this.f16834m.p(gVar);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }
}
