package p041e0;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.ReplacementSpan;
import com.google.android.gms.internal.measurement.I1;
import java.nio.ByteBuffer;
import p050f0.a;
import p125n1.g;

/* JADX INFO: loaded from: classes.dex */
public final class v extends ReplacementSpan {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final u f16863b;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public TextPaint f16866e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Paint.FontMetricsInt f16862a = new Paint.FontMetricsInt();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public short f16864c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f16865d = 1.0f;

    public v(u uVar) {
        I1.f(uVar, "rasterizer cannot be null");
        this.f16863b = uVar;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0042  */
    /* JADX WARN: Code duplicated, block: B:21:0x0046  */
    @Override // android.text.style.ReplacementSpan
    public final void draw(Canvas canvas, CharSequence charSequence, int i9, int i10, float f3, int i11, int i12, int i13, Paint paint) {
        TextPaint textPaint = null;
        if (charSequence instanceof Spanned) {
            CharacterStyle[] characterStyleArr = (CharacterStyle[]) ((Spanned) charSequence).getSpans(i9, i10, CharacterStyle.class);
            if (characterStyleArr.length != 0) {
                if (characterStyleArr.length != 1 || characterStyleArr[0] != this) {
                    TextPaint textPaint2 = this.f16866e;
                    if (textPaint2 == null) {
                        textPaint2 = new TextPaint();
                        this.f16866e = textPaint2;
                    }
                    textPaint = textPaint2;
                    textPaint.set(paint);
                    for (CharacterStyle characterStyle : characterStyleArr) {
                        characterStyle.updateDrawState(textPaint);
                    }
                } else if (paint instanceof TextPaint) {
                    textPaint = (TextPaint) paint;
                }
            } else if (paint instanceof TextPaint) {
                textPaint = (TextPaint) paint;
            }
        } else if (paint instanceof TextPaint) {
            textPaint = (TextPaint) paint;
        }
        TextPaint textPaint3 = textPaint;
        if (textPaint3 != null && textPaint3.bgColor != 0) {
            int color = textPaint3.getColor();
            Paint.Style style = textPaint3.getStyle();
            textPaint3.setColor(textPaint3.bgColor);
            textPaint3.setStyle(Paint.Style.FILL);
            canvas.drawRect(f3, i11, f3 + this.f16864c, i13, textPaint3);
            textPaint3.setStyle(style);
            textPaint3.setColor(color);
        }
        j.a().getClass();
        float f9 = i12;
        Paint paint2 = textPaint3;
        if (textPaint3 == null) {
            paint2 = paint;
        }
        u uVar = this.f16863b;
        g gVar = uVar.f16860b;
        Typeface typeface = (Typeface) gVar.f21580e;
        Typeface typeface2 = paint2.getTypeface();
        paint2.setTypeface(typeface);
        canvas.drawText((char[]) gVar.f21578c, uVar.f16859a * 2, 2, f3, f9, paint2);
        paint2.setTypeface(typeface2);
    }

    @Override // android.text.style.ReplacementSpan
    public final int getSize(Paint paint, CharSequence charSequence, int i9, int i10, Paint.FontMetricsInt fontMetricsInt) {
        Paint.FontMetricsInt fontMetricsInt2 = this.f16862a;
        paint.getFontMetricsInt(fontMetricsInt2);
        float fAbs = Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent) * 1.0f;
        u uVar = this.f16863b;
        a aVarB = uVar.b();
        int iA = aVarB.a(14);
        this.f16865d = fAbs / (iA != 0 ? ((ByteBuffer) aVarB.f5827d).getShort(iA + aVarB.f5824a) : (short) 0);
        a aVarB2 = uVar.b();
        int iA2 = aVarB2.a(14);
        if (iA2 != 0) {
            ((ByteBuffer) aVarB2.f5827d).getShort(iA2 + aVarB2.f5824a);
        }
        a aVarB3 = uVar.b();
        int iA3 = aVarB3.a(12);
        short s9 = (short) ((iA3 != 0 ? ((ByteBuffer) aVarB3.f5827d).getShort(iA3 + aVarB3.f5824a) : (short) 0) * this.f16865d);
        this.f16864c = s9;
        if (fontMetricsInt != null) {
            fontMetricsInt.ascent = fontMetricsInt2.ascent;
            fontMetricsInt.descent = fontMetricsInt2.descent;
            fontMetricsInt.top = fontMetricsInt2.top;
            fontMetricsInt.bottom = fontMetricsInt2.bottom;
        }
        return s9;
    }
}
