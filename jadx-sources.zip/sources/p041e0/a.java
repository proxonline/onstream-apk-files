package p041e0;

import java.util.concurrent.ThreadFactory;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements ThreadFactory {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16816a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f16817b;

    public /* synthetic */ a(String str, int i9) {
        this.f16816a = i9;
        this.f16817b = str;
    }

    @Override // java.util.concurrent.ThreadFactory
    public final Thread newThread(Runnable runnable) {
        switch (this.f16816a) {
            case 0:
                Thread thread = new Thread(runnable, this.f16817b);
                thread.setPriority(10);
                return thread;
            default:
                return new Thread(runnable, this.f16817b);
        }
    }
}
