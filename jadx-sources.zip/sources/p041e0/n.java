package p041e0;

import android.text.TextUtils;

/* JADX INFO: loaded from: classes.dex */
public final class n implements m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f16836a;

    @Override // p041e0.m
    public Object a() {
        return this;
    }

    @Override // p041e0.m
    public boolean b(CharSequence charSequence, int i9, int i10, u uVar) {
        if (!TextUtils.equals(charSequence.subSequence(i9, i10), this.f16836a)) {
            return true;
        }
        uVar.f16861c = (uVar.f16861c & 3) | 4;
        return false;
    }
}
