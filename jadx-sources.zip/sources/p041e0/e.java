package p041e0;

import E4.c;
import K3.h;
import T8.d;
import Y4.i;
import android.os.Build;
import java.util.ArrayList;
import p125n1.g;

/* JADX INFO: loaded from: classes.dex */
public final class e extends h {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ f f16820m;

    public e(f fVar) {
        this.f16820m = fVar;
    }

    @Override // K3.h
    public final void o(Throwable th) {
        ((j) this.f16820m.f16823c).d(th);
    }

    @Override // K3.h
    public final void p(g gVar) {
        f fVar = this.f16820m;
        fVar.f16822b = gVar;
        g gVar2 = (g) fVar.f16822b;
        j jVar = (j) fVar.f16823c;
        fVar.f16821a = new i(gVar2, jVar.f16831g, jVar.f16833i, Build.VERSION.SDK_INT >= 34 ? l.a() : d.j());
        j jVar2 = (j) fVar.f16823c;
        jVar2.getClass();
        ArrayList arrayList = new ArrayList();
        jVar2.f16825a.writeLock().lock();
        try {
            jVar2.f16827c = 1;
            arrayList.addAll(jVar2.f16826b);
            jVar2.f16826b.clear();
            jVar2.f16825a.writeLock().unlock();
            jVar2.f16828d.post(new c(arrayList, jVar2.f16827c, (Throwable) null));
        } catch (Throwable th) {
            jVar2.f16825a.writeLock().unlock();
            throw th;
        }
    }
}
