package p041e0;

import B0.a;
import D.RunnableC0078a;
import K3.h;
import M.c;
import M.d;
import M.i;
import M.j;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import com.google.android.gms.internal.measurement.I1;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import p033d2.b;

/* JADX INFO: loaded from: classes.dex */
public final class p implements i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f16843a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f16844b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final b f16845c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f16846d = new Object();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Handler f16847e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public ThreadPoolExecutor f16848f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ThreadPoolExecutor f16849g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public h f16850h;

    public p(Context context, d dVar) {
        I1.f(context, "Context cannot be null");
        this.f16843a = context.getApplicationContext();
        this.f16844b = dVar;
        this.f16845c = q.f16851d;
    }

    @Override // p041e0.i
    public final void a(h hVar) {
        synchronized (this.f16846d) {
            this.f16850h = hVar;
        }
        c();
    }

    public final void b() {
        synchronized (this.f16846d) {
            try {
                this.f16850h = null;
                Handler handler = this.f16847e;
                if (handler != null) {
                    handler.removeCallbacks(null);
                }
                this.f16847e = null;
                ThreadPoolExecutor threadPoolExecutor = this.f16849g;
                if (threadPoolExecutor != null) {
                    threadPoolExecutor.shutdown();
                }
                this.f16848f = null;
                this.f16849g = null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void c() {
        synchronized (this.f16846d) {
            try {
                if (this.f16850h == null) {
                    return;
                }
                if (this.f16848f == null) {
                    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new a("emojiCompat", 0));
                    threadPoolExecutor.allowCoreThreadTimeOut(true);
                    this.f16849g = threadPoolExecutor;
                    this.f16848f = threadPoolExecutor;
                }
                this.f16848f.execute(new RunnableC0078a(19, this));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final j d() {
        try {
            b bVar = this.f16845c;
            Context context = this.f16843a;
            d dVar = this.f16844b;
            bVar.getClass();
            Object[] objArr = {dVar};
            ArrayList arrayList = new ArrayList(1);
            Object obj = objArr[0];
            Objects.requireNonNull(obj);
            arrayList.add(obj);
            i iVarA = c.a(context, DesugarCollections.unmodifiableList(arrayList));
            int i9 = iVarA.f4516a;
            if (i9 != 0) {
                throw new RuntimeException(a.n("fetchFonts failed (", i9, ")"));
            }
            j[] jVarArr = (j[]) iVarA.f4517b.get(0);
            if (jVarArr == null || jVarArr.length == 0) {
                throw new RuntimeException("fetchFonts failed (empty result)");
            }
            return jVarArr[0];
        } catch (PackageManager.NameNotFoundException e9) {
            throw new RuntimeException("provider not found", e9);
        }
    }
}
