package R7;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f6828a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a f6829b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a f6830c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final a f6831d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a f6832e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ a[] f6833f;

    static {
        a aVar = new a("LevelDebug", 0);
        f6828a = aVar;
        a aVar2 = new a("LevelInfo", 1);
        f6829b = aVar2;
        a aVar3 = new a("LevelWarning", 2);
        f6830c = aVar3;
        a aVar4 = new a("LevelError", 3);
        f6831d = aVar4;
        a aVar5 = new a("LevelNone", 4);
        f6832e = aVar5;
        f6833f = new a[]{aVar, aVar2, aVar3, aVar4, aVar5};
    }

    public static a valueOf(String str) {
        return (a) Enum.valueOf(a.class, str);
    }

    public static a[] values() {
        return (a[]) f6833f.clone();
    }
}
