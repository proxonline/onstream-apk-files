package R7;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final b f6834a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final b f6835b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ b[] f6836c;

    static {
        b bVar = new b("OnErrorDiscard", 0);
        f6834a = bVar;
        b bVar2 = new b("OnErrorRecover", 1);
        f6835b = bVar2;
        f6836c = new b[]{bVar, bVar2};
    }

    public static b valueOf(String str) {
        return (b) Enum.valueOf(b.class, str);
    }

    public static b[] values() {
        return (b[]) f6836c.clone();
    }
}
