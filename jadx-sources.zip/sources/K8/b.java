package K8;

import B8.C0042h;
import L8.C;
import a9.C0496o;
import a9.C0499s;
import a9.InterfaceC0485d;
import a9.InterfaceC0488g;
import a9.N;
import p015b4.c;
import p015b4.h;
import p015b4.q;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class b implements c, InterfaceC0488g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0042h f3867a;

    public /* synthetic */ b(C0042h c0042h) {
        this.f3867a = c0042h;
    }

    @Override // p015b4.c
    public void g(h hVar) {
        Exception excF = hVar.f();
        if (excF != null) {
            this.f3867a.resumeWith(u0.m(excF));
        } else if (((q) hVar).f11492d) {
            this.f3867a.d(null);
        } else {
            this.f3867a.resumeWith(hVar.g());
        }
    }

    @Override // a9.InterfaceC0488g
    public void i(InterfaceC0485d interfaceC0485d, N n9) {
        boolean zF = n9.f10067a.f();
        C0042h c0042h = this.f3867a;
        if (!zF) {
            c0042h.resumeWith(u0.m(new C0496o(n9)));
            return;
        }
        Object obj = n9.f10068b;
        if (obj != null) {
            c0042h.resumeWith(obj);
            return;
        }
        C cK = interfaceC0485d.k();
        cK.getClass();
        Object objCast = C0499s.class.cast(cK.f4302e.get(C0499s.class));
        kotlin.jvm.internal.h.b(objCast);
        C0499s c0499s = (C0499s) objCast;
        c0042h.resumeWith(u0.m(new p039d8.b("Response from " + c0499s.f10111a.getName() + '.' + c0499s.f10113c.getName() + " was null but response body type was declared as non-null")));
    }

    @Override // a9.InterfaceC0488g
    public void v(InterfaceC0485d interfaceC0485d, Throwable th) {
        this.f3867a.resumeWith(u0.m(th));
    }
}
