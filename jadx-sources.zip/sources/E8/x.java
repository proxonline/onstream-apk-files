package E8;

/* JADX INFO: loaded from: classes.dex */
public final class x extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public C0099s f1555r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f1556s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f1557t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ C0099s f1558u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Object f1559v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x(C0099s c0099s, p093j8.c cVar) {
        super(cVar);
        this.f1558u = c0099s;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1556s = obj;
        this.f1557t |= Integer.MIN_VALUE;
        return this.f1558u.emit(null, this);
    }
}
