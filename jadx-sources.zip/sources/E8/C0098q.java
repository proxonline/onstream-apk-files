package E8;

import co.notix.b9;
import p195v5.u0;

/* JADX INFO: renamed from: E8.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0098q implements InterfaceC0086e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1531a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f1532b;

    public /* synthetic */ C0098q(InterfaceC0086e interfaceC0086e, int i9) {
        this.f1531a = i9;
        this.f1532b = interfaceC0086e;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public C0098q(p167r8.p pVar) {
        this.f1531a = 2;
        this.f1532b = (p093j8.i) pVar;
    }

    /* JADX WARN: Code duplicated, block: B:14:0x002e  */
    /* JADX WARN: Type inference failed for: r6v8, types: [j8.i, r8.p] */
    @Override // E8.InterfaceC0086e
    public final Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar) {
        C0082a c0082a;
        Throwable th;
        F8.z zVar;
        switch (this.f1531a) {
            case 0:
                Object objCollect = ((InterfaceC0086e) this.f1532b).collect(new C0099s(new kotlin.jvm.internal.m(), 0, interfaceC0087f), dVar);
                return objCollect == p084i8.a.f19475a ? objCollect : p039d8.l.f16813a;
            case 1:
                Object objCollect2 = ((b9) this.f1532b).collect(new D(interfaceC0087f, 0), dVar);
                return objCollect2 == p084i8.a.f19475a ? objCollect2 : p039d8.l.f16813a;
            case 2:
                if (dVar instanceof C0082a) {
                    c0082a = (C0082a) dVar;
                    int i9 = c0082a.f1484u;
                    if ((i9 & Integer.MIN_VALUE) != 0) {
                        c0082a.f1484u = i9 - Integer.MIN_VALUE;
                    } else {
                        c0082a = new C0082a(this, dVar);
                    }
                } else {
                    c0082a = new C0082a(this, dVar);
                }
                Object obj = c0082a.f1482s;
                int i10 = c0082a.f1484u;
                p039d8.l lVar = p039d8.l.f16813a;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    zVar = c0082a.f1481r;
                    try {
                        u0.F(obj);
                        zVar.releaseIntercepted();
                        return lVar;
                    } catch (Throwable th2) {
                        th = th2;
                        zVar.releaseIntercepted();
                        throw th;
                    }
                }
                u0.F(obj);
                F8.z zVar2 = new F8.z(interfaceC0087f, c0082a.getContext());
                try {
                    c0082a.f1481r = zVar2;
                    c0082a.f1484u = 1;
                    Object objInvoke = ((p093j8.i) this.f1532b).invoke(zVar2, c0082a);
                    p084i8.a aVar = p084i8.a.f19475a;
                    if (objInvoke != aVar) {
                        objInvoke = lVar;
                    }
                    if (objInvoke == aVar) {
                        return aVar;
                    }
                    zVar = zVar2;
                    zVar.releaseIntercepted();
                    return lVar;
                } catch (Throwable th3) {
                    th = th3;
                    zVar = zVar2;
                    zVar.releaseIntercepted();
                    throw th;
                }
            default:
                Object objCollect3 = ((C0100t) this.f1532b).collect(new D(interfaceC0087f, 1), dVar);
                return objCollect3 == p084i8.a.f19475a ? objCollect3 : p039d8.l.f16813a;
        }
    }
}
