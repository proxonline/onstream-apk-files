package E8;

/* JADX INFO: loaded from: classes.dex */
public final class C extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f1426r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1427s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ D f1428t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C(D d9, p093j8.c cVar) {
        super(cVar);
        this.f1428t = d9;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1426r = obj;
        this.f1427s |= Integer.MIN_VALUE;
        return this.f1428t.emit(null, this);
    }
}
