package E8;

import B8.C0042h;

/* JADX INFO: loaded from: classes.dex */
public final class M implements B8.O {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final O f1446a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f1447b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f1448c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C0042h f1449d;

    public M(O o4, long j, Object obj, C0042h c0042h) {
        this.f1446a = o4;
        this.f1447b = j;
        this.f1448c = obj;
        this.f1449d = c0042h;
    }

    @Override // B8.O
    public final void b() {
        O o4 = this.f1446a;
        synchronized (o4) {
            if (this.f1447b < o4.m()) {
                return;
            }
            Object[] objArr = o4.f1460h;
            kotlin.jvm.internal.h.b(objArr);
            long j = this.f1447b;
            if (objArr[((int) j) & (objArr.length - 1)] != this) {
                return;
            }
            P.d(objArr, j, P.f1464a);
            o4.h();
        }
    }
}
