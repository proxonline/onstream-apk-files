package E8;

import B7.C0021h;

/* JADX INFO: loaded from: classes.dex */
public final class A extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public kotlin.jvm.internal.o f1417r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public C0021h f1418s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public /* synthetic */ Object f1419t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f1420u;

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1419t = obj;
        this.f1420u |= Integer.MIN_VALUE;
        return P.k(null, this);
    }
}
