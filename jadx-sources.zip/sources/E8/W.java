package E8;

/* JADX INFO: loaded from: classes.dex */
public final class W implements InterfaceC0087f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Throwable f1480a;

    public W(Throwable th) {
        this.f1480a = th;
    }

    @Override // E8.InterfaceC0087f
    public final Object emit(Object obj, h8.d dVar) throws Throwable {
        throw this.f1480a;
    }
}
