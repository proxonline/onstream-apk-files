package E8;

/* JADX INFO: loaded from: classes.dex */
public interface I extends S, H {
}
