package E8;

/* JADX INFO: renamed from: E8.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0091j extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f1503r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1504s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C0092k f1505t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object f1506u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public InterfaceC0087f f1507v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0091j(C0092k c0092k, h8.d dVar) {
        super(dVar);
        this.f1505t = c0092k;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1503r = obj;
        this.f1504s |= Integer.MIN_VALUE;
        return this.f1505t.collect(null, this);
    }
}
