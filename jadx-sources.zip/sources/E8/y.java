package E8;

import G8.AbstractC0165a;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f1560a = 0;

    static {
        AbstractC0165a.j("kotlinx.coroutines.flow.defaultConcurrency", 16, 1, Integer.MAX_VALUE);
    }
}
