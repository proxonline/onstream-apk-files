package E8;

/* JADX INFO: renamed from: E8.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0093l extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f1510r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1511s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C0094m f1512t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public C0094m f1513u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public InterfaceC0087f f1514v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public F8.z f1515w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0093l(C0094m c0094m, h8.d dVar) {
        super(dVar);
        this.f1512t = c0094m;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1510r = obj;
        this.f1511s |= Integer.MIN_VALUE;
        return this.f1512t.collect(null, this);
    }
}
