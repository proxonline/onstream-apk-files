package E8;

import B8.InterfaceC0047j0;

/* JADX INFO: loaded from: classes.dex */
public final class T extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public U f1469r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public InterfaceC0087f f1470s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public V f1471t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public InterfaceC0047j0 f1472u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Object f1473v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f1474w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ U f1475x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f1476y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public T(U u4, h8.d dVar) {
        super(dVar);
        this.f1475x = u4;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1474w = obj;
        this.f1476y |= Integer.MIN_VALUE;
        this.f1475x.collect(null, this);
        return p084i8.a.f19475a;
    }
}
