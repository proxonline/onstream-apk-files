package E8;

/* JADX INFO: loaded from: classes.dex */
public final class z extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public C0099s f1561r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f1562s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f1563t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ C0099s f1564u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Object f1565v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public z(C0099s c0099s, p093j8.c cVar) {
        super(cVar);
        this.f1564u = c0099s;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1562s = obj;
        this.f1563t |= Integer.MIN_VALUE;
        return this.f1564u.emit(null, this);
    }
}
