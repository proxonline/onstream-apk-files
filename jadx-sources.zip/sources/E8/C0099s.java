package E8;

import F8.C0104a;
import co.notix.le;
import p195v5.u0;

/* JADX INFO: renamed from: E8.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0099s implements InterfaceC0087f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1536a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1537b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1538c;

    public C0099s(InterfaceC0087f interfaceC0087f, le leVar) {
        this.f1536a = 3;
        this.f1537b = interfaceC0087f;
        this.f1538c = leVar;
    }

    public /* synthetic */ C0099s(Object obj, int i9, Object obj2) {
        this.f1536a = i9;
        this.f1538c = obj;
        this.f1537b = obj2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public C0099s(p167r8.p pVar, InterfaceC0087f interfaceC0087f) {
        this.f1536a = 1;
        this.f1538c = (p093j8.i) pVar;
        this.f1537b = interfaceC0087f;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x007f  */
    /* JADX WARN: Code duplicated, block: B:54:0x00e0  */
    /* JADX WARN: Code duplicated, block: B:74:0x0143  */
    /* JADX WARN: Code duplicated, block: B:76:0x0146  */
    /* JADX WARN: Code duplicated, block: B:83:0x015f  */
    /* JADX WARN: Code duplicated, block: B:9:0x0018  */
    /* JADX WARN: Type inference failed for: r9v12, types: [j8.i, r8.p] */
    @Override // E8.InterfaceC0087f
    public final Object emit(Object obj, h8.d dVar) {
        r rVar;
        x xVar;
        Object obj2;
        Object obj3;
        C0099s c0099s;
        z zVar;
        C0099s c0099s2;
        E e9;
        Object obj4;
        InterfaceC0087f interfaceC0087f;
        switch (this.f1536a) {
            case 0:
                if (dVar instanceof r) {
                    rVar = (r) dVar;
                    int i9 = rVar.f1535t;
                    if ((i9 & Integer.MIN_VALUE) != 0) {
                        rVar.f1535t = i9 - Integer.MIN_VALUE;
                    } else {
                        rVar = new r(this, (p093j8.c) dVar);
                    }
                } else {
                    rVar = new r(this, (p093j8.c) dVar);
                }
                Object obj5 = rVar.f1533r;
                int i10 = rVar.f1535t;
                p039d8.l lVar = p039d8.l.f16813a;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    u0.F(obj5);
                    return lVar;
                }
                u0.F(obj5);
                kotlin.jvm.internal.m mVar = (kotlin.jvm.internal.m) this.f1538c;
                int i11 = mVar.f21065a;
                if (i11 < 1) {
                    mVar.f21065a = i11 + 1;
                    return lVar;
                }
                InterfaceC0087f interfaceC0087f2 = (InterfaceC0087f) this.f1537b;
                rVar.f1535t = 1;
                Object objEmit = interfaceC0087f2.emit(obj, rVar);
                p084i8.a aVar = p084i8.a.f19475a;
                return objEmit == aVar ? aVar : lVar;
            case 1:
                if (dVar instanceof x) {
                    xVar = (x) dVar;
                    int i12 = xVar.f1557t;
                    if ((i12 & Integer.MIN_VALUE) != 0) {
                        xVar.f1557t = i12 - Integer.MIN_VALUE;
                    } else {
                        xVar = new x(this, (p093j8.c) dVar);
                    }
                } else {
                    xVar = new x(this, (p093j8.c) dVar);
                }
                Object obj6 = xVar.f1556s;
                int i13 = xVar.f1557t;
                boolean z9 = true;
                p084i8.a aVar2 = p084i8.a.f19475a;
                if (i13 != 0) {
                    if (i13 == 1) {
                        Object obj7 = xVar.f1559v;
                        C0099s c0099s3 = xVar.f1555r;
                        u0.F(obj6);
                        obj3 = obj7;
                        c0099s = c0099s3;
                        obj2 = obj6;
                    } else {
                        if (i13 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        c0099s = xVar.f1555r;
                        u0.F(obj6);
                    }
                    if (z9) {
                        return p039d8.l.f16813a;
                    }
                    throw new C0104a(c0099s);
                }
                u0.F(obj6);
                ?? r9 = (p093j8.i) this.f1538c;
                xVar.f1555r = this;
                xVar.f1559v = obj;
                xVar.f1557t = 1;
                Object objInvoke = r9.invoke(obj, xVar);
                if (objInvoke == aVar2) {
                    return aVar2;
                }
                obj2 = objInvoke;
                obj3 = obj;
                c0099s = this;
                if (((Boolean) obj2).booleanValue()) {
                    InterfaceC0087f interfaceC0087f3 = (InterfaceC0087f) c0099s.f1537b;
                    xVar.f1555r = c0099s;
                    xVar.f1559v = null;
                    xVar.f1557t = 2;
                    if (interfaceC0087f3.emit(obj3, xVar) == aVar2) {
                        return aVar2;
                    }
                } else {
                    z9 = false;
                }
                if (z9) {
                    return p039d8.l.f16813a;
                }
                throw new C0104a(c0099s);
            case 2:
                if (dVar instanceof z) {
                    zVar = (z) dVar;
                    int i14 = zVar.f1563t;
                    if ((i14 & Integer.MIN_VALUE) != 0) {
                        zVar.f1563t = i14 - Integer.MIN_VALUE;
                    } else {
                        zVar = new z(this, (p093j8.c) dVar);
                    }
                } else {
                    zVar = new z(this, (p093j8.c) dVar);
                }
                Object objInvoke2 = zVar.f1562s;
                int i15 = zVar.f1563t;
                if (i15 == 0) {
                    u0.F(objInvoke2);
                    p167r8.p pVar = (p167r8.p) this.f1538c;
                    zVar.f1561r = this;
                    zVar.f1565v = obj;
                    zVar.f1563t = 1;
                    objInvoke2 = pVar.invoke(obj, zVar);
                    p084i8.a aVar3 = p084i8.a.f19475a;
                    if (objInvoke2 == aVar3) {
                        return aVar3;
                    }
                    c0099s2 = this;
                } else {
                    if (i15 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    obj = zVar.f1565v;
                    c0099s2 = zVar.f1561r;
                    u0.F(objInvoke2);
                }
                if (!((Boolean) objInvoke2).booleanValue()) {
                    return p039d8.l.f16813a;
                }
                ((kotlin.jvm.internal.o) c0099s2.f1537b).f21067a = obj;
                throw new C0104a(c0099s2);
            default:
                if (dVar instanceof E) {
                    e9 = (E) dVar;
                    int i16 = e9.f1432s;
                    if ((i16 & Integer.MIN_VALUE) != 0) {
                        e9.f1432s = i16 - Integer.MIN_VALUE;
                    } else {
                        e9 = new E(this, (p093j8.c) dVar);
                    }
                } else {
                    e9 = new E(this, (p093j8.c) dVar);
                }
                Object obj8 = e9.f1431r;
                int i17 = e9.f1432s;
                p084i8.a aVar4 = p084i8.a.f19475a;
                if (i17 != 0) {
                    if (i17 == 1) {
                        interfaceC0087f = e9.f1435v;
                        obj4 = e9.f1434u;
                        u0.F(obj8);
                    } else {
                        if (i17 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        u0.F(obj8);
                    }
                    return p039d8.l.f16813a;
                }
                u0.F(obj8);
                InterfaceC0087f interfaceC0087f4 = (InterfaceC0087f) this.f1537b;
                le leVar = (le) this.f1538c;
                e9.f1434u = obj;
                e9.f1435v = interfaceC0087f4;
                e9.f1432s = 1;
                if (leVar.invoke(obj, e9) == aVar4) {
                    return aVar4;
                }
                obj4 = obj;
                interfaceC0087f = interfaceC0087f4;
                e9.f1434u = null;
                e9.f1435v = null;
                e9.f1432s = 2;
                if (interfaceC0087f.emit(obj4, e9) == aVar4) {
                    return aVar4;
                }
                return p039d8.l.f16813a;
        }
    }
}
