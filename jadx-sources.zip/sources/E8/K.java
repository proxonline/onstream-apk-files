package E8;

/* JADX INFO: loaded from: classes.dex */
public final class K implements S, InterfaceC0086e, F8.v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ S f1445a;

    public K(I i9) {
        this.f1445a = i9;
    }

    @Override // F8.v
    public final InterfaceC0086e a(h8.i iVar, int i9, D8.a aVar) {
        return (((i9 < 0 || i9 >= 2) && i9 != -2) || aVar != D8.a.f1126b) ? P.m(this, iVar, i9, aVar) : this;
    }

    @Override // E8.InterfaceC0086e
    public final Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar) {
        return this.f1445a.collect(interfaceC0087f, dVar);
    }

    @Override // E8.S
    public final Object getValue() {
        return this.f1445a.getValue();
    }
}
