package E8;

/* JADX INFO: renamed from: E8.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0103w extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f1551r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1552s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C0100t f1553t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public C0099s f1554u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0103w(C0100t c0100t, h8.d dVar) {
        super(dVar);
        this.f1553t = c0100t;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1551r = obj;
        this.f1552s |= Integer.MIN_VALUE;
        return this.f1553t.collect(null, this);
    }
}
