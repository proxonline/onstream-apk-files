package E8;

import F8.AbstractC0106c;
import p195v5.u0;

/* JADX INFO: renamed from: E8.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0084c implements InterfaceC0087f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1488a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0087f f1489b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ kotlin.jvm.internal.o f1490c;

    public C0084c(C0085d c0085d, kotlin.jvm.internal.o oVar, InterfaceC0087f interfaceC0087f) {
        this.f1490c = oVar;
        this.f1489b = interfaceC0087f;
    }

    public C0084c(InterfaceC0087f interfaceC0087f, kotlin.jvm.internal.o oVar) {
        this.f1489b = interfaceC0087f;
        this.f1490c = oVar;
    }

    /* JADX WARN: Code duplicated, block: B:36:0x0067  */
    /* JADX WARN: Code duplicated, block: B:9:0x0018  */
    @Override // E8.InterfaceC0087f
    public final Object emit(Object obj, h8.d dVar) throws Throwable {
        C0083b c0083b;
        C0097p c0097p;
        C0084c c0084c;
        switch (this.f1488a) {
            case 0:
                if (dVar instanceof C0083b) {
                    c0083b = (C0083b) dVar;
                    int i9 = c0083b.f1487t;
                    if ((i9 & Integer.MIN_VALUE) != 0) {
                        c0083b.f1487t = i9 - Integer.MIN_VALUE;
                    } else {
                        c0083b = new C0083b(this, (p093j8.c) dVar);
                    }
                } else {
                    c0083b = new C0083b(this, (p093j8.c) dVar);
                }
                Object obj2 = c0083b.f1485r;
                int i10 = c0083b.f1487t;
                p039d8.l lVar = p039d8.l.f16813a;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    u0.F(obj2);
                    return lVar;
                }
                u0.F(obj2);
                kotlin.jvm.internal.o oVar = this.f1490c;
                Object obj3 = oVar.f21067a;
                if (obj3 != AbstractC0106c.f1745b && kotlin.jvm.internal.h.a(obj3, obj)) {
                    return lVar;
                }
                oVar.f21067a = obj;
                c0083b.f1487t = 1;
                Object objEmit = this.f1489b.emit(obj, c0083b);
                p084i8.a aVar = p084i8.a.f19475a;
                return objEmit == aVar ? aVar : lVar;
            default:
                if (dVar instanceof C0097p) {
                    c0097p = (C0097p) dVar;
                    int i11 = c0097p.f1530u;
                    if ((i11 & Integer.MIN_VALUE) != 0) {
                        c0097p.f1530u = i11 - Integer.MIN_VALUE;
                    } else {
                        c0097p = new C0097p(this, (p093j8.c) dVar);
                    }
                } else {
                    c0097p = new C0097p(this, (p093j8.c) dVar);
                }
                Object obj4 = c0097p.f1528s;
                int i12 = c0097p.f1530u;
                if (i12 != 0) {
                    if (i12 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    c0084c = c0097p.f1527r;
                    try {
                        u0.F(obj4);
                        return p039d8.l.f16813a;
                    } catch (Throwable th) {
                        th = th;
                        c0084c.f1490c.f21067a = th;
                        throw th;
                    }
                }
                u0.F(obj4);
                try {
                    InterfaceC0087f interfaceC0087f = this.f1489b;
                    c0097p.f1527r = this;
                    c0097p.f1530u = 1;
                    Object objEmit2 = interfaceC0087f.emit(obj, c0097p);
                    p084i8.a aVar2 = p084i8.a.f19475a;
                    if (objEmit2 == aVar2) {
                        return aVar2;
                    }
                    return p039d8.l.f16813a;
                } catch (Throwable th2) {
                    th = th2;
                    c0084c = this;
                    c0084c.f1490c.f21067a = th;
                    throw th;
                }
        }
    }
}
