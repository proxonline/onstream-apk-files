package E8;

/* JADX INFO: renamed from: E8.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0082a extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public F8.z f1481r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f1482s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C0098q f1483t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f1484u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0082a(C0098q c0098q, h8.d dVar) {
        super(dVar);
        this.f1483t = c0098q;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1482s = obj;
        this.f1484u |= Integer.MIN_VALUE;
        return this.f1483t.collect(null, this);
    }
}
