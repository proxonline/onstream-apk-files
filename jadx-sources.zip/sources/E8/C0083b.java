package E8;

/* JADX INFO: renamed from: E8.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0083b extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f1485r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ C0084c f1486s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f1487t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0083b(C0084c c0084c, p093j8.c cVar) {
        super(cVar);
        this.f1486s = c0084c;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1485r = obj;
        this.f1487t |= Integer.MIN_VALUE;
        return this.f1486s.emit(null, this);
    }
}
