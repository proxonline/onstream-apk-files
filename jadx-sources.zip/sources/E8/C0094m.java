package E8;

import F8.AbstractC0106c;
import Y.C0449n;
import co.notix.le;
import p195v5.u0;

/* JADX INFO: renamed from: E8.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0094m implements InterfaceC0086e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1516a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1517b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1518c;

    public /* synthetic */ C0094m(InterfaceC0086e interfaceC0086e, p093j8.i iVar, int i9) {
        this.f1516a = i9;
        this.f1517b = interfaceC0086e;
        this.f1518c = iVar;
    }

    public /* synthetic */ C0094m(Object obj, int i9, Object obj2) {
        this.f1516a = i9;
        this.f1518c = obj;
        this.f1517b = obj2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public C0094m(InterfaceC0086e[] interfaceC0086eArr, p167r8.r rVar) {
        this.f1516a = 3;
        this.f1518c = interfaceC0086eArr;
        this.f1517b = (p093j8.i) rVar;
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0064  */
    /* JADX WARN: Code duplicated, block: B:49:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:86:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r2v7, types: [j8.i, r8.r] */
    @Override // E8.InterfaceC0086e
    public final Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar) throws Throwable {
        C0093l c0093l;
        Throwable th;
        F8.z zVar;
        C0094m c0094m;
        InterfaceC0087f interfaceC0087f2;
        InterfaceC0086e interfaceC0086e;
        C0095n c0095n;
        C0094m c0094m2;
        switch (this.f1516a) {
            case 0:
                if (dVar instanceof C0093l) {
                    c0093l = (C0093l) dVar;
                    int i9 = c0093l.f1511s;
                    if ((i9 & Integer.MIN_VALUE) != 0) {
                        c0093l.f1511s = i9 - Integer.MIN_VALUE;
                    } else {
                        c0093l = new C0093l(this, dVar);
                    }
                } else {
                    c0093l = new C0093l(this, dVar);
                }
                Object obj = c0093l.f1510r;
                int i10 = c0093l.f1511s;
                p084i8.a aVar = p084i8.a.f19475a;
                if (i10 == 0) {
                    u0.F(obj);
                    F8.z zVar2 = new F8.z(interfaceC0087f, c0093l.getContext());
                    try {
                        C0449n c0449n = (C0449n) this.f1518c;
                        c0093l.f1513u = this;
                        c0093l.f1514v = interfaceC0087f;
                        c0093l.f1515w = zVar2;
                        c0093l.f1511s = 1;
                        if (c0449n.invoke(zVar2, c0093l) == aVar) {
                            return aVar;
                        }
                        c0094m = this;
                        interfaceC0087f2 = interfaceC0087f;
                        zVar = zVar2;
                        zVar.releaseIntercepted();
                        interfaceC0086e = (InterfaceC0086e) c0094m.f1517b;
                        c0093l.f1513u = null;
                        c0093l.f1514v = null;
                        c0093l.f1515w = null;
                        c0093l.f1511s = 2;
                        if (interfaceC0086e.collect(interfaceC0087f2, c0093l) == aVar) {
                            return aVar;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        zVar = zVar2;
                        zVar.releaseIntercepted();
                        throw th;
                    }
                } else if (i10 == 1) {
                    zVar = c0093l.f1515w;
                    interfaceC0087f2 = c0093l.f1514v;
                    c0094m = c0093l.f1513u;
                    try {
                        u0.F(obj);
                        zVar.releaseIntercepted();
                        interfaceC0086e = (InterfaceC0086e) c0094m.f1517b;
                        c0093l.f1513u = null;
                        c0093l.f1514v = null;
                        c0093l.f1515w = null;
                        c0093l.f1511s = 2;
                        if (interfaceC0086e.collect(interfaceC0087f2, c0093l) == aVar) {
                            return aVar;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        zVar.releaseIntercepted();
                        throw th;
                    }
                } else {
                    if (i10 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    u0.F(obj);
                }
                return p039d8.l.f16813a;
            case 1:
                if (dVar instanceof C0095n) {
                    c0095n = (C0095n) dVar;
                    int i11 = c0095n.f1520s;
                    if ((i11 & Integer.MIN_VALUE) != 0) {
                        c0095n.f1520s = i11 - Integer.MIN_VALUE;
                    } else {
                        c0095n = new C0095n(this, dVar);
                    }
                } else {
                    c0095n = new C0095n(this, dVar);
                }
                Object objF = c0095n.f1519r;
                int i12 = c0095n.f1520s;
                Object obj2 = p084i8.a.f19475a;
                if (i12 != 0) {
                    if (i12 == 1) {
                        interfaceC0087f = c0095n.f1523v;
                        c0094m2 = c0095n.f1522u;
                        u0.F(objF);
                    } else {
                        if (i12 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        u0.F(objF);
                    }
                    return p039d8.l.f16813a;
                }
                u0.F(objF);
                InterfaceC0086e interfaceC0086e2 = (InterfaceC0086e) this.f1517b;
                c0095n.f1522u = this;
                c0095n.f1523v = interfaceC0087f;
                c0095n.f1520s = 1;
                objF = P.f(interfaceC0086e2, interfaceC0087f, c0095n);
                if (objF == obj2) {
                    return obj2;
                }
                c0094m2 = this;
                Throwable th4 = (Throwable) objF;
                if (th4 != null) {
                    p017b6.G g4 = (p017b6.G) c0094m2.f1518c;
                    c0095n.f1522u = null;
                    c0095n.f1523v = null;
                    c0095n.f1520s = 2;
                    if (g4.invoke(interfaceC0087f, th4, c0095n) == obj2) {
                        return obj2;
                    }
                }
                return p039d8.l.f16813a;
            case 2:
                Object objCollect = ((InterfaceC0086e) this.f1517b).collect(new C0099s(interfaceC0087f, (le) this.f1518c), dVar);
                return objCollect == p084i8.a.f19475a ? objCollect : p039d8.l.f16813a;
            case 3:
                Object objA = AbstractC0106c.a(interfaceC0087f, dVar, new F((p093j8.c) null, (p167r8.r) this.f1517b), (InterfaceC0086e[]) this.f1518c);
                return objA == p084i8.a.f19475a ? objA : p039d8.l.f16813a;
            default:
                Object objCollect2 = ((C0094m) this.f1518c).collect(new D(interfaceC0087f, (p017b6.K) this.f1517b), dVar);
                return objCollect2 == p084i8.a.f19475a ? objCollect2 : p039d8.l.f16813a;
        }
    }
}
