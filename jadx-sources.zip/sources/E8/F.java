package E8;

import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class F extends p093j8.i implements p167r8.q {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ int f1436r = 0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1437s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public /* synthetic */ InterfaceC0087f f1438t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public /* synthetic */ Object f1439u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ p093j8.i f1440v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public F(p093j8.c cVar, p167r8.r rVar) {
        super(3, cVar);
        this.f1440v = (p093j8.i) rVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public F(p167r8.p pVar, p093j8.c cVar) {
        super(3, cVar);
        this.f1440v = (p093j8.i) pVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public F(p167r8.q qVar, p093j8.c cVar) {
        super(3, cVar);
        this.f1440v = (p093j8.i) qVar;
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [j8.i, r8.r] */
    /* JADX WARN: Type inference failed for: r1v1, types: [j8.i, r8.q] */
    /* JADX WARN: Type inference failed for: r1v2, types: [j8.i, r8.p] */
    @Override // p167r8.q
    public final Object invoke(Object obj, Object obj2, Object obj3) {
        InterfaceC0087f interfaceC0087f = (InterfaceC0087f) obj;
        switch (this.f1436r) {
            case 0:
                F f3 = new F((p093j8.c) ((h8.d) obj3), (p167r8.r) this.f1440v);
                f3.f1438t = interfaceC0087f;
                f3.f1439u = (Object[]) obj2;
                return f3.invokeSuspend(p039d8.l.f16813a);
            case 1:
                F f9 = new F((p167r8.q) this.f1440v, (p093j8.c) ((h8.d) obj3));
                f9.f1438t = interfaceC0087f;
                f9.f1439u = (Object[]) obj2;
                return f9.invokeSuspend(p039d8.l.f16813a);
            default:
                F f10 = new F((p167r8.p) this.f1440v, (p093j8.c) ((h8.d) obj3));
                f10.f1438t = interfaceC0087f;
                f10.f1439u = obj2;
                return f10.invokeSuspend(p039d8.l.f16813a);
        }
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [j8.i, r8.r] */
    /* JADX WARN: Type inference failed for: r2v4, types: [j8.i, r8.q] */
    /* JADX WARN: Type inference failed for: r2v7, types: [j8.i, r8.p] */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        InterfaceC0087f interfaceC0087f;
        InterfaceC0087f interfaceC0087f2;
        InterfaceC0087f interfaceC0087f3;
        switch (this.f1436r) {
            case 0:
                int i9 = this.f1437s;
                p084i8.a aVar = p084i8.a.f19475a;
                if (i9 != 0) {
                    if (i9 == 1) {
                        interfaceC0087f = this.f1438t;
                        u0.F(obj);
                    } else {
                        if (i9 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        u0.F(obj);
                    }
                    return p039d8.l.f16813a;
                }
                u0.F(obj);
                interfaceC0087f = this.f1438t;
                Object[] objArr = (Object[]) this.f1439u;
                Object obj2 = objArr[0];
                Object obj3 = objArr[1];
                Object obj4 = objArr[2];
                this.f1438t = interfaceC0087f;
                this.f1437s = 1;
                obj = this.f1440v.invoke(obj2, obj3, obj4, this);
                if (obj == aVar) {
                    return aVar;
                }
                this.f1438t = null;
                this.f1437s = 2;
                if (interfaceC0087f.emit(obj, this) == aVar) {
                    return aVar;
                }
                return p039d8.l.f16813a;
            case 1:
                int i10 = this.f1437s;
                p084i8.a aVar2 = p084i8.a.f19475a;
                if (i10 != 0) {
                    if (i10 == 1) {
                        interfaceC0087f2 = this.f1438t;
                        u0.F(obj);
                    } else {
                        if (i10 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        u0.F(obj);
                    }
                    return p039d8.l.f16813a;
                }
                u0.F(obj);
                interfaceC0087f2 = this.f1438t;
                Object[] objArr2 = (Object[]) this.f1439u;
                Object obj5 = objArr2[0];
                Object obj6 = objArr2[1];
                this.f1438t = interfaceC0087f2;
                this.f1437s = 1;
                obj = this.f1440v.invoke(obj5, obj6, this);
                if (obj == aVar2) {
                    return aVar2;
                }
                this.f1438t = null;
                this.f1437s = 2;
                if (interfaceC0087f2.emit(obj, this) == aVar2) {
                    return aVar2;
                }
                return p039d8.l.f16813a;
            default:
                int i11 = this.f1437s;
                p084i8.a aVar3 = p084i8.a.f19475a;
                if (i11 != 0) {
                    if (i11 == 1) {
                        interfaceC0087f3 = this.f1438t;
                        u0.F(obj);
                    } else {
                        if (i11 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        u0.F(obj);
                    }
                    return p039d8.l.f16813a;
                }
                u0.F(obj);
                interfaceC0087f3 = this.f1438t;
                Object obj7 = this.f1439u;
                this.f1438t = interfaceC0087f3;
                this.f1437s = 1;
                obj = this.f1440v.invoke(obj7, this);
                if (obj == aVar3) {
                    return aVar3;
                }
                this.f1438t = null;
                this.f1437s = 2;
                if (interfaceC0087f3.emit(obj, this) == aVar3) {
                    return aVar3;
                }
                return p039d8.l.f16813a;
        }
    }
}
