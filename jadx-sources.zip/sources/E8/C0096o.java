package E8;

/* JADX INFO: renamed from: E8.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0096o extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public kotlin.jvm.internal.o f1524r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f1525s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f1526t;

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1525s = obj;
        this.f1526t |= Integer.MIN_VALUE;
        return P.f(null, null, this);
    }
}
