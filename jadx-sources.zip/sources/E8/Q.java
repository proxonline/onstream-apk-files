package E8;

import B8.C0042h;
import F8.AbstractC0105b;
import F8.AbstractC0107d;

/* JADX INFO: loaded from: classes.dex */
public final class Q extends AbstractC0107d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f1467a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public C0042h f1468b;

    @Override // F8.AbstractC0107d
    public final boolean a(AbstractC0105b abstractC0105b) {
        O o4 = (O) abstractC0105b;
        if (this.f1467a >= 0) {
            return false;
        }
        long j = o4.f1461i;
        if (j < o4.j) {
            o4.j = j;
        }
        this.f1467a = j;
        return true;
    }

    @Override // F8.AbstractC0107d
    public final h8.d[] b(AbstractC0105b abstractC0105b) {
        long j = this.f1467a;
        this.f1467a = -1L;
        this.f1468b = null;
        return ((O) abstractC0105b).s(j);
    }
}
