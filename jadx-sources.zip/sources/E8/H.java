package E8;

/* JADX INFO: loaded from: classes.dex */
public interface H extends L, InterfaceC0087f {
    boolean c(Object obj);
}
