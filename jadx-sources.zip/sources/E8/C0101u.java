package E8;

/* JADX INFO: renamed from: E8.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0101u extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public C0102v f1542r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f1543s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public /* synthetic */ Object f1544t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ C0102v f1545u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f1546v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0101u(C0102v c0102v, p093j8.c cVar) {
        super(cVar);
        this.f1545u = c0102v;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1544t = obj;
        this.f1546v |= Integer.MIN_VALUE;
        return this.f1545u.emit(null, this);
    }
}
