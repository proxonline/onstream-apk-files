package E8;

/* JADX INFO: renamed from: E8.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0087f {
    Object emit(Object obj, h8.d dVar);
}
