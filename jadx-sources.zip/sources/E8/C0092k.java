package E8;

import Y.C0452q;
import p195v5.u0;

/* JADX INFO: renamed from: E8.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0092k implements InterfaceC0086e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0098q f1508a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0452q f1509b;

    public C0092k(C0098q c0098q, C0452q c0452q) {
        this.f1508a = c0098q;
        this.f1509b = c0452q;
    }

    /* JADX WARN: Code duplicated, block: B:35:0x007b  */
    /* JADX WARN: Code duplicated, block: B:56:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    @Override // E8.InterfaceC0086e
    public final Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar) throws Throwable {
        C0091j c0091j;
        C0092k c0092k;
        W w6;
        C0452q c0452q;
        F8.z zVar;
        Throwable th;
        F8.z zVar2;
        C0452q c0452q2;
        if (dVar instanceof C0091j) {
            c0091j = (C0091j) dVar;
            int i9 = c0091j.f1504s;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                c0091j.f1504s = i9 - Integer.MIN_VALUE;
            } else {
                c0091j = new C0091j(this, dVar);
            }
        } else {
            c0091j = new C0091j(this, dVar);
        }
        Object obj = c0091j.f1503r;
        int i10 = c0091j.f1504s;
        p084i8.a aVar = p084i8.a.f19475a;
        if (i10 == 0) {
            u0.F(obj);
            try {
                C0098q c0098q = this.f1508a;
                c0091j.f1506u = this;
                c0091j.f1507v = interfaceC0087f;
                c0091j.f1504s = 1;
                if (c0098q.collect(interfaceC0087f, c0091j) != aVar) {
                    c0092k = this;
                    zVar = new F8.z(interfaceC0087f, c0091j.getContext());
                    c0452q2 = c0092k.f1509b;
                    c0091j.f1506u = zVar;
                    c0091j.f1507v = null;
                    c0091j.f1504s = 3;
                    if (c0452q2.invoke(zVar, null, c0091j) != aVar) {
                        zVar2 = zVar;
                        zVar2.releaseIntercepted();
                        return p039d8.l.f16813a;
                    }
                }
            } catch (Throwable th2) {
                th = th2;
                c0092k = this;
                w6 = new W(th);
                c0452q = c0092k.f1509b;
                c0091j.f1506u = th;
                c0091j.f1507v = null;
                c0091j.f1504s = 2;
                if (P.c(w6, c0452q, th, c0091j) == aVar) {
                    throw th;
                }
            }
            return aVar;
        }
        if (i10 != 1) {
            if (i10 == 2) {
                Throwable th3 = (Throwable) c0091j.f1506u;
                u0.F(obj);
                throw th3;
            }
            if (i10 != 3) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zVar2 = (F8.z) c0091j.f1506u;
            try {
                u0.F(obj);
                zVar2.releaseIntercepted();
                return p039d8.l.f16813a;
            } catch (Throwable th4) {
                th = th4;
                zVar2.releaseIntercepted();
                throw th;
            }
        }
        interfaceC0087f = c0091j.f1507v;
        c0092k = (C0092k) c0091j.f1506u;
        try {
            u0.F(obj);
            zVar = new F8.z(interfaceC0087f, c0091j.getContext());
            try {
                c0452q2 = c0092k.f1509b;
                c0091j.f1506u = zVar;
                c0091j.f1507v = null;
                c0091j.f1504s = 3;
                if (c0452q2.invoke(zVar, null, c0091j) != aVar) {
                    zVar2 = zVar;
                    zVar2.releaseIntercepted();
                    return p039d8.l.f16813a;
                }
            } catch (Throwable th5) {
                th = th5;
                zVar2 = zVar;
                zVar2.releaseIntercepted();
                throw th;
            }
        } catch (Throwable th6) {
            th = th6;
            w6 = new W(th);
            c0452q = c0092k.f1509b;
            c0091j.f1506u = th;
            c0091j.f1507v = null;
            c0091j.f1504s = 2;
            if (P.c(w6, c0452q, th, c0091j) == aVar) {
                throw th;
            }
        }
        return aVar;
    }
}
