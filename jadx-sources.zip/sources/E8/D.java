package E8;

import B8.C0058s;
import Y.C0438c;
import Y.X;
import Y.Y;
import p017b6.AbstractC0590t;
import p017b6.C0592v;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class D implements InterfaceC0087f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1429a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0087f f1430b;

    public /* synthetic */ D(InterfaceC0087f interfaceC0087f, int i9) {
        this.f1429a = i9;
        this.f1430b = interfaceC0087f;
    }

    public D(InterfaceC0087f interfaceC0087f, p017b6.K k9) {
        this.f1429a = 2;
        this.f1430b = interfaceC0087f;
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0069  */
    /* JADX WARN: Code duplicated, block: B:58:0x00d5  */
    /* JADX WARN: Code duplicated, block: B:9:0x0018  */
    @Override // E8.InterfaceC0087f
    public final Object emit(Object obj, h8.d dVar) throws Throwable {
        C c10;
        Y.r rVar;
        p017b6.H h6;
        switch (this.f1429a) {
            case 0:
                if (dVar instanceof C) {
                    c10 = (C) dVar;
                    int i9 = c10.f1427s;
                    if ((i9 & Integer.MIN_VALUE) != 0) {
                        c10.f1427s = i9 - Integer.MIN_VALUE;
                    } else {
                        c10 = new C(this, (p093j8.c) dVar);
                    }
                } else {
                    c10 = new C(this, (p093j8.c) dVar);
                }
                Object obj2 = c10.f1426r;
                int i10 = c10.f1427s;
                if (i10 == 0) {
                    u0.F(obj2);
                    if (obj != null) {
                        c10.f1427s = 1;
                        Object objEmit = this.f1430b.emit(obj, c10);
                        p084i8.a aVar = p084i8.a.f19475a;
                        if (objEmit == aVar) {
                            return aVar;
                        }
                    }
                } else {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    u0.F(obj2);
                }
                return p039d8.l.f16813a;
            case 1:
                if (dVar instanceof Y.r) {
                    rVar = (Y.r) dVar;
                    int i11 = rVar.f9304s;
                    if ((i11 & Integer.MIN_VALUE) != 0) {
                        rVar.f9304s = i11 - Integer.MIN_VALUE;
                    } else {
                        rVar = new Y.r(this, (p093j8.c) dVar);
                    }
                } else {
                    rVar = new Y.r(this, (p093j8.c) dVar);
                }
                Object obj3 = rVar.f9303r;
                int i12 = rVar.f9304s;
                if (i12 == 0) {
                    u0.F(obj3);
                    X x5 = (X) obj;
                    if (x5 instanceof Y.P) {
                        throw ((Y.P) x5).f9225b;
                    }
                    if (!(x5 instanceof C0438c)) {
                        if (x5 instanceof Y.N ? true : x5 instanceof Y) {
                            throw new IllegalStateException("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                        }
                        throw new C0058s();
                    }
                    Object obj4 = ((C0438c) x5).f9252b;
                    rVar.f9304s = 1;
                    Object objEmit2 = this.f1430b.emit(obj4, rVar);
                    p084i8.a aVar2 = p084i8.a.f19475a;
                    if (objEmit2 == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i12 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    u0.F(obj3);
                }
                return p039d8.l.f16813a;
            default:
                if (dVar instanceof p017b6.H) {
                    h6 = (p017b6.H) dVar;
                    int i13 = h6.f11513s;
                    if ((i13 & Integer.MIN_VALUE) != 0) {
                        h6.f11513s = i13 - Integer.MIN_VALUE;
                    } else {
                        h6 = new p017b6.H(this, (p093j8.c) dVar);
                    }
                } else {
                    h6 = new p017b6.H(this, (p093j8.c) dVar);
                }
                Object obj5 = h6.f11512r;
                int i14 = h6.f11513s;
                if (i14 == 0) {
                    u0.F(obj5);
                    C0592v c0592v = new C0592v((String) ((p021c0.b) obj).c(AbstractC0590t.f11669c));
                    h6.f11513s = 1;
                    Object objEmit3 = this.f1430b.emit(c0592v, h6);
                    p084i8.a aVar3 = p084i8.a.f19475a;
                    if (objEmit3 == aVar3) {
                        return aVar3;
                    }
                } else {
                    if (i14 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    u0.F(obj5);
                }
                return p039d8.l.f16813a;
        }
    }
}
