package E8;

/* JADX INFO: renamed from: E8.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0088g extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public InterfaceC0087f f1492r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public D8.t f1493s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public D8.b f1494t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f1495u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public /* synthetic */ Object f1496v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f1497w;

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1496v = obj;
        this.f1497w |= Integer.MIN_VALUE;
        return P.j(null, null, false, this);
    }
}
