package E8;

/* JADX INFO: renamed from: E8.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0095n extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f1519r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1520s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C0094m f1521t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public C0094m f1522u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public InterfaceC0087f f1523v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0095n(C0094m c0094m, h8.d dVar) {
        super(dVar);
        this.f1521t = c0094m;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1519r = obj;
        this.f1520s |= Integer.MIN_VALUE;
        return this.f1521t.collect(null, this);
    }
}
