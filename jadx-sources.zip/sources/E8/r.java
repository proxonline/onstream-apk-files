package E8;

/* JADX INFO: loaded from: classes.dex */
public final class r extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f1533r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ C0099s f1534s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f1535t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(C0099s c0099s, p093j8.c cVar) {
        super(cVar);
        this.f1534s = c0099s;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1533r = obj;
        this.f1535t |= Integer.MIN_VALUE;
        return this.f1534s.emit(null, this);
    }
}
