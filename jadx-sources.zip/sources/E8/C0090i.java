package E8;

/* JADX INFO: renamed from: E8.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0090i extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Throwable f1500r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f1501s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f1502t;

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1501s = obj;
        this.f1502t |= Integer.MIN_VALUE;
        return P.c(null, null, null, this);
    }
}
