package E8;

/* JADX INFO: loaded from: classes.dex */
public interface S extends L {
    Object getValue();
}
