package E8;

/* JADX INFO: renamed from: E8.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0097p extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public C0084c f1527r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f1528s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C0084c f1529t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f1530u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0097p(C0084c c0084c, p093j8.c cVar) {
        super(cVar);
        this.f1529t = c0084c;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1528s = obj;
        this.f1530u |= Integer.MIN_VALUE;
        return this.f1529t.emit(null, this);
    }
}
