package E8;

import F8.C0104a;
import p195v5.u0;

/* JADX INFO: renamed from: E8.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0100t implements InterfaceC0086e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1539a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0086e f1540b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ p093j8.i f1541c;

    /* JADX WARN: Multi-variable type inference failed */
    public C0100t(InterfaceC0086e interfaceC0086e, p167r8.p pVar, int i9) {
        this.f1539a = i9;
        switch (i9) {
            case 1:
                this.f1540b = interfaceC0086e;
                this.f1541c = (p093j8.i) pVar;
                break;
            default:
                this.f1540b = interfaceC0086e;
                this.f1541c = (p093j8.i) pVar;
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:31:0x0058  */
    /* JADX WARN: Code duplicated, block: B:9:0x0018  */
    /* JADX WARN: Type inference failed for: r2v0, types: [j8.i, r8.p] */
    /* JADX WARN: Type inference failed for: r3v0, types: [j8.i, r8.p] */
    @Override // E8.InterfaceC0086e
    public final Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar) {
        C0103w c0103w;
        C0099s c0099s;
        switch (this.f1539a) {
            case 0:
                Object objCollect = this.f1540b.collect(new C0102v(new kotlin.jvm.internal.l(), interfaceC0087f, this.f1541c), dVar);
                return objCollect == p084i8.a.f19475a ? objCollect : p039d8.l.f16813a;
            default:
                if (dVar instanceof C0103w) {
                    c0103w = (C0103w) dVar;
                    int i9 = c0103w.f1552s;
                    if ((i9 & Integer.MIN_VALUE) != 0) {
                        c0103w.f1552s = i9 - Integer.MIN_VALUE;
                    } else {
                        c0103w = new C0103w(this, dVar);
                    }
                } else {
                    c0103w = new C0103w(this, dVar);
                }
                Object obj = c0103w.f1551r;
                int i10 = c0103w.f1552s;
                if (i10 != 0) {
                    if (i10 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    c0099s = c0103w.f1554u;
                    try {
                        u0.F(obj);
                    } catch (C0104a e9) {
                        e = e9;
                        if (e.f1739a != c0099s) {
                            throw e;
                        }
                    }
                    break;
                } else {
                    u0.F(obj);
                    InterfaceC0086e interfaceC0086e = this.f1540b;
                    C0099s c0099s2 = new C0099s((p167r8.p) this.f1541c, interfaceC0087f);
                    try {
                        c0103w.f1554u = c0099s2;
                        c0103w.f1552s = 1;
                        Object objCollect2 = interfaceC0086e.collect(c0099s2, c0103w);
                        p084i8.a aVar = p084i8.a.f19475a;
                        if (objCollect2 == aVar) {
                            return aVar;
                        }
                    } catch (C0104a e10) {
                        e = e10;
                        c0099s = c0099s2;
                        if (e.f1739a != c0099s) {
                            throw e;
                        }
                    }
                }
                return p039d8.l.f16813a;
        }
    }
}
