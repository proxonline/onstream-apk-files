package E8;

/* JADX INFO: loaded from: classes.dex */
public final class E extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f1431r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1432s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C0099s f1433t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object f1434u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public InterfaceC0087f f1435v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public E(C0099s c0099s, p093j8.c cVar) {
        super(cVar);
        this.f1433t = c0099s;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f1431r = obj;
        this.f1432s |= Integer.MIN_VALUE;
        return this.f1433t.emit(null, this);
    }
}
