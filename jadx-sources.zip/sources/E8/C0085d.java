package E8;

import F8.AbstractC0106c;

/* JADX INFO: renamed from: E8.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0085d implements InterfaceC0086e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InterfaceC0086e f1491a;

    public C0085d(InterfaceC0086e interfaceC0086e) {
        this.f1491a = interfaceC0086e;
    }

    @Override // E8.InterfaceC0086e
    public final Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar) {
        kotlin.jvm.internal.o oVar = new kotlin.jvm.internal.o();
        oVar.f21067a = AbstractC0106c.f1745b;
        Object objCollect = this.f1491a.collect(new C0084c(this, oVar, interfaceC0087f), dVar);
        return objCollect == p084i8.a.f19475a ? objCollect : p039d8.l.f16813a;
    }
}
