package E8;

import B7.C0021h;
import B8.C0045i0;
import B8.InterfaceC0047j0;
import F8.AbstractC0106c;
import F8.C0104a;
import Y.C0452q;
import co.notix.lc;
import com.google.android.gms.internal.cast.z1;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.NoSuchElementException;
import java.util.concurrent.CancellationException;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public abstract class P {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final G8.w f1464a = new G8.w("NO_VALUE", 0);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final G8.w f1465b = new G8.w("NONE", 0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final G8.w f1466c = new G8.w("PENDING", 0);

    public static O a(int i9) {
        int i10 = (i9 & 1) != 0 ? 0 : 1;
        D8.a aVar = (i9 & 4) != 0 ? D8.a.f1125a : D8.a.f1126b;
        if (i10 < 0) {
            throw new IllegalArgumentException(z1.k("replay cannot be negative, but was ", i10).toString());
        }
        if (i10 > 0 || aVar == D8.a.f1125a) {
            return new O(i10, i10 < 0 ? Integer.MAX_VALUE : i10, aVar);
        }
        throw new IllegalArgumentException(("replay or extraBufferCapacity must be positive with non-default onBufferOverflow strategy " + aVar).toString());
    }

    public static final U b(Object obj) {
        if (obj == null) {
            obj = AbstractC0106c.f1745b;
        }
        return new U(obj);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object c(W w6, C0452q c0452q, Throwable th, p093j8.c cVar) throws IllegalAccessException, InvocationTargetException {
        C0090i c0090i;
        if (cVar instanceof C0090i) {
            c0090i = (C0090i) cVar;
            int i9 = c0090i.f1502t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                c0090i.f1502t = i9 - Integer.MIN_VALUE;
            } else {
                c0090i = new C0090i(cVar);
            }
        } else {
            c0090i = new C0090i(cVar);
        }
        Object obj = c0090i.f1501s;
        int i10 = c0090i.f1502t;
        try {
            if (i10 == 0) {
                u0.F(obj);
                c0090i.f1500r = th;
                c0090i.f1502t = 1;
                Object objInvoke = c0452q.invoke(w6, th, c0090i);
                Object obj2 = p084i8.a.f19475a;
                if (objInvoke == obj2) {
                    return obj2;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                th = c0090i.f1500r;
                u0.F(obj);
            }
            return p039d8.l.f16813a;
        } catch (Throwable th2) {
            if (th != null && th != th2) {
                p054f5.b.a(th2, th);
            }
            throw th2;
        }
    }

    public static final void d(Object[] objArr, long j, Object obj) {
        objArr[((int) j) & (objArr.length - 1)] = obj;
    }

    public static InterfaceC0086e e(InterfaceC0086e interfaceC0086e, int i9) {
        D8.a aVar;
        if (i9 < 0 && i9 != -2 && i9 != -1) {
            throw new IllegalArgumentException(z1.k("Buffer size should be non-negative, BUFFERED, or CONFLATED, but was ", i9).toString());
        }
        if (i9 == -1) {
            i9 = 0;
            aVar = D8.a.f1126b;
        } else {
            aVar = D8.a.f1125a;
        }
        boolean z9 = interfaceC0086e instanceof F8.v;
        h8.j jVar = h8.j.f18937a;
        return z9 ? ((F8.v) interfaceC0086e).a(jVar, i9, aVar) : new F8.i(interfaceC0086e, jVar, i9, aVar);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Serializable f(InterfaceC0086e interfaceC0086e, InterfaceC0087f interfaceC0087f, p093j8.c cVar) throws Throwable {
        C0096o c0096o;
        kotlin.jvm.internal.o oVar;
        InterfaceC0047j0 interfaceC0047j0;
        CancellationException cancellationExceptionJ;
        if (cVar instanceof C0096o) {
            c0096o = (C0096o) cVar;
            int i9 = c0096o.f1526t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                c0096o.f1526t = i9 - Integer.MIN_VALUE;
            } else {
                c0096o = new C0096o(cVar);
            }
        } else {
            c0096o = new C0096o(cVar);
        }
        Object obj = c0096o.f1525s;
        int i10 = c0096o.f1526t;
        if (i10 == 0) {
            u0.F(obj);
            kotlin.jvm.internal.o oVar2 = new kotlin.jvm.internal.o();
            try {
                InterfaceC0087f c0084c = new C0084c(interfaceC0087f, oVar2);
                c0096o.f1524r = oVar2;
                c0096o.f1526t = 1;
                Object objCollect = interfaceC0086e.collect(c0084c, c0096o);
                p084i8.a aVar = p084i8.a.f19475a;
                if (objCollect == aVar) {
                    return aVar;
                }
                return null;
            } catch (Throwable th) {
                th = th;
                oVar = oVar2;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            oVar = c0096o.f1524r;
            try {
                u0.F(obj);
                return null;
            } catch (Throwable th2) {
                th = th2;
            }
        }
        Throwable th3 = (Throwable) oVar.f21067a;
        if ((th3 != null && th3.equals(th)) || ((interfaceC0047j0 = (InterfaceC0047j0) c0096o.getContext().get(C0045i0.f483a)) != null && interfaceC0047j0.isCancelled() && (cancellationExceptionJ = interfaceC0047j0.J()) != null && cancellationExceptionJ.equals(th))) {
            throw th;
        }
        if (th3 == null) {
            return th;
        }
        if (th instanceof CancellationException) {
            p054f5.b.a(th3, th);
            throw th3;
        }
        p054f5.b.a(th, th3);
        throw th;
    }

    public static final Object g(InterfaceC0086e interfaceC0086e, h8.d dVar) {
        Object objCollect = interfaceC0086e.collect(F8.x.f1801a, dVar);
        return objCollect == p084i8.a.f19475a ? objCollect : p039d8.l.f16813a;
    }

    public static final Object h(InterfaceC0086e interfaceC0086e, p167r8.p pVar, h8.d dVar) {
        int i9 = y.f1560a;
        Object objG = g(e(new F8.n(new F(pVar, (p093j8.c) null), interfaceC0086e, h8.j.f18937a, -2, D8.a.f1125a), 0), dVar);
        return objG == p084i8.a.f19475a ? objG : p039d8.l.f16813a;
    }

    public static final InterfaceC0086e i(InterfaceC0086e interfaceC0086e) {
        return ((interfaceC0086e instanceof S) || (interfaceC0086e instanceof C0085d)) ? interfaceC0086e : new C0085d(interfaceC0086e);
    }

    /* JADX WARN: Code duplicated, block: B:27:0x006e  */
    /* JADX WARN: Code duplicated, block: B:28:0x006f  */
    /* JADX WARN: Code duplicated, block: B:31:0x007a A[Catch: all -> 0x0036, TryCatch #1 {all -> 0x0036, blocks: (B:13:0x002f, B:25:0x005e, B:29:0x0072, B:31:0x007a, B:33:0x0080, B:35:0x0086, B:38:0x0097, B:39:0x009f, B:40:0x00a0, B:41:0x00a7, B:20:0x0049, B:24:0x0054), top: B:60:0x0021 }] */
    /* JADX WARN: Code duplicated, block: B:33:0x0080 A[Catch: all -> 0x0036, TryCatch #1 {all -> 0x0036, blocks: (B:13:0x002f, B:25:0x005e, B:29:0x0072, B:31:0x007a, B:33:0x0080, B:35:0x0086, B:38:0x0097, B:39:0x009f, B:40:0x00a0, B:41:0x00a7, B:20:0x0049, B:24:0x0054), top: B:60:0x0021 }] */
    /* JADX WARN: Code duplicated, block: B:35:0x0086 A[Catch: all -> 0x0036, TryCatch #1 {all -> 0x0036, blocks: (B:13:0x002f, B:25:0x005e, B:29:0x0072, B:31:0x007a, B:33:0x0080, B:35:0x0086, B:38:0x0097, B:39:0x009f, B:40:0x00a0, B:41:0x00a7, B:20:0x0049, B:24:0x0054), top: B:60:0x0021 }] */
    /* JADX WARN: Code duplicated, block: B:38:0x0097 A[Catch: all -> 0x0036, TryCatch #1 {all -> 0x0036, blocks: (B:13:0x002f, B:25:0x005e, B:29:0x0072, B:31:0x007a, B:33:0x0080, B:35:0x0086, B:38:0x0097, B:39:0x009f, B:40:0x00a0, B:41:0x00a7, B:20:0x0049, B:24:0x0054), top: B:60:0x0021 }] */
    /* JADX WARN: Code duplicated, block: B:40:0x00a0 A[Catch: all -> 0x0036, TryCatch #1 {all -> 0x0036, blocks: (B:13:0x002f, B:25:0x005e, B:29:0x0072, B:31:0x007a, B:33:0x0080, B:35:0x0086, B:38:0x0097, B:39:0x009f, B:40:0x00a0, B:41:0x00a7, B:20:0x0049, B:24:0x0054), top: B:60:0x0021 }] */
    /* JADX WARN: Code duplicated, block: B:42:0x00a8 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:43:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0094, code lost:
    
        if (r1.emit(r11, r0) == r5) goto L37;
     */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:36:0x0094 -> B:14:0x0032). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Object j(E8.InterfaceC0087f r8, D8.q r9, boolean r10, p093j8.c r11) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 208
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: E8.P.j(E8.f, D8.q, boolean, j8.c):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:33:0x006b  */
    /* JADX WARN: Code duplicated, block: B:7:0x0015  */
    public static final Object k(InterfaceC0086e interfaceC0086e, p093j8.c cVar) {
        A a10;
        kotlin.jvm.internal.o oVar;
        C0104a e9;
        C0021h c0021h;
        G8.w wVar = AbstractC0106c.f1745b;
        if (cVar instanceof A) {
            a10 = (A) cVar;
            int i9 = a10.f1420u;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                a10.f1420u = i9 - Integer.MIN_VALUE;
            } else {
                a10 = new A(cVar);
            }
        } else {
            a10 = new A(cVar);
        }
        Object obj = a10.f1419t;
        int i10 = a10.f1420u;
        if (i10 == 0) {
            u0.F(obj);
            kotlin.jvm.internal.o oVar2 = new kotlin.jvm.internal.o();
            oVar2.f21067a = wVar;
            C0021h c0021h2 = new C0021h(1, oVar2);
            try {
                a10.f1417r = oVar2;
                a10.f1418s = c0021h2;
                a10.f1420u = 1;
                Object objCollect = interfaceC0086e.collect(c0021h2, a10);
                Object obj2 = p084i8.a.f19475a;
                if (objCollect == obj2) {
                    return obj2;
                }
                oVar = oVar2;
            } catch (C0104a e10) {
                oVar = oVar2;
                e9 = e10;
                c0021h = c0021h2;
                if (e9.f1739a != c0021h) {
                    throw e9;
                }
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            c0021h = a10.f1418s;
            oVar = a10.f1417r;
            try {
                u0.F(obj);
            } catch (C0104a e11) {
                e9 = e11;
                if (e9.f1739a != c0021h) {
                    throw e9;
                }
            }
        }
        Object obj3 = oVar.f21067a;
        if (obj3 != wVar) {
            return obj3;
        }
        throw new NoSuchElementException("Expected at least one element");
    }

    /* JADX WARN: Code duplicated, block: B:33:0x007d  */
    /* JADX WARN: Code duplicated, block: B:7:0x0015  */
    public static final Object l(C0098q c0098q, lc lcVar, p093j8.c cVar) {
        B b10;
        lc lcVar2;
        kotlin.jvm.internal.o oVar;
        C0104a e9;
        C0099s c0099s;
        G8.w wVar = AbstractC0106c.f1745b;
        if (cVar instanceof B) {
            b10 = (B) cVar;
            int i9 = b10.f1425v;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                b10.f1425v = i9 - Integer.MIN_VALUE;
            } else {
                b10 = new B(cVar);
            }
        } else {
            b10 = new B(cVar);
        }
        Object obj = b10.f1424u;
        int i10 = b10.f1425v;
        if (i10 == 0) {
            u0.F(obj);
            kotlin.jvm.internal.o oVar2 = new kotlin.jvm.internal.o();
            oVar2.f21067a = wVar;
            C0099s c0099s2 = new C0099s(lcVar, 2, oVar2);
            try {
                b10.f1421r = lcVar;
                b10.f1422s = oVar2;
                b10.f1423t = c0099s2;
                b10.f1425v = 1;
                Object objCollect = c0098q.collect(c0099s2, b10);
                Object obj2 = p084i8.a.f19475a;
                if (objCollect == obj2) {
                    return obj2;
                }
                lcVar2 = lcVar;
                oVar = oVar2;
            } catch (C0104a e10) {
                lcVar2 = lcVar;
                oVar = oVar2;
                e9 = e10;
                c0099s = c0099s2;
                if (e9.f1739a != c0099s) {
                    throw e9;
                }
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            c0099s = b10.f1423t;
            oVar = b10.f1422s;
            lcVar2 = b10.f1421r;
            try {
                u0.F(obj);
            } catch (C0104a e11) {
                e9 = e11;
                if (e9.f1739a != c0099s) {
                    throw e9;
                }
            }
        }
        Object obj3 = oVar.f21067a;
        if (obj3 != wVar) {
            return obj3;
        }
        throw new NoSuchElementException("Expected at least one element matching the predicate " + lcVar2);
    }

    public static final InterfaceC0086e m(L l9, h8.i iVar, int i9, D8.a aVar) {
        return ((i9 == 0 || i9 == -3) && aVar == D8.a.f1125a) ? l9 : new F8.i(l9, iVar, i9, aVar);
    }
}
