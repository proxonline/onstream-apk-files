package E8;

import p195v5.u0;

/* JADX INFO: renamed from: E8.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0089h extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f1498r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ C0094m f1499s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0089h(C0094m c0094m, h8.d dVar) {
        super(2, dVar);
        this.f1499s = c0094m;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new C0089h(this.f1499s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C0089h) create((B8.A) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f1498r;
        if (i9 == 0) {
            u0.F(obj);
            this.f1498r = 1;
            Object objG = P.g(this.f1499s, this);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objG == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return p039d8.l.f16813a;
    }
}
