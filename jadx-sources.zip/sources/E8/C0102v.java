package E8;

import F8.AbstractC0106c;
import G8.AbstractC0165a;
import p195v5.u0;

/* JADX INFO: renamed from: E8.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0102v implements InterfaceC0087f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1547a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f1548b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f1549c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p093j8.i f1550d;

    public C0102v(InterfaceC0087f interfaceC0087f, h8.i iVar) {
        this.f1548b = iVar;
        this.f1549c = AbstractC0165a.l(iVar);
        this.f1550d = new F8.G(interfaceC0087f, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public C0102v(kotlin.jvm.internal.l lVar, InterfaceC0087f interfaceC0087f, p167r8.p pVar) {
        this.f1548b = lVar;
        this.f1549c = interfaceC0087f;
        this.f1550d = (p093j8.i) pVar;
    }

    /* JADX WARN: Code duplicated, block: B:14:0x002e  */
    /* JADX WARN: Type inference failed for: r9v6, types: [j8.i, r8.p] */
    @Override // E8.InterfaceC0087f
    public final Object emit(Object obj, h8.d dVar) {
        C0101u c0101u;
        C0102v c0102v;
        switch (this.f1547a) {
            case 0:
                if (dVar instanceof C0101u) {
                    c0101u = (C0101u) dVar;
                    int i9 = c0101u.f1546v;
                    if ((i9 & Integer.MIN_VALUE) != 0) {
                        c0101u.f1546v = i9 - Integer.MIN_VALUE;
                    } else {
                        c0101u = new C0101u(this, (p093j8.c) dVar);
                    }
                } else {
                    c0101u = new C0101u(this, (p093j8.c) dVar);
                }
                Object objInvoke = c0101u.f1544t;
                int i10 = c0101u.f1546v;
                p039d8.l lVar = p039d8.l.f16813a;
                p084i8.a aVar = p084i8.a.f19475a;
                if (i10 != 0) {
                    if (i10 != 1) {
                        if (i10 == 2) {
                            obj = c0101u.f1543s;
                            c0102v = c0101u.f1542r;
                            u0.F(objInvoke);
                        } else if (i10 != 3) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                    u0.F(objInvoke);
                    return lVar;
                }
                u0.F(objInvoke);
                if (((kotlin.jvm.internal.l) this.f1548b).f21064a) {
                    InterfaceC0087f interfaceC0087f = (InterfaceC0087f) this.f1549c;
                    c0101u.f1546v = 1;
                    if (interfaceC0087f.emit(obj, c0101u) != aVar) {
                        return lVar;
                    }
                } else {
                    c0101u.f1542r = this;
                    c0101u.f1543s = obj;
                    c0101u.f1546v = 2;
                    objInvoke = this.f1550d.invoke(obj, c0101u);
                    if (objInvoke != aVar) {
                        c0102v = this;
                    }
                }
                return aVar;
                if (((Boolean) objInvoke).booleanValue()) {
                    return lVar;
                }
                ((kotlin.jvm.internal.l) c0102v.f1548b).f21064a = true;
                InterfaceC0087f interfaceC0087f2 = (InterfaceC0087f) c0102v.f1549c;
                c0101u.f1542r = null;
                c0101u.f1543s = null;
                c0101u.f1546v = 3;
                if (interfaceC0087f2.emit(obj, c0101u) != aVar) {
                    return lVar;
                }
                return aVar;
            default:
                Object objB = AbstractC0106c.b((h8.i) this.f1548b, obj, this.f1549c, (F8.G) this.f1550d, dVar);
                return objB == p084i8.a.f19475a ? objB : p039d8.l.f16813a;
        }
    }
}
