package E8;

/* JADX INFO: loaded from: classes.dex */
public final class J implements L, InterfaceC0086e, F8.v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ L f1444a;

    public J(H h6) {
        this.f1444a = h6;
    }

    @Override // F8.v
    public final InterfaceC0086e a(h8.i iVar, int i9, D8.a aVar) {
        return P.m(this, iVar, i9, aVar);
    }

    @Override // E8.InterfaceC0086e
    public final Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar) {
        return this.f1444a.collect(interfaceC0087f, dVar);
    }
}
