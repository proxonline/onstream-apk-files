package E8;

import F8.AbstractC0105b;
import F8.AbstractC0106c;
import F8.AbstractC0107d;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes.dex */
public final class V extends AbstractC0107d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AtomicReference f1479a = new AtomicReference(null);

    @Override // F8.AbstractC0107d
    public final boolean a(AbstractC0105b abstractC0105b) {
        AtomicReference atomicReference = this.f1479a;
        if (atomicReference.get() != null) {
            return false;
        }
        atomicReference.set(P.f1465b);
        return true;
    }

    @Override // F8.AbstractC0107d
    public final h8.d[] b(AbstractC0105b abstractC0105b) {
        this.f1479a.set(null);
        return AbstractC0106c.f1744a;
    }
}
