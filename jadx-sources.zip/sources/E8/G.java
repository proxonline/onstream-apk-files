package E8;

import F8.AbstractC0106c;
import co.notix.eg;

/* JADX INFO: loaded from: classes.dex */
public final class G implements InterfaceC0086e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0086e f1441a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0086e f1442b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ eg f1443c;

    public G(I i9, I i10, eg egVar) {
        this.f1441a = i9;
        this.f1442b = i10;
        this.f1443c = egVar;
    }

    @Override // E8.InterfaceC0086e
    public final Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar) throws Throwable {
        Object objA = AbstractC0106c.a(interfaceC0087f, dVar, new F(this.f1443c, (p093j8.c) null), new InterfaceC0086e[]{this.f1441a, this.f1442b});
        return objA == p084i8.a.f19475a ? objA : p039d8.l.f16813a;
    }
}
