package E8;

import B8.C0042h;
import F8.AbstractC0105b;
import F8.AbstractC0106c;
import F8.AbstractC0107d;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: loaded from: classes.dex */
public final class U extends AbstractC0105b implements I, InterfaceC0086e, F8.v {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ AtomicReferenceFieldUpdater f1477f = AtomicReferenceFieldUpdater.newUpdater(U.class, Object.class, "_state$volatile");
    private volatile /* synthetic */ Object _state$volatile;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1478e;

    public U(Object obj) {
        this._state$volatile = obj;
    }

    @Override // F8.v
    public final InterfaceC0086e a(h8.i iVar, int i9, D8.a aVar) {
        return (((i9 < 0 || i9 >= 2) && i9 != -2) || aVar != D8.a.f1126b) ? P.m(this, iVar, i9, aVar) : this;
    }

    @Override // E8.H
    public final boolean c(Object obj) {
        h(obj);
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:53:0x00e7 A[Catch: all -> 0x003e, TryCatch #0 {all -> 0x003e, blocks: (B:14:0x0039, B:28:0x007d, B:30:0x0085, B:33:0x008c, B:34:0x0090, B:36:0x0093, B:46:0x00b4, B:49:0x00c4, B:50:0x00e0, B:56:0x00f0, B:53:0x00e7, B:55:0x00ed, B:38:0x0099, B:42:0x00a0, B:21:0x0053, B:24:0x005d, B:27:0x006e), top: B:63:0x0027 }] */
    /* JADX WARN: Code duplicated, block: B:67:0x00ed A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:68:? A[LOOP:0: B:50:0x00e0->B:68:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x00c3 -> B:28:0x007d). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // E8.InterfaceC0086e
    public final java.lang.Object collect(E8.InterfaceC0087f r18, h8.d r19) {
        /*
            Method dump skipped, instruction units count: 254
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: E8.U.collect(E8.f, h8.d):java.lang.Object");
    }

    @Override // F8.AbstractC0105b
    public final AbstractC0107d d() {
        return new V();
    }

    @Override // F8.AbstractC0105b
    public final AbstractC0107d[] e() {
        return new V[2];
    }

    @Override // E8.InterfaceC0087f
    public final Object emit(Object obj, h8.d dVar) {
        h(obj);
        return p039d8.l.f16813a;
    }

    public final boolean g(Object obj, Object obj2) {
        G8.w wVar = AbstractC0106c.f1745b;
        if (obj == null) {
            obj = wVar;
        }
        if (obj2 == null) {
            obj2 = wVar;
        }
        return i(obj, obj2);
    }

    @Override // E8.S
    public final Object getValue() {
        G8.w wVar = AbstractC0106c.f1745b;
        Object obj = f1477f.get(this);
        if (obj == wVar) {
            return null;
        }
        return obj;
    }

    public final void h(Object obj) {
        if (obj == null) {
            obj = AbstractC0106c.f1745b;
        }
        i(null, obj);
    }

    public final boolean i(Object obj, Object obj2) {
        int i9;
        AbstractC0107d[] abstractC0107dArr;
        G8.w wVar;
        synchronized (this) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f1477f;
            Object obj3 = atomicReferenceFieldUpdater.get(this);
            if (obj != null && !kotlin.jvm.internal.h.a(obj3, obj)) {
                return false;
            }
            if (kotlin.jvm.internal.h.a(obj3, obj2)) {
                return true;
            }
            atomicReferenceFieldUpdater.set(this, obj2);
            int i10 = this.f1478e;
            if ((i10 & 1) != 0) {
                this.f1478e = i10 + 2;
                return true;
            }
            int i11 = i10 + 1;
            this.f1478e = i11;
            AbstractC0107d[] abstractC0107dArr2 = this.f1740a;
            while (true) {
                V[] vArr = (V[]) abstractC0107dArr2;
                if (vArr != null) {
                    for (V v9 : vArr) {
                        if (v9 != null) {
                            AtomicReference atomicReference = v9.f1479a;
                            while (true) {
                                Object obj4 = atomicReference.get();
                                if (obj4 == null || obj4 == (wVar = P.f1466c)) {
                                    break;
                                }
                                G8.w wVar2 = P.f1465b;
                                if (obj4 != wVar2) {
                                    do {
                                        if (atomicReference.compareAndSet(obj4, wVar2)) {
                                            ((C0042h) obj4).resumeWith(p039d8.l.f16813a);
                                            break;
                                        }
                                    } while (atomicReference.get() == obj4);
                                } else {
                                    do {
                                        if (atomicReference.compareAndSet(obj4, wVar)) {
                                            break;
                                        }
                                    } while (atomicReference.get() == obj4);
                                }
                            }
                        }
                    }
                }
                synchronized (this) {
                    i9 = this.f1478e;
                    if (i9 == i11) {
                        this.f1478e = i11 + 1;
                        return true;
                    }
                    abstractC0107dArr = this.f1740a;
                }
                abstractC0107dArr2 = abstractC0107dArr;
                i11 = i9;
            }
        }
    }
}
