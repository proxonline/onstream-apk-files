package E8;

/* JADX INFO: renamed from: E8.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0086e {
    Object collect(InterfaceC0087f interfaceC0087f, h8.d dVar);
}
