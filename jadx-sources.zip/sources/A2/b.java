package A2;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.cast.z1;
import p052f2.C0897a0;
import p052f2.N;

/* JADX INFO: loaded from: classes.dex */
public final class b implements p224z2.b {
    public static final Parcelable.Creator<b> CREATOR = new a(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f5a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f6b;

    public b(int i9, String str) {
        this.f5a = i9;
        this.f6b = str;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // p224z2.b
    public final /* synthetic */ void e(C0897a0 c0897a0) {
    }

    @Override // p224z2.b
    public final /* synthetic */ N g() {
        return null;
    }

    @Override // p224z2.b
    public final /* synthetic */ byte[] l() {
        return null;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Ait(controlCode=");
        sb.append(this.f5a);
        sb.append(",url=");
        return z1.m(sb, this.f6b, ")");
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i9) {
        parcel.writeString(this.f6b);
        parcel.writeInt(this.f5a);
    }
}
