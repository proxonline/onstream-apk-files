package A2;

import S8.y;
import V2.f;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import p224z2.e;

/* JADX INFO: loaded from: classes.dex */
public final class c extends p001a.a {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ int f7h;

    public static B2.a T(y yVar) {
        String strR = yVar.r();
        strR.getClass();
        String strR2 = yVar.r();
        strR2.getClass();
        return new B2.a(strR, strR2, yVar.q(), yVar.q(), Arrays.copyOfRange((byte[]) yVar.f7101c, yVar.f7099a, yVar.f7100b));
    }

    @Override // p001a.a
    public final p224z2.c n(e eVar, ByteBuffer byteBuffer) {
        switch (this.f7h) {
            case 0:
                if (byteBuffer.get() != 116) {
                    return null;
                }
                f fVar = new f(byteBuffer.limit(), byteBuffer.array());
                int i9 = 12;
                fVar.r(12);
                int iF = (fVar.f() + fVar.i(12)) - 4;
                fVar.r(44);
                fVar.s(fVar.i(12));
                fVar.r(16);
                ArrayList arrayList = new ArrayList();
                while (fVar.f() < iF) {
                    fVar.r(48);
                    int i10 = fVar.i(8);
                    fVar.r(4);
                    int iF2 = fVar.f() + fVar.i(i9);
                    String str = null;
                    String str2 = null;
                    while (fVar.f() < iF2) {
                        int i11 = fVar.i(8);
                        int i12 = fVar.i(8);
                        int iF3 = fVar.f() + i12;
                        if (i11 == 2) {
                            int i13 = fVar.i(16);
                            fVar.r(8);
                            if (i13 == 3) {
                                while (fVar.f() < iF3) {
                                    int i14 = fVar.i(8);
                                    Charset charset = K4.e.f3788a;
                                    byte[] bArr = new byte[i14];
                                    fVar.k(i14, bArr);
                                    String str3 = new String(bArr, charset);
                                    int i15 = fVar.i(8);
                                    for (int i16 = 0; i16 < i15; i16++) {
                                        fVar.s(fVar.i(8));
                                    }
                                    str = str3;
                                }
                            }
                        } else if (i11 == 21) {
                            Charset charset2 = K4.e.f3788a;
                            byte[] bArr2 = new byte[i12];
                            fVar.k(i12, bArr2);
                            str2 = new String(bArr2, charset2);
                        }
                        fVar.o(iF3 * 8);
                    }
                    fVar.o(iF2 * 8);
                    if (str != null && str2 != null) {
                        arrayList.add(new b(i10, str.concat(str2)));
                    }
                    i9 = 12;
                }
                if (arrayList.isEmpty()) {
                    return null;
                }
                return new p224z2.c(arrayList);
            default:
                return new p224z2.c(T(new y(byteBuffer.limit(), byteBuffer.array())));
        }
    }
}
