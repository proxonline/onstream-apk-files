package A2;

import B3.C0005f;
import B3.C0006g;
import B3.C0009j;
import B3.C0011l;
import B3.C0012m;
import B3.G;
import B3.r;
import B3.s;
import E2.e;
import E2.f;
import E2.k;
import E2.l;
import E2.m;
import E2.n;
import E2.o;
import android.accounts.Account;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import co.notix.R;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.BinderWrapper;
import com.google.android.gms.internal.measurement.AbstractC0734e2;
import com.google.android.gms.internal.measurement.I1;
import java.util.ArrayList;
import p208x3.d;

/* JADX INFO: loaded from: classes.dex */
public final class a implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4a;

    public /* synthetic */ a(int i9) {
        this.f4a = i9;
    }

    public static void a(C0006g c0006g, Parcel parcel, int i9) {
        int iK = AbstractC0734e2.K(parcel, 20293);
        int i10 = c0006g.f223a;
        AbstractC0734e2.O(parcel, 1, 4);
        parcel.writeInt(i10);
        int i11 = c0006g.f224b;
        AbstractC0734e2.O(parcel, 2, 4);
        parcel.writeInt(i11);
        int i12 = c0006g.f225c;
        AbstractC0734e2.O(parcel, 3, 4);
        parcel.writeInt(i12);
        AbstractC0734e2.G(parcel, 4, c0006g.f226d);
        AbstractC0734e2.C(parcel, 5, c0006g.f227e);
        AbstractC0734e2.I(parcel, 6, c0006g.f228f, i9);
        AbstractC0734e2.B(parcel, 7, c0006g.f229g);
        AbstractC0734e2.F(parcel, 8, c0006g.f230h, i9);
        AbstractC0734e2.I(parcel, 10, c0006g.f231i, i9);
        AbstractC0734e2.I(parcel, 11, c0006g.j, i9);
        boolean z9 = c0006g.f232k;
        AbstractC0734e2.O(parcel, 12, 4);
        parcel.writeInt(z9 ? 1 : 0);
        int i13 = c0006g.f233l;
        AbstractC0734e2.O(parcel, 13, 4);
        parcel.writeInt(i13);
        boolean z10 = c0006g.f234m;
        AbstractC0734e2.O(parcel, 14, 4);
        parcel.writeInt(z10 ? 1 : 0);
        AbstractC0734e2.G(parcel, 15, c0006g.f235n);
        AbstractC0734e2.N(parcel, iK);
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f4a) {
            case 0:
                String string = parcel.readString();
                string.getClass();
                return new b(parcel.readInt(), string);
            case 1:
                int iP = I1.P(parcel);
                int I9 = 0;
                int I10 = 0;
                Uri uri = null;
                int I11 = 0;
                while (parcel.dataPosition() < iP) {
                    int i9 = parcel.readInt();
                    char c10 = (char) i9;
                    if (c10 == 1) {
                        I9 = I1.I(parcel, i9);
                    } else if (c10 == 2) {
                        uri = (Uri) I1.m(parcel, i9, Uri.CREATOR);
                    } else if (c10 == 3) {
                        I11 = I1.I(parcel, i9);
                    } else if (c10 != 4) {
                        I1.M(parcel, i9);
                    } else {
                        I10 = I1.I(parcel, i9);
                    }
                }
                I1.u(parcel, iP);
                return new A3.a(I9, uri, I11, I10);
            case 2:
                return new B2.a(parcel);
            case 3:
                int iP2 = I1.P(parcel);
                ArrayList arrayListR = null;
                int I12 = 0;
                while (parcel.dataPosition() < iP2) {
                    int i10 = parcel.readInt();
                    char c11 = (char) i10;
                    if (c11 == 1) {
                        I12 = I1.I(parcel, i10);
                    } else if (c11 != 2) {
                        I1.M(parcel, i10);
                    } else {
                        arrayListR = I1.r(parcel, i10, C0009j.CREATOR);
                    }
                }
                I1.u(parcel, iP2);
                return new C0012m(I12, arrayListR);
            case 4:
                int iP3 = I1.P(parcel);
                int I13 = -1;
                int I14 = 0;
                int I15 = 0;
                int I16 = 0;
                int I17 = 0;
                String strO = null;
                String strO2 = null;
                long J9 = 0;
                long J10 = 0;
                while (parcel.dataPosition() < iP3) {
                    int i11 = parcel.readInt();
                    switch ((char) i11) {
                        case 1:
                            I14 = I1.I(parcel, i11);
                            break;
                        case 2:
                            I15 = I1.I(parcel, i11);
                            break;
                        case 3:
                            I16 = I1.I(parcel, i11);
                            break;
                        case 4:
                            J9 = I1.J(parcel, i11);
                            break;
                        case 5:
                            J10 = I1.J(parcel, i11);
                            break;
                        case 6:
                            strO = I1.o(parcel, i11);
                            break;
                        case 7:
                            strO2 = I1.o(parcel, i11);
                            break;
                        case '\b':
                            I17 = I1.I(parcel, i11);
                            break;
                        case '\t':
                            I13 = I1.I(parcel, i11);
                            break;
                        default:
                            I1.M(parcel, i11);
                            break;
                    }
                }
                I1.u(parcel, iP3);
                return new C0009j(I14, I15, I16, J9, J10, strO, strO2, I17, I13);
            case 5:
                int iP4 = I1.P(parcel);
                Account account = null;
                int I18 = 0;
                int I19 = 0;
                GoogleSignInAccount googleSignInAccount = null;
                while (parcel.dataPosition() < iP4) {
                    int i12 = parcel.readInt();
                    char c12 = (char) i12;
                    if (c12 == 1) {
                        I18 = I1.I(parcel, i12);
                    } else if (c12 == 2) {
                        account = (Account) I1.m(parcel, i12, Account.CREATOR);
                    } else if (c12 == 3) {
                        I19 = I1.I(parcel, i12);
                    } else if (c12 != 4) {
                        I1.M(parcel, i12);
                    } else {
                        googleSignInAccount = (GoogleSignInAccount) I1.m(parcel, i12, GoogleSignInAccount.CREATOR);
                    }
                }
                I1.u(parcel, iP4);
                return new r(I18, account, I19, googleSignInAccount);
            case 6:
                int iP5 = I1.P(parcel);
                int I20 = 0;
                boolean zE = false;
                boolean zE2 = false;
                IBinder iBinderH = null;
                p208x3.b bVar = null;
                while (parcel.dataPosition() < iP5) {
                    int i13 = parcel.readInt();
                    char c13 = (char) i13;
                    if (c13 == 1) {
                        I20 = I1.I(parcel, i13);
                    } else if (c13 == 2) {
                        iBinderH = I1.H(parcel, i13);
                    } else if (c13 == 3) {
                        bVar = (p208x3.b) I1.m(parcel, i13, p208x3.b.CREATOR);
                    } else if (c13 == 4) {
                        zE = I1.E(parcel, i13);
                    } else if (c13 != 5) {
                        I1.M(parcel, i13);
                    } else {
                        zE2 = I1.E(parcel, i13);
                    }
                }
                I1.u(parcel, iP5);
                return new s(I20, iBinderH, bVar, zE, zE2);
            case 7:
                int iP6 = I1.P(parcel);
                int I21 = 0;
                int I22 = 0;
                int I23 = 0;
                boolean zE3 = false;
                boolean zE4 = false;
                while (parcel.dataPosition() < iP6) {
                    int i14 = parcel.readInt();
                    char c14 = (char) i14;
                    if (c14 == 1) {
                        I21 = I1.I(parcel, i14);
                    } else if (c14 == 2) {
                        zE3 = I1.E(parcel, i14);
                    } else if (c14 == 3) {
                        zE4 = I1.E(parcel, i14);
                    } else if (c14 == 4) {
                        I22 = I1.I(parcel, i14);
                    } else if (c14 != 5) {
                        I1.M(parcel, i14);
                    } else {
                        I23 = I1.I(parcel, i14);
                    }
                }
                I1.u(parcel, iP6);
                return new C0011l(I21, I22, I23, zE3, zE4);
            case 8:
                return new BinderWrapper(parcel);
            case 9:
                int iP7 = I1.P(parcel);
                Bundle bundleJ = null;
                C0005f c0005f = null;
                int I24 = 0;
                d[] dVarArr = null;
                while (parcel.dataPosition() < iP7) {
                    int i15 = parcel.readInt();
                    char c15 = (char) i15;
                    if (c15 == 1) {
                        bundleJ = I1.j(parcel, i15);
                    } else if (c15 == 2) {
                        dVarArr = (d[]) I1.q(parcel, i15, d.CREATOR);
                    } else if (c15 == 3) {
                        I24 = I1.I(parcel, i15);
                    } else if (c15 != 4) {
                        I1.M(parcel, i15);
                    } else {
                        c0005f = (C0005f) I1.m(parcel, i15, C0005f.CREATOR);
                    }
                }
                I1.u(parcel, iP7);
                G g4 = new G();
                g4.f161a = bundleJ;
                g4.f162b = dVarArr;
                g4.f163c = I24;
                g4.f164d = c0005f;
                return g4;
            case R.styleable.GradientColor_android_endX /* 10 */:
                int iP8 = I1.P(parcel);
                C0011l c0011l = null;
                int[] iArrK = null;
                int[] iArrK2 = null;
                boolean zE5 = false;
                boolean zE6 = false;
                int I25 = 0;
                while (parcel.dataPosition() < iP8) {
                    int i16 = parcel.readInt();
                    switch ((char) i16) {
                        case 1:
                            c0011l = (C0011l) I1.m(parcel, i16, C0011l.CREATOR);
                            break;
                        case 2:
                            zE5 = I1.E(parcel, i16);
                            break;
                        case 3:
                            zE6 = I1.E(parcel, i16);
                            break;
                        case 4:
                            iArrK = I1.k(parcel, i16);
                            break;
                        case 5:
                            I25 = I1.I(parcel, i16);
                            break;
                        case 6:
                            iArrK2 = I1.k(parcel, i16);
                            break;
                        default:
                            I1.M(parcel, i16);
                            break;
                    }
                }
                I1.u(parcel, iP8);
                return new C0005f(c0011l, zE5, zE6, iArrK, I25, iArrK2);
            case R.styleable.GradientColor_android_endY /* 11 */:
                int iP9 = I1.P(parcel);
                Bundle bundle = new Bundle();
                Scope[] scopeArr = C0006g.f221o;
                String strO3 = null;
                IBinder iBinderH2 = null;
                Account account2 = null;
                String strO4 = null;
                int I26 = 0;
                int I27 = 0;
                int I28 = 0;
                boolean zE7 = false;
                int I29 = 0;
                boolean zE8 = false;
                d[] dVarArr2 = C0006g.f222p;
                d[] dVarArr3 = dVarArr2;
                while (parcel.dataPosition() < iP9) {
                    int i17 = parcel.readInt();
                    switch ((char) i17) {
                        case 1:
                            I26 = I1.I(parcel, i17);
                            break;
                        case 2:
                            I27 = I1.I(parcel, i17);
                            break;
                        case 3:
                            I28 = I1.I(parcel, i17);
                            break;
                        case 4:
                            strO3 = I1.o(parcel, i17);
                            break;
                        case 5:
                            iBinderH2 = I1.H(parcel, i17);
                            break;
                        case 6:
                            scopeArr = (Scope[]) I1.q(parcel, i17, Scope.CREATOR);
                            break;
                        case 7:
                            bundle = I1.j(parcel, i17);
                            break;
                        case '\b':
                            account2 = (Account) I1.m(parcel, i17, Account.CREATOR);
                            break;
                        case '\t':
                        default:
                            I1.M(parcel, i17);
                            break;
                        case R.styleable.GradientColor_android_endX /* 10 */:
                            dVarArr2 = (d[]) I1.q(parcel, i17, d.CREATOR);
                            break;
                        case R.styleable.GradientColor_android_endY /* 11 */:
                            dVarArr3 = (d[]) I1.q(parcel, i17, d.CREATOR);
                            break;
                        case '\f':
                            zE7 = I1.E(parcel, i17);
                            break;
                        case '\r':
                            I29 = I1.I(parcel, i17);
                            break;
                        case 14:
                            zE8 = I1.E(parcel, i17);
                            break;
                        case 15:
                            strO4 = I1.o(parcel, i17);
                            break;
                    }
                }
                I1.u(parcel, iP9);
                return new C0006g(I26, I27, I28, strO3, iBinderH2, scopeArr, bundle, account2, dVarArr2, dVarArr3, zE7, I29, zE8, strO4);
            case 12:
                return new C2.a(parcel);
            case 13:
                return new C2.b(parcel);
            case 14:
                return new D2.b(parcel);
            case 15:
                return new D2.c(parcel);
            case 16:
                return new E2.a(parcel);
            case 17:
                return new E2.b(parcel);
            case 18:
                return new E2.c(parcel);
            case 19:
                return new E2.d(parcel);
            case 20:
                return new e(parcel);
            case 21:
                return new f(parcel);
            case 22:
                return new k(parcel);
            case 23:
                return new l(parcel);
            case 24:
                return new m(parcel);
            case 25:
                return new n(parcel);
            case 26:
                return new o(parcel);
            case 27:
                E4.e eVar = new E4.e(parcel);
                eVar.f1312a = parcel.readFloat();
                eVar.f1313b = parcel.readFloat();
                ArrayList arrayList = new ArrayList();
                eVar.f1314c = arrayList;
                parcel.readList(arrayList, Float.class.getClassLoader());
                eVar.f1315d = parcel.readFloat();
                eVar.f1316e = parcel.createBooleanArray()[0];
                return eVar;
            case 28:
                return new F2.a(parcel);
            default:
                return new F2.b(parcel);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i9) {
        switch (this.f4a) {
            case 0:
                return new b[i9];
            case 1:
                return new A3.a[i9];
            case 2:
                return new B2.a[i9];
            case 3:
                return new C0012m[i9];
            case 4:
                return new C0009j[i9];
            case 5:
                return new r[i9];
            case 6:
                return new s[i9];
            case 7:
                return new C0011l[i9];
            case 8:
                return new BinderWrapper[i9];
            case 9:
                return new G[i9];
            case R.styleable.GradientColor_android_endX /* 10 */:
                return new C0005f[i9];
            case R.styleable.GradientColor_android_endY /* 11 */:
                return new C0006g[i9];
            case 12:
                return new C2.a[i9];
            case 13:
                return new C2.b[i9];
            case 14:
                return new D2.b[i9];
            case 15:
                return new D2.c[i9];
            case 16:
                return new E2.a[i9];
            case 17:
                return new E2.b[i9];
            case 18:
                return new E2.c[i9];
            case 19:
                return new E2.d[i9];
            case 20:
                return new e[i9];
            case 21:
                return new f[i9];
            case 22:
                return new k[i9];
            case 23:
                return new l[i9];
            case 24:
                return new m[i9];
            case 25:
                return new n[i9];
            case 26:
                return new o[i9];
            case 27:
                return new E4.e[i9];
            case 28:
                return new F2.a[i9];
            default:
                return new F2.b[i9];
        }
    }
}
