package p034d3;

import G6.C0149h;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C0149h f16702c = new C0149h(7);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e f16703a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f16704b;

    public d(e eVar, int i9) {
        this.f16703a = eVar;
        this.f16704b = i9;
    }
}
