package p034d3;

import java.util.regex.Pattern;
import p052f2.j0;
import p071h3.y;

/* JADX INFO: loaded from: classes.dex */
public abstract class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Pattern f16725a = Pattern.compile("^NOTE([ \t].*)?$");

    public static float a(String str) {
        if (str.endsWith("%")) {
            return Float.parseFloat(str.substring(0, str.length() - 1)) / 100.0f;
        }
        throw new NumberFormatException("Percentages must end with %");
    }

    public static long b(String str) {
        int i9 = y.f18900a;
        String[] strArrSplit = str.split("\\.", 2);
        long j = 0;
        for (String str2 : strArrSplit[0].split(":", -1)) {
            j = (j * 60) + Long.parseLong(str2);
        }
        long j9 = j * 1000;
        if (strArrSplit.length == 2) {
            j9 += Long.parseLong(strArrSplit[1]);
        }
        return j9 * 1000;
    }

    public static void c(S8.y yVar) throws j0 {
        int i9 = yVar.f7099a;
        String strJ = yVar.j();
        if (strJ == null || !strJ.startsWith("WEBVTT")) {
            yVar.H(i9);
            throw j0.a("Expected WEBVTT. Got " + yVar.j(), null);
        }
    }
}
