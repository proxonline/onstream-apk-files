package p034d3;

/* JADX INFO: loaded from: classes.dex */
public final class f implements Comparable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f16709a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final b f16710b;

    public f(int i9, b bVar) {
        this.f16709a = i9;
        this.f16710b = bVar;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return Integer.compare(this.f16709a, ((f) obj).f16709a);
    }
}
