package p034d3;

import java.util.Collections;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16688f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f16690h;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public float f16696o;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f16683a = "";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f16684b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Set f16685c = Collections.EMPTY_SET;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f16686d = "";

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f16687e = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f16689g = false;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f16691i = false;
    public final int j = -1;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f16692k = -1;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f16693l = -1;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f16694m = -1;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f16695n = -1;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f16697p = -1;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f16698q = false;

    public static int a(String str, int i9, int i10, String str2) {
        if (str.isEmpty() || i9 == -1) {
            return i9;
        }
        if (str.equals(str2)) {
            return i9 + i10;
        }
        return -1;
    }
}
