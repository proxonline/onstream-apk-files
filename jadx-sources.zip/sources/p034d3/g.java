package p034d3;

import U2.a;
import android.text.Layout;
import com.google.android.gms.internal.cast.z1;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f16713c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f16711a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f16712b = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16714d = 2;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f16715e = -3.4028235E38f;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16716f = 1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f16717g = 0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f16718h = -3.4028235E38f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f16719i = Integer.MIN_VALUE;
    public float j = 1.0f;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f16720k = Integer.MIN_VALUE;

    /* JADX WARN: Code duplicated, block: B:20:0x0032  */
    /* JADX WARN: Code duplicated, block: B:21:0x0034  */
    /* JADX WARN: Code duplicated, block: B:29:0x004f  */
    /* JADX WARN: Code duplicated, block: B:31:0x0055  */
    /* JADX WARN: Code duplicated, block: B:39:0x006b  */
    public final a a() {
        Layout.Alignment alignment;
        float f3 = this.f16718h;
        float f9 = -3.4028235E38f;
        if (f3 == -3.4028235E38f) {
            int i9 = this.f16714d;
            if (i9 != 4) {
                f3 = i9 != 5 ? 0.5f : 1.0f;
            } else {
                f3 = 0.0f;
            }
        }
        int i10 = this.f16719i;
        if (i10 == Integer.MIN_VALUE) {
            int i11 = this.f16714d;
            if (i11 == 1) {
                i10 = 0;
            } else if (i11 == 3) {
                i10 = 2;
            } else if (i11 == 4) {
                i10 = 0;
            } else if (i11 != 5) {
                i10 = 1;
            } else {
                i10 = 2;
            }
        }
        a aVar = new a();
        int i12 = this.f16714d;
        if (i12 == 1) {
            alignment = Layout.Alignment.ALIGN_NORMAL;
        } else if (i12 == 2) {
            alignment = Layout.Alignment.ALIGN_CENTER;
        } else if (i12 == 3) {
            alignment = Layout.Alignment.ALIGN_OPPOSITE;
        } else if (i12 == 4) {
            alignment = Layout.Alignment.ALIGN_NORMAL;
        } else if (i12 != 5) {
            z1.u("Unknown textAlignment: ", i12, "WebvttCueParser");
            alignment = null;
        } else {
            alignment = Layout.Alignment.ALIGN_OPPOSITE;
        }
        aVar.f7447c = alignment;
        float f10 = this.f16715e;
        int i13 = this.f16716f;
        if (f10 != -3.4028235E38f && i13 == 0 && (f10 < 0.0f || f10 > 1.0f)) {
            f9 = 1.0f;
        } else if (f10 != -3.4028235E38f) {
            f9 = f10;
        } else if (i13 == 0) {
            f9 = 1.0f;
        }
        aVar.f7449e = f9;
        aVar.f7450f = i13;
        aVar.f7451g = this.f16717g;
        aVar.f7452h = f3;
        aVar.f7453i = i10;
        float f11 = this.j;
        if (i10 == 0) {
            f3 = 1.0f - f3;
        } else if (i10 == 1) {
            f3 = f3 <= 0.5f ? f3 * 2.0f : (1.0f - f3) * 2.0f;
        } else if (i10 != 2) {
            throw new IllegalStateException(String.valueOf(i10));
        }
        aVar.f7455l = Math.min(f11, f3);
        aVar.f7459p = this.f16720k;
        CharSequence charSequence = this.f16713c;
        if (charSequence != null) {
            aVar.f7445a = charSequence;
        }
        return aVar;
    }
}
