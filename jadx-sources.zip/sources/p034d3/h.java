package p034d3;

import S8.y;
import Y2.a;
import Y2.c;
import android.graphics.Color;
import android.text.SpannableStringBuilder;
import android.text.SpannedString;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import j$.util.DesugarCollections;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import p162r3.e;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Pattern f16721a = Pattern.compile("^(\\S+)\\s+-->\\s+(\\S+)(.*)?$");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Pattern f16722b = Pattern.compile("(\\S+?):(\\S+)");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Map f16723c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Map f16724d;

    static {
        HashMap map = new HashMap();
        map.put("white", Integer.valueOf(Color.rgb(255, 255, 255)));
        map.put("lime", Integer.valueOf(Color.rgb(0, 255, 0)));
        map.put("cyan", Integer.valueOf(Color.rgb(0, 255, 255)));
        map.put("red", Integer.valueOf(Color.rgb(255, 0, 0)));
        map.put("yellow", Integer.valueOf(Color.rgb(255, 255, 0)));
        map.put("magenta", Integer.valueOf(Color.rgb(255, 0, 255)));
        map.put("blue", Integer.valueOf(Color.rgb(0, 0, 255)));
        map.put("black", Integer.valueOf(Color.rgb(0, 0, 0)));
        f16723c = DesugarCollections.unmodifiableMap(map);
        HashMap map2 = new HashMap();
        map2.put("bg_white", Integer.valueOf(Color.rgb(255, 255, 255)));
        map2.put("bg_lime", Integer.valueOf(Color.rgb(0, 255, 0)));
        map2.put("bg_cyan", Integer.valueOf(Color.rgb(0, 255, 255)));
        map2.put("bg_red", Integer.valueOf(Color.rgb(255, 0, 0)));
        map2.put("bg_yellow", Integer.valueOf(Color.rgb(255, 255, 0)));
        map2.put("bg_magenta", Integer.valueOf(Color.rgb(255, 0, 255)));
        map2.put("bg_blue", Integer.valueOf(Color.rgb(0, 0, 255)));
        map2.put("bg_black", Integer.valueOf(Color.rgb(0, 0, 0)));
        f16724d = DesugarCollections.unmodifiableMap(map2);
    }

    public static void a(String str, e eVar, List list, SpannableStringBuilder spannableStringBuilder, List list2) {
        int i9;
        int i10;
        int i11;
        int i12 = eVar.f16706b;
        int length = spannableStringBuilder.length();
        String str2 = eVar.f16705a;
        str2.getClass();
        int i13 = -1;
        switch (str2) {
            case "":
            case "v":
            case "lang":
                break;
            case "b":
                spannableStringBuilder.setSpan(new StyleSpan(1), i12, length, 33);
                break;
            case "c":
                for (String str3 : eVar.f16708d) {
                    Map map = f16723c;
                    if (map.containsKey(str3)) {
                        spannableStringBuilder.setSpan(new ForegroundColorSpan(((Integer) map.get(str3)).intValue()), i12, length, 33);
                    } else {
                        Map map2 = f16724d;
                        if (map2.containsKey(str3)) {
                            spannableStringBuilder.setSpan(new BackgroundColorSpan(((Integer) map2.get(str3)).intValue()), i12, length, 33);
                        }
                    }
                }
                break;
            case "i":
                spannableStringBuilder.setSpan(new StyleSpan(2), i12, length, 33);
                break;
            case "u":
                spannableStringBuilder.setSpan(new UnderlineSpan(), i12, length, 33);
                break;
            case "ruby":
                int iC = c(list2, str, eVar);
                ArrayList arrayList = new ArrayList(list.size());
                arrayList.addAll(list);
                Collections.sort(arrayList, d.f16702c);
                int i14 = eVar.f16706b;
                int i15 = 0;
                int length2 = 0;
                while (i15 < arrayList.size()) {
                    if ("rt".equals(((d) arrayList.get(i15)).f16703a.f16705a)) {
                        d dVar = (d) arrayList.get(i15);
                        int iC2 = c(list2, str, dVar.f16703a);
                        if (iC2 == i13) {
                            iC2 = iC != i13 ? iC : 1;
                        }
                        int i16 = dVar.f16703a.f16706b - length2;
                        int i17 = dVar.f16704b - length2;
                        CharSequence charSequenceSubSequence = spannableStringBuilder.subSequence(i16, i17);
                        spannableStringBuilder.delete(i16, i17);
                        spannableStringBuilder.setSpan(new c(charSequenceSubSequence.toString(), iC2), i14, i16, 33);
                        length2 = charSequenceSubSequence.length() + length2;
                        i14 = i16;
                    }
                    i15++;
                    i13 = -1;
                }
                break;
            default:
                return;
        }
        ArrayList arrayListB = b(list2, str, eVar);
        for (int i18 = 0; i18 < arrayListB.size(); i18++) {
            b bVar = ((f) arrayListB.get(i18)).f16710b;
            int i19 = bVar.f16693l;
            if (i19 == -1 && bVar.f16694m == -1) {
                i9 = -1;
            } else {
                i9 = (bVar.f16694m == 1 ? (char) 2 : (char) 0) | (i19 == 1 ? (char) 1 : (char) 0);
            }
            if (i9 != -1) {
                int i20 = bVar.f16693l;
                if (i20 == -1 && bVar.f16694m == -1) {
                    i11 = -1;
                    i10 = 1;
                } else {
                    i10 = 1;
                    i11 = (i20 == 1 ? 1 : 0) | (bVar.f16694m == 1 ? 2 : 0);
                }
                e.a(spannableStringBuilder, new StyleSpan(i11), i12, length);
            } else {
                i10 = 1;
            }
            if (bVar.j == i10) {
                spannableStringBuilder.setSpan(new StrikethroughSpan(), i12, length, 33);
            }
            if (bVar.f16692k == i10) {
                spannableStringBuilder.setSpan(new UnderlineSpan(), i12, length, 33);
            }
            if (bVar.f16689g) {
                if (!bVar.f16689g) {
                    throw new IllegalStateException("Font color not defined");
                }
                e.a(spannableStringBuilder, new ForegroundColorSpan(bVar.f16688f), i12, length);
            }
            if (bVar.f16691i) {
                if (!bVar.f16691i) {
                    throw new IllegalStateException("Background color not defined.");
                }
                e.a(spannableStringBuilder, new BackgroundColorSpan(bVar.f16690h), i12, length);
            }
            if (bVar.f16687e != null) {
                e.a(spannableStringBuilder, new TypefaceSpan(bVar.f16687e), i12, length);
            }
            int i21 = bVar.f16695n;
            if (i21 == 1) {
                e.a(spannableStringBuilder, new AbsoluteSizeSpan((int) bVar.f16696o, true), i12, length);
            } else if (i21 == 2) {
                e.a(spannableStringBuilder, new RelativeSizeSpan(bVar.f16696o), i12, length);
            } else if (i21 == 3) {
                e.a(spannableStringBuilder, new RelativeSizeSpan(bVar.f16696o / 100.0f), i12, length);
            }
            if (bVar.f16698q) {
                spannableStringBuilder.setSpan(new a(), i12, length, 33);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v5, types: [int] */
    /* JADX WARN: Type inference failed for: r4v7 */
    /* JADX WARN: Type inference failed for: r4v8 */
    public static ArrayList b(List list, String str, e eVar) {
        ?? r9;
        int size;
        boolean zIsEmpty;
        ArrayList arrayList = new ArrayList();
        for (int i9 = 0; i9 < list.size(); i9++) {
            b bVar = (b) list.get(i9);
            String str2 = eVar.f16705a;
            Set set = eVar.f16708d;
            String str3 = eVar.f16707c;
            if (bVar.f16683a.isEmpty() && bVar.f16684b.isEmpty() && bVar.f16685c.isEmpty() && bVar.f16686d.isEmpty()) {
                zIsEmpty = TextUtils.isEmpty(str2);
            } else {
                int iA = b.a(bVar.f16686d, b.a(bVar.f16684b, b.a(bVar.f16683a, 0, 1073741824, str), 2, str2), 4, str3);
                if (iA == -1 || !set.containsAll(bVar.f16685c)) {
                    r9 = 0;
                } else {
                    size = iA + (bVar.f16685c.size() * 4);
                }
            }
            if (r9 > 0) {
                r9 = size;
                r9 = zIsEmpty;
                arrayList.add(new f(r9, bVar));
            } else {
                r9 = size;
                r9 = zIsEmpty;
            }
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    public static int c(List list, String str, e eVar) {
        ArrayList arrayListB = b(list, str, eVar);
        for (int i9 = 0; i9 < arrayListB.size(); i9++) {
            int i10 = ((f) arrayListB.get(i9)).f16710b.f16697p;
            if (i10 != -1) {
                return i10;
            }
        }
        return -1;
    }

    public static c d(y yVar, ArrayList arrayList) {
        String strJ = yVar.j();
        if (strJ != null) {
            Pattern pattern = f16721a;
            Matcher matcher = pattern.matcher(strJ);
            if (matcher.matches()) {
                return e(null, matcher, yVar, arrayList);
            }
            String strJ2 = yVar.j();
            if (strJ2 != null) {
                Matcher matcher2 = pattern.matcher(strJ2);
                if (matcher2.matches()) {
                    return e(strJ.trim(), matcher2, yVar, arrayList);
                }
            }
        }
        return null;
    }

    public static c e(String str, Matcher matcher, y yVar, ArrayList arrayList) {
        g gVar = new g();
        try {
            String strGroup = matcher.group(1);
            strGroup.getClass();
            gVar.f16711a = i.b(strGroup);
            String strGroup2 = matcher.group(2);
            strGroup2.getClass();
            gVar.f16712b = i.b(strGroup2);
            String strGroup3 = matcher.group(3);
            strGroup3.getClass();
            f(strGroup3, gVar);
            StringBuilder sb = new StringBuilder();
            String strJ = yVar.j();
            while (!TextUtils.isEmpty(strJ)) {
                if (sb.length() > 0) {
                    sb.append("\n");
                }
                sb.append(strJ.trim());
                strJ = yVar.j();
            }
            gVar.f16713c = g(str, sb.toString(), arrayList);
            return new c(gVar.a().a(), gVar.f16711a, gVar.f16712b);
        } catch (NumberFormatException unused) {
            p071h3.a.P("WebvttCueParser", "Skipping cue with bad header: " + matcher.group());
            return null;
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static void f(String str, g gVar) {
        int i9;
        int i10;
        int i11;
        Matcher matcher = f16722b.matcher(str);
        while (matcher.find()) {
            String strGroup = matcher.group(1);
            strGroup.getClass();
            String strGroup2 = matcher.group(2);
            strGroup2.getClass();
            try {
                if ("line".equals(strGroup)) {
                    h(strGroup2, gVar);
                } else {
                    if ("align".equals(strGroup)) {
                        switch (strGroup2) {
                            case "center":
                            case "middle":
                                i9 = 2;
                                break;
                            case "end":
                                i9 = 3;
                                break;
                            case "left":
                                i9 = 4;
                                break;
                            case "right":
                                i9 = 5;
                                break;
                            case "start":
                                i9 = 1;
                                break;
                            default:
                                p071h3.a.P("WebvttCueParser", "Invalid alignment value: ".concat(strGroup2));
                                i9 = 2;
                                break;
                        }
                        gVar.f16714d = i9;
                    } else if ("position".equals(strGroup)) {
                        int iIndexOf = strGroup2.indexOf(44);
                        if (iIndexOf != -1) {
                            String strSubstring = strGroup2.substring(iIndexOf + 1);
                            strSubstring.getClass();
                            switch (strSubstring) {
                                case "line-left":
                                case "start":
                                    i10 = 0;
                                    break;
                                case "center":
                                case "middle":
                                    i10 = 1;
                                    break;
                                case "line-right":
                                case "end":
                                    i10 = 2;
                                    break;
                                default:
                                    p071h3.a.P("WebvttCueParser", "Invalid anchor value: ".concat(strSubstring));
                                    i10 = Integer.MIN_VALUE;
                                    break;
                            }
                            gVar.f16719i = i10;
                            strGroup2 = strGroup2.substring(0, iIndexOf);
                        }
                        gVar.f16718h = i.a(strGroup2);
                    } else if ("size".equals(strGroup)) {
                        gVar.j = i.a(strGroup2);
                    } else if ("vertical".equals(strGroup)) {
                        if (strGroup2.equals("lr")) {
                            i11 = 2;
                        } else if (strGroup2.equals("rl")) {
                            i11 = 1;
                        } else {
                            p071h3.a.P("WebvttCueParser", "Invalid 'vertical' value: ".concat(strGroup2));
                            i11 = Integer.MIN_VALUE;
                        }
                        gVar.f16720k = i11;
                    } else {
                        p071h3.a.P("WebvttCueParser", "Unknown cue setting " + strGroup + ":" + strGroup2);
                    }
                }
            } catch (NumberFormatException unused) {
                p071h3.a.P("WebvttCueParser", "Skipping bad cue setting: " + matcher.group());
            }
        }
    }

    public static SpannedString g(String str, String str2, List list) {
        char c10;
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        ArrayDeque arrayDeque = new ArrayDeque();
        ArrayList arrayList = new ArrayList();
        int i9 = 0;
        while (true) {
            String strTrim = "";
            if (i9 >= str2.length()) {
                while (!arrayDeque.isEmpty()) {
                    a(str, (e) arrayDeque.pop(), arrayList, spannableStringBuilder, list);
                }
                a(str, new e("", 0, "", Collections.EMPTY_SET), Collections.EMPTY_LIST, spannableStringBuilder, list);
                return SpannedString.valueOf(spannableStringBuilder);
            }
            char cCharAt = str2.charAt(i9);
            if (cCharAt == '&') {
                i9++;
                int iIndexOf = str2.indexOf(59, i9);
                int iIndexOf2 = str2.indexOf(32, i9);
                if (iIndexOf == -1) {
                    iIndexOf = iIndexOf2;
                } else if (iIndexOf2 != -1) {
                    iIndexOf = Math.min(iIndexOf, iIndexOf2);
                }
                if (iIndexOf != -1) {
                    String strSubstring = str2.substring(i9, iIndexOf);
                    strSubstring.getClass();
                    switch (strSubstring) {
                        case "gt":
                            spannableStringBuilder.append('>');
                            break;
                        case "lt":
                            spannableStringBuilder.append('<');
                            break;
                        case "amp":
                            spannableStringBuilder.append('&');
                            break;
                        case "nbsp":
                            spannableStringBuilder.append(' ');
                            break;
                        default:
                            p071h3.a.P("WebvttCueParser", "ignoring unsupported entity: '&" + strSubstring + ";'");
                            break;
                    }
                    if (iIndexOf == iIndexOf2) {
                        spannableStringBuilder.append((CharSequence) " ");
                    }
                    i9 = iIndexOf + 1;
                } else {
                    spannableStringBuilder.append(cCharAt);
                }
            } else if (cCharAt != '<') {
                spannableStringBuilder.append(cCharAt);
                i9++;
            } else {
                int length = i9 + 1;
                if (length < str2.length()) {
                    boolean z9 = str2.charAt(length) == '/';
                    int iIndexOf3 = str2.indexOf(62, length);
                    length = iIndexOf3 == -1 ? str2.length() : iIndexOf3 + 1;
                    int i10 = length - 2;
                    boolean z10 = str2.charAt(i10) == '/';
                    int i11 = i9 + (z9 ? 2 : 1);
                    if (!z10) {
                        i10 = length - 1;
                    }
                    String strSubstring2 = str2.substring(i11, i10);
                    if (!strSubstring2.trim().isEmpty()) {
                        String strTrim2 = strSubstring2.trim();
                        p071h3.a.h(!strTrim2.isEmpty());
                        int i12 = p071h3.y.f18900a;
                        String str3 = strTrim2.split("[ \\.]", 2)[0];
                        str3.getClass();
                        switch (str3) {
                            case "b":
                            case "c":
                            case "i":
                            case "u":
                            case "v":
                            case "rt":
                            case "lang":
                            case "ruby":
                                if (!z9) {
                                    if (!z10) {
                                        int length2 = spannableStringBuilder.length();
                                        String strTrim3 = strSubstring2.trim();
                                        p071h3.a.h(!strTrim3.isEmpty());
                                        int iIndexOf4 = strTrim3.indexOf(" ");
                                        if (iIndexOf4 == -1) {
                                            c10 = 0;
                                        } else {
                                            strTrim = strTrim3.substring(iIndexOf4).trim();
                                            c10 = 0;
                                            strTrim3 = strTrim3.substring(0, iIndexOf4);
                                        }
                                        String[] strArrSplit = strTrim3.split("\\.", -1);
                                        String str4 = strArrSplit[c10];
                                        HashSet hashSet = new HashSet();
                                        for (int i13 = 1; i13 < strArrSplit.length; i13++) {
                                            hashSet.add(strArrSplit[i13]);
                                        }
                                        arrayDeque.push(new e(str4, length2, strTrim, hashSet));
                                    }
                                    break;
                                } else {
                                    while (!arrayDeque.isEmpty()) {
                                        e eVar = (e) arrayDeque.pop();
                                        a(str, eVar, arrayList, spannableStringBuilder, list);
                                        if (arrayDeque.isEmpty()) {
                                            arrayList.clear();
                                        } else {
                                            arrayList.add(new d(eVar, spannableStringBuilder.length()));
                                        }
                                        if (eVar.f16705a.equals(str3)) {
                                            break;
                                        }
                                    }
                                    break;
                                }
                                break;
                        }
                    }
                }
                i9 = length;
            }
        }
    }

    public static void h(String str, g gVar) {
        int iIndexOf = str.indexOf(44);
        if (iIndexOf != -1) {
            String strSubstring = str.substring(iIndexOf + 1);
            strSubstring.getClass();
            int i9 = 2;
            switch (strSubstring) {
                case "center":
                case "middle":
                    i9 = 1;
                    break;
                case "end":
                    break;
                case "start":
                    i9 = 0;
                    break;
                default:
                    p071h3.a.P("WebvttCueParser", "Invalid anchor value: ".concat(strSubstring));
                    i9 = Integer.MIN_VALUE;
                    break;
            }
            gVar.f16717g = i9;
            str = str.substring(0, iIndexOf);
        }
        if (str.endsWith("%")) {
            gVar.f16715e = i.a(str);
            gVar.f16716f = 0;
        } else {
            gVar.f16715e = Integer.parseInt(str);
            gVar.f16716f = 1;
        }
    }
}
