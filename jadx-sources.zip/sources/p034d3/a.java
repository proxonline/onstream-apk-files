package p034d3;

import S8.y;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Pattern f16679c = Pattern.compile("\\[voice=\"([^\"]*)\"\\]");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Pattern f16680d = Pattern.compile("^((?:[0-9]*\\.)?[0-9]+)(px|em|%)$");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final y f16681a = new y(5, false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final StringBuilder f16682b = new StringBuilder();

    public static String a(y yVar, StringBuilder sb) {
        boolean z9 = false;
        sb.setLength(0);
        int i9 = yVar.f7099a;
        int i10 = yVar.f7100b;
        while (i9 < i10 && !z9) {
            char c10 = (char) ((byte[]) yVar.f7101c)[i9];
            if ((c10 < 'A' || c10 > 'Z') && ((c10 < 'a' || c10 > 'z') && !((c10 >= '0' && c10 <= '9') || c10 == '#' || c10 == '-' || c10 == '.' || c10 == '_'))) {
                z9 = true;
            } else {
                i9++;
                sb.append(c10);
            }
        }
        yVar.I(i9 - yVar.f7099a);
        return sb.toString();
    }

    public static String b(y yVar, StringBuilder sb) {
        c(yVar);
        if (yVar.e() == 0) {
            return null;
        }
        String strA = a(yVar, sb);
        if (!"".equals(strA)) {
            return strA;
        }
        return "" + ((char) yVar.x());
    }

    public static void c(y yVar) {
        while (true) {
            for (boolean z9 = true; yVar.e() > 0 && z9; z9 = false) {
                int i9 = yVar.f7099a;
                byte[] bArr = (byte[]) yVar.f7101c;
                byte b10 = bArr[i9];
                char c10 = (char) b10;
                if (c10 == '\t' || c10 == '\n' || c10 == '\f' || c10 == '\r' || c10 == ' ') {
                    yVar.I(1);
                } else {
                    int i10 = yVar.f7100b;
                    int i11 = i9 + 2;
                    if (i11 <= i10) {
                        int i12 = i9 + 1;
                        if (b10 == 47 && bArr[i12] == 42) {
                            while (true) {
                                int i13 = i11 + 1;
                                if (i13 >= i10) {
                                    break;
                                }
                                if (((char) bArr[i11]) == '*' && ((char) bArr[i13]) == '/') {
                                    i11 += 2;
                                    i10 = i11;
                                } else {
                                    i11 = i13;
                                }
                            }
                            yVar.I(i10 - yVar.f7099a);
                        }
                    }
                }
            }
            return;
        }
    }
}
