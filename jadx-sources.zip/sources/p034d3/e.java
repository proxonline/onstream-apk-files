package p034d3;

import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f16705a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f16706b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f16707c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Set f16708d;

    public e(String str, int i9, String str2, Set set) {
        this.f16706b = i9;
        this.f16705a = str;
        this.f16707c = str2;
        this.f16708d = set;
    }
}
