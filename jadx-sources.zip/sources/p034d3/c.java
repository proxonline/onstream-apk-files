package p034d3;

import U2.b;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f16699a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f16700b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f16701c;

    public c(b bVar, long j, long j9) {
        this.f16699a = bVar;
        this.f16700b = j;
        this.f16701c = j9;
    }
}
