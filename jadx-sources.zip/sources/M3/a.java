package M3;

import android.content.SharedPreferences;
import java.util.concurrent.Callable;

/* JADX INFO: loaded from: classes.dex */
public final class a implements Callable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4753a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ SharedPreferences f4754b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f4755c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f4756d;

    public /* synthetic */ a(SharedPreferences sharedPreferences, String str, Object obj, int i9) {
        this.f4753a = i9;
        this.f4754b = sharedPreferences;
        this.f4755c = str;
        this.f4756d = obj;
    }

    @Override // java.util.concurrent.Callable
    public final /* bridge */ /* synthetic */ Object call() {
        switch (this.f4753a) {
            case 0:
                return Boolean.valueOf(this.f4754b.getBoolean(this.f4755c, ((Boolean) this.f4756d).booleanValue()));
            case 1:
                return Integer.valueOf(this.f4754b.getInt(this.f4755c, ((Integer) this.f4756d).intValue()));
            case 2:
                return Long.valueOf(this.f4754b.getLong(this.f4755c, ((Long) this.f4756d).longValue()));
            default:
                return this.f4754b.getString(this.f4755c, (String) this.f4756d);
        }
    }
}
