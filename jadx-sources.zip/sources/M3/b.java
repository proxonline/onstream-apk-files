package M3;

import X3.BinderC0413u0;
import X3.C0378h0;
import X3.C0410t;
import X3.H1;
import X3.X;
import android.content.Context;
import android.os.Binder;
import android.os.Process;
import com.google.android.gms.internal.measurement.K1;
import java.util.concurrent.Callable;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Callable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4757a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f4758b;

    public /* synthetic */ b(int i9, Object obj) {
        this.f4757a = i9;
        this.f4758b = obj;
    }

    public b(BinderC0413u0 binderC0413u0, C0410t c0410t, String str) {
        this.f4757a = 2;
        this.f4758b = binderC0413u0;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        switch (this.f4757a) {
            case 0:
                return ((Context) this.f4758b).getSharedPreferences("google_sdk_flags", 0);
            case 1:
                return new K1(((C0378h0) this.f4758b).f8631k);
            case 2:
                BinderC0413u0 binderC0413u0 = (BinderC0413u0) this.f4758b;
                binderC0413u0.f8808e.w();
                X x5 = binderC0413u0.f8808e.f8244h;
                H1.R(x5);
                x5.r0();
                throw new IllegalStateException("Unexpected call on client side");
            default:
                p159r0.a aVar = (p159r0.a) this.f4758b;
                aVar.f22728d.set(true);
                try {
                    Process.setThreadPriority(10);
                    aVar.f22729e.d();
                    Binder.flushPendingCommands();
                    aVar.a(null);
                    return null;
                } catch (Throwable th) {
                    try {
                        aVar.f22727c.set(true);
                        throw th;
                    } catch (Throwable th2) {
                        aVar.a(null);
                        throw th2;
                    }
                }
        }
    }
}
