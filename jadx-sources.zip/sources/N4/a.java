package N4;

import T8.l;
import java.io.Serializable;
import java.util.AbstractList;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

/* JADX INFO: loaded from: classes.dex */
public final class a extends AbstractList implements RandomAccess, Serializable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f4971a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f4972b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f4973c;

    public a(int i9, int i10, int[] iArr) {
        this.f4971a = iArr;
        this.f4972b = i9;
        this.f4973c = i10;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        if (obj instanceof Integer) {
            return p012b1.a.G(this.f4971a, ((Integer) obj).intValue(), this.f4972b, this.f4973c) != -1;
        }
        return false;
    }

    @Override // java.util.AbstractList, java.util.Collection, java.util.List
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return super.equals(obj);
        }
        a aVar = (a) obj;
        int size = size();
        if (aVar.size() != size) {
            return false;
        }
        for (int i9 = 0; i9 < size; i9++) {
            if (this.f4971a[this.f4972b + i9] != aVar.f4971a[aVar.f4972b + i9]) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i9) {
        l.i(i9, size());
        return Integer.valueOf(this.f4971a[this.f4972b + i9]);
    }

    @Override // java.util.AbstractList, java.util.Collection, java.util.List
    public final int hashCode() {
        int i9 = 1;
        for (int i10 = this.f4972b; i10 < this.f4973c; i10++) {
            i9 = (i9 * 31) + this.f4971a[i10];
        }
        return i9;
    }

    @Override // java.util.AbstractList, java.util.List
    public final int indexOf(Object obj) {
        if (!(obj instanceof Integer)) {
            return -1;
        }
        int iIntValue = ((Integer) obj).intValue();
        int i9 = this.f4973c;
        int[] iArr = this.f4971a;
        int i10 = this.f4972b;
        int iG = p012b1.a.G(iArr, iIntValue, i10, i9);
        if (iG >= 0) {
            return iG - i10;
        }
        return -1;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean isEmpty() {
        return false;
    }

    @Override // java.util.AbstractList, java.util.List
    public final int lastIndexOf(Object obj) {
        int i9;
        if (obj instanceof Integer) {
            int iIntValue = ((Integer) obj).intValue();
            int i10 = this.f4973c;
            do {
                i10--;
                i9 = this.f4972b;
                if (i10 < i9) {
                    i10 = -1;
                    break;
                }
            } while (this.f4971a[i10] != iIntValue);
            if (i10 >= 0) {
                return i10 - i9;
            }
        }
        return -1;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i9, Object obj) {
        Integer num = (Integer) obj;
        l.i(i9, size());
        int i10 = this.f4972b + i9;
        int[] iArr = this.f4971a;
        int i11 = iArr[i10];
        num.getClass();
        iArr[i10] = num.intValue();
        return Integer.valueOf(i11);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f4973c - this.f4972b;
    }

    @Override // java.util.AbstractList, java.util.List
    public final List subList(int i9, int i10) {
        l.l(i9, i10, size());
        if (i9 == i10) {
            return Collections.EMPTY_LIST;
        }
        int i11 = this.f4972b;
        return new a(i9 + i11, i11 + i10, this.f4971a);
    }

    @Override // java.util.AbstractCollection
    public final String toString() {
        StringBuilder sb = new StringBuilder(size() * 5);
        sb.append('[');
        int[] iArr = this.f4971a;
        int i9 = this.f4972b;
        sb.append(iArr[i9]);
        while (true) {
            i9++;
            if (i9 >= this.f4973c) {
                sb.append(']');
                return sb.toString();
            }
            sb.append(", ");
            sb.append(iArr[i9]);
        }
    }
}
