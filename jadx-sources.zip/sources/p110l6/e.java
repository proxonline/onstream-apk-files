package p110l6;

import J8.a;
import p093j8.c;

/* JADX INFO: loaded from: classes.dex */
public final class e extends c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f21118r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public a f21119s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f21120t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public /* synthetic */ Object f21121u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ g f21122v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f21123w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(g gVar, c cVar) {
        super(cVar);
        this.f21122v = gVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f21121u = obj;
        this.f21123w |= Integer.MIN_VALUE;
        return this.f21122v.c(false, this);
    }
}
