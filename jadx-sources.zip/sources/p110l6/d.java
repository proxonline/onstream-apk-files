package p110l6;

import p093j8.c;

/* JADX INFO: loaded from: classes.dex */
public final class d extends c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public String f21114r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f21115s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ g f21116t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f21117u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(g gVar, c cVar) {
        super(cVar);
        this.f21116t = gVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f21115s = obj;
        this.f21117u |= Integer.MIN_VALUE;
        return this.f21116t.b(false, this);
    }
}
