package p110l6;

import p039d8.g;

/* JADX INFO: loaded from: classes.dex */
public final class c extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public g[] f21107r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public g[] f21108s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public String f21109t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f21110u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public /* synthetic */ Object f21111v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ g f21112w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f21113x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(g gVar, p093j8.c cVar) {
        super(cVar);
        this.f21112w = gVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f21111v = obj;
        this.f21113x |= Integer.MIN_VALUE;
        return this.f21112w.a(this);
    }
}
