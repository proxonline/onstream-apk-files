package p110l6;

import p093j8.c;

/* JADX INFO: loaded from: classes.dex */
public final class f extends c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f21124r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ g f21125s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f21126t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(g gVar, c cVar) {
        super(cVar);
        this.f21125s = gVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f21124r = obj;
        this.f21126t |= Integer.MIN_VALUE;
        return this.f21125s.d(null, this);
    }
}
