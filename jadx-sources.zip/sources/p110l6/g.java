package p110l6;

import J8.e;
import T8.l;
import a9.C0496o;
import com.maertsno.data.model.request.trakt.TraktRefreshTokenRequest;
import com.maertsno.data.model.response.trakt.TraktLoginResponse;
import java.io.Serializable;
import java.util.LinkedHashMap;
import kotlin.jvm.internal.h;
import p019b8.a;
import p048e8.r;
import p048e8.u;
import p064g6.o;
import p093j8.c;
import p130n6.d;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f21127a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f21128b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final J8.d f21129c;

    public g(a traktAuthService, d encryptedPreference) {
        h.e(traktAuthService, "traktAuthService");
        h.e(encryptedPreference, "encryptedPreference");
        this.f21127a = traktAuthService;
        this.f21128b = encryptedPreference;
        this.f21129c = e.a();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Serializable a(c cVar) throws Throwable {
        c cVar2;
        p039d8.g[] gVarArr;
        String str;
        p039d8.g[] pairs;
        int i9;
        if (cVar instanceof c) {
            cVar2 = (c) cVar;
            int i10 = cVar2.f21113x;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                cVar2.f21113x = i10 - Integer.MIN_VALUE;
            } else {
                cVar2 = new c(this, cVar);
            }
        } else {
            cVar2 = new c(this, cVar);
        }
        Object obj = cVar2.f21111v;
        int i11 = cVar2.f21113x;
        if (i11 == 0) {
            u0.F(obj);
            gVarArr = new p039d8.g[3];
            gVarArr[0] = new p039d8.g("trakt-api-version", "2");
            gVarArr[1] = new p039d8.g("trakt-api-key", o.f18389a.P0());
            cVar2.f21107r = gVarArr;
            cVar2.f21108s = gVarArr;
            cVar2.f21109t = "Authorization";
            cVar2.f21110u = 2;
            cVar2.f21113x = 1;
            Object objB = b(false, cVar2);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objB == aVar) {
                return aVar;
            }
            str = "Authorization";
            obj = objB;
            pairs = gVarArr;
            i9 = 2;
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            i9 = cVar2.f21110u;
            str = cVar2.f21109t;
            gVarArr = cVar2.f21108s;
            pairs = cVar2.f21107r;
            u0.F(obj);
        }
        gVarArr[i9] = new p039d8.g(str, obj);
        h.e(pairs, "pairs");
        if (pairs.length <= 0) {
            return r.f17245a;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(u.O(pairs.length));
        u.Q(linkedHashMap, pairs);
        return linkedHashMap;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object b(boolean z9, c cVar) throws Throwable {
        d dVar;
        String str;
        if (cVar instanceof d) {
            dVar = (d) cVar;
            int i9 = dVar.f21117u;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                dVar.f21117u = i9 - Integer.MIN_VALUE;
            } else {
                dVar = new d(this, cVar);
            }
        } else {
            dVar = new d(this, cVar);
        }
        Object obj = dVar.f21115s;
        int i10 = dVar.f21117u;
        if (i10 == 0) {
            u0.F(obj);
            String strG = o.f18389a.G();
            dVar.f21114r = strG;
            dVar.f21117u = 1;
            Object objC = c(z9, dVar);
            Object obj2 = p084i8.a.f19475a;
            if (objC == obj2) {
                return obj2;
            }
            obj = objC;
            str = strG;
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            str = dVar.f21114r;
            u0.F(obj);
        }
        return str + " " + obj;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    public final Object c(boolean z9, c cVar) throws Throwable {
        e eVar;
        boolean z10;
        J8.a aVar;
        int i9;
        J8.a aVar2;
        String str;
        if (cVar instanceof e) {
            eVar = (e) cVar;
            int i10 = eVar.f21123w;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                eVar.f21123w = i10 - Integer.MIN_VALUE;
            } else {
                eVar = new e(this, cVar);
            }
        } else {
            eVar = new e(this, cVar);
        }
        Object objD = eVar.f21121u;
        int i11 = eVar.f21123w;
        Object obj = p084i8.a.f19475a;
        try {
            if (i11 == 0) {
                u0.F(objD);
                J8.d dVar = this.f21129c;
                eVar.f21119s = dVar;
                z10 = z9;
                eVar.f21118r = z10;
                eVar.f21120t = 0;
                eVar.f21123w = 1;
                if (dVar.f(eVar) != obj) {
                    aVar = dVar;
                    i9 = 0;
                }
                return obj;
            }
            if (i11 != 1) {
                if (i11 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                aVar2 = eVar.f21119s;
                try {
                    u0.F(objD);
                    str = (String) objD;
                    aVar = aVar2;
                    aVar.a(null);
                    return str;
                } catch (Throwable th) {
                    th = th;
                    aVar2.a(null);
                    throw th;
                }
            }
            int i12 = eVar.f21120t;
            boolean z11 = eVar.f21118r;
            aVar = eVar.f21119s;
            u0.F(objD);
            i9 = i12;
            z10 = z11;
            TraktLoginResponse traktLoginResponseX = l.x(this.f21128b);
            if (traktLoginResponseX == null) {
                throw new p091j6.e();
            }
            String str2 = traktLoginResponseX.f16267d;
            if (str2 != null) {
                if (p229z8.e.j0(str2)) {
                    str2 = null;
                }
                if (str2 != null) {
                    int i13 = A8.a.f92d;
                    long jE = A8.a.e(I3.a.K(System.currentTimeMillis(), A8.c.MILLISECONDS), A8.c.SECONDS);
                    Long l9 = traktLoginResponseX.f16265b;
                    long jLongValue = l9 != null ? l9.longValue() : 0L;
                    Long l10 = traktLoginResponseX.f16266c;
                    long jLongValue2 = l10 != null ? l10.longValue() : 0L;
                    str = traktLoginResponseX.f16264a;
                    if (z10 || str == null || jE - jLongValue > jLongValue2) {
                        eVar.f21119s = aVar;
                        eVar.f21118r = z10;
                        eVar.f21120t = i9;
                        eVar.f21123w = 2;
                        objD = d(str2, eVar);
                        if (objD != obj) {
                            aVar2 = aVar;
                            str = (String) objD;
                            aVar = aVar2;
                        }
                        return obj;
                    }
                    aVar.a(null);
                    return str;
                }
            }
            throw new p091j6.e();
        } catch (Throwable th2) {
            th = th2;
            aVar2 = aVar;
            aVar2.a(null);
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object d(String str, c cVar) throws p091j6.e {
        f fVar;
        if (cVar instanceof f) {
            fVar = (f) cVar;
            int i9 = fVar.f21126t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                fVar.f21126t = i9 - Integer.MIN_VALUE;
            } else {
                fVar = new f(this, cVar);
            }
        } else {
            fVar = new f(this, cVar);
        }
        Object objA = fVar.f21124r;
        int i10 = fVar.f21126t;
        d dVar = this.f21128b;
        try {
            if (i10 == 0) {
                u0.F(objA);
                p175s6.h hVar = (p175s6.h) this.f21127a.get();
                o oVar = o.f18389a;
                TraktRefreshTokenRequest traktRefreshTokenRequest = new TraktRefreshTokenRequest(oVar.P0(), oVar.T0(), str, "refresh_token", oVar.R0());
                fVar.f21126t = 1;
                objA = hVar.a(traktRefreshTokenRequest, fVar);
                p084i8.a aVar = p084i8.a.f19475a;
                if (objA == aVar) {
                    return aVar;
                }
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                u0.F(objA);
            }
            TraktLoginResponse traktLoginResponse = (TraktLoginResponse) objA;
            l.M(dVar, traktLoginResponse);
            String str2 = traktLoginResponse.f16264a;
            if (str2 != null) {
                return str2;
            }
            throw new p091j6.e();
        } catch (C0496o unused) {
            l.M(dVar, null);
            l.N(dVar, null);
            throw new p091j6.e();
        }
    }
}
