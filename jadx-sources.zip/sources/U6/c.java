package U6;

import R6.s;

/* JADX INFO: loaded from: classes.dex */
public final class c extends s {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final D6.d f7539d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f7540e = "";

    public c(D6.d dVar) {
        this.f7539d = dVar;
        f(false, new b(this, null));
    }
}
