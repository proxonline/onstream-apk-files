package U6;

import B8.A;
import p039d8.l;
import p093j8.i;
import p167r8.p;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class b extends i implements p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ c f7538r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(c cVar, h8.d dVar) {
        super(2, dVar);
        this.f7538r = cVar;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new b(this.f7538r, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        b bVar = (b) create((A) obj, (h8.d) obj2);
        l lVar = l.f16813a;
        bVar.invokeSuspend(lVar);
        return lVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        u0.F(obj);
        c cVar = this.f7538r;
        cVar.f7540e = (String) cVar.f7539d.a().f16805a;
        return l.f16813a;
    }
}
