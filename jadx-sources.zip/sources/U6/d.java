package U6;

import R6.n;
import R6.s;
import W.g;
import Y7.f;
import Y7.h;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import androidx.lifecycle.d0;
import com.google.android.gms.internal.measurement.AbstractC0734e2;

/* JADX INFO: loaded from: classes.dex */
public abstract class d<V extends s, B extends g> extends n<V, B> implements p009a8.b {

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public h f7542w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public boolean f7543x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public volatile f f7544y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public final Object f7545z0 = new Object();

    /* JADX INFO: renamed from: A0, reason: collision with root package name */
    public boolean f7541A0 = false;

    @Override // p085j0.AbstractComponentCallbacksC1201y
    public final void F(Activity activity) {
        this.f20569Y = true;
        h hVar = this.f7542w0;
        I3.a.h(hVar == null || f.b(hVar) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        t0();
        if (this.f7541A0) {
            return;
        }
        this.f7541A0 = true;
        ((a) f()).getClass();
    }

    @Override // p085j0.AbstractComponentCallbacksC1201y
    public final void G(Context context) {
        super.G(context);
        t0();
        if (this.f7541A0) {
            return;
        }
        this.f7541A0 = true;
        ((a) f()).getClass();
    }

    @Override // p085j0.AbstractComponentCallbacksC1201y
    public final LayoutInflater M(Bundle bundle) {
        LayoutInflater layoutInflaterM = super.M(bundle);
        return layoutInflaterM.cloneInContext(new h(layoutInflaterM, this));
    }

    @Override // p009a8.b
    public final Object f() {
        if (this.f7544y0 == null) {
            synchronized (this.f7545z0) {
                try {
                    if (this.f7544y0 == null) {
                        this.f7544y0 = new f(this);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return this.f7544y0.f();
    }

    @Override // p085j0.AbstractComponentCallbacksC1201y
    public final Context n() {
        if (super.n() == null && !this.f7543x0) {
            return null;
        }
        t0();
        return this.f7542w0;
    }

    @Override // p085j0.AbstractComponentCallbacksC1201y, androidx.lifecycle.InterfaceC0541j
    public final d0 r() {
        return p012b1.a.y(this, super.r());
    }

    public final void t0() {
        if (this.f7542w0 == null) {
            this.f7542w0 = new h(super.n(), this);
            this.f7543x0 = AbstractC0734e2.s(super.n());
        }
    }
}
