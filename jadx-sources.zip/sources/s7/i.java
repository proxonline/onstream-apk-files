package s7;

import B7.C0021h;
import B8.C0058s;
import E8.U;
import com.maertsno.m.ui.select_player.SelectPlayerFragment;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class i extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23260r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ SelectPlayerFragment f23261s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(SelectPlayerFragment selectPlayerFragment, h8.d dVar) {
        super(2, dVar);
        this.f23261s = selectPlayerFragment;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new i(this.f23261s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        ((i) create((B8.A) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
        return p084i8.a.f19475a;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23260r;
        if (i9 != 0) {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
            throw new C0058s();
        }
        u0.F(obj);
        SelectPlayerFragment selectPlayerFragment = this.f23261s;
        U u4 = selectPlayerFragment.s0().f6812c;
        C0021h c0021h = new C0021h(8, selectPlayerFragment);
        this.f23260r = 1;
        u4.collect(c0021h, this);
        return p084i8.a.f19475a;
    }
}
