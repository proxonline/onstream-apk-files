package s7;

import com.maertsno.domain.type.MediaType;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f23251a;

    static {
        int[] iArr = new int[MediaType.values().length];
        try {
            iArr[2] = 1;
        } catch (NoSuchFieldError unused) {
        }
        f23251a = iArr;
    }
}
