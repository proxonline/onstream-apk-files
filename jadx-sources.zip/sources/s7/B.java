package s7;

import co.notix.R;
import com.maertsno.domain.model.Episode;
import com.maertsno.domain.model.Movie;
import com.maertsno.domain.type.MediaType;
import java.util.List;
import p195v5.u0;
import p219y6.E;

/* JADX INFO: loaded from: classes.dex */
public final class B extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Object f23224r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f23225s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C f23226t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Movie f23227u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public B(C c10, Movie movie, h8.d dVar) {
        super(2, dVar);
        this.f23226t = c10;
        this.f23227u = movie;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new B(this.f23226t, this.f23227u, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((B) create((B8.A) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
    }

    /* JADX WARN: Code duplicated, block: B:35:0x00af A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:36:0x00b0 A[RETURN] */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Object objS;
        int i9 = this.f23225s;
        Movie movie = this.f23227u;
        C c10 = this.f23226t;
        p039d8.l lVar = p039d8.l.f16813a;
        p084i8.a aVar = p084i8.a.f19475a;
        if (i9 == 0) {
            u0.F(obj);
            A5.e eVar = c10.f23233i;
            long j = movie.f16345a;
            this.f23225s = 1;
            objS = eVar.s(j, MediaType.TV_SERIES, this);
            if (objS != aVar) {
            }
            return aVar;
        }
        if (i9 != 1) {
            if (i9 == 2 || i9 == 3) {
                u0.F(obj);
                return lVar;
            }
            if (i9 != 4) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
            return lVar;
        }
        u0.F(obj);
        objS = ((p039d8.i) obj).f16808a;
        if (!(objS instanceof p039d8.h)) {
            List list = (List) objS;
            boolean zIsEmpty = list.isEmpty();
            C c11 = this.f23226t;
            if (zIsEmpty) {
                R6.y yVar = new R6.y(R.string.msg_no_seasons_available);
                this.f23224r = null;
                this.f23225s = 2;
                if (c11.g(yVar, this) == aVar) {
                    return aVar;
                }
                return lVar;
            }
            E e9 = (E) p048e8.i.j0(list);
            List list2 = e9.f26011g;
            if (list2.isEmpty()) {
                R6.y yVar2 = new R6.y(R.string.msg_no_episodes_available);
                this.f23224r = null;
                this.f23225s = 3;
                if (c11.g(yVar2, this) == aVar) {
                    return aVar;
                }
                return lVar;
            }
            Episode episode = (Episode) p048e8.i.j0(list2);
            c11.i(episode.f16320a, movie, episode.f16323d, e9.f26006b, episode.f16328i);
        }
        Throwable thA = p039d8.i.a(objS);
        if (thA != null) {
            this.f23224r = objS;
            this.f23225s = 4;
            if (c10.h(thA, this) == aVar) {
                return aVar;
            }
        }
        return lVar;
    }
}
