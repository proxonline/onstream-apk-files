package s7;

/* JADX INFO: loaded from: classes.dex */
public interface t {
}
