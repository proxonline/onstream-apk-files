package s7;

import B8.C0058s;
import com.maertsno.domain.model.EpisodeSource;
import com.maertsno.m.ui.select_player.SelectPlayerFragment;
import p195v5.u0;
import p200w0.F;

/* JADX INFO: loaded from: classes.dex */
public final class g extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f23256r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ SelectPlayerFragment f23257s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(SelectPlayerFragment selectPlayerFragment, h8.d dVar) {
        super(2, dVar);
        this.f23257s = selectPlayerFragment;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        g gVar = new g(this.f23257s, dVar);
        gVar.f23256r = obj;
        return gVar;
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        g gVar = (g) create((R6.w) obj, (h8.d) obj2);
        p039d8.l lVar = p039d8.l.f16813a;
        gVar.invokeSuspend(lVar);
        return lVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        SelectPlayerFragment selectPlayerFragment = this.f23257s;
        R6.w wVar = (R6.w) this.f23256r;
        u0.F(obj);
        Object objA = wVar.a();
        if (objA != null) {
            x xVar = (x) objA;
            if (xVar instanceof v) {
                try {
                    F fJ = p162r3.e.j(selectPlayerFragment);
                    EpisodeSource episodeSource = ((v) xVar).f23297a;
                    boolean z9 = selectPlayerFragment.r0().f23287b;
                    kotlin.jvm.internal.h.e(episodeSource, "episodeSource");
                    fJ.l(new s(episodeSource, z9));
                } catch (Exception unused) {
                }
            } else if (!xVar.equals(w.f23298a)) {
                throw new C0058s();
            }
        }
        return p039d8.l.f16813a;
    }
}
