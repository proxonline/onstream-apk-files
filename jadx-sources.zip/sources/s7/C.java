package s7;

import C6.C0067b;
import C6.C0071f;
import E8.P;
import E8.U;
import com.maertsno.domain.model.EpisodeSource;
import com.maertsno.domain.model.Movie;

/* JADX INFO: loaded from: classes.dex */
public final class C extends R6.s {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final A5.e f23228d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C0067b f23229e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final C0071f f23230f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final C6.o f23231g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final D6.f f23232h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final A5.e f23233i;
    public final F6.c j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final U f23234k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final U f23235l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public EpisodeSource f23236m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public String f23237n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public long f23238o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public long f23239p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public long f23240q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23241r;

    public C(A5.e eVar, C0067b addToHistoryUseCase, C0071f c0071f, C6.o oVar, D6.f customEventUseCase, A5.e eVar2, F6.c checkLoginUserCase) {
        kotlin.jvm.internal.h.e(addToHistoryUseCase, "addToHistoryUseCase");
        kotlin.jvm.internal.h.e(customEventUseCase, "customEventUseCase");
        kotlin.jvm.internal.h.e(checkLoginUserCase, "checkLoginUserCase");
        this.f23228d = eVar;
        this.f23229e = addToHistoryUseCase;
        this.f23230f = c0071f;
        this.f23231g = oVar;
        this.f23232h = customEventUseCase;
        this.f23233i = eVar2;
        this.j = checkLoginUserCase;
        this.f23234k = P.b(new R6.w(w.f23298a));
        this.f23235l = P.b(p048e8.q.f17244a);
        this.f23237n = "";
        f(true, new u(this, null));
    }

    public final void i(long j, Movie movie, long j9, int i9, long j10) {
        this.f23240q = j9;
        this.f23241r = i9;
        this.f23239p = movie.f16345a;
        this.f23238o = j10;
        this.f23237n = movie.f16348d;
        f(true, new A(this, j, movie, i9, null));
    }
}
