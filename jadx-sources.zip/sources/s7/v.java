package s7;

import com.maertsno.domain.model.EpisodeSource;

/* JADX INFO: loaded from: classes.dex */
public final class v implements x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final EpisodeSource f23297a;

    public v(EpisodeSource episode) {
        kotlin.jvm.internal.h.e(episode, "episode");
        this.f23297a = episode;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof v) && kotlin.jvm.internal.h.a(this.f23297a, ((v) obj).f23297a);
    }

    public final int hashCode() {
        return this.f23297a.hashCode();
    }

    public final String toString() {
        return "GetEpisode(episode=" + this.f23297a + ")";
    }
}
