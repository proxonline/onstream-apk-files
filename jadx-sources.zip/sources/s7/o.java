package s7;

import B8.D;
import com.maertsno.m.ui.select_player.SelectPlayerFragment;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class o extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f23280r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ SelectPlayerFragment f23281s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(SelectPlayerFragment selectPlayerFragment, h8.d dVar) {
        super(2, dVar);
        this.f23281s = selectPlayerFragment;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        o oVar = new o(this.f23281s, dVar);
        oVar.f23280r = obj;
        return oVar;
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        o oVar = (o) create((B8.A) obj, (h8.d) obj2);
        p039d8.l lVar = p039d8.l.f16813a;
        oVar.invokeSuspend(lVar);
        return lVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        B8.A a10 = (B8.A) this.f23280r;
        u0.F(obj);
        SelectPlayerFragment selectPlayerFragment = this.f23281s;
        D.r(a10, null, new f(selectPlayerFragment, null), 3);
        D.r(a10, null, new h(selectPlayerFragment, null), 3);
        D.r(a10, null, new i(selectPlayerFragment, null), 3);
        D.r(a10, null, new k(selectPlayerFragment, null), 3);
        D.r(a10, null, new n(selectPlayerFragment, null), 3);
        return p039d8.l.f16813a;
    }
}
