package s7;

import B8.D;
import B8.M;
import android.content.Intent;
import android.net.Uri;
import com.maertsno.m.ui.main.MainActivity;
import p182t6.T;
import p182t6.U;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class l implements p167r8.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f23266a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ MainActivity f23267b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f23268c;

    public /* synthetic */ l(Object obj, MainActivity mainActivity, int i9) {
        this.f23266a = i9;
        this.f23268c = obj;
        this.f23267b = mainActivity;
    }

    @Override // p167r8.a
    public final Object invoke() {
        switch (this.f23266a) {
            case 0:
                p219y6.C c10 = (p219y6.C) this.f23268c;
                MainActivity mainActivity = this.f23267b;
                try {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.setData(Uri.parse(c10.f26001h));
                    mainActivity.startActivity(intent);
                } catch (Exception unused) {
                    if (c10.f25994a == 1) {
                        U u4 = mainActivity.Y().f17181q.f717a;
                        D.r(u4.f23551d, M.f438b, new p120m6.b(30L, new T(u4, null), null), 2);
                    }
                }
                break;
            default:
                String str = (String) this.f23268c;
                Intent intent2 = new Intent("android.intent.action.VIEW");
                intent2.setData(Uri.parse(str));
                this.f23267b.startActivity(intent2);
                break;
        }
        return p039d8.l.f16813a;
    }
}
