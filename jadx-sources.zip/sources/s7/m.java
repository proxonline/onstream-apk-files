package s7;

import B8.D;
import B8.M;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import co.notix.R;
import com.maertsno.domain.model.EpisodeSource;
import com.maertsno.m.ui.main.MainActivity;
import com.maertsno.m.ui.select_player.SelectPlayerFragment;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import p182t6.T;
import p182t6.U;
import p195v5.u0;
import p219y6.G;
import p219y6.H;

/* JADX INFO: loaded from: classes.dex */
public final class m extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public EpisodeSource f23269r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public G f23270s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public p219y6.C f23271t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public String f23272u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public String f23273v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public long f23274w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f23275x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public /* synthetic */ Object f23276y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final /* synthetic */ SelectPlayerFragment f23277z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m(SelectPlayerFragment selectPlayerFragment, h8.d dVar) {
        super(2, dVar);
        this.f23277z = selectPlayerFragment;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        m mVar = new m(this.f23277z, dVar);
        mVar.f23276y = obj;
        return mVar;
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((m) create((H) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) throws UnsupportedEncodingException {
        long j;
        long j9;
        p219y6.C c10;
        String str;
        String strS;
        SelectPlayerFragment selectPlayerFragment;
        EpisodeSource episodeSource;
        h8.d dVar;
        G g4;
        Object objA;
        String str2;
        p219y6.C c11;
        String str3;
        EpisodeSource episodeSource2;
        G g9;
        String strEncode;
        String string;
        Object next;
        MainActivity mainActivity;
        MainActivity mainActivity2;
        H h6 = (H) this.f23276y;
        int i9 = this.f23275x;
        p039d8.l lVar = p039d8.l.f16813a;
        SelectPlayerFragment selectPlayerFragment2 = this.f23277z;
        if (i9 == 0) {
            u0.F(obj);
            EpisodeSource episodeSource3 = selectPlayerFragment2.s0().f23236m;
            if (episodeSource3 == null) {
                return lVar;
            }
            j = selectPlayerFragment2.s0().f23238o;
            List listA = episodeSource3.a(A6.d.f59a);
            if (listA.isEmpty() || p229z8.e.j0(((G) p048e8.i.j0(listA)).f26017a)) {
                p085j0.B bL = selectPlayerFragment2.l();
                MainActivity mainActivity3 = bL instanceof MainActivity ? (MainActivity) bL : null;
                if (mainActivity3 != null) {
                    R6.y yVar = new R6.y(R.string.msg_no_playable_sources);
                    int i10 = MainActivity.f16475h0;
                    mainActivity3.f0(yVar, true);
                }
                selectPlayerFragment2.l0();
                return lVar;
            }
            G g10 = (G) p048e8.i.j0(listA);
            if (selectPlayerFragment2.r0().f23287b) {
                Iterator it = ((Iterable) selectPlayerFragment2.s0().f23235l.getValue()).iterator();
                do {
                    if (!it.hasNext()) {
                        j9 = 1;
                        next = null;
                        break;
                    }
                    next = it.next();
                    j9 = 1;
                } while (((p219y6.C) next).f25994a != 1);
                c10 = (p219y6.C) next;
            } else {
                j9 = 1;
                C1274b c1274b = (C1274b) selectPlayerFragment2.f16522S0.getValue();
                List list = c1274b.f1946d.f2002f;
                kotlin.jvm.internal.h.d(list, "getCurrentList(...)");
                c10 = (p219y6.C) p048e8.i.m0(c1274b.f23248e, list);
            }
            if (c10 == null) {
                p085j0.B bL2 = selectPlayerFragment2.l();
                MainActivity mainActivity4 = bL2 instanceof MainActivity ? (MainActivity) bL2 : null;
                if (mainActivity4 != null) {
                    R6.y yVar2 = new R6.y(R.string.msg_unknown_error);
                    int i11 = MainActivity.f16475h0;
                    mainActivity4.f0(yVar2, true);
                }
                selectPlayerFragment2.l0();
                return lVar;
            }
            String str4 = g10.f26017a;
            if (str4 == null || p229z8.e.j0(str4)) {
                str = "";
            } else {
                String strEncode2 = URLEncoder.encode(str4, StandardCharsets.UTF_8.name());
                kotlin.jvm.internal.h.d(strEncode2, "encode(...)");
                str = strEncode2;
            }
            String str5 = h6 != null ? h6.f26022c : null;
            if (str5 == null || p229z8.e.j0(str5)) {
                strS = selectPlayerFragment2.s(R.string.label_none);
            } else {
                String str6 = h6 != null ? h6.f26023d : null;
                if (str6 == null || (string = p229z8.e.z0(str6).toString()) == null) {
                    strEncode = "";
                } else {
                    String input = "";
                    for (int i12 = 0; i12 < string.length(); i12++) {
                        char cCharAt = string.charAt(i12);
                        if (u0.z(cCharAt)) {
                            cCharAt = '-';
                        }
                        StringBuilder sb = new StringBuilder();
                        sb.append((Object) input);
                        sb.append(cCharAt);
                        input = sb.toString();
                    }
                    Pattern patternCompile = Pattern.compile("[^-a-zA-Z0-9]");
                    kotlin.jvm.internal.h.d(patternCompile, "compile(...)");
                    kotlin.jvm.internal.h.e(input, "input");
                    String strReplaceAll = patternCompile.matcher(input).replaceAll("");
                    kotlin.jvm.internal.h.d(strReplaceAll, "replaceAll(...)");
                    Pattern patternCompile2 = Pattern.compile("-+");
                    kotlin.jvm.internal.h.d(patternCompile2, "compile(...)");
                    String strReplaceAll2 = patternCompile2.matcher(strReplaceAll).replaceAll("-");
                    kotlin.jvm.internal.h.d(strReplaceAll2, "replaceAll(...)");
                    strEncode = URLEncoder.encode(strReplaceAll2, "UTF-8");
                    kotlin.jvm.internal.h.d(strEncode, "encode(...)");
                }
                strS = str5 + "?/" + strEncode;
            }
            String str7 = strS;
            C cS0 = selectPlayerFragment2.s0();
            this.f23276y = null;
            this.f23269r = episodeSource3;
            this.f23270s = g10;
            this.f23271t = c10;
            this.f23272u = str;
            this.f23273v = str7;
            this.f23274w = j;
            this.f23275x = 1;
            EpisodeSource episodeSource4 = cS0.f23236m;
            if (episodeSource4 != null && cS0.f23239p > 0 && episodeSource4.f16330a > 0 && cS0.j.f1656a.c()) {
                selectPlayerFragment = selectPlayerFragment2;
                episodeSource = episodeSource3;
                dVar = null;
                g4 = g10;
                objA = cS0.f23232h.a(cS0.f23239p, episodeSource4.f16330a, episodeSource4.f16337h, cS0.f23240q, cS0.f23241r, this);
            } else {
                episodeSource = episodeSource3;
                dVar = null;
                selectPlayerFragment = selectPlayerFragment2;
                g4 = g10;
                objA = "";
            }
            p084i8.a aVar = p084i8.a.f19475a;
            if (objA == aVar) {
                return aVar;
            }
            str2 = str7;
            c11 = c10;
            str3 = str;
            episodeSource2 = episodeSource;
            g9 = g4;
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            long j10 = this.f23274w;
            str2 = this.f23273v;
            str3 = this.f23272u;
            c11 = this.f23271t;
            g9 = this.f23270s;
            episodeSource2 = this.f23269r;
            u0.F(obj);
            j = j10;
            selectPlayerFragment = selectPlayerFragment2;
            dVar = null;
            j9 = 1;
            objA = obj;
        }
        String str8 = (String) objA;
        String strY = p229z8.m.Y(p229z8.m.Y(c11.f26000g, "{streaming_url}", str3), "{subtitle_url}", str2);
        String str9 = selectPlayerFragment.s0().f23237n;
        if (p229z8.e.j0(str9)) {
            str9 = episodeSource2.f16331b;
        }
        String strY2 = p229z8.m.Y(p229z8.m.Y(p229z8.m.Y(p229z8.m.Y(strY, "{movie_name}", str9), "{mime_type}", g9.f26018b == A6.g.f74a ? "application/x-mpegURL" : ""), "{event_url}", str8), "{start_time}", String.valueOf(j));
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse(strY2));
        p085j0.B bL3 = selectPlayerFragment.l();
        if (bL3 instanceof MainActivity) {
            mainActivity2 = (MainActivity) bL3;
        } else {
            mainActivity = dVar;
        }
        if (mainActivity == 0) {
            mainActivity = mainActivity2;
            selectPlayerFragment.l0();
            return lVar;
        }
        try {
            mainActivity = mainActivity2;
            mainActivity.startActivity(intent);
            mainActivity.Y().f17168B = true;
            if (c11.f25994a == j9) {
                U u4 = mainActivity.Y().f17181q.f717a;
                D.r(u4.f23551d, M.f438b, new p120m6.b(30L, new T(u4, dVar), dVar), 2);
            }
        } catch (Exception e9) {
            if (e9 instanceof ActivityNotFoundException) {
                SelectPlayerFragment selectPlayerFragment3 = selectPlayerFragment;
                String strS2 = selectPlayerFragment3.s(R.string.title_download_tool);
                kotlin.jvm.internal.h.d(strS2, "getString(...)");
                String string2 = mainActivity.getResources().getString(R.string.message_external_player);
                kotlin.jvm.internal.h.d(string2, "getString(...)");
                C1.f fVar = new C1.f(18);
                String string3 = mainActivity.getResources().getString(R.string.label_cancel);
                kotlin.jvm.internal.h.d(string3, "getString(...)");
                l lVar2 = new l(c11, mainActivity, 0);
                String string4 = mainActivity.getResources().getString(R.string.title_install);
                kotlin.jvm.internal.h.d(string4, "getString(...)");
                M6.b bVar = new M6.b(mainActivity);
                bVar.f4763a = strS2;
                bVar.f4764b = string2;
                bVar.f4765c = string4;
                bVar.f4766d = string3;
                bVar.f4767e = lVar2;
                bVar.f4768f = fVar;
                bVar.show();
                selectPlayerFragment3.l0();
                return lVar;
            }
            mainActivity.f0(new R6.y(R.string.msg_unknown_error), true);
        }
        selectPlayerFragment.l0();
        return lVar;
    }
}
