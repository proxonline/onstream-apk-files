package s7;

/* JADX INFO: loaded from: classes.dex */
public final class w implements x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final w f23298a = new w();
}
