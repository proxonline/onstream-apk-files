package s7;

import com.maertsno.m.ui.select_player.SelectPlayerFragment;
import java.util.List;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class e extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f23252r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ SelectPlayerFragment f23253s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(SelectPlayerFragment selectPlayerFragment, h8.d dVar) {
        super(2, dVar);
        this.f23253s = selectPlayerFragment;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        e eVar = new e(this.f23253s, dVar);
        eVar.f23252r = obj;
        return eVar;
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        e eVar = (e) create((List) obj, (h8.d) obj2);
        p039d8.l lVar = p039d8.l.f16813a;
        eVar.invokeSuspend(lVar);
        return lVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        List list = (List) this.f23252r;
        u0.F(obj);
        ((C1274b) this.f23253s.f16522S0.getValue()).n(list);
        return p039d8.l.f16813a;
    }
}
