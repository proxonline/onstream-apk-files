package s7;

import android.os.Bundle;
import com.maertsno.m.ui.select_player.SelectPlayerFragment;

/* JADX INFO: loaded from: classes.dex */
public final class q extends kotlin.jvm.internal.i implements p167r8.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f23284d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ SelectPlayerFragment f23285e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ q(SelectPlayerFragment selectPlayerFragment, int i9) {
        super(0);
        this.f23284d = i9;
        this.f23285e = selectPlayerFragment;
    }

    @Override // p167r8.a
    public final Object invoke() {
        switch (this.f23284d) {
            case 0:
                SelectPlayerFragment selectPlayerFragment = this.f23285e;
                Bundle bundle = selectPlayerFragment.f20577f;
                if (bundle != null) {
                    return bundle;
                }
                throw new IllegalStateException("Fragment " + selectPlayerFragment + " has null arguments");
            default:
                return this.f23285e;
        }
    }
}
