package s7;

/* JADX INFO: loaded from: classes.dex */
public final class u extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Object f23294r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f23295s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C f23296t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u(C c10, h8.d dVar) {
        super(2, dVar);
        this.f23296t = c10;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new u(this.f23296t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((u) create((B8.A) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x004c, code lost:
    
        if (r3.h(r0, r5) == r4) goto L20;
     */
    @Override // p093j8.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r6) {
        /*
            r5 = this;
            int r0 = r5.f23295s
            r1 = 2
            r2 = 1
            s7.C r3 = r5.f23296t
            i8.a r4 = p084i8.a.f19475a
            if (r0 == 0) goto L22
            if (r0 == r2) goto L1a
            if (r0 != r1) goto L12
            p195v5.u0.F(r6)
            goto L4f
        L12:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L1a:
            p195v5.u0.F(r6)
            d8.i r6 = (p039d8.i) r6
            java.lang.Object r6 = r6.f16808a
            goto L30
        L22:
            p195v5.u0.F(r6)
            A5.e r6 = r3.f23228d
            r5.f23295s = r2
            java.lang.Object r6 = r6.v(r5)
            if (r6 != r4) goto L30
            goto L4e
        L30:
            boolean r0 = r6 instanceof p039d8.h
            if (r0 != 0) goto L3e
            r0 = r6
            y6.x r0 = (p219y6.x) r0
            E8.U r2 = r3.f23235l
            java.util.List r0 = r0.f26115d
            r2.h(r0)
        L3e:
            java.lang.Throwable r0 = p039d8.i.a(r6)
            if (r0 == 0) goto L4f
            r5.f23294r = r6
            r5.f23295s = r1
            java.lang.Object r6 = r3.h(r0, r5)
            if (r6 != r4) goto L4f
        L4e:
            return r4
        L4f:
            d8.l r6 = p039d8.l.f16813a
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: s7.u.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
