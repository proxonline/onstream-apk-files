package s7;

import com.maertsno.domain.model.Movie;

/* JADX INFO: loaded from: classes.dex */
public final class A extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Object f23218r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f23219s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C f23220t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ long f23221u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ Movie f23222v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ int f23223w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public A(C c10, long j, Movie movie, int i9, h8.d dVar) {
        super(2, dVar);
        this.f23220t = c10;
        this.f23221u = j;
        this.f23222v = movie;
        this.f23223w = i9;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new A(this.f23220t, this.f23221u, this.f23222v, this.f23223w, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((A) create((B8.A) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:26:0x0097, code lost:
    
        if (r3.h(r0, r10) == r4) goto L27;
     */
    @Override // p093j8.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r11) {
        /*
            r10 = this;
            int r0 = r10.f23219s
            r1 = 2
            r2 = 1
            s7.C r3 = r10.f23220t
            i8.a r4 = p084i8.a.f19475a
            if (r0 == 0) goto L23
            if (r0 == r2) goto L1b
            if (r0 != r1) goto L13
            p195v5.u0.F(r11)
            goto L9a
        L13:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r0)
            throw r11
        L1b:
            p195v5.u0.F(r11)
            d8.i r11 = (p039d8.i) r11
            java.lang.Object r11 = r11.f16808a
            goto L33
        L23:
            p195v5.u0.F(r11)
            C6.o r11 = r3.f23231g
            r10.f23219s = r2
            long r5 = r10.f23221u
            java.lang.Object r11 = r11.b(r5, r10)
            if (r11 != r4) goto L33
            goto L99
        L33:
            boolean r0 = r11 instanceof p039d8.h
            if (r0 != 0) goto L89
            r0 = r11
            com.maertsno.domain.model.EpisodeSource r0 = (com.maertsno.domain.model.EpisodeSource) r0
            r3.f23236m = r0
            com.maertsno.domain.model.Movie r2 = r10.f23222v
            com.maertsno.domain.type.MediaType r5 = r2.f16352h
            java.lang.String r2 = r2.f16348d
            com.maertsno.domain.type.MediaType r6 = com.maertsno.domain.type.MediaType.TV_SERIES
            if (r5 != r6) goto L76
            java.lang.String r5 = " "
            int r6 = r10.f23223w
            if (r6 > 0) goto L63
            int r6 = r0.f16337h
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            java.lang.String r8 = "E"
            r7.<init>(r8)
            r7.append(r6)
            r7.append(r5)
            r7.append(r2)
            java.lang.String r2 = r7.toString()
            goto L74
        L63:
            int r7 = r0.f16337h
            java.lang.String r8 = "S"
            java.lang.String r9 = ":E"
            java.lang.StringBuilder r5 = B0.a.q(r6, r8, r7, r9, r5)
            r5.append(r2)
            java.lang.String r2 = r5.toString()
        L74:
            r3.f23237n = r2
        L76:
            E8.U r2 = r3.f23234k
            R6.w r5 = new R6.w
            s7.v r6 = new s7.v
            r6.<init>(r0)
            r5.<init>(r6)
            r2.getClass()
            r0 = 0
            r2.i(r0, r5)
        L89:
            java.lang.Throwable r0 = p039d8.i.a(r11)
            if (r0 == 0) goto L9a
            r10.f23218r = r11
            r10.f23219s = r1
            java.lang.Object r11 = r3.h(r0, r10)
            if (r11 != r4) goto L9a
        L99:
            return r4
        L9a:
            d8.l r11 = p039d8.l.f16813a
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: s7.A.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
