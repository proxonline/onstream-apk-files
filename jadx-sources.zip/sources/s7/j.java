package s7;

import com.maertsno.m.ui.select_player.SelectPlayerFragment;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class j extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f23262r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ SelectPlayerFragment f23263s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(SelectPlayerFragment selectPlayerFragment, h8.d dVar) {
        super(2, dVar);
        this.f23263s = selectPlayerFragment;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        j jVar = new j(this.f23263s, dVar);
        jVar.f23262r = obj;
        return jVar;
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        j jVar = (j) create((Boolean) obj, (h8.d) obj2);
        p039d8.l lVar = p039d8.l.f16813a;
        jVar.invokeSuspend(lVar);
        return lVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        Boolean bool = (Boolean) this.f23262r;
        u0.F(obj);
        if (kotlin.jvm.internal.h.a(bool, Boolean.TRUE)) {
            this.f23263s.l0();
        }
        return p039d8.l.f16813a;
    }
}
