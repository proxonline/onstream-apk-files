package s7;

import android.os.Bundle;
import android.os.Parcelable;
import com.maertsno.domain.model.Movie;
import java.io.Serializable;
import p200w0.InterfaceC1372g;

/* JADX INFO: loaded from: classes.dex */
public final class r implements InterfaceC1372g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Movie f23286a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f23287b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f23288c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f23289d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f23290e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f23291f;

    public r(Movie movie, boolean z9, long j, long j9, int i9, long j10) {
        this.f23286a = movie;
        this.f23287b = z9;
        this.f23288c = j;
        this.f23289d = j9;
        this.f23290e = i9;
        this.f23291f = j10;
    }

    public static final r fromBundle(Bundle bundle) {
        kotlin.jvm.internal.h.e(bundle, "bundle");
        bundle.setClassLoader(r.class.getClassLoader());
        if (!bundle.containsKey("movie")) {
            throw new IllegalArgumentException("Required argument \"movie\" is missing and does not have an android:defaultValue");
        }
        if (!Parcelable.class.isAssignableFrom(Movie.class) && !Serializable.class.isAssignableFrom(Movie.class)) {
            throw new UnsupportedOperationException(Movie.class.getName().concat(" must implement Parcelable or Serializable or must be an Enum."));
        }
        Movie movie = (Movie) bundle.get("movie");
        if (movie == null) {
            throw new IllegalArgumentException("Argument \"movie\" is marked as non-null but was passed a null value.");
        }
        return new r(movie, bundle.containsKey("external") ? bundle.getBoolean("external") : false, bundle.containsKey("seasonId") ? bundle.getLong("seasonId") : 0L, bundle.containsKey("episodeId") ? bundle.getLong("episodeId") : 0L, bundle.containsKey("seasonNumber") ? bundle.getInt("seasonNumber") : 0, bundle.containsKey("positionMs") ? bundle.getLong("positionMs") : 0L);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof r)) {
            return false;
        }
        r rVar = (r) obj;
        return kotlin.jvm.internal.h.a(this.f23286a, rVar.f23286a) && this.f23287b == rVar.f23287b && this.f23288c == rVar.f23288c && this.f23289d == rVar.f23289d && this.f23290e == rVar.f23290e && this.f23291f == rVar.f23291f;
    }

    public final int hashCode() {
        int iHashCode = ((this.f23286a.hashCode() * 31) + (this.f23287b ? 1231 : 1237)) * 31;
        long j = this.f23288c;
        int i9 = (iHashCode + ((int) (j ^ (j >>> 32)))) * 31;
        long j9 = this.f23289d;
        int i10 = (((i9 + ((int) (j9 ^ (j9 >>> 32)))) * 31) + this.f23290e) * 31;
        long j10 = this.f23291f;
        return i10 + ((int) (j10 ^ (j10 >>> 32)));
    }

    public final String toString() {
        return "SelectPlayerFragmentArgs(movie=" + this.f23286a + ", external=" + this.f23287b + ", seasonId=" + this.f23288c + ", episodeId=" + this.f23289d + ", seasonNumber=" + this.f23290e + ", positionMs=" + this.f23291f + ")";
    }
}
