package s7;

import android.os.Bundle;
import android.os.Parcelable;
import co.notix.R;
import com.maertsno.domain.model.EpisodeSource;
import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public final class s implements p200w0.B {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final EpisodeSource f23292a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f23293b;

    public s(EpisodeSource episodeSource, boolean z9) {
        kotlin.jvm.internal.h.e(episodeSource, "episodeSource");
        this.f23292a = episodeSource;
        this.f23293b = z9;
    }

    @Override // p200w0.B
    public final Bundle a() {
        Bundle bundle = new Bundle();
        boolean zIsAssignableFrom = Parcelable.class.isAssignableFrom(EpisodeSource.class);
        Parcelable parcelable = this.f23292a;
        if (zIsAssignableFrom) {
            kotlin.jvm.internal.h.c(parcelable, "null cannot be cast to non-null type android.os.Parcelable");
            bundle.putParcelable("episodeSource", parcelable);
        } else {
            if (!Serializable.class.isAssignableFrom(EpisodeSource.class)) {
                throw new UnsupportedOperationException(EpisodeSource.class.getName().concat(" must implement Parcelable or Serializable or must be an Enum."));
            }
            kotlin.jvm.internal.h.c(parcelable, "null cannot be cast to non-null type java.io.Serializable");
            bundle.putSerializable("episodeSource", (Serializable) parcelable);
        }
        bundle.putBoolean("external", this.f23293b);
        return bundle;
    }

    @Override // p200w0.B
    public final int b() {
        return R.id.gotoPlayerSubtitle;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof s)) {
            return false;
        }
        s sVar = (s) obj;
        return kotlin.jvm.internal.h.a(this.f23292a, sVar.f23292a) && this.f23293b == sVar.f23293b;
    }

    public final int hashCode() {
        return (this.f23292a.hashCode() * 31) + (this.f23293b ? 1231 : 1237);
    }

    public final String toString() {
        return "GotoPlayerSubtitle(episodeSource=" + this.f23292a + ", external=" + this.f23293b + ")";
    }
}
