package s7;

import E8.K;
import E8.P;
import com.maertsno.m.ui.select_player.SelectPlayerFragment;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class h extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23258r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ SelectPlayerFragment f23259s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(SelectPlayerFragment selectPlayerFragment, h8.d dVar) {
        super(2, dVar);
        this.f23259s = selectPlayerFragment;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new h(this.f23259s, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((h) create((B8.A) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23258r;
        if (i9 == 0) {
            u0.F(obj);
            SelectPlayerFragment selectPlayerFragment = this.f23259s;
            K k9 = new K(selectPlayerFragment.s0().f23234k);
            g gVar = new g(selectPlayerFragment, null);
            this.f23258r = 1;
            Object objH = P.h(k9, gVar, this);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objH == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
        }
        return p039d8.l.f16813a;
    }
}
