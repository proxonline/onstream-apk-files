package s7;

import N6.i1;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.databinding.DataBinderMapperImpl;
import co.notix.R;

/* JADX INFO: renamed from: s7.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1274b extends R6.e {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final P6.a f23247f = new P6.a(13);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f23248e;

    @Override // R6.e
    public final R6.o o(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        int i9 = i1.f5315L;
        DataBinderMapperImpl dataBinderMapperImpl = W.c.f7778a;
        i1 i1Var = (i1) W.g.X(layoutInflater, R.layout.item_player, viewGroup, false, null);
        kotlin.jvm.internal.h.d(i1Var, "inflate(...)");
        return new p150p7.o(this, i1Var, 2);
    }
}
