package s7;

import R6.s;
import W.g;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import androidx.lifecycle.d0;
import com.google.android.gms.internal.measurement.AbstractC0734e2;

/* JADX INFO: renamed from: s7.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1273a<B extends W.g, V extends R6.s> extends R6.g<B, V> implements p009a8.b {

    /* JADX INFO: renamed from: L0, reason: collision with root package name */
    public Y7.h f23242L0;

    /* JADX INFO: renamed from: M0, reason: collision with root package name */
    public boolean f23243M0;

    /* JADX INFO: renamed from: N0, reason: collision with root package name */
    public volatile Y7.f f23244N0;

    /* JADX INFO: renamed from: O0, reason: collision with root package name */
    public final Object f23245O0 = new Object();

    /* JADX INFO: renamed from: P0, reason: collision with root package name */
    public boolean f23246P0 = false;

    @Override // p085j0.AbstractComponentCallbacksC1201y
    public final void F(Activity activity) {
        this.f20569Y = true;
        Y7.h hVar = this.f23242L0;
        I3.a.h(hVar == null || Y7.f.b(hVar) == activity, "onAttach called multiple times with different Context! Hilt Fragments should not be retained.", new Object[0]);
        q0();
        if (this.f23246P0) {
            return;
        }
        this.f23246P0 = true;
        ((t) f()).getClass();
    }

    @Override // p085j0.DialogInterfaceOnCancelListenerC1194q, p085j0.AbstractComponentCallbacksC1201y
    public final void G(Context context) {
        super.G(context);
        q0();
        if (this.f23246P0) {
            return;
        }
        this.f23246P0 = true;
        ((t) f()).getClass();
    }

    @Override // p085j0.DialogInterfaceOnCancelListenerC1194q, p085j0.AbstractComponentCallbacksC1201y
    public final LayoutInflater M(Bundle bundle) {
        LayoutInflater layoutInflaterM = super.M(bundle);
        return layoutInflaterM.cloneInContext(new Y7.h(layoutInflaterM, this));
    }

    @Override // p009a8.b
    public final Object f() {
        if (this.f23244N0 == null) {
            synchronized (this.f23245O0) {
                try {
                    if (this.f23244N0 == null) {
                        this.f23244N0 = new Y7.f(this);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return this.f23244N0.f();
    }

    @Override // p085j0.AbstractComponentCallbacksC1201y
    public final Context n() {
        if (super.n() == null && !this.f23243M0) {
            return null;
        }
        q0();
        return this.f23242L0;
    }

    public final void q0() {
        if (this.f23242L0 == null) {
            this.f23242L0 = new Y7.h(super.n(), this);
            this.f23243M0 = AbstractC0734e2.s(super.n());
        }
    }

    @Override // p085j0.AbstractComponentCallbacksC1201y, androidx.lifecycle.InterfaceC0541j
    public final d0 r() {
        return p012b1.a.y(this, super.r());
    }
}
