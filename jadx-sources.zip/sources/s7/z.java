package s7;

import com.maertsno.domain.model.Movie;

/* JADX INFO: loaded from: classes.dex */
public final class z extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Object f23302r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f23303s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ C f23304t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Movie f23305u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public z(C c10, Movie movie, h8.d dVar) {
        super(2, dVar);
        this.f23304t = c10;
        this.f23305u = movie;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new z(this.f23304t, this.f23305u, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((z) create((B8.A) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0078  */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0080, code lost:
    
        if (r10.h(r14, r13) == r12) goto L28;
     */
    @Override // p093j8.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r14) {
        /*
            r13 = this;
            int r0 = r13.f23303s
            com.maertsno.domain.model.Movie r4 = r13.f23305u
            s7.C r10 = r13.f23304t
            r11 = 3
            r1 = 2
            r2 = 1
            i8.a r12 = p084i8.a.f19475a
            if (r0 == 0) goto L2f
            if (r0 == r2) goto L26
            if (r0 == r1) goto L20
            if (r0 != r11) goto L18
            p195v5.u0.F(r14)
            goto L83
        L18:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r14.<init>(r0)
            throw r14
        L20:
            java.lang.Object r0 = r13.f23302r
            p195v5.u0.F(r14)
            goto L72
        L26:
            p195v5.u0.F(r14)
            d8.i r14 = (p039d8.i) r14
            java.lang.Object r14 = r14.f16808a
        L2d:
            r0 = r14
            goto L3f
        L2f:
            p195v5.u0.F(r14)
            C6.f r14 = r10.f23230f
            long r5 = r4.f16345a
            r13.f23303s = r2
            java.lang.Object r14 = r14.b(r5, r13)
            if (r14 != r12) goto L2d
            goto L82
        L3f:
            boolean r14 = r0 instanceof p039d8.h
            if (r14 != 0) goto L72
            r14 = r0
            java.util.List r14 = (java.util.List) r14
            boolean r2 = r14.isEmpty()
            r3 = r1
            s7.C r1 = r13.f23304t
            if (r2 == 0) goto L62
            R6.y r14 = new R6.y
            r2 = 2132017529(0x7f140179, float:1.9673339E38)
            r14.<init>(r2)
            r13.f23302r = r0
            r13.f23303s = r3
            java.lang.Object r14 = r1.g(r14, r13)
            if (r14 != r12) goto L72
            goto L82
        L62:
            java.lang.Object r14 = p048e8.i.j0(r14)
            com.maertsno.domain.model.Episode r14 = (com.maertsno.domain.model.Episode) r14
            long r2 = r14.f16320a
            long r5 = r14.f16323d
            r7 = 0
            long r8 = r14.f16328i
            r1.i(r2, r4, r5, r7, r8)
        L72:
            java.lang.Throwable r14 = p039d8.i.a(r0)
            if (r14 == 0) goto L83
            r13.f23302r = r0
            r13.f23303s = r11
            java.lang.Object r14 = r10.h(r14, r13)
            if (r14 != r12) goto L83
        L82:
            return r12
        L83:
            d8.l r14 = p039d8.l.f16813a
            return r14
        */
        throw new UnsupportedOperationException("Method not decompiled: s7.z.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
