package s7;

import C6.C0067b;
import com.maertsno.domain.model.Movie;
import java.io.Serializable;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class y extends p093j8.i implements p167r8.p {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f23299r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ C f23300s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ Movie f23301t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y(C c10, Movie movie, h8.d dVar) {
        super(2, dVar);
        this.f23300s = c10;
        this.f23301t = movie;
    }

    @Override // p093j8.a
    public final h8.d create(Object obj, h8.d dVar) {
        return new y(this.f23300s, this.f23301t, dVar);
    }

    @Override // p167r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((y) create((B8.A) obj, (h8.d) obj2)).invokeSuspend(p039d8.l.f16813a);
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        int i9 = this.f23299r;
        if (i9 == 0) {
            u0.F(obj);
            C0067b c0067b = this.f23300s.f23229e;
            this.f23299r = 1;
            Serializable serializableA = c0067b.a(this.f23301t, this);
            p084i8.a aVar = p084i8.a.f19475a;
            if (serializableA == aVar) {
                return aVar;
            }
        } else {
            if (i9 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
            ((p039d8.i) obj).getClass();
        }
        return p039d8.l.f16813a;
    }
}
