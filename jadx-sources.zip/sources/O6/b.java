package O6;

import D7.s;
import L8.J;
import L8.w;
import Y8.C;
import Y8.InterfaceC0469i;
import kotlin.jvm.internal.h;

/* JADX INFO: loaded from: classes.dex */
public final class b extends J {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f5747a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final J f5748b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C f5749c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f5750d;

    public b(J j) {
        this.f5748b = j;
        this.f5749c = T8.d.c(new D1.d(this, j.k()));
    }

    public b(J responseBody, s sVar) {
        h.e(responseBody, "responseBody");
        this.f5748b = responseBody;
        this.f5750d = sVar;
    }

    @Override // L8.J
    public final long a() {
        switch (this.f5747a) {
            case 0:
                break;
        }
        return this.f5748b.a();
    }

    @Override // L8.J, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        switch (this.f5747a) {
            case 1:
                this.f5748b.close();
                break;
            default:
                super.close();
                break;
        }
    }

    @Override // L8.J
    public final w f() {
        switch (this.f5747a) {
            case 0:
                break;
        }
        return this.f5748b.f();
    }

    @Override // L8.J
    public final InterfaceC0469i k() {
        switch (this.f5747a) {
            case 0:
                C c10 = this.f5749c;
                if (c10 != null) {
                    return c10;
                }
                C c11 = T8.d.c(new a(this, this.f5748b.k()));
                this.f5749c = c11;
                return c11;
            default:
                return this.f5749c;
        }
    }
}
