package O6;

import java.io.Serializable;
import p039d8.i;

/* JADX INFO: loaded from: classes.dex */
public final class d extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public String f5751r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public g f5752s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public /* synthetic */ Object f5753t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ g f5754u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f5755v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(g gVar, p093j8.c cVar) {
        super(cVar);
        this.f5754u = gVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f5753t = obj;
        this.f5755v |= Integer.MIN_VALUE;
        Serializable serializableA = this.f5754u.a(null, null, null, this);
        return serializableA == p084i8.a.f19475a ? serializableA : new i(serializableA);
    }
}
