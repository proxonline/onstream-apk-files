package O6;

import D7.s;
import D7.v;
import E8.U;
import L8.J;
import Y8.C0467g;
import Y8.InterfaceC0469i;
import Y8.p;
import kotlin.jvm.internal.h;

/* JADX INFO: loaded from: classes.dex */
public final class a extends p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f5745b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ b f5746c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(b bVar, InterfaceC0469i interfaceC0469i) {
        super(interfaceC0469i);
        this.f5746c = bVar;
    }

    @Override // Y8.p, Y8.I
    public final long S(C0467g sink, long j) {
        h.e(sink, "sink");
        long jS = super.S(sink, j);
        b bVar = this.f5746c;
        J j9 = bVar.f5748b;
        s sVar = (s) bVar.f5750d;
        if (sVar != null) {
            long j10 = this.f5745b + (jS != -1 ? jS : 0L);
            this.f5745b = j10;
            int iA = (int) ((j10 * ((long) 100)) / j9.a());
            long j11 = 1024;
            long j12 = this.f5745b / j11;
            long jA = j9.a() / j11;
            int i9 = sVar.f1109a;
            v vVar = sVar.f1110b;
            switch (i9) {
                case 0:
                    U u4 = vVar.f1119f;
                    Integer numValueOf = Integer.valueOf(iA);
                    u4.getClass();
                    u4.i(null, numValueOf);
                    break;
                default:
                    U u9 = vVar.f1119f;
                    Integer numValueOf2 = Integer.valueOf(iA);
                    u9.getClass();
                    u9.i(null, numValueOf2);
                    break;
            }
        }
        return jS;
    }
}
