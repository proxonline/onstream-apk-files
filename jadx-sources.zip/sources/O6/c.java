package O6;

import L8.J;
import c9.w;
import c9.y;

/* JADX INFO: loaded from: classes.dex */
public interface c {
    @c9.f
    @w
    Object a(@y String str, h8.d<? super J> dVar);
}
