package O6;

import D7.s;
import L8.G;
import L8.H;
import L8.J;
import L8.v;

/* JADX INFO: loaded from: classes.dex */
public final class f implements v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public s f5761a;

    @Override // L8.v
    public final H a(Q8.f fVar) {
        H hB = fVar.b(fVar.f6623e);
        J j = hB.f4328g;
        b bVar = j == null ? null : new b(j, this.f5761a);
        G gK = hB.k();
        gK.f4316g = bVar;
        return gK.a();
    }
}
