package O6;

import android.net.Uri;
import p039d8.i;

/* JADX INFO: loaded from: classes.dex */
public final class e extends p093j8.c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Uri f5756r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public g f5757s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public /* synthetic */ Object f5758t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ g f5759u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f5760v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(g gVar, p093j8.c cVar) {
        super(cVar);
        this.f5759u = gVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f5758t = obj;
        this.f5760v |= Integer.MIN_VALUE;
        Object objB = this.f5759u.b(null, null, null, this);
        return objB == p084i8.a.f19475a ? objB : new i(objB);
    }
}
