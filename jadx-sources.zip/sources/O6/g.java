package O6;

import D7.s;
import L8.J;
import android.content.Context;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import kotlin.jvm.internal.h;
import p039d8.j;
import p195v5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f5762a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f5763b = p162r3.e.x(new C1.f(3));

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final j f5764c = p162r3.e.x(new D1.c(5, this));

    public g(Context context) {
        this.f5762a = context;
    }

    public static File c(String str, InputStream inputStream) throws IOException {
        if (inputStream == null) {
            return null;
        }
        File file = new File(str);
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        try {
            try {
                byte[] bArr = new byte[1024];
                while (true) {
                    int i9 = inputStream.read(bArr);
                    if (i9 == -1) {
                        fileOutputStream.flush();
                        inputStream.close();
                        fileOutputStream.close();
                        return file;
                    }
                    fileOutputStream.write(bArr, 0, i9);
                }
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    u0.h(inputStream, th);
                    throw th2;
                }
            }
        } catch (Throwable th3) {
            try {
                throw th3;
            } catch (Throwable th4) {
                u0.h(fileOutputStream, th3);
                throw th4;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Serializable a(String str, String str2, s sVar, p093j8.c cVar) {
        d dVar;
        g gVar;
        if (cVar instanceof d) {
            dVar = (d) cVar;
            int i9 = dVar.f5755v;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                dVar.f5755v = i9 - Integer.MIN_VALUE;
            } else {
                dVar = new d(this, cVar);
            }
        } else {
            dVar = new d(this, cVar);
        }
        Object objA = dVar.f5753t;
        int i10 = dVar.f5755v;
        try {
            if (i10 == 0) {
                u0.F(objA);
                ((f) this.f5763b.getValue()).f5761a = sVar;
                c cVar2 = (c) this.f5764c.getValue();
                dVar.f5751r = str2;
                dVar.f5752s = this;
                dVar.f5755v = 1;
                objA = cVar2.a(str, dVar);
                p084i8.a aVar = p084i8.a.f19475a;
                if (objA == aVar) {
                    return aVar;
                }
                gVar = this;
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                gVar = dVar.f5752s;
                str2 = dVar.f5751r;
                u0.F(objA);
            }
            InputStream inputStreamE0 = ((J) objA).k().e0();
            gVar.getClass();
            File fileC = c(str2, inputStreamE0);
            h.b(fileC);
            return fileC;
        } catch (Throwable th) {
            return u0.m(th);
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object b(String str, Uri uri, s sVar, p093j8.c cVar) {
        e eVar;
        g gVar;
        if (cVar instanceof e) {
            eVar = (e) cVar;
            int i9 = eVar.f5760v;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                eVar.f5760v = i9 - Integer.MIN_VALUE;
            } else {
                eVar = new e(this, cVar);
            }
        } else {
            eVar = new e(this, cVar);
        }
        Object objA = eVar.f5758t;
        int i10 = eVar.f5760v;
        try {
            if (i10 == 0) {
                u0.F(objA);
                ((f) this.f5763b.getValue()).f5761a = sVar;
                c cVar2 = (c) this.f5764c.getValue();
                eVar.f5756r = uri;
                eVar.f5757s = this;
                eVar.f5760v = 1;
                objA = cVar2.a(str, eVar);
                p084i8.a aVar = p084i8.a.f19475a;
                if (objA == aVar) {
                    return aVar;
                }
                gVar = this;
            } else {
                if (i10 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                gVar = eVar.f5757s;
                uri = eVar.f5756r;
                u0.F(objA);
            }
            Uri uriD = gVar.d(uri, ((J) objA).k().e0());
            h.b(uriD);
            return uriD;
        } catch (Throwable th) {
            return u0.m(th);
        }
    }

    public final Uri d(Uri uri, InputStream inputStream) throws IOException {
        OutputStream outputStreamOpenOutputStream;
        if (inputStream == null || uri == null || (outputStreamOpenOutputStream = this.f5762a.getContentResolver().openOutputStream(uri)) == null) {
            return null;
        }
        try {
            try {
                byte[] bArr = new byte[1024];
                while (true) {
                    int i9 = inputStream.read(bArr);
                    if (i9 == -1) {
                        outputStreamOpenOutputStream.flush();
                        inputStream.close();
                        outputStreamOpenOutputStream.close();
                        return uri;
                    }
                    outputStreamOpenOutputStream.write(bArr, 0, i9);
                    try {
                        throw th;
                    } catch (Throwable th) {
                        u0.h(outputStreamOpenOutputStream, th);
                        throw th;
                    }
                }
            } catch (Throwable th2) {
                try {
                    throw th2;
                } catch (Throwable th3) {
                    u0.h(inputStream, th2);
                    throw th3;
                }
            }
        } catch (Throwable th4) {
            throw th4;
        }
    }
}
