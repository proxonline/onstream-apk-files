package p098k4;

import B.h;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class b extends U.b {
    public static final Parcelable.Creator<b> CREATOR = new h(8);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f21013c;

    public b(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        if (classLoader == null) {
            b.class.getClassLoader();
        }
        this.f21013c = parcel.readInt() == 1;
    }

    @Override // U.b, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i9) {
        super.writeToParcel(parcel, i9);
        parcel.writeInt(this.f21013c ? 1 : 0);
    }
}
