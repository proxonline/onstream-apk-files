package p098k4;

import A4.a;
import C4.h;
import C4.m;
import C4.x;
import P.S;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import co.notix.R;
import com.google.android.gms.internal.measurement.AbstractC0734e2;
import com.google.android.material.button.MaterialButton;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MaterialButton f21014a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public m f21015b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f21016c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f21017d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f21018e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f21019f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f21020g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f21021h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public PorterDuff.Mode f21022i;
    public ColorStateList j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public ColorStateList f21023k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public ColorStateList f21024l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public h f21025m;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f21029q;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public RippleDrawable f21031s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f21032t;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f21026n = false;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f21027o = false;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f21028p = false;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f21030r = true;

    public c(MaterialButton materialButton, m mVar) {
        this.f21014a = materialButton;
        this.f21015b = mVar;
    }

    public final x a() {
        RippleDrawable rippleDrawable = this.f21031s;
        if (rippleDrawable == null || rippleDrawable.getNumberOfLayers() <= 1) {
            return null;
        }
        return this.f21031s.getNumberOfLayers() > 2 ? (x) this.f21031s.getDrawable(2) : (x) this.f21031s.getDrawable(1);
    }

    public final h b(boolean z9) {
        RippleDrawable rippleDrawable = this.f21031s;
        if (rippleDrawable == null || rippleDrawable.getNumberOfLayers() <= 0) {
            return null;
        }
        return (h) ((LayerDrawable) ((InsetDrawable) this.f21031s.getDrawable(0)).getDrawable()).getDrawable(!z9 ? 1 : 0);
    }

    public final void c(m mVar) {
        this.f21015b = mVar;
        if (b(false) != null) {
            b(false).setShapeAppearanceModel(mVar);
        }
        if (b(true) != null) {
            b(true).setShapeAppearanceModel(mVar);
        }
        if (a() != null) {
            a().setShapeAppearanceModel(mVar);
        }
    }

    public final void d(int i9, int i10) {
        WeakHashMap weakHashMap = S.f5835a;
        MaterialButton materialButton = this.f21014a;
        int paddingStart = materialButton.getPaddingStart();
        int paddingTop = materialButton.getPaddingTop();
        int paddingEnd = materialButton.getPaddingEnd();
        int paddingBottom = materialButton.getPaddingBottom();
        int i11 = this.f21018e;
        int i12 = this.f21019f;
        this.f21019f = i10;
        this.f21018e = i9;
        if (!this.f21027o) {
            e();
        }
        materialButton.setPaddingRelative(paddingStart, (paddingTop + i9) - i11, paddingEnd, (paddingBottom + i10) - i12);
    }

    public final void e() {
        h hVar = new h(this.f21015b);
        MaterialButton materialButton = this.f21014a;
        hVar.i(materialButton.getContext());
        hVar.setTintList(this.j);
        PorterDuff.Mode mode = this.f21022i;
        if (mode != null) {
            hVar.setTintMode(mode);
        }
        float f3 = this.f21021h;
        ColorStateList colorStateList = this.f21023k;
        hVar.f624a.j = f3;
        hVar.invalidateSelf();
        hVar.m(colorStateList);
        h hVar2 = new h(this.f21015b);
        hVar2.setTint(0);
        float f9 = this.f21021h;
        int iK = this.f21026n ? AbstractC0734e2.k(materialButton, R.attr.colorSurface) : 0;
        hVar2.f624a.j = f9;
        hVar2.invalidateSelf();
        hVar2.m(ColorStateList.valueOf(iK));
        h hVar3 = new h(this.f21015b);
        this.f21025m = hVar3;
        hVar3.setTint(-1);
        RippleDrawable rippleDrawable = new RippleDrawable(a.c(this.f21024l), new InsetDrawable((Drawable) new LayerDrawable(new Drawable[]{hVar2, hVar}), this.f21016c, this.f21018e, this.f21017d, this.f21019f), this.f21025m);
        this.f21031s = rippleDrawable;
        materialButton.setInternalBackground(rippleDrawable);
        h hVarB = b(false);
        if (hVarB != null) {
            hVarB.j(this.f21032t);
            hVarB.setState(materialButton.getDrawableState());
        }
    }

    public final void f() {
        h hVarB = b(false);
        h hVarB2 = b(true);
        if (hVarB != null) {
            float f3 = this.f21021h;
            ColorStateList colorStateList = this.f21023k;
            hVarB.f624a.j = f3;
            hVarB.invalidateSelf();
            hVarB.m(colorStateList);
            if (hVarB2 != null) {
                float f9 = this.f21021h;
                int iK = this.f21026n ? AbstractC0734e2.k(this.f21014a, R.attr.colorSurface) : 0;
                hVarB2.f624a.j = f9;
                hVarB2.invalidateSelf();
                hVarB2.m(ColorStateList.valueOf(iK));
            }
        }
    }
}
