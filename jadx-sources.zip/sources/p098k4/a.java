package p098k4;

/* JADX INFO: loaded from: classes.dex */
public interface a {
}
