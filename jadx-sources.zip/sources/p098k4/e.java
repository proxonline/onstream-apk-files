package p098k4;

import C4.a;
import C4.c;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a f21034e = new a(0.0f);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f21035a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f21036b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final c f21037c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c f21038d;

    public e(c cVar, c cVar2, c cVar3, c cVar4) {
        this.f21035a = cVar;
        this.f21036b = cVar3;
        this.f21037c = cVar4;
        this.f21038d = cVar2;
    }
}
