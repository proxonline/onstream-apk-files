package p105l1;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collection;
import p060g1.q;
import p115m1.b;
import p115m1.d;
import p125n1.e;
import p125n1.f;
import p125n1.g;
import p170s1.a;

/* JADX INFO: loaded from: classes.dex */
public final class c implements b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String f21081d = q.h("WorkConstraintsTracker");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f21082a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p115m1.c[] f21083b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f21084c;

    public c(Context context, a aVar, b bVar) {
        Context applicationContext = context.getApplicationContext();
        this.f21082a = bVar;
        this.f21083b = new p115m1.c[]{new p115m1.a((p125n1.a) g.l(applicationContext, aVar).f21577b, 0), new p115m1.a((p125n1.b) g.l(applicationContext, aVar).f21578c, 1), new p115m1.a((f) g.l(applicationContext, aVar).f21580e, 4), new p115m1.a((e) g.l(applicationContext, aVar).f21579d, 2), new p115m1.a((e) g.l(applicationContext, aVar).f21579d, 3), new p115m1.e((e) g.l(applicationContext, aVar).f21579d), new d((e) g.l(applicationContext, aVar).f21579d)};
        this.f21084c = new Object();
    }

    public final boolean a(String str) {
        synchronized (this.f21084c) {
            try {
                for (p115m1.c cVar : this.f21083b) {
                    Object obj = cVar.f21224b;
                    if (obj != null && cVar.b(obj) && cVar.f21223a.contains(str)) {
                        q.c().a(f21081d, "Work " + str + " constrained by " + cVar.getClass().getSimpleName(), new Throwable[0]);
                        return false;
                    }
                }
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b(ArrayList arrayList) {
        synchronized (this.f21084c) {
            try {
                b bVar = this.f21082a;
                if (bVar != null) {
                    bVar.c(arrayList);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void c(Collection collection) {
        synchronized (this.f21084c) {
            try {
                for (p115m1.c cVar : this.f21083b) {
                    if (cVar.f21226d != null) {
                        cVar.f21226d = null;
                        cVar.d(null, cVar.f21224b);
                    }
                }
                for (p115m1.c cVar2 : this.f21083b) {
                    cVar2.c(collection);
                }
                for (p115m1.c cVar3 : this.f21083b) {
                    if (cVar3.f21226d != this) {
                        cVar3.f21226d = this;
                        cVar3.d(this, cVar3.f21224b);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void d() {
        synchronized (this.f21084c) {
            try {
                for (p115m1.c cVar : this.f21083b) {
                    ArrayList arrayList = cVar.f21223a;
                    if (!arrayList.isEmpty()) {
                        arrayList.clear();
                        cVar.f21225c.b(cVar);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
