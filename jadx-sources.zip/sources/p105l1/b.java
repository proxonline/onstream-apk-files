package p105l1;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public interface b {
    void c(List list);

    void e(List list);
}
