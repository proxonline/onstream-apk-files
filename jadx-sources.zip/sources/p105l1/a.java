package p105l1;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f21077a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f21078b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f21079c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f21080d;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return this.f21077a == aVar.f21077a && this.f21078b == aVar.f21078b && this.f21079c == aVar.f21079c && this.f21080d == aVar.f21080d;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [boolean, int] */
    public final int hashCode() {
        ?? r9 = this.f21077a;
        int i9 = r9;
        if (this.f21078b) {
            i9 = r9 + 16;
        }
        int i10 = i9;
        if (this.f21079c) {
            i10 = i9 + 256;
        }
        return this.f21080d ? i10 + 4096 : i10;
    }

    public final String toString() {
        return "[ Connected=" + this.f21077a + " Validated=" + this.f21078b + " Metered=" + this.f21079c + " NotRoaming=" + this.f21080d + " ]";
    }
}
