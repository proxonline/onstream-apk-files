package B6;

import A5.e;
import java.io.Serializable;
import p039d8.i;
import p093j8.c;

/* JADX INFO: loaded from: classes.dex */
public final class a extends c {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f297r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ e f298s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f299t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(e eVar, c cVar) {
        super(cVar);
        this.f298s = eVar;
    }

    @Override // p093j8.a
    public final Object invokeSuspend(Object obj) {
        this.f297r = obj;
        this.f299t |= Integer.MIN_VALUE;
        Serializable serializableU = this.f298s.u(this);
        return serializableU == p084i8.a.f19475a ? serializableU : new i(serializableU);
    }
}
