package p020c;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.a;

/* JADX INFO: loaded from: classes.dex */
public class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new a(5);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public b f11822a;

    public void a(int i9, Bundle bundle) {
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i9) {
        synchronized (this) {
            try {
                if (this.f11822a == null) {
                    this.f11822a = new c(this);
                }
                parcel.writeStrongBinder(this.f11822a.asBinder());
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
