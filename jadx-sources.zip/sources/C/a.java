package C;

import android.R;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f530a = {R.attr.color, R.attr.alpha, R.attr.lStar, co.notix.R.attr.alpha, co.notix.R.attr.lStar};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f531b = {co.notix.R.attr.fontProviderAuthority, co.notix.R.attr.fontProviderCerts, co.notix.R.attr.fontProviderFallbackQuery, co.notix.R.attr.fontProviderFetchStrategy, co.notix.R.attr.fontProviderFetchTimeout, co.notix.R.attr.fontProviderPackage, co.notix.R.attr.fontProviderQuery, co.notix.R.attr.fontProviderSystemFontFamily};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f532c = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, co.notix.R.attr.font, co.notix.R.attr.fontStyle, co.notix.R.attr.fontVariationSettings, co.notix.R.attr.fontWeight, co.notix.R.attr.ttcIndex};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f533d = {R.attr.startColor, R.attr.endColor, R.attr.type, R.attr.centerX, R.attr.centerY, R.attr.gradientRadius, R.attr.tileMode, R.attr.centerColor, R.attr.startX, R.attr.startY, R.attr.endX, R.attr.endY};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final int[] f534e = {R.attr.color, R.attr.offset};
}
