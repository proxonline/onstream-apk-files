package R;

import android.content.ClipDescription;
import android.net.Uri;

/* JADX INFO: loaded from: classes.dex */
public interface g {
    Object c();

    Uri e();

    void f();

    Uri g();

    ClipDescription getDescription();
}
