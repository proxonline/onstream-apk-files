package R;

import android.content.ClipDescription;
import android.net.Uri;
import android.view.inputmethod.InputContentInfo;

/* JADX INFO: loaded from: classes.dex */
public final class f implements g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InputContentInfo f6631a;

    public f(Uri uri, ClipDescription clipDescription, Uri uri2) {
        this.f6631a = new InputContentInfo(uri, clipDescription, uri2);
    }

    public f(Object obj) {
        this.f6631a = (InputContentInfo) obj;
    }

    @Override // R.g
    public final Object c() {
        return this.f6631a;
    }

    @Override // R.g
    public final Uri e() {
        return this.f6631a.getContentUri();
    }

    @Override // R.g
    public final void f() {
        this.f6631a.requestPermission();
    }

    @Override // R.g
    public final Uri g() {
        return this.f6631a.getLinkUri();
    }

    @Override // R.g
    public final ClipDescription getDescription() {
        return this.f6631a.getDescription();
    }
}
