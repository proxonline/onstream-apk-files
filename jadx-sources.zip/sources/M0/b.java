package M0;

import H0.InterfaceC0169b;
import S0.d;

/* JADX INFO: loaded from: classes.dex */
public abstract class b implements d, InterfaceC0169b {
}
