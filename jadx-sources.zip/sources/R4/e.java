package R4;

import android.support.v4.media.session.z;
import java.util.logging.Logger;

/* JADX INFO: loaded from: classes.dex */
public final class e implements Q4.m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Logger f6721a = Logger.getLogger(e.class.getName());

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final e f6722b = new e();

    @Override // Q4.m
    public final Class a() {
        return Q4.a.class;
    }

    @Override // Q4.m
    public final Object b(z zVar) {
        return new d(zVar);
    }

    @Override // Q4.m
    public final Class c() {
        return Q4.a.class;
    }
}
