package R4;

import j$.util.DesugarCollections;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import p026c5.B;
import p026c5.C0619h;
import p026c5.C0634x;
import p026c5.J;
import p026c5.m0;
import p026c5.p0;
import p026c5.s0;
import p026c5.u0;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    static {
        f[] fVarArr = {new f(0, Q4.a.class)};
        HashMap map = new HashMap();
        f fVar = fVarArr[0];
        Class cls = fVar.f6723a;
        if (map.containsKey(cls)) {
            throw new IllegalArgumentException(B0.a.k(cls, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
        }
        map.put(cls, fVar);
        Class cls2 = fVarArr[0].f6723a;
        DesugarCollections.unmodifiableMap(map);
        f[] fVarArr2 = {new f(3, Q4.a.class)};
        HashMap map2 = new HashMap();
        f fVar2 = fVarArr2[0];
        Class cls3 = fVar2.f6723a;
        if (map2.containsKey(cls3)) {
            throw new IllegalArgumentException(B0.a.k(cls3, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
        }
        map2.put(cls3, fVar2);
        Class cls4 = fVarArr2[0].f6723a;
        DesugarCollections.unmodifiableMap(map2);
        f[] fVarArr3 = {new f(4, Q4.a.class)};
        HashMap map3 = new HashMap();
        f fVar3 = fVarArr3[0];
        Class cls5 = fVar3.f6723a;
        if (map3.containsKey(cls5)) {
            throw new IllegalArgumentException(B0.a.k(cls5, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
        }
        map3.put(cls5, fVar3);
        Class cls6 = fVarArr3[0].f6723a;
        DesugarCollections.unmodifiableMap(map3);
        f[] fVarArr4 = {new f(2, Q4.a.class)};
        HashMap map4 = new HashMap();
        f fVar4 = fVarArr4[0];
        Class cls7 = fVar4.f6723a;
        if (map4.containsKey(cls7)) {
            throw new IllegalArgumentException(B0.a.k(cls7, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
        }
        map4.put(cls7, fVar4);
        Class cls8 = fVarArr4[0].f6723a;
        DesugarCollections.unmodifiableMap(map4);
        f[] fVarArr5 = {new f(6, Q4.a.class)};
        HashMap map5 = new HashMap();
        f fVar5 = fVarArr5[0];
        Class cls9 = fVar5.f6723a;
        if (map5.containsKey(cls9)) {
            throw new IllegalArgumentException(B0.a.k(cls9, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
        }
        map5.put(cls9, fVar5);
        Class cls10 = fVarArr5[0].f6723a;
        DesugarCollections.unmodifiableMap(map5);
        f[] fVarArr6 = {new f(7, Q4.a.class)};
        HashMap map6 = new HashMap();
        f fVar6 = fVarArr6[0];
        Class cls11 = fVar6.f6723a;
        if (map6.containsKey(cls11)) {
            throw new IllegalArgumentException(B0.a.k(cls11, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
        }
        map6.put(cls11, fVar6);
        Class cls12 = fVarArr6[0].f6723a;
        DesugarCollections.unmodifiableMap(map6);
        f[] fVarArr7 = {new f(5, Q4.a.class)};
        HashMap map7 = new HashMap();
        f fVar7 = fVarArr7[0];
        Class cls13 = fVar7.f6723a;
        if (map7.containsKey(cls13)) {
            throw new IllegalArgumentException(B0.a.k(cls13, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
        }
        map7.put(cls13, fVar7);
        Class cls14 = fVarArr7[0].f6723a;
        DesugarCollections.unmodifiableMap(map7);
        f[] fVarArr8 = {new f(8, Q4.a.class)};
        HashMap map8 = new HashMap();
        f fVar8 = fVarArr8[0];
        Class cls15 = fVar8.f6723a;
        if (map8.containsKey(cls15)) {
            throw new IllegalArgumentException(B0.a.k(cls15, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
        }
        map8.put(cls15, fVar8);
        Class cls16 = fVarArr8[0].f6723a;
        DesugarCollections.unmodifiableMap(map8);
        int i9 = s0.CONFIG_NAME_FIELD_NUMBER;
        try {
            a();
        } catch (GeneralSecurityException e9) {
            throw new ExceptionInInitializerError(e9);
        }
    }

    public static void a() {
        Q4.n.g(e.f6722b);
        Y4.n.a();
        int i9 = 1;
        Q4.n.e(new h(C0619h.class, new f[]{new f(0, Q4.a.class)}, 0), true);
        int i10 = 3;
        Q4.n.e(new h(C0634x.class, new f[]{new f(3, Q4.a.class)}, 2), true);
        X4.k kVar = o.f6755a;
        X4.i iVar = X4.i.f8943b;
        iVar.e(o.f6755a);
        iVar.d(o.f6756b);
        iVar.c(o.f6757c);
        iVar.b(o.f6758d);
        if (U4.a.a()) {
            return;
        }
        Q4.n.e(new h(p026c5.r.class, new f[]{new f(2, Q4.a.class)}, i9), true);
        iVar.e(l.f6747a);
        iVar.d(l.f6748b);
        iVar.c(l.f6749c);
        iVar.b(l.f6750d);
        int i11 = 4;
        try {
            Cipher.getInstance("AES/GCM-SIV/NoPadding");
            Q4.n.e(new h(B.class, new f[]{new f(4, Q4.a.class)}, i10), true);
            iVar.e(r.f6761a);
            iVar.d(r.f6762b);
            iVar.c(r.f6763c);
            iVar.b(r.f6764d);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException unused) {
        }
        Q4.n.e(new h(J.class, new f[]{new f(5, Q4.a.class)}, i11), true);
        X4.k kVar2 = u.f6765a;
        X4.i iVar2 = X4.i.f8943b;
        iVar2.e(u.f6765a);
        iVar2.d(u.f6766b);
        iVar2.c(u.f6767c);
        iVar2.b(u.f6768d);
        Q4.n.e(new h(m0.class, new f[]{new f(6, Q4.a.class)}, 5), true);
        Q4.n.e(new h(p0.class, new f[]{new f(7, Q4.a.class)}, 6), true);
        Q4.n.e(new h(u0.class, new f[]{new f(8, Q4.a.class)}, 7), true);
        iVar2.e(y.f6772a);
        iVar2.d(y.f6773b);
        iVar2.c(y.f6774c);
        iVar2.b(y.f6775d);
    }
}
