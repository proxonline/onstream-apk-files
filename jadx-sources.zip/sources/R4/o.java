package R4;

/* JADX INFO: loaded from: classes.dex */
public abstract class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final X4.k f6755a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final X4.j f6756b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final X4.c f6757c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final X4.a f6758d;

    static {
        e5.a aVarB = X4.u.b("type.googleapis.com/google.crypto.tink.AesGcmKey");
        f6755a = new X4.k(n.class);
        f6756b = new X4.j(aVarB);
        f6757c = new X4.c(m.class);
        f6758d = new X4.a(aVarB, new C7.q(19));
    }
}
