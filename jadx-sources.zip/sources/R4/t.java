package R4;

/* JADX INFO: loaded from: classes.dex */
public abstract class t extends c {
}
