package R4;

/* JADX INFO: loaded from: classes.dex */
public abstract class c extends Q4.b {
}
