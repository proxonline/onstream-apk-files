package R4;

/* JADX INFO: loaded from: classes.dex */
public abstract class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final X4.k f6747a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final X4.j f6748b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final X4.c f6749c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final X4.a f6750d;

    static {
        e5.a aVarB = X4.u.b("type.googleapis.com/google.crypto.tink.AesEaxKey");
        f6747a = new X4.k(k.class);
        f6748b = new X4.j(aVarB);
        f6749c = new X4.c(i.class);
        f6750d = new X4.a(aVarB, new C7.q(18));
    }
}
