package R4;

import j$.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class k extends c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f6743b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f6744c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f6745d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final j f6746e;

    public k(int i9, int i10, int i11, j jVar) {
        this.f6743b = i9;
        this.f6744c = i10;
        this.f6745d = i11;
        this.f6746e = jVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof k)) {
            return false;
        }
        k kVar = (k) obj;
        return kVar.f6743b == this.f6743b && kVar.f6744c == this.f6744c && kVar.f6745d == this.f6745d && kVar.f6746e == this.f6746e;
    }

    public final int hashCode() {
        return Objects.hash(Integer.valueOf(this.f6743b), Integer.valueOf(this.f6744c), Integer.valueOf(this.f6745d), this.f6746e);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("AesEax Parameters (variant: ");
        sb.append(this.f6746e);
        sb.append(", ");
        sb.append(this.f6744c);
        sb.append("-byte IV, ");
        sb.append(this.f6745d);
        sb.append("-byte tag, and ");
        return p165r6.a.j(sb, this.f6743b, "-byte key)");
    }
}
