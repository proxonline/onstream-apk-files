package R4;

/* JADX INFO: loaded from: classes.dex */
public abstract class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final X4.k f6761a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final X4.j f6762b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final X4.c f6763c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final X4.a f6764d;

    static {
        e5.a aVarB = X4.u.b("type.googleapis.com/google.crypto.tink.AesGcmSivKey");
        f6761a = new X4.k(q.class);
        f6762b = new X4.j(aVarB);
        f6763c = new X4.c(p.class);
        f6764d = new X4.a(aVarB, new C7.q(20));
    }
}
