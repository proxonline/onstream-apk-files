package R4;

import a9.C0501u;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;

/* JADX INFO: loaded from: classes.dex */
public final class s extends b {
    public static s b(j jVar, C0501u c0501u, Integer num) throws GeneralSecurityException {
        e5.a aVar = (e5.a) c0501u.f10118b;
        j jVar2 = j.f6737n;
        if (jVar != jVar2 && num == null) {
            throw new GeneralSecurityException("For given Variant " + jVar + " the value of idRequirement must be non-null");
        }
        if (jVar == jVar2 && num != null) {
            throw new GeneralSecurityException("For given Variant NO_PREFIX the value of idRequirement must be null");
        }
        if (aVar.f17106a.length != 32) {
            throw new GeneralSecurityException("ChaCha20Poly1305 key must be constructed with key of length 32 bytes, not " + aVar.f17106a.length);
        }
        if (jVar == jVar2) {
            e5.a.a(new byte[0]);
        } else if (jVar == j.f6736m) {
            e5.a.a(ByteBuffer.allocate(5).put((byte) 0).putInt(num.intValue()).array());
        } else {
            if (jVar != j.f6735l) {
                throw new IllegalStateException("Unknown Variant: " + jVar);
            }
            e5.a.a(ByteBuffer.allocate(5).put((byte) 1).putInt(num.intValue()).array());
        }
        return new s();
    }
}
