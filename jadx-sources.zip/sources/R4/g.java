package R4;

import co.notix.R;
import com.google.crypto.tink.shaded.protobuf.AbstractC0840a;
import com.google.crypto.tink.shaded.protobuf.AbstractC0847h;
import com.google.crypto.tink.shaded.protobuf.C0846g;
import com.google.crypto.tink.shaded.protobuf.C0853n;
import j$.util.DesugarCollections;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.util.HashMap;
import java.util.Map;
import p026c5.A;
import p026c5.B;
import p026c5.C0612a;
import p026c5.C0613b;
import p026c5.C0614c;
import p026c5.C0615d;
import p026c5.C0616e;
import p026c5.C0617f;
import p026c5.C0618g;
import p026c5.C0619h;
import p026c5.C0621j;
import p026c5.C0622k;
import p026c5.C0623l;
import p026c5.C0625n;
import p026c5.C0627p;
import p026c5.C0628q;
import p026c5.C0630t;
import p026c5.C0632v;
import p026c5.C0633w;
import p026c5.C0634x;
import p026c5.C0636z;
import p026c5.D;
import p026c5.E;
import p026c5.F;
import p026c5.G;
import p026c5.H;
import p026c5.I;
import p026c5.J;
import p026c5.L;
import p026c5.O;
import p026c5.P;
import p026c5.Q;
import p026c5.T;
import p026c5.V;
import p026c5.l0;
import p026c5.m0;
import p026c5.n0;
import p026c5.o0;
import p026c5.p0;
import p026c5.q0;
import p026c5.t0;
import p026c5.u0;
import p026c5.v0;

/* JADX INFO: loaded from: classes.dex */
public final class g extends D.o {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f6725b = 0;

    public g(h hVar) {
        super(C0621j.class);
    }

    public g(h hVar, byte b10) {
        super(C0630t.class);
    }

    public g(h hVar, byte b10, byte b11) {
        super(q0.class);
    }

    public g(h hVar, byte b10, char c10) {
        super(v0.class);
    }

    public g(h hVar, byte b10, int i9) {
        super(H.class);
    }

    public g(h hVar, byte b10, boolean z9) {
        super(n0.class);
    }

    public g(h hVar, char c10) {
        super(C0636z.class);
    }

    public g(h hVar, int i9) {
        super(D.class);
    }

    public g(h hVar, short s9) {
        super(L.class);
    }

    public g(Y4.b bVar) {
        super(T.class);
    }

    public /* synthetic */ g(Class cls) {
        super(cls);
    }

    @Override // D.o
    public final AbstractC0840a Z(AbstractC0840a abstractC0840a) {
        switch (this.f6725b) {
            case 0:
                C0621j c0621j = (C0621j) abstractC0840a;
                f[] fVarArr = {new f(1, p036d5.m.class)};
                HashMap map = new HashMap();
                for (f fVar : fVarArr) {
                    Class cls = fVar.f6723a;
                    if (map.containsKey(cls)) {
                        throw new IllegalArgumentException(B0.a.k(cls, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
                    }
                    map.put(cls, fVar);
                }
                if (fVarArr.length > 0) {
                    Class cls2 = fVarArr[0].f6723a;
                }
                DesugarCollections.unmodifiableMap(map);
                C0625n c0625nY = c0621j.y();
                C0622k c0622kD = C0623l.D();
                C0627p c0627pA = c0625nY.A();
                c0622kD.e();
                C0623l.x((C0623l) c0622kD.f15611b, c0627pA);
                byte[] bArrA = p036d5.p.a(c0625nY.z());
                C0846g c0846gI = AbstractC0847h.i(bArrA, 0, bArrA.length);
                c0622kD.e();
                C0623l.y((C0623l) c0622kD.f15611b, c0846gI);
                c0622kD.e();
                C0623l.w((C0623l) c0622kD.f15611b);
                C0623l c0623l = (C0623l) c0622kD.b();
                f[] fVarArr2 = {new f(11, Q4.j.class)};
                HashMap map2 = new HashMap();
                for (f fVar2 : fVarArr2) {
                    Class cls3 = fVar2.f6723a;
                    if (map2.containsKey(cls3)) {
                        throw new IllegalArgumentException(B0.a.k(cls3, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
                    }
                    map2.put(cls3, fVar2);
                }
                if (fVarArr2.length > 0) {
                    Class cls4 = fVarArr2[0].f6723a;
                }
                DesugarCollections.unmodifiableMap(map2);
                T tZ = c0621j.z();
                P pD = Q.D();
                pD.e();
                Q.w((Q) pD.f15611b);
                V vA = tZ.A();
                pD.e();
                Q.x((Q) pD.f15611b, vA);
                byte[] bArrA2 = p036d5.p.a(tZ.z());
                C0846g c0846gI2 = AbstractC0847h.i(bArrA2, 0, bArrA2.length);
                pD.e();
                Q.y((Q) pD.f15611b, c0846gI2);
                Q q6 = (Q) pD.b();
                C0618g c0618gC = C0619h.C();
                c0618gC.e();
                C0619h.x((C0619h) c0618gC.f15611b, c0623l);
                c0618gC.e();
                C0619h.y((C0619h) c0618gC.f15611b, q6);
                c0618gC.e();
                C0619h.w((C0619h) c0618gC.f15611b);
                return (C0619h) c0618gC.b();
            case 1:
                C0630t c0630t = (C0630t) abstractC0840a;
                C0628q c0628qC = p026c5.r.C();
                byte[] bArrA3 = p036d5.p.a(c0630t.y());
                C0846g c0846gI3 = AbstractC0847h.i(bArrA3, 0, bArrA3.length);
                c0628qC.e();
                p026c5.r.y((p026c5.r) c0628qC.f15611b, c0846gI3);
                C0632v c0632vZ = c0630t.z();
                c0628qC.e();
                p026c5.r.x((p026c5.r) c0628qC.f15611b, c0632vZ);
                c0628qC.e();
                p026c5.r.w((p026c5.r) c0628qC.f15611b);
                return (p026c5.r) c0628qC.b();
            case 2:
                C0633w c0633wA = C0634x.A();
                byte[] bArrA4 = p036d5.p.a(((C0636z) abstractC0840a).x());
                C0846g c0846gI4 = AbstractC0847h.i(bArrA4, 0, bArrA4.length);
                c0633wA.e();
                C0634x.x((C0634x) c0633wA.f15611b, c0846gI4);
                c0633wA.e();
                C0634x.w((C0634x) c0633wA.f15611b);
                return (C0634x) c0633wA.b();
            case 3:
                A A9 = B.A();
                byte[] bArrA5 = p036d5.p.a(((D) abstractC0840a).x());
                C0846g c0846gI5 = AbstractC0847h.i(bArrA5, 0, bArrA5.length);
                A9.e();
                B.x((B) A9.f15611b, c0846gI5);
                A9.e();
                B.w((B) A9.f15611b);
                return (B) A9.b();
            case 4:
                I iA = J.A();
                iA.e();
                J.w((J) iA.f15611b);
                byte[] bArrA6 = p036d5.p.a(32);
                C0846g c0846gI6 = AbstractC0847h.i(bArrA6, 0, bArrA6.length);
                iA.e();
                J.x((J) iA.f15611b, c0846gI6);
                return (J) iA.b();
            case 5:
                l0 l0VarA = m0.A();
                l0VarA.e();
                m0.x((m0) l0VarA.f15611b, (n0) abstractC0840a);
                l0VarA.e();
                m0.w((m0) l0VarA.f15611b);
                return (m0) l0VarA.b();
            case 6:
                o0 o0VarA = p0.A();
                o0VarA.e();
                p0.x((p0) o0VarA.f15611b, (q0) abstractC0840a);
                o0VarA.e();
                p0.w((p0) o0VarA.f15611b);
                return (p0) o0VarA.b();
            case 7:
                t0 t0VarA = u0.A();
                t0VarA.e();
                u0.w((u0) t0VarA.f15611b);
                byte[] bArrA7 = p036d5.p.a(32);
                C0846g c0846gI7 = AbstractC0847h.i(bArrA7, 0, bArrA7.length);
                t0VarA.e();
                u0.x((u0) t0VarA.f15611b, c0846gI7);
                return (u0) t0VarA.b();
            case 8:
                E eA = F.A();
                byte[] bArrA8 = p036d5.p.a(((H) abstractC0840a).x());
                C0846g c0846gI8 = AbstractC0847h.i(bArrA8, 0, bArrA8.length);
                eA.e();
                F.x((F) eA.f15611b, c0846gI8);
                eA.e();
                F.w((F) eA.f15611b);
                return (F) eA.b();
            case 9:
                C0615d c0615d = (C0615d) abstractC0840a;
                C0612a c0612aC = C0613b.C();
                c0612aC.e();
                C0613b.w((C0613b) c0612aC.f15611b);
                byte[] bArrA9 = p036d5.p.a(c0615d.y());
                C0846g c0846gI9 = AbstractC0847h.i(bArrA9, 0, bArrA9.length);
                c0612aC.e();
                C0613b.x((C0613b) c0612aC.f15611b, c0846gI9);
                C0617f c0617fZ = c0615d.z();
                c0612aC.e();
                C0613b.y((C0613b) c0612aC.f15611b, c0617fZ);
                return (C0613b) c0612aC.b();
            default:
                T t8 = (T) abstractC0840a;
                P pD2 = Q.D();
                pD2.e();
                Q.w((Q) pD2.f15611b);
                V vA2 = t8.A();
                pD2.e();
                Q.x((Q) pD2.f15611b, vA2);
                byte[] bArrA10 = p036d5.p.a(t8.z());
                C0846g c0846gI10 = AbstractC0847h.i(bArrA10, 0, bArrA10.length);
                pD2.e();
                Q.y((Q) pD2.f15611b, c0846gI10);
                return (Q) pD2.b();
        }
    }

    @Override // D.o
    public Map i0() {
        switch (this.f6725b) {
            case 0:
                HashMap map = new HashMap();
                map.put("AES128_CTR_HMAC_SHA256", h.l(16, 16, 1));
                map.put("AES128_CTR_HMAC_SHA256_RAW", h.l(16, 16, 3));
                map.put("AES256_CTR_HMAC_SHA256", h.l(32, 32, 1));
                map.put("AES256_CTR_HMAC_SHA256_RAW", h.l(32, 32, 3));
                return DesugarCollections.unmodifiableMap(map);
            case 1:
                HashMap map2 = new HashMap();
                map2.put("AES128_EAX", h.k(16, 1));
                map2.put("AES128_EAX_RAW", h.k(16, 3));
                map2.put("AES256_EAX", h.k(32, 1));
                map2.put("AES256_EAX_RAW", h.k(32, 3));
                return DesugarCollections.unmodifiableMap(map2);
            case 2:
                HashMap map3 = new HashMap();
                map3.put("AES128_GCM", h.m(16, 1));
                map3.put("AES128_GCM_RAW", h.m(16, 3));
                map3.put("AES256_GCM", h.m(32, 1));
                map3.put("AES256_GCM_RAW", h.m(32, 3));
                return DesugarCollections.unmodifiableMap(map3);
            case 3:
                HashMap map4 = new HashMap();
                map4.put("AES128_GCM_SIV", h.n(16, 1));
                map4.put("AES128_GCM_SIV_RAW", h.n(16, 3));
                map4.put("AES256_GCM_SIV", h.n(32, 1));
                map4.put("AES256_GCM_SIV_RAW", h.n(32, 3));
                return DesugarCollections.unmodifiableMap(map4);
            case 4:
                HashMap map5 = new HashMap();
                map5.put("CHACHA20_POLY1305", new X4.d(L.w(), 1));
                map5.put("CHACHA20_POLY1305_RAW", new X4.d(L.w(), 3));
                return DesugarCollections.unmodifiableMap(map5);
            case 5:
            case 6:
            default:
                return super.i0();
            case 7:
                HashMap map6 = new HashMap();
                map6.put("XCHACHA20_POLY1305", new X4.d(v0.w(), 1));
                map6.put("XCHACHA20_POLY1305_RAW", new X4.d(v0.w(), 3));
                return DesugarCollections.unmodifiableMap(map6);
            case 8:
                HashMap map7 = new HashMap();
                G gY = H.y();
                gY.e();
                H.w((H) gY.f15611b);
                map7.put("AES256_SIV", new X4.d((H) gY.b(), 1));
                G gY2 = H.y();
                gY2.e();
                H.w((H) gY2.f15611b);
                map7.put("AES256_SIV_RAW", new X4.d((H) gY2.b(), 3));
                return DesugarCollections.unmodifiableMap(map7);
            case 9:
                HashMap map8 = new HashMap();
                C0614c c0614cA = C0615d.A();
                c0614cA.e();
                C0615d.w((C0615d) c0614cA.f15611b);
                C0616e c0616eZ = C0617f.z();
                c0616eZ.e();
                C0617f.w((C0617f) c0616eZ.f15611b);
                C0617f c0617f = (C0617f) c0616eZ.b();
                c0614cA.e();
                C0615d.x((C0615d) c0614cA.f15611b, c0617f);
                map8.put("AES_CMAC", new X4.d((C0615d) c0614cA.b(), 1));
                C0614c c0614cA2 = C0615d.A();
                c0614cA2.e();
                C0615d.w((C0615d) c0614cA2.f15611b);
                C0616e c0616eZ2 = C0617f.z();
                c0616eZ2.e();
                C0617f.w((C0617f) c0616eZ2.f15611b);
                C0617f c0617f2 = (C0617f) c0616eZ2.b();
                c0614cA2.e();
                C0615d.x((C0615d) c0614cA2.f15611b, c0617f2);
                map8.put("AES256_CMAC", new X4.d((C0615d) c0614cA2.b(), 1));
                C0614c c0614cA3 = C0615d.A();
                c0614cA3.e();
                C0615d.w((C0615d) c0614cA3.f15611b);
                C0616e c0616eZ3 = C0617f.z();
                c0616eZ3.e();
                C0617f.w((C0617f) c0616eZ3.f15611b);
                C0617f c0617f3 = (C0617f) c0616eZ3.b();
                c0614cA3.e();
                C0615d.x((C0615d) c0614cA3.f15611b, c0617f3);
                map8.put("AES256_CMAC_RAW", new X4.d((C0615d) c0614cA3.b(), 3));
                return DesugarCollections.unmodifiableMap(map8);
            case R.styleable.GradientColor_android_endX /* 10 */:
                HashMap map9 = new HashMap();
                O o4 = O.SHA256;
                map9.put("HMAC_SHA256_128BITTAG", Y4.b.k(32, 16, o4, 1));
                map9.put("HMAC_SHA256_128BITTAG_RAW", Y4.b.k(32, 16, o4, 3));
                map9.put("HMAC_SHA256_256BITTAG", Y4.b.k(32, 32, o4, 1));
                map9.put("HMAC_SHA256_256BITTAG_RAW", Y4.b.k(32, 32, o4, 3));
                O o9 = O.SHA512;
                map9.put("HMAC_SHA512_128BITTAG", Y4.b.k(64, 16, o9, 1));
                map9.put("HMAC_SHA512_128BITTAG_RAW", Y4.b.k(64, 16, o9, 3));
                map9.put("HMAC_SHA512_256BITTAG", Y4.b.k(64, 32, o9, 1));
                map9.put("HMAC_SHA512_256BITTAG_RAW", Y4.b.k(64, 32, o9, 3));
                map9.put("HMAC_SHA512_512BITTAG", Y4.b.k(64, 64, o9, 1));
                map9.put("HMAC_SHA512_512BITTAG_RAW", Y4.b.k(64, 64, o9, 3));
                return DesugarCollections.unmodifiableMap(map9);
        }
    }

    @Override // D.o
    public final AbstractC0840a j0(AbstractC0847h abstractC0847h) {
        switch (this.f6725b) {
            case 0:
                return C0621j.B(abstractC0847h, C0853n.a());
            case 1:
                return C0630t.B(abstractC0847h, C0853n.a());
            case 2:
                return C0636z.z(abstractC0847h, C0853n.a());
            case 3:
                return D.z(abstractC0847h, C0853n.a());
            case 4:
                return L.x(abstractC0847h, C0853n.a());
            case 5:
                return n0.y(abstractC0847h, C0853n.a());
            case 6:
                return q0.A(abstractC0847h, C0853n.a());
            case 7:
                return v0.x(abstractC0847h, C0853n.a());
            case 8:
                return H.z(abstractC0847h, C0853n.a());
            case 9:
                return C0615d.B(abstractC0847h, C0853n.a());
            default:
                return T.C(abstractC0847h, C0853n.a());
        }
    }

    @Override // D.o
    public final void q0(AbstractC0840a abstractC0840a) throws GeneralSecurityException {
        switch (this.f6725b) {
            case 0:
                C0621j c0621j = (C0621j) abstractC0840a;
                f[] fVarArr = {new f(1, p036d5.m.class)};
                HashMap map = new HashMap();
                for (f fVar : fVarArr) {
                    Class cls = fVar.f6723a;
                    if (map.containsKey(cls)) {
                        throw new IllegalArgumentException(B0.a.k(cls, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
                    }
                    map.put(cls, fVar);
                }
                if (fVarArr.length > 0) {
                    Class cls2 = fVarArr[0].f6723a;
                }
                DesugarCollections.unmodifiableMap(map);
                C0625n c0625nY = c0621j.y();
                p036d5.q.a(c0625nY.z());
                C0627p c0627pA = c0625nY.A();
                if (c0627pA.y() < 12 || c0627pA.y() > 16) {
                    throw new GeneralSecurityException("invalid IV size");
                }
                f[] fVarArr2 = {new f(11, Q4.j.class)};
                HashMap map2 = new HashMap();
                for (f fVar2 : fVarArr2) {
                    Class cls3 = fVar2.f6723a;
                    if (map2.containsKey(cls3)) {
                        throw new IllegalArgumentException(B0.a.k(cls3, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
                    }
                    map2.put(cls3, fVar2);
                }
                if (fVarArr2.length > 0) {
                    Class cls4 = fVarArr2[0].f6723a;
                }
                DesugarCollections.unmodifiableMap(map2);
                T tZ = c0621j.z();
                if (tZ.z() < 16) {
                    throw new GeneralSecurityException("key too short");
                }
                Y4.b.m(tZ.A());
                p036d5.q.a(c0621j.y().z());
                return;
            case 1:
                C0630t c0630t = (C0630t) abstractC0840a;
                p036d5.q.a(c0630t.y());
                if (c0630t.z().y() != 12 && c0630t.z().y() != 16) {
                    throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
                }
                return;
            case 2:
                p036d5.q.a(((C0636z) abstractC0840a).x());
                return;
            case 3:
                p036d5.q.a(((D) abstractC0840a).x());
                return;
            case 4:
                return;
            case 5:
                return;
            case 6:
                q0 q0Var = (q0) abstractC0840a;
                if (q0Var.y().isEmpty() || !q0Var.z()) {
                    throw new GeneralSecurityException("invalid key format: missing KEK URI or DEK template");
                }
                return;
            case 7:
                return;
            case 8:
                H h6 = (H) abstractC0840a;
                if (h6.x() == 64) {
                    return;
                }
                throw new InvalidAlgorithmParameterException("invalid key size: " + h6.x() + ". Valid keys must have 64 bytes.");
            case 9:
                C0615d c0615d = (C0615d) abstractC0840a;
                Y4.b.l(c0615d.z());
                if (c0615d.y() != 32) {
                    throw new GeneralSecurityException("AesCmacKey size wrong, must be 32 bytes");
                }
                return;
            default:
                T t8 = (T) abstractC0840a;
                if (t8.z() < 16) {
                    throw new GeneralSecurityException("key too short");
                }
                Y4.b.m(t8.A());
                return;
        }
    }
}
