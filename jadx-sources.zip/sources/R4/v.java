package R4;

import H0.C;
import com.google.crypto.tink.shaded.protobuf.AbstractC0840a;
import com.google.crypto.tink.shaded.protobuf.AbstractC0847h;
import com.google.crypto.tink.shaded.protobuf.B;
import com.google.crypto.tink.shaded.protobuf.C0846g;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import p026c5.b0;

/* JADX INFO: loaded from: classes.dex */
public final class v implements Q4.a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final byte[] f6769c = new byte[0];

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b0 f6770a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final W4.b f6771b;

    public v(b0 b0Var, W4.b bVar) {
        this.f6770a = b0Var;
        this.f6771b = bVar;
    }

    @Override // Q4.a
    public final byte[] a(byte[] bArr, byte[] bArr2) {
        AbstractC0840a abstractC0840aZ;
        b0 b0Var = this.f6770a;
        AtomicReference atomicReference = Q4.n.f6578a;
        synchronized (Q4.n.class) {
            try {
                C c10 = ((Q4.e) Q4.n.f6578a.get()).a(b0Var.B()).f6558a;
                Class cls = (Class) c10.f2717c;
                if (!((Map) c10.f2716b).keySet().contains(cls) && !Void.class.equals(cls)) {
                    throw new IllegalArgumentException("Given internalKeyMananger " + c10.toString() + " does not support primitive class " + cls.getName());
                }
                if (!((Boolean) Q4.n.f6580c.get(b0Var.B())).booleanValue()) {
                    throw new GeneralSecurityException("newKey-operation not permitted for key type " + b0Var.B());
                }
                AbstractC0847h abstractC0847hC = b0Var.C();
                try {
                    D.o oVarF = c10.f();
                    AbstractC0840a abstractC0840aJ0 = oVarF.j0(abstractC0847hC);
                    oVarF.q0(abstractC0840aJ0);
                    abstractC0840aZ = oVarF.Z(abstractC0840aJ0);
                } catch (B e9) {
                    throw new GeneralSecurityException("Failures parsing proto of type ".concat(((Class) c10.f().f923a).getName()), e9);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        byte[] bArrE = abstractC0840aZ.e();
        byte[] bArrA = this.f6771b.a(bArrE, f6769c);
        byte[] bArrA2 = ((Q4.a) Q4.n.c(this.f6770a.B(), AbstractC0847h.i(bArrE, 0, bArrE.length), Q4.a.class)).a(bArr, bArr2);
        return ByteBuffer.allocate(bArrA.length + 4 + bArrA2.length).putInt(bArrA.length).put(bArrA).put(bArrA2).array();
    }

    @Override // Q4.a
    public final byte[] b(byte[] bArr, byte[] bArr2) throws GeneralSecurityException {
        try {
            ByteBuffer byteBufferWrap = ByteBuffer.wrap(bArr);
            int i9 = byteBufferWrap.getInt();
            if (i9 <= 0 || i9 > bArr.length - 4) {
                throw new GeneralSecurityException("invalid ciphertext");
            }
            byte[] bArr3 = new byte[i9];
            byteBufferWrap.get(bArr3, 0, i9);
            byte[] bArr4 = new byte[byteBufferWrap.remaining()];
            byteBufferWrap.get(bArr4, 0, byteBufferWrap.remaining());
            byte[] bArrB = this.f6771b.b(bArr3, f6769c);
            String strB = this.f6770a.B();
            AtomicReference atomicReference = Q4.n.f6578a;
            C0846g c0846g = AbstractC0847h.f15563b;
            return ((Q4.a) Q4.n.c(strB, AbstractC0847h.i(bArrB, 0, bArrB.length), Q4.a.class)).b(bArr4, bArr2);
        } catch (IndexOutOfBoundsException e9) {
            e = e9;
            throw new GeneralSecurityException("invalid ciphertext", e);
        } catch (NegativeArraySizeException e10) {
            e = e10;
            throw new GeneralSecurityException("invalid ciphertext", e);
        } catch (BufferUnderflowException e11) {
            e = e11;
            throw new GeneralSecurityException("invalid ciphertext", e);
        }
    }
}
