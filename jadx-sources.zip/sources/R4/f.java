package R4;

import co.notix.R;
import com.google.crypto.tink.shaded.protobuf.AbstractC0840a;
import j$.util.DesugarCollections;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.spec.SecretKeySpec;
import p026c5.B;
import p026c5.C0613b;
import p026c5.C0619h;
import p026c5.C0623l;
import p026c5.C0634x;
import p026c5.F;
import p026c5.J;
import p026c5.O;
import p026c5.Q;
import p026c5.m0;
import p026c5.p0;
import p026c5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Class f6723a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f6724b;

    public f(int i9, Class cls) {
        this.f6724b = i9;
        this.f6723a = cls;
    }

    public final Object a(AbstractC0840a abstractC0840a) throws GeneralSecurityException {
        switch (this.f6724b) {
            case 0:
                C0619h c0619h = (C0619h) abstractC0840a;
                f[] fVarArr = {new f(1, p036d5.m.class)};
                HashMap map = new HashMap();
                for (f fVar : fVarArr) {
                    Class cls = fVar.f6723a;
                    if (map.containsKey(cls)) {
                        throw new IllegalArgumentException(B0.a.k(cls, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
                    }
                    map.put(cls, fVar);
                }
                if (fVarArr.length > 0) {
                    Class cls2 = fVarArr[0].f6723a;
                }
                Map mapUnmodifiableMap = DesugarCollections.unmodifiableMap(map);
                C0623l c0623lZ = c0619h.z();
                f fVar2 = (f) mapUnmodifiableMap.get(p036d5.m.class);
                if (fVar2 == null) {
                    throw new IllegalArgumentException("Requested primitive class " + p036d5.m.class.getCanonicalName() + " not supported.");
                }
                p036d5.m mVar = (p036d5.m) fVar2.a(c0623lZ);
                f[] fVarArr2 = {new f(11, Q4.j.class)};
                HashMap map2 = new HashMap();
                for (f fVar3 : fVarArr2) {
                    Class cls3 = fVar3.f6723a;
                    if (map2.containsKey(cls3)) {
                        throw new IllegalArgumentException(B0.a.k(cls3, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
                    }
                    map2.put(cls3, fVar3);
                }
                if (fVarArr2.length > 0) {
                    Class cls4 = fVarArr2[0].f6723a;
                }
                Map mapUnmodifiableMap2 = DesugarCollections.unmodifiableMap(map2);
                Q qA = c0619h.A();
                f fVar4 = (f) mapUnmodifiableMap2.get(Q4.j.class);
                if (fVar4 != null) {
                    return new p036d5.g(mVar, (Q4.j) fVar4.a(qA), c0619h.A().B().A());
                }
                throw new IllegalArgumentException("Requested primitive class " + Q4.j.class.getCanonicalName() + " not supported.");
            case 1:
                C0623l c0623l = (C0623l) abstractC0840a;
                return new p036d5.a(c0623l.B().y(), c0623l.A().l());
            case 2:
                p026c5.r rVar = (p026c5.r) abstractC0840a;
                return new p036d5.b(rVar.A().y(), rVar.z().l());
            case 3:
                return new p036d5.c(0, ((C0634x) abstractC0840a).y().l());
            case 4:
                return new T4.a(((B) abstractC0840a).y().l());
            case 5:
                return new p036d5.c(1, ((J) abstractC0840a).y().l());
            case 6:
                String strX = ((m0) abstractC0840a).y().x();
                return Q4.i.a(strX).c(strX);
            case 7:
                p0 p0Var = (p0) abstractC0840a;
                String strY = p0Var.y().y();
                return new v(p0Var.y().x(), Q4.i.a(strY).c(strY));
            case 8:
                return new p036d5.c(2, ((u0) abstractC0840a).y().l());
            case 9:
                return new p036d5.d(((F) abstractC0840a).y().l());
            case R.styleable.GradientColor_android_endX /* 10 */:
                C0613b c0613b = (C0613b) abstractC0840a;
                return new p036d5.o(new Y4.i(c0613b.z().l()), c0613b.A().y());
            default:
                Q q6 = (Q) abstractC0840a;
                O oZ = q6.B().z();
                SecretKeySpec secretKeySpec = new SecretKeySpec(q6.A().l(), "HMAC");
                int iA = q6.B().A();
                int iOrdinal = oZ.ordinal();
                if (iOrdinal == 1) {
                    return new p036d5.o(new p071h3.s("HMACSHA1", secretKeySpec), iA);
                }
                if (iOrdinal == 2) {
                    return new p036d5.o(new p071h3.s("HMACSHA384", secretKeySpec), iA);
                }
                if (iOrdinal == 3) {
                    return new p036d5.o(new p071h3.s("HMACSHA256", secretKeySpec), iA);
                }
                if (iOrdinal == 4) {
                    return new p036d5.o(new p071h3.s("HMACSHA512", secretKeySpec), iA);
                }
                if (iOrdinal == 5) {
                    return new p036d5.o(new p071h3.s("HMACSHA224", secretKeySpec), iA);
                }
                throw new GeneralSecurityException("unknown hash");
        }
    }
}
