package R4;

import j$.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class q extends c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f6759b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final j f6760c;

    public q(int i9, j jVar) {
        this.f6759b = i9;
        this.f6760c = jVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return qVar.f6759b == this.f6759b && qVar.f6760c == this.f6760c;
    }

    public final int hashCode() {
        return Objects.hash(Integer.valueOf(this.f6759b), this.f6760c);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("AesGcmSiv Parameters (variant: ");
        sb.append(this.f6760c);
        sb.append(", ");
        return p165r6.a.j(sb, this.f6759b, "-byte key)");
    }
}
