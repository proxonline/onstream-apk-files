package R4;

import X3.A;
import android.support.v4.media.session.z;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class d implements Q4.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final z f6718a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final A f6719b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final A f6720c;

    public d(z zVar) {
        this.f6718a = zVar;
        boolean zIsEmpty = ((p006a5.a) zVar.f10228d).f9932a.isEmpty();
        A a10 = X4.q.f8959a;
        if (zIsEmpty) {
            this.f6719b = a10;
            this.f6720c = a10;
            return;
        }
        X4.f fVar = (X4.f) X4.g.f8938b.f8940a.get();
        fVar = fVar == null ? X4.g.f8939c : fVar;
        X4.q.a(zVar);
        fVar.getClass();
        this.f6719b = a10;
        this.f6720c = a10;
    }

    @Override // Q4.a
    public final byte[] a(byte[] bArr, byte[] bArr2) throws GeneralSecurityException {
        A a10 = this.f6719b;
        z zVar = this.f6718a;
        try {
            byte[] bArr3 = ((Q4.k) zVar.f10227c).f6571c;
            byte[] bArrG = p012b1.a.g(bArr3 == null ? null : Arrays.copyOf(bArr3, bArr3.length), ((Q4.a) ((Q4.k) zVar.f10227c).f6570b).a(bArr, bArr2));
            int i9 = ((Q4.k) zVar.f10227c).f6574f;
            int length = bArr.length;
            a10.getClass();
            return bArrG;
        } catch (GeneralSecurityException e9) {
            a10.getClass();
            throw e9;
        }
    }

    @Override // Q4.a
    public final byte[] b(byte[] bArr, byte[] bArr2) throws GeneralSecurityException {
        int length = bArr.length;
        z zVar = this.f6718a;
        A a10 = this.f6720c;
        if (length > 5) {
            byte[] bArrCopyOf = Arrays.copyOf(bArr, 5);
            byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, 5, bArr.length);
            Iterator it = zVar.y(bArrCopyOf).iterator();
            while (it.hasNext()) {
                try {
                    byte[] bArrB = ((Q4.a) ((Q4.k) it.next()).f6570b).b(bArrCopyOfRange, bArr2);
                    a10.getClass();
                    return bArrB;
                } catch (GeneralSecurityException e9) {
                    e.f6721a.info("ciphertext prefix matches a key, but cannot decrypt: " + e9);
                }
            }
        }
        Iterator it2 = zVar.y(Q4.b.f6557a).iterator();
        while (it2.hasNext()) {
            try {
                byte[] bArrB2 = ((Q4.a) ((Q4.k) it2.next()).f6570b).b(bArr, bArr2);
                a10.getClass();
                return bArrB2;
            } catch (GeneralSecurityException unused) {
            }
        }
        a10.getClass();
        throw new GeneralSecurityException("decryption failed");
    }
}
