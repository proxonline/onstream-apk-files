package R4;

import j$.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class n extends c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f6751b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f6752c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f6753d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final j f6754e;

    public n(int i9, int i10, int i11, j jVar) {
        this.f6751b = i9;
        this.f6752c = i10;
        this.f6753d = i11;
        this.f6754e = jVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof n)) {
            return false;
        }
        n nVar = (n) obj;
        return nVar.f6751b == this.f6751b && nVar.f6752c == this.f6752c && nVar.f6753d == this.f6753d && nVar.f6754e == this.f6754e;
    }

    public final int hashCode() {
        return Objects.hash(Integer.valueOf(this.f6751b), Integer.valueOf(this.f6752c), Integer.valueOf(this.f6753d), this.f6754e);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("AesGcm Parameters (variant: ");
        sb.append(this.f6754e);
        sb.append(", ");
        sb.append(this.f6752c);
        sb.append("-byte IV, ");
        sb.append(this.f6753d);
        sb.append("-byte tag, and ");
        return p165r6.a.j(sb, this.f6751b, "-byte key)");
    }
}
