package R4;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final j f6727c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final j f6728d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final j f6729e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final j f6730f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final j f6731g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final j f6732h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final j f6733i;
    public static final j j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final j f6734k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final j f6735l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final j f6736m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final j f6737n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final j f6738o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final j f6739p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final j f6740q;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6741a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f6742b;

    static {
        int i9 = 0;
        f6727c = new j("TINK", i9);
        f6728d = new j("CRUNCHY", i9);
        f6729e = new j("NO_PREFIX", i9);
        int i10 = 1;
        f6730f = new j("TINK", i10);
        f6731g = new j("CRUNCHY", i10);
        f6732h = new j("NO_PREFIX", i10);
        int i11 = 2;
        f6733i = new j("TINK", i11);
        j = new j("CRUNCHY", i11);
        f6734k = new j("NO_PREFIX", i11);
        int i12 = 3;
        f6735l = new j("TINK", i12);
        f6736m = new j("CRUNCHY", i12);
        f6737n = new j("NO_PREFIX", i12);
        int i13 = 4;
        f6738o = new j("TINK", i13);
        f6739p = new j("CRUNCHY", i13);
        f6740q = new j("NO_PREFIX", i13);
    }

    public /* synthetic */ j(String str, int i9) {
        this.f6741a = i9;
        this.f6742b = str;
    }

    public final String toString() {
        switch (this.f6741a) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
        }
        return this.f6742b;
    }
}
