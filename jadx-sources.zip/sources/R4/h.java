package R4;

import H0.C;
import com.google.crypto.tink.shaded.protobuf.AbstractC0840a;
import com.google.crypto.tink.shaded.protobuf.AbstractC0847h;
import com.google.crypto.tink.shaded.protobuf.C0853n;
import j$.util.DesugarCollections;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.util.HashMap;
import p026c5.B;
import p026c5.C0619h;
import p026c5.C0620i;
import p026c5.C0621j;
import p026c5.C0623l;
import p026c5.C0624m;
import p026c5.C0625n;
import p026c5.C0626o;
import p026c5.C0627p;
import p026c5.C0629s;
import p026c5.C0630t;
import p026c5.C0631u;
import p026c5.C0632v;
import p026c5.C0634x;
import p026c5.C0635y;
import p026c5.C0636z;
import p026c5.D;
import p026c5.F;
import p026c5.J;
import p026c5.O;
import p026c5.Q;
import p026c5.S;
import p026c5.T;
import p026c5.U;
import p026c5.V;
import p026c5.X;
import p026c5.m0;
import p026c5.p0;
import p026c5.u0;

/* JADX INFO: loaded from: classes.dex */
public final class h extends C {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f6726d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h(Class cls, f[] fVarArr, int i9) {
        super(cls, fVarArr);
        this.f6726d = i9;
    }

    public static X4.d k(int i9, int i10) {
        C0629s c0629sA = C0630t.A();
        c0629sA.e();
        C0630t.x((C0630t) c0629sA.f15611b, i9);
        C0631u c0631uZ = C0632v.z();
        c0631uZ.e();
        C0632v.w((C0632v) c0631uZ.f15611b);
        C0632v c0632v = (C0632v) c0631uZ.b();
        c0629sA.e();
        C0630t.w((C0630t) c0629sA.f15611b, c0632v);
        return new X4.d((C0630t) c0629sA.b(), i10);
    }

    public static X4.d l(int i9, int i10, int i11) {
        C0624m c0624mB = C0625n.B();
        C0626o c0626oZ = C0627p.z();
        c0626oZ.e();
        C0627p.w((C0627p) c0626oZ.f15611b);
        C0627p c0627p = (C0627p) c0626oZ.b();
        c0624mB.e();
        C0625n.w((C0625n) c0624mB.f15611b, c0627p);
        c0624mB.e();
        C0625n.x((C0625n) c0624mB.f15611b, i9);
        C0625n c0625n = (C0625n) c0624mB.b();
        S sB = T.B();
        U uB = V.B();
        uB.e();
        V.w((V) uB.f15611b, O.SHA256);
        uB.e();
        V.x((V) uB.f15611b, i10);
        V v9 = (V) uB.b();
        sB.e();
        T.w((T) sB.f15611b, v9);
        sB.e();
        T.x((T) sB.f15611b, 32);
        T t8 = (T) sB.b();
        C0620i c0620iA = C0621j.A();
        c0620iA.e();
        C0621j.w((C0621j) c0620iA.f15611b, c0625n);
        c0620iA.e();
        C0621j.x((C0621j) c0620iA.f15611b, t8);
        return new X4.d((C0621j) c0620iA.b(), i11);
    }

    public static X4.d m(int i9, int i10) {
        C0635y c0635yY = C0636z.y();
        c0635yY.e();
        C0636z.w((C0636z) c0635yY.f15611b, i9);
        return new X4.d((C0636z) c0635yY.b(), i10);
    }

    public static X4.d n(int i9, int i10) {
        p026c5.C cY = D.y();
        cY.e();
        D.w((D) cY.f15611b, i9);
        return new X4.d((D) cY.b(), i10);
    }

    @Override // H0.C
    public int c() {
        switch (this.f6726d) {
            case 0:
                return 2;
            case 1:
            default:
                return super.c();
            case 2:
                return 2;
        }
    }

    @Override // H0.C
    public final String d() {
        switch (this.f6726d) {
            case 0:
                return "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey";
            case 1:
                return "type.googleapis.com/google.crypto.tink.AesEaxKey";
            case 2:
                return "type.googleapis.com/google.crypto.tink.AesGcmKey";
            case 3:
                return "type.googleapis.com/google.crypto.tink.AesGcmSivKey";
            case 4:
                return "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key";
            case 5:
                return "type.googleapis.com/google.crypto.tink.KmsAeadKey";
            case 6:
                return "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey";
            case 7:
                return "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key";
            default:
                return "type.googleapis.com/google.crypto.tink.AesSivKey";
        }
    }

    @Override // H0.C
    public final D.o f() {
        switch (this.f6726d) {
            case 0:
                return new g(this);
            case 1:
                return new g(this, (byte) 0);
            case 2:
                return new g(this, (char) 0);
            case 3:
                return new g(this, 0);
            case 4:
                return new g(this, (short) 0);
            case 5:
                return new g(this, (byte) 0, false);
            case 6:
                return new g(this, (byte) 0, (byte) 0);
            case 7:
                return new g(this, (byte) 0, (char) 0);
            default:
                return new g(this, (byte) 0, 0);
        }
    }

    @Override // H0.C
    public final X g() {
        switch (this.f6726d) {
            case 0:
                return X.SYMMETRIC;
            case 1:
                return X.SYMMETRIC;
            case 2:
                return X.SYMMETRIC;
            case 3:
                return X.SYMMETRIC;
            case 4:
                return X.SYMMETRIC;
            case 5:
                return X.REMOTE;
            case 6:
                return X.REMOTE;
            case 7:
                return X.SYMMETRIC;
            default:
                return X.SYMMETRIC;
        }
    }

    @Override // H0.C
    public final AbstractC0840a h(AbstractC0847h abstractC0847h) {
        switch (this.f6726d) {
            case 0:
                return C0619h.D(abstractC0847h, C0853n.a());
            case 1:
                return p026c5.r.D(abstractC0847h, C0853n.a());
            case 2:
                return C0634x.B(abstractC0847h, C0853n.a());
            case 3:
                return B.B(abstractC0847h, C0853n.a());
            case 4:
                return J.B(abstractC0847h, C0853n.a());
            case 5:
                return m0.B(abstractC0847h, C0853n.a());
            case 6:
                return p0.B(abstractC0847h, C0853n.a());
            case 7:
                return u0.B(abstractC0847h, C0853n.a());
            default:
                return F.B(abstractC0847h, C0853n.a());
        }
    }

    @Override // H0.C
    public final void j(AbstractC0840a abstractC0840a) throws GeneralSecurityException {
        switch (this.f6726d) {
            case 0:
                C0619h c0619h = (C0619h) abstractC0840a;
                p036d5.q.c(c0619h.B());
                f[] fVarArr = {new f(1, p036d5.m.class)};
                HashMap map = new HashMap();
                f fVar = fVarArr[0];
                Class cls = fVar.f6723a;
                if (map.containsKey(cls)) {
                    throw new IllegalArgumentException(B0.a.k(cls, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
                }
                map.put(cls, fVar);
                Class cls2 = fVarArr[0].f6723a;
                DesugarCollections.unmodifiableMap(map);
                C0623l c0623lZ = c0619h.z();
                p036d5.q.c(c0623lZ.C());
                p036d5.q.a(c0623lZ.A().size());
                C0627p c0627pB = c0623lZ.B();
                if (c0627pB.y() < 12 || c0627pB.y() > 16) {
                    throw new GeneralSecurityException("invalid IV size");
                }
                f[] fVarArr2 = {new f(11, Q4.j.class)};
                HashMap map2 = new HashMap();
                f fVar2 = fVarArr2[0];
                Class cls3 = fVar2.f6723a;
                if (map2.containsKey(cls3)) {
                    throw new IllegalArgumentException(B0.a.k(cls3, new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive ")));
                }
                map2.put(cls3, fVar2);
                Class cls4 = fVarArr2[0].f6723a;
                DesugarCollections.unmodifiableMap(map2);
                Q qA = c0619h.A();
                p036d5.q.c(qA.C());
                if (qA.A().size() < 16) {
                    throw new GeneralSecurityException("key too short");
                }
                Y4.b.m(qA.B());
                return;
            case 1:
                p026c5.r rVar = (p026c5.r) abstractC0840a;
                p036d5.q.c(rVar.B());
                p036d5.q.a(rVar.z().size());
                if (rVar.A().y() != 12 && rVar.A().y() != 16) {
                    throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
                }
                return;
            case 2:
                C0634x c0634x = (C0634x) abstractC0840a;
                p036d5.q.c(c0634x.z());
                p036d5.q.a(c0634x.y().size());
                return;
            case 3:
                B b10 = (B) abstractC0840a;
                p036d5.q.c(b10.z());
                p036d5.q.a(b10.y().size());
                return;
            case 4:
                J j = (J) abstractC0840a;
                p036d5.q.c(j.z());
                if (j.y().size() != 32) {
                    throw new GeneralSecurityException("invalid ChaCha20Poly1305Key: incorrect key length");
                }
                return;
            case 5:
                p036d5.q.c(((m0) abstractC0840a).z());
                return;
            case 6:
                p036d5.q.c(((p0) abstractC0840a).z());
                return;
            case 7:
                u0 u0Var = (u0) abstractC0840a;
                p036d5.q.c(u0Var.z());
                if (u0Var.y().size() != 32) {
                    throw new GeneralSecurityException("invalid XChaCha20Poly1305Key: incorrect key length");
                }
                return;
            default:
                F f3 = (F) abstractC0840a;
                p036d5.q.c(f3.z());
                if (f3.y().size() == 64) {
                    return;
                }
                throw new InvalidKeyException("invalid key size: " + f3.y().size() + ". Valid keys must have 64 bytes.");
        }
    }
}
