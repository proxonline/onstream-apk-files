package R4;

/* JADX INFO: loaded from: classes.dex */
public abstract class b extends Q4.b {
}
