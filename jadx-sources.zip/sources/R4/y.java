package R4;

/* JADX INFO: loaded from: classes.dex */
public abstract class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final X4.k f6772a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final X4.j f6773b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final X4.c f6774c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final X4.a f6775d;

    static {
        e5.a aVarB = X4.u.b("type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key");
        f6772a = new X4.k(x.class);
        f6773b = new X4.j(aVarB);
        f6774c = new X4.c(w.class);
        f6775d = new X4.a(aVarB, new C7.q(22));
    }
}
