package R4;

/* JADX INFO: loaded from: classes.dex */
public abstract class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final X4.k f6765a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final X4.j f6766b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final X4.c f6767c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final X4.a f6768d;

    static {
        e5.a aVarB = X4.u.b("type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key");
        f6765a = new X4.k(t.class);
        f6766b = new X4.j(aVarB);
        f6767c = new X4.c(s.class);
        f6768d = new X4.a(aVarB, new C7.q(21));
    }
}
