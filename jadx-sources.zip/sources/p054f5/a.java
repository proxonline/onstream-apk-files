package p054f5;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f17844a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f17845b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f17846c;

    public a(long j, long j9, long j10) {
        this.f17844a = j;
        this.f17845b = j9;
        this.f17846c = j10;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof a) {
            a aVar = (a) obj;
            if (this.f17844a == aVar.f17844a && this.f17845b == aVar.f17845b && this.f17846c == aVar.f17846c) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        long j = this.f17844a;
        long j9 = this.f17845b;
        int i9 = (((((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003) ^ ((int) (j9 ^ (j9 >>> 32)))) * 1000003;
        long j10 = this.f17846c;
        return i9 ^ ((int) ((j10 >>> 32) ^ j10));
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("StartupTime{epochMillis=");
        sb.append(this.f17844a);
        sb.append(", elapsedRealtime=");
        sb.append(this.f17845b);
        sb.append(", uptimeMillis=");
        return B0.a.p(sb, this.f17846c, "}");
    }
}
