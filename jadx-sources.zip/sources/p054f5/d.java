package p054f5;

import K5.e;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;
import p225z3.InterfaceC1405c;

/* JADX INFO: loaded from: classes.dex */
public final class d implements InterfaceC1405c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final AtomicReference f17862a = new AtomicReference();

    @Override // p225z3.InterfaceC1405c
    public final void a(boolean z9) {
        synchronized (f.f17865k) {
            try {
                ArrayList arrayList = new ArrayList(f.f17866l.values());
                int size = arrayList.size();
                int i9 = 0;
                while (i9 < size) {
                    Object obj = arrayList.get(i9);
                    i9++;
                    f fVar = (f) obj;
                    if (fVar.f17871e.get()) {
                        Log.d("FirebaseApp", "Notifying background state change listeners.");
                        Iterator it = fVar.f17875i.iterator();
                        while (it.hasNext()) {
                            f fVar2 = ((c) it.next()).f17861a;
                            if (!z9) {
                                ((e) fVar2.f17874h.get()).c();
                            }
                        }
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
