package p054f5;

import B8.D;
import C1.b;
import java.util.concurrent.Executor;
import kotlin.jvm.internal.h;
import p109l5.a;
import p109l5.c;
import p119m5.d;
import p119m5.p;

/* JADX INFO: loaded from: classes.dex */
public final class g implements d {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final g f17876b = new g(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final g f17877c = new g(1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final g f17878d = new g(2);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final g f17879e = new g(3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f17880a;

    public /* synthetic */ g(int i9) {
        this.f17880a = i9;
    }

    @Override // p119m5.d
    public final Object l(b bVar) {
        switch (this.f17880a) {
            case 0:
                Object objF = bVar.f(new p(a.class, Executor.class));
                h.d(objF, "c.get(Qualified.qualifie…a, Executor::class.java))");
                return D.j((Executor) objF);
            case 1:
                Object objF2 = bVar.f(new p(c.class, Executor.class));
                h.d(objF2, "c.get(Qualified.qualifie…a, Executor::class.java))");
                return D.j((Executor) objF2);
            case 2:
                Object objF3 = bVar.f(new p(p109l5.b.class, Executor.class));
                h.d(objF3, "c.get(Qualified.qualifie…a, Executor::class.java))");
                return D.j((Executor) objF3);
            default:
                Object objF4 = bVar.f(new p(p109l5.d.class, Executor.class));
                h.d(objF4, "c.get(Qualified.qualifie…a, Executor::class.java))");
                return D.j((Executor) objF4);
        }
    }
}
