package p054f5;

import B3.z;
import L.c;
import M5.b;
import R5.a;
import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.util.Base64;
import android.util.Log;
import com.google.firebase.FirebaseCommonRegistrar;
import com.google.firebase.components.ComponentDiscoveryService;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.provider.FirebaseInitProvider;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import p119m5.l;
import p129n5.k;
import p158r.e;
import p225z3.d;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final Object f17865k = new Object();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final e f17866l = new e(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f17867a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f17868b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final i f17869c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p119m5.e f17870d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final l f17873g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final b f17874h;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final AtomicBoolean f17871e = new AtomicBoolean(false);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final AtomicBoolean f17872f = new AtomicBoolean();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final CopyOnWriteArrayList f17875i = new CopyOnWriteArrayList();
    public final CopyOnWriteArrayList j = new CopyOnWriteArrayList();

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r4v9 */
    public f(Context context, i iVar, String str) {
        ?? arrayList;
        Iterator it;
        this.f17867a = context;
        z.e(str);
        this.f17868b = str;
        this.f17869c = iVar;
        a aVar = FirebaseInitProvider.f15743a;
        Trace.beginSection("Firebase");
        Trace.beginSection("ComponentDiscovery");
        ArrayList arrayList2 = new ArrayList();
        Bundle bundle = null;
        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                Log.w("ComponentDiscovery", "Context has no PackageManager.");
            } else {
                ServiceInfo serviceInfo = packageManager.getServiceInfo(new ComponentName(context, (Class<?>) ComponentDiscoveryService.class), 128);
                if (serviceInfo == null) {
                    Log.w("ComponentDiscovery", ComponentDiscoveryService.class + " has no service info.");
                } else {
                    bundle = serviceInfo.metaData;
                }
            }
            while (true) {
                ?? r9 = 1;
                if (!it.hasNext()) {
                    break;
                } else {
                    arrayList2.add(new N5.b(r9 == true ? 1 : 0, (String) it.next()));
                }
            }
        } catch (PackageManager.NameNotFoundException unused) {
            Log.w("ComponentDiscovery", "Application info not found.");
        }
        if (bundle == null) {
            Log.w("ComponentDiscovery", "Could not retrieve metadata, returning empty list of registrars.");
            arrayList = Collections.EMPTY_LIST;
        } else {
            arrayList = new ArrayList();
            for (String str2 : bundle.keySet()) {
                if ("com.google.firebase.components.ComponentRegistrar".equals(bundle.get(str2)) && str2.startsWith("com.google.firebase.components:")) {
                    arrayList.add(str2.substring(31));
                }
            }
        }
        it = arrayList.iterator();
        Trace.endSection();
        Trace.beginSection("Runtime");
        k kVar = k.f21711a;
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        arrayList3.addAll(arrayList2);
        int i9 = 2;
        arrayList3.add(new N5.b(i9, new FirebaseCommonRegistrar()));
        arrayList3.add(new N5.b(i9, new ExecutorsRegistrar()));
        arrayList4.add(p119m5.b.c(context, Context.class, new Class[0]));
        arrayList4.add(p119m5.b.c(this, f.class, new Class[0]));
        arrayList4.add(p119m5.b.c(iVar, i.class, new Class[0]));
        p033d2.b bVar = new p033d2.b(13);
        if ((Build.VERSION.SDK_INT >= 24 ? c.f(context) : true) && FirebaseInitProvider.f15744b.get()) {
            arrayList4.add(p119m5.b.c(aVar, a.class, new Class[0]));
        }
        p119m5.e eVar = new p119m5.e(arrayList3, arrayList4, bVar);
        this.f17870d = eVar;
        Trace.endSection();
        this.f17873g = new l(new K5.c(this, context));
        this.f17874h = eVar.g(K5.e.class);
        c cVar = new c(this);
        a();
        if (this.f17871e.get()) {
            d.f26466e.f26467a.get();
        }
        this.f17875i.add(cVar);
        Trace.endSection();
    }

    public static f c() {
        f fVar;
        synchronized (f17865k) {
            try {
                fVar = (f) f17866l.get("[DEFAULT]");
                if (fVar == null) {
                    throw new IllegalStateException("Default FirebaseApp is not initialized in this process " + G3.b.b() + ". Make sure to call FirebaseApp.initializeApp(Context) first.");
                }
                ((K5.e) fVar.f17874h.get()).c();
            } catch (Throwable th) {
                throw th;
            }
        }
        return fVar;
    }

    public static f f(Context context) {
        synchronized (f17865k) {
            try {
                if (f17866l.containsKey("[DEFAULT]")) {
                    return c();
                }
                i iVarA = i.a(context);
                if (iVarA == null) {
                    Log.w("FirebaseApp", "Default FirebaseApp failed to initialize because no default options were found. This usually means that com.google.gms:google-services was not applied to your gradle project.");
                    return null;
                }
                return g(context, iVarA, "[DEFAULT]");
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static f g(Context context, i iVar, String str) {
        f fVar;
        AtomicReference atomicReference = d.f17862a;
        if (context.getApplicationContext() instanceof Application) {
            Application application = (Application) context.getApplicationContext();
            AtomicReference atomicReference2 = d.f17862a;
            if (atomicReference2.get() == null) {
                d dVar = new d();
                do {
                    if (atomicReference2.compareAndSet(null, dVar)) {
                        d.b(application);
                        d.f26466e.a(dVar);
                        break;
                    }
                } while (atomicReference2.get() == null);
            }
        }
        String strTrim = str.trim();
        if (context.getApplicationContext() != null) {
            context = context.getApplicationContext();
        }
        synchronized (f17865k) {
            e eVar = f17866l;
            z.j("FirebaseApp name " + strTrim + " already exists!", !eVar.containsKey(strTrim));
            z.i(context, "Application context cannot be null.");
            fVar = new f(context, iVar, strTrim);
            eVar.put(strTrim, fVar);
        }
        fVar.e();
        return fVar;
    }

    public final void a() {
        z.j("FirebaseApp was deleted", !this.f17872f.get());
    }

    public final Object b(Class cls) {
        a();
        return this.f17870d.b(cls);
    }

    public final String d() {
        StringBuilder sb = new StringBuilder();
        a();
        byte[] bytes = this.f17868b.getBytes(Charset.defaultCharset());
        sb.append(bytes == null ? null : Base64.encodeToString(bytes, 11));
        sb.append("+");
        a();
        byte[] bytes2 = this.f17869c.f17882b.getBytes(Charset.defaultCharset());
        sb.append(bytes2 != null ? Base64.encodeToString(bytes2, 11) : null);
        return sb.toString();
    }

    public final void e() {
        HashMap map;
        if (!(Build.VERSION.SDK_INT >= 24 ? c.f(this.f17867a) : true)) {
            StringBuilder sb = new StringBuilder("Device in Direct Boot Mode: postponing initialization of Firebase APIs for app ");
            a();
            sb.append(this.f17868b);
            Log.i("FirebaseApp", sb.toString());
            Context context = this.f17867a;
            AtomicReference atomicReference = e.f17863b;
            if (atomicReference.get() == null) {
                e eVar = new e(context);
                while (!atomicReference.compareAndSet(null, eVar)) {
                    if (atomicReference.get() != null) {
                        return;
                    }
                }
                context.registerReceiver(eVar, new IntentFilter("android.intent.action.USER_UNLOCKED"));
                return;
            }
            return;
        }
        StringBuilder sb2 = new StringBuilder("Device unlocked: initializing all Firebase APIs for app ");
        a();
        sb2.append(this.f17868b);
        Log.i("FirebaseApp", sb2.toString());
        p119m5.e eVar2 = this.f17870d;
        a();
        boolean zEquals = "[DEFAULT]".equals(this.f17868b);
        AtomicReference atomicReference2 = eVar2.f21351f;
        Boolean boolValueOf = Boolean.valueOf(zEquals);
        while (!atomicReference2.compareAndSet(null, boolValueOf)) {
            if (atomicReference2.get() != null) {
                ((K5.e) this.f17874h.get()).c();
            }
        }
        synchronized (eVar2) {
            map = new HashMap(eVar2.f21346a);
        }
        eVar2.a(map, zEquals);
        ((K5.e) this.f17874h.get()).c();
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        fVar.a();
        return this.f17868b.equals(fVar.f17868b);
    }

    public final boolean h() {
        boolean z9;
        a();
        a aVar = (a) this.f17873g.get();
        synchronized (aVar) {
            z9 = aVar.f6776a;
        }
        return z9;
    }

    public final int hashCode() {
        return this.f17868b.hashCode();
    }

    public final String toString() {
        A5.e eVar = new A5.e(this);
        eVar.c(this.f17868b, "name");
        eVar.c(this.f17869c, "options");
        return eVar.toString();
    }
}
