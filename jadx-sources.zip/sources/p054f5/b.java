package p054f5;

import B3.z;
import B8.C0058s;
import G0.C0125i;
import G8.e;
import H0.B;
import H0.D;
import H0.InterfaceC0180m;
import H0.w;
import L4.F;
import N0.g;
import N0.h;
import N0.j;
import Y8.AbstractC0461a;
import Y8.C0470j;
import a9.C0489h;
import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Build;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import android.util.LongSparseArray;
import android.view.View;
import com.google.android.gms.internal.measurement.AbstractC0746h;
import com.google.android.gms.internal.measurement.C0726d;
import com.google.android.gms.internal.measurement.C0736f;
import com.google.android.gms.internal.measurement.C0741g;
import com.google.android.gms.internal.measurement.C0771m;
import com.google.android.gms.internal.measurement.C0805t;
import com.google.android.gms.internal.measurement.I1;
import com.google.android.gms.internal.measurement.InterfaceC0776n;
import com.google.firebase.messaging.s;
import com.maertsno.domain.model.EpisodeSource;
import h8.d;
import h8.f;
import h8.i;
import j$.util.DesugarCollections;
import j$.util.Objects;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import p015b4.k;
import p015b4.n;
import p015b4.p;
import p048e8.q;
import p048e8.r;
import p052f2.Y;
import p052f2.j0;
import p062g3.InterfaceC0952m;
import p071h3.a;
import p071h3.y;
import p167r8.l;
import p195v5.u0;
import p200w0.C1368c;
import p219y6.G;
import p219y6.H;
import p224z2.c;
import p229z8.m;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f17847a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f17848b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Field f17849c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static boolean f17850d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Class f17851e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static boolean f17852f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static Field f17853g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static boolean f17854h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static Field f17855i;
    public static boolean j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final /* synthetic */ int f17856k = 0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final /* synthetic */ int f17857l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final /* synthetic */ int f17858m = 0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final /* synthetic */ int f17859n = 0;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final /* synthetic */ int f17860o = 0;

    public static c B(List list) {
        ArrayList arrayList = new ArrayList();
        for (int i9 = 0; i9 < list.size(); i9++) {
            String str = (String) list.get(i9);
            int i10 = y.f18900a;
            String[] strArrSplit = str.split("=", 2);
            if (strArrSplit.length != 2) {
                a.P("VorbisUtil", "Failed to parse Vorbis comment: ".concat(str));
            } else if (strArrSplit[0].equals("METADATA_BLOCK_PICTURE")) {
                try {
                    arrayList.add(C2.a.a(new S8.y(Base64.decode(strArrSplit[1], 0))));
                } catch (RuntimeException e9) {
                    a.Q("VorbisUtil", "Failed to parse vorbis picture", e9);
                }
            } else {
                arrayList.add(new H2.a(strArrSplit[0], strArrSplit[1]));
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return new c(arrayList);
    }

    /* JADX WARN: Code duplicated, block: B:42:0x00b9 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:43:0x00bb  */
    /* JADX WARN: Code duplicated, block: B:46:0x00c0  */
    /* JADX WARN: Code duplicated, block: B:48:0x00c6  */
    /* JADX WARN: Code duplicated, block: B:50:0x00ca  */
    /* JADX WARN: Code duplicated, block: B:51:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:8:0x0016  */
    public static final Object C(w wVar, d dVar, l lVar, boolean z9, boolean z10) {
        h hVar;
        i iVarPlus;
        w wVar2;
        l lVar2;
        boolean z11;
        boolean z12;
        e eVar;
        if (dVar instanceof h) {
            hVar = (h) dVar;
            int i9 = hVar.f4831w;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                hVar.f4831w = i9 - Integer.MIN_VALUE;
            } else {
                hVar = new h(dVar);
            }
        } else {
            hVar = new h(dVar);
        }
        h hVar2 = hVar;
        Object obj = hVar2.f4830v;
        int i10 = hVar2.f4831w;
        p084i8.a aVar = p084i8.a.f19475a;
        if (i10 == 0) {
            u0.F(obj);
            if (wVar.l() && wVar.p() && wVar.m()) {
                j jVar = new j(wVar, null, lVar, z10, z9);
                hVar2.f4831w = 1;
                Object objR = wVar.r(z9, jVar, hVar2);
                if (objR != aVar) {
                    return objR;
                }
            } else {
                hVar2.f4826r = wVar;
                hVar2.f4827s = lVar;
                hVar2.f4828t = z9;
                hVar2.f4829u = z10;
                hVar2.f4831w = 2;
                if (wVar.l()) {
                    D d9 = (D) hVar2.getContext().get(D.f2718c);
                    if (d9 != null) {
                        f fVar = d9.f2719a;
                        e eVar2 = wVar.f2867a;
                        if (eVar2 == null) {
                            kotlin.jvm.internal.h.j("coroutineScope");
                            throw null;
                        }
                        iVarPlus = eVar2.f2636a.plus(fVar);
                        if (iVarPlus == null) {
                            if (z10) {
                                iVarPlus = wVar.f2868b;
                                if (iVarPlus == null) {
                                    kotlin.jvm.internal.h.j("transactionContext");
                                    throw null;
                                }
                            } else {
                                eVar = wVar.f2867a;
                                if (eVar != null) {
                                    kotlin.jvm.internal.h.j("coroutineScope");
                                    throw null;
                                }
                                iVarPlus = eVar.f2636a;
                            }
                        }
                    } else if (z10) {
                        iVarPlus = wVar.f2868b;
                        if (iVarPlus == null) {
                            kotlin.jvm.internal.h.j("transactionContext");
                            throw null;
                        }
                    } else {
                        eVar = wVar.f2867a;
                        if (eVar != null) {
                            kotlin.jvm.internal.h.j("coroutineScope");
                            throw null;
                        }
                        iVarPlus = eVar.f2636a;
                    }
                } else {
                    e eVar3 = wVar.f2867a;
                    if (eVar3 == null) {
                        kotlin.jvm.internal.h.j("coroutineScope");
                        throw null;
                    }
                    iVarPlus = eVar3.f2636a;
                }
                if (iVarPlus != aVar) {
                    wVar2 = wVar;
                    lVar2 = lVar;
                    z11 = z10;
                    obj = iVarPlus;
                    z12 = z9;
                }
            }
        }
        if (i10 == 1) {
            u0.F(obj);
            return obj;
        }
        if (i10 != 2) {
            if (i10 != 3) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(obj);
            return obj;
        }
        boolean z13 = hVar2.f4829u;
        boolean z14 = hVar2.f4828t;
        l lVar3 = hVar2.f4827s;
        w wVar3 = hVar2.f4826r;
        u0.F(obj);
        z11 = z13;
        z12 = z14;
        lVar2 = lVar3;
        wVar2 = wVar3;
        g gVar = new g(wVar2, null, lVar2, z12, z11);
        hVar2.f4826r = null;
        hVar2.f4827s = null;
        hVar2.f4831w = 3;
        Object objC = B8.D.C((i) obj, gVar, hVar2);
        return objC == aVar ? aVar : objC;
    }

    public static String D(X509Certificate x509Certificate) {
        StringBuilder sb = new StringBuilder("sha256/");
        C0470j c0470j = C0470j.f9476d;
        byte[] encoded = x509Certificate.getPublicKey().getEncoded();
        kotlin.jvm.internal.h.d(encoded, "publicKey.encoded");
        int length = encoded.length;
        int i9 = 0;
        K3.h.c(encoded.length, 0, length);
        byte[] bArr = new C0470j(p048e8.h.W(encoded, 0, length)).b("SHA-256").f9477a;
        byte[] map = AbstractC0461a.f9458a;
        kotlin.jvm.internal.h.e(bArr, "<this>");
        kotlin.jvm.internal.h.e(map, "map");
        byte[] bArr2 = new byte[((bArr.length + 2) / 3) * 4];
        int length2 = bArr.length - (bArr.length % 3);
        int i10 = 0;
        while (i9 < length2) {
            byte b10 = bArr[i9];
            int i11 = i9 + 2;
            byte b11 = bArr[i9 + 1];
            i9 += 3;
            byte b12 = bArr[i11];
            bArr2[i10] = map[(b10 & 255) >> 2];
            bArr2[i10 + 1] = map[((b10 & 3) << 4) | ((b11 & 255) >> 4)];
            int i12 = i10 + 3;
            bArr2[i10 + 2] = map[((b11 & 15) << 2) | ((b12 & 255) >> 6)];
            i10 += 4;
            bArr2[i12] = map[b12 & 63];
        }
        int length3 = bArr.length - length2;
        if (length3 == 1) {
            byte b13 = bArr[i9];
            bArr2[i10] = map[(b13 & 255) >> 2];
            bArr2[i10 + 1] = map[(b13 & 3) << 4];
            bArr2[i10 + 2] = 61;
            bArr2[i10 + 3] = 61;
        } else if (length3 == 2) {
            int i13 = i9 + 1;
            byte b14 = bArr[i9];
            byte b15 = bArr[i13];
            bArr2[i10] = map[(b14 & 255) >> 2];
            bArr2[i10 + 1] = map[((b14 & 3) << 4) | ((b15 & 255) >> 4)];
            bArr2[i10 + 2] = map[(b15 & 15) << 2];
            bArr2[i10 + 3] = 61;
        }
        sb.append(new String(bArr2, p229z8.a.f26609a));
        return sb.toString();
    }

    public static final Cursor G(w db, B b10, boolean z9) throws IOException {
        kotlin.jvm.internal.h.e(db, "db");
        db.a();
        db.b();
        Cursor c10 = db.i().a0().f0(b10);
        if (z9 && (c10 instanceof AbstractWindowedCursor)) {
            AbstractWindowedCursor abstractWindowedCursor = (AbstractWindowedCursor) c10;
            int count = abstractWindowedCursor.getCount();
            if ((abstractWindowedCursor.hasWindow() ? abstractWindowedCursor.getWindow().getNumRows() : count) < count) {
                kotlin.jvm.internal.h.e(c10, "c");
                try {
                    MatrixCursor matrixCursor = new MatrixCursor(c10.getColumnNames(), c10.getCount());
                    while (c10.moveToNext()) {
                        Object[] objArr = new Object[c10.getColumnCount()];
                        int columnCount = c10.getColumnCount();
                        for (int i9 = 0; i9 < columnCount; i9++) {
                            int type = c10.getType(i9);
                            if (type == 0) {
                                objArr[i9] = null;
                            } else if (type == 1) {
                                objArr[i9] = Long.valueOf(c10.getLong(i9));
                            } else if (type == 2) {
                                objArr[i9] = Double.valueOf(c10.getDouble(i9));
                            } else if (type == 3) {
                                objArr[i9] = c10.getString(i9);
                            } else {
                                if (type != 4) {
                                    throw new IllegalStateException();
                                }
                                objArr[i9] = c10.getBlob(i9);
                            }
                        }
                        matrixCursor.addRow(objArr);
                    }
                    c10.close();
                    return matrixCursor;
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        u0.h(c10, th);
                        throw th2;
                    }
                }
            }
        }
        return c10;
    }

    public static p116m2.w H(S8.y yVar, boolean z9, boolean z10) throws j0 {
        if (z9) {
            N(3, yVar, false);
        }
        yVar.v((int) yVar.n(), K4.e.f3790c);
        long jN = yVar.n();
        String[] strArr = new String[(int) jN];
        for (int i9 = 0; i9 < jN; i9++) {
            strArr[i9] = yVar.v((int) yVar.n(), K4.e.f3790c);
        }
        if (z10 && (yVar.x() & 1) == 0) {
            throw j0.a("framing bit expected to be set", null);
        }
        return new p116m2.w(strArr);
    }

    public static int I(double d9) {
        if (Double.isNaN(d9)) {
            throw new IllegalArgumentException("Cannot round NaN value.");
        }
        if (d9 > 2.147483647E9d) {
            return Integer.MAX_VALUE;
        }
        if (d9 < -2.147483648E9d) {
            return Integer.MIN_VALUE;
        }
        return (int) Math.round(d9);
    }

    public static int J(float f3) {
        if (Float.isNaN(f3)) {
            throw new IllegalArgumentException("Cannot round NaN value.");
        }
        return Math.round(f3);
    }

    public static String K(Throwable th) {
        kotlin.jvm.internal.h.e(th, "<this>");
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        th.printStackTrace(printWriter);
        printWriter.flush();
        String string = stringWriter.toString();
        kotlin.jvm.internal.h.d(string, "toString(...)");
        return string;
    }

    public static final List L(ArrayList arrayList) {
        int size = arrayList.size();
        if (size != 0) {
            return size != 1 ? DesugarCollections.unmodifiableList(new ArrayList(arrayList)) : Collections.singletonList(p048e8.i.j0(arrayList));
        }
        return q.f17244a;
    }

    public static final Map M(Map map) {
        int size = map.size();
        if (size == 0) {
            return r.f17245a;
        }
        if (size != 1) {
            return DesugarCollections.unmodifiableMap(new LinkedHashMap(map));
        }
        Map.Entry entry = (Map.Entry) p048e8.i.i0(map.entrySet());
        return Collections.singletonMap(entry.getKey(), entry.getValue());
    }

    public static boolean N(int i9, S8.y yVar, boolean z9) throws j0 {
        if (yVar.e() < 7) {
            if (z9) {
                return false;
            }
            throw j0.a("too short header: " + yVar.e(), null);
        }
        if (yVar.x() != i9) {
            if (z9) {
                return false;
            }
            throw j0.a("expected header type " + Integer.toHexString(i9), null);
        }
        if (yVar.x() == 118 && yVar.x() == 111 && yVar.x() == 114 && yVar.x() == 98 && yVar.x() == 105 && yVar.x() == 115) {
            return true;
        }
        if (z9) {
            return false;
        }
        throw j0.a("expected characters 'vorbis'", null);
    }

    public static p015b4.q O(List list) {
        if (list == null || list.isEmpty()) {
            return s(null);
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            if (((p015b4.h) it.next()) == null) {
                throw new NullPointerException("null tasks are not accepted");
            }
        }
        p015b4.q qVar = new p015b4.q();
        k kVar = new k(list.size(), qVar);
        Iterator it2 = list.iterator();
        while (it2.hasNext()) {
            p015b4.h hVar = (p015b4.h) it2.next();
            p pVar = p015b4.j.f11467b;
            hVar.d(pVar, kVar);
            hVar.c(pVar, kVar);
            hVar.a(pVar, kVar);
        }
        return qVar;
    }

    public static p015b4.q P(p015b4.h... hVarArr) {
        if (hVarArr.length == 0) {
            return s(Collections.EMPTY_LIST);
        }
        List listAsList = Arrays.asList(hVarArr);
        return (listAsList == null || listAsList.isEmpty()) ? s(Collections.EMPTY_LIST) : O(listAsList).e(p015b4.j.f11466a, new C0489h(3, listAsList));
    }

    public static Object Q(p015b4.h hVar) throws ExecutionException {
        if (hVar.j()) {
            return hVar.g();
        }
        if (((p015b4.q) hVar).f11492d) {
            throw new CancellationException("Task is already canceled");
        }
        throw new ExecutionException(hVar.f());
    }

    public static String R(Object... objArr) {
        int length;
        int length2;
        int iIndexOf;
        String strH;
        int i9 = 0;
        int i10 = 0;
        while (true) {
            length = objArr.length;
            if (i10 >= length) {
                break;
            }
            Object obj = objArr[i10];
            if (obj == null) {
                strH = "null";
            } else {
                try {
                    strH = obj.toString();
                } catch (Exception e9) {
                    String str = obj.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(obj));
                    Logger.getLogger("com.google.common.base.Strings").logp(Level.WARNING, "com.google.common.base.Strings", "lenientToString", "Exception during lenientFormat for ".concat(str), (Throwable) e9);
                    strH = p165r6.a.h("<", str, " threw ", e9.getClass().getName(), ">");
                }
            }
            objArr[i10] = strH;
            i10++;
        }
        StringBuilder sb = new StringBuilder((length * 16) + 29);
        int i11 = 0;
        while (true) {
            length2 = objArr.length;
            if (i9 >= length2 || (iIndexOf = "expected a non-null reference".indexOf("%s", i11)) == -1) {
                break;
            }
            sb.append((CharSequence) "expected a non-null reference", i11, iIndexOf);
            sb.append(objArr[i9]);
            i9++;
            i11 = iIndexOf + 2;
        }
        sb.append((CharSequence) "expected a non-null reference", i11, 29);
        if (i9 < length2) {
            sb.append(" [");
            sb.append(objArr[i9]);
            for (int i12 = i9 + 1; i12 < objArr.length; i12++) {
                sb.append(", ");
                sb.append(objArr[i12]);
            }
            sb.append(']');
        }
        return sb.toString();
    }

    public static InterfaceC0776n S(C0726d c0726d, s sVar, ArrayList arrayList, boolean z9) {
        InterfaceC0776n interfaceC0776nB;
        u0.I("reduce", 1, arrayList);
        u0.J("reduce", 2, arrayList);
        InterfaceC0776n interfaceC0776nC = ((C0805t) sVar.f15704c).c(sVar, (InterfaceC0776n) arrayList.get(0));
        if (!(interfaceC0776nC instanceof AbstractC0746h)) {
            throw new IllegalArgumentException("Callback should be a method");
        }
        if (arrayList.size() == 2) {
            interfaceC0776nB = ((C0805t) sVar.f15704c).c(sVar, (InterfaceC0776n) arrayList.get(1));
            if (interfaceC0776nB instanceof C0736f) {
                throw new IllegalArgumentException("Failed to parse initial value");
            }
        } else {
            if (c0726d.t() == 0) {
                throw new IllegalStateException("Empty array with no initial value error");
            }
            interfaceC0776nB = null;
        }
        AbstractC0746h abstractC0746h = (AbstractC0746h) interfaceC0776nC;
        int iT = c0726d.t();
        int i9 = z9 ? 0 : iT - 1;
        int i10 = z9 ? iT - 1 : 0;
        int i11 = true == z9 ? 1 : -1;
        if (interfaceC0776nB == null) {
            interfaceC0776nB = c0726d.u(i9);
            i9 += i11;
        }
        while ((i10 - i9) * i11 >= 0) {
            if (c0726d.w(i9)) {
                interfaceC0776nB = abstractC0746h.b(sVar, Arrays.asList(interfaceC0776nB, c0726d.u(i9), new C0741g(Double.valueOf(i9)), c0726d));
                if (interfaceC0776nB instanceof C0736f) {
                    throw new IllegalStateException("Reduce operation failed");
                }
                i9 += i11;
            } else {
                i9 += i11;
            }
        }
        return interfaceC0776nB;
    }

    public static C0726d T(C0726d c0726d, s sVar, C0771m c0771m, Boolean bool, Boolean bool2) {
        C0726d c0726d2 = new C0726d();
        Iterator itS = c0726d.s();
        while (itS.hasNext()) {
            int iIntValue = ((Integer) itS.next()).intValue();
            if (c0726d.w(iIntValue)) {
                InterfaceC0776n interfaceC0776nB = c0771m.b(sVar, Arrays.asList(c0726d.u(iIntValue), new C0741g(Double.valueOf(iIntValue)), c0726d));
                if (interfaceC0776nB.i().equals(bool)) {
                    break;
                }
                if (bool2 == null || interfaceC0776nB.i().equals(bool2)) {
                    c0726d2.v(iIntValue, interfaceC0776nB);
                }
            }
        }
        return c0726d2;
    }

    public static void a(Throwable th, Throwable exception) throws IllegalAccessException, InvocationTargetException {
        kotlin.jvm.internal.h.e(th, "<this>");
        kotlin.jvm.internal.h.e(exception, "exception");
        if (th != exception) {
            Integer num = p122m8.a.f21405a;
            if (num == null || num.intValue() >= 19) {
                th.addSuppressed(exception);
                return;
            }
            Method method = p112l8.a.f21155a;
            if (method != null) {
                method.invoke(th, exception);
            }
        }
    }

    public static Object b(p015b4.h hVar) throws InterruptedException {
        z.g("Must not be called on the main application thread");
        Looper looperMyLooper = Looper.myLooper();
        if (looperMyLooper != null && Objects.equals(looperMyLooper.getThread().getName(), "GoogleApiHandler")) {
            throw new IllegalStateException("Must not be called on GoogleApiHandler thread.");
        }
        z.i(hVar, "Task must not be null");
        if (hVar.i()) {
            return Q(hVar);
        }
        X5.c cVar = new X5.c(1);
        Executor executor = p015b4.j.f11467b;
        hVar.d(executor, cVar);
        hVar.c(executor, cVar);
        hVar.a(executor, cVar);
        cVar.f8978b.await();
        return Q(hVar);
    }

    public static Object c(p015b4.h hVar, long j9, TimeUnit timeUnit) throws TimeoutException {
        z.g("Must not be called on the main application thread");
        Looper looperMyLooper = Looper.myLooper();
        if (looperMyLooper != null && Objects.equals(looperMyLooper.getThread().getName(), "GoogleApiHandler")) {
            throw new IllegalStateException("Must not be called on GoogleApiHandler thread.");
        }
        z.i(hVar, "Task must not be null");
        z.i(timeUnit, "TimeUnit must not be null");
        if (hVar.i()) {
            return Q(hVar);
        }
        X5.c cVar = new X5.c(1);
        Executor executor = p015b4.j.f11467b;
        hVar.d(executor, cVar);
        hVar.c(executor, cVar);
        hVar.a(executor, cVar);
        if (cVar.f8978b.await(j9, timeUnit)) {
            return Q(hVar);
        }
        throw new TimeoutException("Timed out waiting for Task");
    }

    public static p057f8.c d(p057f8.c cVar) {
        cVar.m();
        cVar.f18045c = true;
        return cVar.f18044b > 0 ? cVar : p057f8.c.f18042d;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Iterable, java.lang.Object, java.util.Collection] */
    public static U1.h e(EpisodeSource episodeSource, G url, String langCode) {
        kotlin.jvm.internal.h.e(episodeSource, "episodeSource");
        ?? r9 = episodeSource.f16335f;
        kotlin.jvm.internal.h.e(url, "url");
        kotlin.jvm.internal.h.e(langCode, "langCode");
        U1.h hVar = new U1.h();
        hVar.f7400c = Uri.parse(url.f26017a);
        String strValueOf = String.valueOf(episodeSource.f16330a);
        strValueOf.getClass();
        hVar.f7398a = strValueOf;
        int iOrdinal = url.f26018b.ordinal();
        if (iOrdinal == 0) {
            hVar.f7399b = "application/x-mpegURL";
        } else if (iOrdinal == 1) {
            hVar.f7399b = "application/mp4";
        } else if (iOrdinal != 2) {
            throw new C0058s();
        }
        if (!r9.isEmpty()) {
            ArrayList arrayList = new ArrayList(p048e8.k.Z(r9));
            for (H h6 : r9) {
                Uri uri = Uri.parse(h6.f26022c);
                C0125i c0125i = new C0125i(1);
                c0125i.f2017c = uri;
                c0125i.f2020f = h6.f26022c;
                c0125i.f2018d = "text/vtt";
                c0125i.f2019e = h6.f26023d;
                if (!p229z8.e.j0(langCode) && kotlin.jvm.internal.h.a(h6.f26024e, langCode)) {
                    c0125i.f2016b = 1;
                }
                arrayList.add(new Y(c0125i));
            }
            hVar.f7404g = F.r(arrayList);
        }
        return hVar;
    }

    public static p015b4.q f(Executor executor, Callable callable) {
        z.i(executor, "Executor must not be null");
        p015b4.q qVar = new p015b4.q();
        executor.execute(new n(qVar, callable, 2, false));
        return qVar;
    }

    public static void j(D8.e eVar) {
        eVar.j(null, false);
    }

    public static void k(InterfaceC0952m interfaceC0952m) {
        if (interfaceC0952m != null) {
            try {
                interfaceC0952m.close();
            } catch (IOException unused) {
            }
        }
    }

    public static void l(String str, String str2, Object obj) {
        String strX = x(str);
        if (Log.isLoggable(strX, 3)) {
            Log.d(strX, String.format(str2, obj));
        }
    }

    public static final void m(R0.a connection) {
        kotlin.jvm.internal.h.e(connection, "connection");
        p057f8.c cVar = new p057f8.c(10);
        R0.c cVarD0 = connection.d0("SELECT name FROM sqlite_master WHERE type = 'trigger'");
        while (cVarD0.W()) {
            try {
                cVar.add(cVarD0.m(0));
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    I1.h(cVarD0, th);
                    throw th2;
                }
            }
        }
        I1.h(cVarD0, null);
        ListIterator listIterator = d(cVar).listIterator(0);
        while (true) {
            p057f8.a aVar = (p057f8.a) listIterator;
            if (!aVar.hasNext()) {
                return;
            }
            String str = (String) aVar.next();
            if (m.a0(str, "room_fts_content_sync_", false)) {
                I1.v(connection, "DROP TRIGGER IF EXISTS ".concat(str));
            }
        }
    }

    public static void n(String str, String str2, Exception exc) {
        String strX = x(str);
        if (Log.isLoggable(strX, 6)) {
            Log.e(strX, str2, exc);
        }
    }

    public static final Object o(InterfaceC0180m interfaceC0180m, String str, p093j8.c cVar) {
        Object objC = interfaceC0180m.c(str, new H0.H(0), cVar);
        return objC == p084i8.a.f19475a ? objC : p039d8.l.f16813a;
    }

    public static final p200w0.F p(View view) {
        kotlin.jvm.internal.h.e(view, "view");
        p221y8.e eVar = new p221y8.e(new p221y8.f(new p221y8.h(p221y8.k.Y(view, C1368c.f24988k), C1368c.f24989l, 2), false, new H0.H(8)));
        p200w0.F f3 = (p200w0.F) (!eVar.hasNext() ? null : eVar.next());
        if (f3 != null) {
            return f3;
        }
        throw new IllegalStateException("View " + view + " does not have a NavController set");
    }

    public static void q(Object obj) {
        LongSparseArray longSparseArray;
        if (!f17852f) {
            try {
                f17851e = Class.forName("android.content.res.ThemedResourceCache");
            } catch (ClassNotFoundException e9) {
                Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", e9);
            }
            f17852f = true;
        }
        Class cls = f17851e;
        if (cls == null) {
            return;
        }
        if (!f17854h) {
            try {
                Field declaredField = cls.getDeclaredField("mUnthemedEntries");
                f17853g = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e10) {
                Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", e10);
            }
            f17854h = true;
        }
        Field field = f17853g;
        if (field == null) {
            return;
        }
        try {
            longSparseArray = (LongSparseArray) field.get(obj);
        } catch (IllegalAccessException e11) {
            Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", e11);
            longSparseArray = null;
        }
        if (longSparseArray != null) {
            longSparseArray.clear();
        }
    }

    public static p015b4.q r(Exception exc) {
        p015b4.q qVar = new p015b4.q();
        qVar.n(exc);
        return qVar;
    }

    public static p015b4.q s(Object obj) {
        p015b4.q qVar = new p015b4.q();
        qVar.o(obj);
        return qVar;
    }

    public static String w(G streamUrl) {
        kotlin.jvm.internal.h.e(streamUrl, "streamUrl");
        int iOrdinal = streamUrl.f26018b.ordinal();
        if (iOrdinal == 0) {
            return "application/x-mpegURL";
        }
        if (iOrdinal == 1) {
            return "application/mp4";
        }
        if (iOrdinal != 2) {
            throw new C0058s();
        }
        int iD = y.D(Uri.parse(streamUrl.f26017a));
        if (iD == 0) {
            return "application/dash+xml";
        }
        if (iD == 1) {
            return "application/vnd.ms-sstr+xml";
        }
        if (iD != 2) {
            return null;
        }
        return "application/x-mpegURL";
    }

    public static String x(String str) {
        if (Build.VERSION.SDK_INT >= 26) {
            return "TRuntime.".concat(str);
        }
        String strConcat = "TRuntime.".concat(str);
        return strConcat.length() > 23 ? strConcat.substring(0, 23) : strConcat;
    }

    public static boolean y(byte b10) {
        return b10 > -65;
    }

    public static List z(Object obj) {
        List listSingletonList = Collections.singletonList(obj);
        kotlin.jvm.internal.h.d(listSingletonList, "singletonList(...)");
        return listSingletonList;
    }

    public void A(int i9) {
        synchronized (this) {
        }
    }

    public abstract void E(O4.m mVar, O4.m mVar2);

    public abstract void F(O4.m mVar, Thread thread);

    public abstract boolean g(O4.n nVar, O4.d dVar, O4.d dVar2);

    public abstract boolean h(O4.n nVar, Object obj, Object obj2);

    public abstract boolean i(O4.n nVar, O4.m mVar, O4.m mVar2);

    public abstract O4.d t(O4.n nVar);

    public abstract O4.m u(O4.n nVar);

    public abstract void v(C4.w wVar, float f3, float f9);
}
