package p054f5;

import B3.z;
import G3.e;
import android.content.Context;
import android.text.TextUtils;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f17881a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f17882b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f17883c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f17884d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f17885e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f17886f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f17887g;

    public i(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        int i9 = e.f2280a;
        z.j("ApplicationId must be set.", true ^ (str == null || str.trim().isEmpty()));
        this.f17882b = str;
        this.f17881a = str2;
        this.f17883c = str3;
        this.f17884d = str4;
        this.f17885e = str5;
        this.f17886f = str6;
        this.f17887g = str7;
    }

    public static i a(Context context) {
        A5.e eVar = new A5.e(context);
        String strM = eVar.m("google_app_id");
        if (TextUtils.isEmpty(strM)) {
            return null;
        }
        return new i(strM, eVar.m("google_api_key"), eVar.m("firebase_database_url"), eVar.m("ga_trackingId"), eVar.m("gcm_defaultSenderId"), eVar.m("google_storage_bucket"), eVar.m("project_id"));
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return z.k(this.f17882b, iVar.f17882b) && z.k(this.f17881a, iVar.f17881a) && z.k(this.f17883c, iVar.f17883c) && z.k(this.f17884d, iVar.f17884d) && z.k(this.f17885e, iVar.f17885e) && z.k(this.f17886f, iVar.f17886f) && z.k(this.f17887g, iVar.f17887g);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f17882b, this.f17881a, this.f17883c, this.f17884d, this.f17885e, this.f17886f, this.f17887g});
    }

    public final String toString() {
        A5.e eVar = new A5.e(this);
        eVar.c(this.f17882b, "applicationId");
        eVar.c(this.f17881a, "apiKey");
        eVar.c(this.f17883c, "databaseUrl");
        eVar.c(this.f17885e, "gcmSenderId");
        eVar.c(this.f17886f, "storageBucket");
        eVar.c(this.f17887g, "projectId");
        return eVar.toString();
    }
}
