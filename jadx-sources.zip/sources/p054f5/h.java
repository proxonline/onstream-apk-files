package p054f5;

import B3.z;

/* JADX INFO: loaded from: classes.dex */
public abstract class h extends Exception {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(String str) {
        super(str);
        z.f(str, "Detail message must not be empty");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(String str, Throwable th) {
        super(str, th);
        z.f(str, "Detail message must not be empty");
    }
}
