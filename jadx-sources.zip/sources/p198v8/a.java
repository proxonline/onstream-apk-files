package p198v8;

import j$.util.concurrent.ThreadLocalRandom;
import java.util.Random;
import kotlin.jvm.internal.h;

/* JADX INFO: loaded from: classes.dex */
public final class a extends p188u8.a {
    @Override // p188u8.d
    public final long d(long j) {
        return ThreadLocalRandom.current().nextLong(0L, j);
    }

    @Override // p188u8.a
    public final Random e() {
        ThreadLocalRandom threadLocalRandomCurrent = ThreadLocalRandom.current();
        h.d(threadLocalRandomCurrent, "current(...)");
        return threadLocalRandomCurrent;
    }
}
