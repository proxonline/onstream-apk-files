package W2;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7838a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f7839b;

    public g(int i9, int i10) {
        this.f7838a = i9;
        this.f7839b = i10;
    }
}
