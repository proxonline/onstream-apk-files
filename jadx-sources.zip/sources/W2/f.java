package W2;

import android.util.SparseArray;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7829a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f7830b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f7831c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f7832d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f7833e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f7834f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f7835g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f7836h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f7837i;
    public final SparseArray j;

    public f(int i9, boolean z9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, SparseArray sparseArray) {
        this.f7829a = i9;
        this.f7830b = z9;
        this.f7831c = i10;
        this.f7832d = i11;
        this.f7833e = i12;
        this.f7834f = i13;
        this.f7835g = i14;
        this.f7836h = i15;
        this.f7837i = i16;
        this.j = sparseArray;
    }
}
