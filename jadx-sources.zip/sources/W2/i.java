package W2;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import p071h3.y;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final byte[] f7849h = {0, 7, 8, 15};

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final byte[] f7850i = {0, 119, -120, -1};
    public static final byte[] j = {0, 17, 34, 51, 68, 85, 102, 119, -120, -103, -86, -69, -52, -35, -18, -1};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Paint f7851a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Paint f7852b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Canvas f7853c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c f7854d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final b f7855e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final h f7856f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Bitmap f7857g;

    public i(int i9, int i10) {
        Paint paint = new Paint();
        this.f7851a = paint;
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        paint.setPathEffect(null);
        Paint paint2 = new Paint();
        this.f7852b = paint2;
        paint2.setStyle(Paint.Style.FILL);
        paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OVER));
        paint2.setPathEffect(null);
        this.f7853c = new Canvas();
        this.f7854d = new c(719, 575, 0, 719, 0, 575);
        this.f7855e = new b(0, new int[]{0, -1, -16777216, -8421505}, b(), c());
        this.f7856f = new h(i9, i10);
    }

    public static byte[] a(int i9, int i10, V2.f fVar) {
        byte[] bArr = new byte[i9];
        for (int i11 = 0; i11 < i9; i11++) {
            bArr[i11] = (byte) fVar.i(i10);
        }
        return bArr;
    }

    public static int[] b() {
        int[] iArr = new int[16];
        iArr[0] = 0;
        for (int i9 = 1; i9 < 16; i9++) {
            if (i9 < 8) {
                iArr[i9] = d(255, (i9 & 1) != 0 ? 255 : 0, (i9 & 2) != 0 ? 255 : 0, (i9 & 4) != 0 ? 255 : 0);
            } else {
                iArr[i9] = d(255, (i9 & 1) != 0 ? 127 : 0, (i9 & 2) != 0 ? 127 : 0, (i9 & 4) == 0 ? 0 : 127);
            }
        }
        return iArr;
    }

    public static int[] c() {
        int[] iArr = new int[256];
        iArr[0] = 0;
        for (int i9 = 0; i9 < 256; i9++) {
            if (i9 < 8) {
                iArr[i9] = d(63, (i9 & 1) != 0 ? 255 : 0, (i9 & 2) != 0 ? 255 : 0, (i9 & 4) == 0 ? 0 : 255);
            } else {
                int i10 = i9 & 136;
                if (i10 == 0) {
                    iArr[i9] = d(255, ((i9 & 1) != 0 ? 85 : 0) + ((i9 & 16) != 0 ? 170 : 0), ((i9 & 2) != 0 ? 85 : 0) + ((i9 & 32) != 0 ? 170 : 0), ((i9 & 4) == 0 ? 0 : 85) + ((i9 & 64) == 0 ? 0 : 170));
                } else if (i10 == 8) {
                    iArr[i9] = d(127, ((i9 & 1) != 0 ? 85 : 0) + ((i9 & 16) != 0 ? 170 : 0), ((i9 & 2) != 0 ? 85 : 0) + ((i9 & 32) != 0 ? 170 : 0), ((i9 & 4) == 0 ? 0 : 85) + ((i9 & 64) == 0 ? 0 : 170));
                } else if (i10 == 128) {
                    iArr[i9] = d(255, ((i9 & 1) != 0 ? 43 : 0) + 127 + ((i9 & 16) != 0 ? 85 : 0), ((i9 & 2) != 0 ? 43 : 0) + 127 + ((i9 & 32) != 0 ? 85 : 0), ((i9 & 4) == 0 ? 0 : 43) + 127 + ((i9 & 64) == 0 ? 0 : 85));
                } else if (i10 == 136) {
                    iArr[i9] = d(255, ((i9 & 1) != 0 ? 43 : 0) + ((i9 & 16) != 0 ? 85 : 0), ((i9 & 2) != 0 ? 43 : 0) + ((i9 & 32) != 0 ? 85 : 0), ((i9 & 4) == 0 ? 0 : 43) + ((i9 & 64) == 0 ? 0 : 85));
                }
            }
        }
        return iArr;
    }

    public static int d(int i9, int i10, int i11, int i12) {
        return (i9 << 24) | (i10 << 16) | (i11 << 8) | i12;
    }

    /* JADX WARN: Code duplicated, block: B:115:0x01f5  */
    /* JADX WARN: Code duplicated, block: B:119:0x0203 A[LOOP:3: B:87:0x0156->B:119:0x0203, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:133:0x01ff A[SYNTHETIC] */
    public static void e(byte[] bArr, int[] iArr, int i9, int i10, int i11, Paint paint, Canvas canvas) {
        byte[] bArr2;
        char c10;
        char c11;
        int i12;
        int i13;
        boolean z9;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        boolean z10;
        int i19;
        V2.f fVar = new V2.f(bArr.length, bArr);
        int i20 = i10;
        int i21 = i11;
        byte[] bArrA = null;
        byte[] bArrA2 = null;
        byte[] bArrA3 = null;
        while (fVar.b() != 0) {
            int i22 = 8;
            int i23 = fVar.i(8);
            if (i23 != 240) {
                int i24 = 3;
                int i25 = 2;
                int i26 = 4;
                switch (i23) {
                    case 16:
                        if (i9 == 3) {
                            bArr2 = bArrA == null ? f7850i : bArrA;
                        } else if (i9 == 2) {
                            bArr2 = bArrA3 == null ? f7849h : bArrA3;
                        } else {
                            bArr2 = null;
                        }
                        boolean z11 = false;
                        while (true) {
                            int i27 = fVar.i(2);
                            if (i27 != 0) {
                                i12 = i27;
                                i13 = 1;
                            } else {
                                if (fVar.h()) {
                                    int i28 = fVar.i(3) + 3;
                                    i12 = fVar.i(2);
                                    i13 = i28;
                                } else {
                                    if (fVar.h()) {
                                        i13 = 1;
                                        c10 = '\b';
                                        c11 = 4;
                                    } else {
                                        int i29 = fVar.i(2);
                                        if (i29 == 0) {
                                            c10 = '\b';
                                            c11 = 4;
                                            z11 = true;
                                        } else if (i29 == 1) {
                                            c10 = '\b';
                                            c11 = 4;
                                            i13 = 2;
                                        } else if (i29 == 2) {
                                            c10 = '\b';
                                            c11 = 4;
                                            i13 = fVar.i(4) + 12;
                                            i12 = fVar.i(2);
                                            z11 = z11;
                                        } else if (i29 != 3) {
                                            z11 = z11;
                                            c10 = '\b';
                                            c11 = 4;
                                        } else {
                                            c10 = '\b';
                                            int i30 = fVar.i(8) + 29;
                                            i12 = fVar.i(2);
                                            z11 = z11;
                                            i13 = i30;
                                            c11 = 4;
                                        }
                                        i12 = 0;
                                        i13 = 0;
                                    }
                                    i12 = 0;
                                }
                                if (i13 == 0 && paint != null) {
                                    if (bArr2 != 0) {
                                        i12 = bArr2[i12];
                                    }
                                    paint.setColor(iArr[i12]);
                                    canvas.drawRect(i20, i21, i20 + i13, i21 + 1, paint);
                                }
                                i20 += i13;
                                if (z11) {
                                    fVar.c();
                                } else {
                                    paint = paint;
                                    z11 = z11;
                                }
                            }
                            c10 = '\b';
                            c11 = 4;
                            if (i13 == 0) {
                            }
                            i20 += i13;
                            if (z11) {
                                fVar.c();
                            } else {
                                paint = paint;
                                z11 = z11;
                            }
                            break;
                        }
                        break;
                    case 17:
                        byte[] bArr3 = i9 == 3 ? bArrA2 == null ? j : bArrA2 : null;
                        boolean z12 = false;
                        while (true) {
                            int i31 = fVar.i(i26);
                            if (i31 != 0) {
                                z9 = z12;
                                i16 = i31;
                                i14 = 1;
                            } else if (fVar.h()) {
                                if (fVar.h()) {
                                    int i32 = fVar.i(i25);
                                    if (i32 == 0) {
                                        z9 = z12;
                                        i14 = 1;
                                    } else if (i32 != 1) {
                                        if (i32 == i25) {
                                            i14 = fVar.i(i26) + 9;
                                            i15 = fVar.i(i26);
                                        } else if (i32 != i24) {
                                            z9 = z12;
                                            i14 = 0;
                                        } else {
                                            i14 = fVar.i(i22) + 25;
                                            i15 = fVar.i(i26);
                                        }
                                        i16 = i15;
                                    } else {
                                        z9 = z12;
                                        i14 = i25;
                                    }
                                    i16 = 0;
                                } else {
                                    i14 = fVar.i(i25) + 4;
                                    i16 = fVar.i(i26);
                                }
                                z9 = z12;
                            } else {
                                int i33 = fVar.i(i24);
                                if (i33 != 0) {
                                    i14 = i33 + 2;
                                    z9 = z12;
                                } else {
                                    z9 = true;
                                    i14 = 0;
                                }
                                i16 = 0;
                            }
                            if (i14 == 0 || paint == 0) {
                                i17 = i24;
                                i18 = i25;
                            } else {
                                if (bArr3 != 0) {
                                    i16 = bArr3[i16];
                                }
                                paint.setColor(iArr[i16]);
                                i17 = i24;
                                i18 = 2;
                                canvas.drawRect(i20, i21, i20 + i14, i21 + 1, paint);
                            }
                            i20 += i14;
                            if (z9) {
                                fVar.c();
                            } else {
                                z12 = z9;
                                i24 = i17;
                                i25 = i18;
                                i26 = 4;
                                i22 = 8;
                            }
                            break;
                        }
                        break;
                    case 18:
                        boolean z13 = false;
                        while (true) {
                            int i34 = fVar.i(8);
                            if (i34 != 0) {
                                z10 = z13;
                                i19 = 1;
                            } else if (fVar.h()) {
                                z10 = z13;
                                i19 = fVar.i(7);
                                i34 = fVar.i(8);
                            } else {
                                int i35 = fVar.i(7);
                                if (i35 != 0) {
                                    z10 = z13;
                                    i19 = i35;
                                    i34 = 0;
                                } else {
                                    z10 = true;
                                    i34 = 0;
                                    i19 = 0;
                                }
                            }
                            if (i19 != 0 && paint != 0) {
                                paint.setColor(iArr[i34]);
                                canvas.drawRect(i20, i21, i20 + i19, i21 + 1, paint);
                            }
                            i20 += i19;
                            if (!z10) {
                                z13 = z10;
                            }
                            break;
                        }
                        break;
                    default:
                        switch (i23) {
                            case 32:
                                bArrA3 = a(4, 4, fVar);
                                break;
                            case 33:
                                bArrA = a(4, 8, fVar);
                                break;
                            case 34:
                                bArrA2 = a(16, 8, fVar);
                                break;
                        }
                        break;
                }
            } else {
                i21 += 2;
                i20 = i10;
            }
        }
    }

    public static b f(V2.f fVar, int i9) {
        int[] iArr;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15 = 8;
        int i16 = fVar.i(8);
        fVar.r(8);
        int i17 = 2;
        int i18 = i9 - 2;
        int i19 = 0;
        int[] iArr2 = {0, -1, -16777216, -8421505};
        int[] iArrB = b();
        int[] iArrC = c();
        while (i18 > 0) {
            int i20 = fVar.i(i15);
            int i21 = fVar.i(i15);
            if ((i21 & 128) != 0) {
                iArr = iArr2;
            } else {
                iArr = (i21 & 64) != 0 ? iArrB : iArrC;
            }
            if ((i21 & 1) != 0) {
                i13 = fVar.i(i15);
                i14 = fVar.i(i15);
                i10 = fVar.i(i15);
                i12 = fVar.i(i15);
                i11 = i18 - 6;
            } else {
                int i22 = fVar.i(6) << i17;
                int i23 = fVar.i(4) << 4;
                i10 = fVar.i(4) << 4;
                i11 = i18 - 4;
                i12 = fVar.i(i17) << 6;
                i13 = i22;
                i14 = i23;
            }
            if (i13 == 0) {
                i14 = i19;
                i10 = i14;
                i12 = 255;
            }
            double d9 = i13;
            double d10 = i14 - 128;
            double d11 = i10 - 128;
            iArr[i20] = d((byte) (255 - (i12 & 255)), y.i((int) ((1.402d * d10) + d9), 0, 255), y.i((int) ((d9 - (0.34414d * d11)) - (d10 * 0.71414d)), 0, 255), y.i((int) ((d11 * 1.772d) + d9), 0, 255));
            i18 = i11;
            i19 = 0;
            i16 = i16;
            iArrC = iArrC;
            i15 = 8;
            i17 = 2;
        }
        return new b(i16, iArr2, iArrB, iArrC);
    }

    public static d g(V2.f fVar) {
        byte[] bArr;
        int i9 = fVar.i(16);
        fVar.r(4);
        int i10 = fVar.i(2);
        boolean zH = fVar.h();
        fVar.r(1);
        byte[] bArr2 = y.f18905f;
        if (i10 != 1) {
            if (i10 == 0) {
                int i11 = fVar.i(16);
                int i12 = fVar.i(16);
                if (i11 > 0) {
                    bArr2 = new byte[i11];
                    fVar.k(i11, bArr2);
                }
                if (i12 > 0) {
                    bArr = new byte[i12];
                    fVar.k(i12, bArr);
                }
            }
            return new d(i9, zH, bArr2, bArr);
        }
        fVar.r(fVar.i(8) * 16);
        bArr = bArr2;
        return new d(i9, zH, bArr2, bArr);
    }
}
