package W2;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7817a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f7818b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f7819c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f7820d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f7821e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f7822f;

    public c(int i9, int i10, int i11, int i12, int i13, int i14) {
        this.f7817a = i9;
        this.f7818b = i10;
        this.f7819c = i11;
        this.f7820d = i12;
        this.f7821e = i13;
        this.f7822f = i14;
    }
}
