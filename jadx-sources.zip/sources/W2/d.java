package W2;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7823a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f7824b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final byte[] f7825c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final byte[] f7826d;

    public d(int i9, boolean z9, byte[] bArr, byte[] bArr2) {
        this.f7823a = i9;
        this.f7824b = z9;
        this.f7825c = bArr;
        this.f7826d = bArr2;
    }
}
