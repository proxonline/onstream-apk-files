package W2;

import S8.y;
import android.util.SparseArray;

/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7840a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f7841b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final SparseArray f7842c = new SparseArray();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final SparseArray f7843d = new SparseArray();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final SparseArray f7844e = new SparseArray();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final SparseArray f7845f = new SparseArray();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final SparseArray f7846g = new SparseArray();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public c f7847h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public y f7848i;

    public h(int i9, int i10) {
        this.f7840a = i9;
        this.f7841b = i10;
    }
}
