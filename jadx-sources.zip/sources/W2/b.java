package W2;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7813a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int[] f7814b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int[] f7815c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f7816d;

    public b(int i9, int[] iArr, int[] iArr2, int[] iArr3) {
        this.f7813a = i9;
        this.f7814b = iArr;
        this.f7815c = iArr2;
        this.f7816d = iArr3;
    }
}
