package W2;

import S8.y;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class a extends U2.e {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ int f7811m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Object f7812n;

    public a() {
        this.f7811m = 1;
        this.f7812n = new y(5, false);
    }

    public a(List list) {
        this.f7811m = 0;
        byte[] bArr = (byte[]) list.get(0);
        int length = bArr.length;
        this.f7812n = new i(((bArr[0] & 255) << 8) | (bArr[1] & 255), (bArr[3] & 255) | ((bArr[2] & 255) << 8));
    }

    /*  JADX ERROR: JadxRuntimeException in pass: ModVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r3v1 A5.g, still in use, count: 2, list:
          (r3v1 A5.g) from 0x0327: PHI (r3v2 A5.g) = (r3v1 A5.g), (r3v5 A5.g) binds: [B:118:0x031d, B:161:0x045b] A[DONT_GENERATE, DONT_INLINE]
          (r3v1 A5.g) from 0x02e6: MOVE (r48v8 A5.g) = (r3v1 A5.g)
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:164)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:129)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:93)
        	at jadx.core.utils.InsnRemover.addAndUnbind(InsnRemover.java:59)
        	at jadx.core.dex.visitors.ModVisitor.removeStep(ModVisitor.java:463)
        	at jadx.core.dex.visitors.ModVisitor.visit(ModVisitor.java:97)
        */
    @Override // U2.e
    public final U2.f f(int r47, boolean r48, byte[] r49) {
        /*
            Method dump skipped, instruction units count: 1234
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: W2.a.f(int, boolean, byte[]):U2.f");
    }
}
