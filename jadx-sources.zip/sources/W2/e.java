package W2;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7827a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f7828b;

    public e(int i9, int i10) {
        this.f7827a = i9;
        this.f7828b = i10;
    }
}
