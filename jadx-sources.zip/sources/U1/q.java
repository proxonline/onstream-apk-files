package U1;

import android.support.v4.media.session.z;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public abstract class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final z f7430a;

    static {
        HashMap map = new HashMap();
        HashMap map2 = new HashMap();
        map.put(q.class, e.f7391a);
        map2.remove(q.class);
        map.put(X1.a.class, a.f7378a);
        map2.remove(X1.a.class);
        map.put(X1.g.class, g.f7395a);
        map2.remove(X1.g.class);
        map.put(X1.e.class, d.f7388a);
        map2.remove(X1.e.class);
        map.put(X1.d.class, c.f7385a);
        map2.remove(X1.d.class);
        map.put(X1.b.class, b.f7383a);
        map2.remove(X1.b.class);
        map.put(X1.f.class, f.f7392a);
        map2.remove(X1.f.class);
        f7430a = new z(new HashMap(map), new HashMap(map2), I5.g.f3170a, 5);
    }
}
