package U1;

/* JADX INFO: loaded from: classes.dex */
public final class f implements F5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final f f7392a = new f();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final F5.c f7393b = new F5.c("currentCacheSizeBytes", B0.a.u(B0.a.t(I5.e.class, new I5.a(1))));

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final F5.c f7394c = new F5.c("maxCacheSizeBytes", B0.a.u(B0.a.t(I5.e.class, new I5.a(2))));

    @Override // F5.a
    public final void a(Object obj, Object obj2) {
        X1.f fVar = (X1.f) obj;
        F5.e eVar = (F5.e) obj2;
        eVar.a(f7393b, fVar.f8024a);
        eVar.a(f7394c, fVar.f8025b);
    }
}
