package U1;

import X3.C0390l0;
import X3.C0396n0;
import X3.P0;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class r implements Executor {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f7431a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f7432b;

    public r() {
        this.f7431a = 2;
        P3.d dVar = new P3.d(Looper.getMainLooper());
        Looper.getMainLooper();
        this.f7432b = dVar;
    }

    public /* synthetic */ r(int i9, Object obj) {
        this.f7431a = i9;
        this.f7432b = obj;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        switch (this.f7431a) {
            case 0:
                ((Executor) this.f7432b).execute(new H3.b(runnable, 1));
                break;
            case 1:
                C0390l0 c0390l0 = ((C0396n0) ((P0) this.f7432b).f923a).f8715g;
                C0396n0.g(c0390l0);
                c0390l0.A0(runnable);
                break;
            case 2:
                ((P3.d) this.f7432b).post(runnable);
                break;
            default:
                ((Handler) ((Y4.i) this.f7432b).f9378c).post(runnable);
                break;
        }
    }
}
