package U1;

import X3.A;
import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public final class u implements W1.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f7441a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p029c8.a f7442b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p029c8.a f7443c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final W1.b f7444d;

    public /* synthetic */ u(p029c8.a aVar, p029c8.a aVar2, W1.b bVar, int i9) {
        this.f7441a = i9;
        this.f7442b = aVar;
        this.f7443c = aVar2;
        this.f7444d = bVar;
    }

    @Override // p029c8.a
    public final Object get() {
        switch (this.f7441a) {
            case 0:
                return new t(new p033d2.b(0), new A(29), (Z1.c) ((Z1.b) this.f7442b).get(), (p003a2.j) ((p003a2.k) this.f7443c).get(), (p003a2.l) ((p003a2.m) this.f7444d).get());
            default:
                return new p003a2.d((Context) this.f7442b.get(), (p013b2.d) this.f7443c.get(), (p003a2.b) ((p) this.f7444d).get());
        }
    }
}
