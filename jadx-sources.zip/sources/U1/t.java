package U1;

import D.RunnableC0078a;
import android.content.Context;
import android.support.v4.media.session.z;
import j$.util.DesugarCollections;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static volatile l f7436e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p033d2.a f7437a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p033d2.a f7438b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Z1.c f7439c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p003a2.j f7440d;

    public t(p033d2.a aVar, p033d2.a aVar2, Z1.c cVar, p003a2.j jVar, p003a2.l lVar) {
        this.f7437a = aVar;
        this.f7438b = aVar2;
        this.f7439c = cVar;
        this.f7440d = jVar;
        lVar.f9903a.execute(new RunnableC0078a(10, lVar));
    }

    public static t a() {
        l lVar = f7436e;
        if (lVar != null) {
            return (t) lVar.f7425f.get();
        }
        throw new IllegalStateException("Not initialized!");
    }

    public static void b(Context context) {
        if (f7436e == null) {
            synchronized (t.class) {
                try {
                    if (f7436e == null) {
                        k kVar = new k();
                        context.getClass();
                        kVar.f7419a = context;
                        f7436e = kVar.a();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    public final s c(m mVar) {
        Set setSingleton;
        byte[] bytes;
        if (mVar != null) {
            ((S1.a) mVar).getClass();
            setSingleton = DesugarCollections.unmodifiableSet(S1.a.f6890d);
        } else {
            setSingleton = Collections.singleton(new R1.c("proto"));
        }
        z zVarA = j.a();
        mVar.getClass();
        zVarA.f10226b = "cct";
        S1.a aVar = (S1.a) mVar;
        String str = aVar.f6893a;
        String str2 = aVar.f6894b;
        if (str2 == null && str == null) {
            bytes = null;
        } else {
            if (str2 == null) {
                str2 = "";
            }
            bytes = ("1$" + str + "\\" + str2).getBytes(Charset.forName("UTF-8"));
        }
        zVarA.f10227c = bytes;
        return new s(setSingleton, zVarA.o(), this);
    }
}
