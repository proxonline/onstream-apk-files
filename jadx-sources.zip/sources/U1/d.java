package U1;

/* JADX INFO: loaded from: classes.dex */
public final class d implements F5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d f7388a = new d();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final F5.c f7389b = new F5.c("logSource", B0.a.u(B0.a.t(I5.e.class, new I5.a(1))));

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final F5.c f7390c = new F5.c("logEventDropped", B0.a.u(B0.a.t(I5.e.class, new I5.a(2))));

    @Override // F5.a
    public final void a(Object obj, Object obj2) {
        X1.e eVar = (X1.e) obj;
        F5.e eVar2 = (F5.e) obj2;
        eVar2.g(f7389b, eVar.f8022a);
        eVar2.g(f7390c, eVar.f8023b);
    }
}
