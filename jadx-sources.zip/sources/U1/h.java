package U1;

import L4.F;
import L4.S;
import android.net.Uri;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import p052f2.C0899b0;
import p052f2.P;
import p052f2.T;
import p052f2.U;
import p052f2.V;
import p052f2.W;
import p052f2.Z;

/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f7398a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f7399b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Comparable f7400c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f7401d = new P();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f7402e = new C1.b(6);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f7403f = Collections.EMPTY_LIST;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Serializable f7404g = S.f4015e;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Object f7405h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Object f7406i;
    public Object j;

    public h() {
        N2.t tVar = new N2.t();
        tVar.f4960a = -9223372036854775807L;
        tVar.f4961b = -9223372036854775807L;
        tVar.f4962c = -9223372036854775807L;
        tVar.f4963d = -3.4028235E38f;
        tVar.f4964e = -3.4028235E38f;
        this.f7406i = tVar;
        this.j = W.f17554c;
    }

    public void a(String str, String str2) {
        HashMap map = (HashMap) this.f7405h;
        if (map == null) {
            throw new IllegalStateException("Property \"autoMetadata\" has not been set");
        }
        map.put(str, str2);
    }

    public i b() {
        String strG = this.f7398a == null ? " transportName" : "";
        if (((n) this.f7402e) == null) {
            strG = strG.concat(" encodedPayload");
        }
        if (((Long) this.f7403f) == null) {
            strG = p165r6.a.g(strG, " eventMillis");
        }
        if (((Long) this.f7404g) == null) {
            strG = p165r6.a.g(strG, " uptimeMillis");
        }
        if (((HashMap) this.f7405h) == null) {
            strG = p165r6.a.g(strG, " autoMetadata");
        }
        if (strG.isEmpty()) {
            return new i(this.f7398a, (Integer) this.f7400c, (n) this.f7402e, ((Long) this.f7403f).longValue(), ((Long) this.f7404g).longValue(), (HashMap) this.f7405h, (Integer) this.f7401d, this.f7399b, (byte[]) this.f7406i, (byte[]) this.j);
        }
        throw new IllegalStateException("Missing required properties:".concat(strG));
    }

    public Z c() {
        V v9;
        C1.b bVar = (C1.b) this.f7402e;
        p071h3.a.m(((Uri) bVar.f548b) == null || ((UUID) bVar.f547a) != null);
        Uri uri = (Uri) this.f7400c;
        if (uri != null) {
            String str = this.f7399b;
            C1.b bVar2 = (C1.b) this.f7402e;
            v9 = new V(uri, str, ((UUID) bVar2.f547a) != null ? new T(bVar2) : null, (List) this.f7403f, (F) this.f7404g);
        } else {
            v9 = null;
        }
        String str2 = this.f7398a;
        if (str2 == null) {
            str2 = "";
        }
        String str3 = str2;
        P p8 = (P) this.f7401d;
        p8.getClass();
        p052f2.S s9 = new p052f2.S(p8);
        U uA = ((N2.t) this.f7406i).a();
        C0899b0 c0899b0 = (C0899b0) this.f7405h;
        if (c0899b0 == null) {
            c0899b0 = C0899b0.Z;
        }
        return new Z(str3, s9, v9, uA, c0899b0, (W) this.j);
    }
}
