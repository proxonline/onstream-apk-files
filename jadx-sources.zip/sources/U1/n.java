package U1;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final R1.c f7426a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f7427b;

    public n(R1.c cVar, byte[] bArr) {
        if (cVar == null) {
            throw new NullPointerException("encoding is null");
        }
        if (bArr == null) {
            throw new NullPointerException("bytes is null");
        }
        this.f7426a = cVar;
        this.f7427b = bArr;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n)) {
            return false;
        }
        n nVar = (n) obj;
        if (this.f7426a.equals(nVar.f7426a)) {
            return Arrays.equals(this.f7427b, nVar.f7427b);
        }
        return false;
    }

    public final int hashCode() {
        return ((this.f7426a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f7427b);
    }

    public final String toString() {
        return "EncodedPayload{encoding=" + this.f7426a + ", bytes=[...]}";
    }
}
