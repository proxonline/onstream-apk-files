package U1;

import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public final class k implements S0.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Context f7419a;

    public /* synthetic */ k(Context context) {
        this.f7419a = context;
    }

    public l a() {
        Context context = this.f7419a;
        if (context == null) {
            throw new IllegalStateException(Context.class.getCanonicalName() + " must be set");
        }
        l lVar = new l();
        lVar.f7420a = W1.a.a(o.f7428a);
        V1.e eVar = new V1.e(1, context);
        lVar.f7421b = eVar;
        lVar.f7422c = W1.a.a(new V1.g(eVar, new V1.e(0, eVar), 0));
        V1.e eVar2 = lVar.f7421b;
        lVar.f7423d = new p013b2.e(eVar2, 1);
        p029c8.a aVarA = W1.a.a(new V1.g(lVar.f7423d, W1.a.a(new p013b2.e(eVar2, 0)), 1));
        lVar.f7424e = aVarA;
        p pVar = new p(1);
        V1.e eVar3 = lVar.f7421b;
        u uVar = new u(eVar3, aVarA, pVar, 1);
        p029c8.a aVar = lVar.f7420a;
        p029c8.a aVar2 = lVar.f7422c;
        lVar.f7425f = W1.a.a(new u(new Z1.b(aVar, aVar2, uVar, aVarA, aVarA), new p003a2.k(eVar3, aVar2, aVarA, uVar, aVar, aVarA, aVarA), new p003a2.m(aVar, aVarA, uVar, aVarA), 0));
        return lVar;
    }

    @Override // S0.c
    public S0.d b(E1.b bVar) {
        Context context = this.f7419a;
        String str = (String) bVar.f1218a;
        S0.b callback = (S0.b) bVar.f1221d;
        kotlin.jvm.internal.h.e(callback, "callback");
        if (str == null || str.length() == 0) {
            throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.");
        }
        E1.b bVar2 = new E1.b(context, str, callback, true);
        return new T0.h((Context) bVar2.f1220c, (String) bVar2.f1218a, (S0.b) bVar2.f1221d, bVar2.f1219b);
    }
}
