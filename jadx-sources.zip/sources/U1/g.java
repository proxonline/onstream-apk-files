package U1;

/* JADX INFO: loaded from: classes.dex */
public final class g implements F5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final g f7395a = new g();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final F5.c f7396b = new F5.c("startMs", B0.a.u(B0.a.t(I5.e.class, new I5.a(1))));

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final F5.c f7397c = new F5.c("endMs", B0.a.u(B0.a.t(I5.e.class, new I5.a(2))));

    @Override // F5.a
    public final void a(Object obj, Object obj2) {
        X1.g gVar = (X1.g) obj;
        F5.e eVar = (F5.e) obj2;
        eVar.a(f7396b, gVar.f8026a);
        eVar.a(f7397c, gVar.f8027b);
    }
}
