package U1;

import java.io.Closeable;

/* JADX INFO: loaded from: classes.dex */
public final class l implements Closeable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public p029c8.a f7420a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public V1.e f7421b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public p029c8.a f7422c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public p013b2.e f7423d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public p029c8.a f7424e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public p029c8.a f7425f;

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        ((p013b2.i) ((p013b2.d) this.f7424e.get())).close();
    }
}
