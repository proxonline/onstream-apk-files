package U1;

/* JADX INFO: loaded from: classes.dex */
public final class b implements F5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final b f7383a = new b();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final F5.c f7384b = new F5.c("storageMetrics", B0.a.u(B0.a.t(I5.e.class, new I5.a(1))));

    @Override // F5.a
    public final void a(Object obj, Object obj2) {
        ((F5.e) obj2).g(f7384b, ((X1.b) obj).f8009a);
    }
}
