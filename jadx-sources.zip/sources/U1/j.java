package U1;

import android.support.v4.media.session.z;
import android.util.Base64;
import com.google.android.gms.internal.cast.z1;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f7416a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f7417b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final R1.d f7418c;

    public j(String str, byte[] bArr, R1.d dVar) {
        this.f7416a = str;
        this.f7417b = bArr;
        this.f7418c = dVar;
    }

    public static z a() {
        z zVar = new z(21);
        zVar.f10228d = R1.d.f6638a;
        return zVar;
    }

    public final j b(R1.d dVar) {
        z zVarA = a();
        zVarA.I(this.f7416a);
        if (dVar == null) {
            throw new NullPointerException("Null priority");
        }
        zVarA.f10228d = dVar;
        zVarA.f10227c = this.f7417b;
        return zVarA.o();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof j) {
            j jVar = (j) obj;
            if (this.f7416a.equals(jVar.f7416a) && Arrays.equals(this.f7417b, jVar.f7417b) && this.f7418c.equals(jVar.f7418c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((((this.f7416a.hashCode() ^ 1000003) * 1000003) ^ Arrays.hashCode(this.f7417b)) * 1000003) ^ this.f7418c.hashCode();
    }

    public final String toString() {
        byte[] bArr = this.f7417b;
        String strEncodeToString = bArr == null ? "" : Base64.encodeToString(bArr, 2);
        StringBuilder sb = new StringBuilder("TransportContext(");
        sb.append(this.f7416a);
        sb.append(", ");
        sb.append(this.f7418c);
        sb.append(", ");
        return z1.m(sb, strEncodeToString, ")");
    }
}
