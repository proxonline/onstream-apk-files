package U1;

/* JADX INFO: loaded from: classes.dex */
public final class e implements F5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final e f7391a = new e();

    static {
        F5.c.a("clientMetrics");
    }

    @Override // F5.a
    public final void a(Object obj, Object obj2) {
        throw B0.a.h(obj);
    }
}
