package U1;

/* JADX INFO: loaded from: classes.dex */
public final class a implements F5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f7378a = new a();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final F5.c f7379b = new F5.c("window", B0.a.u(B0.a.t(I5.e.class, new I5.a(1))));

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final F5.c f7380c = new F5.c("logSourceMetrics", B0.a.u(B0.a.t(I5.e.class, new I5.a(2))));

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final F5.c f7381d = new F5.c("globalMetrics", B0.a.u(B0.a.t(I5.e.class, new I5.a(3))));

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final F5.c f7382e = new F5.c("appNamespace", B0.a.u(B0.a.t(I5.e.class, new I5.a(4))));

    @Override // F5.a
    public final void a(Object obj, Object obj2) {
        X1.a aVar = (X1.a) obj;
        F5.e eVar = (F5.e) obj2;
        eVar.g(f7379b, aVar.f8005a);
        eVar.g(f7380c, aVar.f8006b);
        eVar.g(f7381d, aVar.f8007c);
        eVar.g(f7382e, aVar.f8008d);
    }
}
