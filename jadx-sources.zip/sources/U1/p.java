package U1;

import j$.util.DesugarCollections;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes.dex */
public final class p implements W1.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f7429a;

    @Override // p029c8.a
    public final Object get() {
        int i9 = 0;
        switch (this.f7429a) {
            case 0:
                return new r(0, Executors.newSingleThreadExecutor());
            default:
                p033d2.b bVar = new p033d2.b(i9);
                HashMap map = new HashMap();
                Set set = Collections.EMPTY_SET;
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(R1.d.f6638a, new p003a2.c(30000L, 86400000L, set));
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(R1.d.f6640c, new p003a2.c(1000L, 86400000L, set));
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                Set setUnmodifiableSet = DesugarCollections.unmodifiableSet(new HashSet(Arrays.asList(p003a2.e.f9869b)));
                if (setUnmodifiableSet == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(R1.d.f6639b, new p003a2.c(86400000L, 86400000L, setUnmodifiableSet));
                if (map.keySet().size() < R1.d.values().length) {
                    throw new IllegalStateException("Not all priorities have been configured");
                }
                new HashMap();
                return new p003a2.b(bVar, map);
        }
    }
}
