package U1;

import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class s implements R1.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Set f7433a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f7434b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final t f7435c;

    public s(Set set, j jVar, t tVar) {
        this.f7433a = set;
        this.f7434b = jVar;
        this.f7435c = tVar;
    }

    public final C1.b a(String str, R1.c cVar, R1.e eVar) {
        Set set = this.f7433a;
        if (!set.contains(cVar)) {
            throw new IllegalArgumentException(String.format("%s is not supported byt this factory. Supported encodings are: %s.", cVar, set));
        }
        C1.b bVar = new C1.b();
        bVar.f547a = this.f7434b;
        bVar.f548b = str;
        bVar.f549c = cVar;
        bVar.f550d = eVar;
        bVar.f551e = this.f7435c;
        return bVar;
    }
}
