package U1;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f7407a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Integer f7408b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final n f7409c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f7410d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f7411e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Map f7412f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Integer f7413g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f7414h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final byte[] f7415i;
    public final byte[] j;

    public i(String str, Integer num, n nVar, long j, long j9, HashMap map, Integer num2, String str2, byte[] bArr, byte[] bArr2) {
        this.f7407a = str;
        this.f7408b = num;
        this.f7409c = nVar;
        this.f7410d = j;
        this.f7411e = j9;
        this.f7412f = map;
        this.f7413g = num2;
        this.f7414h = str2;
        this.f7415i = bArr;
        this.j = bArr2;
    }

    public final String a(String str) {
        String str2 = (String) this.f7412f.get(str);
        return str2 == null ? "" : str2;
    }

    public final int b(String str) {
        String str2 = (String) this.f7412f.get(str);
        if (str2 == null) {
            return 0;
        }
        return Integer.valueOf(str2).intValue();
    }

    public final h c() {
        h hVar = new h();
        String str = this.f7407a;
        if (str == null) {
            throw new NullPointerException("Null transportName");
        }
        hVar.f7398a = str;
        hVar.f7400c = this.f7408b;
        hVar.f7401d = this.f7413g;
        hVar.f7399b = this.f7414h;
        hVar.f7406i = this.f7415i;
        hVar.j = this.j;
        n nVar = this.f7409c;
        if (nVar == null) {
            throw new NullPointerException("Null encodedPayload");
        }
        hVar.f7402e = nVar;
        hVar.f7403f = Long.valueOf(this.f7410d);
        hVar.f7404g = Long.valueOf(this.f7411e);
        hVar.f7405h = new HashMap(this.f7412f);
        return hVar;
    }

    public final boolean equals(Object obj) {
        Integer num;
        Integer num2;
        String str;
        if (obj == this) {
            return true;
        }
        if (obj instanceof i) {
            i iVar = (i) obj;
            String str2 = iVar.f7407a;
            String str3 = iVar.f7414h;
            Integer num3 = iVar.f7413g;
            Integer num4 = iVar.f7408b;
            if (this.f7407a.equals(str2) && ((num = this.f7408b) != null ? num.equals(num4) : num4 == null) && this.f7409c.equals(iVar.f7409c) && this.f7410d == iVar.f7410d && this.f7411e == iVar.f7411e && this.f7412f.equals(iVar.f7412f) && ((num2 = this.f7413g) != null ? num2.equals(num3) : num3 == null) && ((str = this.f7414h) != null ? str.equals(str3) : str3 == null) && Arrays.equals(this.f7415i, iVar.f7415i) && Arrays.equals(this.j, iVar.j)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int iHashCode = (this.f7407a.hashCode() ^ 1000003) * 1000003;
        Integer num = this.f7408b;
        int iHashCode2 = (((iHashCode ^ (num == null ? 0 : num.hashCode())) * 1000003) ^ this.f7409c.hashCode()) * 1000003;
        long j = this.f7410d;
        int i9 = (iHashCode2 ^ ((int) (j ^ (j >>> 32)))) * 1000003;
        long j9 = this.f7411e;
        int iHashCode3 = (((i9 ^ ((int) (j9 ^ (j9 >>> 32)))) * 1000003) ^ this.f7412f.hashCode()) * 1000003;
        Integer num2 = this.f7413g;
        int iHashCode4 = (iHashCode3 ^ (num2 == null ? 0 : num2.hashCode())) * 1000003;
        String str = this.f7414h;
        return ((((iHashCode4 ^ (str != null ? str.hashCode() : 0)) * 1000003) ^ Arrays.hashCode(this.f7415i)) * 1000003) ^ Arrays.hashCode(this.j);
    }

    public final String toString() {
        return "EventInternal{transportName=" + this.f7407a + ", code=" + this.f7408b + ", encodedPayload=" + this.f7409c + ", eventMillis=" + this.f7410d + ", uptimeMillis=" + this.f7411e + ", autoMetadata=" + this.f7412f + ", productId=" + this.f7413g + ", pseudonymousId=" + this.f7414h + ", experimentIdsClear=" + Arrays.toString(this.f7415i) + ", experimentIdsEncrypted=" + Arrays.toString(this.j) + "}";
    }
}
