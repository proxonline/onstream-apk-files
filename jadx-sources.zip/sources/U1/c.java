package U1;

/* JADX INFO: loaded from: classes.dex */
public final class c implements F5.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c f7385a = new c();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final F5.c f7386b = new F5.c("eventsDroppedCount", B0.a.u(B0.a.t(I5.e.class, new I5.a(1))));

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final F5.c f7387c = new F5.c("reason", B0.a.u(B0.a.t(I5.e.class, new I5.a(3))));

    @Override // F5.a
    public final void a(Object obj, Object obj2) {
        X1.d dVar = (X1.d) obj;
        F5.e eVar = (F5.e) obj2;
        eVar.a(f7386b, dVar.f8019a);
        eVar.g(f7387c, dVar.f8020b);
    }
}
