package Y5;

import p007a6.d;
import p148p5.b;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f9397a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ b f9398b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ d f9399c;

    public /* synthetic */ a(b bVar, d dVar, int i9) {
        this.f9397a = i9;
        this.f9398b = bVar;
        this.f9399c = dVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f9397a) {
            case 0:
                this.f9398b.a(this.f9399c);
                break;
            default:
                this.f9398b.a(this.f9399c);
                break;
        }
    }
}
