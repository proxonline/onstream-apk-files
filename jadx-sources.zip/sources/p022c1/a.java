package p022c1;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
}
