package p022c1;

import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public abstract class b extends ViewGroup {
}
