package E;

import X3.P1;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {
    public static Intent a(Context context, P1 p8, IntentFilter intentFilter) {
        return context.registerReceiver(p8, intentFilter, null, null, 0);
    }

    public static Intent b(Context context, P1 p8, IntentFilter intentFilter) {
        return context.registerReceiver(p8, intentFilter, null, null, 2);
    }

    public static void c(Context context, Intent intent) {
        context.startForegroundService(intent);
    }
}
