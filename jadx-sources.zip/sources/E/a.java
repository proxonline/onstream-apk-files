package E;

import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static Context a(Context context) {
        return context.createDeviceProtectedStorageContext();
    }
}
