package E;

import android.content.Intent;

/* JADX INFO: loaded from: classes.dex */
public abstract class f {
    public static Object a(Intent intent, String str, Class cls) {
        return intent.getParcelableExtra(str, cls);
    }
}
