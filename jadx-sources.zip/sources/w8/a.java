package w8;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public class a implements Iterable, p176s8.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f25509a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f25510b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f25511c;

    public a(int i9, int i10, int i11) {
        if (i11 == 0) {
            throw new IllegalArgumentException("Step must be non-zero.");
        }
        if (i11 == Integer.MIN_VALUE) {
            throw new IllegalArgumentException("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
        }
        this.f25509a = i9;
        this.f25510b = p001a.a.t(i9, i10, i11);
        this.f25511c = i11;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        if (isEmpty() && ((a) obj).isEmpty()) {
            return true;
        }
        a aVar = (a) obj;
        return this.f25509a == aVar.f25509a && this.f25510b == aVar.f25510b && this.f25511c == aVar.f25511c;
    }

    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (((this.f25509a * 31) + this.f25510b) * 31) + this.f25511c;
    }

    public boolean isEmpty() {
        int i9 = this.f25511c;
        int i10 = this.f25510b;
        int i11 = this.f25509a;
        if (i9 > 0) {
            return i11 > i10;
        }
        return i11 < i10;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return new b(this.f25509a, this.f25510b, this.f25511c);
    }

    public String toString() {
        StringBuilder sb;
        int i9 = this.f25510b;
        int i10 = this.f25509a;
        int i11 = this.f25511c;
        if (i11 > 0) {
            sb = new StringBuilder();
            sb.append(i10);
            sb.append("..");
            sb.append(i9);
            sb.append(" step ");
            sb.append(i11);
        } else {
            sb = new StringBuilder();
            sb.append(i10);
            sb.append(" downTo ");
            sb.append(i9);
            sb.append(" step ");
            sb.append(-i11);
        }
        return sb.toString();
    }
}
