package w8;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class d implements Iterator, p176s8.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f25517a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f25518b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f25519c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f25520d;

    public d(long j, long j9, long j10) {
        this.f25517a = j10;
        this.f25518b = j9;
        boolean z9 = false;
        if (j10 <= 0 ? j >= j9 : j <= j9) {
            z9 = true;
        }
        this.f25519c = z9;
        this.f25520d = z9 ? j : j9;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f25519c;
    }

    @Override // java.util.Iterator
    public final /* bridge */ /* synthetic */ Object next() {
        return Long.valueOf(nextLong());
    }

    public final long nextLong() {
        long j = this.f25520d;
        if (j != this.f25518b) {
            this.f25520d = this.f25517a + j;
            return j;
        }
        if (!this.f25519c) {
            throw new NoSuchElementException();
        }
        this.f25519c = false;
        return j;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
