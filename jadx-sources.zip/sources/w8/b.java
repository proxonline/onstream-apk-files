package w8;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Iterator, p176s8.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f25512a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f25513b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f25514c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f25515d;

    public b(int i9, int i10, int i11) {
        this.f25512a = i11;
        this.f25513b = i10;
        boolean z9 = false;
        if (i11 <= 0 ? i9 >= i10 : i9 <= i10) {
            z9 = true;
        }
        this.f25514c = z9;
        this.f25515d = z9 ? i9 : i10;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f25514c;
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i9 = this.f25515d;
        if (i9 != this.f25513b) {
            this.f25515d = this.f25512a + i9;
        } else {
            if (!this.f25514c) {
                throw new NoSuchElementException();
            }
            this.f25514c = false;
        }
        return Integer.valueOf(i9);
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
