package w8;

/* JADX INFO: loaded from: classes.dex */
public final class c extends a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final c f25516d = new c(1, 0, 1);

    @Override // w8.a
    public final boolean equals(Object obj) {
        if (!(obj instanceof c)) {
            return false;
        }
        if (isEmpty() && ((c) obj).isEmpty()) {
            return true;
        }
        c cVar = (c) obj;
        return this.f25509a == cVar.f25509a && this.f25510b == cVar.f25510b;
    }

    @Override // w8.a
    public final int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (this.f25509a * 31) + this.f25510b;
    }

    @Override // w8.a
    public final boolean isEmpty() {
        return this.f25509a > this.f25510b;
    }

    @Override // w8.a
    public final String toString() {
        return this.f25509a + ".." + this.f25510b;
    }
}
