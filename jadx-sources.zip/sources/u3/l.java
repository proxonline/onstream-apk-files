package u3;

import android.os.SystemClock;
import android.util.Log;
import com.google.android.gms.cast.MediaError;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.internal.measurement.H1;
import java.util.Iterator;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public final class l extends T2.d {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final String f23940A;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f23941e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public p146p3.q f23942f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Long f23943g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public p036d5.h f23944h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f23945i;
    public final n j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final n f23946k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final n f23947l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final n f23948m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final n f23949n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final n f23950o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final n f23951p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final n f23952q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final n f23953r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final n f23954s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final n f23955t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final n f23956u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final n f23957v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final n f23958w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final n f23959x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final n f23960y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public p015b4.i f23961z;

    static {
        Pattern pattern = a.f23933a;
        f23940A = "urn:x-cast:".concat("com.google.cast.media");
    }

    public l() {
        super(f23940A);
        this.f23945i = -1;
        n nVar = new n(86400000L);
        this.j = nVar;
        n nVar2 = new n(86400000L);
        this.f23946k = nVar2;
        n nVar3 = new n(86400000L);
        this.f23947l = nVar3;
        n nVar4 = new n(86400000L);
        this.f23948m = nVar4;
        n nVar5 = new n(10000L);
        this.f23949n = nVar5;
        n nVar6 = new n(86400000L);
        this.f23950o = nVar6;
        n nVar7 = new n(86400000L);
        this.f23951p = nVar7;
        n nVar8 = new n(86400000L);
        this.f23952q = nVar8;
        n nVar9 = new n(86400000L);
        this.f23953r = nVar9;
        n nVar10 = new n(86400000L);
        n nVar11 = new n(86400000L);
        n nVar12 = new n(86400000L);
        this.f23954s = nVar12;
        n nVar13 = new n(86400000L);
        this.f23955t = nVar13;
        n nVar14 = new n(86400000L);
        n nVar15 = new n(86400000L);
        this.f23956u = nVar15;
        n nVar16 = new n(86400000L);
        this.f23958w = nVar16;
        this.f23957v = new n(86400000L);
        n nVar17 = new n(86400000L);
        this.f23959x = nVar17;
        n nVar18 = new n(86400000L);
        n nVar19 = new n(86400000L);
        this.f23960y = nVar19;
        m(nVar);
        m(nVar2);
        m(nVar3);
        m(nVar4);
        m(nVar5);
        m(nVar6);
        m(nVar7);
        m(nVar8);
        m(nVar9);
        m(nVar10);
        m(nVar11);
        m(nVar12);
        m(nVar13);
        m(nVar14);
        m(nVar15);
        m(nVar16);
        m(nVar16);
        m(nVar17);
        m(nVar18);
        m(nVar19);
        s();
    }

    public static k r(JSONObject jSONObject) {
        MediaError.k(jSONObject);
        k kVar = new k();
        if (jSONObject.has("customData")) {
            jSONObject.optJSONObject("customData");
        }
        return kVar;
    }

    public static int[] y(JSONArray jSONArray) {
        if (jSONArray == null) {
            return null;
        }
        int[] iArr = new int[jSONArray.length()];
        for (int i9 = 0; i9 < jSONArray.length(); i9++) {
            iArr[i9] = jSONArray.getInt(i9);
        }
        return iArr;
    }

    public final long A() {
        p146p3.j jVar;
        p146p3.q qVar = this.f23942f;
        MediaInfo mediaInfo = qVar == null ? null : qVar.f22368a;
        long jQ = 0;
        if (mediaInfo != null && qVar != null) {
            Long l9 = this.f23943g;
            if (l9 != null) {
                if (l9.equals(4294967296000L)) {
                    p146p3.q qVar2 = this.f23942f;
                    if (qVar2.f22387u != null) {
                        long jLongValue = l9.longValue();
                        p146p3.q qVar3 = this.f23942f;
                        if (qVar3 != null && (jVar = qVar3.f22387u) != null) {
                            long j = jVar.f22324b;
                            jQ = !jVar.f22326d ? q(1.0d, j, -1L) : j;
                        }
                        return Math.min(jLongValue, jQ);
                    }
                    MediaInfo mediaInfo2 = qVar2 == null ? null : qVar2.f22368a;
                    if ((mediaInfo2 != null ? mediaInfo2.f14010e : 0L) >= 0) {
                        long jLongValue2 = l9.longValue();
                        p146p3.q qVar4 = this.f23942f;
                        MediaInfo mediaInfo3 = qVar4 != null ? qVar4.f22368a : null;
                        return Math.min(jLongValue2, mediaInfo3 != null ? mediaInfo3.f14010e : 0L);
                    }
                }
                return l9.longValue();
            }
            if (this.f23941e != 0) {
                double d9 = qVar.f22371d;
                long j9 = qVar.f22374g;
                return (d9 == 0.0d || qVar.f22372e != 2) ? j9 : q(d9, j9, mediaInfo.f14010e);
            }
        }
        return 0L;
    }

    public final long B() throws j {
        p146p3.q qVar = this.f23942f;
        if (qVar != null) {
            return qVar.f22369b;
        }
        throw new j();
    }

    public final void p(m mVar, int i9, long j, int i10, Integer num) {
        if (j != -1 && j < 0) {
            StringBuilder sb = new StringBuilder(53);
            sb.append("playPosition cannot be negative: ");
            sb.append(j);
            throw new IllegalArgumentException(sb.toString());
        }
        JSONObject jSONObject = new JSONObject();
        long jN = n();
        try {
            jSONObject.put("requestId", jN);
            jSONObject.put("type", "QUEUE_UPDATE");
            jSONObject.put("mediaSessionId", B());
            if (i9 != 0) {
                jSONObject.put("currentItemId", i9);
            }
            if (i10 != 0) {
                jSONObject.put("jump", i10);
            }
            String strW = T8.d.w(num);
            if (strW != null) {
                jSONObject.put("repeatMode", strW);
            }
            if (j != -1) {
                jSONObject.put("currentTime", j / 1000.0d);
            }
            int i11 = this.f23945i;
            if (i11 != -1) {
                jSONObject.put("sequenceNumber", i11);
            }
        } catch (JSONException unused) {
        }
        o(jN, jSONObject.toString());
        this.f23954s.a(jN, new i(this, mVar, 1));
    }

    public final long q(double d9, long j, long j9) {
        long jElapsedRealtime = SystemClock.elapsedRealtime() - this.f23941e;
        if (jElapsedRealtime < 0) {
            jElapsedRealtime = 0;
        }
        if (jElapsedRealtime == 0) {
            return j;
        }
        long j10 = j + ((long) (jElapsedRealtime * d9));
        if (j9 > 0 && j10 > j9) {
            return j9;
        }
        if (j10 >= 0) {
            return j10;
        }
        return 0L;
    }

    public final void s() {
        this.f23941e = 0L;
        this.f23942f = null;
        Iterator it = this.f7259d.iterator();
        while (it.hasNext()) {
            ((n) it.next()).f(2002);
        }
    }

    public final void t(JSONObject jSONObject, String str) {
        if (jSONObject.has("sequenceNumber")) {
            this.f23945i = jSONObject.optInt("sequenceNumber", -1);
        } else {
            H1 h6 = (H1) this.f7257b;
            Log.w((String) h6.f14458b, h6.f(str.concat(" message is missing a sequence number."), new Object[0]));
        }
    }

    public final void u() {
        p036d5.h hVar = this.f23944h;
        if (hVar != null) {
            p162r3.i iVar = (p162r3.i) hVar.f16762b;
            Iterator it = iVar.f22851g.iterator();
            while (it.hasNext()) {
                ((p172s3.g) ((p162r3.h) it.next())).b();
            }
            Iterator it2 = iVar.f22852h.iterator();
            while (it2.hasNext()) {
                ((p162r3.g) it2.next()).getClass();
            }
        }
    }

    public final void v() {
        p036d5.h hVar = this.f23944h;
        if (hVar != null) {
            p162r3.i iVar = (p162r3.i) hVar.f16762b;
            Iterator it = iVar.f22851g.iterator();
            while (it.hasNext()) {
                ((p172s3.g) ((p162r3.h) it.next())).b();
            }
            Iterator it2 = iVar.f22852h.iterator();
            while (it2.hasNext()) {
                ((p162r3.g) it2.next()).getClass();
            }
        }
    }

    public final void w() {
        p036d5.h hVar = this.f23944h;
        if (hVar != null) {
            p162r3.i iVar = (p162r3.i) hVar.f16762b;
            Iterator it = iVar.f22851g.iterator();
            while (it.hasNext()) {
                ((p172s3.g) ((p162r3.h) it.next())).b();
            }
            Iterator it2 = iVar.f22852h.iterator();
            while (it2.hasNext()) {
                ((p162r3.g) it2.next()).j();
            }
        }
    }

    public final void x() {
        p036d5.h hVar = this.f23944h;
        if (hVar != null) {
            p162r3.i iVar = (p162r3.i) hVar.f16762b;
            for (p162r3.v vVar : iVar.j.values()) {
                if (iVar.f() && !vVar.f22885d) {
                    p162r3.i iVar2 = vVar.f22886e;
                    P3.d dVar = iVar2.f22846b;
                    p162r3.u uVar = vVar.f22884c;
                    dVar.removeCallbacks(uVar);
                    vVar.f22885d = true;
                    iVar2.f22846b.postDelayed(uVar, vVar.f22883b);
                } else if (!iVar.f() && vVar.f22885d) {
                    vVar.f22886e.f22846b.removeCallbacks(vVar.f22884c);
                    vVar.f22885d = false;
                }
                if (vVar.f22885d && (iVar.g() || iVar.r() || iVar.j() || iVar.i())) {
                    iVar.s(vVar.f22882a);
                }
            }
            Iterator it = iVar.f22851g.iterator();
            while (it.hasNext()) {
                ((p172s3.g) ((p162r3.h) it.next())).b();
            }
            Iterator it2 = iVar.f22852h.iterator();
            while (it2.hasNext()) {
                ((p162r3.g) it2.next()).k();
            }
        }
    }

    public final void z() {
        synchronized (this.f7259d) {
            try {
                Iterator it = this.f7259d.iterator();
                while (it.hasNext()) {
                    ((n) it.next()).f(2002);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        s();
    }
}
