package u3;

import B3.AbstractC0007h;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.internal.measurement.H1;
import p146p3.y;

/* JADX INFO: loaded from: classes.dex */
public final class u extends AbstractC0007h {
    public static final H1 X = new H1("CastClientImplCxless");

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final CastDevice f23999A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final long f24000B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final Bundle f24001C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final String f24002D;

    public u(Context context, Looper looper, X4.p pVar, CastDevice castDevice, long j, Bundle bundle, String str, p225z3.o oVar, p225z3.o oVar2) {
        super(context, looper, 10, pVar, oVar, oVar2, 0);
        this.f23999A = castDevice;
        this.f24000B = j;
        this.f24001C = bundle;
        this.f24002D = str;
    }

    @Override // B3.AbstractC0004e
    public final boolean A() {
        return true;
    }

    @Override // B3.AbstractC0004e, p216y3.c
    public final int f() {
        return 19390000;
    }

    @Override // B3.AbstractC0004e, p216y3.c
    public final void l() {
        try {
            try {
                ((d) u()).f1();
            } finally {
                super.l();
            }
        } catch (RemoteException | IllegalStateException e9) {
            X.a(e9, "Error while disconnecting the controller interface", new Object[0]);
            super.l();
        }
    }

    @Override // B3.AbstractC0004e
    public final /* synthetic */ IInterface o(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.cast.internal.ICastDeviceController");
        return iInterfaceQueryLocalInterface instanceof d ? (d) iInterfaceQueryLocalInterface : new d(iBinder);
    }

    @Override // B3.AbstractC0004e
    public final p208x3.d[] q() {
        return y.f22421e;
    }

    @Override // B3.AbstractC0004e
    public final Bundle s() {
        Bundle bundle = new Bundle();
        X.b("getRemoteService()", new Object[0]);
        CastDevice castDevice = this.f23999A;
        castDevice.getClass();
        bundle.putParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE", castDevice);
        bundle.putLong("com.google.android.gms.cast.EXTRA_CAST_FLAGS", this.f24000B);
        bundle.putString("connectionless_client_record_id", this.f24002D);
        Bundle bundle2 = this.f24001C;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        return bundle;
    }

    @Override // B3.AbstractC0004e
    public final String v() {
        return "com.google.android.gms.cast.internal.ICastDeviceController";
    }

    @Override // B3.AbstractC0004e
    public final String w() {
        return "com.google.android.gms.cast.service.BIND_CAST_DEVICE_CONTROLLER_SERVICE";
    }
}
