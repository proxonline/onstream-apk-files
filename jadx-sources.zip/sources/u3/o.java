package u3;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.internal.cast.AbstractC0659h;

/* JADX INFO: loaded from: classes.dex */
public final class o extends O3.c implements c {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ int f23969f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ p015b4.i f23970g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(int i9, p015b4.i iVar) {
        super("com.google.android.gms.cast.internal.IBundleCallback", 3);
        this.f23969f = i9;
        this.f23970g = iVar;
    }

    @Override // O3.c
    public final boolean b1(int i9, Parcel parcel, Parcel parcel2) {
        if (i9 != 1) {
            return false;
        }
        g((Bundle) AbstractC0659h.a(parcel, Bundle.CREATOR));
        return true;
    }

    @Override // u3.c
    public final void g(Bundle bundle) {
        switch (this.f23969f) {
            case 0:
                this.f23970g.b(bundle);
                break;
            case 1:
                this.f23970g.b(bundle);
                break;
            default:
                this.f23970g.b(bundle);
                break;
        }
    }
}
