package u3;

import android.os.Looper;
import com.google.android.gms.internal.measurement.H1;
import java.util.Locale;
import p133o.I0;

/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final H1 f23962f = new H1("RequestTracker");

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final Object f23963g = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f23964a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public m f23967d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public I0 f23968e;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f23966c = -1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final P3.d f23965b = new P3.d(Looper.getMainLooper());

    public n(long j) {
        this.f23964a = j;
    }

    public final void a(long j, m mVar) {
        m mVar2;
        long j9;
        Object obj = f23963g;
        synchronized (obj) {
            mVar2 = this.f23967d;
            j9 = this.f23966c;
            this.f23966c = j;
            this.f23967d = mVar;
        }
        if (mVar2 != null) {
            mVar2.f(j9);
        }
        synchronized (obj) {
            try {
                I0 i9 = this.f23968e;
                if (i9 != null) {
                    this.f23965b.removeCallbacks(i9);
                }
                I0 i10 = new I0(4, this);
                this.f23968e = i10;
                this.f23965b.postDelayed(i10, this.f23964a);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b(long j, int i9, k kVar) {
        synchronized (f23963g) {
            try {
                long j9 = this.f23966c;
                if (j9 == -1 || j9 != j) {
                    return;
                }
                Locale locale = Locale.ROOT;
                e(i9, kVar, "request " + j + " completed");
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean c() {
        boolean z9;
        synchronized (f23963g) {
            z9 = this.f23966c != -1;
        }
        return z9;
    }

    public final boolean d(long j) {
        boolean z9;
        synchronized (f23963g) {
            long j9 = this.f23966c;
            z9 = false;
            if (j9 != -1 && j9 == j) {
                z9 = true;
            }
        }
        return z9;
    }

    public final void e(int i9, Object obj, String str) {
        f23962f.b(str, new Object[0]);
        Object obj2 = f23963g;
        synchronized (obj2) {
            try {
                m mVar = this.f23967d;
                if (mVar != null) {
                    mVar.l(this.f23966c, obj, i9);
                }
                this.f23966c = -1L;
                this.f23967d = null;
                synchronized (obj2) {
                    try {
                        I0 i10 = this.f23968e;
                        if (i10 != null) {
                            this.f23965b.removeCallbacks(i10);
                            this.f23968e = null;
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final boolean f(int i9) {
        synchronized (f23963g) {
            try {
                long j = this.f23966c;
                if (j == -1) {
                    return false;
                }
                Locale locale = Locale.ROOT;
                e(i9, null, "clearing request " + j);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
