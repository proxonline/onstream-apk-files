package p142p;

import D0.e;
import T8.d;
import android.os.Looper;

/* JADX INFO: loaded from: classes.dex */
public final class a extends d {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static volatile a f22174k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final e f22175l = new e(1);
    public final c j = new c();

    public static a y() {
        if (f22174k != null) {
            return f22174k;
        }
        synchronized (a.class) {
            try {
                if (f22174k == null) {
                    f22174k = new a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return f22174k;
    }

    public final void z(Runnable runnable) {
        c cVar = this.j;
        if (cVar.f22179l == null) {
            synchronized (cVar.j) {
                try {
                    if (cVar.f22179l == null) {
                        cVar.f22179l = c.y(Looper.getMainLooper());
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        cVar.f22179l.post(runnable);
    }
}
