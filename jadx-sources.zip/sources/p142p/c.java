package p142p;

import F.a;
import T8.d;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes.dex */
public final class c extends d {
    public final Object j = new Object();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final ExecutorService f22178k = Executors.newFixedThreadPool(4, new b());

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public volatile Handler f22179l;

    public static Handler y(Looper looper) {
        if (Build.VERSION.SDK_INT >= 28) {
            return a.b(looper);
        }
        try {
            return (Handler) Handler.class.getDeclaredConstructor(Looper.class, Handler.Callback.class, Boolean.TYPE).newInstance(looper, null, Boolean.TRUE);
        } catch (IllegalAccessException | InstantiationException | NoSuchMethodException unused) {
            return new Handler(looper);
        } catch (InvocationTargetException unused2) {
            return new Handler(looper);
        }
    }
}
