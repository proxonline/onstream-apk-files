package p142p;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import p174s5.w;

/* JADX INFO: loaded from: classes.dex */
public final class b implements ThreadFactory {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f22176a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Number f22177b;

    public b() {
        this.f22176a = 0;
        this.f22177b = new AtomicInteger(0);
    }

    public b(AtomicLong atomicLong) {
        this.f22176a = 1;
        this.f22177b = atomicLong;
    }

    @Override // java.util.concurrent.ThreadFactory
    public final Thread newThread(Runnable runnable) {
        switch (this.f22176a) {
            case 0:
                Thread thread = new Thread(runnable);
                thread.setName("arch_disk_io_" + ((AtomicInteger) this.f22177b).getAndIncrement());
                return thread;
            default:
                Thread threadNewThread = Executors.defaultThreadFactory().newThread(new w(runnable));
                threadNewThread.setName("awaitEvenIfOnMainThread task continuation executor" + ((AtomicLong) this.f22177b).getAndIncrement());
                return threadNewThread;
        }
    }
}
