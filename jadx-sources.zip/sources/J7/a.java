package J7;

import co.notix.R;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f3679a = {R.attr.autoPlay, R.attr.enableAutomaticInitialization, R.attr.handleNetworkEvents, R.attr.videoId};
}
