package p082i6;

import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final AtomicBoolean f19301a = new AtomicBoolean(false);

    public static int a() {
        return f19301a.get() ? 28 : 20;
    }
}
