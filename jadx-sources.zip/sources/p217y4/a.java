package p217y4;

import android.R;
import android.content.res.ColorStateList;
import com.google.android.gms.internal.measurement.AbstractC0734e2;
import p133o.C1258z;

/* JADX INFO: loaded from: classes.dex */
public final class a extends C1258z {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final int[][] f25968g = {new int[]{R.attr.state_enabled, R.attr.state_checked}, new int[]{R.attr.state_enabled, -16842912}, new int[]{-16842910, R.attr.state_checked}, new int[]{-16842910, -16842912}};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ColorStateList f25969e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f25970f;

    private ColorStateList getMaterialThemeColorsTintList() {
        if (this.f25969e == null) {
            int iK = AbstractC0734e2.k(this, co.notix.R.attr.colorControlActivated);
            int iK2 = AbstractC0734e2.k(this, co.notix.R.attr.colorOnSurface);
            int iK3 = AbstractC0734e2.k(this, co.notix.R.attr.colorSurface);
            this.f25969e = new ColorStateList(f25968g, new int[]{AbstractC0734e2.u(iK3, 1.0f, iK), AbstractC0734e2.u(iK3, 0.54f, iK2), AbstractC0734e2.u(iK3, 0.38f, iK2), AbstractC0734e2.u(iK3, 0.38f, iK2)});
        }
        return this.f25969e;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f25970f && getButtonTintList() == null) {
            setUseMaterialThemeColors(true);
        }
    }

    public void setUseMaterialThemeColors(boolean z9) {
        this.f25970f = z9;
        if (z9) {
            setButtonTintList(getMaterialThemeColorsTintList());
        } else {
            setButtonTintList(null);
        }
    }
}
