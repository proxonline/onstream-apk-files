package A5;

import p174s5.y;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f44a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f45b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f46c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f47d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final y f48e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f49f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f50g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f51h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f52i;

    public i(String str, String str2, String str3, String str4, y yVar, String str5, String str6, String str7, int i9) {
        this.f44a = str;
        this.f45b = str2;
        this.f46c = str3;
        this.f47d = str4;
        this.f48e = yVar;
        this.f49f = str5;
        this.f50g = str6;
        this.f51h = str7;
        this.f52i = i9;
    }
}
