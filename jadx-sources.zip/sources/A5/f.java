package A5;

import H0.B;
import T0.j;
import android.database.Cursor;
import android.util.Log;
import androidx.work.impl.WorkDatabase_Impl;
import com.google.android.gms.internal.measurement.AbstractC0734e2;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f33a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f34b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f35c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f36d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f37e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f38f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f39g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Object f40h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Object f41i;

    public f(WorkDatabase_Impl workDatabase_Impl) {
        this.f33a = workDatabase_Impl;
        this.f34b = new p144p1.b(workDatabase_Impl, 5);
        this.f35c = new p144p1.e(workDatabase_Impl, 3);
        this.f36d = new p144p1.e(workDatabase_Impl, 4);
        this.f37e = new p144p1.e(workDatabase_Impl, 5);
        this.f38f = new p144p1.e(workDatabase_Impl, 6);
        this.f39g = new p144p1.e(workDatabase_Impl, 7);
        this.f40h = new p144p1.e(workDatabase_Impl, 8);
        this.f41i = new p144p1.e(workDatabase_Impl, 9);
        new p144p1.e(workDatabase_Impl, 10);
    }

    public static void n(JSONObject jSONObject, String str) {
        String str2 = str + jSONObject.toString();
        if (Log.isLoggable("FirebaseCrashlytics", 3)) {
            Log.d("FirebaseCrashlytics", str2, null);
        }
    }

    public void a(p158r.e eVar) throws IOException {
        ArrayList arrayList;
        p158r.b bVar = (p158r.b) eVar.keySet();
        p158r.e eVar2 = bVar.f22699a;
        if (eVar2.isEmpty()) {
            return;
        }
        if (eVar.f22719c > 999) {
            p158r.e eVar3 = new p158r.e(999);
            int i9 = eVar.f22719c;
            int i10 = 0;
            int i11 = 0;
            while (i10 < i9) {
                eVar3.put((String) eVar.f(i10), (ArrayList) eVar.i(i10));
                i10++;
                i11++;
                if (i11 == 999) {
                    a(eVar3);
                    eVar3 = new p158r.e(999);
                    i11 = 0;
                }
            }
            if (i11 > 0) {
                a(eVar3);
                return;
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT `progress`,`work_spec_id` FROM `WorkProgress` WHERE `work_spec_id` IN (");
        int i12 = eVar2.f22719c;
        K3.h.a(i12, sb);
        sb.append(")");
        B bF = B.f(i12, sb.toString());
        Iterator it = bVar.iterator();
        int i13 = 1;
        while (true) {
            p158r.a aVar = (p158r.a) it;
            if (!aVar.hasNext()) {
                break;
            }
            String str = (String) aVar.next();
            if (str == null) {
                bF.b(i13);
            } else {
                bF.p(i13, str);
            }
            i13++;
        }
        Cursor cursorG = p054f5.b.G((WorkDatabase_Impl) this.f33a, bF, false);
        try {
            int iM = AbstractC0734e2.m(cursorG, "work_spec_id");
            if (iM == -1) {
                cursorG.close();
                return;
            }
            while (cursorG.moveToNext()) {
                if (!cursorG.isNull(iM) && (arrayList = (ArrayList) eVar.get(cursorG.getString(iM))) != null) {
                    arrayList.add(p060g1.h.a(cursorG.getBlob(0)));
                }
            }
            cursorG.close();
        } catch (Throwable th) {
            cursorG.close();
            throw th;
        }
    }

    public void b(p158r.e eVar) throws IOException {
        ArrayList arrayList;
        p158r.b bVar = (p158r.b) eVar.keySet();
        p158r.e eVar2 = bVar.f22699a;
        if (eVar2.isEmpty()) {
            return;
        }
        if (eVar.f22719c > 999) {
            p158r.e eVar3 = new p158r.e(999);
            int i9 = eVar.f22719c;
            int i10 = 0;
            int i11 = 0;
            while (i10 < i9) {
                eVar3.put((String) eVar.f(i10), (ArrayList) eVar.i(i10));
                i10++;
                i11++;
                if (i11 == 999) {
                    b(eVar3);
                    eVar3 = new p158r.e(999);
                    i11 = 0;
                }
            }
            if (i11 > 0) {
                b(eVar3);
                return;
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT `tag`,`work_spec_id` FROM `WorkTag` WHERE `work_spec_id` IN (");
        int i12 = eVar2.f22719c;
        K3.h.a(i12, sb);
        sb.append(")");
        B bF = B.f(i12, sb.toString());
        Iterator it = bVar.iterator();
        int i13 = 1;
        while (true) {
            p158r.a aVar = (p158r.a) it;
            if (!aVar.hasNext()) {
                break;
            }
            String str = (String) aVar.next();
            if (str == null) {
                bF.b(i13);
            } else {
                bF.p(i13, str);
            }
            i13++;
        }
        Cursor cursorG = p054f5.b.G((WorkDatabase_Impl) this.f33a, bF, false);
        try {
            int iM = AbstractC0734e2.m(cursorG, "work_spec_id");
            if (iM == -1) {
                cursorG.close();
                return;
            }
            while (cursorG.moveToNext()) {
                if (!cursorG.isNull(iM) && (arrayList = (ArrayList) eVar.get(cursorG.getString(iM))) != null) {
                    arrayList.add(cursorG.getString(0));
                }
            }
            cursorG.close();
        } catch (Throwable th) {
            cursorG.close();
            throw th;
        }
    }

    public void c(String str) {
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        p144p1.e eVar = (p144p1.e) this.f35c;
        j jVarA = eVar.a();
        if (str == null) {
            jVarA.b(1);
        } else {
            jVarA.p(1, str);
        }
        workDatabase_Impl.c();
        try {
            jVarA.a();
            workDatabase_Impl.q();
        } finally {
            workDatabase_Impl.n();
            eVar.i(jVarA);
        }
    }

    public ArrayList d() throws Throwable {
        B b10;
        B bF = B.f(1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 ORDER BY period_start_time LIMIT ?");
        bF.d(200, 1);
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        Cursor cursorG = p054f5.b.G(workDatabase_Impl, bF, false);
        try {
            int iN = AbstractC0734e2.n(cursorG, "required_network_type");
            int iN2 = AbstractC0734e2.n(cursorG, "requires_charging");
            int iN3 = AbstractC0734e2.n(cursorG, "requires_device_idle");
            int iN4 = AbstractC0734e2.n(cursorG, "requires_battery_not_low");
            int iN5 = AbstractC0734e2.n(cursorG, "requires_storage_not_low");
            int iN6 = AbstractC0734e2.n(cursorG, "trigger_content_update_delay");
            int iN7 = AbstractC0734e2.n(cursorG, "trigger_max_content_delay");
            int iN8 = AbstractC0734e2.n(cursorG, "content_uri_triggers");
            int iN9 = AbstractC0734e2.n(cursorG, "id");
            int iN10 = AbstractC0734e2.n(cursorG, "state");
            int iN11 = AbstractC0734e2.n(cursorG, "worker_class_name");
            int iN12 = AbstractC0734e2.n(cursorG, "input_merger_class_name");
            int iN13 = AbstractC0734e2.n(cursorG, "input");
            b10 = bF;
            try {
                int iN14 = AbstractC0734e2.n(cursorG, "output");
                int iN15 = AbstractC0734e2.n(cursorG, "initial_delay");
                int iN16 = AbstractC0734e2.n(cursorG, "interval_duration");
                int iN17 = AbstractC0734e2.n(cursorG, "flex_duration");
                int iN18 = AbstractC0734e2.n(cursorG, "run_attempt_count");
                int iN19 = AbstractC0734e2.n(cursorG, "backoff_policy");
                int iN20 = AbstractC0734e2.n(cursorG, "backoff_delay_duration");
                int iN21 = AbstractC0734e2.n(cursorG, "period_start_time");
                int iN22 = AbstractC0734e2.n(cursorG, "minimum_retention_duration");
                int iN23 = AbstractC0734e2.n(cursorG, "schedule_requested_at");
                int iN24 = AbstractC0734e2.n(cursorG, "run_in_foreground");
                int iN25 = AbstractC0734e2.n(cursorG, "out_of_quota_policy");
                int i9 = iN14;
                ArrayList arrayList = new ArrayList(cursorG.getCount());
                while (cursorG.moveToNext()) {
                    String string = cursorG.getString(iN9);
                    int i10 = iN9;
                    String string2 = cursorG.getString(iN11);
                    int i11 = iN11;
                    p060g1.c cVar = new p060g1.c();
                    int i12 = iN;
                    cVar.f18098a = p001a.a.y(cursorG.getInt(iN));
                    cVar.f18099b = cursorG.getInt(iN2) != 0;
                    cVar.f18100c = cursorG.getInt(iN3) != 0;
                    cVar.f18101d = cursorG.getInt(iN4) != 0;
                    cVar.f18102e = cursorG.getInt(iN5) != 0;
                    int i13 = iN2;
                    cVar.f18103f = cursorG.getLong(iN6);
                    cVar.f18104g = cursorG.getLong(iN7);
                    cVar.f18105h = p001a.a.b(cursorG.getBlob(iN8));
                    p144p1.j jVar = new p144p1.j(string, string2);
                    jVar.f22208b = p001a.a.A(cursorG.getInt(iN10));
                    jVar.f22210d = cursorG.getString(iN12);
                    jVar.f22211e = p060g1.h.a(cursorG.getBlob(iN13));
                    int i14 = i9;
                    jVar.f22212f = p060g1.h.a(cursorG.getBlob(i14));
                    int i15 = iN12;
                    i9 = i14;
                    int i16 = iN15;
                    jVar.f22213g = cursorG.getLong(i16);
                    iN15 = i16;
                    int i17 = iN3;
                    int i18 = iN16;
                    jVar.f22214h = cursorG.getLong(i18);
                    iN16 = i18;
                    int i19 = iN17;
                    jVar.f22215i = cursorG.getLong(i19);
                    int i20 = iN18;
                    jVar.f22216k = cursorG.getInt(i20);
                    int i21 = iN19;
                    iN18 = i20;
                    jVar.f22217l = p001a.a.x(cursorG.getInt(i21));
                    iN17 = i19;
                    int i22 = iN20;
                    jVar.f22218m = cursorG.getLong(i22);
                    iN20 = i22;
                    int i23 = iN21;
                    jVar.f22219n = cursorG.getLong(i23);
                    iN21 = i23;
                    int i24 = iN22;
                    jVar.f22220o = cursorG.getLong(i24);
                    iN22 = i24;
                    int i25 = iN23;
                    jVar.f22221p = cursorG.getLong(i25);
                    int i26 = iN24;
                    jVar.f22222q = cursorG.getInt(i26) != 0;
                    int i27 = iN25;
                    iN24 = i26;
                    jVar.f22223r = p001a.a.z(cursorG.getInt(i27));
                    jVar.j = cVar;
                    arrayList.add(jVar);
                    iN19 = i21;
                    iN3 = i17;
                    iN25 = i27;
                    iN23 = i25;
                    iN12 = i15;
                    iN9 = i10;
                    iN11 = i11;
                    iN2 = i13;
                    iN = i12;
                }
                cursorG.close();
                b10.k();
                return arrayList;
            } catch (Throwable th) {
                th = th;
                cursorG.close();
                b10.k();
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            b10 = bF;
        }
    }

    public c e(int i9) throws Throwable {
        c cVar = null;
        try {
            if (!p183u.e.a(2, i9)) {
                JSONObject jSONObjectX = ((V5.c) this.f37e).x();
                if (jSONObjectX != null) {
                    c cVarV = ((g) this.f35c).V(jSONObjectX);
                    n(jSONObjectX, "Loaded cached settings: ");
                    ((p033d2.b) this.f36d).getClass();
                    long jCurrentTimeMillis = System.currentTimeMillis();
                    if (p183u.e.a(3, i9) || cVarV.f24c >= jCurrentTimeMillis) {
                        try {
                            if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                                Log.v("FirebaseCrashlytics", "Returning cached settings.", null);
                            }
                            return cVarV;
                        } catch (Exception e9) {
                            e = e9;
                            cVar = cVarV;
                            Log.e("FirebaseCrashlytics", "Failed to get cached settings", e);
                            return cVar;
                        }
                    }
                    if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", "Cached settings have expired.", null);
                        return null;
                    }
                } else if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                    Log.d("FirebaseCrashlytics", "No cached settings data found.", null);
                }
            }
            return null;
        } catch (Exception e10) {
            e = e10;
        }
    }

    public ArrayList f(int i9) throws Throwable {
        B b10;
        B bF = B.f(1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY period_start_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND state NOT IN (2, 3, 5))");
        bF.d(i9, 1);
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        Cursor cursorG = p054f5.b.G(workDatabase_Impl, bF, false);
        try {
            int iN = AbstractC0734e2.n(cursorG, "required_network_type");
            int iN2 = AbstractC0734e2.n(cursorG, "requires_charging");
            int iN3 = AbstractC0734e2.n(cursorG, "requires_device_idle");
            int iN4 = AbstractC0734e2.n(cursorG, "requires_battery_not_low");
            int iN5 = AbstractC0734e2.n(cursorG, "requires_storage_not_low");
            int iN6 = AbstractC0734e2.n(cursorG, "trigger_content_update_delay");
            int iN7 = AbstractC0734e2.n(cursorG, "trigger_max_content_delay");
            int iN8 = AbstractC0734e2.n(cursorG, "content_uri_triggers");
            int iN9 = AbstractC0734e2.n(cursorG, "id");
            int iN10 = AbstractC0734e2.n(cursorG, "state");
            int iN11 = AbstractC0734e2.n(cursorG, "worker_class_name");
            int iN12 = AbstractC0734e2.n(cursorG, "input_merger_class_name");
            int iN13 = AbstractC0734e2.n(cursorG, "input");
            b10 = bF;
            try {
                int iN14 = AbstractC0734e2.n(cursorG, "output");
                int iN15 = AbstractC0734e2.n(cursorG, "initial_delay");
                int iN16 = AbstractC0734e2.n(cursorG, "interval_duration");
                int iN17 = AbstractC0734e2.n(cursorG, "flex_duration");
                int iN18 = AbstractC0734e2.n(cursorG, "run_attempt_count");
                int iN19 = AbstractC0734e2.n(cursorG, "backoff_policy");
                int iN20 = AbstractC0734e2.n(cursorG, "backoff_delay_duration");
                int iN21 = AbstractC0734e2.n(cursorG, "period_start_time");
                int iN22 = AbstractC0734e2.n(cursorG, "minimum_retention_duration");
                int iN23 = AbstractC0734e2.n(cursorG, "schedule_requested_at");
                int iN24 = AbstractC0734e2.n(cursorG, "run_in_foreground");
                int iN25 = AbstractC0734e2.n(cursorG, "out_of_quota_policy");
                int i10 = iN14;
                ArrayList arrayList = new ArrayList(cursorG.getCount());
                while (cursorG.moveToNext()) {
                    String string = cursorG.getString(iN9);
                    int i11 = iN9;
                    String string2 = cursorG.getString(iN11);
                    int i12 = iN11;
                    p060g1.c cVar = new p060g1.c();
                    int i13 = iN;
                    cVar.f18098a = p001a.a.y(cursorG.getInt(iN));
                    cVar.f18099b = cursorG.getInt(iN2) != 0;
                    cVar.f18100c = cursorG.getInt(iN3) != 0;
                    cVar.f18101d = cursorG.getInt(iN4) != 0;
                    cVar.f18102e = cursorG.getInt(iN5) != 0;
                    int i14 = iN2;
                    cVar.f18103f = cursorG.getLong(iN6);
                    cVar.f18104g = cursorG.getLong(iN7);
                    cVar.f18105h = p001a.a.b(cursorG.getBlob(iN8));
                    p144p1.j jVar = new p144p1.j(string, string2);
                    jVar.f22208b = p001a.a.A(cursorG.getInt(iN10));
                    jVar.f22210d = cursorG.getString(iN12);
                    jVar.f22211e = p060g1.h.a(cursorG.getBlob(iN13));
                    int i15 = i10;
                    jVar.f22212f = p060g1.h.a(cursorG.getBlob(i15));
                    int i16 = iN12;
                    i10 = i15;
                    int i17 = iN15;
                    jVar.f22213g = cursorG.getLong(i17);
                    iN15 = i17;
                    int i18 = iN3;
                    int i19 = iN16;
                    jVar.f22214h = cursorG.getLong(i19);
                    iN16 = i19;
                    int i20 = iN17;
                    jVar.f22215i = cursorG.getLong(i20);
                    int i21 = iN18;
                    jVar.f22216k = cursorG.getInt(i21);
                    int i22 = iN19;
                    iN18 = i21;
                    jVar.f22217l = p001a.a.x(cursorG.getInt(i22));
                    iN17 = i20;
                    int i23 = iN20;
                    jVar.f22218m = cursorG.getLong(i23);
                    iN20 = i23;
                    int i24 = iN21;
                    jVar.f22219n = cursorG.getLong(i24);
                    iN21 = i24;
                    int i25 = iN22;
                    jVar.f22220o = cursorG.getLong(i25);
                    iN22 = i25;
                    int i26 = iN23;
                    jVar.f22221p = cursorG.getLong(i26);
                    int i27 = iN24;
                    jVar.f22222q = cursorG.getInt(i27) != 0;
                    int i28 = iN25;
                    iN24 = i27;
                    jVar.f22223r = p001a.a.z(cursorG.getInt(i28));
                    jVar.j = cVar;
                    arrayList.add(jVar);
                    iN19 = i22;
                    iN3 = i18;
                    iN25 = i28;
                    iN23 = i26;
                    iN12 = i16;
                    iN9 = i11;
                    iN11 = i12;
                    iN2 = i14;
                    iN = i13;
                }
                cursorG.close();
                b10.k();
                return arrayList;
            } catch (Throwable th) {
                th = th;
                cursorG.close();
                b10.k();
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            b10 = bF;
        }
    }

    public ArrayList g() throws Throwable {
        B b10;
        B bF = B.f(0, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=1");
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        Cursor cursorG = p054f5.b.G(workDatabase_Impl, bF, false);
        try {
            int iN = AbstractC0734e2.n(cursorG, "required_network_type");
            int iN2 = AbstractC0734e2.n(cursorG, "requires_charging");
            int iN3 = AbstractC0734e2.n(cursorG, "requires_device_idle");
            int iN4 = AbstractC0734e2.n(cursorG, "requires_battery_not_low");
            int iN5 = AbstractC0734e2.n(cursorG, "requires_storage_not_low");
            int iN6 = AbstractC0734e2.n(cursorG, "trigger_content_update_delay");
            int iN7 = AbstractC0734e2.n(cursorG, "trigger_max_content_delay");
            int iN8 = AbstractC0734e2.n(cursorG, "content_uri_triggers");
            int iN9 = AbstractC0734e2.n(cursorG, "id");
            int iN10 = AbstractC0734e2.n(cursorG, "state");
            int iN11 = AbstractC0734e2.n(cursorG, "worker_class_name");
            int iN12 = AbstractC0734e2.n(cursorG, "input_merger_class_name");
            int iN13 = AbstractC0734e2.n(cursorG, "input");
            b10 = bF;
            try {
                int iN14 = AbstractC0734e2.n(cursorG, "output");
                int iN15 = AbstractC0734e2.n(cursorG, "initial_delay");
                int iN16 = AbstractC0734e2.n(cursorG, "interval_duration");
                int iN17 = AbstractC0734e2.n(cursorG, "flex_duration");
                int iN18 = AbstractC0734e2.n(cursorG, "run_attempt_count");
                int iN19 = AbstractC0734e2.n(cursorG, "backoff_policy");
                int iN20 = AbstractC0734e2.n(cursorG, "backoff_delay_duration");
                int iN21 = AbstractC0734e2.n(cursorG, "period_start_time");
                int iN22 = AbstractC0734e2.n(cursorG, "minimum_retention_duration");
                int iN23 = AbstractC0734e2.n(cursorG, "schedule_requested_at");
                int iN24 = AbstractC0734e2.n(cursorG, "run_in_foreground");
                int iN25 = AbstractC0734e2.n(cursorG, "out_of_quota_policy");
                int i9 = iN14;
                ArrayList arrayList = new ArrayList(cursorG.getCount());
                while (cursorG.moveToNext()) {
                    String string = cursorG.getString(iN9);
                    int i10 = iN9;
                    String string2 = cursorG.getString(iN11);
                    int i11 = iN11;
                    p060g1.c cVar = new p060g1.c();
                    int i12 = iN;
                    cVar.f18098a = p001a.a.y(cursorG.getInt(iN));
                    cVar.f18099b = cursorG.getInt(iN2) != 0;
                    cVar.f18100c = cursorG.getInt(iN3) != 0;
                    cVar.f18101d = cursorG.getInt(iN4) != 0;
                    cVar.f18102e = cursorG.getInt(iN5) != 0;
                    int i13 = iN2;
                    cVar.f18103f = cursorG.getLong(iN6);
                    cVar.f18104g = cursorG.getLong(iN7);
                    cVar.f18105h = p001a.a.b(cursorG.getBlob(iN8));
                    p144p1.j jVar = new p144p1.j(string, string2);
                    jVar.f22208b = p001a.a.A(cursorG.getInt(iN10));
                    jVar.f22210d = cursorG.getString(iN12);
                    jVar.f22211e = p060g1.h.a(cursorG.getBlob(iN13));
                    int i14 = i9;
                    jVar.f22212f = p060g1.h.a(cursorG.getBlob(i14));
                    int i15 = iN13;
                    i9 = i14;
                    int i16 = iN15;
                    jVar.f22213g = cursorG.getLong(i16);
                    iN15 = i16;
                    int i17 = iN3;
                    int i18 = iN16;
                    jVar.f22214h = cursorG.getLong(i18);
                    iN16 = i18;
                    int i19 = iN17;
                    jVar.f22215i = cursorG.getLong(i19);
                    int i20 = iN18;
                    jVar.f22216k = cursorG.getInt(i20);
                    int i21 = iN19;
                    iN18 = i20;
                    jVar.f22217l = p001a.a.x(cursorG.getInt(i21));
                    iN17 = i19;
                    int i22 = iN20;
                    jVar.f22218m = cursorG.getLong(i22);
                    iN20 = i22;
                    int i23 = iN21;
                    jVar.f22219n = cursorG.getLong(i23);
                    iN21 = i23;
                    int i24 = iN22;
                    jVar.f22220o = cursorG.getLong(i24);
                    iN22 = i24;
                    int i25 = iN23;
                    jVar.f22221p = cursorG.getLong(i25);
                    int i26 = iN24;
                    jVar.f22222q = cursorG.getInt(i26) != 0;
                    int i27 = iN25;
                    iN24 = i26;
                    jVar.f22223r = p001a.a.z(cursorG.getInt(i27));
                    jVar.j = cVar;
                    arrayList.add(jVar);
                    iN19 = i21;
                    iN3 = i17;
                    iN25 = i27;
                    iN23 = i25;
                    iN13 = i15;
                    iN9 = i10;
                    iN11 = i11;
                    iN = i12;
                    iN2 = i13;
                }
                cursorG.close();
                b10.k();
                return arrayList;
            } catch (Throwable th) {
                th = th;
                cursorG.close();
                b10.k();
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            b10 = bF;
        }
    }

    public ArrayList h() {
        B b10;
        B bF = B.f(0, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at<>-1");
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        Cursor cursorG = p054f5.b.G(workDatabase_Impl, bF, false);
        try {
            int iN = AbstractC0734e2.n(cursorG, "required_network_type");
            int iN2 = AbstractC0734e2.n(cursorG, "requires_charging");
            int iN3 = AbstractC0734e2.n(cursorG, "requires_device_idle");
            int iN4 = AbstractC0734e2.n(cursorG, "requires_battery_not_low");
            int iN5 = AbstractC0734e2.n(cursorG, "requires_storage_not_low");
            int iN6 = AbstractC0734e2.n(cursorG, "trigger_content_update_delay");
            int iN7 = AbstractC0734e2.n(cursorG, "trigger_max_content_delay");
            int iN8 = AbstractC0734e2.n(cursorG, "content_uri_triggers");
            int iN9 = AbstractC0734e2.n(cursorG, "id");
            int iN10 = AbstractC0734e2.n(cursorG, "state");
            int iN11 = AbstractC0734e2.n(cursorG, "worker_class_name");
            int iN12 = AbstractC0734e2.n(cursorG, "input_merger_class_name");
            int iN13 = AbstractC0734e2.n(cursorG, "input");
            b10 = bF;
            try {
                int iN14 = AbstractC0734e2.n(cursorG, "output");
                int iN15 = AbstractC0734e2.n(cursorG, "initial_delay");
                int iN16 = AbstractC0734e2.n(cursorG, "interval_duration");
                int iN17 = AbstractC0734e2.n(cursorG, "flex_duration");
                int iN18 = AbstractC0734e2.n(cursorG, "run_attempt_count");
                int iN19 = AbstractC0734e2.n(cursorG, "backoff_policy");
                int iN20 = AbstractC0734e2.n(cursorG, "backoff_delay_duration");
                int iN21 = AbstractC0734e2.n(cursorG, "period_start_time");
                int iN22 = AbstractC0734e2.n(cursorG, "minimum_retention_duration");
                int iN23 = AbstractC0734e2.n(cursorG, "schedule_requested_at");
                int iN24 = AbstractC0734e2.n(cursorG, "run_in_foreground");
                int iN25 = AbstractC0734e2.n(cursorG, "out_of_quota_policy");
                int i9 = iN14;
                ArrayList arrayList = new ArrayList(cursorG.getCount());
                while (cursorG.moveToNext()) {
                    String string = cursorG.getString(iN9);
                    int i10 = iN9;
                    String string2 = cursorG.getString(iN11);
                    int i11 = iN11;
                    p060g1.c cVar = new p060g1.c();
                    int i12 = iN;
                    cVar.f18098a = p001a.a.y(cursorG.getInt(iN));
                    cVar.f18099b = cursorG.getInt(iN2) != 0;
                    cVar.f18100c = cursorG.getInt(iN3) != 0;
                    cVar.f18101d = cursorG.getInt(iN4) != 0;
                    cVar.f18102e = cursorG.getInt(iN5) != 0;
                    int i13 = iN2;
                    cVar.f18103f = cursorG.getLong(iN6);
                    cVar.f18104g = cursorG.getLong(iN7);
                    cVar.f18105h = p001a.a.b(cursorG.getBlob(iN8));
                    p144p1.j jVar = new p144p1.j(string, string2);
                    jVar.f22208b = p001a.a.A(cursorG.getInt(iN10));
                    jVar.f22210d = cursorG.getString(iN12);
                    jVar.f22211e = p060g1.h.a(cursorG.getBlob(iN13));
                    int i14 = i9;
                    jVar.f22212f = p060g1.h.a(cursorG.getBlob(i14));
                    int i15 = iN13;
                    i9 = i14;
                    int i16 = iN15;
                    jVar.f22213g = cursorG.getLong(i16);
                    iN15 = i16;
                    int i17 = iN3;
                    int i18 = iN16;
                    jVar.f22214h = cursorG.getLong(i18);
                    iN16 = i18;
                    int i19 = iN17;
                    jVar.f22215i = cursorG.getLong(i19);
                    int i20 = iN18;
                    jVar.f22216k = cursorG.getInt(i20);
                    int i21 = iN19;
                    iN18 = i20;
                    jVar.f22217l = p001a.a.x(cursorG.getInt(i21));
                    iN17 = i19;
                    int i22 = iN20;
                    jVar.f22218m = cursorG.getLong(i22);
                    iN20 = i22;
                    int i23 = iN21;
                    jVar.f22219n = cursorG.getLong(i23);
                    iN21 = i23;
                    int i24 = iN22;
                    jVar.f22220o = cursorG.getLong(i24);
                    iN22 = i24;
                    int i25 = iN23;
                    jVar.f22221p = cursorG.getLong(i25);
                    int i26 = iN24;
                    jVar.f22222q = cursorG.getInt(i26) != 0;
                    int i27 = iN25;
                    iN24 = i26;
                    jVar.f22223r = p001a.a.z(cursorG.getInt(i27));
                    jVar.j = cVar;
                    arrayList.add(jVar);
                    iN19 = i21;
                    iN3 = i17;
                    iN25 = i27;
                    iN23 = i25;
                    iN13 = i15;
                    iN9 = i10;
                    iN11 = i11;
                    iN = i12;
                    iN2 = i13;
                }
                cursorG.close();
                b10.k();
                return arrayList;
            } catch (Throwable th) {
                th = th;
                cursorG.close();
                b10.k();
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            b10 = bF;
        }
    }

    public c i() {
        return (c) ((AtomicReference) this.f40h).get();
    }

    public int j(String str) throws IOException {
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        B bF = B.f(1, "SELECT state FROM workspec WHERE id=?");
        if (str == null) {
            bF.b(1);
        } else {
            bF.p(1, str);
        }
        workDatabase_Impl.b();
        Cursor cursorG = p054f5.b.G(workDatabase_Impl, bF, false);
        try {
            return cursorG.moveToFirst() ? p001a.a.A(cursorG.getInt(0)) : 0;
        } finally {
            cursorG.close();
            bF.k();
        }
    }

    public ArrayList k(String str) throws IOException {
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        B bF = B.f(1, "SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)");
        if (str == null) {
            bF.b(1);
        } else {
            bF.p(1, str);
        }
        workDatabase_Impl.b();
        Cursor cursorG = p054f5.b.G(workDatabase_Impl, bF, false);
        try {
            ArrayList arrayList = new ArrayList(cursorG.getCount());
            while (cursorG.moveToNext()) {
                arrayList.add(cursorG.getString(0));
            }
            cursorG.close();
            bF.k();
            return arrayList;
        } catch (Throwable th) {
            cursorG.close();
            bF.k();
            throw th;
        }
    }

    public p144p1.j l(String str) throws Throwable {
        B b10;
        p144p1.j jVar;
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        B bF = B.f(1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE id=?");
        if (str == null) {
            bF.b(1);
        } else {
            bF.p(1, str);
        }
        workDatabase_Impl.b();
        Cursor cursorG = p054f5.b.G(workDatabase_Impl, bF, false);
        try {
            int iN = AbstractC0734e2.n(cursorG, "required_network_type");
            int iN2 = AbstractC0734e2.n(cursorG, "requires_charging");
            int iN3 = AbstractC0734e2.n(cursorG, "requires_device_idle");
            int iN4 = AbstractC0734e2.n(cursorG, "requires_battery_not_low");
            int iN5 = AbstractC0734e2.n(cursorG, "requires_storage_not_low");
            int iN6 = AbstractC0734e2.n(cursorG, "trigger_content_update_delay");
            int iN7 = AbstractC0734e2.n(cursorG, "trigger_max_content_delay");
            int iN8 = AbstractC0734e2.n(cursorG, "content_uri_triggers");
            int iN9 = AbstractC0734e2.n(cursorG, "id");
            int iN10 = AbstractC0734e2.n(cursorG, "state");
            int iN11 = AbstractC0734e2.n(cursorG, "worker_class_name");
            int iN12 = AbstractC0734e2.n(cursorG, "input_merger_class_name");
            int iN13 = AbstractC0734e2.n(cursorG, "input");
            int iN14 = AbstractC0734e2.n(cursorG, "output");
            b10 = bF;
            try {
                int iN15 = AbstractC0734e2.n(cursorG, "initial_delay");
                int iN16 = AbstractC0734e2.n(cursorG, "interval_duration");
                int iN17 = AbstractC0734e2.n(cursorG, "flex_duration");
                int iN18 = AbstractC0734e2.n(cursorG, "run_attempt_count");
                int iN19 = AbstractC0734e2.n(cursorG, "backoff_policy");
                int iN20 = AbstractC0734e2.n(cursorG, "backoff_delay_duration");
                int iN21 = AbstractC0734e2.n(cursorG, "period_start_time");
                int iN22 = AbstractC0734e2.n(cursorG, "minimum_retention_duration");
                int iN23 = AbstractC0734e2.n(cursorG, "schedule_requested_at");
                int iN24 = AbstractC0734e2.n(cursorG, "run_in_foreground");
                int iN25 = AbstractC0734e2.n(cursorG, "out_of_quota_policy");
                if (cursorG.moveToFirst()) {
                    String string = cursorG.getString(iN9);
                    String string2 = cursorG.getString(iN11);
                    p060g1.c cVar = new p060g1.c();
                    cVar.f18098a = p001a.a.y(cursorG.getInt(iN));
                    cVar.f18099b = cursorG.getInt(iN2) != 0;
                    cVar.f18100c = cursorG.getInt(iN3) != 0;
                    cVar.f18101d = cursorG.getInt(iN4) != 0;
                    cVar.f18102e = cursorG.getInt(iN5) != 0;
                    cVar.f18103f = cursorG.getLong(iN6);
                    cVar.f18104g = cursorG.getLong(iN7);
                    cVar.f18105h = p001a.a.b(cursorG.getBlob(iN8));
                    jVar = new p144p1.j(string, string2);
                    jVar.f22208b = p001a.a.A(cursorG.getInt(iN10));
                    jVar.f22210d = cursorG.getString(iN12);
                    jVar.f22211e = p060g1.h.a(cursorG.getBlob(iN13));
                    jVar.f22212f = p060g1.h.a(cursorG.getBlob(iN14));
                    jVar.f22213g = cursorG.getLong(iN15);
                    jVar.f22214h = cursorG.getLong(iN16);
                    jVar.f22215i = cursorG.getLong(iN17);
                    jVar.f22216k = cursorG.getInt(iN18);
                    jVar.f22217l = p001a.a.x(cursorG.getInt(iN19));
                    jVar.f22218m = cursorG.getLong(iN20);
                    jVar.f22219n = cursorG.getLong(iN21);
                    jVar.f22220o = cursorG.getLong(iN22);
                    jVar.f22221p = cursorG.getLong(iN23);
                    jVar.f22222q = cursorG.getInt(iN24) != 0;
                    jVar.f22223r = p001a.a.z(cursorG.getInt(iN25));
                    jVar.j = cVar;
                } else {
                    jVar = null;
                }
                cursorG.close();
                b10.k();
                return jVar;
            } catch (Throwable th) {
                th = th;
                cursorG.close();
                b10.k();
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            b10 = bF;
        }
    }

    public ArrayList m(String str) throws IOException {
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        B bF = B.f(1, "SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)");
        if (str == null) {
            bF.b(1);
        } else {
            bF.p(1, str);
        }
        workDatabase_Impl.b();
        Cursor cursorG = p054f5.b.G(workDatabase_Impl, bF, false);
        try {
            int iN = AbstractC0734e2.n(cursorG, "id");
            int iN2 = AbstractC0734e2.n(cursorG, "state");
            ArrayList arrayList = new ArrayList(cursorG.getCount());
            while (cursorG.moveToNext()) {
                p144p1.h hVar = new p144p1.h();
                hVar.f22197a = cursorG.getString(iN);
                hVar.f22198b = p001a.a.A(cursorG.getInt(iN2));
                arrayList.add(hVar);
            }
            cursorG.close();
            bF.k();
            return arrayList;
        } catch (Throwable th) {
            cursorG.close();
            bF.k();
            throw th;
        }
    }

    public void o(long j, String str) {
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        p144p1.e eVar = (p144p1.e) this.f40h;
        j jVarA = eVar.a();
        jVarA.d(j, 1);
        if (str == null) {
            jVarA.b(2);
        } else {
            jVarA.p(2, str);
        }
        workDatabase_Impl.c();
        try {
            jVarA.a();
            workDatabase_Impl.q();
        } finally {
            workDatabase_Impl.n();
            eVar.i(jVarA);
        }
    }

    public void p(String str, p060g1.h hVar) throws Throwable {
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        p144p1.e eVar = (p144p1.e) this.f36d;
        j jVarA = eVar.a();
        byte[] bArrB = p060g1.h.b(hVar);
        if (bArrB == null) {
            jVarA.b(1);
        } else {
            jVarA.U(1, bArrB);
        }
        if (str == null) {
            jVarA.b(2);
        } else {
            jVarA.p(2, str);
        }
        workDatabase_Impl.c();
        try {
            jVarA.a();
            workDatabase_Impl.q();
        } finally {
            workDatabase_Impl.n();
            eVar.i(jVarA);
        }
    }

    public void q(long j, String str) {
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        p144p1.e eVar = (p144p1.e) this.f37e;
        j jVarA = eVar.a();
        jVarA.d(j, 1);
        if (str == null) {
            jVarA.b(2);
        } else {
            jVarA.p(2, str);
        }
        workDatabase_Impl.c();
        try {
            jVarA.a();
            workDatabase_Impl.q();
        } finally {
            workDatabase_Impl.n();
            eVar.i(jVarA);
        }
    }

    public void r(int i9, String... strArr) {
        WorkDatabase_Impl workDatabase_Impl = (WorkDatabase_Impl) this.f33a;
        workDatabase_Impl.b();
        StringBuilder sb = new StringBuilder();
        sb.append("UPDATE workspec SET state=? WHERE id IN (");
        K3.h.a(strArr.length, sb);
        sb.append(")");
        String sql = sb.toString();
        kotlin.jvm.internal.h.e(sql, "sql");
        workDatabase_Impl.a();
        workDatabase_Impl.b();
        j jVarV = workDatabase_Impl.i().a0().v(sql);
        jVarV.d(p001a.a.J(i9), 1);
        int i10 = 2;
        for (String str : strArr) {
            if (str == null) {
                jVarV.b(i10);
            } else {
                jVarV.p(i10, str);
            }
            i10++;
        }
        workDatabase_Impl.c();
        try {
            jVarV.a();
            workDatabase_Impl.q();
        } finally {
            workDatabase_Impl.n();
        }
    }
}
