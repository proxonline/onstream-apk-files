package A5;

import W5.o;
import X5.p;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.Callable;
import org.json.JSONException;
import org.json.JSONObject;
import p174s5.m;
import p174s5.s;
import p200w0.C1373h;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements Callable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f28a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f29b;

    public /* synthetic */ d(int i9, Object obj) {
        this.f28a = i9;
        this.f29b = obj;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        X5.f fVarA;
        FileInputStream fileInputStreamOpenFileInput;
        Throwable th;
        switch (this.f28a) {
            case 0:
                f fVar = (f) ((e) this.f29b).f32c;
                a aVar = (a) fVar.f38f;
                i iVar = (i) fVar.f34b;
                String str = aVar.f18a;
                t5.d.b();
                try {
                    HashMap mapB = a.b(iVar);
                    C1373h c1373h = new C1373h(str, mapB);
                    c1373h.t("User-Agent", "Crashlytics Android SDK/19.4.4");
                    c1373h.t("X-CRASHLYTICS-DEVELOPER-TOKEN", "470fa2b4ae81cd56ecbcda9735803434cec591fa");
                    a.a(c1373h, iVar);
                    String str2 = "Requesting settings from " + str;
                    if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                        Log.d("FirebaseCrashlytics", str2, null);
                    }
                    String str3 = "Settings query params were: " + mapB;
                    if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", str3, null);
                    }
                    return aVar.c(c1373h.s());
                } catch (IOException e9) {
                    Log.e("FirebaseCrashlytics", "Settings request failed.", e9);
                    return null;
                }
            case 1:
                return ((o) this.f29b).a();
            case 2:
                p pVar = (p) this.f29b;
                synchronized (pVar) {
                    fVarA = null;
                    try {
                        try {
                            fileInputStreamOpenFileInput = pVar.f9051a.openFileInput(pVar.f9052b);
                            try {
                                int iAvailable = fileInputStreamOpenFileInput.available();
                                byte[] bArr = new byte[iAvailable];
                                fileInputStreamOpenFileInput.read(bArr, 0, iAvailable);
                                fVarA = X5.f.a(new JSONObject(new String(bArr, "UTF-8")));
                                fileInputStreamOpenFileInput.close();
                            } catch (FileNotFoundException | JSONException unused) {
                                if (fileInputStreamOpenFileInput != null) {
                                    fileInputStreamOpenFileInput.close();
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                if (fileInputStreamOpenFileInput != null) {
                                    fileInputStreamOpenFileInput.close();
                                }
                                throw th;
                            }
                        } catch (Throwable th3) {
                            throw th3;
                        }
                    } catch (FileNotFoundException | JSONException unused2) {
                        fileInputStreamOpenFileInput = null;
                    } catch (Throwable th4) {
                        fileInputStreamOpenFileInput = null;
                        th = th4;
                    }
                }
                return fVarA;
            default:
                p174s5.o oVar = ((s) this.f29b).f23149g;
                oVar.getClass();
                t5.d.a();
                m mVar = oVar.f23121c;
                p218y5.c cVar = (p218y5.c) mVar.f23114c;
                String str4 = (String) mVar.f23113b;
                cVar.getClass();
                boolean z9 = true;
                if (new File((File) cVar.f25983c, str4).exists()) {
                    if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", "Found previous crash marker.", null);
                    }
                    p218y5.c cVar2 = (p218y5.c) mVar.f23114c;
                    cVar2.getClass();
                    new File((File) cVar2.f25983c, str4).delete();
                } else {
                    String strE = oVar.e();
                    if (strE == null || !oVar.j.c(strE)) {
                        z9 = false;
                    }
                }
                return Boolean.valueOf(z9);
        }
    }
}
