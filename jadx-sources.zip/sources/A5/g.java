package A5;

import B3.C0012m;
import G0.C0122f0;
import G0.E0;
import G0.K;
import G0.L;
import J2.C0206q;
import J2.g0;
import N2.u;
import P.C0328v;
import P.C0330x;
import P.InterfaceC0313f;
import P.InterfaceC0323p;
import P.x0;
import P7.x;
import X3.C0366d0;
import X3.C0396n0;
import X3.D0;
import X3.EnumC0377h;
import X3.EnumC0423z0;
import X3.P0;
import X3.U;
import X3.s1;
import a9.C0490i;
import a9.C0496o;
import a9.InterfaceC0485d;
import a9.InterfaceC0487f;
import a9.InterfaceC0488g;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ContentProviderClient;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContentInfo;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import com.google.android.gms.internal.measurement.AbstractC0734e2;
import com.maertsno.data.model.preference.GeneralPreference;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.jvm.internal.p;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import p052f2.j0;
import p062g3.B;
import p062g3.C0953n;
import p062g3.C0954o;
import p062g3.H;
import p062g3.I;
import p062g3.M;
import p062g3.N;
import p062g3.P;
import p062g3.Q;
import p071h3.y;
import p182t6.e0;
import p182t6.s0;
import p195v5.u0;
import p219y6.o;
import p225z3.l;

/* JADX INFO: loaded from: classes.dex */
public final class g implements l, InterfaceC0323p, L, E0, g0, K1.h, M.a, M1.e, I, InterfaceC0313f, P, U2.f, InterfaceC0488g, InterfaceC0487f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f42a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f43b;

    public g(int i9) {
        this.f42a = i9;
        switch (i9) {
            case 20:
                try {
                    this.f43b = XmlPullParserFactory.newInstance();
                    return;
                } catch (XmlPullParserException e9) {
                    throw new RuntimeException("Couldn't create XmlPullParserFactory instance", e9);
                }
            case 22:
                this.f43b = new EnumMap(EnumC0423z0.class);
                return;
            case 26:
                this.f43b = new AtomicInteger(0);
                return;
            default:
                this.f43b = new SparseArray();
                return;
        }
    }

    public /* synthetic */ g(int i9, Object obj) {
        this.f42a = i9;
        this.f43b = obj;
    }

    public g(D0 d9, C0396n0 c0396n0) {
        this.f42a = 24;
        this.f43b = c0396n0;
    }

    public g(Context context, Uri uri) {
        this.f42a = 12;
        this.f43b = context.getContentResolver().acquireUnstableContentProviderClient(uri);
    }

    public g(ContentInfo contentInfo) {
        this.f42a = 16;
        contentInfo.getClass();
        this.f43b = G3.g.o(contentInfo);
    }

    public g(View view) {
        this.f42a = 17;
        if (Build.VERSION.SDK_INT < 30) {
            this.f43b = new C0328v(view);
            return;
        }
        C0330x c0330x = new C0330x(view);
        c0330x.f5940b = view;
        this.f43b = c0330x;
    }

    public g(EnumMap enumMap) {
        this.f42a = 22;
        EnumMap enumMap2 = new EnumMap(EnumC0423z0.class);
        this.f43b = enumMap2;
        enumMap2.putAll(enumMap);
    }

    public g(p130n6.d encryptedPreference) {
        this.f42a = 2;
        kotlin.jvm.internal.h.e(encryptedPreference, "encryptedPreference");
        this.f43b = encryptedPreference;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public g(p167r8.l lVar) {
        this.f42a = 27;
        this.f43b = (kotlin.jvm.internal.i) lVar;
    }

    public g(s0 userRepository) {
        this.f42a = 5;
        kotlin.jvm.internal.h.e(userRepository, "userRepository");
        this.f43b = userRepository;
    }

    public static g U(int i9, int i10, int i11) {
        return new g(18, AccessibilityNodeInfo.CollectionInfo.obtain(i9, i10, false, i11));
    }

    @Override // G0.E0
    public View A(int i9) {
        return ((androidx.recyclerview.widget.a) this.f43b).v(i9);
    }

    @Override // G0.L
    public void B(int i9, int i10) {
        ((K) this.f43b).f1961a.d(i9, i10, null);
    }

    @Override // G0.L
    public void C(int i9, int i10) {
        ((K) this.f43b).f1961a.e(i9, i10);
    }

    @Override // J2.g0
    public long D() {
        long jMin = Long.MAX_VALUE;
        for (g0 g0Var : (g0[]) this.f43b) {
            long jD = g0Var.D();
            if (jD != Long.MIN_VALUE) {
                jMin = Math.min(jMin, jD);
            }
        }
        if (jMin == Long.MAX_VALUE) {
            return Long.MIN_VALUE;
        }
        return jMin;
    }

    @Override // p062g3.I
    public H E(p062g3.K k9, IOException iOException, int i9) {
        long jMin;
        Q q6 = (Q) k9;
        M2.h hVar = (M2.h) this.f43b;
        long j = q6.f18243a;
        Uri uri = q6.f18246d.f18269c;
        C0206q c0206q = new C0206q();
        int i10 = q6.f18245c;
        hVar.f4694n.getClass();
        if (!(iOException instanceof j0) && !(iOException instanceof FileNotFoundException) && !(iOException instanceof B) && !(iOException instanceof M)) {
            int i11 = C0953n.f18305b;
            Throwable cause = iOException;
            while (true) {
                if (cause == null) {
                    jMin = Math.min((i9 - 1) * 1000, 5000);
                    break;
                }
                if ((cause instanceof C0953n) && ((C0953n) cause).f18306a == 2008) {
                    jMin = -9223372036854775807L;
                    break;
                }
                cause = cause.getCause();
            }
        } else {
            jMin = -9223372036854775807L;
            break;
        }
        H h6 = jMin == -9223372036854775807L ? N.f18239f : new H(0, jMin, false);
        hVar.f4697q.j(c0206q, i10, iOException, !h6.a());
        return h6;
    }

    @Override // p062g3.I
    public void F(p062g3.K k9, long j, long j9) {
        Q q6 = (Q) k9;
        M2.h hVar = (M2.h) this.f43b;
        long j10 = q6.f18243a;
        Uri uri = q6.f18246d.f18269c;
        C0206q c0206q = new C0206q();
        hVar.f4694n.getClass();
        hVar.f4697q.f(c0206q, q6.f18245c);
        N2.c cVar = (N2.c) q6.f18248f;
        N2.c cVar2 = hVar.f4681d0;
        int size = cVar2 == null ? 0 : cVar2.f4905m.size();
        long j11 = cVar.b(0).f4925b;
        int i9 = 0;
        while (i9 < size && hVar.f4681d0.b(i9).f4925b < j11) {
            i9++;
        }
        if (cVar.f4897d) {
            if (size - i9 > cVar.f4905m.size()) {
                p071h3.a.P("DashMediaSource", "Loaded out of sync manifest");
            } else {
                long j12 = hVar.f4689j0;
                if (j12 == -9223372036854775807L || cVar.f4901h * 1000 > j12) {
                    hVar.f4688i0 = 0;
                } else {
                    p071h3.a.P("DashMediaSource", "Loaded stale dynamic manifest: " + cVar.f4901h + ", " + hVar.f4689j0);
                }
            }
            int i10 = hVar.f4688i0;
            hVar.f4688i0 = i10 + 1;
            if (i10 < hVar.f4694n.e(q6.f18245c)) {
                hVar.f4679D.postDelayed(hVar.f4702v, Math.min((hVar.f4688i0 - 1) * 1000, 5000));
                return;
            } else {
                hVar.f4678C = new J2.N();
                return;
            }
        }
        hVar.f4681d0 = cVar;
        hVar.f4682e0 = cVar.f4897d & hVar.f4682e0;
        hVar.f4683f0 = j - j9;
        hVar.f4684g0 = j;
        synchronized (hVar.f4700t) {
            try {
                if (q6.f18244b.f18320a == hVar.f4680Y) {
                    Uri uri2 = hVar.f4681d0.f4903k;
                    if (uri2 == null) {
                        uri2 = q6.f18246d.f18269c;
                    }
                    hVar.f4680Y = uri2;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (size != 0) {
            hVar.f4691k0 += i9;
            hVar.v(true);
            return;
        }
        N2.c cVar3 = hVar.f4681d0;
        if (!cVar3.f4897d) {
            hVar.v(true);
            return;
        }
        u uVar = cVar3.f4902i;
        if (uVar == null) {
            hVar.u();
            return;
        }
        String str = uVar.f4966b;
        if (y.a(str, "urn:mpeg:dash:utc:direct:2014") || y.a(str, "urn:mpeg:dash:utc:direct:2012")) {
            try {
                hVar.f4686h0 = y.K(uVar.f4967c) - hVar.f4684g0;
                hVar.v(true);
                return;
            } catch (j0 e9) {
                p071h3.a.u("DashMediaSource", "Failed to resolve time offset.", e9);
                hVar.v(true);
                return;
            }
        }
        if (y.a(str, "urn:mpeg:dash:utc:http-iso:2014") || y.a(str, "urn:mpeg:dash:utc:http-iso:2012")) {
            Q q8 = new Q(hVar.f4706z, Uri.parse(uVar.f4967c), 5, new M2.g());
            hVar.f4676A.f(q8, new M2.f(hVar), 1);
            hVar.f4697q.l(new C0206q(q8.f18244b), q8.f18245c, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
        } else if (y.a(str, "urn:mpeg:dash:utc:http-xsdate:2014") || y.a(str, "urn:mpeg:dash:utc:http-xsdate:2012")) {
            Q q9 = new Q(hVar.f4706z, Uri.parse(uVar.f4967c), 5, new K5.f(15));
            hVar.f4676A.f(q9, new M2.f(hVar), 1);
            hVar.f4697q.l(new C0206q(q9.f18244b), q9.f18245c, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
        } else if (y.a(str, "urn:mpeg:dash:utc:ntp:2014") || y.a(str, "urn:mpeg:dash:utc:ntp:2012")) {
            hVar.u();
        } else {
            p071h3.a.u("DashMediaSource", "Failed to resolve time offset.", new IOException("Unsupported UTC timing scheme"));
            hVar.v(true);
        }
    }

    @Override // G0.E0
    public int H() {
        return ((androidx.recyclerview.widget.a) this.f43b).K();
    }

    @Override // P.InterfaceC0313f
    public int I() {
        return ((ContentInfo) this.f43b).getSource();
    }

    @Override // G0.E0
    public int J(View view) {
        return androidx.recyclerview.widget.a.z(view) + ((ViewGroup.MarginLayoutParams) ((C0122f0) view.getLayoutParams())).bottomMargin;
    }

    @Override // p062g3.P
    public Object M(Uri uri, C0954o c0954o) throws j0 {
        try {
            XmlPullParser xmlPullParserNewPullParser = ((XmlPullParserFactory) this.f43b).newPullParser();
            xmlPullParserNewPullParser.setInput(c0954o, null);
            return (T2.c) new T2.g(uri.toString()).e(xmlPullParserNewPullParser);
        } catch (XmlPullParserException e9) {
            throw j0.b(null, e9);
        }
    }

    @Override // J2.g0
    public boolean N(long j) {
        boolean zN;
        boolean z9 = false;
        do {
            long jP = p();
            if (jP == Long.MIN_VALUE) {
                return z9;
            }
            zN = false;
            for (g0 g0Var : (g0[]) this.f43b) {
                long jP2 = g0Var.p();
                boolean z10 = jP2 != Long.MIN_VALUE && jP2 <= j;
                if (jP2 == jP || z10) {
                    zN |= g0Var.N(j);
                }
            }
            z9 |= zN;
        } while (zN);
        return z9;
    }

    @Override // J2.g0
    public void P(long j) {
        for (g0 g0Var : (g0[]) this.f43b) {
            g0Var.P(j);
        }
    }

    @Override // U2.f
    public int Q() {
        return 1;
    }

    public E1.i R() {
        E1.d dVarK;
        E1.b bVar = (E1.b) this.f43b;
        E1.g gVar = (E1.g) bVar.f1221d;
        synchronized (gVar) {
            bVar.b(true);
            dVarK = gVar.k(((E1.c) bVar.f1220c).f1222a);
        }
        if (dVarK != null) {
            return new E1.i(dVarK);
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:32:0x00c1  */
    public o S() {
        Object objM;
        Object obj;
        p130n6.d dVar = (p130n6.d) this.f43b;
        String strQ = p064g6.o.f18389a.Q();
        kotlin.jvm.internal.d dVarA = p.a(GeneralPreference.class);
        if (dVarA.equals(p.a(Float.TYPE))) {
            objM = (GeneralPreference) Float.valueOf(dVar.f21718a.getFloat(strQ, 0.0f));
        } else if (dVarA.equals(p.a(Integer.TYPE))) {
            objM = (GeneralPreference) Integer.valueOf(dVar.f21718a.getInt(strQ, 0));
        } else if (dVarA.equals(p.a(Long.TYPE))) {
            objM = (GeneralPreference) Long.valueOf(dVar.f21718a.getLong(strQ, 0L));
        } else if (dVarA.equals(p.a(String.class))) {
            Object string = dVar.f21718a.getString(strQ, "");
            if (string == null) {
                throw new NullPointerException("null cannot be cast to non-null type com.maertsno.data.model.preference.GeneralPreference");
            }
            objM = (GeneralPreference) string;
        } else if (dVarA.equals(p.a(Boolean.TYPE))) {
            objM = (GeneralPreference) Boolean.valueOf(dVar.f21718a.getBoolean(strQ, false));
        } else {
            String string2 = dVar.f21718a.getString(strQ, "");
            if (string2 == null || string2.length() == 0) {
                objM = null;
            } else {
                try {
                    objM = dVar.f21719b.a(GeneralPreference.class).b(string2);
                } catch (Throwable th) {
                    objM = u0.m(th);
                }
                if (objM instanceof p039d8.h) {
                    objM = null;
                }
            }
        }
        GeneralPreference generalPreference = (GeneralPreference) objM;
        A6.d dVar2 = A6.d.f59a;
        A6.h hVar = A6.h.f77a;
        if (generalPreference == null) {
            return new o(0, -1, 16, 22, hVar, dVar2, 0, "");
        }
        int i9 = generalPreference.f15759a;
        int i10 = generalPreference.f15760b;
        int i11 = generalPreference.f15761c;
        int i12 = generalPreference.f15762d;
        int i13 = generalPreference.f15763e;
        if (i13 >= 0) {
            p102k8.b bVar = A6.h.f79c;
            if (i13 < bVar.e()) {
                obj = hVar;
                obj = hVar;
                obj = bVar.get(i13);
            }
        }
        obj = hVar;
        obj = hVar;
        obj = hVar;
        A6.h hVar2 = (A6.h) obj;
        int i14 = generalPreference.f15764f;
        Object obj2 = dVar2;
        if (i14 >= 0) {
            p102k8.b bVar2 = A6.d.f65g;
            if (i14 < bVar2.e()) {
                obj2 = dVar2;
                obj2 = bVar2.get(i14);
            }
        }
        obj2 = dVar2;
        return new o(i9, i10, i11, i12, hVar2, (A6.d) obj2, generalPreference.f15765g, generalPreference.f15766h);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Object T(String str, String str2, p093j8.c cVar) {
        F6.a aVar;
        if (cVar instanceof F6.a) {
            aVar = (F6.a) cVar;
            int i9 = aVar.f1652t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                aVar.f1652t = i9 - Integer.MIN_VALUE;
            } else {
                aVar = new F6.a(this, cVar);
            }
        } else {
            aVar = new F6.a(this, cVar);
        }
        Object objA = aVar.f1650r;
        int i10 = aVar.f1652t;
        if (i10 == 0) {
            u0.F(objA);
            s0 s0Var = (s0) this.f43b;
            aVar.f1652t = 1;
            s0Var.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new e0(s0Var, str, str2, null), aVar);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (objA == aVar2) {
                return aVar2;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            u0.F(objA);
        }
        return K3.h.i((p100k6.c) objA);
    }

    public c V(JSONObject jSONObject) {
        h eVar;
        int i9 = jSONObject.getInt("settings_version");
        if (i9 != 3) {
            Log.e("FirebaseCrashlytics", "Could not determine SettingsJsonTransform for settings version " + i9 + ". Using default settings values.", null);
            eVar = new K5.f(1);
        } else {
            eVar = new C4.e(2);
        }
        return eVar.f((p033d2.b) this.f43b, jSONObject);
    }

    public void W() {
        s1 s1Var = (s1) this.f43b;
        s1Var.r0();
        C0396n0 c0396n0 = (C0396n0) s1Var.f923a;
        C0366d0 c0366d0 = c0396n0.f8713e;
        C0396n0.e(c0366d0);
        G3.a aVar = c0396n0.f8718k;
        aVar.getClass();
        if (c0366d0.B0(System.currentTimeMillis())) {
            C0366d0 c0366d1 = c0396n0.f8713e;
            C0396n0.e(c0366d1);
            c0366d1.f8570l.b(true);
            ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
            ActivityManager.getMyMemoryState(runningAppProcessInfo);
            if (runningAppProcessInfo.importance == 100) {
                U u4 = c0396n0.f8714f;
                C0396n0.g(u4);
                u4.f8422n.b("Detected application was in foreground");
                aVar.getClass();
                a0(System.currentTimeMillis());
            }
        }
    }

    public boolean X() {
        U u4 = ((C0396n0) this.f43b).f8714f;
        C0396n0.g(u4);
        return Log.isLoggable(u4.B0(), 3);
    }

    public void Y(long j) {
        s1 s1Var = (s1) this.f43b;
        s1Var.r0();
        s1Var.v0();
        C0396n0 c0396n0 = (C0396n0) s1Var.f923a;
        C0366d0 c0366d0 = c0396n0.f8713e;
        C0396n0.e(c0366d0);
        if (c0366d0.B0(j)) {
            C0396n0.e(c0366d0);
            c0366d0.f8570l.b(true);
            c0396n0.l().w0();
        }
        C0396n0.e(c0366d0);
        c0366d0.f8574p.g(j);
        if (c0366d0.f8570l.a()) {
            a0(j);
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x001b  */
    public void Z(EnumC0423z0 enumC0423z0, int i9) {
        EnumC0377h enumC0377h;
        if (i9 == -30) {
            enumC0377h = EnumC0377h.TCF;
        } else if (i9 == -20) {
            enumC0377h = EnumC0377h.API;
        } else if (i9 == -10) {
            enumC0377h = EnumC0377h.MANIFEST;
        } else if (i9 != 0) {
            enumC0377h = i9 != 30 ? EnumC0377h.UNSET : EnumC0377h.INITIALIZATION;
        } else {
            enumC0377h = EnumC0377h.API;
        }
        ((EnumMap) this.f43b).put(enumC0423z0, enumC0377h);
    }

    @Override // U2.f
    public int a(long j) {
        return -1;
    }

    public void a0(long j) {
        s1 s1Var = (s1) this.f43b;
        s1Var.r0();
        C0396n0 c0396n0 = (C0396n0) s1Var.f923a;
        if (c0396n0.a()) {
            C0366d0 c0366d0 = c0396n0.f8713e;
            C0396n0.e(c0366d0);
            c0366d0.f8574p.g(j);
            c0396n0.f8718k.getClass();
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            U u4 = c0396n0.f8714f;
            C0396n0.g(u4);
            u4.f8422n.c(Long.valueOf(jElapsedRealtime), "Session started, time");
            long j9 = j / 1000;
            Long lValueOf = Long.valueOf(j9);
            P0 p8 = c0396n0.f8720m;
            C0396n0.f(p8);
            p8.C0(j, lValueOf, "auto", "_sid");
            C0396n0.e(c0366d0);
            c0366d0.f8575q.g(j9);
            c0366d0.f8570l.b(false);
            Bundle bundle = new Bundle();
            bundle.putLong("_sid", j9);
            C0396n0.f(p8);
            p8.z0(j, bundle, "auto", "_s");
            String strI = c0366d0.f8580v.i();
            if (TextUtils.isEmpty(strI)) {
                return;
            }
            Bundle bundle2 = new Bundle();
            bundle2.putString("_ffr", strI);
            C0396n0.f(p8);
            p8.z0(j, bundle2, "auto", "_ssr");
        }
    }

    @Override // p225z3.l
    public void accept(Object obj, Object obj2) {
        p015b4.i iVar = (p015b4.i) obj2;
        D3.a aVar = (D3.a) ((D3.d) obj).u();
        C0012m c0012m = (C0012m) this.f43b;
        Parcel parcelObtain = Parcel.obtain();
        parcelObtain.writeInterfaceToken(aVar.f5690g);
        int i9 = P3.a.f6100a;
        if (c0012m == null) {
            parcelObtain.writeInt(0);
        } else {
            parcelObtain.writeInt(1);
            c0012m.writeToParcel(parcelObtain, 0);
        }
        try {
            aVar.f5689f.transact(1, parcelObtain, null, 1);
            parcelObtain.recycle();
            iVar.b(null);
        } catch (Throwable th) {
            parcelObtain.recycle();
            throw th;
        }
    }

    @Override // K1.h
    public void b(K1.a aVar, Bitmap bitmap, Map map) {
        ((K1.g) this.f43b).o(aVar, bitmap, map, AbstractC0734e2.i(bitmap));
    }

    public void b0(EnumC0423z0 enumC0423z0, EnumC0377h enumC0377h) {
        ((EnumMap) this.f43b).put(enumC0423z0, enumC0377h);
    }

    @Override // M.a
    public void close() {
        ContentProviderClient contentProviderClient = (ContentProviderClient) this.f43b;
        if (contentProviderClient != null) {
            contentProviderClient.release();
        }
    }

    @Override // J2.g0
    public boolean d() {
        for (g0 g0Var : (g0[]) this.f43b) {
            if (g0Var.d()) {
                return true;
            }
        }
        return false;
    }

    @Override // a9.InterfaceC0487f
    public Object e(a9.x xVar) {
        C0490i c0490i = new C0490i(xVar);
        xVar.f(new p137o3.i(26, c0490i));
        return c0490i;
    }

    @Override // M.a
    public Cursor f(Uri uri, String[] strArr, String[] strArr2) {
        ContentProviderClient contentProviderClient = (ContentProviderClient) this.f43b;
        if (contentProviderClient == null) {
            return null;
        }
        try {
            return contentProviderClient.query(uri, strArr, "query = ?", strArr2, null, null);
        } catch (RemoteException e9) {
            Log.w("FontsProvider", "Unable to query the content provider", e9);
            return null;
        }
    }

    @Override // K1.h
    public K1.b g(K1.a aVar) {
        return null;
    }

    @Override // G0.L
    public void h(int i9, int i10) {
        ((K) this.f43b).f1961a.f(i9, i10);
    }

    @Override // a9.InterfaceC0488g
    public void i(InterfaceC0485d interfaceC0485d, a9.N n9) {
        C0490i c0490i = (C0490i) this.f43b;
        if (n9.f10067a.f()) {
            c0490i.complete(n9.f10068b);
        } else {
            c0490i.completeExceptionally(new C0496o(n9));
        }
    }

    @Override // G0.L
    public void j(int i9, int i10) {
        ((K) this.f43b).f1961a.c(i9, i10);
    }

    @Override // P.InterfaceC0313f
    public int k() {
        return ((ContentInfo) this.f43b).getFlags();
    }

    @Override // P.InterfaceC0313f
    public ClipData l() {
        return ((ContentInfo) this.f43b).getClip();
    }

    @Override // G0.E0
    public int m() {
        androidx.recyclerview.widget.a aVar = (androidx.recyclerview.widget.a) this.f43b;
        return aVar.f11252o - aVar.H();
    }

    @Override // U2.f
    public long n(int i9) {
        return 0L;
    }

    @Override // G0.E0
    public int o(View view) {
        return androidx.recyclerview.widget.a.F(view) - ((ViewGroup.MarginLayoutParams) ((C0122f0) view.getLayoutParams())).topMargin;
    }

    @Override // J2.g0
    public long p() {
        long jMin = Long.MAX_VALUE;
        for (g0 g0Var : (g0[]) this.f43b) {
            long jP = g0Var.p();
            if (jP != Long.MIN_VALUE) {
                jMin = Math.min(jMin, jP);
            }
        }
        if (jMin == Long.MAX_VALUE) {
            return Long.MIN_VALUE;
        }
        return jMin;
    }

    @Override // p062g3.I
    public void r(p062g3.K k9, long j, long j9, boolean z9) {
        Q q6 = (Q) k9;
        M2.h hVar = (M2.h) this.f43b;
        long j10 = q6.f18243a;
        Uri uri = q6.f18246d.f18269c;
        C0206q c0206q = new C0206q();
        hVar.f4694n.getClass();
        hVar.f4697q.d(c0206q, q6.f18245c, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
    }

    @Override // a9.InterfaceC0487f
    public Type s() {
        return (Type) this.f43b;
    }

    public String toString() {
        switch (this.f42a) {
            case 16:
                return "ContentInfoCompat{" + ((ContentInfo) this.f43b) + "}";
            case 22:
                StringBuilder sb = new StringBuilder("1");
                for (EnumC0423z0 enumC0423z0 : EnumC0423z0.values()) {
                    EnumC0377h enumC0377h = (EnumC0377h) ((EnumMap) this.f43b).get(enumC0423z0);
                    if (enumC0377h == null) {
                        enumC0377h = EnumC0377h.UNSET;
                    }
                    sb.append(enumC0377h.f8624a);
                }
                return sb.toString();
            default:
                return super.toString();
        }
    }

    @Override // P.InterfaceC0323p
    public x0 u(View view, x0 x0Var) {
        F4.i iVar = (F4.i) this.f43b;
        iVar.f1633l = x0Var.a();
        iVar.f1634m = x0Var.b();
        iVar.f1635n = x0Var.c();
        iVar.e();
        return x0Var;
    }

    @Override // a9.InterfaceC0488g
    public void v(InterfaceC0485d interfaceC0485d, Throwable th) {
        ((C0490i) this.f43b).completeExceptionally(th);
    }

    @Override // P.InterfaceC0313f
    public ContentInfo w() {
        return (ContentInfo) this.f43b;
    }

    @Override // K1.h
    public void y(int i9) {
    }

    @Override // U2.f
    public List z(long j) {
        return (List) this.f43b;
    }
}
