package A5;

import android.text.TextUtils;
import android.util.Log;
import j$.util.Objects;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;
import p200w0.C1373h;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f18a;

    public a(String str, int i9) {
        switch (i9) {
            case 2:
                str.getClass();
                this.f18a = str;
                break;
            default:
                this.f18a = str;
                break;
        }
    }

    public a(String str, p033d2.b bVar) {
        if (str == null) {
            throw new IllegalArgumentException("url must not be null.");
        }
        this.f18a = str;
    }

    public static void a(C1373h c1373h, i iVar) {
        String str = iVar.f44a;
        if (str != null) {
            c1373h.t("X-CRASHLYTICS-GOOGLE-APP-ID", str);
        }
        c1373h.t("X-CRASHLYTICS-API-CLIENT-TYPE", "android");
        c1373h.t("X-CRASHLYTICS-API-CLIENT-VERSION", "19.4.4");
        c1373h.t("Accept", "application/json");
        String str2 = iVar.f45b;
        if (str2 != null) {
            c1373h.t("X-CRASHLYTICS-DEVICE-MODEL", str2);
        }
        String str3 = iVar.f46c;
        if (str3 != null) {
            c1373h.t("X-CRASHLYTICS-OS-BUILD-VERSION", str3);
        }
        String str4 = iVar.f47d;
        if (str4 != null) {
            c1373h.t("X-CRASHLYTICS-OS-DISPLAY-VERSION", str4);
        }
        String str5 = iVar.f48e.c().f23085a;
        if (str5 != null) {
            c1373h.t("X-CRASHLYTICS-INSTALLATION-ID", str5);
        }
    }

    public static HashMap b(i iVar) {
        HashMap map = new HashMap();
        map.put("build_version", iVar.f51h);
        map.put("display_version", iVar.f50g);
        map.put("source", Integer.toString(iVar.f52i));
        String str = iVar.f49f;
        if (!TextUtils.isEmpty(str)) {
            map.put("instance", str);
        }
        return map;
    }

    public JSONObject c(K1.g gVar) {
        int i9 = gVar.f3735a;
        p148p5.c cVar = p148p5.c.f22433a;
        cVar.e("Settings response code was: " + i9);
        String str = this.f18a;
        if (i9 != 200 && i9 != 201 && i9 != 202 && i9 != 203) {
            String str2 = "Settings request failed; (status: " + i9 + ") from " + str;
            if (cVar.a(6)) {
                Log.e("FirebaseCrashlytics", str2, null);
            }
            return null;
        }
        String str3 = (String) gVar.f3736b;
        try {
            return new JSONObject(str3);
        } catch (Exception e9) {
            cVar.f("Failed to parse settings JSON from " + str, e9);
            cVar.f("Settings response " + str3, null);
            return null;
        }
    }

    public String d(List list) {
        Iterator it = list.iterator();
        StringBuilder sb = new StringBuilder();
        try {
            if (it.hasNext()) {
                Object next = it.next();
                Objects.requireNonNull(next);
                sb.append(next instanceof CharSequence ? (CharSequence) next : next.toString());
                while (it.hasNext()) {
                    sb.append((CharSequence) this.f18a);
                    Object next2 = it.next();
                    Objects.requireNonNull(next2);
                    sb.append(next2 instanceof CharSequence ? (CharSequence) next2 : next2.toString());
                }
            }
            return sb.toString();
        } catch (IOException e9) {
            throw new AssertionError(e9);
        }
    }
}
