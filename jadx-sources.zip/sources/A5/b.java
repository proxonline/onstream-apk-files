package A5;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f19a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f20b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f21c;

    public b(boolean z9, boolean z10, boolean z11) {
        this.f19a = z9;
        this.f20b = z10;
        this.f21c = z11;
    }
}
