package A5;

import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public interface h {
    c f(p033d2.b bVar, JSONObject jSONObject);
}
