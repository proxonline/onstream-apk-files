package A5;

import p060g1.q;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final q f22a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final b f23b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f24c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final double f25d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final double f26e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f27f;

    public c(long j, q qVar, b bVar, double d9, double d10, int i9) {
        this.f24c = j;
        this.f22a = qVar;
        this.f23b = bVar;
        this.f25d = d9;
        this.f26e = d10;
        this.f27f = i9;
    }
}
