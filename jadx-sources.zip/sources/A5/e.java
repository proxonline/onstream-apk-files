package A5;

import B3.z;
import B8.C0058s;
import C6.t;
import C6.y;
import F6.q;
import G0.A0;
import G0.C0114b0;
import G0.D0;
import G0.E0;
import G0.F0;
import G0.u0;
import H0.C0184q;
import H0.EnumC0186t;
import H0.v;
import P7.x;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import co.notix.R;
import com.google.android.gms.internal.measurement.AbstractC0734e2;
import com.google.android.gms.internal.measurement.I1;
import com.maertsno.data.model.response.ListAvatarsResponse;
import com.maertsno.data.model.response.ListSeasonResponse;
import com.maertsno.data.model.response.ListTopicReportResponse;
import com.maertsno.domain.type.MediaType;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONObject;
import p036d5.k;
import p062g3.C0954o;
import p062g3.P;
import p174s5.l;
import p182t6.C1276a;
import p182t6.C1281f;
import p182t6.C1289n;
import p182t6.C1293s;
import p182t6.C1298x;
import p182t6.C1299y;
import p182t6.J;
import p182t6.Q;
import p182t6.U;
import p182t6.W;
import p182t6.X;
import p182t6.c0;
import p182t6.d0;
import p182t6.h0;
import p182t6.i0;
import p182t6.j0;
import p182t6.n0;
import p182t6.q0;
import p182t6.s0;
import p210x6.m;
import p210x6.n;
import p210x6.r;

/* JADX INFO: loaded from: classes.dex */
public final class e implements p015b4.g, B5.a, R0.b, P, K1.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f30a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f31b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f32c;

    public e(int i9) {
        this.f30a = i9;
        switch (i9) {
            case 4:
                p208x3.e eVar = p208x3.e.f25611d;
                this.f31b = new SparseIntArray();
                this.f32c = eVar;
                break;
            case 21:
                this.f31b = new SparseIntArray();
                this.f32c = new SparseIntArray();
                break;
            case 22:
                break;
            case 24:
                this.f31b = new p158r.i(0);
                this.f32c = new p158r.g();
                break;
            default:
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512);
                this.f31b = byteArrayOutputStream;
                this.f32c = new DataOutputStream(byteArrayOutputStream);
                break;
        }
    }

    public e(int i9, int i10) {
        this.f30a = 19;
        this.f31b = new int[]{i9, i10};
        this.f32c = new float[]{0.0f, 1.0f};
    }

    public e(int i9, int i10, int i11) {
        this.f30a = 19;
        this.f31b = new int[]{i9, i10, i11};
        this.f32c = new float[]{0.0f, 0.5f, 1.0f};
    }

    public e(int i9, K1.g gVar) {
        this.f30a = 29;
        this.f31b = gVar;
        this.f32c = new K1.e(i9, this);
    }

    public e(f fVar, t5.d dVar) {
        this.f30a = 0;
        this.f32c = fVar;
        this.f31b = dVar;
    }

    public e(E0 e9) {
        this.f30a = 23;
        this.f31b = e9;
        D0 d9 = new D0();
        d9.f1897a = 0;
        this.f32c = d9;
    }

    public e(C0184q c0184q, R0.b actual) {
        this.f30a = 25;
        kotlin.jvm.internal.h.e(actual, "actual");
        this.f32c = c0184q;
        this.f31b = actual;
    }

    public e(v vVar) {
        this.f30a = 26;
        this.f31b = new AtomicInteger(0);
        this.f32c = new AtomicBoolean(false);
    }

    public e(Context context) {
        this.f30a = 3;
        z.h(context);
        Resources resources = context.getResources();
        this.f31b = resources;
        this.f32c = resources.getResourcePackageName(R.string.common_google_play_services_unknown_issue);
    }

    public /* synthetic */ e(Object obj) {
        this.f30a = 2;
        this.f32c = obj;
        this.f31b = new ArrayList();
    }

    public /* synthetic */ e(Object obj, int i9, Object obj2) {
        this.f30a = i9;
        this.f31b = obj;
        this.f32c = obj2;
    }

    public e(String str) {
        this.f30a = 27;
        this.f31b = str.concat(".lck");
    }

    public e(ArrayList arrayList, ArrayList arrayList2) {
        this.f30a = 19;
        int size = arrayList.size();
        this.f31b = new int[size];
        this.f32c = new float[size];
        for (int i9 = 0; i9 < size; i9++) {
            ((int[]) this.f31b)[i9] = ((Integer) arrayList.get(i9)).intValue();
            ((float[]) this.f32c)[i9] = ((Float) arrayList2.get(i9)).floatValue();
        }
    }

    public e(J movieRepository, p033d2.b bVar) {
        this.f30a = 8;
        kotlin.jvm.internal.h.e(movieRepository, "movieRepository");
        this.f31b = movieRepository;
        this.f32c = bVar;
    }

    public e(J movieRepository, k kVar) {
        this.f30a = 7;
        kotlin.jvm.internal.h.e(movieRepository, "movieRepository");
        this.f31b = movieRepository;
        this.f32c = kVar;
    }

    public e(J movieRepository, k kVar, byte b10) {
        this.f30a = 9;
        kotlin.jvm.internal.h.e(movieRepository, "movieRepository");
        this.f31b = movieRepository;
        this.f32c = kVar;
    }

    public e(J movieRepository, s0 userRepository) {
        this.f30a = 17;
        kotlin.jvm.internal.h.e(userRepository, "userRepository");
        kotlin.jvm.internal.h.e(movieRepository, "movieRepository");
        this.f31b = userRepository;
        this.f32c = movieRepository;
    }

    public e(J movieRepository, n pageDataMapper) {
        this.f30a = 10;
        kotlin.jvm.internal.h.e(movieRepository, "movieRepository");
        kotlin.jvm.internal.h.e(pageDataMapper, "pageDataMapper");
        this.f31b = movieRepository;
        this.f32c = pageDataMapper;
    }

    public e(U settingRepository, p033d2.b bVar) {
        this.f30a = 11;
        kotlin.jvm.internal.h.e(settingRepository, "settingRepository");
        this.f31b = settingRepository;
        this.f32c = bVar;
    }

    public e(U settingRepository, l lVar) {
        this.f30a = 12;
        kotlin.jvm.internal.h.e(settingRepository, "settingRepository");
        this.f31b = settingRepository;
        this.f32c = lVar;
    }

    public e(d0 traktRepository, k kVar) {
        this.f30a = 14;
        kotlin.jvm.internal.h.e(traktRepository, "traktRepository");
        this.f31b = traktRepository;
        this.f32c = kVar;
    }

    public e(s0 userRepository, p033d2.b bVar) {
        this.f30a = 18;
        kotlin.jvm.internal.h.e(userRepository, "userRepository");
        this.f31b = userRepository;
        this.f32c = bVar;
    }

    public e(s0 userRepository, m movieMapper) {
        this.f30a = 13;
        kotlin.jvm.internal.h.e(userRepository, "userRepository");
        kotlin.jvm.internal.h.e(movieMapper, "movieMapper");
        this.f31b = userRepository;
        this.f32c = movieMapper;
    }

    public e(s0 userRepository, n moviePageMapper) {
        this.f30a = 16;
        kotlin.jvm.internal.h.e(userRepository, "userRepository");
        kotlin.jvm.internal.h.e(moviePageMapper, "moviePageMapper");
        this.f31b = userRepository;
        this.f32c = moviePageMapper;
    }

    public e(s0 userRepository, r rVar) {
        this.f30a = 15;
        kotlin.jvm.internal.h.e(userRepository, "userRepository");
        this.f31b = userRepository;
        this.f32c = rVar;
    }

    public e(B5.a[] aVarArr) {
        this.f30a = 5;
        this.f31b = aVarArr;
        this.f32c = new C4.e(3);
    }

    public static int l(int i9, int i10) {
        int i11 = 0;
        int i12 = 0;
        for (int i13 = 0; i13 < i9; i13++) {
            i11++;
            if (i11 == i10) {
                i12++;
                i11 = 0;
            } else if (i11 > i10) {
                i12++;
                i11 = 1;
            }
        }
        return i11 + 1 > i10 ? i12 + 1 : i12;
    }

    public void A() throws IOException {
        String str = (String) this.f31b;
        if (((FileChannel) this.f32c) != null) {
            return;
        }
        try {
            File file = new File(str);
            File parentFile = file.getParentFile();
            if (parentFile != null) {
                parentFile.mkdirs();
            }
            FileChannel channel = new FileOutputStream(file).getChannel();
            this.f32c = channel;
            if (channel != null) {
                channel.lock();
            }
        } catch (Throwable th) {
            FileChannel fileChannel = (FileChannel) this.f32c;
            if (fileChannel != null) {
                fileChannel.close();
            }
            this.f32c = null;
            throw new IllegalStateException(B0.a.o("Unable to lock file: '", str, "'."), th);
        }
    }

    public void B(int i9, int i10) {
        int[] iArr = (int[]) this.f31b;
        if (iArr == null || i9 >= iArr.length) {
            return;
        }
        int i11 = i9 + i10;
        i(i11);
        int[] iArr2 = (int[]) this.f31b;
        System.arraycopy(iArr2, i9, iArr2, i11, (iArr2.length - i9) - i10);
        Arrays.fill((int[]) this.f31b, i9, i11, -1);
        ArrayList arrayList = (ArrayList) this.f32c;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            A0 a10 = (A0) ((ArrayList) this.f32c).get(size);
            int i12 = a10.f1860a;
            if (i12 >= i9) {
                a10.f1860a = i12 + i10;
            }
        }
    }

    public void C(int i9, int i10) {
        int[] iArr = (int[]) this.f31b;
        if (iArr == null || i9 >= iArr.length) {
            return;
        }
        int i11 = i9 + i10;
        i(i11);
        int[] iArr2 = (int[]) this.f31b;
        System.arraycopy(iArr2, i11, iArr2, i9, (iArr2.length - i9) - i10);
        int[] iArr3 = (int[]) this.f31b;
        Arrays.fill(iArr3, iArr3.length - i10, iArr3.length, -1);
        ArrayList arrayList = (ArrayList) this.f32c;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            A0 a10 = (A0) ((ArrayList) this.f32c).get(size);
            int i12 = a10.f1860a;
            if (i12 >= i9) {
                if (i12 < i11) {
                    ((ArrayList) this.f32c).remove(size);
                } else {
                    a10.f1860a = i12 - i10;
                }
            }
        }
    }

    public C0114b0 D(u0 u0Var, int i9) {
        F0 f3;
        C0114b0 c0114b0;
        p158r.i iVar = (p158r.i) this.f31b;
        int iD = iVar.d(u0Var);
        if (iD >= 0 && (f3 = (F0) iVar.i(iD)) != null) {
            int i10 = f3.f1913a;
            if ((i10 & i9) != 0) {
                int i11 = i10 & (~i9);
                f3.f1913a = i11;
                if (i9 == 4) {
                    c0114b0 = f3.f1914b;
                } else {
                    if (i9 != 8) {
                        throw new IllegalArgumentException("Must provide flag PRE or POST");
                    }
                    c0114b0 = f3.f1915c;
                }
                if ((i11 & 12) == 0) {
                    iVar.g(iD);
                    f3.f1913a = 0;
                    f3.f1914b = null;
                    f3.f1915c = null;
                    F0.f1912d.c(f3);
                }
                return c0114b0;
            }
        }
        return null;
    }

    public void E(u0 u0Var) {
        F0 f3 = (F0) ((p158r.i) this.f31b).get(u0Var);
        if (f3 == null) {
            return;
        }
        f3.f1913a &= -2;
    }

    public void F(u0 u0Var) {
        p158r.g gVar = (p158r.g) this.f32c;
        for (int iL = gVar.l() - 1; iL >= 0; iL--) {
            if (u0Var == gVar.m(iL)) {
                Object[] objArr = gVar.f22713c;
                Object obj = objArr[iL];
                Object obj2 = p158r.h.f22715a;
                if (obj == obj2) {
                    break;
                }
                objArr[iL] = obj2;
                gVar.f22711a = true;
                break;
            }
        }
        F0 f3 = (F0) ((p158r.i) this.f31b).remove(u0Var);
        if (f3 != null) {
            f3.f1913a = 0;
            f3.f1914b = null;
            f3.f1915c = null;
            F0.f1912d.c(f3);
        }
    }

    public void G() {
        synchronized (this) {
            ((AtomicInteger) this.f31b).decrementAndGet();
            if (((AtomicInteger) this.f31b).get() < 0) {
                throw new IllegalStateException("Unbalanced call to unblock() detected.");
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Serializable H(Integer num, p093j8.c cVar) {
        E6.g gVar;
        if (cVar instanceof E6.g) {
            gVar = (E6.g) cVar;
            int i9 = gVar.f1404t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                gVar.f1404t = i9 - Integer.MIN_VALUE;
            } else {
                gVar = new E6.g(this, cVar);
            }
        } else {
            gVar = new E6.g(this, cVar);
        }
        Object objA = gVar.f1402r;
        int i10 = gVar.f1404t;
        if (i10 == 0) {
            p195v5.u0.F(objA);
            d0 d0Var = (d0) this.f31b;
            gVar.f1404t = 1;
            d0Var.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new c0(num, d0Var, null), gVar);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p195v5.u0.F(objA);
        }
        p100k6.c cVar2 = (p100k6.c) objA;
        if (cVar2 instanceof p100k6.b) {
            return (Serializable) p165r6.a.a((k) this.f32c, (List) ((p100k6.b) cVar2).f21048a);
        }
        if (cVar2 instanceof p100k6.a) {
            return p195v5.u0.m(((p100k6.a) cVar2).f21047a);
        }
        throw new C0058s();
    }

    @Override // p062g3.P
    public Object M(Uri uri, C0954o c0954o) {
        I2.a aVar = (I2.a) ((P) this.f31b).M(uri, c0954o);
        List list = (List) this.f32c;
        return (list == null || list.isEmpty()) ? aVar : (I2.a) aVar.a(list);
    }

    @Override // R0.b
    public R0.a a(String fileName) {
        FileChannel fileChannel;
        FileChannel fileChannel2;
        kotlin.jvm.internal.h.e(fileName, "fileName");
        C0184q c0184q = (C0184q) this.f32c;
        if (!fileName.equals(":memory:")) {
            fileName = c0184q.f2838c.f2793a.getDatabasePath(fileName).getAbsolutePath();
            kotlin.jvm.internal.h.b(fileName);
        }
        boolean z9 = true;
        I0.a aVar = new I0.a(fileName, (c0184q.f2836a || c0184q.f2837b || fileName.equals(":memory:")) ? false : true);
        ReentrantLock reentrantLock = aVar.f3135a;
        reentrantLock.lock();
        e eVar = aVar.f3136b;
        if (eVar != null) {
            try {
                eVar.A();
            } catch (Throwable th) {
                th = th;
                z9 = false;
            }
        }
        try {
            try {
                if (c0184q.f2837b) {
                    throw new IllegalStateException("Recursive database initialization detected. Did you try to use the database instance during initialization? Maybe in one of the callbacks?");
                }
                R0.a aVarA = ((R0.b) this.f31b).a(fileName);
                if (c0184q.f2836a) {
                    if (c0184q.f2838c.f2799g == EnumC0186t.f2863c) {
                        I1.v(aVarA, "PRAGMA synchronous = NORMAL");
                    } else {
                        I1.v(aVarA, "PRAGMA synchronous = FULL");
                    }
                    C0184q.b(aVarA);
                    c0184q.f2839d.t(aVarA);
                } else {
                    try {
                        c0184q.f2837b = true;
                        C0184q.a(c0184q, aVarA);
                        c0184q.f2837b = false;
                    } catch (Throwable th2) {
                        c0184q.f2837b = false;
                        throw th2;
                    }
                }
                if (eVar != null && (fileChannel2 = (FileChannel) eVar.f32c) != null) {
                    try {
                        fileChannel2.close();
                        eVar.f32c = null;
                    } catch (Throwable th3) {
                        eVar.f32c = null;
                        throw th3;
                    }
                }
                reentrantLock.unlock();
                return aVarA;
            } catch (Throwable th4) {
                if (eVar != null && (fileChannel = (FileChannel) eVar.f32c) != null) {
                    try {
                        fileChannel.close();
                    } finally {
                        eVar.f32c = null;
                    }
                }
                throw th4;
            }
        } catch (Throwable th5) {
            th = th5;
        }
        th = th5;
        try {
            if (z9) {
                throw th;
            }
            throw new IllegalStateException("Unable to open database '" + fileName + "'. Was a proper path / name used in Room's database builder?", th);
        } catch (Throwable th6) {
            reentrantLock.unlock();
            throw th6;
        }
    }

    @Override // K1.h
    public void b(K1.a aVar, Bitmap bitmap, Map map) {
        int i9;
        int i10 = AbstractC0734e2.i(bitmap);
        K1.e eVar = (K1.e) this.f32c;
        synchronized (((p033d2.b) eVar.f1887g)) {
            i9 = eVar.f1882b;
        }
        if (i10 <= i9) {
            ((K1.e) this.f32c).l(aVar, new K1.d(bitmap, map, i10));
        } else {
            ((K1.e) this.f32c).m(aVar);
            ((K1.g) this.f31b).o(aVar, bitmap, map, i10);
        }
    }

    public void c(Object obj, String str) {
        ((ArrayList) this.f31b).add(str + "=" + String.valueOf(obj));
    }

    public void d(u0 u0Var, C0114b0 c0114b0) {
        p158r.i iVar = (p158r.i) this.f31b;
        F0 f0A = (F0) iVar.get(u0Var);
        if (f0A == null) {
            f0A = F0.a();
            iVar.put(u0Var, f0A);
        }
        f0A.f1915c = c0114b0;
        f0A.f1913a |= 8;
    }

    public boolean e() {
        synchronized (this) {
            if (((AtomicBoolean) this.f32c).get()) {
                return false;
            }
            ((AtomicInteger) this.f31b).incrementAndGet();
            return true;
        }
    }

    public void f() {
        int[] iArr = (int[]) this.f31b;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        this.f32c = null;
    }

    @Override // K1.h
    public K1.b g(K1.a aVar) {
        K1.d dVar = (K1.d) ((K1.e) this.f32c).h(aVar);
        if (dVar != null) {
            return new K1.b(dVar.f3726a, dVar.f3727b);
        }
        return null;
    }

    public byte[] h(B2.a aVar) {
        DataOutputStream dataOutputStream = (DataOutputStream) this.f32c;
        ByteArrayOutputStream byteArrayOutputStream = (ByteArrayOutputStream) this.f31b;
        byteArrayOutputStream.reset();
        try {
            dataOutputStream.writeBytes(aVar.f146a);
            dataOutputStream.writeByte(0);
            String str = aVar.f147b;
            if (str == null) {
                str = "";
            }
            dataOutputStream.writeBytes(str);
            dataOutputStream.writeByte(0);
            dataOutputStream.writeLong(aVar.f148c);
            dataOutputStream.writeLong(aVar.f149d);
            dataOutputStream.write(aVar.f150e);
            dataOutputStream.flush();
            return byteArrayOutputStream.toByteArray();
        } catch (IOException e9) {
            throw new RuntimeException(e9);
        }
    }

    public void i(int i9) {
        int[] iArr = (int[]) this.f31b;
        if (iArr == null) {
            int[] iArr2 = new int[Math.max(i9, 10) + 1];
            this.f31b = iArr2;
            Arrays.fill(iArr2, -1);
        } else if (i9 >= iArr.length) {
            int length = iArr.length;
            while (length <= i9) {
                length *= 2;
            }
            int[] iArr3 = new int[length];
            this.f31b = iArr3;
            System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            int[] iArr4 = (int[]) this.f31b;
            Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Serializable j(p093j8.c cVar) {
        E6.e eVar;
        if (cVar instanceof E6.e) {
            eVar = (E6.e) cVar;
            int i9 = eVar.f1398t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                eVar.f1398t = i9 - Integer.MIN_VALUE;
            } else {
                eVar = new E6.e(this, cVar);
            }
        } else {
            eVar = new E6.e(this, cVar);
        }
        Object objA = eVar.f1396r;
        int i10 = eVar.f1398t;
        if (i10 == 0) {
            p195v5.u0.F(objA);
            d0 d0Var = (d0) this.f31b;
            eVar.f1398t = 1;
            d0Var.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new W(d0Var, null), eVar);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p195v5.u0.F(objA);
        }
        p100k6.c cVar2 = (p100k6.c) objA;
        if (cVar2 instanceof p100k6.b) {
            return (Serializable) p165r6.a.a((k) this.f32c, (List) ((p100k6.b) cVar2).f21048a);
        }
        if (cVar2 instanceof p100k6.a) {
            return p195v5.u0.m(((p100k6.a) cVar2).f21047a);
        }
        throw new C0058s();
    }

    public View k(int i9, int i10, int i11, int i12) {
        D0 d9 = (D0) this.f32c;
        E0 e9 = (E0) this.f31b;
        int iH = e9.H();
        int iM = e9.m();
        int i13 = i10 > i9 ? 1 : -1;
        View view = null;
        while (i9 != i10) {
            View viewA = e9.A(i9);
            int iO = e9.o(viewA);
            int iJ = e9.J(viewA);
            d9.f1898b = iH;
            d9.f1899c = iM;
            d9.f1900d = iO;
            d9.f1901e = iJ;
            if (i11 != 0) {
                d9.f1897a = i11;
                if (d9.a()) {
                    return viewA;
                }
            }
            if (i12 != 0) {
                d9.f1897a = i12;
                if (d9.a()) {
                    view = viewA;
                }
            }
            i9 += i13;
        }
        return view;
    }

    public String m(String str) {
        String str2 = (String) this.f32c;
        Resources resources = (Resources) this.f31b;
        int identifier = resources.getIdentifier(str, "string", str2);
        if (identifier == 0) {
            return null;
        }
        return resources.getString(identifier);
    }

    @Override // B5.a
    public StackTraceElement[] n(StackTraceElement[] stackTraceElementArr) {
        if (stackTraceElementArr.length <= 1024) {
            return stackTraceElementArr;
        }
        B5.a[] aVarArr = (B5.a[]) this.f31b;
        StackTraceElement[] stackTraceElementArrN = stackTraceElementArr;
        for (int i9 = 0; i9 < 1; i9++) {
            B5.a aVar = aVarArr[i9];
            if (stackTraceElementArrN.length <= 1024) {
                break;
            }
            stackTraceElementArrN = aVar.n(stackTraceElementArr);
        }
        return stackTraceElementArrN.length > 1024 ? ((C4.e) this.f32c).n(stackTraceElementArrN) : stackTraceElementArrN;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Serializable o(p093j8.c cVar) {
        E6.f fVar;
        if (cVar instanceof E6.f) {
            fVar = (E6.f) cVar;
            int i9 = fVar.f1401t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                fVar.f1401t = i9 - Integer.MIN_VALUE;
            } else {
                fVar = new E6.f(this, cVar);
            }
        } else {
            fVar = new E6.f(this, cVar);
        }
        Object objA = fVar.f1399r;
        int i10 = fVar.f1401t;
        if (i10 == 0) {
            p195v5.u0.F(objA);
            d0 d0Var = (d0) this.f31b;
            fVar.f1401t = 1;
            d0Var.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new X(d0Var, null), fVar);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p195v5.u0.F(objA);
        }
        p100k6.c cVar2 = (p100k6.c) objA;
        if (cVar2 instanceof p100k6.b) {
            return (Serializable) p165r6.a.a((k) this.f32c, (List) ((p100k6.b) cVar2).f21048a);
        }
        if (cVar2 instanceof p100k6.a) {
            return p195v5.u0.m(((p100k6.a) cVar2).f21047a);
        }
        throw new C0058s();
    }

    public void p() {
        ((SparseIntArray) this.f31b).clear();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Serializable q(A6.a aVar, int i9, p093j8.c cVar) {
        C6.r rVar;
        String strL;
        if (cVar instanceof C6.r) {
            rVar = (C6.r) cVar;
            int i10 = rVar.f790t;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                rVar.f790t = i10 - Integer.MIN_VALUE;
            } else {
                rVar = new C6.r(this, cVar);
            }
        } else {
            rVar = new C6.r(this, cVar);
        }
        Object objA = rVar.f788r;
        int i11 = rVar.f790t;
        if (i11 == 0) {
            p195v5.u0.F(objA);
            int iOrdinal = aVar.ordinal();
            if (iOrdinal == 0) {
                strL = null;
            } else if (iOrdinal == 1) {
                strL = I3.a.L(new Date());
            } else {
                if (iOrdinal != 2) {
                    throw new C0058s();
                }
                strL = I3.a.L(new Date(System.currentTimeMillis() - 86400000));
            }
            J j = (J) this.f31b;
            rVar.f790t = 1;
            j.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new C1289n(strL, j, i9, null), rVar);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (objA == aVar2) {
                return aVar2;
            }
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p195v5.u0.F(objA);
        }
        p100k6.c cVar2 = (p100k6.c) objA;
        if (cVar2 instanceof p100k6.b) {
            return (Serializable) p165r6.a.a((k) this.f32c, (List) ((p100k6.b) cVar2).f21048a);
        }
        if (cVar2 instanceof p100k6.a) {
            return p195v5.u0.m(((p100k6.a) cVar2).f21047a);
        }
        throw new C0058s();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Object r(int i9, List list, p093j8.c cVar) {
        y yVar;
        if (cVar instanceof y) {
            yVar = (y) cVar;
            int i10 = yVar.f818t;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                yVar.f818t = i10 - Integer.MIN_VALUE;
            } else {
                yVar = new y(this, cVar);
            }
        } else {
            yVar = new y(this, cVar);
        }
        Object objA = yVar.f816r;
        int i11 = yVar.f818t;
        if (i11 == 0) {
            p195v5.u0.F(objA);
            J j = (J) this.f31b;
            yVar.f818t = 1;
            j.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new C1298x(j, i9, list, null), yVar);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p195v5.u0.F(objA);
        }
        return K3.h.k((p100k6.c) objA, (n) this.f32c);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Object s(long j, MediaType mediaType, p093j8.c cVar) {
        t tVar;
        if (cVar instanceof t) {
            tVar = (t) cVar;
            int i9 = tVar.f796t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                tVar.f796t = i9 - Integer.MIN_VALUE;
            } else {
                tVar = new t(this, cVar);
            }
        } else {
            tVar = new t(this, cVar);
        }
        Object objA = tVar.f794r;
        int i10 = tVar.f796t;
        if (i10 == 0) {
            p195v5.u0.F(objA);
            J j9 = (J) this.f31b;
            int i11 = mediaType == MediaType.MOVIE ? 1 : 2;
            tVar.f796t = 1;
            j9.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new C1293s(j9, j, i11, null), tVar);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p195v5.u0.F(objA);
        }
        p100k6.c cVar2 = (p100k6.c) objA;
        if (cVar2 instanceof p100k6.b) {
            return ((p033d2.b) this.f32c).x((ListSeasonResponse) ((p100k6.b) cVar2).f21048a).f26116a;
        }
        if (cVar2 instanceof p100k6.a) {
            return p195v5.u0.m(((p100k6.a) cVar2).f21047a);
        }
        throw new C0058s();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Object t(MediaType mediaType, int i9, p093j8.c cVar) {
        F6.h hVar;
        if (cVar instanceof F6.h) {
            hVar = (F6.h) cVar;
            int i10 = hVar.f1669t;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                hVar.f1669t = i10 - Integer.MIN_VALUE;
            } else {
                hVar = new F6.h(this, cVar);
            }
        } else {
            hVar = new F6.h(this, cVar);
        }
        Object objA = hVar.f1667r;
        int i11 = hVar.f1669t;
        if (i11 == 0) {
            p195v5.u0.F(objA);
            s0 s0Var = (s0) this.f31b;
            String str = mediaType.f16383a;
            Locale locale = Locale.getDefault();
            kotlin.jvm.internal.h.d(locale, "getDefault(...)");
            String lowerCase = str.toLowerCase(locale);
            kotlin.jvm.internal.h.d(lowerCase, "toLowerCase(...)");
            hVar.f1669t = 1;
            s0Var.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new i0(s0Var, lowerCase, i9, null), hVar);
            p084i8.a aVar = p084i8.a.f19475a;
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p195v5.u0.F(objA);
        }
        return K3.h.k((p100k6.c) objA, (n) this.f32c);
    }

    public String toString() {
        switch (this.f30a) {
            case 2:
                StringBuilder sb = new StringBuilder(100);
                sb.append(this.f32c.getClass().getSimpleName());
                sb.append('{');
                ArrayList arrayList = (ArrayList) this.f31b;
                int size = arrayList.size();
                for (int i9 = 0; i9 < size; i9++) {
                    sb.append((String) arrayList.get(i9));
                    if (i9 < size - 1) {
                        sb.append(", ");
                    }
                }
                sb.append('}');
                return sb.toString();
            default:
                return super.toString();
        }
    }

    /* JADX WARN: Code duplicated, block: B:33:0x008d  */
    /* JADX WARN: Code duplicated, block: B:9:0x001e  */
    public Serializable u(p093j8.c cVar) {
        B6.a aVar;
        C6.x xVar;
        int i9 = this.f30a;
        p084i8.a aVar2 = p084i8.a.f19475a;
        switch (i9) {
            case 6:
                if (cVar instanceof B6.a) {
                    aVar = (B6.a) cVar;
                    int i10 = aVar.f299t;
                    if ((i10 & Integer.MIN_VALUE) != 0) {
                        aVar.f299t = i10 - Integer.MIN_VALUE;
                    } else {
                        aVar = new B6.a(this, cVar);
                    }
                } else {
                    aVar = new B6.a(this, cVar);
                }
                Object objA = aVar.f297r;
                int i11 = aVar.f299t;
                if (i11 == 0) {
                    p195v5.u0.F(objA);
                    p174s5.m mVar = (p174s5.m) this.f31b;
                    aVar.f299t = 1;
                    x xVar2 = p196v6.b.f24714a;
                    objA = p196v6.b.a(new C1276a(mVar, null), aVar);
                    if (objA == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i11 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    p195v5.u0.F(objA);
                }
                p100k6.c cVar2 = (p100k6.c) objA;
                if (cVar2 instanceof p100k6.b) {
                    return (Serializable) p165r6.a.a((k) this.f32c, ((ListAvatarsResponse) ((p100k6.b) cVar2).f21048a).f16059a);
                }
                if (cVar2 instanceof p100k6.a) {
                    return p195v5.u0.m(((p100k6.a) cVar2).f21047a);
                }
                throw new C0058s();
            default:
                if (cVar instanceof C6.x) {
                    xVar = (C6.x) cVar;
                    int i12 = xVar.f815t;
                    if ((i12 & Integer.MIN_VALUE) != 0) {
                        xVar.f815t = i12 - Integer.MIN_VALUE;
                    } else {
                        xVar = new C6.x(this, cVar);
                    }
                } else {
                    xVar = new C6.x(this, cVar);
                }
                Object objA2 = xVar.f813r;
                int i13 = xVar.f815t;
                if (i13 == 0) {
                    p195v5.u0.F(objA2);
                    J j = (J) this.f31b;
                    xVar.f815t = 1;
                    j.getClass();
                    x xVar3 = p196v6.b.f24714a;
                    objA2 = p196v6.b.a(new C1299y(j, null), xVar);
                    if (objA2 == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i13 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    p195v5.u0.F(objA2);
                }
                p100k6.c cVar3 = (p100k6.c) objA2;
                if (cVar3 instanceof p100k6.b) {
                    return (Serializable) p165r6.a.a((k) this.f32c, ((ListTopicReportResponse) ((p100k6.b) cVar3).f21048a).f16080a);
                }
                if (cVar3 instanceof p100k6.a) {
                    return p195v5.u0.m(((p100k6.a) cVar3).f21047a);
                }
                throw new C0058s();
        }
    }

    /* JADX WARN: Code duplicated, block: B:26:0x006b  */
    /* JADX WARN: Code duplicated, block: B:50:0x00db  */
    /* JADX WARN: Code duplicated, block: B:67:0x0128  */
    /* JADX WARN: Code duplicated, block: B:84:0x0175  */
    /* JADX WARN: Code duplicated, block: B:9:0x001e  */
    public Object v(p093j8.c cVar) {
        D6.l lVar;
        D6.m mVar;
        F6.g gVar;
        F6.n nVar;
        q qVar;
        int i9 = this.f30a;
        p084i8.a aVar = p084i8.a.f19475a;
        switch (i9) {
            case R.styleable.GradientColor_android_endY /* 11 */:
                if (cVar instanceof D6.l) {
                    lVar = (D6.l) cVar;
                    int i10 = lVar.f1052t;
                    if ((i10 & Integer.MIN_VALUE) != 0) {
                        lVar.f1052t = i10 - Integer.MIN_VALUE;
                    } else {
                        lVar = new D6.l(this, cVar);
                    }
                } else {
                    lVar = new D6.l(this, cVar);
                }
                Object objA = lVar.f1050r;
                int i11 = lVar.f1052t;
                if (i11 == 0) {
                    p195v5.u0.F(objA);
                    U u4 = (U) this.f31b;
                    lVar.f1052t = 1;
                    u4.getClass();
                    x xVar = p196v6.b.f24714a;
                    objA = p196v6.b.a(new p182t6.P(u4, null), lVar);
                    if (objA == aVar) {
                        return aVar;
                    }
                } else {
                    if (i11 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    p195v5.u0.F(objA);
                }
                return K3.h.k((p100k6.c) objA, (p033d2.b) this.f32c);
            case 12:
                if (cVar instanceof D6.m) {
                    mVar = (D6.m) cVar;
                    int i12 = mVar.f1055t;
                    if ((i12 & Integer.MIN_VALUE) != 0) {
                        mVar.f1055t = i12 - Integer.MIN_VALUE;
                    } else {
                        mVar = new D6.m(this, cVar);
                    }
                } else {
                    mVar = new D6.m(this, cVar);
                }
                Object objA2 = mVar.f1053r;
                int i13 = mVar.f1055t;
                if (i13 == 0) {
                    p195v5.u0.F(objA2);
                    U u9 = (U) this.f31b;
                    mVar.f1055t = 1;
                    u9.getClass();
                    x xVar2 = p196v6.b.f24714a;
                    objA2 = p196v6.b.a(new Q(u9, null), mVar);
                    if (objA2 == aVar) {
                        return aVar;
                    }
                } else {
                    if (i13 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    p195v5.u0.F(objA2);
                }
                return K3.h.k((p100k6.c) objA2, (l) this.f32c);
            case 13:
            case 14:
            case 16:
            default:
                if (cVar instanceof q) {
                    qVar = (q) cVar;
                    int i14 = qVar.f1695t;
                    if ((i14 & Integer.MIN_VALUE) != 0) {
                        qVar.f1695t = i14 - Integer.MIN_VALUE;
                    } else {
                        qVar = new q(this, cVar);
                    }
                } else {
                    qVar = new q(this, cVar);
                }
                Object objA3 = qVar.f1693r;
                int i15 = qVar.f1695t;
                if (i15 == 0) {
                    p195v5.u0.F(objA3);
                    s0 s0Var = (s0) this.f31b;
                    qVar.f1695t = 1;
                    s0Var.getClass();
                    x xVar3 = p196v6.b.f24714a;
                    objA3 = p196v6.b.a(new q0(s0Var, null), qVar);
                    if (objA3 == aVar) {
                        return aVar;
                    }
                } else {
                    if (i15 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    p195v5.u0.F(objA3);
                }
                return K3.h.k((p100k6.c) objA3, (p033d2.b) this.f32c);
            case 15:
                if (cVar instanceof F6.g) {
                    gVar = (F6.g) cVar;
                    int i16 = gVar.f1666t;
                    if ((i16 & Integer.MIN_VALUE) != 0) {
                        gVar.f1666t = i16 - Integer.MIN_VALUE;
                    } else {
                        gVar = new F6.g(this, cVar);
                    }
                } else {
                    gVar = new F6.g(this, cVar);
                }
                Object objA4 = gVar.f1664r;
                int i17 = gVar.f1666t;
                if (i17 == 0) {
                    p195v5.u0.F(objA4);
                    s0 s0Var2 = (s0) this.f31b;
                    gVar.f1666t = 1;
                    s0Var2.getClass();
                    x xVar4 = p196v6.b.f24714a;
                    objA4 = p196v6.b.a(new h0(s0Var2, null), gVar);
                    if (objA4 == aVar) {
                        return aVar;
                    }
                } else {
                    if (i17 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    p195v5.u0.F(objA4);
                }
                return K3.h.k((p100k6.c) objA4, (r) this.f32c);
            case 17:
                if (cVar instanceof F6.n) {
                    nVar = (F6.n) cVar;
                    int i18 = nVar.f1686u;
                    if ((i18 & Integer.MIN_VALUE) != 0) {
                        nVar.f1686u = i18 - Integer.MIN_VALUE;
                    } else {
                        nVar = new F6.n(this, cVar);
                    }
                } else {
                    nVar = new F6.n(this, cVar);
                }
                Object objA5 = nVar.f1684s;
                int i19 = nVar.f1686u;
                if (i19 == 0) {
                    p195v5.u0.F(objA5);
                    s0 s0Var3 = (s0) this.f31b;
                    nVar.f1686u = 1;
                    s0Var3.getClass();
                    x xVar5 = p196v6.b.f24714a;
                    objA5 = p196v6.b.a(new n0(s0Var3, null), nVar);
                    if (objA5 == aVar) {
                        return aVar;
                    }
                } else {
                    if (i19 != 1) {
                        if (i19 != 2) {
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        Object obj = nVar.f1683r;
                        p195v5.u0.F(objA5);
                        return obj;
                    }
                    p195v5.u0.F(objA5);
                }
                Object objI = K3.h.i((p100k6.c) objA5);
                if (!(objI instanceof p039d8.h)) {
                    J j = (J) this.f32c;
                    nVar.f1683r = objI;
                    nVar.f1686u = 2;
                    j.getClass();
                    x xVar6 = p196v6.b.f24714a;
                    if (p196v6.b.a(new C1281f(j, null), nVar) == aVar) {
                        return aVar;
                    }
                }
                return objI;
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Serializable w(List list, p093j8.c cVar) {
        E6.a aVar;
        if (cVar instanceof E6.a) {
            aVar = (E6.a) cVar;
            int i9 = aVar.f1387t;
            if ((i9 & Integer.MIN_VALUE) != 0) {
                aVar.f1387t = i9 - Integer.MIN_VALUE;
            } else {
                aVar = new E6.a(this, cVar);
            }
        } else {
            aVar = new E6.a(this, cVar);
        }
        Object objA = aVar.f1385r;
        int i10 = aVar.f1387t;
        if (i10 == 0) {
            p195v5.u0.F(objA);
            s0 s0Var = (s0) this.f31b;
            aVar.f1387t = 1;
            s0Var.getClass();
            x xVar = p196v6.b.f24714a;
            objA = p196v6.b.a(new j0(s0Var, list, null), aVar);
            p084i8.a aVar2 = p084i8.a.f19475a;
            if (objA == aVar2) {
                return aVar2;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            p195v5.u0.F(objA);
        }
        p100k6.c cVar2 = (p100k6.c) objA;
        if (!(cVar2 instanceof p100k6.b)) {
            if (cVar2 instanceof p100k6.a) {
                return p195v5.u0.m(((p100k6.a) cVar2).f21047a);
            }
            throw new C0058s();
        }
        m mVar = (m) this.f32c;
        List list2 = (List) ((p100k6.b) cVar2).f21048a;
        mVar.getClass();
        return (Serializable) p165r6.a.a(mVar, list2);
    }

    @Override // p015b4.g
    public p015b4.q x(Object obj) throws Throwable {
        FileWriter fileWriter;
        f fVar = (f) this.f32c;
        JSONObject jSONObject = (JSONObject) ((t5.d) this.f31b).f23490c.f23484a.submit(new d(0, this)).get();
        FileWriter fileWriter2 = null;
        if (jSONObject != null) {
            c cVarV = ((g) fVar.f35c).V(jSONObject);
            V5.c cVar = (V5.c) fVar.f37e;
            long j = cVarV.f24c;
            cVar.getClass();
            if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                Log.v("FirebaseCrashlytics", "Writing settings to cache file...", null);
            }
            try {
                jSONObject.put("expires_at", j);
                fileWriter = new FileWriter((File) cVar.f7730b);
                try {
                    try {
                        fileWriter.write(jSONObject.toString());
                        fileWriter.flush();
                    } catch (Throwable th) {
                        th = th;
                        fileWriter2 = fileWriter;
                        p174s5.g.b(fileWriter2, "Failed to close settings writer.");
                        throw th;
                    }
                } catch (Exception e9) {
                    e = e9;
                    Log.e("FirebaseCrashlytics", "Failed to cache settings", e);
                }
            } catch (Exception e10) {
                e = e10;
                fileWriter = null;
            } catch (Throwable th2) {
                th = th2;
                p174s5.g.b(fileWriter2, "Failed to close settings writer.");
                throw th;
            }
            p174s5.g.b(fileWriter, "Failed to close settings writer.");
            f.n(jSONObject, "Loaded settings: ");
            String str = ((i) fVar.f34b).f49f;
            SharedPreferences.Editor editorEdit = ((Context) fVar.f33a).getSharedPreferences("com.google.firebase.crashlytics", 0).edit();
            editorEdit.putString("existing_instance_identifier", str);
            editorEdit.apply();
            ((AtomicReference) fVar.f40h).set(cVarV);
            ((p015b4.i) ((AtomicReference) fVar.f41i).get()).d(cVarV);
        }
        return p054f5.b.s(null);
    }

    @Override // K1.h
    public void y(int i9) {
        int i10;
        if (i9 >= 40) {
            ((K1.e) this.f32c).p(-1);
            return;
        }
        if (10 > i9 || i9 >= 20) {
            return;
        }
        K1.e eVar = (K1.e) this.f32c;
        synchronized (((p033d2.b) eVar.f1887g)) {
            i10 = eVar.f1883c;
        }
        eVar.p(i10 / 2);
    }

    public boolean z(View view) {
        D0 d9 = (D0) this.f32c;
        E0 e9 = (E0) this.f31b;
        int iH = e9.H();
        int iM = e9.m();
        int iO = e9.o(view);
        int iJ = e9.J(view);
        d9.f1898b = iH;
        d9.f1899c = iM;
        d9.f1900d = iO;
        d9.f1901e = iJ;
        d9.f1897a = 24579;
        return d9.a();
    }
}
