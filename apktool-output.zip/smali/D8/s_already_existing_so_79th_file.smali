.class public final LD8/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB8/L0;


# instance fields
.field public final a:LB8/h;


# direct methods
.method public constructor <init>(LB8/h;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LD8/s;->a:LB8/h;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(LG8/u;I)V
    .locals 1

    .line 1
    iget-object v0, p0, LD8/s;->a:LB8/h;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LB8/h;->a(LG8/u;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
