.class public interface abstract LD8/u;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(Lj8/c;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public abstract h(Ljava/lang/Object;)Ljava/lang/Object;
.end method
