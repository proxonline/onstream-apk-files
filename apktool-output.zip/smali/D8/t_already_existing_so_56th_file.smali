.class public interface abstract LD8/t;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f(Ljava/util/concurrent/CancellationException;)V
.end method

.method public abstract g()Ljava/lang/Object;
.end method

.method public abstract i(LF8/s;)Ljava/lang/Object;
.end method
