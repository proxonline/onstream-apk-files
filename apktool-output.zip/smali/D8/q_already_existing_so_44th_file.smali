.class public final LD8/q;
.super LB8/a;
.source "SourceFile"

# interfaces
.implements LD8/r;
.implements LD8/i;


# instance fields
.field public final d:LD8/e;


# direct methods
.method public constructor <init>(Lh8/i;LD8/e;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-direct {p0, p1, v0}, LB8/a;-><init>(Lh8/i;Z)V

    .line 3
    .line 4
    .line 5
    iput-object p2, p0, LD8/q;->d:LD8/e;

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final a0(Ljava/lang/Throwable;Z)V
    .locals 2

    .line 1
    iget-object v0, p0, LD8/q;->d:LD8/e;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, p1, v1}, LD8/e;->j(Ljava/lang/Throwable;Z)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    if-nez p2, :cond_0

    .line 11
    .line 12
    iget-object p2, p0, LB8/a;->c:Lh8/i;

    .line 13
    .line 14
    invoke-static {p2, p1}, LB8/D;->o(Lh8/i;Ljava/lang/Throwable;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final b0(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, Ld8/l;

    .line 2
    .line 3
    iget-object p1, p0, LD8/q;->d:LD8/e;

    .line 4
    .line 5
    invoke-static {p1}, Lf5/b;->j(LD8/e;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final c(Lj8/c;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LD8/q;->d:LD8/e;

    .line 2
    .line 3
    invoke-interface {v0, p1, p2}, LD8/u;->c(Lj8/c;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public final f(Ljava/util/concurrent/CancellationException;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, LB8/u0;->isCancelled()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    if-nez p1, :cond_1

    .line 9
    .line 10
    new-instance p1, LB8/k0;

    .line 11
    .line 12
    invoke-virtual {p0}, LB8/a;->s()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-direct {p1, v0, v1, p0}, LB8/k0;-><init>(Ljava/lang/String;Ljava/lang/Throwable;LB8/u0;)V

    .line 18
    .line 19
    .line 20
    :cond_1
    invoke-virtual {p0, p1}, LD8/q;->q(Ljava/util/concurrent/CancellationException;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final g()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LD8/q;->d:LD8/e;

    .line 2
    .line 3
    invoke-virtual {v0}, LD8/e;->g()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    return-object v0
.end method

.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public final i(LF8/s;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LD8/q;->d:LD8/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {v0, p1}, LD8/e;->A(LD8/e;Lj8/c;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    return-object p1
.end method

.method public final q(Ljava/util/concurrent/CancellationException;)V
    .locals 2

    .line 1
    iget-object v0, p0, LD8/q;->d:LD8/e;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-virtual {v0, p1, v1}, LD8/e;->j(Ljava/lang/Throwable;Z)Z

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p1}, LB8/u0;->p(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    return-void
.end method
