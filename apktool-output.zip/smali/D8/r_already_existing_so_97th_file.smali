.class public interface abstract LD8/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB8/A;
.implements LD8/u;
