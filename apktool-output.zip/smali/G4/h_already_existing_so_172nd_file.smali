.class public interface abstract LG4/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract d(LG4/f;I)V
.end method
