.class public interface abstract LG4/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG4/b;
