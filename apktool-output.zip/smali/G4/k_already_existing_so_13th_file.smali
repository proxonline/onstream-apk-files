.class public final LG4/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LP8/i;LP8/e;LQ8/d;)V
    .locals 1

    const-string v0, "finder"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, LG4/k;->b:Ljava/lang/Object;

    .line 3
    iput-object p2, p0, LG4/k;->c:Ljava/lang/Object;

    .line 4
    iput-object p3, p0, LG4/k;->d:Ljava/lang/Object;

    .line 5
    invoke-interface {p3}, LQ8/d;->h()LP8/k;

    move-result-object p1

    iput-object p1, p0, LG4/k;->e:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/tabs/TabLayout;Landroidx/viewpager2/widget/ViewPager2;LG4/h;)V
    .locals 0

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-object p1, p0, LG4/k;->b:Ljava/lang/Object;

    .line 8
    iput-object p2, p0, LG4/k;->c:Ljava/lang/Object;

    .line 9
    iput-object p3, p0, LG4/k;->d:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a()V
    .locals 7

    .line 1
    iget-object v0, p0, LG4/k;->b:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, Lcom/google/android/material/tabs/TabLayout;

    .line 5
    .line 6
    iget-object v0, p0, LG4/k;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroidx/viewpager2/widget/ViewPager2;

    .line 9
    .line 10
    iget-boolean v2, p0, LG4/k;->a:Z

    .line 11
    .line 12
    if-nez v2, :cond_2

    .line 13
    .line 14
    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getAdapter()LG0/V;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    iput-object v2, p0, LG4/k;->e:Ljava/lang/Object;

    .line 19
    .line 20
    if-eqz v2, :cond_1

    .line 21
    .line 22
    const/4 v2, 0x1

    .line 23
    iput-boolean v2, p0, LG4/k;->a:Z

    .line 24
    .line 25
    new-instance v2, LG4/i;

    .line 26
    .line 27
    invoke-direct {v2, v1}, LG4/i;-><init>(Lcom/google/android/material/tabs/TabLayout;)V

    .line 28
    .line 29
    .line 30
    iget-object v3, v0, Landroidx/viewpager2/widget/ViewPager2;->c:Le1/b;

    .line 31
    .line 32
    iget-object v3, v3, Le1/b;->b:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v3, Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    new-instance v2, LG4/j;

    .line 40
    .line 41
    invoke-direct {v2, v0}, LG4/j;-><init>(Landroidx/viewpager2/widget/ViewPager2;)V

    .line 42
    .line 43
    .line 44
    iget-object v3, v1, Lcom/google/android/material/tabs/TabLayout;->j0:Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v4

    .line 50
    if-nez v4, :cond_0

    .line 51
    .line 52
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    :cond_0
    new-instance v2, LG0/m0;

    .line 56
    .line 57
    const/4 v3, 0x1

    .line 58
    invoke-direct {v2, v3, p0}, LG0/m0;-><init>(ILjava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    iget-object v3, p0, LG4/k;->e:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v3, LG0/V;

    .line 64
    .line 65
    iget-object v3, v3, LG0/V;->a:LG0/W;

    .line 66
    .line 67
    invoke-virtual {v3, v2}, Landroid/database/Observable;->registerObserver(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p0}, LG4/k;->c()V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    .line 74
    .line 75
    .line 76
    move-result v2

    .line 77
    const/4 v5, 0x1

    .line 78
    const/4 v6, 0x1

    .line 79
    const/4 v3, 0x0

    .line 80
    const/4 v4, 0x1

    .line 81
    invoke-virtual/range {v1 .. v6}, Lcom/google/android/material/tabs/TabLayout;->h(IFZZZ)V

    .line 82
    .line 83
    .line 84
    return-void

    .line 85
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 86
    .line 87
    const-string v1, "TabLayoutMediator attached before ViewPager2 has an adapter"

    .line 88
    .line 89
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    throw v0

    .line 93
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 94
    .line 95
    const-string v1, "TabLayoutMediator is already attached"

    .line 96
    .line 97
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    throw v0
.end method

.method public b(ZZLjava/io/IOException;)Ljava/io/IOException;
    .locals 1

    .line 1
    iget-object v0, p0, LG4/k;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LP8/i;

    .line 4
    .line 5
    if-eqz p3, :cond_0

    .line 6
    .line 7
    invoke-virtual {p0, p3}, LG4/k;->e(Ljava/io/IOException;)V

    .line 8
    .line 9
    .line 10
    :cond_0
    invoke-virtual {v0, p0, p2, p1, p3}, LP8/i;->h(LG4/k;ZZLjava/io/IOException;)Ljava/io/IOException;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1
.end method

.method public c()V
    .locals 13

    .line 1
    iget-object v0, p0, LG4/k;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/google/android/material/tabs/TabLayout;

    .line 4
    .line 5
    invoke-virtual {v0}, Lcom/google/android/material/tabs/TabLayout;->f()V

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lcom/google/android/material/tabs/TabLayout;->b:Ljava/util/ArrayList;

    .line 9
    .line 10
    iget-object v2, p0, LG4/k;->e:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v2, LG0/V;

    .line 13
    .line 14
    if-eqz v2, :cond_7

    .line 15
    .line 16
    invoke-virtual {v2}, LG0/V;->a()I

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    const/4 v3, 0x0

    .line 21
    move v4, v3

    .line 22
    :goto_0
    const/4 v5, 0x1

    .line 23
    if-ge v4, v2, :cond_4

    .line 24
    .line 25
    invoke-virtual {v0}, Lcom/google/android/material/tabs/TabLayout;->e()LG4/f;

    .line 26
    .line 27
    .line 28
    move-result-object v6

    .line 29
    iget-object v7, p0, LG4/k;->d:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v7, LG4/h;

    .line 32
    .line 33
    invoke-interface {v7, v6, v4}, LG4/h;->d(LG4/f;I)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 37
    .line 38
    .line 39
    move-result v7

    .line 40
    iget-object v8, v6, LG4/f;->d:Lcom/google/android/material/tabs/TabLayout;

    .line 41
    .line 42
    if-ne v8, v0, :cond_3

    .line 43
    .line 44
    iput v7, v6, LG4/f;->b:I

    .line 45
    .line 46
    invoke-virtual {v1, v7, v6}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 50
    .line 51
    .line 52
    move-result v8

    .line 53
    add-int/2addr v7, v5

    .line 54
    const/4 v9, -0x1

    .line 55
    move v10, v9

    .line 56
    :goto_1
    if-ge v7, v8, :cond_1

    .line 57
    .line 58
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v11

    .line 62
    check-cast v11, LG4/f;

    .line 63
    .line 64
    iget v11, v11, LG4/f;->b:I

    .line 65
    .line 66
    iget v12, v0, Lcom/google/android/material/tabs/TabLayout;->a:I

    .line 67
    .line 68
    if-ne v11, v12, :cond_0

    .line 69
    .line 70
    move v10, v7

    .line 71
    :cond_0
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v11

    .line 75
    check-cast v11, LG4/f;

    .line 76
    .line 77
    iput v7, v11, LG4/f;->b:I

    .line 78
    .line 79
    add-int/lit8 v7, v7, 0x1

    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_1
    iput v10, v0, Lcom/google/android/material/tabs/TabLayout;->a:I

    .line 83
    .line 84
    iget-object v7, v6, LG4/f;->e:LG4/g;

    .line 85
    .line 86
    invoke-virtual {v7, v3}, LG4/g;->setSelected(Z)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v7, v3}, Landroid/view/View;->setActivated(Z)V

    .line 90
    .line 91
    .line 92
    iget-object v8, v0, Lcom/google/android/material/tabs/TabLayout;->d:LG4/e;

    .line 93
    .line 94
    iget v6, v6, LG4/f;->b:I

    .line 95
    .line 96
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    .line 97
    .line 98
    const/4 v11, -0x2

    .line 99
    invoke-direct {v10, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 100
    .line 101
    .line 102
    iget v9, v0, Lcom/google/android/material/tabs/TabLayout;->B:I

    .line 103
    .line 104
    if-ne v9, v5, :cond_2

    .line 105
    .line 106
    iget v5, v0, Lcom/google/android/material/tabs/TabLayout;->y:I

    .line 107
    .line 108
    if-nez v5, :cond_2

    .line 109
    .line 110
    iput v3, v10, Landroid/widget/LinearLayout$LayoutParams;->width:I

    .line 111
    .line 112
    const/high16 v5, 0x3f800000    # 1.0f

    .line 113
    .line 114
    iput v5, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_2
    iput v11, v10, Landroid/widget/LinearLayout$LayoutParams;->width:I

    .line 118
    .line 119
    const/4 v5, 0x0

    .line 120
    iput v5, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 121
    .line 122
    :goto_2
    invoke-virtual {v8, v7, v6, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 123
    .line 124
    .line 125
    add-int/lit8 v4, v4, 0x1

    .line 126
    .line 127
    goto :goto_0

    .line 128
    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 129
    .line 130
    const-string v1, "Tab belongs to a different TabLayout."

    .line 131
    .line 132
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    throw v0

    .line 136
    :cond_4
    if-lez v2, :cond_7

    .line 137
    .line 138
    invoke-virtual {v0}, Lcom/google/android/material/tabs/TabLayout;->getTabCount()I

    .line 139
    .line 140
    .line 141
    move-result v2

    .line 142
    sub-int/2addr v2, v5

    .line 143
    iget-object v3, p0, LG4/k;->c:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast v3, Landroidx/viewpager2/widget/ViewPager2;

    .line 146
    .line 147
    invoke-virtual {v3}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    .line 148
    .line 149
    .line 150
    move-result v3

    .line 151
    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    .line 152
    .line 153
    .line 154
    move-result v2

    .line 155
    invoke-virtual {v0}, Lcom/google/android/material/tabs/TabLayout;->getSelectedTabPosition()I

    .line 156
    .line 157
    .line 158
    move-result v3

    .line 159
    if-eq v2, v3, :cond_7

    .line 160
    .line 161
    if-ltz v2, :cond_6

    .line 162
    .line 163
    invoke-virtual {v0}, Lcom/google/android/material/tabs/TabLayout;->getTabCount()I

    .line 164
    .line 165
    .line 166
    move-result v3

    .line 167
    if-lt v2, v3, :cond_5

    .line 168
    .line 169
    goto :goto_3

    .line 170
    :cond_5
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v1

    .line 174
    check-cast v1, LG4/f;

    .line 175
    .line 176
    goto :goto_4

    .line 177
    :cond_6
    :goto_3
    const/4 v1, 0x0

    .line 178
    :goto_4
    invoke-virtual {v0, v1, v5}, Lcom/google/android/material/tabs/TabLayout;->g(LG4/f;Z)V

    .line 179
    .line 180
    .line 181
    :cond_7
    return-void
.end method

.method public d(Z)LL8/G;
    .locals 1

    .line 1
    :try_start_0
    iget-object v0, p0, LG4/k;->d:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LQ8/d;

    .line 4
    .line 5
    invoke-interface {v0, p1}, LQ8/d;->f(Z)LL8/G;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    iput-object p0, p1, LL8/G;->m:LG4/k;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 12
    .line 13
    return-object p1

    .line 14
    :catch_0
    move-exception p1

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    return-object p1

    .line 17
    :goto_0
    invoke-virtual {p0, p1}, LG4/k;->e(Ljava/io/IOException;)V

    .line 18
    .line 19
    .line 20
    throw p1
.end method

.method public e(Ljava/io/IOException;)V
    .locals 5

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, LG4/k;->a:Z

    .line 3
    .line 4
    iget-object v1, p0, LG4/k;->c:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v1, LP8/e;

    .line 7
    .line 8
    invoke-virtual {v1, p1}, LP8/e;->e(Ljava/io/IOException;)V

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, LG4/k;->d:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, LQ8/d;

    .line 14
    .line 15
    invoke-interface {v1}, LQ8/d;->h()LP8/k;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    iget-object v2, p0, LG4/k;->b:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v2, LP8/i;

    .line 22
    .line 23
    monitor-enter v1

    .line 24
    :try_start_0
    instance-of v3, p1, LS8/C;

    .line 25
    .line 26
    if-eqz v3, :cond_2

    .line 27
    .line 28
    move-object v3, p1

    .line 29
    check-cast v3, LS8/C;

    .line 30
    .line 31
    iget v3, v3, LS8/C;->a:I

    .line 32
    .line 33
    const/16 v4, 0x8

    .line 34
    .line 35
    if-ne v3, v4, :cond_0

    .line 36
    .line 37
    iget p1, v1, LP8/k;->n:I

    .line 38
    .line 39
    add-int/2addr p1, v0

    .line 40
    iput p1, v1, LP8/k;->n:I

    .line 41
    .line 42
    if-le p1, v0, :cond_5

    .line 43
    .line 44
    iput-boolean v0, v1, LP8/k;->j:Z

    .line 45
    .line 46
    iget p1, v1, LP8/k;->l:I

    .line 47
    .line 48
    add-int/2addr p1, v0

    .line 49
    iput p1, v1, LP8/k;->l:I

    .line 50
    .line 51
    goto :goto_1

    .line 52
    :catchall_0
    move-exception p1

    .line 53
    goto :goto_2

    .line 54
    :cond_0
    check-cast p1, LS8/C;

    .line 55
    .line 56
    iget p1, p1, LS8/C;->a:I

    .line 57
    .line 58
    const/16 v3, 0x9

    .line 59
    .line 60
    if-ne p1, v3, :cond_1

    .line 61
    .line 62
    iget-boolean p1, v2, LP8/i;->m:Z

    .line 63
    .line 64
    if-nez p1, :cond_5

    .line 65
    .line 66
    :cond_1
    iput-boolean v0, v1, LP8/k;->j:Z

    .line 67
    .line 68
    iget p1, v1, LP8/k;->l:I

    .line 69
    .line 70
    add-int/2addr p1, v0

    .line 71
    iput p1, v1, LP8/k;->l:I

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_2
    iget-object v3, v1, LP8/k;->g:LS8/o;

    .line 75
    .line 76
    if-eqz v3, :cond_3

    .line 77
    .line 78
    move v3, v0

    .line 79
    goto :goto_0

    .line 80
    :cond_3
    const/4 v3, 0x0

    .line 81
    :goto_0
    if-eqz v3, :cond_4

    .line 82
    .line 83
    instance-of v3, p1, LS8/a;

    .line 84
    .line 85
    if-eqz v3, :cond_5

    .line 86
    .line 87
    :cond_4
    iput-boolean v0, v1, LP8/k;->j:Z

    .line 88
    .line 89
    iget v3, v1, LP8/k;->m:I

    .line 90
    .line 91
    if-nez v3, :cond_5

    .line 92
    .line 93
    iget-object v2, v2, LP8/i;->a:LL8/A;

    .line 94
    .line 95
    iget-object v3, v1, LP8/k;->b:LL8/K;

    .line 96
    .line 97
    invoke-static {v2, v3, p1}, LP8/k;->d(LL8/A;LL8/K;Ljava/io/IOException;)V

    .line 98
    .line 99
    .line 100
    iget p1, v1, LP8/k;->l:I

    .line 101
    .line 102
    add-int/2addr p1, v0

    .line 103
    iput p1, v1, LP8/k;->l:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 104
    .line 105
    :cond_5
    :goto_1
    monitor-exit v1

    .line 106
    return-void

    .line 107
    :goto_2
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 108
    throw p1
.end method
