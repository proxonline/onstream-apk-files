.class public final Le0/q;
.super LG0/N;
.source "SourceFile"


# static fields
.field public static final d:Ld2/b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ld2/b;

    .line 2
    .line 3
    const/4 v1, 0x5

    .line 4
    invoke-direct {v0, v1}, Ld2/b;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Le0/q;->d:Ld2/b;

    .line 8
    .line 9
    return-void
.end method
