.class public interface abstract Le0/m;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method

.method public abstract b(Ljava/lang/CharSequence;IILe0/u;)Z
.end method
