.class public interface abstract Le0/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LK3/h;)V
.end method
