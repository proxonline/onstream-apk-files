.class public final Le0/y;
.super Ld5/k;
.source "SourceFile"


# virtual methods
.method public final D(Ljava/lang/CharSequence;)Z
    .locals 0

    .line 1
    invoke-static {p1}, LG3/d;->z(Ljava/lang/CharSequence;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    if-nez p1, :cond_0

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    return p1

    .line 9
    :cond_0
    const/4 p1, 0x1

    .line 10
    return p1
.end method
