.class public abstract Li2/j;
.super Li2/g;
.source "SourceFile"
