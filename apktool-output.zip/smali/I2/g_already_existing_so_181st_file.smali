.class public abstract Li2/g;
.super LS0/b;
.source "SourceFile"


# instance fields
.field public c:J


# virtual methods
.method public abstract r()V
.end method
