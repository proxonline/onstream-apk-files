.class public final Li2/e;
.super Ljava/lang/IllegalStateException;
.source "SourceFile"
