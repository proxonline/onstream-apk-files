.class public interface abstract annotation LI5/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation system Ldalvik/annotation/AnnotationDefault;
    value = .subannotation LI5/e;
        intEncoding = .enum LI5/d;->a:LI5/d;
    .end subannotation
.end annotation
