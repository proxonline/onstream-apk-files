.class public abstract LI5/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG5/a;


# static fields
.field public static final a:LH5/a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LH5/a;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, v1}, LH5/a;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LI5/g;->a:LH5/a;

    .line 8
    .line 9
    return-void
.end method
