.class public final LH0/r;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lkotlin/jvm/internal/d;

.field public final b:Landroid/content/Context;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/util/ArrayList;

.field public final e:Ljava/util/ArrayList;

.field public f:Ljava/util/concurrent/Executor;

.field public g:Ljava/util/concurrent/Executor;

.field public h:LU1/k;

.field public i:Z

.field public final j:LH0/t;

.field public final k:J

.field public final l:LH0/u;

.field public final m:Ljava/util/LinkedHashSet;

.field public final n:Ljava/util/LinkedHashSet;

.field public final o:Ljava/util/ArrayList;

.field public p:Z

.field public q:Z

.field public r:Z

.field public final s:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/Class;Ljava/lang/String;)V
    .locals 2

    .line 1
    const-string v0, "context"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    new-instance v0, Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, LH0/r;->d:Ljava/util/ArrayList;

    .line 15
    .line 16
    new-instance v0, Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object v0, p0, LH0/r;->e:Ljava/util/ArrayList;

    .line 22
    .line 23
    sget-object v0, LH0/t;->a:LH0/t;

    .line 24
    .line 25
    iput-object v0, p0, LH0/r;->j:LH0/t;

    .line 26
    .line 27
    const-wide/16 v0, -0x1

    .line 28
    .line 29
    iput-wide v0, p0, LH0/r;->k:J

    .line 30
    .line 31
    new-instance v0, LH0/u;

    .line 32
    .line 33
    const/4 v1, 0x0

    .line 34
    invoke-direct {v0, v1}, LH0/u;-><init>(I)V

    .line 35
    .line 36
    .line 37
    iput-object v0, p0, LH0/r;->l:LH0/u;

    .line 38
    .line 39
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 40
    .line 41
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 42
    .line 43
    .line 44
    iput-object v0, p0, LH0/r;->m:Ljava/util/LinkedHashSet;

    .line 45
    .line 46
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 47
    .line 48
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 49
    .line 50
    .line 51
    iput-object v0, p0, LH0/r;->n:Ljava/util/LinkedHashSet;

    .line 52
    .line 53
    new-instance v0, Ljava/util/ArrayList;

    .line 54
    .line 55
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 56
    .line 57
    .line 58
    iput-object v0, p0, LH0/r;->o:Ljava/util/ArrayList;

    .line 59
    .line 60
    const/4 v0, 0x1

    .line 61
    iput-boolean v0, p0, LH0/r;->p:Z

    .line 62
    .line 63
    iput-boolean v0, p0, LH0/r;->s:Z

    .line 64
    .line 65
    invoke-static {p2}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 66
    .line 67
    .line 68
    move-result-object p2

    .line 69
    iput-object p2, p0, LH0/r;->a:Lkotlin/jvm/internal/d;

    .line 70
    .line 71
    iput-object p1, p0, LH0/r;->b:Landroid/content/Context;

    .line 72
    .line 73
    iput-object p3, p0, LH0/r;->c:Ljava/lang/String;

    .line 74
    .line 75
    return-void
.end method


# virtual methods
.method public final varargs a([LL0/a;)V
    .locals 6

    .line 1
    array-length v0, p1

    .line 2
    const/4 v1, 0x0

    .line 3
    move v2, v1

    .line 4
    :goto_0
    if-ge v2, v0, :cond_0

    .line 5
    .line 6
    aget-object v3, p1, v2

    .line 7
    .line 8
    iget v4, v3, LL0/a;->a:I

    .line 9
    .line 10
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 11
    .line 12
    .line 13
    move-result-object v4

    .line 14
    iget-object v5, p0, LH0/r;->n:Ljava/util/LinkedHashSet;

    .line 15
    .line 16
    invoke-interface {v5, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    iget v3, v3, LL0/a;->b:I

    .line 20
    .line 21
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    invoke-interface {v5, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    add-int/lit8 v2, v2, 0x1

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    array-length v0, p1

    .line 32
    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    check-cast p1, [LL0/a;

    .line 37
    .line 38
    iget-object v0, p0, LH0/r;->l:LH0/u;

    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    const-string v2, "migrations"

    .line 44
    .line 45
    invoke-static {p1, v2}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    array-length v2, p1

    .line 49
    :goto_1
    if-ge v1, v2, :cond_1

    .line 50
    .line 51
    aget-object v3, p1, v1

    .line 52
    .line 53
    invoke-virtual {v0, v3}, LH0/u;->a(LL0/a;)V

    .line 54
    .line 55
    .line 56
    add-int/lit8 v1, v1, 0x1

    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_1
    return-void
.end method

.method public final b()LH0/w;
    .locals 25

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-object v0, v1, LH0/r;->f:Ljava/util/concurrent/Executor;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-object v2, v1, LH0/r;->g:Ljava/util/concurrent/Executor;

    .line 8
    .line 9
    if-nez v2, :cond_0

    .line 10
    .line 11
    sget-object v0, Lp/a;->l:LD0/e;

    .line 12
    .line 13
    iput-object v0, v1, LH0/r;->g:Ljava/util/concurrent/Executor;

    .line 14
    .line 15
    iput-object v0, v1, LH0/r;->f:Ljava/util/concurrent/Executor;

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    if-eqz v0, :cond_1

    .line 19
    .line 20
    iget-object v2, v1, LH0/r;->g:Ljava/util/concurrent/Executor;

    .line 21
    .line 22
    if-nez v2, :cond_1

    .line 23
    .line 24
    iput-object v0, v1, LH0/r;->g:Ljava/util/concurrent/Executor;

    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_1
    if-nez v0, :cond_2

    .line 28
    .line 29
    iget-object v0, v1, LH0/r;->g:Ljava/util/concurrent/Executor;

    .line 30
    .line 31
    iput-object v0, v1, LH0/r;->f:Ljava/util/concurrent/Executor;

    .line 32
    .line 33
    :cond_2
    :goto_0
    const-string v0, "migrationStartAndEndVersions"

    .line 34
    .line 35
    iget-object v2, v1, LH0/r;->n:Ljava/util/LinkedHashSet;

    .line 36
    .line 37
    invoke-static {v2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    const-string v0, "migrationsNotRequiredFrom"

    .line 41
    .line 42
    iget-object v3, v1, LH0/r;->m:Ljava/util/LinkedHashSet;

    .line 43
    .line 44
    invoke-static {v3, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_4

    .line 52
    .line 53
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    if-eqz v2, :cond_4

    .line 62
    .line 63
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    check-cast v2, Ljava/lang/Number;

    .line 68
    .line 69
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    invoke-interface {v3, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v4

    .line 81
    if-nez v4, :cond_3

    .line 82
    .line 83
    goto :goto_1

    .line 84
    :cond_3
    const-string v0, "Inconsistency detected. A Migration was supplied to addMigration() that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(). Start version is: "

    .line 85
    .line 86
    invoke-static {v0, v2}, Lcom/google/android/gms/internal/cast/z1;->k(Ljava/lang/String;I)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 91
    .line 92
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    throw v2

    .line 100
    :cond_4
    iget-object v0, v1, LH0/r;->h:LU1/k;

    .line 101
    .line 102
    if-nez v0, :cond_5

    .line 103
    .line 104
    new-instance v0, LK5/f;

    .line 105
    .line 106
    const/16 v2, 0x14

    .line 107
    .line 108
    invoke-direct {v0, v2}, LK5/f;-><init>(I)V

    .line 109
    .line 110
    .line 111
    :cond_5
    move-object v6, v0

    .line 112
    iget-wide v4, v1, LH0/r;->k:J

    .line 113
    .line 114
    const-wide/16 v7, 0x0

    .line 115
    .line 116
    cmp-long v0, v4, v7

    .line 117
    .line 118
    const/4 v4, 0x1

    .line 119
    if-lez v0, :cond_6

    .line 120
    .line 121
    move v0, v4

    .line 122
    goto :goto_2

    .line 123
    :cond_6
    const/4 v0, 0x0

    .line 124
    :goto_2
    const-string v5, "Required value was null."

    .line 125
    .line 126
    if-eqz v0, :cond_8

    .line 127
    .line 128
    iget-object v0, v1, LH0/r;->c:Ljava/lang/String;

    .line 129
    .line 130
    if-eqz v0, :cond_7

    .line 131
    .line 132
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 133
    .line 134
    invoke-direct {v0, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    throw v0

    .line 138
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 139
    .line 140
    const-string v2, "Cannot create auto-closing database for an in-memory database."

    .line 141
    .line 142
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 143
    .line 144
    .line 145
    throw v0

    .line 146
    :cond_8
    move-object/from16 v16, v3

    .line 147
    .line 148
    new-instance v3, LH0/a;

    .line 149
    .line 150
    iget-boolean v9, v1, LH0/r;->i:Z

    .line 151
    .line 152
    iget-object v0, v1, LH0/r;->j:LH0/t;

    .line 153
    .line 154
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 155
    .line 156
    .line 157
    const-string v7, "context"

    .line 158
    .line 159
    move v8, v4

    .line 160
    iget-object v4, v1, LH0/r;->b:Landroid/content/Context;

    .line 161
    .line 162
    invoke-static {v4, v7}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 163
    .line 164
    .line 165
    sget-object v7, LH0/t;->a:LH0/t;

    .line 166
    .line 167
    if-eq v0, v7, :cond_9

    .line 168
    .line 169
    goto :goto_4

    .line 170
    :cond_9
    const-string v0, "activity"

    .line 171
    .line 172
    invoke-virtual {v4, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    instance-of v7, v0, Landroid/app/ActivityManager;

    .line 177
    .line 178
    if-eqz v7, :cond_a

    .line 179
    .line 180
    check-cast v0, Landroid/app/ActivityManager;

    .line 181
    .line 182
    goto :goto_3

    .line 183
    :cond_a
    const/4 v0, 0x0

    .line 184
    :goto_3
    if-eqz v0, :cond_b

    .line 185
    .line 186
    invoke-virtual {v0}, Landroid/app/ActivityManager;->isLowRamDevice()Z

    .line 187
    .line 188
    .line 189
    move-result v0

    .line 190
    if-nez v0, :cond_b

    .line 191
    .line 192
    sget-object v0, LH0/t;->c:LH0/t;

    .line 193
    .line 194
    goto :goto_4

    .line 195
    :cond_b
    sget-object v0, LH0/t;->b:LH0/t;

    .line 196
    .line 197
    :goto_4
    iget-object v11, v1, LH0/r;->f:Ljava/util/concurrent/Executor;

    .line 198
    .line 199
    if-eqz v11, :cond_31

    .line 200
    .line 201
    iget-object v12, v1, LH0/r;->g:Ljava/util/concurrent/Executor;

    .line 202
    .line 203
    if-eqz v12, :cond_30

    .line 204
    .line 205
    iget-boolean v14, v1, LH0/r;->p:Z

    .line 206
    .line 207
    iget-boolean v15, v1, LH0/r;->q:Z

    .line 208
    .line 209
    iget-boolean v5, v1, LH0/r;->r:Z

    .line 210
    .line 211
    const/16 v23, 0x0

    .line 212
    .line 213
    const/16 v24, 0x0

    .line 214
    .line 215
    move/from16 v22, v5

    .line 216
    .line 217
    iget-object v5, v1, LH0/r;->c:Ljava/lang/String;

    .line 218
    .line 219
    iget-object v7, v1, LH0/r;->l:LH0/u;

    .line 220
    .line 221
    move v13, v8

    .line 222
    iget-object v8, v1, LH0/r;->d:Ljava/util/ArrayList;

    .line 223
    .line 224
    move/from16 v17, v13

    .line 225
    .line 226
    const/4 v13, 0x0

    .line 227
    move/from16 v18, v17

    .line 228
    .line 229
    const/16 v17, 0x0

    .line 230
    .line 231
    move/from16 v19, v18

    .line 232
    .line 233
    const/16 v18, 0x0

    .line 234
    .line 235
    move/from16 v20, v19

    .line 236
    .line 237
    const/16 v19, 0x0

    .line 238
    .line 239
    iget-object v2, v1, LH0/r;->e:Ljava/util/ArrayList;

    .line 240
    .line 241
    iget-object v10, v1, LH0/r;->o:Ljava/util/ArrayList;

    .line 242
    .line 243
    move/from16 v21, v20

    .line 244
    .line 245
    move-object/from16 v20, v2

    .line 246
    .line 247
    move/from16 v2, v21

    .line 248
    .line 249
    move-object/from16 v21, v10

    .line 250
    .line 251
    move-object v10, v0

    .line 252
    const/4 v0, 0x0

    .line 253
    invoke-direct/range {v3 .. v24}, LH0/a;-><init>(Landroid/content/Context;Ljava/lang/String;LS0/c;LH0/u;Ljava/util/List;ZLH0/t;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Landroid/content/Intent;ZZLjava/util/Set;Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;Ljava/util/List;Ljava/util/List;ZLR0/b;Lh8/i;)V

    .line 254
    .line 255
    .line 256
    iget-boolean v4, v1, LH0/r;->s:Z

    .line 257
    .line 258
    iput-boolean v4, v3, LH0/a;->v:Z

    .line 259
    .line 260
    iget-object v4, v1, LH0/r;->a:Lkotlin/jvm/internal/d;

    .line 261
    .line 262
    invoke-static {v4}, Lv5/u0;->u(Lx8/c;)Ljava/lang/Class;

    .line 263
    .line 264
    .line 265
    move-result-object v4

    .line 266
    invoke-virtual {v4}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;

    .line 267
    .line 268
    .line 269
    move-result-object v5

    .line 270
    if-eqz v5, :cond_c

    .line 271
    .line 272
    invoke-virtual {v5}, Ljava/lang/Package;->getName()Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object v5

    .line 276
    if-nez v5, :cond_d

    .line 277
    .line 278
    :cond_c
    const-string v5, ""

    .line 279
    .line 280
    :cond_d
    invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v6

    .line 284
    invoke-static {v6}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 285
    .line 286
    .line 287
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 288
    .line 289
    .line 290
    move-result v7

    .line 291
    if-nez v7, :cond_e

    .line 292
    .line 293
    goto :goto_5

    .line 294
    :cond_e
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 295
    .line 296
    .line 297
    move-result v7

    .line 298
    add-int/2addr v7, v2

    .line 299
    invoke-virtual {v6, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object v6

    .line 303
    const-string v7, "substring(...)"

    .line 304
    .line 305
    invoke-static {v6, v7}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    :goto_5
    const/16 v7, 0x5f

    .line 309
    .line 310
    const/16 v8, 0x2e

    .line 311
    .line 312
    invoke-virtual {v6, v8, v7}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v6

    .line 316
    const-string v7, "replace(...)"

    .line 317
    .line 318
    invoke-static {v6, v7}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 319
    .line 320
    .line 321
    const-string v7, "_Impl"

    .line 322
    .line 323
    invoke-virtual {v6, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 324
    .line 325
    .line 326
    move-result-object v6

    .line 327
    :try_start_0
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    .line 328
    .line 329
    .line 330
    move-result v7

    .line 331
    if-nez v7, :cond_f

    .line 332
    .line 333
    move-object v5, v6

    .line 334
    goto :goto_6

    .line 335
    :cond_f
    new-instance v7, Ljava/lang/StringBuilder;

    .line 336
    .line 337
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 338
    .line 339
    .line 340
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 341
    .line 342
    .line 343
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 344
    .line 345
    .line 346
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 347
    .line 348
    .line 349
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object v5

    .line 353
    :goto_6
    invoke-virtual {v4}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 354
    .line 355
    .line 356
    move-result-object v7

    .line 357
    invoke-static {v5, v2, v7}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 358
    .line 359
    .line 360
    move-result-object v5

    .line 361
    const-string v7, "null cannot be cast to non-null type java.lang.Class<T of androidx.room.util.KClassUtil.findAndInstantiateDatabaseImpl>"

    .line 362
    .line 363
    invoke-static {v5, v7}, Lkotlin/jvm/internal/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 364
    .line 365
    .line 366
    invoke-virtual {v5, v0}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 367
    .line 368
    .line 369
    move-result-object v5

    .line 370
    invoke-virtual {v5, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 371
    .line 372
    .line 373
    move-result-object v4
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_1

    .line 374
    check-cast v4, LH0/w;

    .line 375
    .line 376
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 377
    .line 378
    .line 379
    iget-boolean v5, v3, LH0/a;->v:Z

    .line 380
    .line 381
    iput-boolean v5, v4, LH0/w;->k:Z

    .line 382
    .line 383
    :try_start_1
    invoke-virtual {v4}, LH0/w;->f()LG0/N;

    .line 384
    .line 385
    .line 386
    move-result-object v10

    .line 387
    const-string v5, "null cannot be cast to non-null type androidx.room.RoomOpenDelegate"

    .line 388
    .line 389
    invoke-static {v10, v5}, Lkotlin/jvm/internal/h;->c(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_1
    .catch Ld8/f; {:try_start_1 .. :try_end_1} :catch_0

    .line 390
    .line 391
    .line 392
    goto :goto_7

    .line 393
    :catch_0
    move-object v10, v0

    .line 394
    :goto_7
    if-nez v10, :cond_10

    .line 395
    .line 396
    new-instance v5, LH0/q;

    .line 397
    .line 398
    new-instance v6, LE1/a;

    .line 399
    .line 400
    const/4 v7, 0x2

    .line 401
    invoke-direct {v6, v7, v4}, LE1/a;-><init>(ILjava/lang/Object;)V

    .line 402
    .line 403
    .line 404
    invoke-direct {v5, v3, v6}, LH0/q;-><init>(LH0/a;LE1/a;)V

    .line 405
    .line 406
    .line 407
    goto :goto_8

    .line 408
    :cond_10
    new-instance v5, LH0/q;

    .line 409
    .line 410
    invoke-direct {v5, v3, v10}, LH0/q;-><init>(LH0/a;LG0/N;)V

    .line 411
    .line 412
    .line 413
    :goto_8
    iput-object v5, v4, LH0/w;->e:LH0/q;

    .line 414
    .line 415
    invoke-virtual {v4}, LH0/w;->e()LH0/h;

    .line 416
    .line 417
    .line 418
    move-result-object v5

    .line 419
    iput-object v5, v4, LH0/w;->f:LH0/h;

    .line 420
    .line 421
    new-instance v5, Ljava/util/LinkedHashMap;

    .line 422
    .line 423
    invoke-direct {v5}, Ljava/util/LinkedHashMap;-><init>()V

    .line 424
    .line 425
    .line 426
    invoke-virtual {v4}, LH0/w;->j()Ljava/util/Set;

    .line 427
    .line 428
    .line 429
    move-result-object v6

    .line 430
    iget-object v7, v3, LH0/a;->r:Ljava/util/List;

    .line 431
    .line 432
    invoke-interface {v7}, Ljava/util/List;->size()I

    .line 433
    .line 434
    .line 435
    move-result v8

    .line 436
    new-array v9, v8, [Z

    .line 437
    .line 438
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 439
    .line 440
    .line 441
    move-result-object v6

    .line 442
    :goto_9
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 443
    .line 444
    .line 445
    move-result v10

    .line 446
    const/4 v11, -0x1

    .line 447
    if-eqz v10, :cond_15

    .line 448
    .line 449
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 450
    .line 451
    .line 452
    move-result-object v10

    .line 453
    check-cast v10, Lx8/c;

    .line 454
    .line 455
    invoke-interface {v7}, Ljava/util/Collection;->size()I

    .line 456
    .line 457
    .line 458
    move-result v12

    .line 459
    add-int/2addr v12, v11

    .line 460
    if-ltz v12, :cond_13

    .line 461
    .line 462
    :goto_a
    add-int/lit8 v13, v12, -0x1

    .line 463
    .line 464
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 465
    .line 466
    .line 467
    move-result-object v14

    .line 468
    move-object v15, v10

    .line 469
    check-cast v15, Lkotlin/jvm/internal/d;

    .line 470
    .line 471
    invoke-virtual {v15, v14}, Lkotlin/jvm/internal/d;->d(Ljava/lang/Object;)Z

    .line 472
    .line 473
    .line 474
    move-result v14

    .line 475
    if-eqz v14, :cond_11

    .line 476
    .line 477
    aput-boolean v2, v9, v12

    .line 478
    .line 479
    move v11, v12

    .line 480
    goto :goto_b

    .line 481
    :cond_11
    if-gez v13, :cond_12

    .line 482
    .line 483
    goto :goto_b

    .line 484
    :cond_12
    move v12, v13

    .line 485
    goto :goto_a

    .line 486
    :cond_13
    :goto_b
    if-ltz v11, :cond_14

    .line 487
    .line 488
    invoke-interface {v7, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 489
    .line 490
    .line 491
    move-result-object v11

    .line 492
    invoke-interface {v5, v10, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 493
    .line 494
    .line 495
    goto :goto_9

    .line 496
    :cond_14
    new-instance v0, Ljava/lang/StringBuilder;

    .line 497
    .line 498
    const-string v2, "A required auto migration spec ("

    .line 499
    .line 500
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 501
    .line 502
    .line 503
    check-cast v10, Lkotlin/jvm/internal/d;

    .line 504
    .line 505
    invoke-virtual {v10}, Lkotlin/jvm/internal/d;->b()Ljava/lang/String;

    .line 506
    .line 507
    .line 508
    move-result-object v2

    .line 509
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 510
    .line 511
    .line 512
    const-string v2, ") is missing in the database configuration."

    .line 513
    .line 514
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 515
    .line 516
    .line 517
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 518
    .line 519
    .line 520
    move-result-object v0

    .line 521
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 522
    .line 523
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 524
    .line 525
    .line 526
    move-result-object v0

    .line 527
    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 528
    .line 529
    .line 530
    throw v2

    .line 531
    :cond_15
    invoke-interface {v7}, Ljava/util/Collection;->size()I

    .line 532
    .line 533
    .line 534
    move-result v6

    .line 535
    add-int/2addr v6, v11

    .line 536
    if-ltz v6, :cond_18

    .line 537
    .line 538
    :goto_c
    add-int/lit8 v7, v6, -0x1

    .line 539
    .line 540
    if-ge v6, v8, :cond_17

    .line 541
    .line 542
    aget-boolean v6, v9, v6

    .line 543
    .line 544
    if-eqz v6, :cond_17

    .line 545
    .line 546
    if-gez v7, :cond_16

    .line 547
    .line 548
    goto :goto_d

    .line 549
    :cond_16
    move v6, v7

    .line 550
    goto :goto_c

    .line 551
    :cond_17
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 552
    .line 553
    const-string v2, "Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder."

    .line 554
    .line 555
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 556
    .line 557
    .line 558
    throw v0

    .line 559
    :cond_18
    :goto_d
    invoke-virtual {v4, v5}, LH0/w;->d(Ljava/util/LinkedHashMap;)Ljava/util/List;

    .line 560
    .line 561
    .line 562
    move-result-object v5

    .line 563
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 564
    .line 565
    .line 566
    move-result-object v5

    .line 567
    :cond_19
    :goto_e
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 568
    .line 569
    .line 570
    move-result v6

    .line 571
    if-eqz v6, :cond_1c

    .line 572
    .line 573
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 574
    .line 575
    .line 576
    move-result-object v6

    .line 577
    check-cast v6, LL0/a;

    .line 578
    .line 579
    iget v7, v6, LL0/a;->a:I

    .line 580
    .line 581
    iget v8, v6, LL0/a;->b:I

    .line 582
    .line 583
    iget-object v9, v3, LH0/a;->d:LH0/u;

    .line 584
    .line 585
    iget-object v10, v9, LH0/u;->a:Ljava/util/LinkedHashMap;

    .line 586
    .line 587
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 588
    .line 589
    .line 590
    move-result-object v12

    .line 591
    invoke-interface {v10, v12}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 592
    .line 593
    .line 594
    move-result v12

    .line 595
    if-eqz v12, :cond_1b

    .line 596
    .line 597
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 598
    .line 599
    .line 600
    move-result-object v7

    .line 601
    invoke-virtual {v10, v7}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 602
    .line 603
    .line 604
    move-result-object v7

    .line 605
    check-cast v7, Ljava/util/Map;

    .line 606
    .line 607
    if-nez v7, :cond_1a

    .line 608
    .line 609
    sget-object v7, Le8/r;->a:Le8/r;

    .line 610
    .line 611
    :cond_1a
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 612
    .line 613
    .line 614
    move-result-object v8

    .line 615
    invoke-interface {v7, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 616
    .line 617
    .line 618
    move-result v7

    .line 619
    goto :goto_f

    .line 620
    :cond_1b
    const/4 v7, 0x0

    .line 621
    :goto_f
    if-nez v7, :cond_19

    .line 622
    .line 623
    invoke-virtual {v9, v6}, LH0/u;->a(LL0/a;)V

    .line 624
    .line 625
    .line 626
    goto :goto_e

    .line 627
    :cond_1c
    invoke-virtual {v4}, LH0/w;->k()Ljava/util/LinkedHashMap;

    .line 628
    .line 629
    .line 630
    move-result-object v5

    .line 631
    iget-object v6, v3, LH0/a;->q:Ljava/util/List;

    .line 632
    .line 633
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 634
    .line 635
    .line 636
    move-result v7

    .line 637
    new-array v7, v7, [Z

    .line 638
    .line 639
    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 640
    .line 641
    .line 642
    move-result-object v5

    .line 643
    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 644
    .line 645
    .line 646
    move-result-object v5

    .line 647
    :cond_1d
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 648
    .line 649
    .line 650
    move-result v8

    .line 651
    if-eqz v8, :cond_22

    .line 652
    .line 653
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 654
    .line 655
    .line 656
    move-result-object v8

    .line 657
    check-cast v8, Ljava/util/Map$Entry;

    .line 658
    .line 659
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 660
    .line 661
    .line 662
    move-result-object v9

    .line 663
    check-cast v9, Lx8/c;

    .line 664
    .line 665
    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 666
    .line 667
    .line 668
    move-result-object v8

    .line 669
    check-cast v8, Ljava/util/List;

    .line 670
    .line 671
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 672
    .line 673
    .line 674
    move-result-object v8

    .line 675
    :goto_10
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 676
    .line 677
    .line 678
    move-result v10

    .line 679
    if-eqz v10, :cond_1d

    .line 680
    .line 681
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 682
    .line 683
    .line 684
    move-result-object v10

    .line 685
    check-cast v10, Lx8/c;

    .line 686
    .line 687
    invoke-interface {v6}, Ljava/util/Collection;->size()I

    .line 688
    .line 689
    .line 690
    move-result v12

    .line 691
    add-int/2addr v12, v11

    .line 692
    if-ltz v12, :cond_20

    .line 693
    .line 694
    :goto_11
    add-int/lit8 v13, v12, -0x1

    .line 695
    .line 696
    invoke-interface {v6, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 697
    .line 698
    .line 699
    move-result-object v14

    .line 700
    move-object v15, v10

    .line 701
    check-cast v15, Lkotlin/jvm/internal/d;

    .line 702
    .line 703
    invoke-virtual {v15, v14}, Lkotlin/jvm/internal/d;->d(Ljava/lang/Object;)Z

    .line 704
    .line 705
    .line 706
    move-result v14

    .line 707
    if-eqz v14, :cond_1e

    .line 708
    .line 709
    aput-boolean v2, v7, v12

    .line 710
    .line 711
    goto :goto_13

    .line 712
    :cond_1e
    if-gez v13, :cond_1f

    .line 713
    .line 714
    goto :goto_12

    .line 715
    :cond_1f
    move v12, v13

    .line 716
    goto :goto_11

    .line 717
    :cond_20
    :goto_12
    move v12, v11

    .line 718
    :goto_13
    if-ltz v12, :cond_21

    .line 719
    .line 720
    invoke-interface {v6, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 721
    .line 722
    .line 723
    move-result-object v12

    .line 724
    const-string v13, "kclass"

    .line 725
    .line 726
    invoke-static {v10, v13}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 727
    .line 728
    .line 729
    const-string v13, "converter"

    .line 730
    .line 731
    invoke-static {v12, v13}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 732
    .line 733
    .line 734
    iget-object v13, v4, LH0/w;->j:Ljava/util/LinkedHashMap;

    .line 735
    .line 736
    invoke-interface {v13, v10, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 737
    .line 738
    .line 739
    goto :goto_10

    .line 740
    :cond_21
    new-instance v0, Ljava/lang/StringBuilder;

    .line 741
    .line 742
    const-string v2, "A required type converter ("

    .line 743
    .line 744
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 745
    .line 746
    .line 747
    check-cast v10, Lkotlin/jvm/internal/d;

    .line 748
    .line 749
    invoke-virtual {v10}, Lkotlin/jvm/internal/d;->b()Ljava/lang/String;

    .line 750
    .line 751
    .line 752
    move-result-object v2

    .line 753
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 754
    .line 755
    .line 756
    const-string v2, ") for "

    .line 757
    .line 758
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 759
    .line 760
    .line 761
    check-cast v9, Lkotlin/jvm/internal/d;

    .line 762
    .line 763
    invoke-virtual {v9}, Lkotlin/jvm/internal/d;->b()Ljava/lang/String;

    .line 764
    .line 765
    .line 766
    move-result-object v2

    .line 767
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 768
    .line 769
    .line 770
    const-string v2, " is missing in the database configuration."

    .line 771
    .line 772
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 773
    .line 774
    .line 775
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 776
    .line 777
    .line 778
    move-result-object v0

    .line 779
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 780
    .line 781
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 782
    .line 783
    .line 784
    move-result-object v0

    .line 785
    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 786
    .line 787
    .line 788
    throw v2

    .line 789
    :cond_22
    invoke-interface {v6}, Ljava/util/Collection;->size()I

    .line 790
    .line 791
    .line 792
    move-result v2

    .line 793
    add-int/2addr v2, v11

    .line 794
    if-ltz v2, :cond_25

    .line 795
    .line 796
    :goto_14
    add-int/lit8 v5, v2, -0x1

    .line 797
    .line 798
    aget-boolean v8, v7, v2

    .line 799
    .line 800
    if-eqz v8, :cond_24

    .line 801
    .line 802
    if-gez v5, :cond_23

    .line 803
    .line 804
    goto :goto_15

    .line 805
    :cond_23
    move v2, v5

    .line 806
    goto :goto_14

    .line 807
    :cond_24
    invoke-interface {v6, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 808
    .line 809
    .line 810
    move-result-object v0

    .line 811
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 812
    .line 813
    new-instance v3, Ljava/lang/StringBuilder;

    .line 814
    .line 815
    const-string v4, "Unexpected type converter "

    .line 816
    .line 817
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 818
    .line 819
    .line 820
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 821
    .line 822
    .line 823
    const-string v0, ". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder."

    .line 824
    .line 825
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 826
    .line 827
    .line 828
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 829
    .line 830
    .line 831
    move-result-object v0

    .line 832
    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 833
    .line 834
    .line 835
    throw v2

    .line 836
    :cond_25
    :goto_15
    iget-object v2, v3, LH0/a;->h:Ljava/util/concurrent/Executor;

    .line 837
    .line 838
    iput-object v2, v4, LH0/w;->c:Ljava/util/concurrent/Executor;

    .line 839
    .line 840
    new-instance v2, LH0/E;

    .line 841
    .line 842
    iget-object v5, v3, LH0/a;->i:Ljava/util/concurrent/Executor;

    .line 843
    .line 844
    invoke-direct {v2, v5}, LH0/E;-><init>(Ljava/util/concurrent/Executor;)V

    .line 845
    .line 846
    .line 847
    iput-object v2, v4, LH0/w;->d:LH0/E;

    .line 848
    .line 849
    iget-object v2, v4, LH0/w;->c:Ljava/util/concurrent/Executor;

    .line 850
    .line 851
    if-eqz v2, :cond_2f

    .line 852
    .line 853
    invoke-static {v2}, LB8/D;->j(Ljava/util/concurrent/Executor;)LB8/w;

    .line 854
    .line 855
    .line 856
    move-result-object v2

    .line 857
    invoke-static {}, LB8/D;->b()LB8/C0;

    .line 858
    .line 859
    .line 860
    move-result-object v5

    .line 861
    invoke-virtual {v2, v5}, Lh8/a;->plus(Lh8/i;)Lh8/i;

    .line 862
    .line 863
    .line 864
    move-result-object v2

    .line 865
    invoke-static {v2}, LB8/D;->a(Lh8/i;)LG8/e;

    .line 866
    .line 867
    .line 868
    move-result-object v2

    .line 869
    iput-object v2, v4, LH0/w;->a:LG8/e;

    .line 870
    .line 871
    iget-object v2, v2, LG8/e;->a:Lh8/i;

    .line 872
    .line 873
    iget-object v5, v4, LH0/w;->d:LH0/E;

    .line 874
    .line 875
    if-eqz v5, :cond_2e

    .line 876
    .line 877
    invoke-static {v5}, LB8/D;->j(Ljava/util/concurrent/Executor;)LB8/w;

    .line 878
    .line 879
    .line 880
    move-result-object v5

    .line 881
    invoke-interface {v2, v5}, Lh8/i;->plus(Lh8/i;)Lh8/i;

    .line 882
    .line 883
    .line 884
    move-result-object v2

    .line 885
    iput-object v2, v4, LH0/w;->b:Lh8/i;

    .line 886
    .line 887
    iget-boolean v2, v3, LH0/a;->f:Z

    .line 888
    .line 889
    iput-boolean v2, v4, LH0/w;->h:Z

    .line 890
    .line 891
    iget-object v2, v4, LH0/w;->e:LH0/q;

    .line 892
    .line 893
    const-string v3, "connectionManager"

    .line 894
    .line 895
    if-eqz v2, :cond_2d

    .line 896
    .line 897
    invoke-virtual {v2}, LH0/q;->c()LS0/d;

    .line 898
    .line 899
    .line 900
    move-result-object v2

    .line 901
    if-nez v2, :cond_27

    .line 902
    .line 903
    :cond_26
    move-object v10, v0

    .line 904
    goto :goto_17

    .line 905
    :cond_27
    move-object v10, v2

    .line 906
    :goto_16
    nop

    .line 907
    instance-of v2, v10, LM0/b;

    .line 908
    .line 909
    if-eqz v2, :cond_28

    .line 910
    .line 911
    goto :goto_17

    .line 912
    :cond_28
    instance-of v2, v10, LH0/b;

    .line 913
    .line 914
    if-eqz v2, :cond_26

    .line 915
    .line 916
    check-cast v10, LH0/b;

    .line 917
    .line 918
    invoke-interface {v10}, LH0/b;->a()LS0/d;

    .line 919
    .line 920
    .line 921
    move-result-object v10

    .line 922
    goto :goto_16

    .line 923
    :goto_17
    check-cast v10, LM0/b;

    .line 924
    .line 925
    iget-object v2, v4, LH0/w;->e:LH0/q;

    .line 926
    .line 927
    if-eqz v2, :cond_2c

    .line 928
    .line 929
    invoke-virtual {v2}, LH0/q;->c()LS0/d;

    .line 930
    .line 931
    .line 932
    move-result-object v2

    .line 933
    if-nez v2, :cond_2a

    .line 934
    .line 935
    :cond_29
    move-object v10, v0

    .line 936
    goto :goto_19

    .line 937
    :cond_2a
    move-object v10, v2

    .line 938
    :goto_18
    nop

    .line 939
    instance-of v2, v10, LM0/a;

    .line 940
    .line 941
    if-eqz v2, :cond_2b

    .line 942
    .line 943
    goto :goto_19

    .line 944
    :cond_2b
    instance-of v2, v10, LH0/b;

    .line 945
    .line 946
    if-eqz v2, :cond_29

    .line 947
    .line 948
    check-cast v10, LH0/b;

    .line 949
    .line 950
    invoke-interface {v10}, LH0/b;->a()LS0/d;

    .line 951
    .line 952
    .line 953
    move-result-object v10

    .line 954
    goto :goto_18

    .line 955
    :goto_19
    check-cast v10, LM0/a;

    .line 956
    .line 957
    return-object v4

    .line 958
    :cond_2c
    invoke-static {v3}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 959
    .line 960
    .line 961
    throw v0

    .line 962
    :cond_2d
    invoke-static {v3}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 963
    .line 964
    .line 965
    throw v0

    .line 966
    :cond_2e
    const-string v2, "internalTransactionExecutor"

    .line 967
    .line 968
    invoke-static {v2}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 969
    .line 970
    .line 971
    throw v0

    .line 972
    :cond_2f
    const-string v2, "internalQueryExecutor"

    .line 973
    .line 974
    invoke-static {v2}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 975
    .line 976
    .line 977
    throw v0

    .line 978
    :catch_1
    move-exception v0

    .line 979
    goto :goto_1a

    .line 980
    :catch_2
    move-exception v0

    .line 981
    goto :goto_1b

    .line 982
    :catch_3
    move-exception v0

    .line 983
    goto :goto_1c

    .line 984
    :goto_1a
    new-instance v2, Ljava/lang/RuntimeException;

    .line 985
    .line 986
    new-instance v3, Ljava/lang/StringBuilder;

    .line 987
    .line 988
    const-string v5, "Failed to create an instance of "

    .line 989
    .line 990
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 991
    .line 992
    .line 993
    invoke-static {v4, v3}, LB0/a;->k(Ljava/lang/Class;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 994
    .line 995
    .line 996
    move-result-object v3

    .line 997
    invoke-direct {v2, v3, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 998
    .line 999
    .line 1000
    throw v2

    .line 1001
    :goto_1b
    new-instance v2, Ljava/lang/RuntimeException;

    .line 1002
    .line 1003
    new-instance v3, Ljava/lang/StringBuilder;

    .line 1004
    .line 1005
    const-string v5, "Cannot access the constructor "

    .line 1006
    .line 1007
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1008
    .line 1009
    .line 1010
    invoke-static {v4, v3}, LB0/a;->k(Ljava/lang/Class;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1011
    .line 1012
    .line 1013
    move-result-object v3

    .line 1014
    invoke-direct {v2, v3, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 1015
    .line 1016
    .line 1017
    throw v2

    .line 1018
    :goto_1c
    new-instance v2, Ljava/lang/RuntimeException;

    .line 1019
    .line 1020
    new-instance v3, Ljava/lang/StringBuilder;

    .line 1021
    .line 1022
    const-string v5, "Cannot find implementation for "

    .line 1023
    .line 1024
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1025
    .line 1026
    .line 1027
    invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 1028
    .line 1029
    .line 1030
    move-result-object v4

    .line 1031
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1032
    .line 1033
    .line 1034
    const-string v4, ". "

    .line 1035
    .line 1036
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1037
    .line 1038
    .line 1039
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1040
    .line 1041
    .line 1042
    const-string v4, " does not exist. Is Room annotation processor correctly configured?"

    .line 1043
    .line 1044
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1045
    .line 1046
    .line 1047
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1048
    .line 1049
    .line 1050
    move-result-object v3

    .line 1051
    invoke-direct {v2, v3, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 1052
    .line 1053
    .line 1054
    throw v2

    .line 1055
    :cond_30
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 1056
    .line 1057
    invoke-direct {v0, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1058
    .line 1059
    .line 1060
    throw v0

    .line 1061
    :cond_31
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 1062
    .line 1063
    invoke-direct {v0, v5}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1064
    .line 1065
    .line 1066
    throw v0
.end method
