.class public final LH0/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LX3/P0;Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x4

    iput v0, p0, LH0/y;->a:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LH0/y;->b:Ljava/lang/Object;

    iput-object p3, p0, LH0/y;->c:Ljava/lang/Object;

    iput-object p4, p0, LH0/y;->d:Ljava/lang/Object;

    invoke-static {p1}, Lj$/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p1, p0, LH0/y;->e:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p5, p0, LH0/y;->a:I

    iput-object p1, p0, LH0/y;->b:Ljava/lang/Object;

    iput-object p2, p0, LH0/y;->c:Ljava/lang/Object;

    iput-object p3, p0, LH0/y;->d:Ljava/lang/Object;

    iput-object p4, p0, LH0/y;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V
    .locals 0

    .line 2
    iput p5, p0, LH0/y;->a:I

    iput-object p2, p0, LH0/y;->b:Ljava/lang/Object;

    iput-object p3, p0, LH0/y;->c:Ljava/lang/Object;

    iput-object p4, p0, LH0/y;->d:Ljava/lang/Object;

    iput-object p1, p0, LH0/y;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a()V
    .locals 6

    .line 1
    iget-object v0, p0, LH0/y;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LX3/l1;

    .line 4
    .line 5
    iget-object v1, p0, LH0/y;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 8
    .line 9
    iget-object v2, p0, LH0/y;->d:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, LX3/O1;

    .line 12
    .line 13
    iget-object v3, p0, LH0/y;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v3, LX3/A1;

    .line 16
    .line 17
    monitor-enter v1

    .line 18
    :try_start_0
    iget-object v4, v0, LX3/l1;->d:LX3/H;

    .line 19
    .line 20
    if-nez v4, :cond_0

    .line 21
    .line 22
    iget-object v2, v0, LD/o;->a:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v2, LX3/n0;

    .line 25
    .line 26
    iget-object v2, v2, LX3/n0;->f:LX3/U;

    .line 27
    .line 28
    invoke-static {v2}, LX3/n0;->g(LX3/v0;)V

    .line 29
    .line 30
    .line 31
    iget-object v2, v2, LX3/U;->f:LP8/b;

    .line 32
    .line 33
    const-string v3, "[sgtm] Failed to get upload batches; not connected to service"

    .line 34
    .line 35
    invoke-virtual {v2, v3}, LP8/b;->b(Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 36
    .line 37
    .line 38
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 39
    return-void

    .line 40
    :catchall_0
    move-exception v0

    .line 41
    goto :goto_2

    .line 42
    :catch_0
    move-exception v2

    .line 43
    goto :goto_0

    .line 44
    :cond_0
    :try_start_2
    new-instance v5, LX3/e1;

    .line 45
    .line 46
    invoke-direct {v5, v0, v1}, LX3/e1;-><init>(LX3/l1;Ljava/util/concurrent/atomic/AtomicReference;)V

    .line 47
    .line 48
    .line 49
    invoke-interface {v4, v2, v3, v5}, LX3/H;->J0(LX3/O1;LX3/A1;LX3/L;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0}, LX3/l1;->E0()V
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 53
    .line 54
    .line 55
    goto :goto_1

    .line 56
    :goto_0
    :try_start_3
    iget-object v0, v0, LD/o;->a:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v0, LX3/n0;

    .line 59
    .line 60
    iget-object v0, v0, LX3/n0;->f:LX3/U;

    .line 61
    .line 62
    invoke-static {v0}, LX3/n0;->g(LX3/v0;)V

    .line 63
    .line 64
    .line 65
    iget-object v0, v0, LX3/U;->f:LP8/b;

    .line 66
    .line 67
    const-string v3, "[sgtm] Failed to get upload batches; remote exception"

    .line 68
    .line 69
    invoke-virtual {v0, v2, v3}, LP8/b;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    .line 73
    .line 74
    .line 75
    :goto_1
    monitor-exit v1

    .line 76
    return-void

    .line 77
    :goto_2
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 78
    throw v0
.end method


# virtual methods
.method public final run()V
    .locals 30

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, LH0/y;->a:I

    .line 4
    .line 5
    const-wide/16 v2, 0x0

    .line 6
    .line 7
    const/4 v4, 0x2

    .line 8
    const/4 v5, 0x1

    .line 9
    const/4 v6, 0x0

    .line 10
    const/4 v7, 0x0

    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Ls5/l;

    .line 17
    .line 18
    iget-object v2, v1, LH0/y;->e:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v2, Lv0/o;

    .line 21
    .line 22
    iget-object v3, v1, LH0/y;->c:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v3, Lv0/l;

    .line 25
    .line 26
    iget-object v4, v1, LH0/y;->d:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v4, Ljava/util/ArrayList;

    .line 29
    .line 30
    invoke-virtual {v0, v2, v3, v4}, Ls5/l;->b(Lv0/o;Lv0/l;Ljava/util/Collection;)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :pswitch_0
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v0, Ls5/l;

    .line 37
    .line 38
    iget-object v2, v1, LH0/y;->e:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v2, Lv0/o;

    .line 41
    .line 42
    iget-object v3, v1, LH0/y;->c:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v3, Lv0/l;

    .line 45
    .line 46
    iget-object v4, v1, LH0/y;->d:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v4, Ljava/util/Collection;

    .line 49
    .line 50
    invoke-virtual {v0, v2, v3, v4}, Ls5/l;->b(Lv0/o;Lv0/l;Ljava/util/Collection;)V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :pswitch_1
    iget-object v0, v1, LH0/y;->d:Ljava/lang/Object;

    .line 55
    .line 56
    move-object v2, v0

    .line 57
    check-cast v2, Lr1/j;

    .line 58
    .line 59
    const-string v0, "Ignoring setProgressAsync(...). WorkSpec ("

    .line 60
    .line 61
    iget-object v3, v1, LH0/y;->b:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v3, Ljava/util/UUID;

    .line 64
    .line 65
    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v8

    .line 69
    invoke-static {}, Lg1/q;->c()Lg1/q;

    .line 70
    .line 71
    .line 72
    move-result-object v9

    .line 73
    sget-object v10, Lq1/o;->c:Ljava/lang/String;

    .line 74
    .line 75
    iget-object v11, v1, LH0/y;->c:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v11, Lg1/h;

    .line 78
    .line 79
    new-instance v12, Ljava/lang/StringBuilder;

    .line 80
    .line 81
    const-string v13, "Updating progress for "

    .line 82
    .line 83
    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v12, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    const-string v3, " ("

    .line 90
    .line 91
    invoke-virtual {v12, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 92
    .line 93
    .line 94
    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    const-string v3, ")"

    .line 98
    .line 99
    invoke-virtual {v12, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    new-array v12, v7, [Ljava/lang/Throwable;

    .line 107
    .line 108
    invoke-virtual {v9, v10, v3, v12}, Lg1/q;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V

    .line 109
    .line 110
    .line 111
    iget-object v3, v1, LH0/y;->e:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v3, Lq1/o;

    .line 114
    .line 115
    iget-object v9, v3, Lq1/o;->a:Landroidx/work/impl/WorkDatabase;

    .line 116
    .line 117
    iget-object v3, v3, Lq1/o;->a:Landroidx/work/impl/WorkDatabase;

    .line 118
    .line 119
    invoke-virtual {v9}, LH0/w;->c()V

    .line 120
    .line 121
    .line 122
    :try_start_0
    invoke-virtual {v3}, Landroidx/work/impl/WorkDatabase;->x()LA5/f;

    .line 123
    .line 124
    .line 125
    move-result-object v9

    .line 126
    invoke-virtual {v9, v8}, LA5/f;->l(Ljava/lang/String;)Lp1/j;

    .line 127
    .line 128
    .line 129
    move-result-object v9

    .line 130
    if-eqz v9, :cond_1

    .line 131
    .line 132
    iget v9, v9, Lp1/j;->b:I

    .line 133
    .line 134
    if-ne v9, v4, :cond_0

    .line 135
    .line 136
    new-instance v0, Lp1/g;

    .line 137
    .line 138
    invoke-direct {v0, v8, v11}, Lp1/g;-><init>(Ljava/lang/String;Lg1/h;)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v3}, Landroidx/work/impl/WorkDatabase;->w()Ln1/g;

    .line 142
    .line 143
    .line 144
    move-result-object v4

    .line 145
    iget-object v8, v4, Ln1/g;->b:Ljava/lang/Object;

    .line 146
    .line 147
    check-cast v8, Landroidx/work/impl/WorkDatabase_Impl;

    .line 148
    .line 149
    invoke-virtual {v8}, LH0/w;->b()V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v8}, LH0/w;->c()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 153
    .line 154
    .line 155
    :try_start_1
    iget-object v4, v4, Ln1/g;->c:Ljava/lang/Object;

    .line 156
    .line 157
    check-cast v4, Lp1/b;

    .line 158
    .line 159
    invoke-virtual {v4, v0}, Lp1/b;->l(Ljava/lang/Object;)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {v8}, LH0/w;->q()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 163
    .line 164
    .line 165
    :try_start_2
    invoke-virtual {v8}, LH0/w;->n()V

    .line 166
    .line 167
    .line 168
    goto :goto_0

    .line 169
    :catchall_0
    move-exception v0

    .line 170
    invoke-virtual {v8}, LH0/w;->n()V

    .line 171
    .line 172
    .line 173
    throw v0

    .line 174
    :catchall_1
    move-exception v0

    .line 175
    goto :goto_2

    .line 176
    :cond_0
    invoke-static {}, Lg1/q;->c()Lg1/q;

    .line 177
    .line 178
    .line 179
    move-result-object v4

    .line 180
    new-instance v9, Ljava/lang/StringBuilder;

    .line 181
    .line 182
    invoke-direct {v9, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    const-string v0, ") is not in a RUNNING state."

    .line 189
    .line 190
    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 191
    .line 192
    .line 193
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    new-array v8, v7, [Ljava/lang/Throwable;

    .line 198
    .line 199
    invoke-virtual {v4, v10, v0, v8}, Lg1/q;->j(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V

    .line 200
    .line 201
    .line 202
    :goto_0
    invoke-virtual {v2, v6}, Lr1/j;->i(Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    invoke-virtual {v3}, LH0/w;->q()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 206
    .line 207
    .line 208
    :goto_1
    invoke-virtual {v3}, LH0/w;->n()V

    .line 209
    .line 210
    .line 211
    goto :goto_3

    .line 212
    :cond_1
    :try_start_3
    const-string v0, "Calls to setProgressAsync() must complete before a ListenableWorker signals completion of work by returning an instance of Result."

    .line 213
    .line 214
    new-instance v4, Ljava/lang/IllegalStateException;

    .line 215
    .line 216
    invoke-direct {v4, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    throw v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 220
    :goto_2
    :try_start_4
    invoke-static {}, Lg1/q;->c()Lg1/q;

    .line 221
    .line 222
    .line 223
    move-result-object v4

    .line 224
    sget-object v6, Lq1/o;->c:Ljava/lang/String;

    .line 225
    .line 226
    const-string v8, "Error updating Worker progress"

    .line 227
    .line 228
    new-array v5, v5, [Ljava/lang/Throwable;

    .line 229
    .line 230
    aput-object v0, v5, v7

    .line 231
    .line 232
    invoke-virtual {v4, v6, v8, v5}, Lg1/q;->b(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V

    .line 233
    .line 234
    .line 235
    invoke-virtual {v2, v0}, Lr1/j;->j(Ljava/lang/Throwable;)Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 236
    .line 237
    .line 238
    goto :goto_1

    .line 239
    :goto_3
    return-void

    .line 240
    :catchall_2
    move-exception v0

    .line 241
    invoke-virtual {v3}, LH0/w;->n()V

    .line 242
    .line 243
    .line 244
    throw v0

    .line 245
    :pswitch_2
    iget-object v0, v1, LH0/y;->e:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast v0, Ld5/h;

    .line 248
    .line 249
    iget-object v0, v0, Ld5/h;->b:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast v0, Ln/e;

    .line 252
    .line 253
    iget-object v2, v1, LH0/y;->c:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v2, Ln/m;

    .line 256
    .line 257
    iget-object v3, v1, LH0/y;->b:Ljava/lang/Object;

    .line 258
    .line 259
    check-cast v3, Ln/d;

    .line 260
    .line 261
    if-eqz v3, :cond_2

    .line 262
    .line 263
    iput-boolean v5, v0, Ln/e;->z:Z

    .line 264
    .line 265
    iget-object v3, v3, Ln/d;->b:Ln/k;

    .line 266
    .line 267
    invoke-virtual {v3, v7}, Ln/k;->c(Z)V

    .line 268
    .line 269
    .line 270
    iput-boolean v7, v0, Ln/e;->z:Z

    .line 271
    .line 272
    :cond_2
    invoke-virtual {v2}, Ln/m;->isEnabled()Z

    .line 273
    .line 274
    .line 275
    move-result v0

    .line 276
    if-eqz v0, :cond_3

    .line 277
    .line 278
    invoke-virtual {v2}, Ln/m;->hasSubMenu()Z

    .line 279
    .line 280
    .line 281
    move-result v0

    .line 282
    if-eqz v0, :cond_3

    .line 283
    .line 284
    iget-object v0, v1, LH0/y;->d:Ljava/lang/Object;

    .line 285
    .line 286
    check-cast v0, Ln/k;

    .line 287
    .line 288
    const/4 v3, 0x4

    .line 289
    invoke-virtual {v0, v2, v6, v3}, Ln/k;->q(Landroid/view/MenuItem;Ln/w;I)Z

    .line 290
    .line 291
    .line 292
    :cond_3
    return-void

    .line 293
    :pswitch_3
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 294
    .line 295
    check-cast v0, Lcom/google/android/gms/internal/cast/b;

    .line 296
    .line 297
    iget-object v4, v1, LH0/y;->c:Ljava/lang/Object;

    .line 298
    .line 299
    check-cast v4, Lv0/C;

    .line 300
    .line 301
    iget-object v8, v1, LH0/y;->d:Ljava/lang/Object;

    .line 302
    .line 303
    check-cast v8, Lv0/C;

    .line 304
    .line 305
    iget-object v9, v1, LH0/y;->e:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast v9, Lcom/google/android/gms/internal/cast/R0;

    .line 308
    .line 309
    iget-object v10, v0, Lcom/google/android/gms/internal/cast/b;->a:Lcom/google/android/gms/internal/cast/g;

    .line 310
    .line 311
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 312
    .line 313
    .line 314
    sget-object v0, Lcom/google/android/gms/internal/cast/g;->f:Lcom/google/android/gms/internal/measurement/H1;

    .line 315
    .line 316
    new-instance v11, Ljava/util/HashSet;

    .line 317
    .line 318
    iget-object v12, v10, Lcom/google/android/gms/internal/cast/g;->a:Ljava/util/HashSet;

    .line 319
    .line 320
    invoke-direct {v11, v12}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v11}, Ljava/util/HashSet;->isEmpty()Z

    .line 324
    .line 325
    .line 326
    move-result v11

    .line 327
    if-eqz v11, :cond_4

    .line 328
    .line 329
    const-string v2, "No need to prepare transfer without any callback"

    .line 330
    .line 331
    new-array v3, v7, [Ljava/lang/Object;

    .line 332
    .line 333
    invoke-virtual {v0, v2, v3}, Lcom/google/android/gms/internal/measurement/H1;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 334
    .line 335
    .line 336
    invoke-virtual {v9}, Lcom/google/android/gms/internal/cast/R0;->j0()Z

    .line 337
    .line 338
    .line 339
    goto/16 :goto_b

    .line 340
    .line 341
    :cond_4
    iget v4, v4, Lv0/C;->k:I

    .line 342
    .line 343
    if-ne v4, v5, :cond_12

    .line 344
    .line 345
    iget v4, v8, Lv0/C;->k:I

    .line 346
    .line 347
    if-eqz v4, :cond_5

    .line 348
    .line 349
    goto/16 :goto_a

    .line 350
    .line 351
    :cond_5
    iget-object v4, v10, Lcom/google/android/gms/internal/cast/g;->c:Lq3/g;

    .line 352
    .line 353
    if-nez v4, :cond_6

    .line 354
    .line 355
    move-object v4, v6

    .line 356
    goto :goto_4

    .line 357
    :cond_6
    invoke-virtual {v4}, Lq3/g;->c()Lq3/d;

    .line 358
    .line 359
    .line 360
    move-result-object v4

    .line 361
    if-eqz v4, :cond_7

    .line 362
    .line 363
    iput-object v10, v4, Lq3/d;->k:Lcom/google/android/gms/internal/cast/g;

    .line 364
    .line 365
    :cond_7
    :goto_4
    if-nez v4, :cond_8

    .line 366
    .line 367
    const-string v2, "No need to prepare transfer when there is no Cast session"

    .line 368
    .line 369
    new-array v3, v7, [Ljava/lang/Object;

    .line 370
    .line 371
    invoke-virtual {v0, v2, v3}, Lcom/google/android/gms/internal/measurement/H1;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 372
    .line 373
    .line 374
    invoke-virtual {v9}, Lcom/google/android/gms/internal/cast/R0;->j0()Z

    .line 375
    .line 376
    .line 377
    goto/16 :goto_b

    .line 378
    .line 379
    :cond_8
    invoke-static {}, LB3/z;->d()V

    .line 380
    .line 381
    .line 382
    iget-object v4, v4, Lq3/d;->i:Lr3/i;

    .line 383
    .line 384
    if-eqz v4, :cond_f

    .line 385
    .line 386
    invoke-virtual {v4}, Lr3/i;->f()Z

    .line 387
    .line 388
    .line 389
    move-result v8

    .line 390
    if-nez v8, :cond_9

    .line 391
    .line 392
    goto/16 :goto_8

    .line 393
    .line 394
    :cond_9
    const-string v8, "Prepare route transfer for changing endpoint"

    .line 395
    .line 396
    new-array v11, v7, [Ljava/lang/Object;

    .line 397
    .line 398
    invoke-virtual {v0, v8, v11}, Lcom/google/android/gms/internal/measurement/H1;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 399
    .line 400
    .line 401
    iput-object v6, v10, Lcom/google/android/gms/internal/cast/g;->e:Lp3/r;

    .line 402
    .line 403
    iput v5, v10, Lcom/google/android/gms/internal/cast/g;->b:I

    .line 404
    .line 405
    iput-object v9, v10, Lcom/google/android/gms/internal/cast/g;->d:Lcom/google/android/gms/internal/cast/R0;

    .line 406
    .line 407
    invoke-static {}, LB3/z;->d()V

    .line 408
    .line 409
    .line 410
    invoke-virtual {v4}, Lr3/i;->t()Z

    .line 411
    .line 412
    .line 413
    move-result v0

    .line 414
    if-eqz v0, :cond_e

    .line 415
    .line 416
    invoke-virtual {v4}, Lr3/i;->c()Lp3/q;

    .line 417
    .line 418
    .line 419
    move-result-object v0

    .line 420
    invoke-static {v0}, LB3/z;->h(Ljava/lang/Object;)V

    .line 421
    .line 422
    .line 423
    const-wide/32 v8, 0x40000

    .line 424
    .line 425
    .line 426
    iget-wide v11, v0, Lp3/q;->h:J

    .line 427
    .line 428
    and-long/2addr v8, v11

    .line 429
    cmp-long v0, v8, v2

    .line 430
    .line 431
    if-eqz v0, :cond_a

    .line 432
    .line 433
    iget-object v2, v4, Lr3/i;->c:Lu3/l;

    .line 434
    .line 435
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 436
    .line 437
    .line 438
    new-instance v3, Lorg/json/JSONObject;

    .line 439
    .line 440
    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    .line 441
    .line 442
    .line 443
    invoke-virtual {v2}, LT2/d;->n()J

    .line 444
    .line 445
    .line 446
    move-result-wide v8

    .line 447
    :try_start_5
    const-string v0, "requestId"

    .line 448
    .line 449
    invoke-virtual {v3, v0, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 450
    .line 451
    .line 452
    const-string v0, "type"

    .line 453
    .line 454
    const-string v4, "STORE_SESSION"

    .line 455
    .line 456
    invoke-virtual {v3, v0, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 457
    .line 458
    .line 459
    new-instance v0, Lorg/json/JSONObject;

    .line 460
    .line 461
    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 462
    .line 463
    .line 464
    const-string v4, "assistant_supported"

    .line 465
    .line 466
    invoke-virtual {v0, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 467
    .line 468
    .line 469
    const-string v4, "display_supported"

    .line 470
    .line 471
    invoke-virtual {v0, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 472
    .line 473
    .line 474
    const-string v4, "is_group"

    .line 475
    .line 476
    invoke-virtual {v0, v4, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 477
    .line 478
    .line 479
    const-string v4, "targetDeviceCapabilities"

    .line 480
    .line 481
    invoke-virtual {v3, v4, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_5} :catch_0

    .line 482
    .line 483
    .line 484
    goto :goto_5

    .line 485
    :catch_0
    move-exception v0

    .line 486
    iget-object v4, v2, LT2/d;->b:Ljava/lang/Object;

    .line 487
    .line 488
    check-cast v4, Lcom/google/android/gms/internal/measurement/H1;

    .line 489
    .line 490
    const-string v5, "store session failed to create JSON message"

    .line 491
    .line 492
    new-array v6, v7, [Ljava/lang/Object;

    .line 493
    .line 494
    iget-object v7, v4, Lcom/google/android/gms/internal/measurement/H1;->b:Ljava/lang/Object;

    .line 495
    .line 496
    check-cast v7, Ljava/lang/String;

    .line 497
    .line 498
    invoke-virtual {v4, v5, v6}, Lcom/google/android/gms/internal/measurement/H1;->f(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 499
    .line 500
    .line 501
    move-result-object v4

    .line 502
    invoke-static {v7, v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 503
    .line 504
    .line 505
    :goto_5
    :try_start_6
    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 506
    .line 507
    .line 508
    move-result-object v0

    .line 509
    invoke-virtual {v2, v8, v9, v0}, LT2/d;->o(JLjava/lang/String;)V
    :try_end_6
    .catch Ljava/lang/IllegalStateException; {:try_start_6 .. :try_end_6} :catch_1

    .line 510
    .line 511
    .line 512
    iget-object v0, v2, Lu3/l;->y:Lu3/n;

    .line 513
    .line 514
    new-instance v3, Ls5/l;

    .line 515
    .line 516
    invoke-direct {v3, v2}, Ls5/l;-><init>(Ljava/lang/Object;)V

    .line 517
    .line 518
    .line 519
    invoke-virtual {v0, v8, v9, v3}, Lu3/n;->a(JLu3/m;)V

    .line 520
    .line 521
    .line 522
    new-instance v0, Lb4/i;

    .line 523
    .line 524
    invoke-direct {v0}, Lb4/i;-><init>()V

    .line 525
    .line 526
    .line 527
    iput-object v0, v2, Lu3/l;->z:Lb4/i;

    .line 528
    .line 529
    iget-object v0, v0, Lb4/i;->a:Lb4/q;

    .line 530
    .line 531
    goto/16 :goto_7

    .line 532
    .line 533
    :catch_1
    move-exception v0

    .line 534
    invoke-static {v0}, Lf5/b;->r(Ljava/lang/Exception;)Lb4/q;

    .line 535
    .line 536
    .line 537
    move-result-object v0

    .line 538
    goto :goto_7

    .line 539
    :cond_a
    new-instance v0, Lb4/q;

    .line 540
    .line 541
    invoke-direct {v0}, Lb4/q;-><init>()V

    .line 542
    .line 543
    .line 544
    const-string v2, "RemoteMediaClient"

    .line 545
    .line 546
    const-string v3, "create SessionState with cached mediaInfo and mediaStatus"

    .line 547
    .line 548
    invoke-static {v2, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 549
    .line 550
    .line 551
    invoke-virtual {v4}, Lr3/i;->b()Lcom/google/android/gms/cast/MediaInfo;

    .line 552
    .line 553
    .line 554
    move-result-object v12

    .line 555
    invoke-virtual {v4}, Lr3/i;->c()Lp3/q;

    .line 556
    .line 557
    .line 558
    move-result-object v2

    .line 559
    if-eqz v12, :cond_d

    .line 560
    .line 561
    if-nez v2, :cond_b

    .line 562
    .line 563
    goto :goto_6

    .line 564
    :cond_b
    sget-object v14, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 565
    .line 566
    invoke-virtual {v4}, Lr3/i;->a()J

    .line 567
    .line 568
    .line 569
    move-result-wide v15

    .line 570
    iget-object v13, v2, Lp3/q;->v:Lp3/n;

    .line 571
    .line 572
    iget-wide v3, v2, Lp3/q;->d:D

    .line 573
    .line 574
    const-wide/high16 v7, 0x4000000000000000L    # 2.0

    .line 575
    .line 576
    invoke-static {v3, v4, v7, v8}, Ljava/lang/Double;->compare(DD)I

    .line 577
    .line 578
    .line 579
    move-result v5

    .line 580
    if-gtz v5, :cond_c

    .line 581
    .line 582
    const-wide/high16 v7, 0x3fe0000000000000L    # 0.5

    .line 583
    .line 584
    invoke-static {v3, v4, v7, v8}, Ljava/lang/Double;->compare(DD)I

    .line 585
    .line 586
    .line 587
    move-result v5

    .line 588
    if-ltz v5, :cond_c

    .line 589
    .line 590
    iget-object v5, v2, Lp3/q;->k:[J

    .line 591
    .line 592
    iget-object v2, v2, Lp3/q;->o:Lorg/json/JSONObject;

    .line 593
    .line 594
    new-instance v11, Lp3/k;

    .line 595
    .line 596
    const/16 v21, 0x0

    .line 597
    .line 598
    const/16 v22, 0x0

    .line 599
    .line 600
    const/16 v23, 0x0

    .line 601
    .line 602
    const/16 v24, 0x0

    .line 603
    .line 604
    const-wide/16 v25, 0x0

    .line 605
    .line 606
    move-object/from16 v20, v2

    .line 607
    .line 608
    move-wide/from16 v17, v3

    .line 609
    .line 610
    move-object/from16 v19, v5

    .line 611
    .line 612
    invoke-direct/range {v11 .. v26}, Lp3/k;-><init>(Lcom/google/android/gms/cast/MediaInfo;Lp3/n;Ljava/lang/Boolean;JD[JLorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    .line 613
    .line 614
    .line 615
    new-instance v2, Lp3/r;

    .line 616
    .line 617
    invoke-direct {v2, v11, v6}, Lp3/r;-><init>(Lp3/k;Lorg/json/JSONObject;)V

    .line 618
    .line 619
    .line 620
    move-object v6, v2

    .line 621
    goto :goto_6

    .line 622
    :cond_c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 623
    .line 624
    const-string v2, "playbackRate must be between PLAYBACK_RATE_MIN and PLAYBACK_RATE_MAX"

    .line 625
    .line 626
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 627
    .line 628
    .line 629
    throw v0

    .line 630
    :cond_d
    :goto_6
    invoke-virtual {v0, v6}, Lb4/q;->o(Ljava/lang/Object;)V

    .line 631
    .line 632
    .line 633
    goto :goto_7

    .line 634
    :cond_e
    new-instance v0, Lu3/j;

    .line 635
    .line 636
    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    .line 637
    .line 638
    .line 639
    invoke-static {v0}, Lf5/b;->r(Ljava/lang/Exception;)Lb4/q;

    .line 640
    .line 641
    .line 642
    move-result-object v0

    .line 643
    :goto_7
    new-instance v2, Lcom/google/android/gms/internal/cast/f;

    .line 644
    .line 645
    invoke-direct {v2, v10}, Lcom/google/android/gms/internal/cast/f;-><init>(Lcom/google/android/gms/internal/cast/g;)V

    .line 646
    .line 647
    .line 648
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 649
    .line 650
    .line 651
    sget-object v3, Lb4/j;->a:LU1/r;

    .line 652
    .line 653
    invoke-virtual {v0, v3, v2}, Lb4/q;->d(Ljava/util/concurrent/Executor;Lb4/e;)Lb4/q;

    .line 654
    .line 655
    .line 656
    new-instance v2, Lcom/google/android/gms/internal/cast/f;

    .line 657
    .line 658
    invoke-direct {v2, v10}, Lcom/google/android/gms/internal/cast/f;-><init>(Lcom/google/android/gms/internal/cast/g;)V

    .line 659
    .line 660
    .line 661
    invoke-virtual {v0, v3, v2}, Lb4/q;->c(Ljava/util/concurrent/Executor;Lb4/d;)Lb4/q;

    .line 662
    .line 663
    .line 664
    sget-object v0, Lcom/google/android/gms/internal/cast/D;->m0:Lcom/google/android/gms/internal/cast/D;

    .line 665
    .line 666
    invoke-static {v0}, Lcom/google/android/gms/internal/cast/V;->a(Lcom/google/android/gms/internal/cast/D;)V

    .line 667
    .line 668
    .line 669
    goto :goto_b

    .line 670
    :cond_f
    :goto_8
    const-string v2, "No need to prepare transfer when there is no media session"

    .line 671
    .line 672
    new-array v3, v7, [Ljava/lang/Object;

    .line 673
    .line 674
    invoke-virtual {v0, v2, v3}, Lcom/google/android/gms/internal/measurement/H1;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 675
    .line 676
    .line 677
    iget-object v0, v10, Lcom/google/android/gms/internal/cast/g;->c:Lq3/g;

    .line 678
    .line 679
    if-nez v0, :cond_10

    .line 680
    .line 681
    goto :goto_9

    .line 682
    :cond_10
    invoke-virtual {v0}, Lq3/g;->c()Lq3/d;

    .line 683
    .line 684
    .line 685
    move-result-object v0

    .line 686
    if-eqz v0, :cond_11

    .line 687
    .line 688
    iput-object v6, v0, Lq3/d;->k:Lcom/google/android/gms/internal/cast/g;

    .line 689
    .line 690
    :cond_11
    :goto_9
    invoke-virtual {v9}, Lcom/google/android/gms/internal/cast/R0;->j0()Z

    .line 691
    .line 692
    .line 693
    goto :goto_b

    .line 694
    :cond_12
    :goto_a
    const-string v2, "No need to prepare transfer for non cast-to-phone case"

    .line 695
    .line 696
    new-array v3, v7, [Ljava/lang/Object;

    .line 697
    .line 698
    invoke-virtual {v0, v2, v3}, Lcom/google/android/gms/internal/measurement/H1;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 699
    .line 700
    .line 701
    invoke-virtual {v9}, Lcom/google/android/gms/internal/cast/R0;->j0()Z

    .line 702
    .line 703
    .line 704
    :goto_b
    return-void

    .line 705
    :pswitch_4
    iget-object v0, v1, LH0/y;->e:Ljava/lang/Object;

    .line 706
    .line 707
    check-cast v0, LV5/c;

    .line 708
    .line 709
    iget-object v0, v0, LV5/c;->b:Ljava/lang/Object;

    .line 710
    .line 711
    check-cast v0, LX3/H1;

    .line 712
    .line 713
    invoke-virtual {v0}, LX3/H1;->j0()LX3/M1;

    .line 714
    .line 715
    .line 716
    move-result-object v2

    .line 717
    invoke-virtual {v0}, LX3/H1;->L()LG3/a;

    .line 718
    .line 719
    .line 720
    move-result-object v3

    .line 721
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 722
    .line 723
    .line 724
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 725
    .line 726
    .line 727
    move-result-wide v6

    .line 728
    iget-object v3, v1, LH0/y;->b:Ljava/lang/Object;

    .line 729
    .line 730
    move-object v9, v3

    .line 731
    check-cast v9, Ljava/lang/String;

    .line 732
    .line 733
    iget-object v3, v1, LH0/y;->c:Ljava/lang/Object;

    .line 734
    .line 735
    check-cast v3, Ljava/lang/String;

    .line 736
    .line 737
    iget-object v4, v1, LH0/y;->d:Ljava/lang/Object;

    .line 738
    .line 739
    check-cast v4, Landroid/os/Bundle;

    .line 740
    .line 741
    const-string v5, "auto"

    .line 742
    .line 743
    const/4 v8, 0x0

    .line 744
    invoke-virtual/range {v2 .. v8}, LX3/M1;->U0(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;JZ)LX3/t;

    .line 745
    .line 746
    .line 747
    move-result-object v2

    .line 748
    invoke-static {v2}, LB3/z;->h(Ljava/lang/Object;)V

    .line 749
    .line 750
    .line 751
    invoke-virtual {v0, v2, v9}, LX3/H1;->c(LX3/t;Ljava/lang/String;)V

    .line 752
    .line 753
    .line 754
    return-void

    .line 755
    :pswitch_5
    invoke-direct {v1}, LH0/y;->a()V

    .line 756
    .line 757
    .line 758
    return-void

    .line 759
    :pswitch_6
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 760
    .line 761
    move-object v2, v0

    .line 762
    check-cast v2, LX3/l1;

    .line 763
    .line 764
    iget-object v0, v1, LH0/y;->c:Ljava/lang/Object;

    .line 765
    .line 766
    move-object v3, v0

    .line 767
    check-cast v3, Ljava/util/concurrent/atomic/AtomicReference;

    .line 768
    .line 769
    iget-object v0, v1, LH0/y;->d:Ljava/lang/Object;

    .line 770
    .line 771
    check-cast v0, LX3/O1;

    .line 772
    .line 773
    iget-object v4, v1, LH0/y;->e:Ljava/lang/Object;

    .line 774
    .line 775
    check-cast v4, Landroid/os/Bundle;

    .line 776
    .line 777
    monitor-enter v3

    .line 778
    :try_start_7
    iget-object v5, v2, LX3/l1;->d:LX3/H;

    .line 779
    .line 780
    if-nez v5, :cond_13

    .line 781
    .line 782
    iget-object v0, v2, LD/o;->a:Ljava/lang/Object;

    .line 783
    .line 784
    check-cast v0, LX3/n0;

    .line 785
    .line 786
    iget-object v0, v0, LX3/n0;->f:LX3/U;

    .line 787
    .line 788
    invoke-static {v0}, LX3/n0;->g(LX3/v0;)V

    .line 789
    .line 790
    .line 791
    iget-object v0, v0, LX3/U;->f:LP8/b;

    .line 792
    .line 793
    const-string v4, "Failed to request trigger URIs; not connected to service"

    .line 794
    .line 795
    invoke-virtual {v0, v4}, LP8/b;->b(Ljava/lang/String;)V
    :try_end_7
    .catch Landroid/os/RemoteException; {:try_start_7 .. :try_end_7} :catch_2
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 796
    .line 797
    .line 798
    :try_start_8
    monitor-exit v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 799
    goto :goto_e

    .line 800
    :catchall_3
    move-exception v0

    .line 801
    goto :goto_f

    .line 802
    :catch_2
    move-exception v0

    .line 803
    goto :goto_c

    .line 804
    :cond_13
    :try_start_9
    new-instance v6, LX3/d1;

    .line 805
    .line 806
    invoke-direct {v6, v2, v3}, LX3/d1;-><init>(LX3/l1;Ljava/util/concurrent/atomic/AtomicReference;)V

    .line 807
    .line 808
    .line 809
    invoke-interface {v5, v0, v4, v6}, LX3/H;->J(LX3/O1;Landroid/os/Bundle;LX3/J;)V

    .line 810
    .line 811
    .line 812
    invoke-virtual {v2}, LX3/l1;->E0()V
    :try_end_9
    .catch Landroid/os/RemoteException; {:try_start_9 .. :try_end_9} :catch_2
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .line 813
    .line 814
    .line 815
    goto :goto_d

    .line 816
    :goto_c
    :try_start_a
    iget-object v2, v2, LD/o;->a:Ljava/lang/Object;

    .line 817
    .line 818
    check-cast v2, LX3/n0;

    .line 819
    .line 820
    iget-object v2, v2, LX3/n0;->f:LX3/U;

    .line 821
    .line 822
    invoke-static {v2}, LX3/n0;->g(LX3/v0;)V

    .line 823
    .line 824
    .line 825
    iget-object v2, v2, LX3/U;->f:LP8/b;

    .line 826
    .line 827
    const-string v4, "Failed to request trigger URIs; remote exception"

    .line 828
    .line 829
    invoke-virtual {v2, v0, v4}, LP8/b;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 830
    .line 831
    .line 832
    invoke-virtual {v3}, Ljava/lang/Object;->notifyAll()V

    .line 833
    .line 834
    .line 835
    :goto_d
    monitor-exit v3

    .line 836
    :goto_e
    return-void

    .line 837
    :goto_f
    monitor-exit v3
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    .line 838
    throw v0

    .line 839
    :pswitch_7
    iget-object v0, v1, LH0/y;->d:Ljava/lang/Object;

    .line 840
    .line 841
    move-object v2, v0

    .line 842
    check-cast v2, Lcom/google/android/gms/internal/measurement/L;

    .line 843
    .line 844
    iget-object v0, v1, LH0/y;->e:Ljava/lang/Object;

    .line 845
    .line 846
    move-object v3, v0

    .line 847
    check-cast v3, LX3/l1;

    .line 848
    .line 849
    :try_start_b
    iget-object v0, v3, LX3/l1;->d:LX3/H;

    .line 850
    .line 851
    if-nez v0, :cond_14

    .line 852
    .line 853
    iget-object v0, v3, LD/o;->a:Ljava/lang/Object;

    .line 854
    .line 855
    check-cast v0, LX3/n0;

    .line 856
    .line 857
    iget-object v4, v0, LX3/n0;->f:LX3/U;

    .line 858
    .line 859
    invoke-static {v4}, LX3/n0;->g(LX3/v0;)V

    .line 860
    .line 861
    .line 862
    iget-object v4, v4, LX3/U;->f:LP8/b;

    .line 863
    .line 864
    const-string v5, "Discarding data. Failed to send event to service to bundle"

    .line 865
    .line 866
    invoke-virtual {v4, v5}, LP8/b;->b(Ljava/lang/String;)V
    :try_end_b
    .catch Landroid/os/RemoteException; {:try_start_b .. :try_end_b} :catch_3
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    .line 867
    .line 868
    .line 869
    iget-object v0, v0, LX3/n0;->i:LX3/M1;

    .line 870
    .line 871
    invoke-static {v0}, LX3/n0;->e(LD/o;)V

    .line 872
    .line 873
    .line 874
    invoke-virtual {v0, v2, v6}, LX3/M1;->d1(Lcom/google/android/gms/internal/measurement/L;[B)V

    .line 875
    .line 876
    .line 877
    goto :goto_11

    .line 878
    :cond_14
    :try_start_c
    iget-object v4, v1, LH0/y;->b:Ljava/lang/Object;

    .line 879
    .line 880
    check-cast v4, LX3/t;

    .line 881
    .line 882
    iget-object v5, v1, LH0/y;->c:Ljava/lang/Object;

    .line 883
    .line 884
    check-cast v5, Ljava/lang/String;

    .line 885
    .line 886
    invoke-interface {v0, v4, v5}, LX3/H;->m0(LX3/t;Ljava/lang/String;)[B

    .line 887
    .line 888
    .line 889
    move-result-object v6

    .line 890
    invoke-virtual {v3}, LX3/l1;->E0()V
    :try_end_c
    .catch Landroid/os/RemoteException; {:try_start_c .. :try_end_c} :catch_3
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    .line 891
    .line 892
    .line 893
    goto :goto_10

    .line 894
    :catchall_4
    move-exception v0

    .line 895
    goto :goto_12

    .line 896
    :catch_3
    move-exception v0

    .line 897
    :try_start_d
    iget-object v4, v3, LD/o;->a:Ljava/lang/Object;

    .line 898
    .line 899
    check-cast v4, LX3/n0;

    .line 900
    .line 901
    iget-object v4, v4, LX3/n0;->f:LX3/U;

    .line 902
    .line 903
    invoke-static {v4}, LX3/n0;->g(LX3/v0;)V

    .line 904
    .line 905
    .line 906
    iget-object v4, v4, LX3/U;->f:LP8/b;

    .line 907
    .line 908
    const-string v5, "Failed to send event to the service to bundle"

    .line 909
    .line 910
    invoke-virtual {v4, v0, v5}, LP8/b;->c(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    .line 911
    .line 912
    .line 913
    :goto_10
    iget-object v0, v3, LD/o;->a:Ljava/lang/Object;

    .line 914
    .line 915
    check-cast v0, LX3/n0;

    .line 916
    .line 917
    iget-object v0, v0, LX3/n0;->i:LX3/M1;

    .line 918
    .line 919
    invoke-static {v0}, LX3/n0;->e(LD/o;)V

    .line 920
    .line 921
    .line 922
    invoke-virtual {v0, v2, v6}, LX3/M1;->d1(Lcom/google/android/gms/internal/measurement/L;[B)V

    .line 923
    .line 924
    .line 925
    :goto_11
    return-void

    .line 926
    :goto_12
    iget-object v3, v3, LD/o;->a:Ljava/lang/Object;

    .line 927
    .line 928
    check-cast v3, LX3/n0;

    .line 929
    .line 930
    iget-object v3, v3, LX3/n0;->i:LX3/M1;

    .line 931
    .line 932
    invoke-static {v3}, LX3/n0;->e(LD/o;)V

    .line 933
    .line 934
    .line 935
    invoke-virtual {v3, v2, v6}, LX3/M1;->d1(Lcom/google/android/gms/internal/measurement/L;[B)V

    .line 936
    .line 937
    .line 938
    throw v0

    .line 939
    :pswitch_8
    iget-object v0, v1, LH0/y;->e:Ljava/lang/Object;

    .line 940
    .line 941
    check-cast v0, Lcom/google/android/gms/measurement/internal/AppMeasurementDynamiteService;

    .line 942
    .line 943
    iget-object v0, v0, Lcom/google/android/gms/measurement/internal/AppMeasurementDynamiteService;->e:LX3/n0;

    .line 944
    .line 945
    invoke-virtual {v0}, LX3/n0;->j()LX3/l1;

    .line 946
    .line 947
    .line 948
    move-result-object v9

    .line 949
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 950
    .line 951
    move-object v13, v0

    .line 952
    check-cast v13, Lcom/google/android/gms/internal/measurement/L;

    .line 953
    .line 954
    iget-object v0, v1, LH0/y;->c:Ljava/lang/Object;

    .line 955
    .line 956
    move-object v10, v0

    .line 957
    check-cast v10, Ljava/lang/String;

    .line 958
    .line 959
    iget-object v0, v1, LH0/y;->d:Ljava/lang/Object;

    .line 960
    .line 961
    move-object v11, v0

    .line 962
    check-cast v11, Ljava/lang/String;

    .line 963
    .line 964
    invoke-virtual {v9}, LX3/B;->r0()V

    .line 965
    .line 966
    .line 967
    invoke-virtual {v9}, LX3/G;->s0()V

    .line 968
    .line 969
    .line 970
    invoke-virtual {v9, v7}, LX3/l1;->H0(Z)LX3/O1;

    .line 971
    .line 972
    .line 973
    move-result-object v12

    .line 974
    new-instance v8, LX3/t0;

    .line 975
    .line 976
    invoke-direct/range {v8 .. v13}, LX3/t0;-><init>(LX3/l1;Ljava/lang/String;Ljava/lang/String;LX3/O1;Lcom/google/android/gms/internal/measurement/L;)V

    .line 977
    .line 978
    .line 979
    invoke-virtual {v9, v8}, LX3/l1;->F0(Ljava/lang/Runnable;)V

    .line 980
    .line 981
    .line 982
    return-void

    .line 983
    :pswitch_9
    iget-object v0, v1, LH0/y;->c:Ljava/lang/Object;

    .line 984
    .line 985
    move-object v11, v0

    .line 986
    check-cast v11, Ljava/lang/String;

    .line 987
    .line 988
    iget-object v0, v1, LH0/y;->d:Ljava/lang/Object;

    .line 989
    .line 990
    move-object v12, v0

    .line 991
    check-cast v12, Ljava/lang/String;

    .line 992
    .line 993
    iget-object v0, v1, LH0/y;->e:Ljava/lang/Object;

    .line 994
    .line 995
    check-cast v0, LX3/P0;

    .line 996
    .line 997
    iget-object v0, v0, LD/o;->a:Ljava/lang/Object;

    .line 998
    .line 999
    check-cast v0, LX3/n0;

    .line 1000
    .line 1001
    invoke-virtual {v0}, LX3/n0;->j()LX3/l1;

    .line 1002
    .line 1003
    .line 1004
    move-result-object v9

    .line 1005
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 1006
    .line 1007
    move-object v10, v0

    .line 1008
    check-cast v10, Ljava/util/concurrent/atomic/AtomicReference;

    .line 1009
    .line 1010
    invoke-virtual {v9}, LX3/B;->r0()V

    .line 1011
    .line 1012
    .line 1013
    invoke-virtual {v9}, LX3/G;->s0()V

    .line 1014
    .line 1015
    .line 1016
    invoke-virtual {v9, v7}, LX3/l1;->H0(Z)LX3/O1;

    .line 1017
    .line 1018
    .line 1019
    move-result-object v13

    .line 1020
    new-instance v8, LX3/t0;

    .line 1021
    .line 1022
    invoke-direct/range {v8 .. v13}, LX3/t0;-><init>(LX3/l1;Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/String;Ljava/lang/String;LX3/O1;)V

    .line 1023
    .line 1024
    .line 1025
    invoke-virtual {v9, v8}, LX3/l1;->F0(Ljava/lang/Runnable;)V

    .line 1026
    .line 1027
    .line 1028
    return-void

    .line 1029
    :pswitch_a
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 1030
    .line 1031
    check-cast v0, LX3/u0;

    .line 1032
    .line 1033
    iget-object v4, v1, LH0/y;->c:Ljava/lang/Object;

    .line 1034
    .line 1035
    move-object/from16 v16, v4

    .line 1036
    .line 1037
    check-cast v16, Landroid/os/Bundle;

    .line 1038
    .line 1039
    iget-object v4, v1, LH0/y;->d:Ljava/lang/Object;

    .line 1040
    .line 1041
    move-object v10, v4

    .line 1042
    check-cast v10, Ljava/lang/String;

    .line 1043
    .line 1044
    iget-object v4, v1, LH0/y;->e:Ljava/lang/Object;

    .line 1045
    .line 1046
    check-cast v4, LX3/O1;

    .line 1047
    .line 1048
    iget-object v5, v0, LX3/u0;->e:LX3/H1;

    .line 1049
    .line 1050
    invoke-virtual {v5}, LX3/H1;->d0()LX3/g;

    .line 1051
    .line 1052
    .line 1053
    move-result-object v0

    .line 1054
    sget-object v7, LX3/E;->W0:LX3/D;

    .line 1055
    .line 1056
    invoke-virtual {v0, v6, v7}, LX3/g;->B0(Ljava/lang/String;LX3/D;)Z

    .line 1057
    .line 1058
    .line 1059
    move-result v0

    .line 1060
    invoke-virtual/range {v16 .. v16}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 1061
    .line 1062
    .line 1063
    move-result v7

    .line 1064
    if-eqz v7, :cond_15

    .line 1065
    .line 1066
    if-eqz v0, :cond_15

    .line 1067
    .line 1068
    iget-object v2, v5, LX3/H1;->c:LX3/n;

    .line 1069
    .line 1070
    invoke-static {v2}, LX3/H1;->R(LX3/C1;)V

    .line 1071
    .line 1072
    .line 1073
    invoke-virtual {v2}, LD/o;->r0()V

    .line 1074
    .line 1075
    .line 1076
    invoke-virtual {v2}, LX3/C1;->s0()V

    .line 1077
    .line 1078
    .line 1079
    :try_start_e
    invoke-virtual {v2}, LX3/n;->i1()Landroid/database/sqlite/SQLiteDatabase;

    .line 1080
    .line 1081
    .line 1082
    move-result-object v0

    .line 1083
    const-string v3, "delete from default_event_params where app_id=?"

    .line 1084
    .line 1085
    filled-new-array {v10}, [Ljava/lang/String;

    .line 1086
    .line 1087
    .line 1088
    move-result-object v4

    .line 1089
    invoke-virtual {v0, v3, v4}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_e
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_e .. :try_end_e} :catch_4

    .line 1090
    .line 1091
    .line 1092
    goto/16 :goto_14

    .line 1093
    .line 1094
    :catch_4
    move-exception v0

    .line 1095
    iget-object v2, v2, LD/o;->a:Ljava/lang/Object;

    .line 1096
    .line 1097
    check-cast v2, LX3/n0;

    .line 1098
    .line 1099
    iget-object v2, v2, LX3/n0;->f:LX3/U;

    .line 1100
    .line 1101
    invoke-static {v2}, LX3/n0;->g(LX3/v0;)V

    .line 1102
    .line 1103
    .line 1104
    iget-object v2, v2, LX3/U;->f:LP8/b;

    .line 1105
    .line 1106
    const-string v3, "Error clearing default event params"

    .line 1107
    .line 1108
    invoke-virtual {v2, v0, v3}, LP8/b;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1109
    .line 1110
    .line 1111
    goto/16 :goto_14

    .line 1112
    .line 1113
    :cond_15
    iget-object v0, v5, LX3/H1;->c:LX3/n;

    .line 1114
    .line 1115
    invoke-static {v0}, LX3/H1;->R(LX3/C1;)V

    .line 1116
    .line 1117
    .line 1118
    iget-object v7, v0, LD/o;->a:Ljava/lang/Object;

    .line 1119
    .line 1120
    check-cast v7, LX3/n0;

    .line 1121
    .line 1122
    invoke-virtual {v0}, LD/o;->r0()V

    .line 1123
    .line 1124
    .line 1125
    invoke-virtual {v0}, LX3/C1;->s0()V

    .line 1126
    .line 1127
    .line 1128
    iget-object v8, v0, LD/o;->a:Ljava/lang/Object;

    .line 1129
    .line 1130
    check-cast v8, LX3/n0;

    .line 1131
    .line 1132
    const-string v11, "dep"

    .line 1133
    .line 1134
    move-object v9, v7

    .line 1135
    new-instance v7, LM2/k;

    .line 1136
    .line 1137
    move-object v12, v9

    .line 1138
    const-string v9, ""

    .line 1139
    .line 1140
    move-object v14, v12

    .line 1141
    const-wide/16 v12, 0x0

    .line 1142
    .line 1143
    move-object/from16 v17, v14

    .line 1144
    .line 1145
    const-wide/16 v14, 0x0

    .line 1146
    .line 1147
    move-object/from16 v2, v17

    .line 1148
    .line 1149
    invoke-direct/range {v7 .. v16}, LM2/k;-><init>(LX3/n0;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJLandroid/os/Bundle;)V

    .line 1150
    .line 1151
    .line 1152
    move-object/from16 v3, v16

    .line 1153
    .line 1154
    iget-object v8, v0, LX3/y1;->b:LX3/H1;

    .line 1155
    .line 1156
    iget-object v8, v8, LX3/H1;->g:LX3/X;

    .line 1157
    .line 1158
    invoke-static {v8}, LX3/H1;->R(LX3/C1;)V

    .line 1159
    .line 1160
    .line 1161
    invoke-virtual {v8, v7}, LX3/X;->T0(LM2/k;)Lcom/google/android/gms/internal/measurement/b1;

    .line 1162
    .line 1163
    .line 1164
    move-result-object v7

    .line 1165
    invoke-virtual {v7}, Lcom/google/android/gms/internal/measurement/S1;->a()[B

    .line 1166
    .line 1167
    .line 1168
    move-result-object v7

    .line 1169
    iget-object v2, v2, LX3/n0;->f:LX3/U;

    .line 1170
    .line 1171
    invoke-static {v2}, LX3/n0;->g(LX3/v0;)V

    .line 1172
    .line 1173
    .line 1174
    iget-object v8, v2, LX3/U;->n:LP8/b;

    .line 1175
    .line 1176
    array-length v9, v7

    .line 1177
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1178
    .line 1179
    .line 1180
    move-result-object v9

    .line 1181
    const-string v11, "Saving default event parameters, appId, data size"

    .line 1182
    .line 1183
    invoke-virtual {v8, v10, v9, v11}, LP8/b;->d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 1184
    .line 1185
    .line 1186
    new-instance v8, Landroid/content/ContentValues;

    .line 1187
    .line 1188
    invoke-direct {v8}, Landroid/content/ContentValues;-><init>()V

    .line 1189
    .line 1190
    .line 1191
    const-string v9, "app_id"

    .line 1192
    .line 1193
    invoke-virtual {v8, v9, v10}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 1194
    .line 1195
    .line 1196
    const-string v9, "parameters"

    .line 1197
    .line 1198
    invoke-virtual {v8, v9, v7}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    .line 1199
    .line 1200
    .line 1201
    :try_start_f
    invoke-virtual {v0}, LX3/n;->i1()Landroid/database/sqlite/SQLiteDatabase;

    .line 1202
    .line 1203
    .line 1204
    move-result-object v0

    .line 1205
    const-string v7, "default_event_params"

    .line 1206
    .line 1207
    const/4 v9, 0x5

    .line 1208
    invoke-virtual {v0, v7, v6, v8, v9}, Landroid/database/sqlite/SQLiteDatabase;->insertWithOnConflict(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;I)J

    .line 1209
    .line 1210
    .line 1211
    move-result-wide v7

    .line 1212
    const-wide/16 v11, -0x1

    .line 1213
    .line 1214
    cmp-long v0, v7, v11

    .line 1215
    .line 1216
    if-nez v0, :cond_16

    .line 1217
    .line 1218
    invoke-static {v2}, LX3/n0;->g(LX3/v0;)V

    .line 1219
    .line 1220
    .line 1221
    iget-object v0, v2, LX3/U;->f:LP8/b;

    .line 1222
    .line 1223
    const-string v7, "Failed to insert default event parameters (got -1). appId"

    .line 1224
    .line 1225
    invoke-static {v10}, LX3/U;->z0(Ljava/lang/String;)LX3/T;

    .line 1226
    .line 1227
    .line 1228
    move-result-object v8

    .line 1229
    invoke-virtual {v0, v8, v7}, LP8/b;->c(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_f
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_f .. :try_end_f} :catch_5

    .line 1230
    .line 1231
    .line 1232
    goto :goto_13

    .line 1233
    :catch_5
    move-exception v0

    .line 1234
    invoke-static {v2}, LX3/n0;->g(LX3/v0;)V

    .line 1235
    .line 1236
    .line 1237
    iget-object v2, v2, LX3/U;->f:LP8/b;

    .line 1238
    .line 1239
    invoke-static {v10}, LX3/U;->z0(Ljava/lang/String;)LX3/T;

    .line 1240
    .line 1241
    .line 1242
    move-result-object v7

    .line 1243
    const-string v8, "Error storing default event parameters. appId"

    .line 1244
    .line 1245
    invoke-virtual {v2, v7, v0, v8}, LP8/b;->d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 1246
    .line 1247
    .line 1248
    :cond_16
    :goto_13
    iget-object v2, v5, LX3/H1;->c:LX3/n;

    .line 1249
    .line 1250
    invoke-static {v2}, LX3/H1;->R(LX3/C1;)V

    .line 1251
    .line 1252
    .line 1253
    iget-wide v7, v4, LX3/O1;->D:J

    .line 1254
    .line 1255
    :try_start_10
    const-string v0, "select count(*) from raw_events where app_id=? and timestamp >= ? and name not like \'!_%\' escape \'!\' limit 1;"

    .line 1256
    .line 1257
    invoke-static {v7, v8}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 1258
    .line 1259
    .line 1260
    move-result-object v4

    .line 1261
    filled-new-array {v10, v4}, [Ljava/lang/String;

    .line 1262
    .line 1263
    .line 1264
    move-result-object v4

    .line 1265
    const-wide/16 v11, 0x0

    .line 1266
    .line 1267
    invoke-virtual {v2, v11, v12, v0, v4}, LX3/n;->O0(JLjava/lang/String;[Ljava/lang/String;)J

    .line 1268
    .line 1269
    .line 1270
    move-result-wide v13

    .line 1271
    cmp-long v0, v13, v11

    .line 1272
    .line 1273
    if-lez v0, :cond_17

    .line 1274
    .line 1275
    goto :goto_14

    .line 1276
    :cond_17
    const-string v0, "select count(*) from raw_events where app_id=? and timestamp >= ? and name like \'!_%\' escape \'!\' limit 1;"

    .line 1277
    .line 1278
    invoke-static {v7, v8}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 1279
    .line 1280
    .line 1281
    move-result-object v4

    .line 1282
    filled-new-array {v10, v4}, [Ljava/lang/String;

    .line 1283
    .line 1284
    .line 1285
    move-result-object v4

    .line 1286
    invoke-virtual {v2, v11, v12, v0, v4}, LX3/n;->O0(JLjava/lang/String;[Ljava/lang/String;)J

    .line 1287
    .line 1288
    .line 1289
    move-result-wide v13
    :try_end_10
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_10 .. :try_end_10} :catch_6

    .line 1290
    cmp-long v0, v13, v11

    .line 1291
    .line 1292
    if-lez v0, :cond_18

    .line 1293
    .line 1294
    iget-object v0, v5, LX3/H1;->c:LX3/n;

    .line 1295
    .line 1296
    invoke-static {v0}, LX3/H1;->R(LX3/C1;)V

    .line 1297
    .line 1298
    .line 1299
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1300
    .line 1301
    .line 1302
    move-result-object v2

    .line 1303
    invoke-virtual {v0, v10, v2, v6, v3}, LX3/n;->L0(Ljava/lang/String;Ljava/lang/Long;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 1304
    .line 1305
    .line 1306
    goto :goto_14

    .line 1307
    :catch_6
    move-exception v0

    .line 1308
    iget-object v2, v2, LD/o;->a:Ljava/lang/Object;

    .line 1309
    .line 1310
    check-cast v2, LX3/n0;

    .line 1311
    .line 1312
    iget-object v2, v2, LX3/n0;->f:LX3/U;

    .line 1313
    .line 1314
    invoke-static {v2}, LX3/n0;->g(LX3/v0;)V

    .line 1315
    .line 1316
    .line 1317
    iget-object v2, v2, LX3/U;->f:LP8/b;

    .line 1318
    .line 1319
    const-string v3, "Error checking backfill conditions"

    .line 1320
    .line 1321
    invoke-virtual {v2, v0, v3}, LP8/b;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1322
    .line 1323
    .line 1324
    :cond_18
    :goto_14
    return-void

    .line 1325
    :pswitch_b
    iget-object v0, v1, LH0/y;->e:Ljava/lang/Object;

    .line 1326
    .line 1327
    check-cast v0, Lcom/google/android/gms/measurement/internal/AppMeasurementDynamiteService;

    .line 1328
    .line 1329
    iget-object v0, v0, Lcom/google/android/gms/measurement/internal/AppMeasurementDynamiteService;->e:LX3/n0;

    .line 1330
    .line 1331
    invoke-virtual {v0}, LX3/n0;->j()LX3/l1;

    .line 1332
    .line 1333
    .line 1334
    move-result-object v9

    .line 1335
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 1336
    .line 1337
    move-object v12, v0

    .line 1338
    check-cast v12, Lcom/google/android/gms/internal/measurement/L;

    .line 1339
    .line 1340
    iget-object v0, v1, LH0/y;->c:Ljava/lang/Object;

    .line 1341
    .line 1342
    move-object v10, v0

    .line 1343
    check-cast v10, LX3/t;

    .line 1344
    .line 1345
    iget-object v0, v1, LH0/y;->d:Ljava/lang/Object;

    .line 1346
    .line 1347
    move-object v11, v0

    .line 1348
    check-cast v11, Ljava/lang/String;

    .line 1349
    .line 1350
    invoke-virtual {v9}, LX3/B;->r0()V

    .line 1351
    .line 1352
    .line 1353
    invoke-virtual {v9}, LX3/G;->s0()V

    .line 1354
    .line 1355
    .line 1356
    iget-object v0, v9, LD/o;->a:Ljava/lang/Object;

    .line 1357
    .line 1358
    check-cast v0, LX3/n0;

    .line 1359
    .line 1360
    iget-object v2, v0, LX3/n0;->i:LX3/M1;

    .line 1361
    .line 1362
    invoke-static {v2}, LX3/n0;->e(LD/o;)V

    .line 1363
    .line 1364
    .line 1365
    iget-object v2, v2, LD/o;->a:Ljava/lang/Object;

    .line 1366
    .line 1367
    check-cast v2, LX3/n0;

    .line 1368
    .line 1369
    sget-object v3, Lx3/f;->b:Lx3/f;

    .line 1370
    .line 1371
    iget-object v2, v2, LX3/n0;->a:Landroid/content/Context;

    .line 1372
    .line 1373
    const v4, 0xbdfcb8

    .line 1374
    .line 1375
    .line 1376
    invoke-virtual {v3, v2, v4}, Lx3/f;->b(Landroid/content/Context;I)I

    .line 1377
    .line 1378
    .line 1379
    move-result v2

    .line 1380
    if-eqz v2, :cond_19

    .line 1381
    .line 1382
    iget-object v2, v0, LX3/n0;->f:LX3/U;

    .line 1383
    .line 1384
    invoke-static {v2}, LX3/n0;->g(LX3/v0;)V

    .line 1385
    .line 1386
    .line 1387
    iget-object v2, v2, LX3/U;->i:LP8/b;

    .line 1388
    .line 1389
    const-string v3, "Not bundling data. Service unavailable or out of date"

    .line 1390
    .line 1391
    invoke-virtual {v2, v3}, LP8/b;->b(Ljava/lang/String;)V

    .line 1392
    .line 1393
    .line 1394
    iget-object v0, v0, LX3/n0;->i:LX3/M1;

    .line 1395
    .line 1396
    invoke-static {v0}, LX3/n0;->e(LD/o;)V

    .line 1397
    .line 1398
    .line 1399
    new-array v2, v7, [B

    .line 1400
    .line 1401
    invoke-virtual {v0, v12, v2}, LX3/M1;->d1(Lcom/google/android/gms/internal/measurement/L;[B)V

    .line 1402
    .line 1403
    .line 1404
    goto :goto_15

    .line 1405
    :cond_19
    new-instance v8, LH0/y;

    .line 1406
    .line 1407
    const/4 v13, 0x6

    .line 1408
    const/4 v14, 0x0

    .line 1409
    invoke-direct/range {v8 .. v14}, LH0/y;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 1410
    .line 1411
    .line 1412
    invoke-virtual {v9, v8}, LX3/l1;->F0(Ljava/lang/Runnable;)V

    .line 1413
    .line 1414
    .line 1415
    :goto_15
    return-void

    .line 1416
    :pswitch_c
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 1417
    .line 1418
    check-cast v0, LX3/u0;

    .line 1419
    .line 1420
    iget-object v2, v1, LH0/y;->c:Ljava/lang/Object;

    .line 1421
    .line 1422
    check-cast v2, Ljava/lang/String;

    .line 1423
    .line 1424
    iget-object v3, v1, LH0/y;->d:Ljava/lang/Object;

    .line 1425
    .line 1426
    check-cast v3, LX3/A1;

    .line 1427
    .line 1428
    iget-object v5, v1, LH0/y;->e:Ljava/lang/Object;

    .line 1429
    .line 1430
    check-cast v5, LX3/L;

    .line 1431
    .line 1432
    iget-object v8, v0, LX3/u0;->e:LX3/H1;

    .line 1433
    .line 1434
    invoke-virtual {v8}, LX3/H1;->w()V

    .line 1435
    .line 1436
    .line 1437
    invoke-virtual {v8}, LX3/H1;->D()LX3/l0;

    .line 1438
    .line 1439
    .line 1440
    move-result-object v0

    .line 1441
    invoke-virtual {v0}, LX3/l0;->r0()V

    .line 1442
    .line 1443
    .line 1444
    invoke-virtual {v8}, LX3/H1;->k0()V

    .line 1445
    .line 1446
    .line 1447
    iget-object v0, v8, LX3/H1;->c:LX3/n;

    .line 1448
    .line 1449
    invoke-static {v0}, LX3/H1;->R(LX3/C1;)V

    .line 1450
    .line 1451
    .line 1452
    sget-object v9, LX3/E;->B:LX3/D;

    .line 1453
    .line 1454
    invoke-virtual {v9, v6}, LX3/D;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1455
    .line 1456
    .line 1457
    move-result-object v9

    .line 1458
    check-cast v9, Ljava/lang/Integer;

    .line 1459
    .line 1460
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 1461
    .line 1462
    .line 1463
    move-result v9

    .line 1464
    invoke-virtual {v0, v2, v3, v9}, LX3/n;->w0(Ljava/lang/String;LX3/A1;I)Ljava/util/List;

    .line 1465
    .line 1466
    .line 1467
    move-result-object v0

    .line 1468
    new-instance v3, Ljava/util/ArrayList;

    .line 1469
    .line 1470
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1471
    .line 1472
    .line 1473
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 1474
    .line 1475
    .line 1476
    move-result-object v0

    .line 1477
    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1478
    .line 1479
    .line 1480
    move-result v9

    .line 1481
    if-eqz v9, :cond_21

    .line 1482
    .line 1483
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1484
    .line 1485
    .line 1486
    move-result-object v9

    .line 1487
    check-cast v9, LX3/J1;

    .line 1488
    .line 1489
    iget-object v10, v9, LX3/J1;->c:Ljava/lang/String;

    .line 1490
    .line 1491
    iget-wide v11, v9, LX3/J1;->h:J

    .line 1492
    .line 1493
    iget-wide v13, v9, LX3/J1;->a:J

    .line 1494
    .line 1495
    invoke-virtual {v8, v2, v10}, LX3/H1;->n(Ljava/lang/String;Ljava/lang/String;)Z

    .line 1496
    .line 1497
    .line 1498
    move-result v10

    .line 1499
    if-nez v10, :cond_1a

    .line 1500
    .line 1501
    invoke-virtual {v8}, LX3/H1;->t()LX3/U;

    .line 1502
    .line 1503
    .line 1504
    move-result-object v10

    .line 1505
    iget-object v10, v10, LX3/U;->n:LP8/b;

    .line 1506
    .line 1507
    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1508
    .line 1509
    .line 1510
    move-result-object v11

    .line 1511
    iget-object v9, v9, LX3/J1;->c:Ljava/lang/String;

    .line 1512
    .line 1513
    const-string v12, "[sgtm] batch skipped due to destination in backoff. appId, rowId, url"

    .line 1514
    .line 1515
    invoke-virtual {v10, v12, v2, v11, v9}, LP8/b;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1516
    .line 1517
    .line 1518
    goto :goto_16

    .line 1519
    :cond_1a
    iget v10, v9, LX3/J1;->i:I

    .line 1520
    .line 1521
    if-gtz v10, :cond_1b

    .line 1522
    .line 1523
    move-object/from16 v19, v8

    .line 1524
    .line 1525
    goto :goto_17

    .line 1526
    :cond_1b
    sget-object v15, LX3/E;->z:LX3/D;

    .line 1527
    .line 1528
    invoke-virtual {v15, v6}, LX3/D;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1529
    .line 1530
    .line 1531
    move-result-object v15

    .line 1532
    check-cast v15, Ljava/lang/Integer;

    .line 1533
    .line 1534
    invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I

    .line 1535
    .line 1536
    .line 1537
    move-result v15

    .line 1538
    if-le v10, v15, :cond_1c

    .line 1539
    .line 1540
    move-object v9, v8

    .line 1541
    move-wide/from16 v16, v11

    .line 1542
    .line 1543
    goto/16 :goto_1d

    .line 1544
    .line 1545
    :cond_1c
    sget-object v15, LX3/E;->x:LX3/D;

    .line 1546
    .line 1547
    invoke-virtual {v15, v6}, LX3/D;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1548
    .line 1549
    .line 1550
    move-result-object v15

    .line 1551
    check-cast v15, Ljava/lang/Long;

    .line 1552
    .line 1553
    invoke-virtual {v15}, Ljava/lang/Long;->longValue()J

    .line 1554
    .line 1555
    .line 1556
    move-result-wide v15

    .line 1557
    add-int/lit8 v10, v10, -0x1

    .line 1558
    .line 1559
    const-wide/16 v17, 0x1

    .line 1560
    .line 1561
    shl-long v17, v17, v10

    .line 1562
    .line 1563
    move-object/from16 v19, v8

    .line 1564
    .line 1565
    mul-long v7, v15, v17

    .line 1566
    .line 1567
    sget-object v15, LX3/E;->y:LX3/D;

    .line 1568
    .line 1569
    invoke-virtual {v15, v6}, LX3/D;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1570
    .line 1571
    .line 1572
    move-result-object v15

    .line 1573
    check-cast v15, Ljava/lang/Long;

    .line 1574
    .line 1575
    move-wide/from16 v16, v11

    .line 1576
    .line 1577
    invoke-virtual {v15}, Ljava/lang/Long;->longValue()J

    .line 1578
    .line 1579
    .line 1580
    move-result-wide v10

    .line 1581
    invoke-static {v7, v8, v10, v11}, Ljava/lang/Math;->min(JJ)J

    .line 1582
    .line 1583
    .line 1584
    move-result-wide v7

    .line 1585
    invoke-virtual/range {v19 .. v19}, LX3/H1;->L()LG3/a;

    .line 1586
    .line 1587
    .line 1588
    move-result-object v10

    .line 1589
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1590
    .line 1591
    .line 1592
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 1593
    .line 1594
    .line 1595
    move-result-wide v10

    .line 1596
    add-long v7, v16, v7

    .line 1597
    .line 1598
    cmp-long v7, v10, v7

    .line 1599
    .line 1600
    if-ltz v7, :cond_20

    .line 1601
    .line 1602
    :goto_17
    new-instance v7, Landroid/os/Bundle;

    .line 1603
    .line 1604
    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    .line 1605
    .line 1606
    .line 1607
    iget-object v8, v9, LX3/J1;->d:Ljava/util/HashMap;

    .line 1608
    .line 1609
    invoke-virtual {v8}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 1610
    .line 1611
    .line 1612
    move-result-object v8

    .line 1613
    invoke-interface {v8}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 1614
    .line 1615
    .line 1616
    move-result-object v8

    .line 1617
    :goto_18
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 1618
    .line 1619
    .line 1620
    move-result v10

    .line 1621
    if-eqz v10, :cond_1d

    .line 1622
    .line 1623
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1624
    .line 1625
    .line 1626
    move-result-object v10

    .line 1627
    check-cast v10, Ljava/util/Map$Entry;

    .line 1628
    .line 1629
    invoke-interface {v10}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1630
    .line 1631
    .line 1632
    move-result-object v11

    .line 1633
    check-cast v11, Ljava/lang/String;

    .line 1634
    .line 1635
    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1636
    .line 1637
    .line 1638
    move-result-object v10

    .line 1639
    check-cast v10, Ljava/lang/String;

    .line 1640
    .line 1641
    invoke-virtual {v7, v11, v10}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 1642
    .line 1643
    .line 1644
    goto :goto_18

    .line 1645
    :cond_1d
    iget-wide v10, v9, LX3/J1;->a:J

    .line 1646
    .line 1647
    iget-object v8, v9, LX3/J1;->b:Lcom/google/android/gms/internal/measurement/h1;

    .line 1648
    .line 1649
    iget-object v13, v9, LX3/J1;->c:Ljava/lang/String;

    .line 1650
    .line 1651
    iget-object v14, v9, LX3/J1;->e:LX3/W0;

    .line 1652
    .line 1653
    move-object/from16 v24, v13

    .line 1654
    .line 1655
    iget-wide v12, v9, LX3/J1;->g:J

    .line 1656
    .line 1657
    new-instance v20, LX3/z1;

    .line 1658
    .line 1659
    invoke-virtual {v8}, Lcom/google/android/gms/internal/measurement/S1;->a()[B

    .line 1660
    .line 1661
    .line 1662
    move-result-object v23

    .line 1663
    iget v8, v14, LX3/W0;->a:I

    .line 1664
    .line 1665
    const-string v29, ""

    .line 1666
    .line 1667
    move-object/from16 v25, v7

    .line 1668
    .line 1669
    move/from16 v26, v8

    .line 1670
    .line 1671
    move-wide/from16 v21, v10

    .line 1672
    .line 1673
    move-wide/from16 v27, v12

    .line 1674
    .line 1675
    invoke-direct/range {v20 .. v29}, LX3/z1;-><init>(J[BLjava/lang/String;Landroid/os/Bundle;IJLjava/lang/String;)V

    .line 1676
    .line 1677
    .line 1678
    move-object/from16 v7, v20

    .line 1679
    .line 1680
    :try_start_11
    invoke-static {}, Lcom/google/android/gms/internal/measurement/h1;->w()Lcom/google/android/gms/internal/measurement/g1;

    .line 1681
    .line 1682
    .line 1683
    move-result-object v8

    .line 1684
    iget-object v9, v7, LX3/z1;->b:[B

    .line 1685
    .line 1686
    invoke-static {v8, v9}, LX3/X;->e1(Lcom/google/android/gms/internal/measurement/g2;[B)Lcom/google/android/gms/internal/measurement/g2;

    .line 1687
    .line 1688
    .line 1689
    move-result-object v8

    .line 1690
    check-cast v8, Lcom/google/android/gms/internal/measurement/g1;

    .line 1691
    .line 1692
    const/4 v9, 0x0

    .line 1693
    :goto_19
    iget-object v10, v8, Lcom/google/android/gms/internal/measurement/g2;->b:Lcom/google/android/gms/internal/measurement/h2;

    .line 1694
    .line 1695
    check-cast v10, Lcom/google/android/gms/internal/measurement/h1;

    .line 1696
    .line 1697
    invoke-virtual {v10}, Lcom/google/android/gms/internal/measurement/h1;->q()I

    .line 1698
    .line 1699
    .line 1700
    move-result v10

    .line 1701
    if-ge v9, v10, :cond_1e

    .line 1702
    .line 1703
    iget-object v10, v8, Lcom/google/android/gms/internal/measurement/g2;->b:Lcom/google/android/gms/internal/measurement/h2;

    .line 1704
    .line 1705
    check-cast v10, Lcom/google/android/gms/internal/measurement/h1;

    .line 1706
    .line 1707
    invoke-virtual {v10, v9}, Lcom/google/android/gms/internal/measurement/h1;->r(I)Lcom/google/android/gms/internal/measurement/j1;

    .line 1708
    .line 1709
    .line 1710
    move-result-object v10

    .line 1711
    invoke-virtual {v10}, Lcom/google/android/gms/internal/measurement/h2;->i()Lcom/google/android/gms/internal/measurement/g2;

    .line 1712
    .line 1713
    .line 1714
    move-result-object v10

    .line 1715
    check-cast v10, Lcom/google/android/gms/internal/measurement/i1;

    .line 1716
    .line 1717
    invoke-virtual/range {v19 .. v19}, LX3/H1;->L()LG3/a;

    .line 1718
    .line 1719
    .line 1720
    move-result-object v11

    .line 1721
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1722
    .line 1723
    .line 1724
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 1725
    .line 1726
    .line 1727
    move-result-wide v11

    .line 1728
    invoke-virtual {v10}, Lcom/google/android/gms/internal/measurement/g2;->b()V

    .line 1729
    .line 1730
    .line 1731
    iget-object v13, v10, Lcom/google/android/gms/internal/measurement/g2;->b:Lcom/google/android/gms/internal/measurement/h2;

    .line 1732
    .line 1733
    check-cast v13, Lcom/google/android/gms/internal/measurement/j1;

    .line 1734
    .line 1735
    invoke-virtual {v13, v11, v12}, Lcom/google/android/gms/internal/measurement/j1;->f0(J)V

    .line 1736
    .line 1737
    .line 1738
    invoke-virtual {v8}, Lcom/google/android/gms/internal/measurement/g2;->b()V

    .line 1739
    .line 1740
    .line 1741
    iget-object v11, v8, Lcom/google/android/gms/internal/measurement/g2;->b:Lcom/google/android/gms/internal/measurement/h2;

    .line 1742
    .line 1743
    check-cast v11, Lcom/google/android/gms/internal/measurement/h1;

    .line 1744
    .line 1745
    invoke-virtual {v10}, Lcom/google/android/gms/internal/measurement/g2;->e()Lcom/google/android/gms/internal/measurement/h2;

    .line 1746
    .line 1747
    .line 1748
    move-result-object v10

    .line 1749
    check-cast v10, Lcom/google/android/gms/internal/measurement/j1;

    .line 1750
    .line 1751
    invoke-virtual {v11, v9, v10}, Lcom/google/android/gms/internal/measurement/h1;->y(ILcom/google/android/gms/internal/measurement/j1;)V

    .line 1752
    .line 1753
    .line 1754
    add-int/lit8 v9, v9, 0x1

    .line 1755
    .line 1756
    goto :goto_19

    .line 1757
    :catch_7
    move-object/from16 v9, v19

    .line 1758
    .line 1759
    goto :goto_1c

    .line 1760
    :cond_1e
    invoke-virtual {v8}, Lcom/google/android/gms/internal/measurement/g2;->e()Lcom/google/android/gms/internal/measurement/h2;

    .line 1761
    .line 1762
    .line 1763
    move-result-object v9

    .line 1764
    check-cast v9, Lcom/google/android/gms/internal/measurement/h1;

    .line 1765
    .line 1766
    invoke-virtual {v9}, Lcom/google/android/gms/internal/measurement/S1;->a()[B

    .line 1767
    .line 1768
    .line 1769
    move-result-object v9

    .line 1770
    iput-object v9, v7, LX3/z1;->b:[B

    .line 1771
    .line 1772
    invoke-virtual/range {v19 .. v19}, LX3/H1;->t()LX3/U;

    .line 1773
    .line 1774
    .line 1775
    move-result-object v9

    .line 1776
    invoke-virtual {v9}, LX3/U;->B0()Ljava/lang/String;

    .line 1777
    .line 1778
    .line 1779
    move-result-object v9

    .line 1780
    invoke-static {v9, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 1781
    .line 1782
    .line 1783
    move-result v9
    :try_end_11
    .catch Lcom/google/android/gms/internal/measurement/q2; {:try_start_11 .. :try_end_11} :catch_7

    .line 1784
    if-eqz v9, :cond_1f

    .line 1785
    .line 1786
    move-object/from16 v9, v19

    .line 1787
    .line 1788
    :try_start_12
    iget-object v10, v9, LX3/H1;->g:LX3/X;

    .line 1789
    .line 1790
    invoke-static {v10}, LX3/H1;->R(LX3/C1;)V

    .line 1791
    .line 1792
    .line 1793
    invoke-virtual {v8}, Lcom/google/android/gms/internal/measurement/g2;->e()Lcom/google/android/gms/internal/measurement/h2;

    .line 1794
    .line 1795
    .line 1796
    move-result-object v8

    .line 1797
    check-cast v8, Lcom/google/android/gms/internal/measurement/h1;

    .line 1798
    .line 1799
    invoke-virtual {v10, v8}, LX3/X;->U0(Lcom/google/android/gms/internal/measurement/h1;)Ljava/lang/String;

    .line 1800
    .line 1801
    .line 1802
    move-result-object v8

    .line 1803
    iput-object v8, v7, LX3/z1;->g:Ljava/lang/String;
    :try_end_12
    .catch Lcom/google/android/gms/internal/measurement/q2; {:try_start_12 .. :try_end_12} :catch_8

    .line 1804
    .line 1805
    goto :goto_1a

    .line 1806
    :cond_1f
    move-object/from16 v9, v19

    .line 1807
    .line 1808
    :goto_1a
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1809
    .line 1810
    .line 1811
    :goto_1b
    move-object v8, v9

    .line 1812
    const/4 v7, 0x0

    .line 1813
    goto/16 :goto_16

    .line 1814
    .line 1815
    :catch_8
    :goto_1c
    invoke-virtual {v9}, LX3/H1;->t()LX3/U;

    .line 1816
    .line 1817
    .line 1818
    move-result-object v7

    .line 1819
    iget-object v7, v7, LX3/U;->i:LP8/b;

    .line 1820
    .line 1821
    const-string v8, "Failed to parse queued batch. appId"

    .line 1822
    .line 1823
    invoke-virtual {v7, v2, v8}, LP8/b;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1824
    .line 1825
    .line 1826
    goto :goto_1b

    .line 1827
    :cond_20
    move-object/from16 v9, v19

    .line 1828
    .line 1829
    :goto_1d
    invoke-virtual {v9}, LX3/H1;->t()LX3/U;

    .line 1830
    .line 1831
    .line 1832
    move-result-object v7

    .line 1833
    iget-object v7, v7, LX3/U;->n:LP8/b;

    .line 1834
    .line 1835
    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1836
    .line 1837
    .line 1838
    move-result-object v8

    .line 1839
    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1840
    .line 1841
    .line 1842
    move-result-object v10

    .line 1843
    const-string v11, "[sgtm] batch skipped waiting for next retry. appId, rowId, lastUploadMillis"

    .line 1844
    .line 1845
    invoke-virtual {v7, v11, v2, v8, v10}, LP8/b;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1846
    .line 1847
    .line 1848
    goto :goto_1b

    .line 1849
    :cond_21
    move-object v9, v8

    .line 1850
    new-instance v0, LX3/B1;

    .line 1851
    .line 1852
    invoke-direct {v0, v3}, LX3/B1;-><init>(Ljava/util/ArrayList;)V

    .line 1853
    .line 1854
    .line 1855
    :try_start_13
    invoke-interface {v5, v0}, LX3/L;->B0(LX3/B1;)V

    .line 1856
    .line 1857
    .line 1858
    invoke-virtual {v9}, LX3/H1;->t()LX3/U;

    .line 1859
    .line 1860
    .line 1861
    move-result-object v0

    .line 1862
    iget-object v0, v0, LX3/U;->n:LP8/b;

    .line 1863
    .line 1864
    const-string v4, "[sgtm] Sending queued upload batches to client. appId, count"

    .line 1865
    .line 1866
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 1867
    .line 1868
    .line 1869
    move-result v3

    .line 1870
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1871
    .line 1872
    .line 1873
    move-result-object v3

    .line 1874
    invoke-virtual {v0, v2, v3, v4}, LP8/b;->d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_13
    .catch Landroid/os/RemoteException; {:try_start_13 .. :try_end_13} :catch_9

    .line 1875
    .line 1876
    .line 1877
    goto :goto_1e

    .line 1878
    :catch_9
    move-exception v0

    .line 1879
    invoke-virtual {v9}, LX3/H1;->t()LX3/U;

    .line 1880
    .line 1881
    .line 1882
    move-result-object v3

    .line 1883
    iget-object v3, v3, LX3/U;->f:LP8/b;

    .line 1884
    .line 1885
    const-string v4, "[sgtm] Failed to return upload batches for app"

    .line 1886
    .line 1887
    invoke-virtual {v3, v2, v0, v4}, LP8/b;->d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 1888
    .line 1889
    .line 1890
    :goto_1e
    return-void

    .line 1891
    :pswitch_d
    iget-object v0, v1, LH0/y;->c:Ljava/lang/Object;

    .line 1892
    .line 1893
    move-object v2, v0

    .line 1894
    check-cast v2, LB8/h;

    .line 1895
    .line 1896
    :try_start_14
    iget-object v0, v1, LH0/y;->b:Ljava/lang/Object;

    .line 1897
    .line 1898
    check-cast v0, Lh8/i;

    .line 1899
    .line 1900
    sget-object v3, Lh8/e;->a:Lh8/e;

    .line 1901
    .line 1902
    invoke-interface {v0, v3}, Lh8/i;->minusKey(Lh8/h;)Lh8/i;

    .line 1903
    .line 1904
    .line 1905
    move-result-object v0

    .line 1906
    new-instance v3, LH0/x;

    .line 1907
    .line 1908
    iget-object v4, v1, LH0/y;->d:Ljava/lang/Object;

    .line 1909
    .line 1910
    check-cast v4, LH0/w;

    .line 1911
    .line 1912
    iget-object v5, v1, LH0/y;->e:Ljava/lang/Object;

    .line 1913
    .line 1914
    check-cast v5, LH0/z;

    .line 1915
    .line 1916
    invoke-direct {v3, v4, v2, v5, v6}, LH0/x;-><init>(LH0/w;LB8/h;LH0/z;Lh8/d;)V

    .line 1917
    .line 1918
    .line 1919
    invoke-static {v0, v3}, LB8/D;->v(Lh8/i;Lr8/p;)Ljava/lang/Object;
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_5

    .line 1920
    .line 1921
    .line 1922
    goto :goto_1f

    .line 1923
    :catchall_5
    move-exception v0

    .line 1924
    invoke-virtual {v2, v0}, LB8/h;->d(Ljava/lang/Throwable;)Z

    .line 1925
    .line 1926
    .line 1927
    :goto_1f
    return-void

    .line 1928
    nop

    .line 1929
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
