.class public final LH0/O;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public r:LH0/m;

.field public s:Ljava/lang/String;

.field public t:[Ljava/lang/String;

.field public u:I

.field public v:I

.field public synthetic w:Ljava/lang/Object;

.field public final synthetic x:LH0/T;

.field public y:I


# direct methods
.method public constructor <init>(LH0/T;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH0/O;->x:LH0/T;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iput-object p1, p0, LH0/O;->w:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, LH0/O;->y:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, LH0/O;->y:I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    const/4 v0, 0x0

    .line 12
    iget-object v1, p0, LH0/O;->x:LH0/T;

    .line 13
    .line 14
    invoke-static {v1, p1, v0, p0}, LH0/T;->d(LH0/T;LH0/G;ILj8/c;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    return-object p1
.end method
