.class public final LH0/x;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:I

.field public synthetic s:Ljava/lang/Object;

.field public final synthetic t:LH0/w;

.field public final synthetic u:LB8/h;

.field public final synthetic v:LH0/z;


# direct methods
.method public constructor <init>(LH0/w;LB8/h;LH0/z;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH0/x;->t:LH0/w;

    .line 2
    .line 3
    iput-object p2, p0, LH0/x;->u:LB8/h;

    .line 4
    .line 5
    iput-object p3, p0, LH0/x;->v:LH0/z;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Lj8/i;-><init>(ILh8/d;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 4

    .line 1
    new-instance v0, LH0/x;

    .line 2
    .line 3
    iget-object v1, p0, LH0/x;->u:LB8/h;

    .line 4
    .line 5
    iget-object v2, p0, LH0/x;->v:LH0/z;

    .line 6
    .line 7
    iget-object v3, p0, LH0/x;->t:LH0/w;

    .line 8
    .line 9
    invoke-direct {v0, v3, v1, v2, p2}, LH0/x;-><init>(LH0/w;LB8/h;LH0/z;Lh8/d;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, v0, LH0/x;->s:Ljava/lang/Object;

    .line 13
    .line 14
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LH0/x;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LH0/x;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LH0/x;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LH0/x;->r:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    iget-object v0, p0, LH0/x;->s:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lh8/d;

    .line 11
    .line 12
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 19
    .line 20
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    throw p1

    .line 24
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget-object p1, p0, LH0/x;->s:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast p1, LB8/A;

    .line 30
    .line 31
    invoke-interface {p1}, LB8/A;->u()Lh8/i;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    sget-object v0, Lh8/e;->a:Lh8/e;

    .line 36
    .line 37
    invoke-interface {p1, v0}, Lh8/i;->get(Lh8/h;)Lh8/g;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    invoke-static {p1}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    check-cast p1, Lh8/f;

    .line 45
    .line 46
    new-instance v0, LH0/D;

    .line 47
    .line 48
    invoke-direct {v0, p1}, LH0/D;-><init>(Lh8/f;)V

    .line 49
    .line 50
    .line 51
    iget-object v2, p0, LH0/x;->t:LH0/w;

    .line 52
    .line 53
    iget-object v2, v2, LH0/w;->i:Ljava/lang/ThreadLocal;

    .line 54
    .line 55
    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 56
    .line 57
    .line 58
    move-result v3

    .line 59
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    new-instance v4, LG8/z;

    .line 64
    .line 65
    invoke-direct {v4, v3, v2}, LG8/z;-><init>(Ljava/lang/Object;Ljava/lang/ThreadLocal;)V

    .line 66
    .line 67
    .line 68
    check-cast p1, Lh8/a;

    .line 69
    .line 70
    invoke-virtual {p1, v0}, Lh8/a;->plus(Lh8/i;)Lh8/i;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-interface {p1, v4}, Lh8/i;->plus(Lh8/i;)Lh8/i;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    iget-object v0, p0, LH0/x;->u:LB8/h;

    .line 79
    .line 80
    iput-object v0, p0, LH0/x;->s:Ljava/lang/Object;

    .line 81
    .line 82
    iput v1, p0, LH0/x;->r:I

    .line 83
    .line 84
    iget-object v1, p0, LH0/x;->v:LH0/z;

    .line 85
    .line 86
    invoke-static {p1, v1, p0}, LB8/D;->C(Lh8/i;Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    sget-object v1, Li8/a;->a:Li8/a;

    .line 91
    .line 92
    if-ne p1, v1, :cond_2

    .line 93
    .line 94
    return-object v1

    .line 95
    :cond_2
    :goto_0
    invoke-interface {v0, p1}, Lh8/d;->resumeWith(Ljava/lang/Object;)V

    .line 96
    .line 97
    .line 98
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 99
    .line 100
    return-object p1
.end method
