.class public final LH0/z;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:I

.field public synthetic s:Ljava/lang/Object;

.field public final synthetic t:LN0/c;


# direct methods
.method public constructor <init>(LN0/c;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, LH0/z;->t:LN0/c;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lj8/i;-><init>(ILh8/d;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 2

    .line 1
    new-instance v0, LH0/z;

    .line 2
    .line 3
    iget-object v1, p0, LH0/z;->t:LN0/c;

    .line 4
    .line 5
    invoke-direct {v0, v1, p2}, LH0/z;-><init>(LN0/c;Lh8/d;)V

    .line 6
    .line 7
    .line 8
    iput-object p1, v0, LH0/z;->s:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LH0/z;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LH0/z;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LH0/z;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LH0/z;->r:I

    .line 2
    .line 3
    const-string v1, "Transaction was never started or was already released."

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    if-ne v0, v2, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, LH0/z;->s:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, LH0/D;

    .line 13
    .line 14
    :try_start_0
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :catchall_0
    move-exception p1

    .line 19
    goto :goto_1

    .line 20
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 21
    .line 22
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 23
    .line 24
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    throw p1

    .line 28
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iget-object p1, p0, LH0/z;->s:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p1, LB8/A;

    .line 34
    .line 35
    invoke-interface {p1}, LB8/A;->u()Lh8/i;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    sget-object v0, LH0/D;->c:LK5/f;

    .line 40
    .line 41
    invoke-interface {p1, v0}, Lh8/i;->get(Lh8/h;)Lh8/g;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-static {p1}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    move-object v0, p1

    .line 49
    check-cast v0, LH0/D;

    .line 50
    .line 51
    iget-object p1, v0, LH0/D;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 52
    .line 53
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 54
    .line 55
    .line 56
    :try_start_1
    iget-object p1, p0, LH0/z;->t:LN0/c;

    .line 57
    .line 58
    iput-object v0, p0, LH0/z;->s:Ljava/lang/Object;

    .line 59
    .line 60
    iput v2, p0, LH0/z;->r:I

    .line 61
    .line 62
    invoke-virtual {p1, p0}, LN0/c;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 66
    sget-object v2, Li8/a;->a:Li8/a;

    .line 67
    .line 68
    if-ne p1, v2, :cond_2

    .line 69
    .line 70
    return-object v2

    .line 71
    :cond_2
    :goto_0
    iget-object v0, v0, LH0/D;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 72
    .line 73
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    if-ltz v0, :cond_3

    .line 78
    .line 79
    return-object p1

    .line 80
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 81
    .line 82
    invoke-direct {p1, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    throw p1

    .line 86
    :goto_1
    iget-object v0, v0, LH0/D;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 87
    .line 88
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    if-ltz v0, :cond_4

    .line 93
    .line 94
    throw p1

    .line 95
    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 96
    .line 97
    invoke-direct {p1, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    throw p1
.end method
