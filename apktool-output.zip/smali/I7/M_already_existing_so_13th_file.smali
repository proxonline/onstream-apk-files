.class public final Li7/m;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:Lcom/maertsno/m/ui/player/MoviePlayerActivity;


# direct methods
.method public constructor <init>(Lcom/maertsno/m/ui/player/MoviePlayerActivity;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, Li7/m;->s:Lcom/maertsno/m/ui/player/MoviePlayerActivity;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lj8/i;-><init>(ILh8/d;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 2

    .line 1
    new-instance v0, Li7/m;

    .line 2
    .line 3
    iget-object v1, p0, Li7/m;->s:Lcom/maertsno/m/ui/player/MoviePlayerActivity;

    .line 4
    .line 5
    invoke-direct {v0, v1, p2}, Li7/m;-><init>(Lcom/maertsno/m/ui/player/MoviePlayerActivity;Lh8/d;)V

    .line 6
    .line 7
    .line 8
    iput-object p1, v0, Li7/m;->r:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lcom/maertsno/domain/model/Movie;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Li7/m;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Li7/m;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Li7/m;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-object p2
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, Li7/m;->r:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/maertsno/domain/model/Movie;

    .line 4
    .line 5
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    iget-wide v1, v0, Lcom/maertsno/domain/model/Movie;->a:J

    .line 9
    .line 10
    const-wide/16 v3, 0x0

    .line 11
    .line 12
    cmp-long p1, v1, v3

    .line 13
    .line 14
    sget-object v1, Ld8/l;->a:Ld8/l;

    .line 15
    .line 16
    if-nez p1, :cond_0

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    sget p1, Lcom/maertsno/m/ui/player/MoviePlayerActivity;->i0:I

    .line 20
    .line 21
    iget-object p1, p0, Li7/m;->s:Lcom/maertsno/m/ui/player/MoviePlayerActivity;

    .line 22
    .line 23
    iget-object p1, p1, Lcom/maertsno/m/ui/player/MoviePlayerActivity;->X:LN6/c;

    .line 24
    .line 25
    if-eqz p1, :cond_2

    .line 26
    .line 27
    iget-object p1, p1, LN6/c;->T:Lcom/maertsno/exoplayer/StyledPlayerView;

    .line 28
    .line 29
    const v2, 0x7f0a0082

    .line 30
    .line 31
    .line 32
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    if-eqz p1, :cond_1

    .line 37
    .line 38
    check-cast p1, Landroid/widget/Button;

    .line 39
    .line 40
    iget-object v0, v0, Lcom/maertsno/domain/model/Movie;->d:Ljava/lang/String;

    .line 41
    .line 42
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 43
    .line 44
    .line 45
    :cond_1
    :goto_0
    return-object v1

    .line 46
    :cond_2
    const-string p1, "binding"

    .line 47
    .line 48
    invoke-static {p1}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    const/4 p1, 0x0

    .line 52
    throw p1
.end method
