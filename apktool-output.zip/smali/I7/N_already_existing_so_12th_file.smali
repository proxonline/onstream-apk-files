.class public final Li7/n;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:I

.field public final synthetic s:Lcom/maertsno/m/ui/player/MoviePlayerActivity;


# direct methods
.method public constructor <init>(Lcom/maertsno/m/ui/player/MoviePlayerActivity;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, Li7/n;->s:Lcom/maertsno/m/ui/player/MoviePlayerActivity;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lj8/i;-><init>(ILh8/d;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 1

    .line 1
    new-instance p1, Li7/n;

    .line 2
    .line 3
    iget-object v0, p0, Li7/n;->s:Lcom/maertsno/m/ui/player/MoviePlayerActivity;

    .line 4
    .line 5
    invoke-direct {p1, v0, p2}, Li7/n;-><init>(Lcom/maertsno/m/ui/player/MoviePlayerActivity;Lh8/d;)V

    .line 6
    .line 7
    .line 8
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Li7/n;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Li7/n;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Li7/n;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, Li7/n;->r:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p1

    .line 20
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    sget p1, Lcom/maertsno/m/ui/player/MoviePlayerActivity;->i0:I

    .line 24
    .line 25
    iget-object p1, p0, Li7/n;->s:Lcom/maertsno/m/ui/player/MoviePlayerActivity;

    .line 26
    .line 27
    invoke-virtual {p1}, Lcom/maertsno/m/ui/player/MoviePlayerActivity;->d0()Li7/I;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iget-object v0, v0, Li7/I;->h:LE8/U;

    .line 32
    .line 33
    new-instance v2, LE8/K;

    .line 34
    .line 35
    invoke-direct {v2, v0}, LE8/K;-><init>(LE8/I;)V

    .line 36
    .line 37
    .line 38
    new-instance v0, Li7/m;

    .line 39
    .line 40
    const/4 v3, 0x0

    .line 41
    invoke-direct {v0, p1, v3}, Li7/m;-><init>(Lcom/maertsno/m/ui/player/MoviePlayerActivity;Lh8/d;)V

    .line 42
    .line 43
    .line 44
    iput v1, p0, Li7/n;->r:I

    .line 45
    .line 46
    invoke-static {v2, v0, p0}, LE8/P;->h(LE8/e;Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    sget-object v0, Li8/a;->a:Li8/a;

    .line 51
    .line 52
    if-ne p1, v0, :cond_2

    .line 53
    .line 54
    return-object v0

    .line 55
    :cond_2
    :goto_0
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 56
    .line 57
    return-object p1
.end method
