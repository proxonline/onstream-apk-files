.class public final synthetic Li7/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr8/l;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, Li7/j;->a:I

    iput-object p1, p0, Li7/j;->b:Ljava/lang/Object;

    iput-object p3, p0, Li7/j;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Li7/j;->a:I

    .line 4
    .line 5
    const v4, 0x7f1400ed

    .line 6
    .line 7
    .line 8
    const v5, 0x7f1400ec

    .line 9
    .line 10
    .line 11
    const v6, 0x7f1400ea

    .line 12
    .line 13
    .line 14
    const v7, 0x7f1400ee

    .line 15
    .line 16
    .line 17
    const v8, 0x7f140107

    .line 18
    .line 19
    .line 20
    const/4 v9, 0x4

    .line 21
    const/4 v10, 0x3

    .line 22
    const/4 v11, 0x2

    .line 23
    const/4 v12, 0x1

    .line 24
    const-string v13, "it"

    .line 25
    .line 26
    const-string v14, "_connection"

    .line 27
    .line 28
    sget-object v15, Ld8/l;->a:Ld8/l;

    .line 29
    .line 30
    iget-object v2, v1, Li7/j;->c:Ljava/lang/Object;

    .line 31
    .line 32
    iget-object v3, v1, Li7/j;->b:Ljava/lang/Object;

    .line 33
    .line 34
    packed-switch v0, :pswitch_data_0

    .line 35
    .line 36
    .line 37
    check-cast v3, Lo6/k;

    .line 38
    .line 39
    check-cast v2, Lp6/c;

    .line 40
    .line 41
    move-object/from16 v0, p1

    .line 42
    .line 43
    check-cast v0, LR0/a;

    .line 44
    .line 45
    invoke-static {v0, v14}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    iget-object v3, v3, Lo6/k;->b:Lo6/h;

    .line 49
    .line 50
    invoke-virtual {v3, v0, v2}, Lcom/google/android/gms/internal/measurement/I1;->x(LR0/a;Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-object v15

    .line 54
    :pswitch_0
    check-cast v3, Lo6/i;

    .line 55
    .line 56
    check-cast v2, Lp6/b;

    .line 57
    .line 58
    move-object/from16 v0, p1

    .line 59
    .line 60
    check-cast v0, LR0/a;

    .line 61
    .line 62
    invoke-static {v0, v14}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    iget-object v3, v3, Lo6/i;->b:Lo6/h;

    .line 66
    .line 67
    invoke-virtual {v3, v0, v2}, Lcom/google/android/gms/internal/measurement/I1;->x(LR0/a;Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    return-object v15

    .line 71
    :pswitch_1
    check-cast v3, Lo6/e;

    .line 72
    .line 73
    check-cast v2, Ljava/util/List;

    .line 74
    .line 75
    move-object/from16 v0, p1

    .line 76
    .line 77
    check-cast v0, LR0/a;

    .line 78
    .line 79
    invoke-static {v0, v14}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    iget-object v3, v3, Lo6/e;->b:Lo6/c;

    .line 83
    .line 84
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    if-nez v2, :cond_0

    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_0
    const-string v4, "INSERT OR REPLACE INTO `tbl_continue` (`id`,`user_id`,`movie_id`,`season_id`,`episode_id`,`season_number`,`episode_number`,`time`,`percent`,`status`,`updated_at`,`movie`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"

    .line 91
    .line 92
    invoke-interface {v0, v4}, LR0/a;->d0(Ljava/lang/String;)LR0/c;

    .line 93
    .line 94
    .line 95
    move-result-object v4

    .line 96
    :try_start_0
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 101
    .line 102
    .line 103
    move-result v2

    .line 104
    if-eqz v2, :cond_2

    .line 105
    .line 106
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v2

    .line 110
    if-eqz v2, :cond_1

    .line 111
    .line 112
    invoke-virtual {v3, v4, v2}, Lo6/c;->b(LR0/c;Ljava/lang/Object;)V

    .line 113
    .line 114
    .line 115
    invoke-interface {v4}, LR0/c;->W()Z

    .line 116
    .line 117
    .line 118
    invoke-interface {v4}, LR0/c;->reset()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 119
    .line 120
    .line 121
    goto :goto_0

    .line 122
    :catchall_0
    move-exception v0

    .line 123
    move-object v2, v0

    .line 124
    goto :goto_2

    .line 125
    :cond_2
    const/4 v0, 0x0

    .line 126
    invoke-static {v4, v0}, Lcom/google/android/gms/internal/measurement/I1;->h(LR0/c;Ljava/lang/Throwable;)V

    .line 127
    .line 128
    .line 129
    :goto_1
    return-object v15

    .line 130
    :goto_2
    :try_start_1
    throw v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 131
    :catchall_1
    move-exception v0

    .line 132
    invoke-static {v4, v2}, Lcom/google/android/gms/internal/measurement/I1;->h(LR0/c;Ljava/lang/Throwable;)V

    .line 133
    .line 134
    .line 135
    throw v0

    .line 136
    :pswitch_2
    check-cast v3, Lo6/e;

    .line 137
    .line 138
    check-cast v2, Lp6/a;

    .line 139
    .line 140
    move-object/from16 v0, p1

    .line 141
    .line 142
    check-cast v0, LR0/a;

    .line 143
    .line 144
    invoke-static {v0, v14}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    iget-object v3, v3, Lo6/e;->b:Lo6/c;

    .line 148
    .line 149
    invoke-virtual {v3, v0, v2}, Lcom/google/android/gms/internal/measurement/I1;->x(LR0/a;Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    return-object v15

    .line 153
    :pswitch_3
    check-cast v3, Lcom/maertsno/exoplayer/StyledPlayerView;

    .line 154
    .line 155
    check-cast v2, Lcom/maertsno/m/ui/player/PlayerActivity;

    .line 156
    .line 157
    move-object/from16 v0, p1

    .line 158
    .line 159
    check-cast v0, Landroid/view/View;

    .line 160
    .line 161
    sget v14, Lcom/maertsno/m/ui/player/PlayerActivity;->j0:I

    .line 162
    .line 163
    invoke-static {v0, v13}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v3}, Lcom/maertsno/exoplayer/StyledPlayerView;->getResizeMode()I

    .line 167
    .line 168
    .line 169
    move-result v13

    .line 170
    if-eq v13, v12, :cond_6

    .line 171
    .line 172
    if-eq v13, v11, :cond_5

    .line 173
    .line 174
    if-eq v13, v10, :cond_4

    .line 175
    .line 176
    if-eq v13, v9, :cond_3

    .line 177
    .line 178
    move v4, v8

    .line 179
    goto :goto_3

    .line 180
    :cond_3
    move v4, v7

    .line 181
    goto :goto_3

    .line 182
    :cond_4
    move v4, v6

    .line 183
    goto :goto_3

    .line 184
    :cond_5
    move v4, v5

    .line 185
    :cond_6
    :goto_3
    invoke-virtual {v3}, Lcom/maertsno/exoplayer/StyledPlayerView;->getResizeMode()I

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    if-nez v3, :cond_7

    .line 190
    .line 191
    const v3, 0x7f080114

    .line 192
    .line 193
    .line 194
    goto :goto_4

    .line 195
    :cond_7
    const v3, 0x7f080122

    .line 196
    .line 197
    .line 198
    :goto_4
    instance-of v5, v0, Lcom/google/android/material/button/MaterialButton;

    .line 199
    .line 200
    if-eqz v5, :cond_8

    .line 201
    .line 202
    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    .line 203
    .line 204
    invoke-virtual {v2, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object v2

    .line 208
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setIconResource(I)V

    .line 212
    .line 213
    .line 214
    :cond_8
    return-object v15

    .line 215
    :pswitch_4
    check-cast v3, Lcom/maertsno/exoplayer/StyledPlayerView;

    .line 216
    .line 217
    check-cast v2, Lcom/maertsno/m/ui/player/MoviePlayerActivity;

    .line 218
    .line 219
    move-object/from16 v0, p1

    .line 220
    .line 221
    check-cast v0, Landroid/view/View;

    .line 222
    .line 223
    sget v14, Lcom/maertsno/m/ui/player/MoviePlayerActivity;->i0:I

    .line 224
    .line 225
    invoke-static {v0, v13}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {v3}, Lcom/maertsno/exoplayer/StyledPlayerView;->getResizeMode()I

    .line 229
    .line 230
    .line 231
    move-result v13

    .line 232
    if-eq v13, v12, :cond_c

    .line 233
    .line 234
    if-eq v13, v11, :cond_b

    .line 235
    .line 236
    if-eq v13, v10, :cond_a

    .line 237
    .line 238
    if-eq v13, v9, :cond_9

    .line 239
    .line 240
    move v4, v8

    .line 241
    goto :goto_5

    .line 242
    :cond_9
    move v4, v7

    .line 243
    goto :goto_5

    .line 244
    :cond_a
    move v4, v6

    .line 245
    goto :goto_5

    .line 246
    :cond_b
    move v4, v5

    .line 247
    :cond_c
    :goto_5
    invoke-virtual {v3}, Lcom/maertsno/exoplayer/StyledPlayerView;->getResizeMode()I

    .line 248
    .line 249
    .line 250
    move-result v3

    .line 251
    if-nez v3, :cond_d

    .line 252
    .line 253
    const v3, 0x7f080114

    .line 254
    .line 255
    .line 256
    goto :goto_6

    .line 257
    :cond_d
    const v3, 0x7f080122

    .line 258
    .line 259
    .line 260
    :goto_6
    instance-of v5, v0, Lcom/google/android/material/button/MaterialButton;

    .line 261
    .line 262
    if-eqz v5, :cond_e

    .line 263
    .line 264
    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    .line 265
    .line 266
    invoke-virtual {v2, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v2

    .line 270
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 271
    .line 272
    .line 273
    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setIconResource(I)V

    .line 274
    .line 275
    .line 276
    :cond_e
    return-object v15

    .line 277
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
