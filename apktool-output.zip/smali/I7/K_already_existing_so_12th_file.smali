.class public final synthetic Li7/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr8/l;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:LW/g;

.field public final synthetic d:Li/h;


# direct methods
.method public synthetic constructor <init>(LW/g;ILi/h;I)V
    .locals 0

    .line 1
    iput p4, p0, Li7/k;->a:I

    iput-object p1, p0, Li7/k;->c:LW/g;

    iput p2, p0, Li7/k;->b:I

    iput-object p3, p0, Li7/k;->d:Li/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    iget v0, p0, Li7/k;->a:I

    .line 2
    .line 3
    sget-object v1, Ld8/l;->a:Ld8/l;

    .line 4
    .line 5
    const-wide/16 v2, 0xfa

    .line 6
    .line 7
    const v4, 0x7f07019f

    .line 8
    .line 9
    .line 10
    const/high16 v5, 0x40000000    # 2.0f

    .line 11
    .line 12
    const-string v6, "view"

    .line 13
    .line 14
    iget-object v7, p0, Li7/k;->d:Li/h;

    .line 15
    .line 16
    iget v8, p0, Li7/k;->b:I

    .line 17
    .line 18
    iget-object v9, p0, Li7/k;->c:LW/g;

    .line 19
    .line 20
    packed-switch v0, :pswitch_data_0

    .line 21
    .line 22
    .line 23
    check-cast v9, LN6/e;

    .line 24
    .line 25
    check-cast v7, Lcom/maertsno/m/ui/player/PlayerActivity;

    .line 26
    .line 27
    check-cast p1, Landroid/view/View;

    .line 28
    .line 29
    sget v0, Lcom/maertsno/m/ui/player/PlayerActivity;->j0:I

    .line 30
    .line 31
    invoke-static {p1, v6}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    iget-object v0, v9, LN6/e;->T:Lcom/maertsno/exoplayer/StyledPlayerView;

    .line 35
    .line 36
    invoke-virtual {v0}, Landroid/view/View;->getPivotY()F

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    div-float/2addr v0, v5

    .line 41
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 42
    .line 43
    .line 44
    move-result v5

    .line 45
    int-to-float v5, v5

    .line 46
    sub-float/2addr v0, v5

    .line 47
    if-nez v8, :cond_0

    .line 48
    .line 49
    invoke-virtual {v7}, Li/h;->getResources()Landroid/content/res/Resources;

    .line 50
    .line 51
    .line 52
    move-result-object v5

    .line 53
    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    int-to-float v4, v4

    .line 58
    sub-float/2addr v0, v4

    .line 59
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    invoke-virtual {p1, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 72
    .line 73
    .line 74
    return-object v1

    .line 75
    :pswitch_0
    check-cast v9, LN6/c;

    .line 76
    .line 77
    check-cast v7, Lcom/maertsno/m/ui/player/MoviePlayerActivity;

    .line 78
    .line 79
    check-cast p1, Landroid/view/View;

    .line 80
    .line 81
    sget v0, Lcom/maertsno/m/ui/player/MoviePlayerActivity;->i0:I

    .line 82
    .line 83
    invoke-static {p1, v6}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    iget-object v0, v9, LN6/c;->T:Lcom/maertsno/exoplayer/StyledPlayerView;

    .line 87
    .line 88
    invoke-virtual {v0}, Landroid/view/View;->getPivotY()F

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    div-float/2addr v0, v5

    .line 93
    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    .line 94
    .line 95
    .line 96
    move-result v5

    .line 97
    int-to-float v5, v5

    .line 98
    sub-float/2addr v0, v5

    .line 99
    if-nez v8, :cond_1

    .line 100
    .line 101
    invoke-virtual {v7}, Li/h;->getResources()Landroid/content/res/Resources;

    .line 102
    .line 103
    .line 104
    move-result-object v5

    .line 105
    invoke-virtual {v5, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 106
    .line 107
    .line 108
    move-result v4

    .line 109
    int-to-float v4, v4

    .line 110
    sub-float/2addr v0, v4

    .line 111
    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    invoke-virtual {p1, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 124
    .line 125
    .line 126
    return-object v1

    .line 127
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
