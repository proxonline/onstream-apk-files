.class public final La7/n;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:Ljava/lang/Object;

.field public s:I

.field public final synthetic t:La7/o;

.field public final synthetic u:I

.field public final synthetic v:I


# direct methods
.method public constructor <init>(La7/o;IILh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, La7/n;->t:La7/o;

    .line 2
    .line 3
    iput p2, p0, La7/n;->u:I

    .line 4
    .line 5
    iput p3, p0, La7/n;->v:I

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Lj8/i;-><init>(ILh8/d;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 3

    .line 1
    new-instance p1, La7/n;

    .line 2
    .line 3
    iget v0, p0, La7/n;->u:I

    .line 4
    .line 5
    iget v1, p0, La7/n;->v:I

    .line 6
    .line 7
    iget-object v2, p0, La7/n;->t:La7/o;

    .line 8
    .line 9
    invoke-direct {p1, v2, v0, v1, p2}, La7/n;-><init>(La7/o;IILh8/d;)V

    .line 10
    .line 11
    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La7/n;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, La7/n;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, La7/n;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    .line 1
    iget v0, p0, La7/n;->s:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    iget-object v2, p0, La7/n;->t:La7/o;

    .line 5
    .line 6
    const/4 v3, 0x1

    .line 7
    sget-object v4, Li8/a;->a:Li8/a;

    .line 8
    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    if-eq v0, v3, :cond_1

    .line 12
    .line 13
    if-ne v0, v1, :cond_0

    .line 14
    .line 15
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    goto :goto_3

    .line 19
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 20
    .line 21
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 22
    .line 23
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1

    .line 27
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    check-cast p1, Ld8/i;

    .line 31
    .line 32
    iget-object p1, p1, Ld8/i;->a:Ljava/lang/Object;

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    iget-object p1, v2, La7/o;->d:LA5/e;

    .line 39
    .line 40
    iget-object v0, v2, La7/o;->e:LA6/a;

    .line 41
    .line 42
    iput v3, p0, La7/n;->s:I

    .line 43
    .line 44
    iget v5, p0, La7/n;->u:I

    .line 45
    .line 46
    invoke-virtual {p1, v0, v5, p0}, LA5/e;->q(LA6/a;ILj8/c;)Ljava/io/Serializable;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    if-ne p1, v4, :cond_3

    .line 51
    .line 52
    goto :goto_2

    .line 53
    :cond_3
    :goto_0
    instance-of v0, p1, Ld8/h;

    .line 54
    .line 55
    if-nez v0, :cond_5

    .line 56
    .line 57
    move-object v0, p1

    .line 58
    check-cast v0, Ljava/util/List;

    .line 59
    .line 60
    iget v5, p0, La7/n;->v:I

    .line 61
    .line 62
    if-ne v5, v3, :cond_4

    .line 63
    .line 64
    iget-object v3, v2, La7/o;->f:LE8/U;

    .line 65
    .line 66
    invoke-virtual {v3, v0}, LE8/U;->h(Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_4
    iget-object v3, v2, La7/o;->f:LE8/U;

    .line 71
    .line 72
    invoke-interface {v3}, LE8/S;->getValue()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    check-cast v5, Ljava/util/Collection;

    .line 77
    .line 78
    invoke-static {v5, v0}, Le8/i;->u0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    const/4 v5, 0x0

    .line 86
    invoke-virtual {v3, v5, v0}, LE8/U;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    :cond_5
    :goto_1
    invoke-static {p1}, Ld8/i;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    if-eqz v0, :cond_6

    .line 94
    .line 95
    iput-object p1, p0, La7/n;->r:Ljava/lang/Object;

    .line 96
    .line 97
    iput v1, p0, La7/n;->s:I

    .line 98
    .line 99
    invoke-virtual {v2, v0, p0}, LR6/s;->h(Ljava/lang/Throwable;Lh8/d;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    if-ne p1, v4, :cond_6

    .line 104
    .line 105
    :goto_2
    return-object v4

    .line 106
    :cond_6
    :goto_3
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 107
    .line 108
    return-object p1
.end method
