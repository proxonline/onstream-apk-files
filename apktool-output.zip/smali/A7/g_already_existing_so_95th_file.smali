.class public final La7/g;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:La7/l;


# direct methods
.method public constructor <init>(La7/l;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, La7/g;->s:La7/l;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lj8/i;-><init>(ILh8/d;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 2

    .line 1
    new-instance v0, La7/g;

    .line 2
    .line 3
    iget-object v1, p0, La7/g;->s:La7/l;

    .line 4
    .line 5
    invoke-direct {v0, v1, p2}, La7/g;-><init>(La7/l;Lh8/d;)V

    .line 6
    .line 7
    .line 8
    iput-object p1, v0, La7/g;->r:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LR6/w;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La7/g;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, La7/g;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, La7/g;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-object p2
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, La7/g;->r:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LR6/w;

    .line 4
    .line 5
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, LR6/w;->a()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    check-cast p1, Ljava/lang/Boolean;

    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    if-eqz p1, :cond_0

    .line 21
    .line 22
    iget-object p1, p0, La7/g;->s:La7/l;

    .line 23
    .line 24
    iget-object p1, p1, La7/l;->D0:Ld8/j;

    .line 25
    .line 26
    invoke-virtual {p1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    check-cast p1, LP6/d;

    .line 31
    .line 32
    sget-object v0, Le8/q;->a:Le8/q;

    .line 33
    .line 34
    invoke-virtual {p1, v0}, LG0/K;->n(Ljava/util/List;)V

    .line 35
    .line 36
    .line 37
    :cond_0
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 38
    .line 39
    return-object p1
.end method
