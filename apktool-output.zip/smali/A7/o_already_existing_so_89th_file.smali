.class public final La7/o;
.super LR6/s;
.source "SourceFile"


# instance fields
.field public final d:LA5/e;

.field public e:LA6/a;

.field public final f:LE8/U;


# direct methods
.method public constructor <init>(LA5/e;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LR6/s;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La7/o;->d:LA5/e;

    .line 5
    .line 6
    sget-object p1, LA6/a;->a:LA6/a;

    .line 7
    .line 8
    iput-object p1, p0, La7/o;->e:LA6/a;

    .line 9
    .line 10
    sget-object p1, Le8/q;->a:Le8/q;

    .line 11
    .line 12
    invoke-static {p1}, LE8/P;->b(Ljava/lang/Object;)LE8/U;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, La7/o;->f:LE8/U;

    .line 17
    .line 18
    return-void
.end method
