.class public final La7/l;
.super La7/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "La7/a<",
        "La7/o;",
        "LN6/y1;",
        ">;"
    }
.end annotation


# instance fields
.field public final B0:LC1/b;

.field public final C0:LC1/b;

.field public final D0:Ld8/j;

.field public final E0:Ld8/j;


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 1
    invoke-direct {p0}, La7/a;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, LY6/d;

    .line 5
    .line 6
    const/4 v1, 0x5

    .line 7
    invoke-direct {v0, v1, p0}, LY6/d;-><init>(ILjava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    new-instance v1, LY6/d;

    .line 11
    .line 12
    const/4 v2, 0x6

    .line 13
    invoke-direct {v1, v2, v0}, LY6/d;-><init>(ILjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-static {v1}, Lr3/e;->w(Lr8/a;)Ld8/d;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    const-class v1, La7/o;

    .line 21
    .line 22
    invoke-static {v1}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    new-instance v2, LX6/C;

    .line 27
    .line 28
    const/4 v3, 0x6

    .line 29
    invoke-direct {v2, v0, v3}, LX6/C;-><init>(Ld8/d;I)V

    .line 30
    .line 31
    .line 32
    new-instance v3, LX6/C;

    .line 33
    .line 34
    const/4 v4, 0x7

    .line 35
    invoke-direct {v3, v0, v4}, LX6/C;-><init>(Ld8/d;I)V

    .line 36
    .line 37
    .line 38
    new-instance v4, La7/k;

    .line 39
    .line 40
    const/4 v5, 0x0

    .line 41
    invoke-direct {v4, p0, v0, v5}, La7/k;-><init>(La7/l;Ld8/d;I)V

    .line 42
    .line 43
    .line 44
    new-instance v0, LC1/b;

    .line 45
    .line 46
    invoke-direct {v0, v1, v2, v4, v3}, LC1/b;-><init>(Lkotlin/jvm/internal/d;Lr8/a;Lr8/a;Lr8/a;)V

    .line 47
    .line 48
    .line 49
    iput-object v0, p0, La7/l;->B0:LC1/b;

    .line 50
    .line 51
    new-instance v0, La7/b;

    .line 52
    .line 53
    const/4 v1, 0x0

    .line 54
    invoke-direct {v0, p0, v1}, La7/b;-><init>(La7/l;I)V

    .line 55
    .line 56
    .line 57
    new-instance v1, LY6/d;

    .line 58
    .line 59
    const/4 v2, 0x7

    .line 60
    invoke-direct {v1, v2, v0}, LY6/d;-><init>(ILjava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    invoke-static {v1}, Lr3/e;->w(Lr8/a;)Ld8/d;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    const-class v1, LZ6/d;

    .line 68
    .line 69
    invoke-static {v1}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    new-instance v2, LX6/C;

    .line 74
    .line 75
    const/16 v3, 0x8

    .line 76
    .line 77
    invoke-direct {v2, v0, v3}, LX6/C;-><init>(Ld8/d;I)V

    .line 78
    .line 79
    .line 80
    new-instance v3, LX6/C;

    .line 81
    .line 82
    const/16 v4, 0x9

    .line 83
    .line 84
    invoke-direct {v3, v0, v4}, LX6/C;-><init>(Ld8/d;I)V

    .line 85
    .line 86
    .line 87
    new-instance v4, La7/k;

    .line 88
    .line 89
    const/4 v5, 0x1

    .line 90
    invoke-direct {v4, p0, v0, v5}, La7/k;-><init>(La7/l;Ld8/d;I)V

    .line 91
    .line 92
    .line 93
    new-instance v0, LC1/b;

    .line 94
    .line 95
    invoke-direct {v0, v1, v2, v4, v3}, LC1/b;-><init>(Lkotlin/jvm/internal/d;Lr8/a;Lr8/a;Lr8/a;)V

    .line 96
    .line 97
    .line 98
    iput-object v0, p0, La7/l;->C0:LC1/b;

    .line 99
    .line 100
    new-instance v0, La7/b;

    .line 101
    .line 102
    const/4 v1, 0x1

    .line 103
    invoke-direct {v0, p0, v1}, La7/b;-><init>(La7/l;I)V

    .line 104
    .line 105
    .line 106
    invoke-static {v0}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    iput-object v0, p0, La7/l;->D0:Ld8/j;

    .line 111
    .line 112
    new-instance v0, La7/b;

    .line 113
    .line 114
    const/4 v1, 0x2

    .line 115
    invoke-direct {v0, p0, v1}, La7/b;-><init>(La7/l;I)V

    .line 116
    .line 117
    .line 118
    invoke-static {v0}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    iput-object v0, p0, La7/l;->E0:Ld8/j;

    .line 123
    .line 124
    return-void
.end method


# virtual methods
.method public final H(Landroid/os/Bundle;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Lj0/y;->H(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    const-class p1, LA6/a;

    .line 5
    .line 6
    invoke-static {p1}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    const-string v0, "ARGS_PAGE_TYPE"

    .line 11
    .line 12
    invoke-static {p0, v0, p1}, Lr3/e;->r(LR6/n;Ljava/lang/String;Lkotlin/jvm/internal/d;)Ljava/io/Serializable;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, LA6/a;

    .line 17
    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    invoke-virtual {p0}, La7/l;->u0()La7/o;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iput-object p1, v0, La7/o;->e:LA6/a;

    .line 25
    .line 26
    :cond_0
    return-void
.end method

.method public final g0()I
    .locals 1

    .line 1
    const v0, 0x7f0d00d9

    .line 2
    .line 3
    .line 4
    return v0
.end method

.method public final bridge synthetic i0()LR6/s;
    .locals 1

    .line 1
    invoke-virtual {p0}, La7/l;->u0()La7/o;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final m0()V
    .locals 5

    .line 1
    invoke-static {p0}, Landroidx/lifecycle/V;->e(Landroidx/lifecycle/v;)Landroidx/lifecycle/q;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, La7/j;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-direct {v1, p0, v2}, La7/j;-><init>(La7/l;Lh8/d;)V

    .line 9
    .line 10
    .line 11
    const/4 v3, 0x3

    .line 12
    invoke-static {v0, v2, v1, v3}, LB8/D;->r(LB8/A;Lh8/i;Lr8/p;I)LB8/B0;

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0}, La7/l;->u0()La7/o;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iget-object v0, v0, La7/o;->f:LE8/U;

    .line 20
    .line 21
    invoke-interface {v0}, LE8/S;->getValue()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, Ljava/util/List;

    .line 26
    .line 27
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_0

    .line 32
    .line 33
    invoke-virtual {p0}, La7/l;->u0()La7/o;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {}, Li6/a;->a()I

    .line 38
    .line 39
    .line 40
    new-instance v1, La7/n;

    .line 41
    .line 42
    const/4 v3, 0x0

    .line 43
    const/4 v4, 0x1

    .line 44
    invoke-direct {v1, v0, v3, v4, v2}, La7/n;-><init>(La7/o;IILh8/d;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0, v4, v1}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 48
    .line 49
    .line 50
    :cond_0
    return-void
.end method

.method public final r0()V
    .locals 5

    .line 1
    invoke-virtual {p0}, LR6/n;->f0()LW/g;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, LN6/y1;

    .line 6
    .line 7
    iget-object v1, p0, La7/l;->E0:Ld8/j;

    .line 8
    .line 9
    invoke-virtual {v1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    check-cast v2, La7/d;

    .line 14
    .line 15
    iget-object v3, v0, LN6/y1;->E:Landroidx/recyclerview/widget/RecyclerView;

    .line 16
    .line 17
    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/a;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    invoke-static {v4}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    iput-object v4, v2, LR6/u;->i:Landroidx/recyclerview/widget/a;

    .line 28
    .line 29
    invoke-virtual {v1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    check-cast v1, La7/d;

    .line 34
    .line 35
    invoke-virtual {v3, v1}, Landroidx/recyclerview/widget/RecyclerView;->j(LG0/h0;)V

    .line 36
    .line 37
    .line 38
    iget-object v1, p0, La7/l;->D0:Ld8/j;

    .line 39
    .line 40
    invoke-virtual {v1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    check-cast v1, LP6/d;

    .line 45
    .line 46
    invoke-virtual {v3, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(LG0/V;)V

    .line 47
    .line 48
    .line 49
    iget-object v1, v0, LN6/y1;->F:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    .line 50
    .line 51
    new-instance v2, LB7/e;

    .line 52
    .line 53
    const/16 v3, 0xb

    .line 54
    .line 55
    invoke-direct {v2, v0, v3, p0}, LB7/e;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v1, v2}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setOnRefreshListener(LX0/i;)V

    .line 59
    .line 60
    .line 61
    return-void
.end method

.method public final u0()La7/o;
    .locals 1

    .line 1
    iget-object v0, p0, La7/l;->B0:LC1/b;

    .line 2
    .line 3
    invoke-virtual {v0}, LC1/b;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, La7/o;

    .line 8
    .line 9
    return-object v0
.end method
