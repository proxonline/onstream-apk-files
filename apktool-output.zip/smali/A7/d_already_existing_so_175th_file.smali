.class public final La7/d;
.super LR6/u;
.source "SourceFile"


# instance fields
.field public final synthetic j:La7/l;


# direct methods
.method public constructor <init>(La7/l;Landroidx/recyclerview/widget/a;)V
    .locals 0

    .line 1
    iput-object p1, p0, La7/d;->j:La7/l;

    .line 2
    .line 3
    invoke-direct {p0, p2}, LR6/u;-><init>(Landroidx/recyclerview/widget/a;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c(I)V
    .locals 4

    .line 1
    iget-object v0, p0, La7/d;->j:La7/l;

    .line 2
    .line 3
    invoke-virtual {v0}, La7/l;->u0()La7/o;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    add-int/lit8 v1, p1, -0x1

    .line 8
    .line 9
    invoke-static {}, Li6/a;->a()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    mul-int/2addr v2, v1

    .line 14
    new-instance v1, La7/n;

    .line 15
    .line 16
    const/4 v3, 0x0

    .line 17
    invoke-direct {v1, v0, v2, p1, v3}, La7/n;-><init>(La7/o;IILh8/d;)V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x1

    .line 21
    invoke-virtual {v0, p1, v1}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 22
    .line 23
    .line 24
    return-void
.end method
