.class public final synthetic La7/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr8/a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:La7/l;


# direct methods
.method public synthetic constructor <init>(La7/l;I)V
    .locals 0

    .line 1
    iput p2, p0, La7/b;->a:I

    iput-object p1, p0, La7/b;->b:La7/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, La7/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, La7/b;->b:La7/l;

    .line 7
    .line 8
    invoke-virtual {v0}, LR6/n;->f0()LW/g;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, LN6/y1;

    .line 13
    .line 14
    iget-object v1, v1, LN6/y1;->E:Landroidx/recyclerview/widget/RecyclerView;

    .line 15
    .line 16
    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/a;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-static {v1}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    new-instance v2, La7/d;

    .line 24
    .line 25
    invoke-direct {v2, v0, v1}, La7/d;-><init>(La7/l;Landroidx/recyclerview/widget/a;)V

    .line 26
    .line 27
    .line 28
    return-object v2

    .line 29
    :pswitch_0
    new-instance v0, LP6/d;

    .line 30
    .line 31
    new-instance v1, La7/c;

    .line 32
    .line 33
    iget-object v2, p0, La7/b;->b:La7/l;

    .line 34
    .line 35
    invoke-direct {v1, v2}, La7/c;-><init>(La7/l;)V

    .line 36
    .line 37
    .line 38
    invoke-direct {v0, v1}, LP6/d;-><init>(LR6/v;)V

    .line 39
    .line 40
    .line 41
    return-object v0

    .line 42
    :pswitch_1
    iget-object v0, p0, La7/b;->b:La7/l;

    .line 43
    .line 44
    invoke-virtual {v0}, Lj0/y;->a0()Lj0/y;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    return-object v0

    .line 49
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
