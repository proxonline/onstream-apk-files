.class public final La7/i;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:La7/l;


# direct methods
.method public constructor <init>(La7/l;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, La7/i;->s:La7/l;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lj8/i;-><init>(ILh8/d;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 2

    .line 1
    new-instance v0, La7/i;

    .line 2
    .line 3
    iget-object v1, p0, La7/i;->s:La7/l;

    .line 4
    .line 5
    invoke-direct {v0, v1, p2}, La7/i;-><init>(La7/l;Lh8/d;)V

    .line 6
    .line 7
    .line 8
    iput-object p1, v0, La7/i;->r:Ljava/lang/Object;

    .line 9
    .line 10
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, La7/i;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, La7/i;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, La7/i;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    return-object p2
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, La7/i;->r:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LB8/A;

    .line 4
    .line 5
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    new-instance p1, La7/f;

    .line 9
    .line 10
    iget-object v1, p0, La7/i;->s:La7/l;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-direct {p1, v1, v2}, La7/f;-><init>(La7/l;Lh8/d;)V

    .line 14
    .line 15
    .line 16
    const/4 v3, 0x3

    .line 17
    invoke-static {v0, v2, p1, v3}, LB8/D;->r(LB8/A;Lh8/i;Lr8/p;I)LB8/B0;

    .line 18
    .line 19
    .line 20
    new-instance p1, La7/h;

    .line 21
    .line 22
    invoke-direct {p1, v1, v2}, La7/h;-><init>(La7/l;Lh8/d;)V

    .line 23
    .line 24
    .line 25
    invoke-static {v0, v2, p1, v3}, LB8/D;->r(LB8/A;Lh8/i;Lr8/p;I)LB8/B0;

    .line 26
    .line 27
    .line 28
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 29
    .line 30
    return-object p1
.end method
