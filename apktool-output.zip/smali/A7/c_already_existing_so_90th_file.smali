.class public final synthetic La7/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LR6/v;


# instance fields
.field public final synthetic a:La7/l;


# direct methods
.method public constructor <init>(La7/l;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La7/c;->a:La7/l;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Lcom/maertsno/domain/model/Movie;

    .line 2
    .line 3
    const-string v0, "p0"

    .line 4
    .line 5
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, La7/c;->a:La7/l;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v1, LL6/t;

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-direct {v1, p1, v2}, LL6/t;-><init>(Lcom/maertsno/domain/model/Movie;Z)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v1}, LR6/n;->k0(Lw0/B;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 9

    .line 1
    instance-of v0, p1, LR6/v;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    instance-of v0, p1, La7/c;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    new-instance v1, Lkotlin/jvm/internal/g;

    .line 10
    .line 11
    const-string v7, "onMovieClick(Lcom/maertsno/domain/model/Movie;)V"

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    const/4 v2, 0x1

    .line 15
    const-class v4, La7/l;

    .line 16
    .line 17
    iget-object v5, p0, La7/c;->a:La7/l;

    .line 18
    .line 19
    const-string v6, "onMovieClick"

    .line 20
    .line 21
    invoke-direct/range {v1 .. v7}, Lkotlin/jvm/internal/f;-><init>(IILjava/lang/Class;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    check-cast p1, La7/c;

    .line 25
    .line 26
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    new-instance v2, Lkotlin/jvm/internal/g;

    .line 30
    .line 31
    iget-object v6, p1, La7/c;->a:La7/l;

    .line 32
    .line 33
    const-string v8, "onMovieClick(Lcom/maertsno/domain/model/Movie;)V"

    .line 34
    .line 35
    const/4 v4, 0x0

    .line 36
    const/4 v3, 0x1

    .line 37
    const-class v5, La7/l;

    .line 38
    .line 39
    const-string v7, "onMovieClick"

    .line 40
    .line 41
    invoke-direct/range {v2 .. v8}, Lkotlin/jvm/internal/f;-><init>(IILjava/lang/Class;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v1, v2}, Lkotlin/jvm/internal/f;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    return p1

    .line 49
    :cond_0
    const/4 p1, 0x0

    .line 50
    return p1
.end method

.method public final hashCode()I
    .locals 7

    .line 1
    new-instance v0, Lkotlin/jvm/internal/g;

    .line 2
    .line 3
    const-string v6, "onMovieClick(Lcom/maertsno/domain/model/Movie;)V"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v1, 0x1

    .line 7
    const-class v3, La7/l;

    .line 8
    .line 9
    iget-object v4, p0, La7/c;->a:La7/l;

    .line 10
    .line 11
    const-string v5, "onMovieClick"

    .line 12
    .line 13
    invoke-direct/range {v0 .. v6}, Lkotlin/jvm/internal/f;-><init>(IILjava/lang/Class;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0}, Lkotlin/jvm/internal/f;->hashCode()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    return v0
.end method
