.class public abstract La7/a;
.super LR6/n;
.source "SourceFile"

# interfaces
.implements La8/b;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "LR6/s;",
        "B:",
        "LW/g;",
        ">",
        "LR6/n<",
        "TV;TB;>;",
        "La8/b;"
    }
.end annotation


# instance fields
.field public A0:Z

.field public w0:LY7/h;

.field public x0:Z

.field public volatile y0:LY7/f;

.field public final z0:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LR6/n;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, La7/a;->z0:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, La7/a;->A0:Z

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final F(Landroid/app/Activity;)V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lj0/y;->Y:Z

    .line 3
    .line 4
    iget-object v1, p0, La7/a;->w0:LY7/h;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    if-eqz v1, :cond_1

    .line 8
    .line 9
    invoke-static {v1}, LY7/f;->b(Landroid/content/Context;)Landroid/content/Context;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    if-ne v1, p1, :cond_0

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    move p1, v2

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    :goto_0
    move p1, v0

    .line 19
    :goto_1
    const-string v1, "onAttach called multiple times with different Context! Hilt Fragments should not be retained."

    .line 20
    .line 21
    new-array v2, v2, [Ljava/lang/Object;

    .line 22
    .line 23
    invoke-static {p1, v1, v2}, LI3/a;->h(ZLjava/lang/String;[Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0}, La7/a;->t0()V

    .line 27
    .line 28
    .line 29
    iget-boolean p1, p0, La7/a;->A0:Z

    .line 30
    .line 31
    if-nez p1, :cond_2

    .line 32
    .line 33
    iput-boolean v0, p0, La7/a;->A0:Z

    .line 34
    .line 35
    invoke-virtual {p0}, La7/a;->f()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    check-cast p1, La7/m;

    .line 40
    .line 41
    move-object v0, p0

    .line 42
    check-cast v0, La7/l;

    .line 43
    .line 44
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    :cond_2
    return-void
.end method

.method public final G(Landroid/content/Context;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Lj0/y;->G(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, La7/a;->t0()V

    .line 5
    .line 6
    .line 7
    iget-boolean p1, p0, La7/a;->A0:Z

    .line 8
    .line 9
    if-nez p1, :cond_0

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    iput-boolean p1, p0, La7/a;->A0:Z

    .line 13
    .line 14
    invoke-virtual {p0}, La7/a;->f()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    check-cast p1, La7/m;

    .line 19
    .line 20
    move-object v0, p0

    .line 21
    check-cast v0, La7/l;

    .line 22
    .line 23
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method

.method public final M(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 1

    .line 1
    invoke-super {p0, p1}, Lj0/y;->M(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    new-instance v0, LY7/h;

    .line 6
    .line 7
    invoke-direct {v0, p1, p0}, LY7/h;-><init>(Landroid/view/LayoutInflater;Lj0/y;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1, v0}, Landroid/view/LayoutInflater;->cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1
.end method

.method public final f()Ljava/lang/Object;
    .locals 2

    .line 1
    iget-object v0, p0, La7/a;->y0:LY7/f;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, La7/a;->z0:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    iget-object v1, p0, La7/a;->y0:LY7/f;

    .line 9
    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    new-instance v1, LY7/f;

    .line 13
    .line 14
    invoke-direct {v1, p0}, LY7/f;-><init>(Lj0/y;)V

    .line 15
    .line 16
    .line 17
    iput-object v1, p0, La7/a;->y0:LY7/f;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catchall_0
    move-exception v1

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    :goto_0
    monitor-exit v0

    .line 23
    goto :goto_2

    .line 24
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    throw v1

    .line 26
    :cond_1
    :goto_2
    iget-object v0, p0, La7/a;->y0:LY7/f;

    .line 27
    .line 28
    invoke-virtual {v0}, LY7/f;->f()Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    return-object v0
.end method

.method public final n()Landroid/content/Context;
    .locals 1

    .line 1
    invoke-super {p0}, Lj0/y;->n()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    iget-boolean v0, p0, La7/a;->x0:Z

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    return-object v0

    .line 13
    :cond_0
    invoke-virtual {p0}, La7/a;->t0()V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, La7/a;->w0:LY7/h;

    .line 17
    .line 18
    return-object v0
.end method

.method public final r()Landroidx/lifecycle/d0;
    .locals 1

    .line 1
    invoke-super {p0}, Lj0/y;->r()Landroidx/lifecycle/d0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {p0, v0}, Lb1/a;->y(Lj0/y;Landroidx/lifecycle/d0;)LX7/f;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public final t0()V
    .locals 2

    .line 1
    iget-object v0, p0, La7/a;->w0:LY7/h;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0}, Lj0/y;->n()Landroid/content/Context;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    new-instance v1, LY7/h;

    .line 10
    .line 11
    invoke-direct {v1, v0, p0}, LY7/h;-><init>(Landroid/content/Context;Lj0/y;)V

    .line 12
    .line 13
    .line 14
    iput-object v1, p0, La7/a;->w0:LY7/h;

    .line 15
    .line 16
    invoke-super {p0}, Lj0/y;->n()Landroid/content/Context;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-static {v0}, Lcom/google/android/gms/internal/measurement/e2;->s(Landroid/content/Context;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    iput-boolean v0, p0, La7/a;->x0:Z

    .line 25
    .line 26
    :cond_0
    return-void
.end method
