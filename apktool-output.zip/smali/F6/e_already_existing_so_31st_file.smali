.class public final Lf6/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lf6/o;


# instance fields
.field public final a:LN5/e;

.field public final b:Lb6/b;

.field public final c:Lf6/g;

.field public final d:Ld6/a;

.field public final e:LJ8/d;


# direct methods
.method public constructor <init>(Lh8/i;LN5/e;Lb6/b;Lf6/g;Ld6/a;)V
    .locals 1

    .line 1
    const-string v0, "backgroundDispatcher"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string p1, "firebaseInstallationsApi"

    .line 7
    .line 8
    invoke-static {p2, p1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string p1, "appInfo"

    .line 12
    .line 13
    invoke-static {p3, p1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string p1, "configsFetcher"

    .line 17
    .line 18
    invoke-static {p4, p1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string p1, "lazySettingsCache"

    .line 22
    .line 23
    invoke-static {p5, p1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    .line 28
    .line 29
    iput-object p2, p0, Lf6/e;->a:LN5/e;

    .line 30
    .line 31
    iput-object p3, p0, Lf6/e;->b:Lb6/b;

    .line 32
    .line 33
    iput-object p4, p0, Lf6/e;->c:Lf6/g;

    .line 34
    .line 35
    iput-object p5, p0, Lf6/e;->d:Ld6/a;

    .line 36
    .line 37
    invoke-static {}, LJ8/e;->a()LJ8/d;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    iput-object p1, p0, Lf6/e;->e:LJ8/d;

    .line 42
    .line 43
    return-void
.end method

.method public static f(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    const-string v0, "/"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "compile(...)"

    .line 8
    .line 9
    invoke-static {v0, v1}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    const-string v1, ""

    .line 13
    .line 14
    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    invoke-virtual {p0, v1}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    const-string v0, "replaceAll(...)"

    .line 23
    .line 24
    invoke-static {p0, v0}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-object p0
.end method


# virtual methods
.method public final a()Ljava/lang/Boolean;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lf6/e;->e()Lf6/n;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Lf6/n;->b:Lf6/h;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, v0, Lf6/h;->a:Ljava/lang/Boolean;

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    const-string v0, "sessionConfigs"

    .line 13
    .line 14
    invoke-static {v0}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    throw v0
.end method

.method public final b(Lh8/d;)Ljava/lang/Object;
    .locals 24

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    instance-of v2, v0, Lf6/b;

    .line 6
    .line 7
    if-eqz v2, :cond_0

    .line 8
    .line 9
    move-object v2, v0

    .line 10
    check-cast v2, Lf6/b;

    .line 11
    .line 12
    iget v3, v2, Lf6/b;->v:I

    .line 13
    .line 14
    const/high16 v4, -0x80000000

    .line 15
    .line 16
    and-int v5, v3, v4

    .line 17
    .line 18
    if-eqz v5, :cond_0

    .line 19
    .line 20
    sub-int/2addr v3, v4

    .line 21
    iput v3, v2, Lf6/b;->v:I

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    new-instance v2, Lf6/b;

    .line 25
    .line 26
    check-cast v0, Lj8/c;

    .line 27
    .line 28
    invoke-direct {v2, v1, v0}, Lf6/b;-><init>(Lf6/e;Lj8/c;)V

    .line 29
    .line 30
    .line 31
    :goto_0
    iget-object v0, v2, Lf6/b;->t:Ljava/lang/Object;

    .line 32
    .line 33
    iget v3, v2, Lf6/b;->v:I

    .line 34
    .line 35
    const/4 v4, 0x3

    .line 36
    const/4 v5, 0x1

    .line 37
    const-string v6, "SessionConfigFetcher"

    .line 38
    .line 39
    const/4 v7, 0x2

    .line 40
    sget-object v8, Ld8/l;->a:Ld8/l;

    .line 41
    .line 42
    const/4 v9, 0x0

    .line 43
    sget-object v10, Li8/a;->a:Li8/a;

    .line 44
    .line 45
    if-eqz v3, :cond_4

    .line 46
    .line 47
    if-eq v3, v5, :cond_3

    .line 48
    .line 49
    if-eq v3, v7, :cond_2

    .line 50
    .line 51
    if-ne v3, v4, :cond_1

    .line 52
    .line 53
    iget-object v2, v2, Lf6/b;->r:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v2, LJ8/a;

    .line 56
    .line 57
    :try_start_0
    invoke-static {v0}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 58
    .line 59
    .line 60
    goto/16 :goto_5

    .line 61
    .line 62
    :catchall_0
    move-exception v0

    .line 63
    goto/16 :goto_6

    .line 64
    .line 65
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 66
    .line 67
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 68
    .line 69
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    throw v0

    .line 73
    :cond_2
    iget-object v3, v2, Lf6/b;->s:LJ8/a;

    .line 74
    .line 75
    iget-object v11, v2, Lf6/b;->r:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v11, Lf6/e;

    .line 78
    .line 79
    :try_start_1
    invoke-static {v0}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 80
    .line 81
    .line 82
    goto :goto_2

    .line 83
    :catchall_1
    move-exception v0

    .line 84
    move-object v2, v3

    .line 85
    goto/16 :goto_6

    .line 86
    .line 87
    :cond_3
    iget-object v3, v2, Lf6/b;->s:LJ8/a;

    .line 88
    .line 89
    iget-object v11, v2, Lf6/b;->r:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast v11, Lf6/e;

    .line 92
    .line 93
    invoke-static {v0}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_4
    invoke-static {v0}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    iget-object v0, v1, Lf6/e;->e:LJ8/d;

    .line 101
    .line 102
    invoke-virtual {v0}, LJ8/d;->e()Z

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    if-nez v3, :cond_5

    .line 107
    .line 108
    invoke-virtual {v1}, Lf6/e;->e()Lf6/n;

    .line 109
    .line 110
    .line 111
    move-result-object v3

    .line 112
    invoke-virtual {v3}, Lf6/n;->b()Z

    .line 113
    .line 114
    .line 115
    move-result v3

    .line 116
    if-nez v3, :cond_5

    .line 117
    .line 118
    return-object v8

    .line 119
    :cond_5
    iput-object v1, v2, Lf6/b;->r:Ljava/lang/Object;

    .line 120
    .line 121
    iput-object v0, v2, Lf6/b;->s:LJ8/a;

    .line 122
    .line 123
    iput v5, v2, Lf6/b;->v:I

    .line 124
    .line 125
    invoke-virtual {v0, v2}, LJ8/d;->f(Lh8/d;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v3

    .line 129
    if-ne v3, v10, :cond_6

    .line 130
    .line 131
    goto/16 :goto_4

    .line 132
    .line 133
    :cond_6
    move-object v3, v0

    .line 134
    move-object v11, v1

    .line 135
    :goto_1
    :try_start_2
    invoke-virtual {v11}, Lf6/e;->e()Lf6/n;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    invoke-virtual {v0}, Lf6/n;->b()Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    if-nez v0, :cond_7

    .line 144
    .line 145
    const-string v0, "Remote settings cache not expired. Using cached values."

    .line 146
    .line 147
    invoke-static {v6, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 148
    .line 149
    .line 150
    invoke-interface {v3, v9}, LJ8/a;->a(Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    return-object v8

    .line 154
    :cond_7
    :try_start_3
    sget-object v0, Lb6/B;->c:Lb6/A;

    .line 155
    .line 156
    iget-object v12, v11, Lf6/e;->a:LN5/e;

    .line 157
    .line 158
    iput-object v11, v2, Lf6/b;->r:Ljava/lang/Object;

    .line 159
    .line 160
    iput-object v3, v2, Lf6/b;->s:LJ8/a;

    .line 161
    .line 162
    iput v7, v2, Lf6/b;->v:I

    .line 163
    .line 164
    invoke-virtual {v0, v12, v2}, Lb6/A;->a(LN5/e;Lj8/c;)Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    if-ne v0, v10, :cond_8

    .line 169
    .line 170
    goto/16 :goto_4

    .line 171
    .line 172
    :cond_8
    :goto_2
    check-cast v0, Lb6/B;

    .line 173
    .line 174
    iget-object v0, v0, Lb6/B;->a:Ljava/lang/String;

    .line 175
    .line 176
    const-string v12, ""

    .line 177
    .line 178
    invoke-virtual {v0, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 179
    .line 180
    .line 181
    move-result v12

    .line 182
    if-eqz v12, :cond_9

    .line 183
    .line 184
    const-string v0, "Error getting Firebase Installation ID. Skipping this Session Event."

    .line 185
    .line 186
    invoke-static {v6, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 187
    .line 188
    .line 189
    invoke-interface {v3, v9}, LJ8/a;->a(Ljava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    return-object v8

    .line 193
    :cond_9
    :try_start_4
    const-string v12, "X-Crashlytics-Installation-ID"

    .line 194
    .line 195
    new-instance v13, Ld8/g;

    .line 196
    .line 197
    invoke-direct {v13, v12, v0}, Ld8/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 198
    .line 199
    .line 200
    const-string v0, "X-Crashlytics-Device-Model"

    .line 201
    .line 202
    const-string v12, "%s/%s"

    .line 203
    .line 204
    new-array v14, v7, [Ljava/lang/Object;

    .line 205
    .line 206
    sget-object v15, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 207
    .line 208
    const/16 v16, 0x0

    .line 209
    .line 210
    aput-object v15, v14, v16

    .line 211
    .line 212
    sget-object v15, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 213
    .line 214
    aput-object v15, v14, v5

    .line 215
    .line 216
    invoke-static {v14, v7}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object v14

    .line 220
    invoke-static {v12, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v12

    .line 224
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 225
    .line 226
    .line 227
    invoke-static {v12}, Lf6/e;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v12

    .line 231
    new-instance v14, Ld8/g;

    .line 232
    .line 233
    invoke-direct {v14, v0, v12}, Ld8/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    const-string v0, "X-Crashlytics-OS-Build-Version"

    .line 237
    .line 238
    sget-object v12, Landroid/os/Build$VERSION;->INCREMENTAL:Ljava/lang/String;

    .line 239
    .line 240
    const-string v15, "INCREMENTAL"

    .line 241
    .line 242
    invoke-static {v12, v15}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 243
    .line 244
    .line 245
    invoke-static {v12}, Lf6/e;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object v12

    .line 249
    new-instance v15, Ld8/g;

    .line 250
    .line 251
    invoke-direct {v15, v0, v12}, Ld8/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    const-string v0, "X-Crashlytics-OS-Display-Version"

    .line 255
    .line 256
    sget-object v12, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    .line 257
    .line 258
    move/from16 p1, v5

    .line 259
    .line 260
    const-string v5, "RELEASE"

    .line 261
    .line 262
    invoke-static {v12, v5}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 263
    .line 264
    .line 265
    invoke-static {v12}, Lf6/e;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 266
    .line 267
    .line 268
    move-result-object v5

    .line 269
    new-instance v12, Ld8/g;

    .line 270
    .line 271
    invoke-direct {v12, v0, v5}, Ld8/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 272
    .line 273
    .line 274
    const-string v0, "X-Crashlytics-API-Client-Version"

    .line 275
    .line 276
    iget-object v5, v11, Lf6/e;->b:Lb6/b;

    .line 277
    .line 278
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 279
    .line 280
    .line 281
    const-string v5, "2.1.2"

    .line 282
    .line 283
    move/from16 v17, v4

    .line 284
    .line 285
    new-instance v4, Ld8/g;

    .line 286
    .line 287
    invoke-direct {v4, v0, v5}, Ld8/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 288
    .line 289
    .line 290
    const/4 v0, 0x5

    .line 291
    new-array v5, v0, [Ld8/g;

    .line 292
    .line 293
    aput-object v13, v5, v16

    .line 294
    .line 295
    aput-object v14, v5, p1

    .line 296
    .line 297
    aput-object v15, v5, v7

    .line 298
    .line 299
    aput-object v12, v5, v17

    .line 300
    .line 301
    const/4 v12, 0x4

    .line 302
    aput-object v4, v5, v12

    .line 303
    .line 304
    new-instance v4, Ljava/util/LinkedHashMap;

    .line 305
    .line 306
    invoke-static {v0}, Le8/u;->O(I)I

    .line 307
    .line 308
    .line 309
    move-result v0

    .line 310
    invoke-direct {v4, v0}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 311
    .line 312
    .line 313
    invoke-static {v4, v5}, Le8/u;->Q(Ljava/util/LinkedHashMap;[Ld8/g;)V

    .line 314
    .line 315
    .line 316
    const-string v0, "Fetching settings from server."

    .line 317
    .line 318
    invoke-static {v6, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 319
    .line 320
    .line 321
    iget-object v0, v11, Lf6/e;->c:Lf6/g;

    .line 322
    .line 323
    new-instance v5, Lf6/c;

    .line 324
    .line 325
    invoke-direct {v5, v11, v9}, Lf6/c;-><init>(Lf6/e;Lh8/d;)V

    .line 326
    .line 327
    .line 328
    new-instance v6, Lf6/d;

    .line 329
    .line 330
    invoke-direct {v6, v7, v9}, Lj8/i;-><init>(ILh8/d;)V

    .line 331
    .line 332
    .line 333
    iput-object v3, v2, Lf6/b;->r:Ljava/lang/Object;

    .line 334
    .line 335
    iput-object v9, v2, Lf6/b;->s:LJ8/a;

    .line 336
    .line 337
    move/from16 v7, v17

    .line 338
    .line 339
    iput v7, v2, Lf6/b;->v:I

    .line 340
    .line 341
    iget-object v7, v0, Lf6/g;->b:Lh8/i;

    .line 342
    .line 343
    new-instance v18, Lf6/f;

    .line 344
    .line 345
    const/16 v23, 0x0

    .line 346
    .line 347
    move-object/from16 v19, v0

    .line 348
    .line 349
    move-object/from16 v20, v4

    .line 350
    .line 351
    move-object/from16 v21, v5

    .line 352
    .line 353
    move-object/from16 v22, v6

    .line 354
    .line 355
    invoke-direct/range {v18 .. v23}, Lf6/f;-><init>(Lf6/g;Ljava/util/Map;Lf6/c;Lf6/d;Lh8/d;)V

    .line 356
    .line 357
    .line 358
    move-object/from16 v0, v18

    .line 359
    .line 360
    invoke-static {v7, v0, v2}, LB8/D;->C(Lh8/i;Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 361
    .line 362
    .line 363
    move-result-object v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 364
    if-ne v0, v10, :cond_a

    .line 365
    .line 366
    goto :goto_3

    .line 367
    :cond_a
    move-object v0, v8

    .line 368
    :goto_3
    if-ne v0, v10, :cond_b

    .line 369
    .line 370
    :goto_4
    return-object v10

    .line 371
    :cond_b
    move-object v2, v3

    .line 372
    :goto_5
    invoke-interface {v2, v9}, LJ8/a;->a(Ljava/lang/Object;)V

    .line 373
    .line 374
    .line 375
    return-object v8

    .line 376
    :goto_6
    invoke-interface {v2, v9}, LJ8/a;->a(Ljava/lang/Object;)V

    .line 377
    .line 378
    .line 379
    throw v0
.end method

.method public final c()Ljava/lang/Double;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lf6/e;->e()Lf6/n;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Lf6/n;->b:Lf6/h;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, v0, Lf6/h;->b:Ljava/lang/Double;

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    const-string v0, "sessionConfigs"

    .line 13
    .line 14
    invoke-static {v0}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    throw v0
.end method

.method public final d()LA8/a;
    .locals 3

    .line 1
    invoke-virtual {p0}, Lf6/e;->e()Lf6/n;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Lf6/n;->b:Lf6/h;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    iget-object v0, v0, Lf6/h;->c:Ljava/lang/Integer;

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    sget v1, LA8/a;->d:I

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    sget-object v1, LA8/c;->d:LA8/c;

    .line 21
    .line 22
    invoke-static {v0, v1}, LI3/a;->J(ILA8/c;)J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    new-instance v2, LA8/a;

    .line 27
    .line 28
    invoke-direct {v2, v0, v1}, LA8/a;-><init>(J)V

    .line 29
    .line 30
    .line 31
    return-object v2

    .line 32
    :cond_0
    return-object v1

    .line 33
    :cond_1
    const-string v0, "sessionConfigs"

    .line 34
    .line 35
    invoke-static {v0}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    throw v1
.end method

.method public final e()Lf6/n;
    .locals 2

    .line 1
    iget-object v0, p0, Lf6/e;->d:Ld6/a;

    .line 2
    .line 3
    invoke-interface {v0}, Ld6/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const-string v1, "lazySettingsCache.get()"

    .line 8
    .line 9
    invoke-static {v0, v1}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    check-cast v0, Lf6/n;

    .line 13
    .line 14
    return-object v0
.end method
