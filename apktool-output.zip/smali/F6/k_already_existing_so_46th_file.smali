.class public final Lf6/k;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:Lf6/n;

.field public s:I

.field public final synthetic t:Lf6/n;


# direct methods
.method public constructor <init>(Lf6/n;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lf6/k;->t:Lf6/n;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lj8/i;-><init>(ILh8/d;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 1

    .line 1
    new-instance p1, Lf6/k;

    .line 2
    .line 3
    iget-object v0, p0, Lf6/k;->t:Lf6/n;

    .line 4
    .line 5
    invoke-direct {p1, v0, p2}, Lf6/k;-><init>(Lf6/n;Lh8/d;)V

    .line 6
    .line 7
    .line 8
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lf6/k;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lf6/k;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lf6/k;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, Lf6/k;->s:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    iget-object v0, p0, Lf6/k;->r:Lf6/n;

    .line 9
    .line 10
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    goto :goto_0

    .line 14
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 15
    .line 16
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 17
    .line 18
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    throw p1

    .line 22
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget-object v0, p0, Lf6/k;->t:Lf6/n;

    .line 26
    .line 27
    iget-object p1, v0, Lf6/n;->a:LY/h;

    .line 28
    .line 29
    invoke-interface {p1}, LY/h;->b()LE8/e;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iput-object v0, p0, Lf6/k;->r:Lf6/n;

    .line 34
    .line 35
    iput v1, p0, Lf6/k;->s:I

    .line 36
    .line 37
    invoke-static {p1, p0}, LE8/P;->k(LE8/e;Lj8/c;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    sget-object v2, Li8/a;->a:Li8/a;

    .line 42
    .line 43
    if-ne p1, v2, :cond_2

    .line 44
    .line 45
    return-object v2

    .line 46
    :cond_2
    :goto_0
    check-cast p1, Lc0/b;

    .line 47
    .line 48
    new-instance v2, Lc0/b;

    .line 49
    .line 50
    invoke-virtual {p1}, Lc0/b;->a()Ljava/util/Map;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    invoke-static {p1}, Le8/u;->T(Ljava/util/Map;)Ljava/util/LinkedHashMap;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-direct {v2, p1, v1}, Lc0/b;-><init>(Ljava/util/LinkedHashMap;Z)V

    .line 59
    .line 60
    .line 61
    invoke-static {v0, v2}, Lf6/n;->a(Lf6/n;Lc0/b;)V

    .line 62
    .line 63
    .line 64
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 65
    .line 66
    return-object p1
.end method
