.class public interface abstract Lf6/o;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Ljava/lang/Boolean;
.end method

.method public abstract b(Lh8/d;)Ljava/lang/Object;
.end method

.method public abstract c()Ljava/lang/Double;
.end method

.method public abstract d()LA8/a;
.end method
