.class public final Lf6/i;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public r:Lf6/j;

.field public synthetic s:Ljava/lang/Object;

.field public final synthetic t:Lf6/j;

.field public u:I


# direct methods
.method public constructor <init>(Lf6/j;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lf6/i;->t:Lf6/j;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lf6/i;->s:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lf6/i;->u:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lf6/i;->u:I

    .line 9
    .line 10
    iget-object p1, p0, Lf6/i;->t:Lf6/j;

    .line 11
    .line 12
    invoke-virtual {p1, p0}, Lf6/j;->b(Lj8/c;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    return-object p1
.end method
