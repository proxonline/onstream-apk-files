.class public final LE6/g;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:LA5/e;

.field public t:I


# direct methods
.method public constructor <init>(LA5/e;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LE6/g;->s:LA5/e;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, LE6/g;->r:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, LE6/g;->t:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, LE6/g;->t:I

    .line 9
    .line 10
    iget-object p1, p0, LE6/g;->s:LA5/e;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, LA5/e;->H(Ljava/lang/Integer;Lj8/c;)Ljava/io/Serializable;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    sget-object v0, Li8/a;->a:Li8/a;

    .line 18
    .line 19
    if-ne p1, v0, :cond_0

    .line 20
    .line 21
    return-object p1

    .line 22
    :cond_0
    new-instance v0, Ld8/i;

    .line 23
    .line 24
    invoke-direct {v0, p1}, Ld8/i;-><init>(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    return-object v0
.end method
