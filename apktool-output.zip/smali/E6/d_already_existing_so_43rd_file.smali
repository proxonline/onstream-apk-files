.class public final LE6/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lt6/d0;

.field public final b:Ld5/k;

.field public final c:Ln6/d;

.field public final d:Ljava/util/LinkedHashSet;


# direct methods
.method public constructor <init>(Lt6/d0;Ld5/k;Ln6/d;)V
    .locals 1

    .line 1
    const-string v0, "traktRepository"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "encryptedPreference"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, LE6/d;->a:Lt6/d0;

    .line 15
    .line 16
    iput-object p2, p0, LE6/d;->b:Ld5/k;

    .line 17
    .line 18
    iput-object p3, p0, LE6/d;->c:Ln6/d;

    .line 19
    .line 20
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 21
    .line 22
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, LE6/d;->d:Ljava/util/LinkedHashSet;

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public final a(Lj8/c;)Ljava/lang/Object;
    .locals 9

    .line 1
    instance-of v0, p1, LE6/c;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, LE6/c;

    .line 7
    .line 8
    iget v1, v0, LE6/c;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LE6/c;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LE6/c;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, LE6/c;-><init>(LE6/d;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, LE6/c;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LE6/c;->t:I

    .line 28
    .line 29
    iget-object v2, p0, LE6/d;->d:Ljava/util/LinkedHashSet;

    .line 30
    .line 31
    iget-object v3, p0, LE6/d;->c:Ln6/d;

    .line 32
    .line 33
    const/4 v4, 0x1

    .line 34
    if-eqz v1, :cond_2

    .line 35
    .line 36
    if-ne v1, v4, :cond_1

    .line 37
    .line 38
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    goto :goto_3

    .line 42
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 43
    .line 44
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    throw p1

    .line 50
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    sget-object p1, Lg6/o;->a:Lg6/o;

    .line 54
    .line 55
    invoke-virtual {p1}, Lg6/o;->c0()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    iget-object v1, v3, Ln6/d;->a:Landroid/content/SharedPreferences;

    .line 60
    .line 61
    const-string v5, ""

    .line 62
    .line 63
    invoke-interface {v1, p1, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    new-array v1, v4, [Ljava/lang/reflect/Type;

    .line 68
    .line 69
    const-class v5, Ljava/lang/Long;

    .line 70
    .line 71
    const/4 v6, 0x0

    .line 72
    aput-object v5, v1, v6

    .line 73
    .line 74
    invoke-static {v1}, LP7/C;->f([Ljava/lang/reflect/Type;)LQ7/c;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    sget-object v5, Le8/q;->a:Le8/q;

    .line 79
    .line 80
    const/4 v6, 0x0

    .line 81
    if-eqz p1, :cond_6

    .line 82
    .line 83
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 84
    .line 85
    .line 86
    move-result v7

    .line 87
    if-nez v7, :cond_3

    .line 88
    .line 89
    goto :goto_2

    .line 90
    :cond_3
    :try_start_0
    iget-object v7, v3, Ln6/d;->b:LP7/x;

    .line 91
    .line 92
    sget-object v8, LQ7/e;->a:Ljava/util/Set;

    .line 93
    .line 94
    invoke-virtual {v7, v1, v8, v6}, LP7/x;->b(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)LP7/k;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    invoke-virtual {v1, p1}, LP7/k;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    check-cast p1, Ljava/util/List;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 103
    .line 104
    goto :goto_1

    .line 105
    :catchall_0
    move-exception p1

    .line 106
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    :goto_1
    instance-of v1, p1, Ld8/h;

    .line 111
    .line 112
    if-eqz v1, :cond_4

    .line 113
    .line 114
    move-object p1, v6

    .line 115
    :cond_4
    check-cast p1, Ljava/util/List;

    .line 116
    .line 117
    if-nez p1, :cond_5

    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_5
    move-object v5, p1

    .line 121
    :cond_6
    :goto_2
    invoke-interface {v2, v5}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 122
    .line 123
    .line 124
    iput v4, v0, LE6/c;->t:I

    .line 125
    .line 126
    iget-object p1, p0, LE6/d;->a:Lt6/d0;

    .line 127
    .line 128
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 129
    .line 130
    .line 131
    sget-object v1, Lv6/b;->a:LP7/x;

    .line 132
    .line 133
    new-instance v1, Lt6/c0;

    .line 134
    .line 135
    invoke-direct {v1, v6, p1, v6}, Lt6/c0;-><init>(Ljava/lang/Integer;Lt6/d0;Lh8/d;)V

    .line 136
    .line 137
    .line 138
    invoke-static {v1, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    sget-object v0, Li8/a;->a:Li8/a;

    .line 143
    .line 144
    if-ne p1, v0, :cond_7

    .line 145
    .line 146
    return-object v0

    .line 147
    :cond_7
    :goto_3
    check-cast p1, Lk6/c;

    .line 148
    .line 149
    instance-of v0, p1, Lk6/b;

    .line 150
    .line 151
    if-eqz v0, :cond_d

    .line 152
    .line 153
    check-cast p1, Lk6/b;

    .line 154
    .line 155
    iget-object p1, p1, Lk6/b;->a:Ljava/lang/Object;

    .line 156
    .line 157
    check-cast p1, Ljava/util/List;

    .line 158
    .line 159
    iget-object v0, p0, LE6/d;->b:Ld5/k;

    .line 160
    .line 161
    invoke-static {v0, p1}, Lr6/a;->a(Lx6/l;Ljava/util/List;)Ljava/util/List;

    .line 162
    .line 163
    .line 164
    move-result-object p1

    .line 165
    invoke-interface {v2, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    .line 166
    .line 167
    .line 168
    sget-object v0, Lg6/o;->a:Lg6/o;

    .line 169
    .line 170
    invoke-virtual {v0}, Lg6/o;->c0()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    iget-object v1, v3, Ln6/d;->a:Landroid/content/SharedPreferences;

    .line 175
    .line 176
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 177
    .line 178
    .line 179
    move-result-object v1

    .line 180
    instance-of v2, p1, Ljava/lang/String;

    .line 181
    .line 182
    if-eqz v2, :cond_8

    .line 183
    .line 184
    check-cast p1, Ljava/lang/String;

    .line 185
    .line 186
    invoke-interface {v1, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 187
    .line 188
    .line 189
    goto :goto_4

    .line 190
    :cond_8
    instance-of v2, p1, Ljava/lang/Float;

    .line 191
    .line 192
    if-eqz v2, :cond_9

    .line 193
    .line 194
    check-cast p1, Ljava/lang/Number;

    .line 195
    .line 196
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 197
    .line 198
    .line 199
    move-result p1

    .line 200
    invoke-interface {v1, v0, p1}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    .line 201
    .line 202
    .line 203
    goto :goto_4

    .line 204
    :cond_9
    instance-of v2, p1, Ljava/lang/Integer;

    .line 205
    .line 206
    if-eqz v2, :cond_a

    .line 207
    .line 208
    check-cast p1, Ljava/lang/Number;

    .line 209
    .line 210
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 211
    .line 212
    .line 213
    move-result p1

    .line 214
    invoke-interface {v1, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 215
    .line 216
    .line 217
    goto :goto_4

    .line 218
    :cond_a
    instance-of v2, p1, Ljava/lang/Long;

    .line 219
    .line 220
    if-eqz v2, :cond_b

    .line 221
    .line 222
    check-cast p1, Ljava/lang/Number;

    .line 223
    .line 224
    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    .line 225
    .line 226
    .line 227
    move-result-wide v2

    .line 228
    invoke-interface {v1, v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 229
    .line 230
    .line 231
    goto :goto_4

    .line 232
    :cond_b
    instance-of v2, p1, Ljava/lang/Boolean;

    .line 233
    .line 234
    if-eqz v2, :cond_c

    .line 235
    .line 236
    check-cast p1, Ljava/lang/Boolean;

    .line 237
    .line 238
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 239
    .line 240
    .line 241
    move-result p1

    .line 242
    invoke-interface {v1, v0, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 243
    .line 244
    .line 245
    goto :goto_4

    .line 246
    :cond_c
    iget-object v2, v3, Ln6/d;->b:LP7/x;

    .line 247
    .line 248
    const-class v3, Ljava/util/List;

    .line 249
    .line 250
    invoke-virtual {v2, v3}, LP7/x;->a(Ljava/lang/Class;)LP7/k;

    .line 251
    .line 252
    .line 253
    move-result-object v2

    .line 254
    invoke-virtual {v2, p1}, LP7/k;->d(Ljava/lang/Object;)Ljava/lang/String;

    .line 255
    .line 256
    .line 257
    move-result-object p1

    .line 258
    invoke-interface {v1, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 259
    .line 260
    .line 261
    :goto_4
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 262
    .line 263
    .line 264
    :cond_d
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 265
    .line 266
    return-object p1
.end method
