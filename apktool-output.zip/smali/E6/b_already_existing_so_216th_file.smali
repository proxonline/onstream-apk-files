.class public interface abstract Le6/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc8/a;
