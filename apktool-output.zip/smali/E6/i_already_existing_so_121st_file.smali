.class public final LE6/i;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:Lo3/i;

.field public t:I


# direct methods
.method public constructor <init>(Lo3/i;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LE6/i;->s:Lo3/i;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, LE6/i;->r:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, LE6/i;->t:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, LE6/i;->t:I

    .line 9
    .line 10
    iget-object p1, p0, LE6/i;->s:Lo3/i;

    .line 11
    .line 12
    invoke-virtual {p1, p0}, Lo3/i;->T(Lj8/c;)Ljava/io/Serializable;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    sget-object v0, Li8/a;->a:Li8/a;

    .line 17
    .line 18
    if-ne p1, v0, :cond_0

    .line 19
    .line 20
    return-object p1

    .line 21
    :cond_0
    new-instance v0, Ld8/i;

    .line 22
    .line 23
    invoke-direct {v0, p1}, Ld8/i;-><init>(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    return-object v0
.end method
