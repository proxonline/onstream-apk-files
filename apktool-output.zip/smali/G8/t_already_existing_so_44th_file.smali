.class public LG8/t;
.super LB8/a;
.source "SourceFile"

# interfaces
.implements Lj8/d;


# instance fields
.field public final d:Lh8/d;


# direct methods
.method public constructor <init>(Lh8/d;Lh8/i;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-direct {p0, p2, v0}, LB8/a;-><init>(Lh8/i;Z)V

    .line 3
    .line 4
    .line 5
    iput-object p1, p0, LG8/t;->d:Lh8/d;

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final O()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public final getCallerFrame()Lj8/d;
    .locals 2

    .line 1
    iget-object v0, p0, LG8/t;->d:Lh8/d;

    .line 2
    .line 3
    instance-of v1, v0, Lj8/d;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    check-cast v0, Lj8/d;

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    return-object v0
.end method

.method public m(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LG8/t;->d:Lh8/d;

    .line 2
    .line 3
    invoke-static {v0}, LT8/l;->A(Lh8/d;)Lh8/d;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {p1}, LB8/D;->t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-static {p1, v0}, LG8/a;->i(Ljava/lang/Object;Lh8/d;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public n(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget-object v0, p0, LG8/t;->d:Lh8/d;

    .line 2
    .line 3
    invoke-static {p1}, LB8/D;->t(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-interface {v0, p1}, Lh8/d;->resumeWith(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
