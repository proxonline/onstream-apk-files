.class public final synthetic LD1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr8/a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LD1/c;->a:I

    iput-object p2, p0, LD1/c;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, LD1/c;->a:I

    .line 4
    .line 5
    sget-object v2, Ld8/l;->a:Ld8/l;

    .line 6
    .line 7
    const/4 v3, 0x4

    .line 8
    const/4 v4, 0x5

    .line 9
    const/4 v5, 0x0

    .line 10
    const/4 v6, 0x0

    .line 11
    const/4 v7, 0x1

    .line 12
    iget-object v8, v1, LD1/c;->b:Ljava/lang/Object;

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    return-object v8

    .line 18
    :pswitch_0
    check-cast v8, Lcom/maertsno/m/ui/settings/picker/ColorPickerDialog;

    .line 19
    .line 20
    new-instance v0, Lv7/a;

    .line 21
    .line 22
    invoke-direct {v0, v8}, Lv7/a;-><init>(Lcom/maertsno/m/ui/settings/picker/ColorPickerDialog;)V

    .line 23
    .line 24
    .line 25
    return-object v0

    .line 26
    :pswitch_1
    check-cast v8, LH0/w;

    .line 27
    .line 28
    const-class v0, Ln6/c;

    .line 29
    .line 30
    invoke-static {v0}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    iget-object v2, v8, LH0/w;->j:Ljava/util/LinkedHashMap;

    .line 35
    .line 36
    invoke-virtual {v2, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    const-string v2, "null cannot be cast to non-null type T of androidx.room.RoomDatabase.getTypeConverter"

    .line 41
    .line 42
    invoke-static {v0, v2}, Lkotlin/jvm/internal/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    check-cast v0, Ln6/c;

    .line 46
    .line 47
    return-object v0

    .line 48
    :pswitch_2
    check-cast v8, Lcom/maertsno/m/ui/rating/RatingBottomSheetFragment;

    .line 49
    .line 50
    invoke-virtual {v8}, Lj0/y;->q()Landroid/content/res/Resources;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    const v2, 0x7f030005

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    return-object v0

    .line 62
    :pswitch_3
    check-cast v8, Lm7/e;

    .line 63
    .line 64
    invoke-virtual {v8}, Lj0/y;->a0()Lj0/y;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    return-object v0

    .line 69
    :pswitch_4
    check-cast v8, Lh7/e;

    .line 70
    .line 71
    invoke-virtual {v8}, Lj0/y;->a0()Lj0/y;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    return-object v0

    .line 76
    :pswitch_5
    check-cast v8, Lj0/B;

    .line 77
    .line 78
    invoke-virtual {v8}, Ld/k;->reportFullyDrawn()V

    .line 79
    .line 80
    .line 81
    return-object v5

    .line 82
    :pswitch_6
    check-cast v8, Lc7/a;

    .line 83
    .line 84
    iget-object v0, v8, Lc7/a;->w:LW/g;

    .line 85
    .line 86
    check-cast v0, LN6/O0;

    .line 87
    .line 88
    iget-object v0, v0, LW/g;->s:Landroid/view/View;

    .line 89
    .line 90
    const-string v2, "getRoot(...)"

    .line 91
    .line 92
    invoke-static {v0, v2}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    invoke-static {v0}, LI7/f;->d(Landroid/view/View;)Z

    .line 96
    .line 97
    .line 98
    move-result v0

    .line 99
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    return-object v0

    .line 104
    :pswitch_7
    check-cast v8, Landroidx/lifecycle/g0;

    .line 105
    .line 106
    invoke-static {v8}, Landroidx/lifecycle/V;->f(Landroidx/lifecycle/g0;)Landroidx/lifecycle/X;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    return-object v0

    .line 111
    :pswitch_8
    check-cast v8, LW6/m;

    .line 112
    .line 113
    new-instance v0, LW6/c;

    .line 114
    .line 115
    new-instance v2, LB7/f;

    .line 116
    .line 117
    invoke-direct {v2, v4, v8}, LB7/f;-><init>(ILjava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    new-instance v4, LE1/a;

    .line 121
    .line 122
    invoke-direct {v4, v3, v8}, LE1/a;-><init>(ILjava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    invoke-direct {v0, v2, v4}, LW6/c;-><init>(LB7/f;LE1/a;)V

    .line 126
    .line 127
    .line 128
    return-object v0

    .line 129
    :pswitch_9
    check-cast v8, Lcom/maertsno/m/ui/download/DownloadFragment;

    .line 130
    .line 131
    new-instance v0, LV6/p;

    .line 132
    .line 133
    new-instance v2, LE1/a;

    .line 134
    .line 135
    const/4 v3, 0x3

    .line 136
    invoke-direct {v2, v3, v8}, LE1/a;-><init>(ILjava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    invoke-direct {v0, v2}, LV6/p;-><init>(LE1/a;)V

    .line 140
    .line 141
    .line 142
    return-object v0

    .line 143
    :pswitch_a
    check-cast v8, LT0/h;

    .line 144
    .line 145
    iget-object v0, v8, LT0/h;->c:LS0/b;

    .line 146
    .line 147
    iget-object v2, v8, LT0/h;->a:Landroid/content/Context;

    .line 148
    .line 149
    iget-object v3, v8, LT0/h;->b:Ljava/lang/String;

    .line 150
    .line 151
    const/16 v4, 0x16

    .line 152
    .line 153
    if-eqz v3, :cond_0

    .line 154
    .line 155
    iget-boolean v5, v8, LT0/h;->d:Z

    .line 156
    .line 157
    if-eqz v5, :cond_0

    .line 158
    .line 159
    new-instance v5, Ljava/io/File;

    .line 160
    .line 161
    const-string v7, "context"

    .line 162
    .line 163
    invoke-static {v2, v7}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 164
    .line 165
    .line 166
    invoke-virtual {v2}, Landroid/content/Context;->getNoBackupFilesDir()Ljava/io/File;

    .line 167
    .line 168
    .line 169
    move-result-object v7

    .line 170
    const-string v9, "getNoBackupFilesDir(...)"

    .line 171
    .line 172
    invoke-static {v7, v9}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    invoke-direct {v5, v7, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 176
    .line 177
    .line 178
    new-instance v3, LT0/g;

    .line 179
    .line 180
    invoke-virtual {v5}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v5

    .line 184
    new-instance v7, Lo3/i;

    .line 185
    .line 186
    invoke-direct {v7, v4, v6}, Lo3/i;-><init>(IB)V

    .line 187
    .line 188
    .line 189
    invoke-direct {v3, v2, v5, v7, v0}, LT0/g;-><init>(Landroid/content/Context;Ljava/lang/String;Lo3/i;LS0/b;)V

    .line 190
    .line 191
    .line 192
    goto :goto_0

    .line 193
    :cond_0
    new-instance v5, LT0/g;

    .line 194
    .line 195
    new-instance v7, Lo3/i;

    .line 196
    .line 197
    invoke-direct {v7, v4, v6}, Lo3/i;-><init>(IB)V

    .line 198
    .line 199
    .line 200
    invoke-direct {v5, v2, v3, v7, v0}, LT0/g;-><init>(Landroid/content/Context;Ljava/lang/String;Lo3/i;LS0/b;)V

    .line 201
    .line 202
    .line 203
    move-object v3, v5

    .line 204
    :goto_0
    iget-boolean v0, v8, LT0/h;->f:Z

    .line 205
    .line 206
    invoke-virtual {v3, v0}, Landroid/database/sqlite/SQLiteOpenHelper;->setWriteAheadLoggingEnabled(Z)V

    .line 207
    .line 208
    .line 209
    return-object v3

    .line 210
    :pswitch_b
    check-cast v8, LS6/f;

    .line 211
    .line 212
    iget-object v0, v8, Lj0/y;->x:Lj0/y;

    .line 213
    .line 214
    if-eqz v0, :cond_1

    .line 215
    .line 216
    invoke-virtual {v8}, Lj0/y;->a0()Lj0/y;

    .line 217
    .line 218
    .line 219
    move-result-object v8

    .line 220
    :cond_1
    return-object v8

    .line 221
    :pswitch_c
    check-cast v8, LO6/g;

    .line 222
    .line 223
    new-instance v0, LL8/z;

    .line 224
    .line 225
    invoke-direct {v0}, LL8/z;-><init>()V

    .line 226
    .line 227
    .line 228
    iget-object v2, v8, LO6/g;->b:Ld8/j;

    .line 229
    .line 230
    invoke-virtual {v2}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object v2

    .line 234
    check-cast v2, LO6/f;

    .line 235
    .line 236
    invoke-virtual {v0, v2}, LL8/z;->a(LL8/v;)V

    .line 237
    .line 238
    .line 239
    iput-boolean v7, v0, LL8/z;->f:Z

    .line 240
    .line 241
    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 242
    .line 243
    const-string v3, "unit"

    .line 244
    .line 245
    invoke-static {v2, v3}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 246
    .line 247
    .line 248
    const-wide/16 v3, 0xf

    .line 249
    .line 250
    invoke-static {v3, v4, v2}, LM8/b;->b(JLjava/util/concurrent/TimeUnit;)I

    .line 251
    .line 252
    .line 253
    move-result v2

    .line 254
    iput v2, v0, LL8/z;->v:I

    .line 255
    .line 256
    new-instance v2, LL8/A;

    .line 257
    .line 258
    invoke-direct {v2, v0}, LL8/A;-><init>(LL8/z;)V

    .line 259
    .line 260
    .line 261
    new-instance v0, Ln1/g;

    .line 262
    .line 263
    const/16 v3, 0xa

    .line 264
    .line 265
    invoke-direct {v0, v3}, Ln1/g;-><init>(I)V

    .line 266
    .line 267
    .line 268
    const-string v3, "https://base.url"

    .line 269
    .line 270
    invoke-virtual {v0, v3}, Ln1/g;->c(Ljava/lang/String;)V

    .line 271
    .line 272
    .line 273
    iput-object v2, v0, Ln1/g;->b:Ljava/lang/Object;

    .line 274
    .line 275
    invoke-virtual {v0}, Ln1/g;->e()La9/P;

    .line 276
    .line 277
    .line 278
    move-result-object v0

    .line 279
    const-class v2, LO6/c;

    .line 280
    .line 281
    invoke-virtual {v0, v2}, La9/P;->b(Ljava/lang/Class;)Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object v0

    .line 285
    check-cast v0, LO6/c;

    .line 286
    .line 287
    return-object v0

    .line 288
    :pswitch_d
    check-cast v8, LO0/e;

    .line 289
    .line 290
    invoke-interface {v8}, Landroidx/lifecycle/v;->C()LD/o;

    .line 291
    .line 292
    .line 293
    move-result-object v0

    .line 294
    new-instance v3, LO0/b;

    .line 295
    .line 296
    invoke-direct {v3, v6, v8}, LO0/b;-><init>(ILjava/lang/Object;)V

    .line 297
    .line 298
    .line 299
    invoke-virtual {v0, v3}, LD/o;->X(Landroidx/lifecycle/u;)V

    .line 300
    .line 301
    .line 302
    return-object v2

    .line 303
    :pswitch_e
    check-cast v8, LA5/e;

    .line 304
    .line 305
    const-string v0, ":memory:"

    .line 306
    .line 307
    invoke-virtual {v8, v0}, LA5/e;->a(Ljava/lang/String;)LR0/a;

    .line 308
    .line 309
    .line 310
    move-result-object v0

    .line 311
    return-object v0

    .line 312
    :pswitch_f
    check-cast v8, LH0/C;

    .line 313
    .line 314
    invoke-virtual {v8}, LH0/C;->b()Ljava/lang/String;

    .line 315
    .line 316
    .line 317
    move-result-object v0

    .line 318
    iget-object v2, v8, LH0/C;->a:Ljava/lang/Object;

    .line 319
    .line 320
    check-cast v2, LH0/w;

    .line 321
    .line 322
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 323
    .line 324
    .line 325
    invoke-virtual {v2}, LH0/w;->a()V

    .line 326
    .line 327
    .line 328
    invoke-virtual {v2}, LH0/w;->b()V

    .line 329
    .line 330
    .line 331
    invoke-virtual {v2}, LH0/w;->i()LS0/d;

    .line 332
    .line 333
    .line 334
    move-result-object v2

    .line 335
    invoke-interface {v2}, LS0/d;->a0()LS0/a;

    .line 336
    .line 337
    .line 338
    move-result-object v2

    .line 339
    invoke-interface {v2, v0}, LS0/a;->v(Ljava/lang/String;)LT0/j;

    .line 340
    .line 341
    .line 342
    move-result-object v0

    .line 343
    return-object v0

    .line 344
    :pswitch_10
    check-cast v8, Lcom/maertsno/m/ui/update/UpdateFragment;

    .line 345
    .line 346
    :try_start_0
    iget-object v0, v8, Lcom/maertsno/m/ui/update/UpdateFragment;->D0:Lj0/r;

    .line 347
    .line 348
    const-string v3, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 349
    .line 350
    invoke-virtual {v0, v3}, Lj0/r;->a(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 351
    .line 352
    .line 353
    goto :goto_1

    .line 354
    :catch_0
    new-instance v0, LR6/y;

    .line 355
    .line 356
    const v3, 0x7f140180

    .line 357
    .line 358
    .line 359
    invoke-direct {v0, v3}, LR6/y;-><init>(I)V

    .line 360
    .line 361
    .line 362
    invoke-virtual {v8, v0, v7}, LR6/n;->p0(LR6/z;Z)V

    .line 363
    .line 364
    .line 365
    :goto_1
    return-object v2

    .line 366
    :pswitch_11
    check-cast v8, LD1/g;

    .line 367
    .line 368
    new-instance v0, Landroid/graphics/BitmapFactory$Options;

    .line 369
    .line 370
    invoke-direct {v0}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    .line 371
    .line 372
    .line 373
    iget-object v2, v8, LD1/g;->b:LM1/n;

    .line 374
    .line 375
    new-instance v9, LD1/d;

    .line 376
    .line 377
    iget-object v10, v8, LD1/g;->a:LD1/p;

    .line 378
    .line 379
    invoke-virtual {v10}, LD1/p;->f()LY8/i;

    .line 380
    .line 381
    .line 382
    move-result-object v11

    .line 383
    invoke-direct {v9, v11}, LD1/d;-><init>(LY8/I;)V

    .line 384
    .line 385
    .line 386
    invoke-static {v9}, LT8/d;->c(LY8/I;)LY8/C;

    .line 387
    .line 388
    .line 389
    move-result-object v11

    .line 390
    iput-boolean v7, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 391
    .line 392
    new-instance v12, LY8/z;

    .line 393
    .line 394
    invoke-direct {v12, v11}, LY8/z;-><init>(LY8/i;)V

    .line 395
    .line 396
    .line 397
    invoke-static {v12}, LT8/d;->c(LY8/I;)LY8/C;

    .line 398
    .line 399
    .line 400
    move-result-object v12

    .line 401
    new-instance v13, LY8/f;

    .line 402
    .line 403
    invoke-direct {v13, v12, v7}, LY8/f;-><init>(LY8/i;I)V

    .line 404
    .line 405
    .line 406
    invoke-static {v13, v5, v0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 407
    .line 408
    .line 409
    iget-object v12, v9, LD1/d;->c:Ljava/lang/Object;

    .line 410
    .line 411
    check-cast v12, Ljava/lang/Exception;

    .line 412
    .line 413
    if-nez v12, :cond_2e

    .line 414
    .line 415
    iput-boolean v6, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    .line 416
    .line 417
    sget-object v12, LD1/m;->a:Landroid/graphics/Paint;

    .line 418
    .line 419
    iget-object v12, v0, Landroid/graphics/BitmapFactory$Options;->outMimeType:Ljava/lang/String;

    .line 420
    .line 421
    iget-object v8, v8, LD1/g;->d:LD1/l;

    .line 422
    .line 423
    sget-object v13, LD1/n;->a:Ljava/util/Set;

    .line 424
    .line 425
    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    .line 426
    .line 427
    .line 428
    move-result v8

    .line 429
    if-eqz v8, :cond_7

    .line 430
    .line 431
    const/4 v15, 0x2

    .line 432
    if-eq v8, v7, :cond_3

    .line 433
    .line 434
    if-ne v8, v15, :cond_2

    .line 435
    .line 436
    goto :goto_2

    .line 437
    :cond_2
    new-instance v0, LB8/s;

    .line 438
    .line 439
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 440
    .line 441
    .line 442
    throw v0

    .line 443
    :cond_3
    if-eqz v12, :cond_7

    .line 444
    .line 445
    sget-object v8, LD1/n;->a:Ljava/util/Set;

    .line 446
    .line 447
    invoke-interface {v8, v12}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 448
    .line 449
    .line 450
    move-result v8

    .line 451
    if-eqz v8, :cond_7

    .line 452
    .line 453
    :goto_2
    new-instance v8, Lh0/g;

    .line 454
    .line 455
    new-instance v12, LD1/k;

    .line 456
    .line 457
    new-instance v5, LY8/z;

    .line 458
    .line 459
    invoke-direct {v5, v11}, LY8/z;-><init>(LY8/i;)V

    .line 460
    .line 461
    .line 462
    invoke-static {v5}, LT8/d;->c(LY8/I;)LY8/C;

    .line 463
    .line 464
    .line 465
    move-result-object v5

    .line 466
    new-instance v13, LY8/f;

    .line 467
    .line 468
    invoke-direct {v13, v5, v7}, LY8/f;-><init>(LY8/i;I)V

    .line 469
    .line 470
    .line 471
    invoke-direct {v12, v13}, LD1/k;-><init>(Ljava/io/InputStream;)V

    .line 472
    .line 473
    .line 474
    invoke-direct {v8, v12}, Lh0/g;-><init>(LD1/k;)V

    .line 475
    .line 476
    .line 477
    new-instance v5, LD1/j;

    .line 478
    .line 479
    const-string v12, "Orientation"

    .line 480
    .line 481
    invoke-virtual {v8, v12}, Lh0/g;->c(Ljava/lang/String;)Lh0/c;

    .line 482
    .line 483
    .line 484
    move-result-object v13

    .line 485
    if-nez v13, :cond_4

    .line 486
    .line 487
    goto :goto_3

    .line 488
    :cond_4
    :try_start_1
    iget-object v14, v8, Lh0/g;->e:Ljava/nio/ByteOrder;

    .line 489
    .line 490
    invoke-virtual {v13, v14}, Lh0/c;->e(Ljava/nio/ByteOrder;)I

    .line 491
    .line 492
    .line 493
    move-result v13
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    .line 494
    goto :goto_4

    .line 495
    :catch_1
    :goto_3
    move v13, v7

    .line 496
    :goto_4
    if-eq v13, v15, :cond_5

    .line 497
    .line 498
    const/4 v14, 0x7

    .line 499
    if-eq v13, v14, :cond_5

    .line 500
    .line 501
    if-eq v13, v3, :cond_5

    .line 502
    .line 503
    if-eq v13, v4, :cond_5

    .line 504
    .line 505
    move v3, v6

    .line 506
    goto :goto_5

    .line 507
    :cond_5
    move v3, v7

    .line 508
    :goto_5
    invoke-virtual {v8, v12}, Lh0/g;->c(Ljava/lang/String;)Lh0/c;

    .line 509
    .line 510
    .line 511
    move-result-object v4

    .line 512
    if-nez v4, :cond_6

    .line 513
    .line 514
    goto :goto_6

    .line 515
    :cond_6
    :try_start_2
    iget-object v8, v8, Lh0/g;->e:Ljava/nio/ByteOrder;

    .line 516
    .line 517
    invoke-virtual {v4, v8}, Lh0/c;->e(Ljava/nio/ByteOrder;)I

    .line 518
    .line 519
    .line 520
    move-result v4
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_2

    .line 521
    goto :goto_7

    .line 522
    :catch_2
    :goto_6
    move v4, v7

    .line 523
    :goto_7
    packed-switch v4, :pswitch_data_1

    .line 524
    .line 525
    .line 526
    move v4, v6

    .line 527
    goto :goto_8

    .line 528
    :pswitch_12
    const/16 v4, 0x5a

    .line 529
    .line 530
    goto :goto_8

    .line 531
    :pswitch_13
    const/16 v4, 0x10e

    .line 532
    .line 533
    goto :goto_8

    .line 534
    :pswitch_14
    const/16 v4, 0xb4

    .line 535
    .line 536
    :goto_8
    invoke-direct {v5, v4, v3}, LD1/j;-><init>(IZ)V

    .line 537
    .line 538
    .line 539
    goto :goto_9

    .line 540
    :cond_7
    sget-object v5, LD1/j;->c:LD1/j;

    .line 541
    .line 542
    :goto_9
    iget v3, v5, LD1/j;->b:I

    .line 543
    .line 544
    iget-boolean v4, v5, LD1/j;->a:Z

    .line 545
    .line 546
    iget-object v5, v9, LD1/d;->c:Ljava/lang/Object;

    .line 547
    .line 548
    check-cast v5, Ljava/lang/Exception;

    .line 549
    .line 550
    if-nez v5, :cond_2d

    .line 551
    .line 552
    iput-boolean v6, v0, Landroid/graphics/BitmapFactory$Options;->inMutable:Z

    .line 553
    .line 554
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 555
    .line 556
    const/16 v8, 0x1a

    .line 557
    .line 558
    if-lt v5, v8, :cond_8

    .line 559
    .line 560
    iget-object v12, v2, LM1/n;->c:Landroid/graphics/ColorSpace;

    .line 561
    .line 562
    if-eqz v12, :cond_8

    .line 563
    .line 564
    invoke-static {v0, v12}, LD1/b;->t(Landroid/graphics/BitmapFactory$Options;Landroid/graphics/ColorSpace;)V

    .line 565
    .line 566
    .line 567
    :cond_8
    iget-boolean v12, v2, LM1/n;->h:Z

    .line 568
    .line 569
    iget-object v13, v2, LM1/n;->a:Landroid/content/Context;

    .line 570
    .line 571
    iget-object v14, v2, LM1/n;->d:LN1/h;

    .line 572
    .line 573
    iput-boolean v12, v0, Landroid/graphics/BitmapFactory$Options;->inPremultiplied:Z

    .line 574
    .line 575
    iget-object v12, v2, LM1/n;->b:Landroid/graphics/Bitmap$Config;

    .line 576
    .line 577
    if-nez v4, :cond_9

    .line 578
    .line 579
    if-lez v3, :cond_b

    .line 580
    .line 581
    :cond_9
    if-eqz v12, :cond_a

    .line 582
    .line 583
    invoke-static {v12}, Lcom/google/android/gms/internal/measurement/e2;->t(Landroid/graphics/Bitmap$Config;)Z

    .line 584
    .line 585
    .line 586
    move-result v15

    .line 587
    if-eqz v15, :cond_b

    .line 588
    .line 589
    :cond_a
    sget-object v12, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 590
    .line 591
    :cond_b
    iget-boolean v15, v2, LM1/n;->g:Z

    .line 592
    .line 593
    if-eqz v15, :cond_c

    .line 594
    .line 595
    sget-object v15, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 596
    .line 597
    if-ne v12, v15, :cond_c

    .line 598
    .line 599
    iget-object v15, v0, Landroid/graphics/BitmapFactory$Options;->outMimeType:Ljava/lang/String;

    .line 600
    .line 601
    const-string v6, "image/jpeg"

    .line 602
    .line 603
    invoke-static {v15, v6}, Lkotlin/jvm/internal/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 604
    .line 605
    .line 606
    move-result v6

    .line 607
    if-eqz v6, :cond_c

    .line 608
    .line 609
    sget-object v12, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    .line 610
    .line 611
    :cond_c
    if-lt v5, v8, :cond_d

    .line 612
    .line 613
    invoke-static {v0}, LD1/b;->f(Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap$Config;

    .line 614
    .line 615
    .line 616
    move-result-object v5

    .line 617
    invoke-static {}, LD1/b;->e()Landroid/graphics/Bitmap$Config;

    .line 618
    .line 619
    .line 620
    move-result-object v6

    .line 621
    if-ne v5, v6, :cond_d

    .line 622
    .line 623
    invoke-static {}, LD1/b;->C()Landroid/graphics/Bitmap$Config;

    .line 624
    .line 625
    .line 626
    move-result-object v5

    .line 627
    if-eq v12, v5, :cond_d

    .line 628
    .line 629
    invoke-static {}, LD1/b;->e()Landroid/graphics/Bitmap$Config;

    .line 630
    .line 631
    .line 632
    move-result-object v12

    .line 633
    :cond_d
    iput-object v12, v0, Landroid/graphics/BitmapFactory$Options;->inPreferredConfig:Landroid/graphics/Bitmap$Config;

    .line 634
    .line 635
    invoke-virtual {v10}, LD1/p;->a()La/a;

    .line 636
    .line 637
    .line 638
    move-result-object v5

    .line 639
    instance-of v6, v5, LD1/q;

    .line 640
    .line 641
    if-eqz v6, :cond_e

    .line 642
    .line 643
    sget-object v6, LN1/h;->c:LN1/h;

    .line 644
    .line 645
    invoke-static {v14, v6}, Lkotlin/jvm/internal/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 646
    .line 647
    .line 648
    move-result v6

    .line 649
    if-eqz v6, :cond_e

    .line 650
    .line 651
    iput v7, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 652
    .line 653
    iput-boolean v7, v0, Landroid/graphics/BitmapFactory$Options;->inScaled:Z

    .line 654
    .line 655
    check-cast v5, LD1/q;

    .line 656
    .line 657
    iget v2, v5, LD1/q;->h:I

    .line 658
    .line 659
    iput v2, v0, Landroid/graphics/BitmapFactory$Options;->inDensity:I

    .line 660
    .line 661
    invoke-virtual {v13}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 662
    .line 663
    .line 664
    move-result-object v2

    .line 665
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 666
    .line 667
    .line 668
    move-result-object v2

    .line 669
    iget v2, v2, Landroid/util/DisplayMetrics;->densityDpi:I

    .line 670
    .line 671
    iput v2, v0, Landroid/graphics/BitmapFactory$Options;->inTargetDensity:I

    .line 672
    .line 673
    move v1, v4

    .line 674
    move v10, v7

    .line 675
    const/4 v2, 0x0

    .line 676
    goto/16 :goto_14

    .line 677
    .line 678
    :cond_e
    iget v5, v0, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    .line 679
    .line 680
    if-lez v5, :cond_f

    .line 681
    .line 682
    iget v6, v0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    .line 683
    .line 684
    if-gtz v6, :cond_10

    .line 685
    .line 686
    :cond_f
    move v1, v4

    .line 687
    move v10, v7

    .line 688
    goto/16 :goto_13

    .line 689
    .line 690
    :cond_10
    const/16 v8, 0x5a

    .line 691
    .line 692
    const/16 v10, 0x10e

    .line 693
    .line 694
    if-eq v3, v8, :cond_12

    .line 695
    .line 696
    if-ne v3, v10, :cond_11

    .line 697
    .line 698
    goto :goto_a

    .line 699
    :cond_11
    move v12, v5

    .line 700
    goto :goto_b

    .line 701
    :cond_12
    :goto_a
    move v12, v6

    .line 702
    :goto_b
    if-eq v3, v8, :cond_14

    .line 703
    .line 704
    if-ne v3, v10, :cond_13

    .line 705
    .line 706
    goto :goto_c

    .line 707
    :cond_13
    move v5, v6

    .line 708
    :cond_14
    :goto_c
    iget-object v6, v2, LM1/n;->e:LN1/g;

    .line 709
    .line 710
    sget-object v8, LN1/h;->c:LN1/h;

    .line 711
    .line 712
    invoke-static {v14, v8}, Lkotlin/jvm/internal/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 713
    .line 714
    .line 715
    move-result v10

    .line 716
    if-eqz v10, :cond_15

    .line 717
    .line 718
    move v10, v12

    .line 719
    goto :goto_d

    .line 720
    :cond_15
    iget-object v10, v14, LN1/h;->a:La/a;

    .line 721
    .line 722
    invoke-static {v10, v6}, LQ1/f;->e(La/a;LN1/g;)I

    .line 723
    .line 724
    .line 725
    move-result v10

    .line 726
    :goto_d
    invoke-static {v14, v8}, Lkotlin/jvm/internal/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 727
    .line 728
    .line 729
    move-result v8

    .line 730
    if-eqz v8, :cond_16

    .line 731
    .line 732
    move v8, v5

    .line 733
    goto :goto_e

    .line 734
    :cond_16
    iget-object v8, v14, LN1/h;->b:La/a;

    .line 735
    .line 736
    invoke-static {v8, v6}, LQ1/f;->e(La/a;LN1/g;)I

    .line 737
    .line 738
    .line 739
    move-result v8

    .line 740
    :goto_e
    div-int v14, v12, v10

    .line 741
    .line 742
    invoke-static {v14}, Ljava/lang/Integer;->highestOneBit(I)I

    .line 743
    .line 744
    .line 745
    move-result v14

    .line 746
    div-int v15, v5, v8

    .line 747
    .line 748
    invoke-static {v15}, Ljava/lang/Integer;->highestOneBit(I)I

    .line 749
    .line 750
    .line 751
    move-result v15

    .line 752
    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    .line 753
    .line 754
    .line 755
    move-result v1

    .line 756
    if-eqz v1, :cond_18

    .line 757
    .line 758
    if-ne v1, v7, :cond_17

    .line 759
    .line 760
    invoke-static {v14, v15}, Ljava/lang/Math;->max(II)I

    .line 761
    .line 762
    .line 763
    move-result v1

    .line 764
    goto :goto_f

    .line 765
    :cond_17
    new-instance v0, LB8/s;

    .line 766
    .line 767
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 768
    .line 769
    .line 770
    throw v0

    .line 771
    :cond_18
    invoke-static {v14, v15}, Ljava/lang/Math;->min(II)I

    .line 772
    .line 773
    .line 774
    move-result v1

    .line 775
    :goto_f
    if-ge v1, v7, :cond_19

    .line 776
    .line 777
    move v1, v7

    .line 778
    :cond_19
    iput v1, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 779
    .line 780
    int-to-double v14, v12

    .line 781
    move v12, v8

    .line 782
    int-to-double v7, v1

    .line 783
    div-double/2addr v14, v7

    .line 784
    move v1, v4

    .line 785
    int-to-double v4, v5

    .line 786
    div-double/2addr v4, v7

    .line 787
    int-to-double v7, v10

    .line 788
    move-wide/from16 v16, v4

    .line 789
    .line 790
    int-to-double v4, v12

    .line 791
    div-double/2addr v7, v14

    .line 792
    div-double v4, v4, v16

    .line 793
    .line 794
    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    .line 795
    .line 796
    .line 797
    move-result v6

    .line 798
    if-eqz v6, :cond_1b

    .line 799
    .line 800
    const/4 v10, 0x1

    .line 801
    if-ne v6, v10, :cond_1a

    .line 802
    .line 803
    invoke-static {v7, v8, v4, v5}, Ljava/lang/Math;->min(DD)D

    .line 804
    .line 805
    .line 806
    move-result-wide v4

    .line 807
    goto :goto_10

    .line 808
    :cond_1a
    new-instance v0, LB8/s;

    .line 809
    .line 810
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 811
    .line 812
    .line 813
    throw v0

    .line 814
    :cond_1b
    invoke-static {v7, v8, v4, v5}, Ljava/lang/Math;->max(DD)D

    .line 815
    .line 816
    .line 817
    move-result-wide v4

    .line 818
    :goto_10
    iget-boolean v2, v2, LM1/n;->f:Z

    .line 819
    .line 820
    const-wide/high16 v6, 0x3ff0000000000000L    # 1.0

    .line 821
    .line 822
    if-eqz v2, :cond_1c

    .line 823
    .line 824
    cmpl-double v2, v4, v6

    .line 825
    .line 826
    if-lez v2, :cond_1c

    .line 827
    .line 828
    move-wide v4, v6

    .line 829
    :cond_1c
    cmpg-double v2, v4, v6

    .line 830
    .line 831
    if-nez v2, :cond_1d

    .line 832
    .line 833
    const/4 v2, 0x1

    .line 834
    goto :goto_11

    .line 835
    :cond_1d
    const/4 v2, 0x0

    .line 836
    :goto_11
    xor-int/lit8 v8, v2, 0x1

    .line 837
    .line 838
    iput-boolean v8, v0, Landroid/graphics/BitmapFactory$Options;->inScaled:Z

    .line 839
    .line 840
    if-nez v2, :cond_1e

    .line 841
    .line 842
    cmpl-double v2, v4, v6

    .line 843
    .line 844
    const v6, 0x7fffffff

    .line 845
    .line 846
    .line 847
    if-lez v2, :cond_1f

    .line 848
    .line 849
    int-to-double v7, v6

    .line 850
    div-double/2addr v7, v4

    .line 851
    invoke-static {v7, v8}, Lf5/b;->I(D)I

    .line 852
    .line 853
    .line 854
    move-result v2

    .line 855
    iput v2, v0, Landroid/graphics/BitmapFactory$Options;->inDensity:I

    .line 856
    .line 857
    iput v6, v0, Landroid/graphics/BitmapFactory$Options;->inTargetDensity:I

    .line 858
    .line 859
    :cond_1e
    :goto_12
    const/4 v2, 0x0

    .line 860
    const/4 v10, 0x1

    .line 861
    goto :goto_14

    .line 862
    :cond_1f
    iput v6, v0, Landroid/graphics/BitmapFactory$Options;->inDensity:I

    .line 863
    .line 864
    int-to-double v6, v6

    .line 865
    mul-double/2addr v6, v4

    .line 866
    invoke-static {v6, v7}, Lf5/b;->I(D)I

    .line 867
    .line 868
    .line 869
    move-result v2

    .line 870
    iput v2, v0, Landroid/graphics/BitmapFactory$Options;->inTargetDensity:I

    .line 871
    .line 872
    goto :goto_12

    .line 873
    :goto_13
    iput v10, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 874
    .line 875
    const/4 v2, 0x0

    .line 876
    iput-boolean v2, v0, Landroid/graphics/BitmapFactory$Options;->inScaled:Z

    .line 877
    .line 878
    :goto_14
    :try_start_3
    new-instance v4, LY8/f;

    .line 879
    .line 880
    invoke-direct {v4, v11, v10}, LY8/f;-><init>(LY8/i;I)V

    .line 881
    .line 882
    .line 883
    const/4 v5, 0x0

    .line 884
    invoke-static {v4, v5, v0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    .line 885
    .line 886
    .line 887
    move-result-object v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 888
    invoke-virtual {v11}, LY8/C;->close()V

    .line 889
    .line 890
    .line 891
    iget-object v5, v9, LD1/d;->c:Ljava/lang/Object;

    .line 892
    .line 893
    check-cast v5, Ljava/lang/Exception;

    .line 894
    .line 895
    if-nez v5, :cond_2c

    .line 896
    .line 897
    if-eqz v4, :cond_2b

    .line 898
    .line 899
    invoke-virtual {v13}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 900
    .line 901
    .line 902
    move-result-object v5

    .line 903
    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 904
    .line 905
    .line 906
    move-result-object v5

    .line 907
    iget v5, v5, Landroid/util/DisplayMetrics;->densityDpi:I

    .line 908
    .line 909
    invoke-virtual {v4, v5}, Landroid/graphics/Bitmap;->setDensity(I)V

    .line 910
    .line 911
    .line 912
    if-nez v1, :cond_20

    .line 913
    .line 914
    if-lez v3, :cond_28

    .line 915
    .line 916
    :cond_20
    new-instance v5, Landroid/graphics/Matrix;

    .line 917
    .line 918
    invoke-direct {v5}, Landroid/graphics/Matrix;-><init>()V

    .line 919
    .line 920
    .line 921
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    .line 922
    .line 923
    .line 924
    move-result v6

    .line 925
    int-to-float v6, v6

    .line 926
    const/high16 v7, 0x40000000    # 2.0f

    .line 927
    .line 928
    div-float/2addr v6, v7

    .line 929
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getHeight()I

    .line 930
    .line 931
    .line 932
    move-result v8

    .line 933
    int-to-float v8, v8

    .line 934
    div-float/2addr v8, v7

    .line 935
    if-eqz v1, :cond_21

    .line 936
    .line 937
    const/high16 v1, -0x40800000    # -1.0f

    .line 938
    .line 939
    const/high16 v7, 0x3f800000    # 1.0f

    .line 940
    .line 941
    invoke-virtual {v5, v1, v7, v6, v8}, Landroid/graphics/Matrix;->postScale(FFFF)Z

    .line 942
    .line 943
    .line 944
    :cond_21
    if-lez v3, :cond_22

    .line 945
    .line 946
    int-to-float v1, v3

    .line 947
    invoke-virtual {v5, v1, v6, v8}, Landroid/graphics/Matrix;->postRotate(FFF)Z

    .line 948
    .line 949
    .line 950
    :cond_22
    new-instance v1, Landroid/graphics/RectF;

    .line 951
    .line 952
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    .line 953
    .line 954
    .line 955
    move-result v6

    .line 956
    int-to-float v6, v6

    .line 957
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getHeight()I

    .line 958
    .line 959
    .line 960
    move-result v7

    .line 961
    int-to-float v7, v7

    .line 962
    const/4 v8, 0x0

    .line 963
    invoke-direct {v1, v8, v8, v6, v7}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 964
    .line 965
    .line 966
    invoke-virtual {v5, v1}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    .line 967
    .line 968
    .line 969
    iget v6, v1, Landroid/graphics/RectF;->left:F

    .line 970
    .line 971
    cmpg-float v7, v6, v8

    .line 972
    .line 973
    if-nez v7, :cond_23

    .line 974
    .line 975
    iget v7, v1, Landroid/graphics/RectF;->top:F

    .line 976
    .line 977
    cmpg-float v7, v7, v8

    .line 978
    .line 979
    if-nez v7, :cond_23

    .line 980
    .line 981
    :goto_15
    const/16 v8, 0x5a

    .line 982
    .line 983
    goto :goto_16

    .line 984
    :cond_23
    neg-float v6, v6

    .line 985
    iget v1, v1, Landroid/graphics/RectF;->top:F

    .line 986
    .line 987
    neg-float v1, v1

    .line 988
    invoke-virtual {v5, v6, v1}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 989
    .line 990
    .line 991
    goto :goto_15

    .line 992
    :goto_16
    if-eq v3, v8, :cond_26

    .line 993
    .line 994
    const/16 v10, 0x10e

    .line 995
    .line 996
    if-ne v3, v10, :cond_24

    .line 997
    .line 998
    goto :goto_17

    .line 999
    :cond_24
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    .line 1000
    .line 1001
    .line 1002
    move-result v1

    .line 1003
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getHeight()I

    .line 1004
    .line 1005
    .line 1006
    move-result v3

    .line 1007
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    .line 1008
    .line 1009
    .line 1010
    move-result-object v6

    .line 1011
    if-nez v6, :cond_25

    .line 1012
    .line 1013
    sget-object v6, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 1014
    .line 1015
    :cond_25
    invoke-static {v1, v3, v6}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 1016
    .line 1017
    .line 1018
    move-result-object v1

    .line 1019
    goto :goto_18

    .line 1020
    :cond_26
    :goto_17
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getHeight()I

    .line 1021
    .line 1022
    .line 1023
    move-result v1

    .line 1024
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getWidth()I

    .line 1025
    .line 1026
    .line 1027
    move-result v3

    .line 1028
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    .line 1029
    .line 1030
    .line 1031
    move-result-object v6

    .line 1032
    if-nez v6, :cond_27

    .line 1033
    .line 1034
    sget-object v6, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 1035
    .line 1036
    :cond_27
    invoke-static {v1, v3, v6}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 1037
    .line 1038
    .line 1039
    move-result-object v1

    .line 1040
    :goto_18
    new-instance v3, Landroid/graphics/Canvas;

    .line 1041
    .line 1042
    invoke-direct {v3, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 1043
    .line 1044
    .line 1045
    sget-object v6, LD1/m;->a:Landroid/graphics/Paint;

    .line 1046
    .line 1047
    invoke-virtual {v3, v4, v5, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V

    .line 1048
    .line 1049
    .line 1050
    invoke-virtual {v4}, Landroid/graphics/Bitmap;->recycle()V

    .line 1051
    .line 1052
    .line 1053
    move-object v4, v1

    .line 1054
    :cond_28
    new-instance v1, LD1/i;

    .line 1055
    .line 1056
    invoke-virtual {v13}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 1057
    .line 1058
    .line 1059
    move-result-object v3

    .line 1060
    new-instance v5, Landroid/graphics/drawable/BitmapDrawable;

    .line 1061
    .line 1062
    invoke-direct {v5, v3, v4}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    .line 1063
    .line 1064
    .line 1065
    iget v3, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    .line 1066
    .line 1067
    const/4 v10, 0x1

    .line 1068
    if-gt v3, v10, :cond_2a

    .line 1069
    .line 1070
    iget-boolean v0, v0, Landroid/graphics/BitmapFactory$Options;->inScaled:Z

    .line 1071
    .line 1072
    if-eqz v0, :cond_29

    .line 1073
    .line 1074
    goto :goto_19

    .line 1075
    :cond_29
    move v6, v2

    .line 1076
    goto :goto_1a

    .line 1077
    :cond_2a
    :goto_19
    move v6, v10

    .line 1078
    :goto_1a
    invoke-direct {v1, v5, v6}, LD1/i;-><init>(Landroid/graphics/drawable/BitmapDrawable;Z)V

    .line 1079
    .line 1080
    .line 1081
    return-object v1

    .line 1082
    :cond_2b
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1083
    .line 1084
    const-string v1, "BitmapFactory returned a null bitmap. Often this means BitmapFactory could not decode the image data read from the input source (e.g. network, disk, or memory) as it\'s not encoded as a valid image format."

    .line 1085
    .line 1086
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1087
    .line 1088
    .line 1089
    throw v0

    .line 1090
    :cond_2c
    throw v5

    .line 1091
    :catchall_0
    move-exception v0

    .line 1092
    move-object v1, v0

    .line 1093
    :try_start_4
    throw v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 1094
    :catchall_1
    move-exception v0

    .line 1095
    invoke-static {v11, v1}, Lv5/u0;->h(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1096
    .line 1097
    .line 1098
    throw v0

    .line 1099
    :cond_2d
    throw v5

    .line 1100
    :cond_2e
    throw v12

    .line 1101
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    :pswitch_data_1
    .packed-switch 0x3
        :pswitch_14
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_12
        :pswitch_13
    .end packed-switch
.end method
