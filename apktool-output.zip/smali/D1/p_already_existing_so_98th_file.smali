.class public abstract LD1/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# virtual methods
.method public abstract a()La/a;
.end method

.method public abstract f()LY8/i;
.end method
