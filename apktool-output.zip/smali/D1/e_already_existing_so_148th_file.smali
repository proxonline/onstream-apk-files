.class public final LD1/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LD1/l;

.field public final b:LJ8/i;


# direct methods
.method public constructor <init>(ILD1/l;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, LD1/e;->a:LD1/l;

    .line 5
    .line 6
    sget p2, LJ8/j;->a:I

    .line 7
    .line 8
    new-instance p2, LJ8/i;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-direct {p2, p1, v0}, LJ8/i;-><init>(II)V

    .line 12
    .line 13
    .line 14
    iput-object p2, p0, LD1/e;->b:LJ8/i;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    instance-of p1, p1, LD1/e;

    .line 2
    .line 3
    return p1
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    const-class v0, LD1/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method
