.class public final La4/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I
