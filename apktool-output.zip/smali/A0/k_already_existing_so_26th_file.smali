.class public final La0/k;
.super La0/c;
.source "SourceFile"


# virtual methods
.method public final b(Lj8/c;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    instance-of v0, p1, La0/j;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, La0/j;

    .line 7
    .line 8
    iget v1, v0, La0/j;->w:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, La0/j;->w:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, La0/j;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, La0/j;-><init>(La0/k;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, La0/j;->u:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, La0/j;->w:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    sget-object v3, Ld8/l;->a:Ld8/l;

    .line 31
    .line 32
    const/4 v4, 0x0

    .line 33
    if-eqz v1, :cond_2

    .line 34
    .line 35
    if-ne v1, v2, :cond_1

    .line 36
    .line 37
    iget-object p2, v0, La0/j;->t:LY8/B;

    .line 38
    .line 39
    iget-object v1, v0, La0/j;->s:LY8/t;

    .line 40
    .line 41
    iget-object v0, v0, La0/j;->r:LY8/t;

    .line 42
    .line 43
    :try_start_0
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :catchall_0
    move-exception p1

    .line 48
    goto :goto_5

    .line 49
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 50
    .line 51
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 52
    .line 53
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    throw p1

    .line 57
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    iget-object p1, p0, La0/c;->c:La0/a;

    .line 61
    .line 62
    iget-object p1, p1, La0/a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 63
    .line 64
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 65
    .line 66
    .line 67
    move-result p1

    .line 68
    if-nez p1, :cond_a

    .line 69
    .line 70
    iget-object p1, p0, La0/c;->a:LY8/n;

    .line 71
    .line 72
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 73
    .line 74
    .line 75
    const-string v1, "file"

    .line 76
    .line 77
    iget-object v5, p0, La0/c;->b:LY8/y;

    .line 78
    .line 79
    invoke-static {v5, v1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p1, v5}, LY8/n;->l(LY8/y;)LY8/t;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    :try_start_1
    invoke-static {v1}, LY8/t;->a(LY8/t;)LY8/k;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    invoke-static {p1}, LT8/d;->b(LY8/G;)LY8/B;

    .line 91
    .line 92
    .line 93
    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_6

    .line 94
    :try_start_2
    sget-object v5, Lc0/e;->a:Lc0/e;

    .line 95
    .line 96
    iput-object v1, v0, La0/j;->r:LY8/t;

    .line 97
    .line 98
    iput-object v1, v0, La0/j;->s:LY8/t;

    .line 99
    .line 100
    iput-object p1, v0, La0/j;->t:LY8/B;

    .line 101
    .line 102
    iput v2, v0, La0/j;->w:I

    .line 103
    .line 104
    invoke-virtual {v5, p2, p1}, Lc0/e;->c(Ljava/lang/Object;LY8/B;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 105
    .line 106
    .line 107
    sget-object p2, Li8/a;->a:Li8/a;

    .line 108
    .line 109
    if-ne v3, p2, :cond_3

    .line 110
    .line 111
    return-object p2

    .line 112
    :cond_3
    move-object p2, p1

    .line 113
    move-object v0, v1

    .line 114
    :goto_1
    :try_start_3
    invoke-virtual {v1}, LY8/t;->flush()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 115
    .line 116
    .line 117
    if-eqz p2, :cond_4

    .line 118
    .line 119
    :try_start_4
    invoke-interface {p2}, Ljava/io/Closeable;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 120
    .line 121
    .line 122
    goto :goto_2

    .line 123
    :catchall_1
    move-exception p1

    .line 124
    goto :goto_3

    .line 125
    :cond_4
    :goto_2
    move-object p1, v4

    .line 126
    :goto_3
    move-object p2, v3

    .line 127
    :goto_4
    move-object v1, v0

    .line 128
    goto :goto_7

    .line 129
    :catchall_2
    move-exception p2

    .line 130
    move-object v0, p2

    .line 131
    move-object p2, p1

    .line 132
    move-object p1, v0

    .line 133
    move-object v0, v1

    .line 134
    :goto_5
    if-eqz p2, :cond_5

    .line 135
    .line 136
    :try_start_5
    invoke-interface {p2}, Ljava/io/Closeable;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 137
    .line 138
    .line 139
    goto :goto_6

    .line 140
    :catchall_3
    move-exception p2

    .line 141
    :try_start_6
    invoke-static {p1, p2}, Lf5/b;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 142
    .line 143
    .line 144
    goto :goto_6

    .line 145
    :catchall_4
    move-exception p1

    .line 146
    move-object v1, v0

    .line 147
    goto :goto_9

    .line 148
    :cond_5
    :goto_6
    move-object p2, v4

    .line 149
    goto :goto_4

    .line 150
    :goto_7
    if-nez p1, :cond_7

    .line 151
    .line 152
    :try_start_7
    invoke-static {p2}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    .line 153
    .line 154
    .line 155
    if-eqz v1, :cond_6

    .line 156
    .line 157
    :try_start_8
    invoke-interface {v1}, Ljava/io/Closeable;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    .line 158
    .line 159
    .line 160
    goto :goto_8

    .line 161
    :catchall_5
    move-exception v4

    .line 162
    :cond_6
    :goto_8
    move-object p1, v3

    .line 163
    goto :goto_b

    .line 164
    :catchall_6
    move-exception p1

    .line 165
    goto :goto_9

    .line 166
    :cond_7
    :try_start_9
    throw p1
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_6

    .line 167
    :goto_9
    if-eqz v1, :cond_8

    .line 168
    .line 169
    :try_start_a
    invoke-interface {v1}, Ljava/io/Closeable;->close()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_7

    .line 170
    .line 171
    .line 172
    goto :goto_a

    .line 173
    :catchall_7
    move-exception p2

    .line 174
    invoke-static {p1, p2}, Lf5/b;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 175
    .line 176
    .line 177
    :cond_8
    :goto_a
    move-object v6, v4

    .line 178
    move-object v4, p1

    .line 179
    move-object p1, v6

    .line 180
    :goto_b
    if-nez v4, :cond_9

    .line 181
    .line 182
    invoke-static {p1}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 183
    .line 184
    .line 185
    return-object v3

    .line 186
    :cond_9
    throw v4

    .line 187
    :cond_a
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 188
    .line 189
    const-string p2, "This scope has already been closed."

    .line 190
    .line 191
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    throw p1
.end method
