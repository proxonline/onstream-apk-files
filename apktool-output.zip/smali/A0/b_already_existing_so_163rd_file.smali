.class public final La0/b;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public r:Ljava/lang/Object;

.field public s:LY8/C;

.field public synthetic t:Ljava/lang/Object;

.field public final synthetic u:La0/c;

.field public v:I


# direct methods
.method public constructor <init>(La0/c;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, La0/b;->u:La0/c;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, La0/b;->t:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, La0/b;->v:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, La0/b;->v:I

    .line 9
    .line 10
    iget-object p1, p0, La0/b;->u:La0/c;

    .line 11
    .line 12
    invoke-static {p1, p0}, La0/c;->a(La0/c;Lj8/c;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    return-object p1
.end method
