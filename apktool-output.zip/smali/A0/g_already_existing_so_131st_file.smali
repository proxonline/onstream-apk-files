.class public final La0/g;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public r:La0/i;

.field public s:La0/c;

.field public t:Z

.field public synthetic u:Ljava/lang/Object;

.field public final synthetic v:La0/i;

.field public w:I


# direct methods
.method public constructor <init>(La0/i;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, La0/g;->v:La0/i;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, La0/g;->u:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, La0/g;->w:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, La0/g;->w:I

    .line 9
    .line 10
    iget-object p1, p0, La0/g;->v:La0/i;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, La0/i;->a(LY/q;Lj8/c;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method
