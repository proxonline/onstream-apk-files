.class public final La0/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LY/a;


# instance fields
.field public final a:LY8/n;

.field public final b:LY8/y;

.field public final c:LY/W;

.field public final d:La0/e;

.field public final e:La0/a;

.field public final f:LJ8/d;


# direct methods
.method public constructor <init>(LY8/n;LY8/y;LY/W;La0/e;)V
    .locals 1

    .line 1
    const-string v0, "fileSystem"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "path"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "coordinator"

    .line 12
    .line 13
    invoke-static {p3, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, La0/i;->a:LY8/n;

    .line 20
    .line 21
    iput-object p2, p0, La0/i;->b:LY8/y;

    .line 22
    .line 23
    iput-object p3, p0, La0/i;->c:LY/W;

    .line 24
    .line 25
    iput-object p4, p0, La0/i;->d:La0/e;

    .line 26
    .line 27
    new-instance p1, La0/a;

    .line 28
    .line 29
    invoke-direct {p1}, La0/a;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object p1, p0, La0/i;->e:La0/a;

    .line 33
    .line 34
    invoke-static {}, LJ8/e;->a()LJ8/d;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    iput-object p1, p0, La0/i;->f:LJ8/d;

    .line 39
    .line 40
    return-void
.end method


# virtual methods
.method public final a(LY/q;Lj8/c;)Ljava/lang/Object;
    .locals 6

    .line 1
    instance-of v0, p2, La0/g;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, La0/g;

    .line 7
    .line 8
    iget v1, v0, La0/g;->w:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, La0/g;->w:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, La0/g;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, La0/g;-><init>(La0/i;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, La0/g;->u:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, La0/g;->w:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    const/4 v3, 0x0

    .line 31
    if-eqz v1, :cond_2

    .line 32
    .line 33
    if-ne v1, v2, :cond_1

    .line 34
    .line 35
    iget-boolean p1, v0, La0/g;->t:Z

    .line 36
    .line 37
    iget-object v1, v0, La0/g;->s:La0/c;

    .line 38
    .line 39
    iget-object v0, v0, La0/g;->r:La0/i;

    .line 40
    .line 41
    :try_start_0
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 42
    .line 43
    .line 44
    goto :goto_1

    .line 45
    :catchall_0
    move-exception p2

    .line 46
    goto :goto_3

    .line 47
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 48
    .line 49
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 50
    .line 51
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    throw p1

    .line 55
    :cond_2
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    iget-object p2, p0, La0/i;->e:La0/a;

    .line 59
    .line 60
    iget-object p2, p2, La0/a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 61
    .line 62
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 63
    .line 64
    .line 65
    move-result p2

    .line 66
    if-nez p2, :cond_7

    .line 67
    .line 68
    iget-object p2, p0, La0/i;->f:LJ8/d;

    .line 69
    .line 70
    invoke-virtual {p2}, LJ8/d;->g()Z

    .line 71
    .line 72
    .line 73
    move-result p2

    .line 74
    :try_start_1
    new-instance v1, La0/c;

    .line 75
    .line 76
    iget-object v4, p0, La0/i;->a:LY8/n;

    .line 77
    .line 78
    iget-object v5, p0, La0/i;->b:LY8/y;

    .line 79
    .line 80
    invoke-direct {v1, v4, v5}, La0/c;-><init>(LY8/n;LY8/y;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_5

    .line 81
    .line 82
    .line 83
    :try_start_2
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 84
    .line 85
    .line 86
    move-result-object v4

    .line 87
    iput-object p0, v0, La0/g;->r:La0/i;

    .line 88
    .line 89
    iput-object v1, v0, La0/g;->s:La0/c;

    .line 90
    .line 91
    iput-boolean p2, v0, La0/g;->t:Z

    .line 92
    .line 93
    iput v2, v0, La0/g;->w:I

    .line 94
    .line 95
    invoke-virtual {p1, v1, v4, v0}, LY/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    .line 99
    sget-object v0, Li8/a;->a:Li8/a;

    .line 100
    .line 101
    if-ne p1, v0, :cond_3

    .line 102
    .line 103
    return-object v0

    .line 104
    :cond_3
    move v0, p2

    .line 105
    move-object p2, p1

    .line 106
    move p1, v0

    .line 107
    move-object v0, p0

    .line 108
    :goto_1
    :try_start_3
    invoke-interface {v1}, LY/a;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 109
    .line 110
    .line 111
    move-object v1, v3

    .line 112
    goto :goto_2

    .line 113
    :catchall_1
    move-exception v1

    .line 114
    :goto_2
    if-nez v1, :cond_5

    .line 115
    .line 116
    if-eqz p1, :cond_4

    .line 117
    .line 118
    iget-object p1, v0, La0/i;->f:LJ8/d;

    .line 119
    .line 120
    invoke-virtual {p1, v3}, LJ8/d;->a(Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    :cond_4
    return-object p2

    .line 124
    :cond_5
    :try_start_4
    throw v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 125
    :catchall_2
    move-exception p2

    .line 126
    goto :goto_5

    .line 127
    :catchall_3
    move-exception p1

    .line 128
    move v0, p2

    .line 129
    move-object p2, p1

    .line 130
    move p1, v0

    .line 131
    move-object v0, p0

    .line 132
    :goto_3
    :try_start_5
    invoke-interface {v1}, LY/a;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 133
    .line 134
    .line 135
    goto :goto_4

    .line 136
    :catchall_4
    move-exception v1

    .line 137
    :try_start_6
    invoke-static {p2, v1}, Lf5/b;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 138
    .line 139
    .line 140
    :goto_4
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 141
    :catchall_5
    move-exception p1

    .line 142
    move v0, p2

    .line 143
    move-object p2, p1

    .line 144
    move p1, v0

    .line 145
    move-object v0, p0

    .line 146
    :goto_5
    if-eqz p1, :cond_6

    .line 147
    .line 148
    iget-object p1, v0, La0/i;->f:LJ8/d;

    .line 149
    .line 150
    invoke-virtual {p1, v3}, LJ8/d;->a(Ljava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    :cond_6
    throw p2

    .line 154
    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 155
    .line 156
    const-string p2, "StorageConnection has already been disposed."

    .line 157
    .line 158
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 159
    .line 160
    .line 161
    throw p1
.end method

.method public final b(LY/L;Lj8/c;)Ljava/lang/Object;
    .locals 9

    .line 1
    const-string v0, ".tmp"

    .line 2
    .line 3
    instance-of v1, p2, La0/h;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    move-object v1, p2

    .line 8
    check-cast v1, La0/h;

    .line 9
    .line 10
    iget v2, v1, La0/h;->x:I

    .line 11
    .line 12
    const/high16 v3, -0x80000000

    .line 13
    .line 14
    and-int v4, v2, v3

    .line 15
    .line 16
    if-eqz v4, :cond_0

    .line 17
    .line 18
    sub-int/2addr v2, v3

    .line 19
    iput v2, v1, La0/h;->x:I

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    new-instance v1, La0/h;

    .line 23
    .line 24
    invoke-direct {v1, p0, p2}, La0/h;-><init>(La0/i;Lj8/c;)V

    .line 25
    .line 26
    .line 27
    :goto_0
    iget-object p2, v1, La0/h;->v:Ljava/lang/Object;

    .line 28
    .line 29
    iget v2, v1, La0/h;->x:I

    .line 30
    .line 31
    const/4 v3, 0x2

    .line 32
    const/4 v4, 0x1

    .line 33
    const/4 v5, 0x0

    .line 34
    sget-object v6, Li8/a;->a:Li8/a;

    .line 35
    .line 36
    if-eqz v2, :cond_3

    .line 37
    .line 38
    if-eq v2, v4, :cond_2

    .line 39
    .line 40
    if-ne v2, v3, :cond_1

    .line 41
    .line 42
    iget-object p1, v1, La0/h;->u:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast p1, LY/a;

    .line 45
    .line 46
    iget-object v0, v1, La0/h;->t:LY8/y;

    .line 47
    .line 48
    iget-object v2, v1, La0/h;->s:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v2, LJ8/a;

    .line 51
    .line 52
    iget-object v1, v1, La0/h;->r:La0/i;

    .line 53
    .line 54
    :try_start_0
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 55
    .line 56
    .line 57
    goto/16 :goto_3

    .line 58
    .line 59
    :catchall_0
    move-exception p2

    .line 60
    goto/16 :goto_6

    .line 61
    .line 62
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 63
    .line 64
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 65
    .line 66
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    throw p1

    .line 70
    :cond_2
    iget-object p1, v1, La0/h;->u:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast p1, LJ8/a;

    .line 73
    .line 74
    iget-object v2, v1, La0/h;->t:LY8/y;

    .line 75
    .line 76
    iget-object v4, v1, La0/h;->s:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v4, Lr8/p;

    .line 79
    .line 80
    iget-object v7, v1, La0/h;->r:La0/i;

    .line 81
    .line 82
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    move-object p2, p1

    .line 86
    move-object p1, v4

    .line 87
    goto :goto_1

    .line 88
    :cond_3
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    iget-object p2, p0, La0/i;->e:La0/a;

    .line 92
    .line 93
    iget-object p2, p2, La0/a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 94
    .line 95
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 96
    .line 97
    .line 98
    move-result p2

    .line 99
    if-nez p2, :cond_a

    .line 100
    .line 101
    iget-object p2, p0, La0/i;->b:LY8/y;

    .line 102
    .line 103
    invoke-virtual {p2}, LY8/y;->c()LY8/y;

    .line 104
    .line 105
    .line 106
    move-result-object v2

    .line 107
    if-eqz v2, :cond_9

    .line 108
    .line 109
    iget-object p2, p0, La0/i;->a:LY8/n;

    .line 110
    .line 111
    invoke-virtual {p2, v2}, LY8/n;->c(LY8/y;)V

    .line 112
    .line 113
    .line 114
    iput-object p0, v1, La0/h;->r:La0/i;

    .line 115
    .line 116
    iput-object p1, v1, La0/h;->s:Ljava/lang/Object;

    .line 117
    .line 118
    iput-object v2, v1, La0/h;->t:LY8/y;

    .line 119
    .line 120
    iget-object p2, p0, La0/i;->f:LJ8/d;

    .line 121
    .line 122
    iput-object p2, v1, La0/h;->u:Ljava/lang/Object;

    .line 123
    .line 124
    iput v4, v1, La0/h;->x:I

    .line 125
    .line 126
    invoke-virtual {p2, v1}, LJ8/d;->f(Lh8/d;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v4

    .line 130
    if-ne v4, v6, :cond_4

    .line 131
    .line 132
    goto :goto_2

    .line 133
    :cond_4
    move-object v7, p0

    .line 134
    :goto_1
    :try_start_1
    iget-object v4, v7, La0/i;->b:LY8/y;

    .line 135
    .line 136
    iget-object v8, v7, La0/i;->a:LY8/n;

    .line 137
    .line 138
    invoke-virtual {v4}, LY8/y;->b()Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v4

    .line 142
    invoke-virtual {v4, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-virtual {v2, v0}, LY8/y;->e(Ljava/lang/String;)LY8/y;

    .line 147
    .line 148
    .line 149
    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_5

    .line 150
    :try_start_2
    invoke-virtual {v8, v0}, LY8/n;->e(LY8/y;)V

    .line 151
    .line 152
    .line 153
    new-instance v2, La0/k;

    .line 154
    .line 155
    invoke-direct {v2, v8, v0}, La0/c;-><init>(LY8/n;LY8/y;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_5

    .line 156
    .line 157
    .line 158
    :try_start_3
    iput-object v7, v1, La0/h;->r:La0/i;

    .line 159
    .line 160
    iput-object p2, v1, La0/h;->s:Ljava/lang/Object;

    .line 161
    .line 162
    iput-object v0, v1, La0/h;->t:LY8/y;

    .line 163
    .line 164
    iput-object v2, v1, La0/h;->u:Ljava/lang/Object;

    .line 165
    .line 166
    iput v3, v1, La0/h;->x:I

    .line 167
    .line 168
    invoke-interface {p1, v2, v1}, Lr8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 172
    if-ne p1, v6, :cond_5

    .line 173
    .line 174
    :goto_2
    return-object v6

    .line 175
    :cond_5
    move-object p1, v2

    .line 176
    move-object v1, v7

    .line 177
    move-object v2, p2

    .line 178
    :goto_3
    :try_start_4
    invoke-interface {p1}, LY/a;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 179
    .line 180
    .line 181
    move-object p1, v5

    .line 182
    goto :goto_4

    .line 183
    :catchall_1
    move-exception p1

    .line 184
    :goto_4
    if-nez p1, :cond_7

    .line 185
    .line 186
    :try_start_5
    iget-object p1, v1, La0/i;->a:LY8/n;

    .line 187
    .line 188
    invoke-virtual {p1, v0}, LY8/n;->g(LY8/y;)Z

    .line 189
    .line 190
    .line 191
    move-result p1

    .line 192
    if-eqz p1, :cond_6

    .line 193
    .line 194
    iget-object p1, v1, La0/i;->a:LY8/n;

    .line 195
    .line 196
    iget-object p2, v1, La0/i;->b:LY8/y;

    .line 197
    .line 198
    invoke-virtual {p1, v0, p2}, LY8/n;->b(LY8/y;LY8/y;)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 199
    .line 200
    .line 201
    goto :goto_5

    .line 202
    :catchall_2
    move-exception p1

    .line 203
    move-object p2, v2

    .line 204
    goto :goto_9

    .line 205
    :catch_0
    move-exception p1

    .line 206
    move-object v7, v1

    .line 207
    move-object p2, v2

    .line 208
    goto :goto_8

    .line 209
    :cond_6
    :goto_5
    invoke-interface {v2, v5}, LJ8/a;->a(Ljava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 213
    .line 214
    return-object p1

    .line 215
    :cond_7
    :try_start_6
    throw p1
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 216
    :catchall_3
    move-exception p1

    .line 217
    move-object v1, p2

    .line 218
    move-object p2, p1

    .line 219
    move-object p1, v2

    .line 220
    move-object v2, v1

    .line 221
    move-object v1, v7

    .line 222
    :goto_6
    :try_start_7
    invoke-interface {p1}, LY/a;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 223
    .line 224
    .line 225
    goto :goto_7

    .line 226
    :catchall_4
    move-exception p1

    .line 227
    :try_start_8
    invoke-static {p2, p1}, Lf5/b;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 228
    .line 229
    .line 230
    :goto_7
    throw p2
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_0
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 231
    :catchall_5
    move-exception p1

    .line 232
    goto :goto_9

    .line 233
    :catch_1
    move-exception p1

    .line 234
    :goto_8
    :try_start_9
    iget-object v1, v7, La0/i;->a:LY8/n;

    .line 235
    .line 236
    invoke-virtual {v1, v0}, LY8/n;->g(LY8/y;)Z

    .line 237
    .line 238
    .line 239
    move-result v1
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 240
    if-eqz v1, :cond_8

    .line 241
    .line 242
    :try_start_a
    iget-object v1, v7, La0/i;->a:LY8/n;

    .line 243
    .line 244
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 245
    .line 246
    .line 247
    invoke-virtual {v1, v0}, LY8/n;->e(LY8/y;)V
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_2
    .catchall {:try_start_a .. :try_end_a} :catchall_5

    .line 248
    .line 249
    .line 250
    :catch_2
    :cond_8
    :try_start_b
    throw p1
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 251
    :goto_9
    invoke-interface {p2, v5}, LJ8/a;->a(Ljava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    throw p1

    .line 255
    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 256
    .line 257
    const-string p2, "must have a parent path"

    .line 258
    .line 259
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    throw p1

    .line 263
    :cond_a
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 264
    .line 265
    const-string p2, "StorageConnection has already been disposed."

    .line 266
    .line 267
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    throw p1
.end method

.method public final close()V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-object v1, p0, La0/i;->e:La0/a;

    .line 3
    .line 4
    iget-object v1, v1, La0/a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 5
    .line 6
    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, La0/i;->d:La0/e;

    .line 10
    .line 11
    invoke-virtual {v0}, La0/e;->invoke()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    return-void
.end method
