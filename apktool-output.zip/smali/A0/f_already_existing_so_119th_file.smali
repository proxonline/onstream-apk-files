.class public final La0/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e:Ljava/util/LinkedHashSet;

.field public static final f:LX3/z;


# instance fields
.field public final a:LY8/n;

.field public final b:Lr8/p;

.field public final c:LL8/p;

.field public final d:Ld8/j;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ljava/util/LinkedHashSet;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La0/f;->e:Ljava/util/LinkedHashSet;

    .line 7
    .line 8
    new-instance v0, LX3/z;

    .line 9
    .line 10
    const/16 v1, 0x1a

    .line 11
    .line 12
    invoke-direct {v0, v1}, LX3/z;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, La0/f;->f:LX3/z;

    .line 16
    .line 17
    return-void
.end method

.method public constructor <init>(LY8/n;LL8/p;)V
    .locals 1

    .line 1
    const-string v0, "fileSystem"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, La0/f;->a:LY8/n;

    .line 10
    .line 11
    sget-object p1, La0/d;->d:La0/d;

    .line 12
    .line 13
    iput-object p1, p0, La0/f;->b:Lr8/p;

    .line 14
    .line 15
    iput-object p2, p0, La0/f;->c:LL8/p;

    .line 16
    .line 17
    new-instance p1, La0/e;

    .line 18
    .line 19
    const/4 p2, 0x0

    .line 20
    invoke-direct {p1, p0, p2}, La0/e;-><init>(La0/f;I)V

    .line 21
    .line 22
    .line 23
    invoke-static {p1}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    iput-object p1, p0, La0/f;->d:Ld8/j;

    .line 28
    .line 29
    return-void
.end method
