.class public final Lb6/z;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public r:Ljava/lang/Object;

.field public synthetic s:Ljava/lang/Object;

.field public final synthetic t:Lb6/A;

.field public u:I


# direct methods
.method public constructor <init>(Lb6/A;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lb6/z;->t:Lb6/A;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, Lb6/z;->s:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lb6/z;->u:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lb6/z;->u:I

    .line 9
    .line 10
    iget-object p1, p0, Lb6/z;->t:Lb6/A;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Lb6/A;->a(LN5/e;Lj8/c;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method
