.class public final Lb6/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le6/b;


# instance fields
.field public final synthetic a:I

.field public final b:Lc8/a;


# direct methods
.method public synthetic constructor <init>(Lc8/a;I)V
    .locals 0

    .line 1
    iput p2, p0, Lb6/m;->a:I

    iput-object p1, p0, Lb6/m;->b:Lc8/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, Lb6/m;->a:I

    .line 2
    .line 3
    const-string v1, "appContext"

    .line 4
    .line 5
    iget-object v2, p0, Lb6/m;->b:Lc8/a;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-interface {v2}, Lc8/a;->get()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, LY/h;

    .line 15
    .line 16
    new-instance v1, Lf6/n;

    .line 17
    .line 18
    invoke-direct {v1, v0}, Lf6/n;-><init>(LY/h;)V

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_0
    check-cast v2, Le6/c;

    .line 23
    .line 24
    iget-object v0, v2, Le6/c;->a:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v0, Landroid/content/Context;

    .line 27
    .line 28
    new-instance v1, Lf6/a;

    .line 29
    .line 30
    invoke-direct {v1, v0}, Lf6/a;-><init>(Landroid/content/Context;)V

    .line 31
    .line 32
    .line 33
    return-object v1

    .line 34
    :pswitch_1
    check-cast v2, Le6/c;

    .line 35
    .line 36
    iget-object v0, v2, Le6/c;->a:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v0, Landroid/content/Context;

    .line 39
    .line 40
    new-instance v1, Lb6/c0;

    .line 41
    .line 42
    invoke-direct {v1, v0}, Lb6/c0;-><init>(Landroid/content/Context;)V

    .line 43
    .line 44
    .line 45
    return-object v1

    .line 46
    :pswitch_2
    check-cast v2, Le6/c;

    .line 47
    .line 48
    iget-object v0, v2, Le6/c;->a:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v0, Landroid/content/Context;

    .line 51
    .line 52
    invoke-static {v0, v1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    new-instance v1, LA5/g;

    .line 56
    .line 57
    sget-object v2, Lb6/q;->f:Lb6/q;

    .line 58
    .line 59
    invoke-direct {v1, v2}, LA5/g;-><init>(Lr8/l;)V

    .line 60
    .line 61
    .line 62
    new-instance v2, Lb6/r;

    .line 63
    .line 64
    const/4 v3, 0x1

    .line 65
    invoke-direct {v2, v0, v3}, Lb6/r;-><init>(Landroid/content/Context;I)V

    .line 66
    .line 67
    .line 68
    invoke-static {v1, v2}, Lc0/e;->a(LA5/g;Lr8/a;)Lc0/d;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    return-object v0

    .line 73
    :pswitch_3
    check-cast v2, Le6/c;

    .line 74
    .line 75
    iget-object v0, v2, Le6/c;->a:Ljava/lang/Object;

    .line 76
    .line 77
    check-cast v0, Landroid/content/Context;

    .line 78
    .line 79
    invoke-static {v0, v1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    new-instance v1, LA5/g;

    .line 83
    .line 84
    sget-object v2, Lb6/q;->e:Lb6/q;

    .line 85
    .line 86
    invoke-direct {v1, v2}, LA5/g;-><init>(Lr8/l;)V

    .line 87
    .line 88
    .line 89
    new-instance v2, Lb6/r;

    .line 90
    .line 91
    const/4 v3, 0x0

    .line 92
    invoke-direct {v2, v0, v3}, Lb6/r;-><init>(Landroid/content/Context;I)V

    .line 93
    .line 94
    .line 95
    invoke-static {v1, v2}, Lc0/e;->a(LA5/g;Lr8/a;)Lc0/d;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    return-object v0

    .line 100
    :pswitch_4
    check-cast v2, Le6/c;

    .line 101
    .line 102
    iget-object v0, v2, Le6/c;->a:Ljava/lang/Object;

    .line 103
    .line 104
    check-cast v0, Lf5/f;

    .line 105
    .line 106
    const-string v1, "firebaseApp"

    .line 107
    .line 108
    invoke-static {v0, v1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    sget-object v1, Lb6/O;->a:Lb6/O;

    .line 112
    .line 113
    invoke-static {v0}, Lb6/O;->a(Lf5/f;)Lb6/b;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    return-object v0

    .line 118
    :pswitch_5
    check-cast v2, Le6/c;

    .line 119
    .line 120
    iget-object v0, v2, Le6/c;->a:Ljava/lang/Object;

    .line 121
    .line 122
    check-cast v0, LM5/b;

    .line 123
    .line 124
    new-instance v1, Lb6/l;

    .line 125
    .line 126
    invoke-direct {v1, v0}, Lb6/l;-><init>(LM5/b;)V

    .line 127
    .line 128
    .line 129
    return-object v1

    .line 130
    nop

    .line 131
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
