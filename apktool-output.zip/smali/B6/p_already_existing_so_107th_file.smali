.class public interface abstract Lb6/P;
.super Ljava/lang/Object;
.source "SourceFile"
