.class public final Lb6/G;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/q;


# instance fields
.field public r:I

.field public synthetic s:LE8/f;

.field public synthetic t:Ljava/lang/Throwable;


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    check-cast p1, LE8/f;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Throwable;

    .line 4
    .line 5
    check-cast p3, Lh8/d;

    .line 6
    .line 7
    new-instance v0, Lb6/G;

    .line 8
    .line 9
    const/4 v1, 0x3

    .line 10
    invoke-direct {v0, v1, p3}, Lj8/i;-><init>(ILh8/d;)V

    .line 11
    .line 12
    .line 13
    iput-object p1, v0, Lb6/G;->s:LE8/f;

    .line 14
    .line 15
    iput-object p2, v0, Lb6/G;->t:Ljava/lang/Throwable;

    .line 16
    .line 17
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 18
    .line 19
    invoke-virtual {v0, p1}, Lb6/G;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, Lb6/G;->r:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p1

    .line 20
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object p1, p0, Lb6/G;->s:LE8/f;

    .line 24
    .line 25
    iget-object v0, p0, Lb6/G;->t:Ljava/lang/Throwable;

    .line 26
    .line 27
    const-string v2, "FirebaseSessionsRepo"

    .line 28
    .line 29
    const-string v3, "Error reading stored session data."

    .line 30
    .line 31
    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 32
    .line 33
    .line 34
    new-instance v0, Lc0/b;

    .line 35
    .line 36
    invoke-direct {v0, v1}, Lc0/b;-><init>(Z)V

    .line 37
    .line 38
    .line 39
    const/4 v2, 0x0

    .line 40
    iput-object v2, p0, Lb6/G;->s:LE8/f;

    .line 41
    .line 42
    iput v1, p0, Lb6/G;->r:I

    .line 43
    .line 44
    invoke-interface {p1, v0, p0}, LE8/f;->emit(Ljava/lang/Object;Lh8/d;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    sget-object v0, Li8/a;->a:Li8/a;

    .line 49
    .line 50
    if-ne p1, v0, :cond_2

    .line 51
    .line 52
    return-object v0

    .line 53
    :cond_2
    :goto_0
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 54
    .line 55
    return-object p1
.end method
