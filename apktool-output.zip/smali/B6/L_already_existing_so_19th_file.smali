.class public final Lb6/l;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LM5/b;


# direct methods
.method public constructor <init>(LM5/b;)V
    .locals 1

    .line 1
    const-string v0, "transportFactoryProvider"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lb6/l;->a:LM5/b;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final a(Lb6/N;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lb6/l;->a:LM5/b;

    .line 2
    .line 3
    invoke-interface {v0}, LM5/b;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LR1/f;

    .line 8
    .line 9
    new-instance v1, LR1/c;

    .line 10
    .line 11
    const-string v2, "json"

    .line 12
    .line 13
    invoke-direct {v1, v2}, LR1/c;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    new-instance v2, LY4/l;

    .line 17
    .line 18
    const/16 v3, 0x8

    .line 19
    .line 20
    invoke-direct {v2, v3, p0}, LY4/l;-><init>(ILjava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    check-cast v0, LU1/s;

    .line 24
    .line 25
    const-string v3, "FIREBASE_APPQUALITY_SESSION"

    .line 26
    .line 27
    invoke-virtual {v0, v3, v1, v2}, LU1/s;->a(Ljava/lang/String;LR1/c;LR1/e;)LC1/b;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    new-instance v1, LR1/a;

    .line 32
    .line 33
    const/4 v2, 0x0

    .line 34
    sget-object v3, LR1/d;->a:LR1/d;

    .line 35
    .line 36
    invoke-direct {v1, v2, p1, v3, v2}, LR1/a;-><init>(Ljava/lang/Integer;Ljava/lang/Object;LR1/d;LR1/b;)V

    .line 37
    .line 38
    .line 39
    new-instance p1, LC7/q;

    .line 40
    .line 41
    const/16 v2, 0x17

    .line 42
    .line 43
    invoke-direct {p1, v2}, LC7/q;-><init>(I)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0, v1, p1}, LC1/b;->I(LR1/a;LR1/g;)V

    .line 47
    .line 48
    .line 49
    return-void
.end method
