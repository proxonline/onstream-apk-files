.class public final Lb6/y;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le6/b;


# instance fields
.field public final a:Le6/c;

.field public final b:Lc8/a;

.field public final c:Lc8/a;

.field public final d:Lc8/a;


# direct methods
.method public constructor <init>(Le6/c;Lc8/a;Lc8/a;Lc8/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb6/y;->a:Le6/c;

    .line 5
    .line 6
    iput-object p2, p0, Lb6/y;->b:Lc8/a;

    .line 7
    .line 8
    iput-object p3, p0, Lb6/y;->c:Lc8/a;

    .line 9
    .line 10
    iput-object p4, p0, Lb6/y;->d:Lc8/a;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, Lb6/y;->a:Le6/c;

    .line 2
    .line 3
    iget-object v0, v0, Le6/c;->a:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lf5/f;

    .line 6
    .line 7
    iget-object v1, p0, Lb6/y;->b:Lc8/a;

    .line 8
    .line 9
    invoke-interface {v1}, Lc8/a;->get()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lf6/j;

    .line 14
    .line 15
    iget-object v2, p0, Lb6/y;->c:Lc8/a;

    .line 16
    .line 17
    invoke-interface {v2}, Lc8/a;->get()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    check-cast v2, Lh8/i;

    .line 22
    .line 23
    iget-object v3, p0, Lb6/y;->d:Lc8/a;

    .line 24
    .line 25
    invoke-interface {v3}, Lc8/a;->get()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Lb6/c0;

    .line 30
    .line 31
    new-instance v4, Lb6/p;

    .line 32
    .line 33
    invoke-direct {v4, v0, v1, v2, v3}, Lb6/p;-><init>(Lf5/f;Lf6/j;Lh8/i;Lb6/c0;)V

    .line 34
    .line 35
    .line 36
    return-object v4
.end method
