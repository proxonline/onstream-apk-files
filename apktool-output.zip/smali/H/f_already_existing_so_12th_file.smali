.class public abstract LH/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lb1/a;

.field public static final b:LG0/C0;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    const-string v0, "TypefaceCompat static init"

    .line 2
    .line 3
    invoke-static {v0}, Lcom/google/android/gms/internal/measurement/e2;->b(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 7
    .line 8
    const/16 v1, 0x1d

    .line 9
    .line 10
    if-lt v0, v1, :cond_0

    .line 11
    .line 12
    new-instance v0, LH/k;

    .line 13
    .line 14
    invoke-direct {v0}, Lb1/a;-><init>()V

    .line 15
    .line 16
    .line 17
    sput-object v0, LH/f;->a:Lb1/a;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/16 v1, 0x1c

    .line 21
    .line 22
    if-lt v0, v1, :cond_1

    .line 23
    .line 24
    new-instance v0, LH/j;

    .line 25
    .line 26
    invoke-direct {v0}, LH/i;-><init>()V

    .line 27
    .line 28
    .line 29
    sput-object v0, LH/f;->a:Lb1/a;

    .line 30
    .line 31
    goto :goto_0

    .line 32
    :cond_1
    const/16 v1, 0x1a

    .line 33
    .line 34
    if-lt v0, v1, :cond_2

    .line 35
    .line 36
    new-instance v0, LH/i;

    .line 37
    .line 38
    invoke-direct {v0}, LH/i;-><init>()V

    .line 39
    .line 40
    .line 41
    sput-object v0, LH/f;->a:Lb1/a;

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_2
    const/16 v1, 0x18

    .line 45
    .line 46
    if-lt v0, v1, :cond_4

    .line 47
    .line 48
    sget-object v0, LH/h;->l:Ljava/lang/reflect/Method;

    .line 49
    .line 50
    if-nez v0, :cond_3

    .line 51
    .line 52
    const-string v1, "TypefaceCompatApi24Impl"

    .line 53
    .line 54
    const-string v2, "Unable to collect necessary private methods.Fallback to legacy implementation."

    .line 55
    .line 56
    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 57
    .line 58
    .line 59
    :cond_3
    if-eqz v0, :cond_4

    .line 60
    .line 61
    new-instance v0, LH/h;

    .line 62
    .line 63
    invoke-direct {v0}, Lb1/a;-><init>()V

    .line 64
    .line 65
    .line 66
    sput-object v0, LH/f;->a:Lb1/a;

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_4
    new-instance v0, LH/g;

    .line 70
    .line 71
    invoke-direct {v0}, Lb1/a;-><init>()V

    .line 72
    .line 73
    .line 74
    sput-object v0, LH/f;->a:Lb1/a;

    .line 75
    .line 76
    :goto_0
    new-instance v0, LG0/C0;

    .line 77
    .line 78
    const/16 v1, 0x10

    .line 79
    .line 80
    invoke-direct {v0, v1}, LG0/C0;-><init>(I)V

    .line 81
    .line 82
    .line 83
    sput-object v0, LH/f;->b:LG0/C0;

    .line 84
    .line 85
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 86
    .line 87
    .line 88
    return-void
.end method

.method public static a(Landroid/content/Context;LG/d;Landroid/content/res/Resources;ILjava/lang/String;IILG/b;Z)Landroid/graphics/Typeface;
    .locals 16

    .line 1
    move-object/from16 v2, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move/from16 v4, p6

    .line 6
    .line 7
    move-object/from16 v1, p7

    .line 8
    .line 9
    instance-of v3, v0, LG/g;

    .line 10
    .line 11
    const/4 v6, -0x3

    .line 12
    const/4 v7, 0x0

    .line 13
    if-eqz v3, :cond_10

    .line 14
    .line 15
    check-cast v0, LG/g;

    .line 16
    .line 17
    iget-object v3, v0, LG/g;->e:Ljava/lang/String;

    .line 18
    .line 19
    if-eqz v3, :cond_1

    .line 20
    .line 21
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    .line 22
    .line 23
    .line 24
    move-result v5

    .line 25
    if-eqz v5, :cond_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    invoke-static {v3, v7}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    sget-object v5, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    .line 33
    .line 34
    invoke-static {v5, v7}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    if-eqz v3, :cond_1

    .line 39
    .line 40
    invoke-virtual {v3, v5}, Landroid/graphics/Typeface;->equals(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v5

    .line 44
    if-nez v5, :cond_1

    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_1
    :goto_0
    const/4 v3, 0x0

    .line 48
    :goto_1
    if-eqz v3, :cond_3

    .line 49
    .line 50
    if-eqz v1, :cond_2

    .line 51
    .line 52
    new-instance v0, Landroid/os/Handler;

    .line 53
    .line 54
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 59
    .line 60
    .line 61
    new-instance v2, LG/j;

    .line 62
    .line 63
    invoke-direct {v2, v1, v7, v3}, LG/j;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 67
    .line 68
    .line 69
    :cond_2
    return-object v3

    .line 70
    :cond_3
    const/4 v9, 0x1

    .line 71
    if-eqz p8, :cond_5

    .line 72
    .line 73
    iget v3, v0, LG/g;->d:I

    .line 74
    .line 75
    if-nez v3, :cond_4

    .line 76
    .line 77
    :goto_2
    move v3, v9

    .line 78
    goto :goto_3

    .line 79
    :cond_4
    move v3, v7

    .line 80
    goto :goto_3

    .line 81
    :cond_5
    if-nez v1, :cond_4

    .line 82
    .line 83
    goto :goto_2

    .line 84
    :goto_3
    const/4 v5, -0x1

    .line 85
    if-eqz p8, :cond_6

    .line 86
    .line 87
    iget v10, v0, LG/g;->c:I

    .line 88
    .line 89
    goto :goto_4

    .line 90
    :cond_6
    move v10, v5

    .line 91
    :goto_4
    new-instance v11, Landroid/os/Handler;

    .line 92
    .line 93
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 94
    .line 95
    .line 96
    move-result-object v12

    .line 97
    invoke-direct {v11, v12}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 98
    .line 99
    .line 100
    new-instance v12, LV5/c;

    .line 101
    .line 102
    const/16 v13, 0x8

    .line 103
    .line 104
    invoke-direct {v12, v13}, LV5/c;-><init>(I)V

    .line 105
    .line 106
    .line 107
    iput-object v1, v12, LV5/c;->b:Ljava/lang/Object;

    .line 108
    .line 109
    iget-object v1, v0, LG/g;->b:LM/d;

    .line 110
    .line 111
    const/4 v14, 0x2

    .line 112
    if-eqz v1, :cond_8

    .line 113
    .line 114
    iget-object v0, v0, LG/g;->a:LM/d;

    .line 115
    .line 116
    new-array v15, v14, [Ljava/lang/Object;

    .line 117
    .line 118
    aput-object v0, v15, v7

    .line 119
    .line 120
    aput-object v1, v15, v9

    .line 121
    .line 122
    new-instance v0, Ljava/util/ArrayList;

    .line 123
    .line 124
    invoke-direct {v0, v14}, Ljava/util/ArrayList;-><init>(I)V

    .line 125
    .line 126
    .line 127
    move v1, v7

    .line 128
    :goto_5
    if-ge v1, v14, :cond_7

    .line 129
    .line 130
    aget-object v8, v15, v1

    .line 131
    .line 132
    invoke-static {v8}, Lj$/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    add-int/lit8 v1, v1, 0x1

    .line 139
    .line 140
    goto :goto_5

    .line 141
    :cond_7
    invoke-static {v0}, Lj$/util/DesugarCollections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    goto :goto_6

    .line 146
    :cond_8
    iget-object v0, v0, LG/g;->a:LM/d;

    .line 147
    .line 148
    new-array v1, v9, [Ljava/lang/Object;

    .line 149
    .line 150
    aput-object v0, v1, v7

    .line 151
    .line 152
    new-instance v0, Ljava/util/ArrayList;

    .line 153
    .line 154
    invoke-direct {v0, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 155
    .line 156
    .line 157
    aget-object v1, v1, v7

    .line 158
    .line 159
    invoke-static {v1}, Lj$/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    invoke-static {v0}, Lj$/util/DesugarCollections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    :goto_6
    new-instance v8, LK4/g;

    .line 170
    .line 171
    new-instance v1, LG0/e;

    .line 172
    .line 173
    invoke-direct {v1, v11, v14}, LG0/e;-><init>(Landroid/os/Handler;I)V

    .line 174
    .line 175
    .line 176
    const/4 v11, 0x3

    .line 177
    invoke-direct {v8, v12, v11, v1}, LK4/g;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    if-eqz v3, :cond_c

    .line 181
    .line 182
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 183
    .line 184
    .line 185
    move-result v3

    .line 186
    if-gt v3, v9, :cond_b

    .line 187
    .line 188
    invoke-interface {v0, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    move-object v3, v0

    .line 193
    check-cast v3, LM/d;

    .line 194
    .line 195
    sget-object v0, LM/h;->a:LG0/C0;

    .line 196
    .line 197
    new-array v0, v9, [Ljava/lang/Object;

    .line 198
    .line 199
    aput-object v3, v0, v7

    .line 200
    .line 201
    new-instance v11, Ljava/util/ArrayList;

    .line 202
    .line 203
    invoke-direct {v11, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 204
    .line 205
    .line 206
    aget-object v0, v0, v7

    .line 207
    .line 208
    invoke-static {v0}, Lj$/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    invoke-virtual {v11, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 212
    .line 213
    .line 214
    invoke-static {v11}, Lj$/util/DesugarCollections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    invoke-static {v4, v0}, LM/h;->a(ILjava/util/List;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    sget-object v11, LM/h;->a:LG0/C0;

    .line 223
    .line 224
    invoke-virtual {v11, v0}, LG0/C0;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 225
    .line 226
    .line 227
    move-result-object v11

    .line 228
    check-cast v11, Landroid/graphics/Typeface;

    .line 229
    .line 230
    if-eqz v11, :cond_9

    .line 231
    .line 232
    new-instance v0, LO4/o;

    .line 233
    .line 234
    invoke-direct {v0, v12, v13, v11}, LO4/o;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 235
    .line 236
    .line 237
    invoke-virtual {v1, v0}, LG0/e;->execute(Ljava/lang/Runnable;)V

    .line 238
    .line 239
    .line 240
    move-object v8, v11

    .line 241
    goto/16 :goto_b

    .line 242
    .line 243
    :cond_9
    if-ne v10, v5, :cond_a

    .line 244
    .line 245
    new-array v1, v9, [Ljava/lang/Object;

    .line 246
    .line 247
    aput-object v3, v1, v7

    .line 248
    .line 249
    new-instance v3, Ljava/util/ArrayList;

    .line 250
    .line 251
    invoke-direct {v3, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 252
    .line 253
    .line 254
    aget-object v1, v1, v7

    .line 255
    .line 256
    invoke-static {v1}, Lj$/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 260
    .line 261
    .line 262
    invoke-static {v3}, Lj$/util/DesugarCollections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 263
    .line 264
    .line 265
    move-result-object v1

    .line 266
    invoke-static {v0, v2, v1, v4}, LM/h;->b(Ljava/lang/String;Landroid/content/Context;Ljava/util/List;I)LM/g;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    invoke-virtual {v8, v0}, LK4/g;->w(LM/g;)V

    .line 271
    .line 272
    .line 273
    iget-object v8, v0, LM/g;->a:Landroid/graphics/Typeface;

    .line 274
    .line 275
    goto/16 :goto_b

    .line 276
    .line 277
    :cond_a
    move-object v1, v0

    .line 278
    new-instance v0, LM/e;

    .line 279
    .line 280
    const/4 v5, 0x0

    .line 281
    invoke-direct/range {v0 .. v5}, LM/e;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/Object;II)V

    .line 282
    .line 283
    .line 284
    :try_start_0
    sget-object v1, LM/h;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 285
    .line 286
    invoke-interface {v1, v0}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    .line 287
    .line 288
    .line 289
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_3

    .line 290
    int-to-long v1, v10

    .line 291
    :try_start_1
    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 292
    .line 293
    invoke-interface {v0, v1, v2, v3}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    .line 294
    .line 295
    .line 296
    move-result-object v0
    :try_end_1
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_1 .. :try_end_1} :catch_2

    .line 297
    :try_start_2
    check-cast v0, LM/g;

    .line 298
    .line 299
    invoke-virtual {v8, v0}, LK4/g;->w(LM/g;)V

    .line 300
    .line 301
    .line 302
    iget-object v8, v0, LM/g;->a:Landroid/graphics/Typeface;

    .line 303
    .line 304
    goto/16 :goto_b

    .line 305
    .line 306
    :catch_0
    move-exception v0

    .line 307
    goto :goto_7

    .line 308
    :catch_1
    move-exception v0

    .line 309
    goto :goto_8

    .line 310
    :catch_2
    new-instance v0, Ljava/lang/InterruptedException;

    .line 311
    .line 312
    const-string v1, "timeout"

    .line 313
    .line 314
    invoke-direct {v0, v1}, Ljava/lang/InterruptedException;-><init>(Ljava/lang/String;)V

    .line 315
    .line 316
    .line 317
    throw v0

    .line 318
    :goto_7
    throw v0

    .line 319
    :goto_8
    new-instance v1, Ljava/lang/RuntimeException;

    .line 320
    .line 321
    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 322
    .line 323
    .line 324
    throw v1
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_3

    .line 325
    :catch_3
    iget-object v0, v8, LK4/g;->c:Ljava/lang/Object;

    .line 326
    .line 327
    check-cast v0, LG0/e;

    .line 328
    .line 329
    iget-object v1, v8, LK4/g;->b:Ljava/lang/Object;

    .line 330
    .line 331
    check-cast v1, LV5/c;

    .line 332
    .line 333
    new-instance v2, LE4/c;

    .line 334
    .line 335
    invoke-direct {v2, v6, v9, v1}, LE4/c;-><init>(IILjava/lang/Object;)V

    .line 336
    .line 337
    .line 338
    invoke-virtual {v0, v2}, LG0/e;->execute(Ljava/lang/Runnable;)V

    .line 339
    .line 340
    .line 341
    :goto_9
    const/4 v8, 0x0

    .line 342
    goto/16 :goto_b

    .line 343
    .line 344
    :cond_b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 345
    .line 346
    const-string v1, "Fallbacks with blocking fetches are not supported for performance reasons"

    .line 347
    .line 348
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 349
    .line 350
    .line 351
    throw v0

    .line 352
    :cond_c
    invoke-static {v4, v0}, LM/h;->a(ILjava/util/List;)Ljava/lang/String;

    .line 353
    .line 354
    .line 355
    move-result-object v2

    .line 356
    sget-object v3, LM/h;->a:LG0/C0;

    .line 357
    .line 358
    invoke-virtual {v3, v2}, LG0/C0;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 359
    .line 360
    .line 361
    move-result-object v3

    .line 362
    check-cast v3, Landroid/graphics/Typeface;

    .line 363
    .line 364
    if-eqz v3, :cond_d

    .line 365
    .line 366
    new-instance v0, LO4/o;

    .line 367
    .line 368
    invoke-direct {v0, v12, v13, v3}, LO4/o;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 369
    .line 370
    .line 371
    invoke-virtual {v1, v0}, LG0/e;->execute(Ljava/lang/Runnable;)V

    .line 372
    .line 373
    .line 374
    move-object v8, v3

    .line 375
    goto :goto_b

    .line 376
    :cond_d
    new-instance v1, LM/f;

    .line 377
    .line 378
    invoke-direct {v1, v7, v8}, LM/f;-><init>(ILjava/lang/Object;)V

    .line 379
    .line 380
    .line 381
    sget-object v3, LM/h;->c:Ljava/lang/Object;

    .line 382
    .line 383
    monitor-enter v3

    .line 384
    :try_start_3
    sget-object v5, LM/h;->d:Lr/i;

    .line 385
    .line 386
    invoke-virtual {v5, v2}, Lr/i;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 387
    .line 388
    .line 389
    move-result-object v6

    .line 390
    check-cast v6, Ljava/util/ArrayList;

    .line 391
    .line 392
    if-eqz v6, :cond_e

    .line 393
    .line 394
    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 395
    .line 396
    .line 397
    monitor-exit v3

    .line 398
    goto :goto_9

    .line 399
    :catchall_0
    move-exception v0

    .line 400
    goto :goto_c

    .line 401
    :cond_e
    new-instance v6, Ljava/util/ArrayList;

    .line 402
    .line 403
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 404
    .line 405
    .line 406
    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 407
    .line 408
    .line 409
    invoke-virtual {v5, v2, v6}, Lr/i;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 410
    .line 411
    .line 412
    monitor-exit v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 413
    move-object v3, v0

    .line 414
    new-instance v0, LM/e;

    .line 415
    .line 416
    const/4 v5, 0x1

    .line 417
    move-object v1, v2

    .line 418
    move-object/from16 v2, p0

    .line 419
    .line 420
    invoke-direct/range {v0 .. v5}, LM/e;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/Object;II)V

    .line 421
    .line 422
    .line 423
    sget-object v2, LM/h;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 424
    .line 425
    new-instance v3, LM/f;

    .line 426
    .line 427
    invoke-direct {v3, v9, v1}, LM/f;-><init>(ILjava/lang/Object;)V

    .line 428
    .line 429
    .line 430
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 431
    .line 432
    .line 433
    move-result-object v1

    .line 434
    if-nez v1, :cond_f

    .line 435
    .line 436
    new-instance v1, Landroid/os/Handler;

    .line 437
    .line 438
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 439
    .line 440
    .line 441
    move-result-object v5

    .line 442
    invoke-direct {v1, v5}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 443
    .line 444
    .line 445
    goto :goto_a

    .line 446
    :cond_f
    new-instance v1, Landroid/os/Handler;

    .line 447
    .line 448
    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    .line 449
    .line 450
    .line 451
    :goto_a
    new-instance v5, LM/m;

    .line 452
    .line 453
    invoke-direct {v5, v7}, LM/m;-><init>(I)V

    .line 454
    .line 455
    .line 456
    iput-object v0, v5, LM/m;->b:Ljava/lang/Object;

    .line 457
    .line 458
    iput-object v3, v5, LM/m;->c:Ljava/lang/Object;

    .line 459
    .line 460
    iput-object v1, v5, LM/m;->d:Ljava/lang/Object;

    .line 461
    .line 462
    invoke-virtual {v2, v5}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 463
    .line 464
    .line 465
    goto :goto_9

    .line 466
    :goto_b
    move-object/from16 v5, p2

    .line 467
    .line 468
    goto :goto_d

    .line 469
    :goto_c
    :try_start_4
    monitor-exit v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 470
    throw v0

    .line 471
    :cond_10
    sget-object v3, LH/f;->a:Lb1/a;

    .line 472
    .line 473
    check-cast v0, LG/e;

    .line 474
    .line 475
    move-object/from16 v5, p2

    .line 476
    .line 477
    invoke-virtual {v3, v2, v0, v5, v4}, Lb1/a;->l(Landroid/content/Context;LG/e;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;

    .line 478
    .line 479
    .line 480
    move-result-object v8

    .line 481
    if-eqz v1, :cond_12

    .line 482
    .line 483
    if-eqz v8, :cond_11

    .line 484
    .line 485
    new-instance v0, Landroid/os/Handler;

    .line 486
    .line 487
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 488
    .line 489
    .line 490
    move-result-object v2

    .line 491
    invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 492
    .line 493
    .line 494
    new-instance v2, LG/j;

    .line 495
    .line 496
    invoke-direct {v2, v1, v7, v8}, LG/j;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 497
    .line 498
    .line 499
    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 500
    .line 501
    .line 502
    goto :goto_d

    .line 503
    :cond_11
    invoke-virtual {v1, v6}, LG/b;->a(I)V

    .line 504
    .line 505
    .line 506
    :cond_12
    :goto_d
    if-eqz v8, :cond_13

    .line 507
    .line 508
    sget-object v0, LH/f;->b:LG0/C0;

    .line 509
    .line 510
    invoke-static/range {p2 .. p6}, LH/f;->b(Landroid/content/res/Resources;ILjava/lang/String;II)Ljava/lang/String;

    .line 511
    .line 512
    .line 513
    move-result-object v1

    .line 514
    invoke-virtual {v0, v1, v8}, LG0/C0;->l(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 515
    .line 516
    .line 517
    :cond_13
    return-object v8
.end method

.method public static b(Landroid/content/res/Resources;ILjava/lang/String;II)Ljava/lang/String;
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getResourcePackageName(I)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const/16 p0, 0x2d

    .line 14
    .line 15
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0
.end method
