.class public abstract Le8/l;
.super Le8/k;
.source "SourceFile"
