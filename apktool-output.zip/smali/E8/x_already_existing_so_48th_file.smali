.class public final LE8/x;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public r:LE8/s;

.field public synthetic s:Ljava/lang/Object;

.field public t:I

.field public final synthetic u:LE8/s;

.field public v:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LE8/s;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LE8/x;->u:LE8/s;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, LE8/x;->s:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, LE8/x;->t:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, LE8/x;->t:I

    .line 9
    .line 10
    iget-object p1, p0, LE8/x;->u:LE8/s;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, LE8/s;->emit(Ljava/lang/Object;Lh8/d;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method
