.class public interface abstract Ld/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/v;


# virtual methods
.method public abstract b()Ld/z;
.end method
