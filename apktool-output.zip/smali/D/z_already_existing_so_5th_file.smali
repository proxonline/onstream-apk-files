.class public final Ld/z;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Runnable;

.field public final b:Le8/g;

.field public c:Lj0/I;

.field public final d:Landroid/window/OnBackInvokedCallback;

.field public e:Landroid/window/OnBackInvokedDispatcher;

.field public f:Z

.field public g:Z


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ld/z;->a:Ljava/lang/Runnable;

    .line 5
    .line 6
    new-instance p1, Le8/g;

    .line 7
    .line 8
    invoke-direct {p1}, Le8/g;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Ld/z;->b:Le8/g;

    .line 12
    .line 13
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 14
    .line 15
    const/16 v0, 0x21

    .line 16
    .line 17
    if-lt p1, v0, :cond_1

    .line 18
    .line 19
    const/16 v0, 0x22

    .line 20
    .line 21
    if-lt p1, v0, :cond_0

    .line 22
    .line 23
    new-instance p1, Ld/r;

    .line 24
    .line 25
    const/4 v0, 0x0

    .line 26
    invoke-direct {p1, p0, v0}, Ld/r;-><init>(Ld/z;I)V

    .line 27
    .line 28
    .line 29
    new-instance v0, Ld/r;

    .line 30
    .line 31
    const/4 v1, 0x1

    .line 32
    invoke-direct {v0, p0, v1}, Ld/r;-><init>(Ld/z;I)V

    .line 33
    .line 34
    .line 35
    new-instance v1, Ld/s;

    .line 36
    .line 37
    const/4 v2, 0x0

    .line 38
    invoke-direct {v1, p0, v2}, Ld/s;-><init>(Ld/z;I)V

    .line 39
    .line 40
    .line 41
    new-instance v2, Ld/s;

    .line 42
    .line 43
    const/4 v3, 0x1

    .line 44
    invoke-direct {v2, p0, v3}, Ld/s;-><init>(Ld/z;I)V

    .line 45
    .line 46
    .line 47
    sget-object v3, Ld/w;->a:Ld/w;

    .line 48
    .line 49
    invoke-virtual {v3, p1, v0, v1, v2}, Ld/w;->a(Lr8/l;Lr8/l;Lr8/a;Lr8/a;)Landroid/window/OnBackInvokedCallback;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    goto :goto_0

    .line 54
    :cond_0
    new-instance p1, Ld/s;

    .line 55
    .line 56
    const/4 v0, 0x2

    .line 57
    invoke-direct {p1, p0, v0}, Ld/s;-><init>(Ld/z;I)V

    .line 58
    .line 59
    .line 60
    sget-object v0, Ld/u;->a:Ld/u;

    .line 61
    .line 62
    invoke-virtual {v0, p1}, Ld/u;->a(Lr8/a;)Landroid/window/OnBackInvokedCallback;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    :goto_0
    iput-object p1, p0, Ld/z;->d:Landroid/window/OnBackInvokedCallback;

    .line 67
    .line 68
    :cond_1
    return-void
.end method


# virtual methods
.method public final a(Landroidx/lifecycle/v;Lj0/I;)V
    .locals 9

    .line 1
    const-string v0, "owner"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "onBackPressedCallback"

    .line 7
    .line 8
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-interface {p1}, Landroidx/lifecycle/v;->C()LD/o;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {p1}, LD/o;->c0()Landroidx/lifecycle/o;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sget-object v1, Landroidx/lifecycle/o;->a:Landroidx/lifecycle/o;

    .line 20
    .line 21
    if-ne v0, v1, :cond_0

    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    new-instance v0, Ld/x;

    .line 25
    .line 26
    invoke-direct {v0, p0, p1, p2}, Ld/x;-><init>(Ld/z;LD/o;Lj0/I;)V

    .line 27
    .line 28
    .line 29
    iget-object p1, p2, Lj0/I;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 30
    .line 31
    invoke-virtual {p1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    invoke-virtual {p0}, Ld/z;->d()V

    .line 35
    .line 36
    .line 37
    new-instance v1, LH0/v;

    .line 38
    .line 39
    const/4 v7, 0x0

    .line 40
    const/4 v8, 0x1

    .line 41
    const/4 v2, 0x0

    .line 42
    const-class v4, Ld/z;

    .line 43
    .line 44
    const-string v5, "updateEnabledCallbacks"

    .line 45
    .line 46
    const-string v6, "updateEnabledCallbacks()V"

    .line 47
    .line 48
    move-object v3, p0

    .line 49
    invoke-direct/range {v1 .. v8}, LH0/v;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    .line 50
    .line 51
    .line 52
    iput-object v1, p2, Lj0/I;->c:Lkotlin/jvm/internal/g;

    .line 53
    .line 54
    return-void
.end method

.method public final b()V
    .locals 13

    .line 1
    iget-object v0, p0, Ld/z;->c:Lj0/I;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_2

    .line 5
    .line 6
    iget-object v0, p0, Ld/z;->b:Le8/g;

    .line 7
    .line 8
    invoke-virtual {v0}, Le8/g;->e()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    invoke-virtual {v0, v2}, Ljava/util/AbstractList;->listIterator(I)Ljava/util/ListIterator;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    :cond_0
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_1

    .line 21
    .line 22
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    move-object v3, v2

    .line 27
    check-cast v3, Lj0/I;

    .line 28
    .line 29
    iget-boolean v3, v3, Lj0/I;->a:Z

    .line 30
    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    move-object v2, v1

    .line 35
    :goto_0
    move-object v0, v2

    .line 36
    check-cast v0, Lj0/I;

    .line 37
    .line 38
    :cond_2
    iput-object v1, p0, Ld/z;->c:Lj0/I;

    .line 39
    .line 40
    if-eqz v0, :cond_12

    .line 41
    .line 42
    iget v1, v0, Lj0/I;->d:I

    .line 43
    .line 44
    packed-switch v1, :pswitch_data_0

    .line 45
    .line 46
    .line 47
    iget-object v0, v0, Lj0/I;->e:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v0, Lw0/F;

    .line 50
    .line 51
    invoke-virtual {v0}, Lw0/F;->m()Z

    .line 52
    .line 53
    .line 54
    goto/16 :goto_5

    .line 55
    .line 56
    :pswitch_0
    iget-object v0, v0, Lj0/I;->e:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v0, Lj0/U;

    .line 59
    .line 60
    const/4 v1, 0x3

    .line 61
    invoke-static {v1}, Lj0/U;->L(I)Z

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    const-string v3, "FragmentManager"

    .line 66
    .line 67
    if-eqz v2, :cond_3

    .line 68
    .line 69
    new-instance v2, Ljava/lang/StringBuilder;

    .line 70
    .line 71
    const-string v4, "handleOnBackPressed. PREDICTIVE_BACK = true fragment manager "

    .line 72
    .line 73
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 77
    .line 78
    .line 79
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 84
    .line 85
    .line 86
    :cond_3
    iget-object v2, v0, Lj0/U;->j:Lj0/I;

    .line 87
    .line 88
    iget-object v4, v0, Lj0/U;->o:Ljava/util/ArrayList;

    .line 89
    .line 90
    const/4 v5, 0x1

    .line 91
    iput-boolean v5, v0, Lj0/U;->i:Z

    .line 92
    .line 93
    invoke-virtual {v0, v5}, Lj0/U;->z(Z)Z

    .line 94
    .line 95
    .line 96
    const/4 v6, 0x0

    .line 97
    iput-boolean v6, v0, Lj0/U;->i:Z

    .line 98
    .line 99
    iget-object v7, v0, Lj0/U;->h:Lj0/a;

    .line 100
    .line 101
    if-eqz v7, :cond_d

    .line 102
    .line 103
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    .line 104
    .line 105
    .line 106
    move-result v7

    .line 107
    const/4 v8, 0x0

    .line 108
    if-nez v7, :cond_6

    .line 109
    .line 110
    new-instance v7, Ljava/util/LinkedHashSet;

    .line 111
    .line 112
    iget-object v9, v0, Lj0/U;->h:Lj0/a;

    .line 113
    .line 114
    invoke-static {v9}, Lj0/U;->G(Lj0/a;)Ljava/util/HashSet;

    .line 115
    .line 116
    .line 117
    move-result-object v9

    .line 118
    invoke-direct {v7, v9}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 122
    .line 123
    .line 124
    move-result v9

    .line 125
    move v10, v6

    .line 126
    :goto_1
    if-ge v10, v9, :cond_6

    .line 127
    .line 128
    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v11

    .line 132
    add-int/lit8 v10, v10, 0x1

    .line 133
    .line 134
    if-nez v11, :cond_5

    .line 135
    .line 136
    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 137
    .line 138
    .line 139
    move-result-object v11

    .line 140
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 141
    .line 142
    .line 143
    move-result v12

    .line 144
    if-nez v12, :cond_4

    .line 145
    .line 146
    goto :goto_1

    .line 147
    :cond_4
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    check-cast v0, Lj0/y;

    .line 152
    .line 153
    throw v8

    .line 154
    :cond_5
    new-instance v0, Ljava/lang/ClassCastException;

    .line 155
    .line 156
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 157
    .line 158
    .line 159
    throw v0

    .line 160
    :cond_6
    iget-object v4, v0, Lj0/U;->h:Lj0/a;

    .line 161
    .line 162
    iget-object v4, v4, Lj0/a;->a:Ljava/util/ArrayList;

    .line 163
    .line 164
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 165
    .line 166
    .line 167
    move-result v7

    .line 168
    move v9, v6

    .line 169
    :cond_7
    :goto_2
    if-ge v9, v7, :cond_8

    .line 170
    .line 171
    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v10

    .line 175
    add-int/lit8 v9, v9, 0x1

    .line 176
    .line 177
    check-cast v10, Lj0/b0;

    .line 178
    .line 179
    iget-object v10, v10, Lj0/b0;->b:Lj0/y;

    .line 180
    .line 181
    if-eqz v10, :cond_7

    .line 182
    .line 183
    iput-boolean v6, v10, Lj0/y;->m:Z

    .line 184
    .line 185
    goto :goto_2

    .line 186
    :cond_8
    new-instance v4, Ljava/util/ArrayList;

    .line 187
    .line 188
    iget-object v7, v0, Lj0/U;->h:Lj0/a;

    .line 189
    .line 190
    invoke-static {v7}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 191
    .line 192
    .line 193
    move-result-object v7

    .line 194
    invoke-direct {v4, v7}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v0, v4, v6, v5}, Lj0/U;->f(Ljava/util/ArrayList;II)Ljava/util/HashSet;

    .line 198
    .line 199
    .line 200
    move-result-object v4

    .line 201
    invoke-virtual {v4}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 202
    .line 203
    .line 204
    move-result-object v4

    .line 205
    :goto_3
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 206
    .line 207
    .line 208
    move-result v5

    .line 209
    if-eqz v5, :cond_a

    .line 210
    .line 211
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    move-result-object v5

    .line 215
    check-cast v5, Lj0/m;

    .line 216
    .line 217
    iget-object v7, v5, Lj0/m;->c:Ljava/util/ArrayList;

    .line 218
    .line 219
    invoke-static {v1}, Lj0/U;->L(I)Z

    .line 220
    .line 221
    .line 222
    move-result v9

    .line 223
    if-eqz v9, :cond_9

    .line 224
    .line 225
    const-string v9, "SpecialEffectsController: Completing Back "

    .line 226
    .line 227
    invoke-static {v3, v9}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 228
    .line 229
    .line 230
    :cond_9
    invoke-virtual {v5, v7}, Lj0/m;->k(Ljava/util/List;)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v5, v7}, Lj0/m;->c(Ljava/util/List;)V

    .line 234
    .line 235
    .line 236
    goto :goto_3

    .line 237
    :cond_a
    iget-object v4, v0, Lj0/U;->h:Lj0/a;

    .line 238
    .line 239
    iget-object v4, v4, Lj0/a;->a:Ljava/util/ArrayList;

    .line 240
    .line 241
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 242
    .line 243
    .line 244
    move-result v5

    .line 245
    :cond_b
    :goto_4
    if-ge v6, v5, :cond_c

    .line 246
    .line 247
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v7

    .line 251
    add-int/lit8 v6, v6, 0x1

    .line 252
    .line 253
    check-cast v7, Lj0/b0;

    .line 254
    .line 255
    iget-object v7, v7, Lj0/b0;->b:Lj0/y;

    .line 256
    .line 257
    if-eqz v7, :cond_b

    .line 258
    .line 259
    iget-object v9, v7, Lj0/y;->Z:Landroid/view/ViewGroup;

    .line 260
    .line 261
    if-nez v9, :cond_b

    .line 262
    .line 263
    invoke-virtual {v0, v7}, Lj0/U;->g(Lj0/y;)Lj0/a0;

    .line 264
    .line 265
    .line 266
    move-result-object v7

    .line 267
    invoke-virtual {v7}, Lj0/a0;->k()V

    .line 268
    .line 269
    .line 270
    goto :goto_4

    .line 271
    :cond_c
    iput-object v8, v0, Lj0/U;->h:Lj0/a;

    .line 272
    .line 273
    invoke-virtual {v0}, Lj0/U;->i0()V

    .line 274
    .line 275
    .line 276
    invoke-static {v1}, Lj0/U;->L(I)Z

    .line 277
    .line 278
    .line 279
    move-result v1

    .line 280
    if-eqz v1, :cond_11

    .line 281
    .line 282
    const-string v1, "Op is being set to null"

    .line 283
    .line 284
    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 285
    .line 286
    .line 287
    new-instance v1, Ljava/lang/StringBuilder;

    .line 288
    .line 289
    const-string v4, "OnBackPressedCallback enabled="

    .line 290
    .line 291
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 292
    .line 293
    .line 294
    iget-boolean v2, v2, Lj0/I;->a:Z

    .line 295
    .line 296
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 297
    .line 298
    .line 299
    const-string v2, " for  FragmentManager "

    .line 300
    .line 301
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 302
    .line 303
    .line 304
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 305
    .line 306
    .line 307
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    move-result-object v0

    .line 311
    invoke-static {v3, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 312
    .line 313
    .line 314
    goto :goto_5

    .line 315
    :cond_d
    iget-boolean v2, v2, Lj0/I;->a:Z

    .line 316
    .line 317
    if-eqz v2, :cond_f

    .line 318
    .line 319
    invoke-static {v1}, Lj0/U;->L(I)Z

    .line 320
    .line 321
    .line 322
    move-result v1

    .line 323
    if-eqz v1, :cond_e

    .line 324
    .line 325
    const-string v1, "Calling popBackStackImmediate via onBackPressed callback"

    .line 326
    .line 327
    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 328
    .line 329
    .line 330
    :cond_e
    invoke-virtual {v0}, Lj0/U;->T()Z

    .line 331
    .line 332
    .line 333
    goto :goto_5

    .line 334
    :cond_f
    invoke-static {v1}, Lj0/U;->L(I)Z

    .line 335
    .line 336
    .line 337
    move-result v1

    .line 338
    if-eqz v1, :cond_10

    .line 339
    .line 340
    const-string v1, "Calling onBackPressed via onBackPressed callback"

    .line 341
    .line 342
    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 343
    .line 344
    .line 345
    :cond_10
    iget-object v0, v0, Lj0/U;->g:Ld/z;

    .line 346
    .line 347
    invoke-virtual {v0}, Ld/z;->b()V

    .line 348
    .line 349
    .line 350
    :cond_11
    :goto_5
    return-void

    .line 351
    :cond_12
    iget-object v0, p0, Ld/z;->a:Ljava/lang/Runnable;

    .line 352
    .line 353
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 354
    .line 355
    .line 356
    return-void

    .line 357
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final c(Z)V
    .locals 5

    .line 1
    iget-object v0, p0, Ld/z;->e:Landroid/window/OnBackInvokedDispatcher;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    iget-object v1, p0, Ld/z;->d:Landroid/window/OnBackInvokedCallback;

    .line 6
    .line 7
    if-eqz v1, :cond_1

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    sget-object v3, Ld/u;->a:Ld/u;

    .line 11
    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    iget-boolean v4, p0, Ld/z;->f:Z

    .line 15
    .line 16
    if-nez v4, :cond_0

    .line 17
    .line 18
    invoke-virtual {v3, v0, v2, v1}, Ld/u;->b(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    const/4 p1, 0x1

    .line 22
    iput-boolean p1, p0, Ld/z;->f:Z

    .line 23
    .line 24
    return-void

    .line 25
    :cond_0
    if-nez p1, :cond_1

    .line 26
    .line 27
    iget-boolean p1, p0, Ld/z;->f:Z

    .line 28
    .line 29
    if-eqz p1, :cond_1

    .line 30
    .line 31
    invoke-virtual {v3, v0, v1}, Ld/u;->c(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    iput-boolean v2, p0, Ld/z;->f:Z

    .line 35
    .line 36
    :cond_1
    return-void
.end method

.method public final d()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Ld/z;->g:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, Ld/z;->b:Le8/g;

    .line 5
    .line 6
    if-eqz v2, :cond_0

    .line 7
    .line 8
    invoke-virtual {v2}, Le8/g;->isEmpty()Z

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    if-eqz v3, :cond_0

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    invoke-virtual {v2}, Ljava/util/AbstractList;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_2

    .line 24
    .line 25
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Lj0/I;

    .line 30
    .line 31
    iget-boolean v3, v3, Lj0/I;->a:Z

    .line 32
    .line 33
    if-eqz v3, :cond_1

    .line 34
    .line 35
    const/4 v1, 0x1

    .line 36
    :cond_2
    :goto_0
    iput-boolean v1, p0, Ld/z;->g:Z

    .line 37
    .line 38
    if-eq v1, v0, :cond_3

    .line 39
    .line 40
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 41
    .line 42
    const/16 v2, 0x21

    .line 43
    .line 44
    if-lt v0, v2, :cond_3

    .line 45
    .line 46
    invoke-virtual {p0, v1}, Ld/z;->c(Z)V

    .line 47
    .line 48
    .line 49
    :cond_3
    return-void
.end method
