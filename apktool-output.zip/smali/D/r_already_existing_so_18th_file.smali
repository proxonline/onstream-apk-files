.class public final Ld/r;
.super Lkotlin/jvm/internal/i;
.source "SourceFile"

# interfaces
.implements Lr8/l;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ld/z;


# direct methods
.method public synthetic constructor <init>(Ld/z;I)V
    .locals 0

    .line 1
    iput p2, p0, Ld/r;->d:I

    iput-object p1, p0, Ld/r;->e:Ld/z;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/i;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget v0, p0, Ld/r;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ld/b;

    .line 7
    .line 8
    const-string v0, "backEvent"

    .line 9
    .line 10
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Ld/r;->e:Ld/z;

    .line 14
    .line 15
    iget-object v1, v0, Ld/z;->c:Lj0/I;

    .line 16
    .line 17
    if-nez v1, :cond_2

    .line 18
    .line 19
    iget-object v0, v0, Ld/z;->b:Le8/g;

    .line 20
    .line 21
    invoke-virtual {v0}, Le8/g;->e()I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    invoke-virtual {v0, v1}, Ljava/util/AbstractList;->listIterator(I)Ljava/util/ListIterator;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    :cond_0
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    move-object v2, v1

    .line 40
    check-cast v2, Lj0/I;

    .line 41
    .line 42
    iget-boolean v2, v2, Lj0/I;->a:Z

    .line 43
    .line 44
    if-eqz v2, :cond_0

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_1
    const/4 v1, 0x0

    .line 48
    :goto_0
    check-cast v1, Lj0/I;

    .line 49
    .line 50
    :cond_2
    if-eqz v1, :cond_9

    .line 51
    .line 52
    iget v0, v1, Lj0/I;->d:I

    .line 53
    .line 54
    packed-switch v0, :pswitch_data_1

    .line 55
    .line 56
    .line 57
    const-string v0, "backEvent"

    .line 58
    .line 59
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    goto/16 :goto_3

    .line 63
    .line 64
    :pswitch_0
    iget-object v0, v1, Lj0/I;->e:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v0, Lj0/U;

    .line 67
    .line 68
    const/4 v1, 0x2

    .line 69
    invoke-static {v1}, Lj0/U;->L(I)Z

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    const-string v3, "FragmentManager"

    .line 74
    .line 75
    if-eqz v2, :cond_3

    .line 76
    .line 77
    new-instance v2, Ljava/lang/StringBuilder;

    .line 78
    .line 79
    const-string v4, "handleOnBackProgressed. PREDICTIVE_BACK = true fragment manager "

    .line 80
    .line 81
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    invoke-static {v3, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 92
    .line 93
    .line 94
    :cond_3
    iget-object v2, v0, Lj0/U;->h:Lj0/a;

    .line 95
    .line 96
    if-eqz v2, :cond_9

    .line 97
    .line 98
    new-instance v2, Ljava/util/ArrayList;

    .line 99
    .line 100
    iget-object v4, v0, Lj0/U;->h:Lj0/a;

    .line 101
    .line 102
    invoke-static {v4}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 103
    .line 104
    .line 105
    move-result-object v4

    .line 106
    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 107
    .line 108
    .line 109
    const/4 v4, 0x0

    .line 110
    const/4 v5, 0x1

    .line 111
    invoke-virtual {v0, v2, v4, v5}, Lj0/U;->f(Ljava/util/ArrayList;II)Ljava/util/HashSet;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    :cond_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 120
    .line 121
    .line 122
    move-result v5

    .line 123
    if-eqz v5, :cond_7

    .line 124
    .line 125
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v5

    .line 129
    check-cast v5, Lj0/m;

    .line 130
    .line 131
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    .line 133
    .line 134
    const-string v6, "backEvent"

    .line 135
    .line 136
    invoke-static {p1, v6}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    invoke-static {v1}, Lj0/U;->L(I)Z

    .line 140
    .line 141
    .line 142
    move-result v6

    .line 143
    if-eqz v6, :cond_5

    .line 144
    .line 145
    new-instance v6, Ljava/lang/StringBuilder;

    .line 146
    .line 147
    const-string v7, "SpecialEffectsController: Processing Progress "

    .line 148
    .line 149
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    iget v7, p1, Ld/b;->c:F

    .line 153
    .line 154
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v6

    .line 161
    invoke-static {v3, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 162
    .line 163
    .line 164
    :cond_5
    iget-object v6, v5, Lj0/m;->c:Ljava/util/ArrayList;

    .line 165
    .line 166
    new-instance v7, Ljava/util/ArrayList;

    .line 167
    .line 168
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 172
    .line 173
    .line 174
    move-result v8

    .line 175
    move v9, v4

    .line 176
    :goto_1
    if-ge v9, v8, :cond_6

    .line 177
    .line 178
    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v10

    .line 182
    add-int/lit8 v9, v9, 0x1

    .line 183
    .line 184
    check-cast v10, Lj0/f0;

    .line 185
    .line 186
    iget-object v10, v10, Lj0/f0;->k:Ljava/util/ArrayList;

    .line 187
    .line 188
    invoke-static {v10, v7}, Le8/o;->c0(Ljava/lang/Iterable;Ljava/util/AbstractCollection;)V

    .line 189
    .line 190
    .line 191
    goto :goto_1

    .line 192
    :cond_6
    invoke-static {v7}, Le8/i;->G0(Ljava/util/Collection;)Ljava/util/Set;

    .line 193
    .line 194
    .line 195
    move-result-object v6

    .line 196
    invoke-static {v6}, Le8/i;->D0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 197
    .line 198
    .line 199
    move-result-object v6

    .line 200
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 201
    .line 202
    .line 203
    move-result v7

    .line 204
    move v8, v4

    .line 205
    :goto_2
    if-ge v8, v7, :cond_4

    .line 206
    .line 207
    invoke-interface {v6, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object v9

    .line 211
    check-cast v9, Lj0/e0;

    .line 212
    .line 213
    iget-object v10, v5, Lj0/m;->a:Landroid/view/ViewGroup;

    .line 214
    .line 215
    invoke-virtual {v9, p1, v10}, Lj0/e0;->c(Ld/b;Landroid/view/ViewGroup;)V

    .line 216
    .line 217
    .line 218
    add-int/lit8 v8, v8, 0x1

    .line 219
    .line 220
    goto :goto_2

    .line 221
    :cond_7
    iget-object p1, v0, Lj0/U;->o:Ljava/util/ArrayList;

    .line 222
    .line 223
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 228
    .line 229
    .line 230
    move-result v0

    .line 231
    if-nez v0, :cond_8

    .line 232
    .line 233
    goto :goto_3

    .line 234
    :cond_8
    invoke-static {p1}, LB0/a;->i(Ljava/util/Iterator;)Ljava/lang/ClassCastException;

    .line 235
    .line 236
    .line 237
    move-result-object p1

    .line 238
    throw p1

    .line 239
    :cond_9
    :goto_3
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 240
    .line 241
    return-object p1

    .line 242
    :pswitch_1
    check-cast p1, Ld/b;

    .line 243
    .line 244
    const-string v0, "backEvent"

    .line 245
    .line 246
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 247
    .line 248
    .line 249
    iget-object v0, p0, Ld/r;->e:Ld/z;

    .line 250
    .line 251
    iget-object v1, v0, Ld/z;->b:Le8/g;

    .line 252
    .line 253
    invoke-virtual {v1}, Le8/g;->e()I

    .line 254
    .line 255
    .line 256
    move-result v2

    .line 257
    invoke-virtual {v1, v2}, Ljava/util/AbstractList;->listIterator(I)Ljava/util/ListIterator;

    .line 258
    .line 259
    .line 260
    move-result-object v1

    .line 261
    :cond_a
    invoke-interface {v1}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 262
    .line 263
    .line 264
    move-result v2

    .line 265
    if-eqz v2, :cond_b

    .line 266
    .line 267
    invoke-interface {v1}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    move-result-object v2

    .line 271
    move-object v3, v2

    .line 272
    check-cast v3, Lj0/I;

    .line 273
    .line 274
    iget-boolean v3, v3, Lj0/I;->a:Z

    .line 275
    .line 276
    if-eqz v3, :cond_a

    .line 277
    .line 278
    goto :goto_4

    .line 279
    :cond_b
    const/4 v2, 0x0

    .line 280
    :goto_4
    check-cast v2, Lj0/I;

    .line 281
    .line 282
    iput-object v2, v0, Ld/z;->c:Lj0/I;

    .line 283
    .line 284
    if-eqz v2, :cond_d

    .line 285
    .line 286
    iget v0, v2, Lj0/I;->d:I

    .line 287
    .line 288
    packed-switch v0, :pswitch_data_2

    .line 289
    .line 290
    .line 291
    const-string v0, "backEvent"

    .line 292
    .line 293
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 294
    .line 295
    .line 296
    goto :goto_5

    .line 297
    :pswitch_2
    iget-object p1, v2, Lj0/I;->e:Ljava/lang/Object;

    .line 298
    .line 299
    check-cast p1, Lj0/U;

    .line 300
    .line 301
    const/4 v0, 0x3

    .line 302
    invoke-static {v0}, Lj0/U;->L(I)Z

    .line 303
    .line 304
    .line 305
    move-result v0

    .line 306
    if-eqz v0, :cond_c

    .line 307
    .line 308
    new-instance v0, Ljava/lang/StringBuilder;

    .line 309
    .line 310
    const-string v1, "handleOnBackStarted. PREDICTIVE_BACK = true fragment manager "

    .line 311
    .line 312
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 316
    .line 317
    .line 318
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 319
    .line 320
    .line 321
    move-result-object v0

    .line 322
    const-string v1, "FragmentManager"

    .line 323
    .line 324
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 325
    .line 326
    .line 327
    :cond_c
    invoke-virtual {p1}, Lj0/U;->w()V

    .line 328
    .line 329
    .line 330
    new-instance v0, Lj0/S;

    .line 331
    .line 332
    invoke-direct {v0, p1}, Lj0/S;-><init>(Lj0/U;)V

    .line 333
    .line 334
    .line 335
    const/4 v1, 0x0

    .line 336
    invoke-virtual {p1, v0, v1}, Lj0/U;->x(Lj0/P;Z)V

    .line 337
    .line 338
    .line 339
    :cond_d
    :goto_5
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 340
    .line 341
    return-object p1

    .line 342
    nop

    .line 343
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch

    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_2
    .end packed-switch
.end method
