.class public interface abstract Ld/q;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ld/B;Ld/B;Landroid/view/Window;Landroid/view/View;ZZ)V
.end method
