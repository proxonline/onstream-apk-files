.class public interface abstract LE2/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(IIIII)Z
.end method
