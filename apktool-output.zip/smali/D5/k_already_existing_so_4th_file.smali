.class public Ld5/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld5/l;
.implements Lg3/O;
.implements Lt4/r;
.implements Lj2/v;
.implements LJ5/a;
.implements Lm2/c;
.implements Lm2/l;
.implements Lq5/a;
.implements Lb4/g;
.implements Lu5/d;
.implements Lx6/l;


# static fields
.field public static b:Ld5/k;

.field public static final synthetic c:Ld5/k;


# instance fields
.field public final synthetic a:I


# direct methods
.method public static synthetic constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ld5/k;

    .line 2
    .line 3
    const/16 v1, 0xf

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ld5/k;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Ld5/k;->c:Ld5/k;

    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Ld5/k;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static B(Landroid/content/Context;Lw0/A;Landroid/os/Bundle;Landroidx/lifecycle/o;Lw0/v;)Lw0/n;
    .locals 9

    .line 1
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v7

    .line 9
    const-string v0, "randomUUID().toString()"

    .line 10
    .line 11
    invoke-static {v7, v0}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const-string v0, "destination"

    .line 15
    .line 16
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    const-string v0, "hostLifecycleState"

    .line 20
    .line 21
    invoke-static {p3, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    new-instance v1, Lw0/n;

    .line 25
    .line 26
    const/4 v8, 0x0

    .line 27
    move-object v2, p0

    .line 28
    move-object v3, p1

    .line 29
    move-object v4, p2

    .line 30
    move-object v5, p3

    .line 31
    move-object v6, p4

    .line 32
    invoke-direct/range {v1 .. v8}, Lw0/n;-><init>(Landroid/content/Context;Lw0/A;Landroid/os/Bundle;Landroidx/lifecycle/o;Lw0/v;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 33
    .line 34
    .line 35
    return-object v1
.end method

.method public static C(Lg0/b;Landroid/text/Editable;IIZ)Z
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_19

    .line 3
    .line 4
    if-ltz p2, :cond_19

    .line 5
    .line 6
    if-gez p3, :cond_0

    .line 7
    .line 8
    goto/16 :goto_9

    .line 9
    .line 10
    :cond_0
    invoke-static {p1}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    invoke-static {p1}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    const/4 v3, -0x1

    .line 19
    if-eq v1, v3, :cond_19

    .line 20
    .line 21
    if-eq v2, v3, :cond_19

    .line 22
    .line 23
    if-eq v1, v2, :cond_1

    .line 24
    .line 25
    goto/16 :goto_9

    .line 26
    .line 27
    :cond_1
    const/4 v4, 0x1

    .line 28
    if-eqz p4, :cond_16

    .line 29
    .line 30
    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    .line 31
    .line 32
    .line 33
    move-result p2

    .line 34
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 35
    .line 36
    .line 37
    move-result p4

    .line 38
    if-ltz v1, :cond_3

    .line 39
    .line 40
    if-ge p4, v1, :cond_2

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_2
    if-gez p2, :cond_4

    .line 44
    .line 45
    :cond_3
    :goto_0
    move v1, v3

    .line 46
    goto :goto_3

    .line 47
    :cond_4
    :goto_1
    move p4, v0

    .line 48
    :goto_2
    if-nez p2, :cond_5

    .line 49
    .line 50
    goto :goto_3

    .line 51
    :cond_5
    add-int/lit8 v1, v1, -0x1

    .line 52
    .line 53
    if-gez v1, :cond_7

    .line 54
    .line 55
    if-eqz p4, :cond_6

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_6
    move v1, v0

    .line 59
    goto :goto_3

    .line 60
    :cond_7
    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    if-eqz p4, :cond_9

    .line 65
    .line 66
    invoke-static {v5}, Ljava/lang/Character;->isHighSurrogate(C)Z

    .line 67
    .line 68
    .line 69
    move-result p4

    .line 70
    if-nez p4, :cond_8

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_8
    add-int/lit8 p2, p2, -0x1

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_9
    invoke-static {v5}, Ljava/lang/Character;->isSurrogate(C)Z

    .line 77
    .line 78
    .line 79
    move-result v6

    .line 80
    if-nez v6, :cond_a

    .line 81
    .line 82
    add-int/lit8 p2, p2, -0x1

    .line 83
    .line 84
    goto :goto_2

    .line 85
    :cond_a
    invoke-static {v5}, Ljava/lang/Character;->isHighSurrogate(C)Z

    .line 86
    .line 87
    .line 88
    move-result p4

    .line 89
    if-eqz p4, :cond_b

    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_b
    move p4, v4

    .line 93
    goto :goto_2

    .line 94
    :goto_3
    invoke-static {p3, v0}, Ljava/lang/Math;->max(II)I

    .line 95
    .line 96
    .line 97
    move-result p2

    .line 98
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 99
    .line 100
    .line 101
    move-result p3

    .line 102
    if-ltz v2, :cond_d

    .line 103
    .line 104
    if-ge p3, v2, :cond_c

    .line 105
    .line 106
    goto :goto_4

    .line 107
    :cond_c
    if-gez p2, :cond_e

    .line 108
    .line 109
    :cond_d
    :goto_4
    move p3, v3

    .line 110
    goto :goto_7

    .line 111
    :cond_e
    :goto_5
    move p4, v0

    .line 112
    :goto_6
    if-nez p2, :cond_f

    .line 113
    .line 114
    move p3, v2

    .line 115
    goto :goto_7

    .line 116
    :cond_f
    if-lt v2, p3, :cond_10

    .line 117
    .line 118
    if-eqz p4, :cond_15

    .line 119
    .line 120
    goto :goto_4

    .line 121
    :cond_10
    invoke-interface {p1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 122
    .line 123
    .line 124
    move-result v5

    .line 125
    if-eqz p4, :cond_12

    .line 126
    .line 127
    invoke-static {v5}, Ljava/lang/Character;->isLowSurrogate(C)Z

    .line 128
    .line 129
    .line 130
    move-result p4

    .line 131
    if-nez p4, :cond_11

    .line 132
    .line 133
    goto :goto_4

    .line 134
    :cond_11
    add-int/lit8 p2, p2, -0x1

    .line 135
    .line 136
    add-int/lit8 v2, v2, 0x1

    .line 137
    .line 138
    goto :goto_5

    .line 139
    :cond_12
    invoke-static {v5}, Ljava/lang/Character;->isSurrogate(C)Z

    .line 140
    .line 141
    .line 142
    move-result v6

    .line 143
    if-nez v6, :cond_13

    .line 144
    .line 145
    add-int/lit8 p2, p2, -0x1

    .line 146
    .line 147
    add-int/lit8 v2, v2, 0x1

    .line 148
    .line 149
    goto :goto_6

    .line 150
    :cond_13
    invoke-static {v5}, Ljava/lang/Character;->isLowSurrogate(C)Z

    .line 151
    .line 152
    .line 153
    move-result p4

    .line 154
    if-eqz p4, :cond_14

    .line 155
    .line 156
    goto :goto_4

    .line 157
    :cond_14
    add-int/lit8 v2, v2, 0x1

    .line 158
    .line 159
    move p4, v4

    .line 160
    goto :goto_6

    .line 161
    :cond_15
    :goto_7
    if-eq v1, v3, :cond_19

    .line 162
    .line 163
    if-ne p3, v3, :cond_17

    .line 164
    .line 165
    goto :goto_9

    .line 166
    :cond_16
    sub-int/2addr v1, p2

    .line 167
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 168
    .line 169
    .line 170
    move-result v1

    .line 171
    add-int/2addr v2, p3

    .line 172
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 173
    .line 174
    .line 175
    move-result p2

    .line 176
    invoke-static {v2, p2}, Ljava/lang/Math;->min(II)I

    .line 177
    .line 178
    .line 179
    move-result p3

    .line 180
    :cond_17
    const-class p2, Le0/v;

    .line 181
    .line 182
    invoke-interface {p1, v1, p3, p2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    move-result-object p2

    .line 186
    check-cast p2, [Le0/v;

    .line 187
    .line 188
    if-eqz p2, :cond_19

    .line 189
    .line 190
    array-length p4, p2

    .line 191
    if-lez p4, :cond_19

    .line 192
    .line 193
    array-length p4, p2

    .line 194
    move v2, v0

    .line 195
    :goto_8
    if-ge v2, p4, :cond_18

    .line 196
    .line 197
    aget-object v3, p2, v2

    .line 198
    .line 199
    invoke-interface {p1, v3}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 200
    .line 201
    .line 202
    move-result v5

    .line 203
    invoke-interface {p1, v3}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 204
    .line 205
    .line 206
    move-result v3

    .line 207
    invoke-static {v5, v1}, Ljava/lang/Math;->min(II)I

    .line 208
    .line 209
    .line 210
    move-result v1

    .line 211
    invoke-static {v3, p3}, Ljava/lang/Math;->max(II)I

    .line 212
    .line 213
    .line 214
    move-result p3

    .line 215
    add-int/lit8 v2, v2, 0x1

    .line 216
    .line 217
    goto :goto_8

    .line 218
    :cond_18
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 219
    .line 220
    .line 221
    move-result p2

    .line 222
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    .line 223
    .line 224
    .line 225
    move-result p4

    .line 226
    invoke-static {p3, p4}, Ljava/lang/Math;->min(II)I

    .line 227
    .line 228
    .line 229
    move-result p3

    .line 230
    invoke-virtual {p0}, Landroid/view/inputmethod/InputConnectionWrapper;->beginBatchEdit()Z

    .line 231
    .line 232
    .line 233
    invoke-interface {p1, p2, p3}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    .line 234
    .line 235
    .line 236
    invoke-virtual {p0}, Landroid/view/inputmethod/InputConnectionWrapper;->endBatchEdit()Z

    .line 237
    .line 238
    .line 239
    return v4

    .line 240
    :cond_19
    :goto_9
    return v0
.end method

.method public static E(Lcom/maertsno/data/model/response/EpisodeDetailResponse;)Lcom/maertsno/domain/model/EpisodeSource;
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-string v1, "dto"

    .line 4
    .line 5
    invoke-static {v0, v1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->t:Lcom/maertsno/data/model/response/FileSizeResponse;

    .line 9
    .line 10
    iget-object v2, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->u:Lcom/maertsno/data/model/response/StreamingResponse;

    .line 11
    .line 12
    iget-object v3, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->n:Ljava/lang/String;

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    const-string v5, "|"

    .line 17
    .line 18
    filled-new-array {v5}, [Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v5

    .line 22
    invoke-static {v3, v5}, Lz8/e;->p0(Ljava/lang/CharSequence;[Ljava/lang/String;)Ljava/util/List;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    const/4 v3, 0x0

    .line 28
    :goto_0
    if-eqz v3, :cond_1

    .line 29
    .line 30
    invoke-static {v3}, Le8/i;->k0(Ljava/util/List;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v5

    .line 34
    check-cast v5, Ljava/lang/String;

    .line 35
    .line 36
    goto :goto_1

    .line 37
    :cond_1
    const/4 v5, 0x0

    .line 38
    :goto_1
    const-string v6, ""

    .line 39
    .line 40
    if-nez v5, :cond_2

    .line 41
    .line 42
    move-object v12, v6

    .line 43
    goto :goto_2

    .line 44
    :cond_2
    move-object v12, v5

    .line 45
    :goto_2
    const/4 v5, 0x1

    .line 46
    if-eqz v3, :cond_3

    .line 47
    .line 48
    invoke-static {v5, v3}, Le8/i;->m0(ILjava/util/List;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    check-cast v3, Ljava/lang/String;

    .line 53
    .line 54
    goto :goto_3

    .line 55
    :cond_3
    const/4 v3, 0x0

    .line 56
    :goto_3
    if-nez v3, :cond_4

    .line 57
    .line 58
    move-object v3, v6

    .line 59
    :cond_4
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 60
    .line 61
    .line 62
    move-result v13

    .line 63
    iget-wide v8, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->e:J

    .line 64
    .line 65
    iget-object v3, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->k:Ljava/lang/String;

    .line 66
    .line 67
    if-nez v3, :cond_5

    .line 68
    .line 69
    move-object v10, v6

    .line 70
    goto :goto_4

    .line 71
    :cond_5
    move-object v10, v3

    .line 72
    :goto_4
    iget-object v3, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->s:Ljava/lang/String;

    .line 73
    .line 74
    if-eqz v3, :cond_6

    .line 75
    .line 76
    const-string v7, "{width}x{height}"

    .line 77
    .line 78
    const-string v11, "1920x1080"

    .line 79
    .line 80
    invoke-static {v3, v7, v11}, Lz8/m;->Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    goto :goto_5

    .line 85
    :cond_6
    const/4 v3, 0x0

    .line 86
    :goto_5
    if-nez v3, :cond_7

    .line 87
    .line 88
    move-object v11, v6

    .line 89
    goto :goto_6

    .line 90
    :cond_7
    move-object v11, v3

    .line 91
    :goto_6
    iget-object v3, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->w:Ljava/util/List;

    .line 92
    .line 93
    if-eqz v3, :cond_f

    .line 94
    .line 95
    new-instance v7, Ljava/util/ArrayList;

    .line 96
    .line 97
    invoke-static {v3}, Le8/k;->Z(Ljava/lang/Iterable;)I

    .line 98
    .line 99
    .line 100
    move-result v14

    .line 101
    invoke-direct {v7, v14}, Ljava/util/ArrayList;-><init>(I)V

    .line 102
    .line 103
    .line 104
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    :goto_7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 109
    .line 110
    .line 111
    move-result v14

    .line 112
    if-eqz v14, :cond_e

    .line 113
    .line 114
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v14

    .line 118
    check-cast v14, Lcom/maertsno/data/model/response/SubResponse;

    .line 119
    .line 120
    new-instance v15, Ly6/H;

    .line 121
    .line 122
    iget-wide v4, v14, Lcom/maertsno/data/model/response/SubResponse;->c:J

    .line 123
    .line 124
    move-object/from16 v24, v3

    .line 125
    .line 126
    iget-object v3, v14, Lcom/maertsno/data/model/response/SubResponse;->a:Ljava/lang/Long;

    .line 127
    .line 128
    if-eqz v3, :cond_8

    .line 129
    .line 130
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 131
    .line 132
    .line 133
    move-result-wide v16

    .line 134
    :goto_8
    move-wide/from16 v18, v16

    .line 135
    .line 136
    goto :goto_9

    .line 137
    :cond_8
    const-wide/16 v16, 0x0

    .line 138
    .line 139
    goto :goto_8

    .line 140
    :goto_9
    iget-object v3, v14, Lcom/maertsno/data/model/response/SubResponse;->h:Ljava/lang/String;

    .line 141
    .line 142
    if-nez v3, :cond_9

    .line 143
    .line 144
    move-object/from16 v20, v6

    .line 145
    .line 146
    goto :goto_a

    .line 147
    :cond_9
    move-object/from16 v20, v3

    .line 148
    .line 149
    :goto_a
    iget-object v3, v14, Lcom/maertsno/data/model/response/SubResponse;->f:Ljava/lang/String;

    .line 150
    .line 151
    if-nez v3, :cond_a

    .line 152
    .line 153
    move-object/from16 v21, v6

    .line 154
    .line 155
    goto :goto_b

    .line 156
    :cond_a
    move-object/from16 v21, v3

    .line 157
    .line 158
    :goto_b
    iget-object v3, v14, Lcom/maertsno/data/model/response/SubResponse;->g:Ljava/lang/String;

    .line 159
    .line 160
    if-nez v3, :cond_b

    .line 161
    .line 162
    move-object/from16 v22, v6

    .line 163
    .line 164
    goto :goto_c

    .line 165
    :cond_b
    move-object/from16 v22, v3

    .line 166
    .line 167
    :goto_c
    iget-object v3, v14, Lcom/maertsno/data/model/response/SubResponse;->e:Ljava/lang/Integer;

    .line 168
    .line 169
    if-nez v3, :cond_c

    .line 170
    .line 171
    const/4 v14, 0x1

    .line 172
    goto :goto_e

    .line 173
    :cond_c
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 174
    .line 175
    .line 176
    move-result v3

    .line 177
    const/4 v14, 0x1

    .line 178
    if-ne v3, v14, :cond_d

    .line 179
    .line 180
    move/from16 v23, v14

    .line 181
    .line 182
    :goto_d
    move-wide/from16 v16, v4

    .line 183
    .line 184
    goto :goto_f

    .line 185
    :cond_d
    :goto_e
    const/4 v3, 0x0

    .line 186
    move/from16 v23, v3

    .line 187
    .line 188
    goto :goto_d

    .line 189
    :goto_f
    invoke-direct/range {v15 .. v23}, Ly6/H;-><init>(JJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v7, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move v5, v14

    .line 196
    move-object/from16 v3, v24

    .line 197
    .line 198
    goto :goto_7

    .line 199
    :cond_e
    :goto_10
    move v14, v5

    .line 200
    goto :goto_11

    .line 201
    :cond_f
    const/4 v7, 0x0

    .line 202
    goto :goto_10

    .line 203
    :goto_11
    sget-object v3, Le8/q;->a:Le8/q;

    .line 204
    .line 205
    if-nez v7, :cond_10

    .line 206
    .line 207
    move-object v7, v3

    .line 208
    :cond_10
    if-eqz v2, :cond_13

    .line 209
    .line 210
    iget-object v4, v2, Lcom/maertsno/data/model/response/StreamingResponse;->b:Ljava/util/List;

    .line 211
    .line 212
    if-eqz v4, :cond_13

    .line 213
    .line 214
    new-instance v5, Ljava/util/ArrayList;

    .line 215
    .line 216
    invoke-static {v4}, Le8/k;->Z(Ljava/lang/Iterable;)I

    .line 217
    .line 218
    .line 219
    move-result v6

    .line 220
    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 221
    .line 222
    .line 223
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 224
    .line 225
    .line 226
    move-result-object v4

    .line 227
    :goto_12
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 228
    .line 229
    .line 230
    move-result v6

    .line 231
    if-eqz v6, :cond_12

    .line 232
    .line 233
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v6

    .line 237
    check-cast v6, Lcom/maertsno/data/model/response/StreamDataResponse;

    .line 238
    .line 239
    new-instance v15, Ly6/G;

    .line 240
    .line 241
    iget-object v14, v6, Lcom/maertsno/data/model/response/StreamDataResponse;->c:Ljava/lang/String;

    .line 242
    .line 243
    iget-object v6, v6, Lcom/maertsno/data/model/response/StreamDataResponse;->b:Ljava/lang/String;

    .line 244
    .line 245
    move-object/from16 v16, v3

    .line 246
    .line 247
    if-eqz v1, :cond_11

    .line 248
    .line 249
    iget-object v3, v1, Lcom/maertsno/data/model/response/FileSizeResponse;->d:Ljava/lang/Long;

    .line 250
    .line 251
    goto :goto_13

    .line 252
    :cond_11
    const/4 v3, 0x0

    .line 253
    :goto_13
    invoke-direct {v15, v14, v6, v3}, Ly6/G;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 254
    .line 255
    .line 256
    invoke-virtual {v5, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    move-object/from16 v3, v16

    .line 260
    .line 261
    const/4 v14, 0x1

    .line 262
    goto :goto_12

    .line 263
    :cond_12
    move-object/from16 v16, v3

    .line 264
    .line 265
    goto :goto_14

    .line 266
    :cond_13
    move-object/from16 v16, v3

    .line 267
    .line 268
    const/4 v5, 0x0

    .line 269
    :goto_14
    if-nez v5, :cond_14

    .line 270
    .line 271
    move-object/from16 v18, v16

    .line 272
    .line 273
    goto :goto_15

    .line 274
    :cond_14
    move-object/from16 v18, v5

    .line 275
    .line 276
    :goto_15
    if-eqz v2, :cond_16

    .line 277
    .line 278
    iget-object v3, v2, Lcom/maertsno/data/model/response/StreamingResponse;->e:Ljava/util/List;

    .line 279
    .line 280
    if-eqz v3, :cond_16

    .line 281
    .line 282
    new-instance v4, Ljava/util/ArrayList;

    .line 283
    .line 284
    invoke-static {v3}, Le8/k;->Z(Ljava/lang/Iterable;)I

    .line 285
    .line 286
    .line 287
    move-result v5

    .line 288
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 289
    .line 290
    .line 291
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 292
    .line 293
    .line 294
    move-result-object v3

    .line 295
    :goto_16
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 296
    .line 297
    .line 298
    move-result v5

    .line 299
    if-eqz v5, :cond_17

    .line 300
    .line 301
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object v5

    .line 305
    check-cast v5, Lcom/maertsno/data/model/response/StreamDataResponse;

    .line 306
    .line 307
    new-instance v6, Ly6/G;

    .line 308
    .line 309
    iget-object v14, v5, Lcom/maertsno/data/model/response/StreamDataResponse;->c:Ljava/lang/String;

    .line 310
    .line 311
    iget-object v5, v5, Lcom/maertsno/data/model/response/StreamDataResponse;->b:Ljava/lang/String;

    .line 312
    .line 313
    if-eqz v1, :cond_15

    .line 314
    .line 315
    iget-object v15, v1, Lcom/maertsno/data/model/response/FileSizeResponse;->c:Ljava/lang/Long;

    .line 316
    .line 317
    goto :goto_17

    .line 318
    :cond_15
    const/4 v15, 0x0

    .line 319
    :goto_17
    invoke-direct {v6, v14, v5, v15}, Ly6/G;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 320
    .line 321
    .line 322
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 323
    .line 324
    .line 325
    goto :goto_16

    .line 326
    :cond_16
    const/4 v4, 0x0

    .line 327
    :cond_17
    if-nez v4, :cond_18

    .line 328
    .line 329
    move-object/from16 v19, v16

    .line 330
    .line 331
    goto :goto_18

    .line 332
    :cond_18
    move-object/from16 v19, v4

    .line 333
    .line 334
    :goto_18
    if-eqz v2, :cond_1a

    .line 335
    .line 336
    iget-object v3, v2, Lcom/maertsno/data/model/response/StreamingResponse;->c:Ljava/util/List;

    .line 337
    .line 338
    if-eqz v3, :cond_1a

    .line 339
    .line 340
    new-instance v4, Ljava/util/ArrayList;

    .line 341
    .line 342
    invoke-static {v3}, Le8/k;->Z(Ljava/lang/Iterable;)I

    .line 343
    .line 344
    .line 345
    move-result v5

    .line 346
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 347
    .line 348
    .line 349
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 350
    .line 351
    .line 352
    move-result-object v3

    .line 353
    :goto_19
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 354
    .line 355
    .line 356
    move-result v5

    .line 357
    if-eqz v5, :cond_1b

    .line 358
    .line 359
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 360
    .line 361
    .line 362
    move-result-object v5

    .line 363
    check-cast v5, Lcom/maertsno/data/model/response/StreamDataResponse;

    .line 364
    .line 365
    new-instance v6, Ly6/G;

    .line 366
    .line 367
    iget-object v14, v5, Lcom/maertsno/data/model/response/StreamDataResponse;->c:Ljava/lang/String;

    .line 368
    .line 369
    iget-object v5, v5, Lcom/maertsno/data/model/response/StreamDataResponse;->b:Ljava/lang/String;

    .line 370
    .line 371
    if-eqz v1, :cond_19

    .line 372
    .line 373
    iget-object v15, v1, Lcom/maertsno/data/model/response/FileSizeResponse;->a:Ljava/lang/Long;

    .line 374
    .line 375
    goto :goto_1a

    .line 376
    :cond_19
    const/4 v15, 0x0

    .line 377
    :goto_1a
    invoke-direct {v6, v14, v5, v15}, Ly6/G;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 378
    .line 379
    .line 380
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 381
    .line 382
    .line 383
    goto :goto_19

    .line 384
    :cond_1a
    const/4 v4, 0x0

    .line 385
    :cond_1b
    if-nez v4, :cond_1c

    .line 386
    .line 387
    move-object/from16 v20, v16

    .line 388
    .line 389
    goto :goto_1b

    .line 390
    :cond_1c
    move-object/from16 v20, v4

    .line 391
    .line 392
    :goto_1b
    if-eqz v2, :cond_1e

    .line 393
    .line 394
    iget-object v3, v2, Lcom/maertsno/data/model/response/StreamingResponse;->d:Ljava/util/List;

    .line 395
    .line 396
    if-eqz v3, :cond_1e

    .line 397
    .line 398
    new-instance v4, Ljava/util/ArrayList;

    .line 399
    .line 400
    invoke-static {v3}, Le8/k;->Z(Ljava/lang/Iterable;)I

    .line 401
    .line 402
    .line 403
    move-result v5

    .line 404
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 405
    .line 406
    .line 407
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 408
    .line 409
    .line 410
    move-result-object v3

    .line 411
    :goto_1c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 412
    .line 413
    .line 414
    move-result v5

    .line 415
    if-eqz v5, :cond_1f

    .line 416
    .line 417
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    move-result-object v5

    .line 421
    check-cast v5, Lcom/maertsno/data/model/response/StreamDataResponse;

    .line 422
    .line 423
    new-instance v6, Ly6/G;

    .line 424
    .line 425
    iget-object v14, v5, Lcom/maertsno/data/model/response/StreamDataResponse;->c:Ljava/lang/String;

    .line 426
    .line 427
    iget-object v5, v5, Lcom/maertsno/data/model/response/StreamDataResponse;->b:Ljava/lang/String;

    .line 428
    .line 429
    if-eqz v1, :cond_1d

    .line 430
    .line 431
    iget-object v15, v1, Lcom/maertsno/data/model/response/FileSizeResponse;->b:Ljava/lang/Long;

    .line 432
    .line 433
    goto :goto_1d

    .line 434
    :cond_1d
    const/4 v15, 0x0

    .line 435
    :goto_1d
    invoke-direct {v6, v14, v5, v15}, Ly6/G;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 436
    .line 437
    .line 438
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 439
    .line 440
    .line 441
    goto :goto_1c

    .line 442
    :cond_1e
    const/4 v4, 0x0

    .line 443
    :cond_1f
    if-nez v4, :cond_20

    .line 444
    .line 445
    move-object/from16 v21, v16

    .line 446
    .line 447
    goto :goto_1e

    .line 448
    :cond_20
    move-object/from16 v21, v4

    .line 449
    .line 450
    :goto_1e
    if-eqz v2, :cond_23

    .line 451
    .line 452
    iget-object v2, v2, Lcom/maertsno/data/model/response/StreamingResponse;->a:Ljava/util/List;

    .line 453
    .line 454
    if-eqz v2, :cond_23

    .line 455
    .line 456
    new-instance v3, Ljava/util/ArrayList;

    .line 457
    .line 458
    invoke-static {v2}, Le8/k;->Z(Ljava/lang/Iterable;)I

    .line 459
    .line 460
    .line 461
    move-result v4

    .line 462
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 463
    .line 464
    .line 465
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 466
    .line 467
    .line 468
    move-result-object v2

    .line 469
    :goto_1f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 470
    .line 471
    .line 472
    move-result v4

    .line 473
    if-eqz v4, :cond_22

    .line 474
    .line 475
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 476
    .line 477
    .line 478
    move-result-object v4

    .line 479
    check-cast v4, Lcom/maertsno/data/model/response/StreamDataResponse;

    .line 480
    .line 481
    new-instance v5, Ly6/G;

    .line 482
    .line 483
    iget-object v6, v4, Lcom/maertsno/data/model/response/StreamDataResponse;->c:Ljava/lang/String;

    .line 484
    .line 485
    iget-object v4, v4, Lcom/maertsno/data/model/response/StreamDataResponse;->b:Ljava/lang/String;

    .line 486
    .line 487
    if-eqz v1, :cond_21

    .line 488
    .line 489
    iget-object v14, v1, Lcom/maertsno/data/model/response/FileSizeResponse;->d:Ljava/lang/Long;

    .line 490
    .line 491
    goto :goto_20

    .line 492
    :cond_21
    const/4 v14, 0x0

    .line 493
    :goto_20
    invoke-direct {v5, v6, v4, v14}, Ly6/G;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V

    .line 494
    .line 495
    .line 496
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 497
    .line 498
    .line 499
    goto :goto_1f

    .line 500
    :cond_22
    move-object v4, v3

    .line 501
    goto :goto_21

    .line 502
    :cond_23
    const/4 v4, 0x0

    .line 503
    :goto_21
    if-nez v4, :cond_24

    .line 504
    .line 505
    move-object/from16 v22, v16

    .line 506
    .line 507
    goto :goto_22

    .line 508
    :cond_24
    move-object/from16 v22, v4

    .line 509
    .line 510
    :goto_22
    new-instance v15, Ly6/F;

    .line 511
    .line 512
    move-object/from16 v17, v15

    .line 513
    .line 514
    invoke-direct/range {v17 .. v22}, Ly6/F;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    .line 515
    .line 516
    .line 517
    iget-object v1, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->c:Ljava/lang/Integer;

    .line 518
    .line 519
    if-eqz v1, :cond_25

    .line 520
    .line 521
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 522
    .line 523
    .line 524
    move-result v1

    .line 525
    move/from16 v16, v1

    .line 526
    .line 527
    goto :goto_23

    .line 528
    :cond_25
    const/16 v16, 0x1

    .line 529
    .line 530
    :goto_23
    iget-wide v1, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->j:J

    .line 531
    .line 532
    iget-object v3, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->p:Ljava/lang/Long;

    .line 533
    .line 534
    if-eqz v3, :cond_26

    .line 535
    .line 536
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 537
    .line 538
    .line 539
    move-result-wide v3

    .line 540
    :goto_24
    move-wide/from16 v19, v3

    .line 541
    .line 542
    goto :goto_25

    .line 543
    :cond_26
    const-wide/16 v3, -0x1

    .line 544
    .line 545
    goto :goto_24

    .line 546
    :goto_25
    iget-object v0, v0, Lcom/maertsno/data/model/response/EpisodeDetailResponse;->q:Ljava/lang/Integer;

    .line 547
    .line 548
    if-eqz v0, :cond_27

    .line 549
    .line 550
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 551
    .line 552
    .line 553
    move-result v5

    .line 554
    move/from16 v21, v5

    .line 555
    .line 556
    :goto_26
    move-object v14, v7

    .line 557
    goto :goto_27

    .line 558
    :cond_27
    const/16 v21, 0x1

    .line 559
    .line 560
    goto :goto_26

    .line 561
    :goto_27
    new-instance v7, Lcom/maertsno/domain/model/EpisodeSource;

    .line 562
    .line 563
    move-wide/from16 v17, v1

    .line 564
    .line 565
    invoke-direct/range {v7 .. v21}, Lcom/maertsno/domain/model/EpisodeSource;-><init>(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/util/List;Ly6/F;IJJI)V

    .line 566
    .line 567
    .line 568
    return-object v7
.end method

.method public static F(Lcom/maertsno/data/model/response/PlayerConfigsResponse;)Ly6/D;
    .locals 8

    .line 1
    const-string v0, "dto"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/maertsno/data/model/response/PlayerConfigsResponse;->a:Ljava/lang/Integer;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v2, 0x1

    .line 17
    if-ne v0, v2, :cond_1

    .line 18
    .line 19
    goto :goto_1

    .line 20
    :cond_1
    :goto_0
    move v2, v1

    .line 21
    :goto_1
    iget-object v0, p0, Lcom/maertsno/data/model/response/PlayerConfigsResponse;->b:Ljava/lang/Integer;

    .line 22
    .line 23
    if-eqz v0, :cond_2

    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    goto :goto_2

    .line 30
    :cond_2
    move v0, v1

    .line 31
    :goto_2
    invoke-static {}, Lcom/maertsno/domain/type/MediaType;->values()[Lcom/maertsno/domain/type/MediaType;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    array-length v4, v3

    .line 36
    :goto_3
    if-ge v1, v4, :cond_5

    .line 37
    .line 38
    aget-object v5, v3, v1

    .line 39
    .line 40
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 41
    .line 42
    .line 43
    move-result v6

    .line 44
    iget-object v7, p0, Lcom/maertsno/data/model/response/PlayerConfigsResponse;->c:Ljava/lang/Integer;

    .line 45
    .line 46
    if-nez v7, :cond_3

    .line 47
    .line 48
    goto :goto_4

    .line 49
    :cond_3
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 50
    .line 51
    .line 52
    move-result v7

    .line 53
    if-ne v6, v7, :cond_4

    .line 54
    .line 55
    goto :goto_5

    .line 56
    :cond_4
    :goto_4
    add-int/lit8 v1, v1, 0x1

    .line 57
    .line 58
    goto :goto_3

    .line 59
    :cond_5
    const/4 v5, 0x0

    .line 60
    :goto_5
    if-nez v5, :cond_6

    .line 61
    .line 62
    sget-object v5, Lcom/maertsno/domain/type/MediaType;->b:Lcom/maertsno/domain/type/MediaType;

    .line 63
    .line 64
    :cond_6
    new-instance p0, Ly6/D;

    .line 65
    .line 66
    invoke-direct {p0, v2, v0, v5}, Ly6/D;-><init>(ZILcom/maertsno/domain/type/MediaType;)V

    .line 67
    .line 68
    .line 69
    return-object p0
.end method


# virtual methods
.method public A(Ld5/h;)V
    .locals 0

    .line 1
    return-void
.end method

.method public D(Ljava/lang/CharSequence;)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public a()V
    .locals 0

    .line 1
    return-void
.end method

.method public b()V
    .locals 0

    .line 1
    return-void
.end method

.method public c()V
    .locals 0

    .line 1
    return-void
.end method

.method public d([B[B)V
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public e(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Ld5/k;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    if-nez p2, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Ljava/security/Signature;->getInstance(Ljava/lang/String;)Ljava/security/Signature;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-static {p1, p2}, Ljava/security/Signature;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/Signature;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    :goto_0
    return-object p1

    .line 18
    :pswitch_0
    if-nez p2, :cond_1

    .line 19
    .line 20
    invoke-static {p1}, Ljavax/crypto/Mac;->getInstance(Ljava/lang/String;)Ljavax/crypto/Mac;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    goto :goto_1

    .line 25
    :cond_1
    invoke-static {p1, p2}, Ljavax/crypto/Mac;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljavax/crypto/Mac;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    :goto_1
    return-object p1

    .line 30
    :pswitch_1
    if-nez p2, :cond_2

    .line 31
    .line 32
    invoke-static {p1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    goto :goto_2

    .line 37
    :cond_2
    invoke-static {p1, p2}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/KeyFactory;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    :goto_2
    return-object p1

    .line 42
    :pswitch_2
    if-nez p2, :cond_3

    .line 43
    .line 44
    invoke-static {p1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    goto :goto_3

    .line 49
    :cond_3
    invoke-static {p1, p2}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljavax/crypto/Cipher;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    :goto_3
    return-object p1

    .line 54
    nop

    .line 55
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public f(Lm2/r;)V
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public g()V
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public h([B)Ljava/util/Map;
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public i([B)V
    .locals 0

    .line 1
    return-void
.end method

.method public j()Ljava/lang/String;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public k([B[B)[B
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public synthetic l([BLg2/m;)V
    .locals 0

    .line 1
    return-void
.end method

.method public m(J)J
    .locals 0

    .line 1
    return-wide p1
.end method

.method public n()Lj2/u;
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw v0
.end method

.method public o([B)V
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public p([BLjava/util/List;ILjava/util/HashMap;)Lj2/t;
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public q()I
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public r(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 32

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Ld5/k;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    move-object/from16 v1, p1

    .line 9
    .line 10
    check-cast v1, Lcom/maertsno/data/model/response/trakt/TraktResponseItem;

    .line 11
    .line 12
    const-string v2, "dto"

    .line 13
    .line 14
    invoke-static {v1, v2}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v2, v1, Lcom/maertsno/data/model/response/trakt/TraktResponseItem;->c:Lcom/maertsno/data/model/response/trakt/TraktMovie;

    .line 18
    .line 19
    if-eqz v2, :cond_0

    .line 20
    .line 21
    iget-object v2, v2, Lcom/maertsno/data/model/response/trakt/TraktMovie;->a:Lcom/maertsno/data/model/response/trakt/TraktIds;

    .line 22
    .line 23
    if-eqz v2, :cond_0

    .line 24
    .line 25
    iget-object v2, v2, Lcom/maertsno/data/model/response/trakt/TraktIds;->c:Ljava/lang/Long;

    .line 26
    .line 27
    if-eqz v2, :cond_0

    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 30
    .line 31
    .line 32
    move-result-wide v1

    .line 33
    goto :goto_1

    .line 34
    :cond_0
    iget-object v1, v1, Lcom/maertsno/data/model/response/trakt/TraktResponseItem;->f:Lcom/maertsno/data/model/response/trakt/TraktShow;

    .line 35
    .line 36
    if-eqz v1, :cond_1

    .line 37
    .line 38
    iget-object v1, v1, Lcom/maertsno/data/model/response/trakt/TraktShow;->a:Lcom/maertsno/data/model/response/trakt/TraktIds;

    .line 39
    .line 40
    if-eqz v1, :cond_1

    .line 41
    .line 42
    iget-object v1, v1, Lcom/maertsno/data/model/response/trakt/TraktIds;->c:Ljava/lang/Long;

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_1
    const/4 v1, 0x0

    .line 46
    :goto_0
    if-eqz v1, :cond_2

    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 49
    .line 50
    .line 51
    move-result-wide v1

    .line 52
    goto :goto_1

    .line 53
    :cond_2
    const-wide/16 v1, -0x1

    .line 54
    .line 55
    :goto_1
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    return-object v1

    .line 60
    :pswitch_0
    move-object/from16 v1, p1

    .line 61
    .line 62
    check-cast v1, Lcom/maertsno/data/model/response/TopicReportResponse;

    .line 63
    .line 64
    const-string v2, "dto"

    .line 65
    .line 66
    invoke-static {v1, v2}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    new-instance v2, Ly6/J;

    .line 70
    .line 71
    iget-wide v3, v1, Lcom/maertsno/data/model/response/TopicReportResponse;->a:J

    .line 72
    .line 73
    iget-object v1, v1, Lcom/maertsno/data/model/response/TopicReportResponse;->b:Ljava/lang/String;

    .line 74
    .line 75
    if-nez v1, :cond_3

    .line 76
    .line 77
    const-string v1, ""

    .line 78
    .line 79
    :cond_3
    invoke-direct {v2, v3, v4, v1}, Ly6/J;-><init>(JLjava/lang/String;)V

    .line 80
    .line 81
    .line 82
    return-object v2

    .line 83
    :pswitch_1
    move-object/from16 v1, p1

    .line 84
    .line 85
    check-cast v1, Lcom/maertsno/data/model/response/PlayerConfigsResponse;

    .line 86
    .line 87
    invoke-static {v1}, Ld5/k;->F(Lcom/maertsno/data/model/response/PlayerConfigsResponse;)Ly6/D;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    return-object v1

    .line 92
    :pswitch_2
    move-object/from16 v1, p1

    .line 93
    .line 94
    check-cast v1, Lp6/b;

    .line 95
    .line 96
    const-string v2, "dto"

    .line 97
    .line 98
    invoke-static {v1, v2}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    iget-wide v4, v1, Lp6/b;->a:J

    .line 102
    .line 103
    iget-object v6, v1, Lp6/b;->e:Ljava/lang/String;

    .line 104
    .line 105
    iget-object v7, v1, Lp6/b;->d:Ljava/lang/String;

    .line 106
    .line 107
    iget-object v8, v1, Lp6/b;->b:Ljava/lang/String;

    .line 108
    .line 109
    iget-object v10, v1, Lp6/b;->f:Ljava/lang/String;

    .line 110
    .line 111
    invoke-static {}, Lcom/maertsno/domain/type/MediaType;->values()[Lcom/maertsno/domain/type/MediaType;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    array-length v3, v2

    .line 116
    const/4 v9, 0x0

    .line 117
    :goto_2
    if-ge v9, v3, :cond_5

    .line 118
    .line 119
    aget-object v11, v2, v9

    .line 120
    .line 121
    iget-object v12, v11, Lcom/maertsno/domain/type/MediaType;->a:Ljava/lang/String;

    .line 122
    .line 123
    iget-object v13, v1, Lp6/b;->c:Ljava/lang/String;

    .line 124
    .line 125
    invoke-virtual {v12, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v12

    .line 129
    if-eqz v12, :cond_4

    .line 130
    .line 131
    goto :goto_3

    .line 132
    :cond_4
    add-int/lit8 v9, v9, 0x1

    .line 133
    .line 134
    goto :goto_2

    .line 135
    :cond_5
    const/4 v11, 0x0

    .line 136
    :goto_3
    if-nez v11, :cond_6

    .line 137
    .line 138
    sget-object v11, Lcom/maertsno/domain/type/MediaType;->c:Lcom/maertsno/domain/type/MediaType;

    .line 139
    .line 140
    :cond_6
    move-object v12, v11

    .line 141
    new-instance v3, Lcom/maertsno/domain/model/Movie;

    .line 142
    .line 143
    const/4 v9, 0x0

    .line 144
    const/4 v11, 0x0

    .line 145
    const/4 v13, 0x0

    .line 146
    const/4 v14, 0x0

    .line 147
    const/4 v15, 0x0

    .line 148
    const/16 v16, 0x0

    .line 149
    .line 150
    const/16 v17, 0x0

    .line 151
    .line 152
    const/16 v18, 0x0

    .line 153
    .line 154
    const-wide/16 v19, 0x0

    .line 155
    .line 156
    const-wide/16 v21, 0x0

    .line 157
    .line 158
    const/16 v23, 0x0

    .line 159
    .line 160
    const/16 v24, 0x0

    .line 161
    .line 162
    const/16 v25, 0x0

    .line 163
    .line 164
    const/16 v26, 0x0

    .line 165
    .line 166
    const/16 v27, 0x0

    .line 167
    .line 168
    const/16 v28, 0x0

    .line 169
    .line 170
    const-wide/16 v29, 0x0

    .line 171
    .line 172
    const v31, 0xffff50

    .line 173
    .line 174
    .line 175
    invoke-direct/range {v3 .. v31}, Lcom/maertsno/domain/model/Movie;-><init>(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILcom/maertsno/domain/type/MediaType;Ljava/lang/String;Ljava/lang/String;ZIILjava/lang/String;DJLjava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;ZLy6/L;JI)V

    .line 176
    .line 177
    .line 178
    iget-object v2, v1, Lp6/b;->g:Ljava/lang/String;

    .line 179
    .line 180
    const-string v4, "<set-?>"

    .line 181
    .line 182
    invoke-static {v2, v4}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    iput-object v2, v3, Lcom/maertsno/domain/model/Movie;->y:Ljava/lang/String;

    .line 186
    .line 187
    iget-object v1, v1, Lp6/b;->h:Ljava/lang/String;

    .line 188
    .line 189
    invoke-static {v1, v4}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    iput-object v1, v3, Lcom/maertsno/domain/model/Movie;->z:Ljava/lang/String;

    .line 193
    .line 194
    return-object v3

    .line 195
    :pswitch_3
    move-object/from16 v1, p1

    .line 196
    .line 197
    check-cast v1, Lcom/maertsno/data/model/response/EpisodeDetailResponse;

    .line 198
    .line 199
    invoke-static {v1}, Ld5/k;->E(Lcom/maertsno/data/model/response/EpisodeDetailResponse;)Lcom/maertsno/domain/model/EpisodeSource;

    .line 200
    .line 201
    .line 202
    move-result-object v1

    .line 203
    return-object v1

    .line 204
    :pswitch_4
    move-object/from16 v1, p1

    .line 205
    .line 206
    check-cast v1, Lcom/maertsno/data/model/response/AvatarResponse;

    .line 207
    .line 208
    const-string v2, "dto"

    .line 209
    .line 210
    invoke-static {v1, v2}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 211
    .line 212
    .line 213
    new-instance v2, Ly6/a;

    .line 214
    .line 215
    iget-wide v3, v1, Lcom/maertsno/data/model/response/AvatarResponse;->a:J

    .line 216
    .line 217
    iget-object v1, v1, Lcom/maertsno/data/model/response/AvatarResponse;->b:Ljava/lang/String;

    .line 218
    .line 219
    if-nez v1, :cond_7

    .line 220
    .line 221
    const-string v1, ""

    .line 222
    .line 223
    :cond_7
    const-string v5, "{width}x{height}"

    .line 224
    .line 225
    const-string v6, "200x300"

    .line 226
    .line 227
    invoke-static {v1, v5, v6}, Lz8/m;->Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 228
    .line 229
    .line 230
    move-result-object v1

    .line 231
    invoke-direct {v2, v3, v4, v1}, Ly6/a;-><init>(JLjava/lang/String;)V

    .line 232
    .line 233
    .line 234
    return-object v2

    .line 235
    :pswitch_data_0
    .packed-switch 0x18
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public s(Landroid/view/View;LP/x0;Lg3/G;)LP/x0;
    .locals 5

    .line 1
    iget v0, p3, Lg3/G;->d:I

    .line 2
    .line 3
    invoke-virtual {p2}, LP/x0;->a()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    add-int/2addr v1, v0

    .line 8
    iput v1, p3, Lg3/G;->d:I

    .line 9
    .line 10
    sget-object v0, LP/S;->a:Ljava/util/WeakHashMap;

    .line 11
    .line 12
    invoke-virtual {p1}, Landroid/view/View;->getLayoutDirection()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x1

    .line 17
    if-ne v0, v1, :cond_0

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    const/4 v1, 0x0

    .line 21
    :goto_0
    invoke-virtual {p2}, LP/x0;->b()I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    invoke-virtual {p2}, LP/x0;->c()I

    .line 26
    .line 27
    .line 28
    move-result v2

    .line 29
    iget v3, p3, Lg3/G;->a:I

    .line 30
    .line 31
    if-eqz v1, :cond_1

    .line 32
    .line 33
    move v4, v2

    .line 34
    goto :goto_1

    .line 35
    :cond_1
    move v4, v0

    .line 36
    :goto_1
    add-int/2addr v3, v4

    .line 37
    iput v3, p3, Lg3/G;->a:I

    .line 38
    .line 39
    iget v4, p3, Lg3/G;->c:I

    .line 40
    .line 41
    if-eqz v1, :cond_2

    .line 42
    .line 43
    goto :goto_2

    .line 44
    :cond_2
    move v0, v2

    .line 45
    :goto_2
    add-int/2addr v4, v0

    .line 46
    iput v4, p3, Lg3/G;->c:I

    .line 47
    .line 48
    iget v0, p3, Lg3/G;->b:I

    .line 49
    .line 50
    iget p3, p3, Lg3/G;->d:I

    .line 51
    .line 52
    invoke-virtual {p1, v3, v0, v4, p3}, Landroid/view/View;->setPaddingRelative(IIII)V

    .line 53
    .line 54
    .line 55
    return-object p2
.end method

.method public t(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    const-string p1, "FirebaseCrashlytics"

    .line 2
    .line 3
    const/4 v0, 0x3

    .line 4
    invoke-static {p1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    const-string v0, "Skipping logging Crashlytics event to Firebase, no Firebase Analytics"

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    invoke-static {p1, v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 14
    .line 15
    .line 16
    :cond_0
    return-void
.end method

.method public u(JLjava/lang/String;)V
    .locals 0

    .line 1
    return-void
.end method

.method public v([B)Li2/a;
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public w(II)Lm2/u;
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public x(Ljava/lang/Object;)Lb4/q;
    .locals 0

    .line 1
    check-cast p1, Ljava/lang/Void;

    .line 2
    .line 3
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 4
    .line 5
    invoke-static {p1}, Lf5/b;->s(Ljava/lang/Object;)Lb4/q;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public y(Ljava/lang/String;[B)Z
    .locals 0

    .line 1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    invoke-direct {p1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 4
    .line 5
    .line 6
    throw p1
.end method

.method public z()[B
    .locals 2

    .line 1
    new-instance v0, Landroid/media/MediaDrmException;

    .line 2
    .line 3
    const-string v1, "Attempting to open a session using a dummy ExoMediaDrm."

    .line 4
    .line 5
    invoke-direct {v0, v1}, Landroid/media/MediaDrmException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw v0
.end method
