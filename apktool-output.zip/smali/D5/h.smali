.class public final Ld5/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld5/i;
.implements LQ/o;
.implements Lo/c0;
.implements LO1/b;
.implements Landroidx/lifecycle/E;
.implements Lf/b;
.implements LL8/e;
.implements Lo/x0;
.implements Ln4/h;
.implements Ln/i;
.implements Lb4/e;
.implements Lq5/b;
.implements Lr5/a;
.implements Ls3/a;
.implements Lb4/g;
.implements Lt4/h;
.implements Lz3/l;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 2

    iput p1, p0, Ld5/h;->a:I

    packed-switch p1, :pswitch_data_0

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Lp3/n;

    .line 5
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 6
    iput-object v0, p1, Lp3/n;->a:Ljava/lang/String;

    iput-object v0, p1, Lp3/n;->b:Ljava/lang/String;

    const/4 v1, 0x0

    iput v1, p1, Lp3/n;->c:I

    iput-object v0, p1, Lp3/n;->d:Ljava/lang/String;

    iput v1, p1, Lp3/n;->f:I

    iput-object v0, p1, Lp3/n;->g:Ljava/util/ArrayList;

    iput v1, p1, Lp3/n;->h:I

    const-wide/16 v0, -0x1

    iput-wide v0, p1, Lp3/n;->i:J

    .line 7
    iput-object p1, p0, Ld5/h;->b:Ljava/lang/Object;

    return-void

    .line 8
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void

    :pswitch_data_0
    .packed-switch 0x13
        :pswitch_0
    .end packed-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Ld5/h;->a:I

    iput-object p2, p0, Ld5/h;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup;)V
    .locals 1

    const/16 v0, 0x18

    iput v0, p0, Ld5/h;->a:I

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    invoke-virtual {p1}, Landroid/view/View;->getOverlay()Landroid/view/ViewOverlay;

    move-result-object p1

    iput-object p1, p0, Ld5/h;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/widget/EditText;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Ld5/h;->a:I

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    new-instance v0, Lcom/google/android/material/appbar/h;

    invoke-direct {v0, p1}, Lcom/google/android/material/appbar/h;-><init>(Landroid/widget/EditText;)V

    iput-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 2
    iput p2, p0, Ld5/h;->a:I

    iput-object p1, p0, Ld5/h;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lu3/p;[Ljava/lang/String;)V
    .locals 0

    const/16 p1, 0x19

    iput p1, p0, Ld5/h;->a:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Ld5/h;->b:Ljava/lang/Object;

    return-void
.end method

.method public static s(LT0/c;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)"

    .line 7
    .line 8
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)"

    .line 12
    .line 13
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))"

    .line 17
    .line 18
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)"

    .line 22
    .line 23
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)"

    .line 27
    .line 28
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 32
    .line 33
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)"

    .line 37
    .line 38
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    const-string v0, "CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 42
    .line 43
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 47
    .line 48
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    const-string v0, "CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)"

    .line 52
    .line 53
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    const-string v0, "CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )"

    .line 57
    .line 58
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    const-string v0, "CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))"

    .line 62
    .line 63
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    const-string v0, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)"

    .line 67
    .line 68
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    const-string v0, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \'c103703e120ae8cc73c9248622f3cd1e\')"

    .line 72
    .line 73
    invoke-virtual {p0, v0}, LT0/c;->o(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    return-void
.end method

.method private final u(Ln/k;)V
    .locals 0

    .line 1
    return-void
.end method

.method public static v(LT0/c;)LB3/M;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Ljava/util/HashMap;

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 7
    .line 8
    .line 9
    new-instance v3, LN0/l;

    .line 10
    .line 11
    const/4 v8, 0x0

    .line 12
    const/4 v5, 0x1

    .line 13
    const/4 v4, 0x1

    .line 14
    const-string v6, "work_spec_id"

    .line 15
    .line 16
    const-string v7, "TEXT"

    .line 17
    .line 18
    const/4 v9, 0x1

    .line 19
    invoke-direct/range {v3 .. v9}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 20
    .line 21
    .line 22
    const-string v4, "work_spec_id"

    .line 23
    .line 24
    invoke-virtual {v1, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    new-instance v5, LN0/l;

    .line 28
    .line 29
    const/4 v10, 0x0

    .line 30
    const/4 v7, 0x1

    .line 31
    const/4 v6, 0x2

    .line 32
    const-string v8, "prerequisite_id"

    .line 33
    .line 34
    const-string v9, "TEXT"

    .line 35
    .line 36
    const/4 v11, 0x1

    .line 37
    invoke-direct/range {v5 .. v11}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 38
    .line 39
    .line 40
    const-string v3, "prerequisite_id"

    .line 41
    .line 42
    invoke-virtual {v1, v3, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    new-instance v5, Ljava/util/HashSet;

    .line 46
    .line 47
    invoke-direct {v5, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 48
    .line 49
    .line 50
    new-instance v6, LN0/m;

    .line 51
    .line 52
    filled-new-array {v4}, [Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v7

    .line 56
    invoke-static {v7}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 57
    .line 58
    .line 59
    move-result-object v10

    .line 60
    const-string v12, "id"

    .line 61
    .line 62
    filled-new-array {v12}, [Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    invoke-static {v7}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 67
    .line 68
    .line 69
    move-result-object v11

    .line 70
    const-string v7, "WorkSpec"

    .line 71
    .line 72
    const-string v8, "CASCADE"

    .line 73
    .line 74
    const-string v9, "CASCADE"

    .line 75
    .line 76
    invoke-direct/range {v6 .. v11}, LN0/m;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v5, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    new-instance v13, LN0/m;

    .line 83
    .line 84
    filled-new-array {v3}, [Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v6

    .line 88
    invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 89
    .line 90
    .line 91
    move-result-object v17

    .line 92
    filled-new-array {v12}, [Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object v6

    .line 96
    invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 97
    .line 98
    .line 99
    move-result-object v18

    .line 100
    const-string v14, "WorkSpec"

    .line 101
    .line 102
    const-string v15, "CASCADE"

    .line 103
    .line 104
    const-string v16, "CASCADE"

    .line 105
    .line 106
    invoke-direct/range {v13 .. v18}, LN0/m;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v5, v13}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    new-instance v6, Ljava/util/HashSet;

    .line 113
    .line 114
    invoke-direct {v6, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 115
    .line 116
    .line 117
    new-instance v7, LN0/n;

    .line 118
    .line 119
    filled-new-array {v4}, [Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v8

    .line 123
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 124
    .line 125
    .line 126
    move-result-object v8

    .line 127
    const-string v9, "index_Dependency_work_spec_id"

    .line 128
    .line 129
    invoke-direct {v7, v9, v8}, LN0/n;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v6, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    new-instance v7, LN0/n;

    .line 136
    .line 137
    filled-new-array {v3}, [Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v3

    .line 141
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    const-string v8, "index_Dependency_prerequisite_id"

    .line 146
    .line 147
    invoke-direct {v7, v8, v3}, LN0/n;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v6, v7}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    new-instance v3, LN0/o;

    .line 154
    .line 155
    const-string v7, "Dependency"

    .line 156
    .line 157
    invoke-direct {v3, v7, v1, v5, v6}, LN0/o;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 158
    .line 159
    .line 160
    invoke-static {v0, v7}, LN0/o;->a(LT0/c;Ljava/lang/String;)LN0/o;

    .line 161
    .line 162
    .line 163
    move-result-object v1

    .line 164
    invoke-virtual {v3, v1}, LN0/o;->equals(Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result v5

    .line 168
    const-string v6, "\n Found:\n"

    .line 169
    .line 170
    const/4 v7, 0x0

    .line 171
    if-nez v5, :cond_0

    .line 172
    .line 173
    new-instance v0, LB3/M;

    .line 174
    .line 175
    new-instance v2, Ljava/lang/StringBuilder;

    .line 176
    .line 177
    const-string v4, "Dependency(androidx.work.impl.model.Dependency).\n Expected:\n"

    .line 178
    .line 179
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 189
    .line 190
    .line 191
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    const/4 v2, 0x2

    .line 196
    invoke-direct {v0, v7, v1, v2}, LB3/M;-><init>(ZLjava/lang/String;I)V

    .line 197
    .line 198
    .line 199
    return-object v0

    .line 200
    :cond_0
    new-instance v1, Ljava/util/HashMap;

    .line 201
    .line 202
    const/16 v3, 0x19

    .line 203
    .line 204
    invoke-direct {v1, v3}, Ljava/util/HashMap;-><init>(I)V

    .line 205
    .line 206
    .line 207
    new-instance v13, LN0/l;

    .line 208
    .line 209
    const/16 v18, 0x0

    .line 210
    .line 211
    const/4 v15, 0x1

    .line 212
    const/16 v19, 0x1

    .line 213
    .line 214
    const/4 v14, 0x1

    .line 215
    const-string v16, "id"

    .line 216
    .line 217
    const-string v17, "TEXT"

    .line 218
    .line 219
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 220
    .line 221
    .line 222
    invoke-virtual {v1, v12, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    new-instance v14, LN0/l;

    .line 226
    .line 227
    const/16 v19, 0x0

    .line 228
    .line 229
    const/16 v16, 0x1

    .line 230
    .line 231
    const/16 v20, 0x1

    .line 232
    .line 233
    const/4 v15, 0x0

    .line 234
    const-string v17, "state"

    .line 235
    .line 236
    const-string v18, "INTEGER"

    .line 237
    .line 238
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 239
    .line 240
    .line 241
    const-string v3, "state"

    .line 242
    .line 243
    invoke-virtual {v1, v3, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    new-instance v15, LN0/l;

    .line 247
    .line 248
    const/16 v20, 0x0

    .line 249
    .line 250
    const/16 v17, 0x1

    .line 251
    .line 252
    const/16 v21, 0x1

    .line 253
    .line 254
    const/16 v16, 0x0

    .line 255
    .line 256
    const-string v18, "worker_class_name"

    .line 257
    .line 258
    const-string v19, "TEXT"

    .line 259
    .line 260
    invoke-direct/range {v15 .. v21}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 261
    .line 262
    .line 263
    const-string v3, "worker_class_name"

    .line 264
    .line 265
    invoke-virtual {v1, v3, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    new-instance v16, LN0/l;

    .line 269
    .line 270
    const/16 v21, 0x0

    .line 271
    .line 272
    const/16 v18, 0x1

    .line 273
    .line 274
    const/16 v22, 0x0

    .line 275
    .line 276
    const/16 v17, 0x0

    .line 277
    .line 278
    const-string v19, "input_merger_class_name"

    .line 279
    .line 280
    const-string v20, "TEXT"

    .line 281
    .line 282
    invoke-direct/range {v16 .. v22}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 283
    .line 284
    .line 285
    move-object/from16 v3, v16

    .line 286
    .line 287
    const-string v5, "input_merger_class_name"

    .line 288
    .line 289
    invoke-virtual {v1, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 290
    .line 291
    .line 292
    new-instance v13, LN0/l;

    .line 293
    .line 294
    const/16 v18, 0x0

    .line 295
    .line 296
    const/4 v15, 0x1

    .line 297
    const/16 v19, 0x1

    .line 298
    .line 299
    const/4 v14, 0x0

    .line 300
    const-string v16, "input"

    .line 301
    .line 302
    const-string v17, "BLOB"

    .line 303
    .line 304
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 305
    .line 306
    .line 307
    const-string v3, "input"

    .line 308
    .line 309
    invoke-virtual {v1, v3, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    new-instance v14, LN0/l;

    .line 313
    .line 314
    const/16 v19, 0x0

    .line 315
    .line 316
    const/16 v16, 0x1

    .line 317
    .line 318
    const/16 v20, 0x1

    .line 319
    .line 320
    const/4 v15, 0x0

    .line 321
    const-string v17, "output"

    .line 322
    .line 323
    const-string v18, "BLOB"

    .line 324
    .line 325
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 326
    .line 327
    .line 328
    const-string v3, "output"

    .line 329
    .line 330
    invoke-virtual {v1, v3, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    new-instance v15, LN0/l;

    .line 334
    .line 335
    const/16 v20, 0x0

    .line 336
    .line 337
    const/16 v17, 0x1

    .line 338
    .line 339
    const/16 v21, 0x1

    .line 340
    .line 341
    const/16 v16, 0x0

    .line 342
    .line 343
    const-string v18, "initial_delay"

    .line 344
    .line 345
    const-string v19, "INTEGER"

    .line 346
    .line 347
    invoke-direct/range {v15 .. v21}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 348
    .line 349
    .line 350
    const-string v3, "initial_delay"

    .line 351
    .line 352
    invoke-virtual {v1, v3, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 353
    .line 354
    .line 355
    new-instance v16, LN0/l;

    .line 356
    .line 357
    const/16 v21, 0x0

    .line 358
    .line 359
    const/16 v18, 0x1

    .line 360
    .line 361
    const/16 v22, 0x1

    .line 362
    .line 363
    const/16 v17, 0x0

    .line 364
    .line 365
    const-string v19, "interval_duration"

    .line 366
    .line 367
    const-string v20, "INTEGER"

    .line 368
    .line 369
    invoke-direct/range {v16 .. v22}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 370
    .line 371
    .line 372
    move-object/from16 v3, v16

    .line 373
    .line 374
    const-string v5, "interval_duration"

    .line 375
    .line 376
    invoke-virtual {v1, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 377
    .line 378
    .line 379
    new-instance v13, LN0/l;

    .line 380
    .line 381
    const/16 v18, 0x0

    .line 382
    .line 383
    const/4 v15, 0x1

    .line 384
    const/16 v19, 0x1

    .line 385
    .line 386
    const/4 v14, 0x0

    .line 387
    const-string v16, "flex_duration"

    .line 388
    .line 389
    const-string v17, "INTEGER"

    .line 390
    .line 391
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 392
    .line 393
    .line 394
    const-string v3, "flex_duration"

    .line 395
    .line 396
    invoke-virtual {v1, v3, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    new-instance v14, LN0/l;

    .line 400
    .line 401
    const/16 v19, 0x0

    .line 402
    .line 403
    const/16 v16, 0x1

    .line 404
    .line 405
    const/16 v20, 0x1

    .line 406
    .line 407
    const/4 v15, 0x0

    .line 408
    const-string v17, "run_attempt_count"

    .line 409
    .line 410
    const-string v18, "INTEGER"

    .line 411
    .line 412
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 413
    .line 414
    .line 415
    const-string v3, "run_attempt_count"

    .line 416
    .line 417
    invoke-virtual {v1, v3, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    new-instance v15, LN0/l;

    .line 421
    .line 422
    const/16 v20, 0x0

    .line 423
    .line 424
    const/16 v17, 0x1

    .line 425
    .line 426
    const/16 v21, 0x1

    .line 427
    .line 428
    const/16 v16, 0x0

    .line 429
    .line 430
    const-string v18, "backoff_policy"

    .line 431
    .line 432
    const-string v19, "INTEGER"

    .line 433
    .line 434
    invoke-direct/range {v15 .. v21}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 435
    .line 436
    .line 437
    const-string v3, "backoff_policy"

    .line 438
    .line 439
    invoke-virtual {v1, v3, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 440
    .line 441
    .line 442
    new-instance v16, LN0/l;

    .line 443
    .line 444
    const/16 v21, 0x0

    .line 445
    .line 446
    const/16 v18, 0x1

    .line 447
    .line 448
    const/16 v17, 0x0

    .line 449
    .line 450
    const-string v19, "backoff_delay_duration"

    .line 451
    .line 452
    const-string v20, "INTEGER"

    .line 453
    .line 454
    invoke-direct/range {v16 .. v22}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 455
    .line 456
    .line 457
    move-object/from16 v3, v16

    .line 458
    .line 459
    const-string v5, "backoff_delay_duration"

    .line 460
    .line 461
    invoke-virtual {v1, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 462
    .line 463
    .line 464
    new-instance v13, LN0/l;

    .line 465
    .line 466
    const/16 v18, 0x0

    .line 467
    .line 468
    const/4 v15, 0x1

    .line 469
    const/16 v19, 0x1

    .line 470
    .line 471
    const/4 v14, 0x0

    .line 472
    const-string v16, "period_start_time"

    .line 473
    .line 474
    const-string v17, "INTEGER"

    .line 475
    .line 476
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 477
    .line 478
    .line 479
    const-string v3, "period_start_time"

    .line 480
    .line 481
    invoke-virtual {v1, v3, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 482
    .line 483
    .line 484
    new-instance v14, LN0/l;

    .line 485
    .line 486
    const/16 v19, 0x0

    .line 487
    .line 488
    const/16 v16, 0x1

    .line 489
    .line 490
    const/16 v20, 0x1

    .line 491
    .line 492
    const/4 v15, 0x0

    .line 493
    const-string v17, "minimum_retention_duration"

    .line 494
    .line 495
    const-string v18, "INTEGER"

    .line 496
    .line 497
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 498
    .line 499
    .line 500
    const-string v5, "minimum_retention_duration"

    .line 501
    .line 502
    invoke-virtual {v1, v5, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 503
    .line 504
    .line 505
    new-instance v15, LN0/l;

    .line 506
    .line 507
    const/16 v20, 0x0

    .line 508
    .line 509
    const/16 v17, 0x1

    .line 510
    .line 511
    const/16 v21, 0x1

    .line 512
    .line 513
    const/16 v16, 0x0

    .line 514
    .line 515
    const-string v18, "schedule_requested_at"

    .line 516
    .line 517
    const-string v19, "INTEGER"

    .line 518
    .line 519
    invoke-direct/range {v15 .. v21}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 520
    .line 521
    .line 522
    const-string v5, "schedule_requested_at"

    .line 523
    .line 524
    invoke-virtual {v1, v5, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 525
    .line 526
    .line 527
    new-instance v16, LN0/l;

    .line 528
    .line 529
    const/16 v21, 0x0

    .line 530
    .line 531
    const/16 v18, 0x1

    .line 532
    .line 533
    const/16 v17, 0x0

    .line 534
    .line 535
    const-string v19, "run_in_foreground"

    .line 536
    .line 537
    const-string v20, "INTEGER"

    .line 538
    .line 539
    invoke-direct/range {v16 .. v22}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 540
    .line 541
    .line 542
    move-object/from16 v8, v16

    .line 543
    .line 544
    const-string v9, "run_in_foreground"

    .line 545
    .line 546
    invoke-virtual {v1, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 547
    .line 548
    .line 549
    new-instance v13, LN0/l;

    .line 550
    .line 551
    const/16 v18, 0x0

    .line 552
    .line 553
    const/4 v15, 0x1

    .line 554
    const/16 v19, 0x1

    .line 555
    .line 556
    const/4 v14, 0x0

    .line 557
    const-string v16, "out_of_quota_policy"

    .line 558
    .line 559
    const-string v17, "INTEGER"

    .line 560
    .line 561
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 562
    .line 563
    .line 564
    const-string v8, "out_of_quota_policy"

    .line 565
    .line 566
    invoke-virtual {v1, v8, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 567
    .line 568
    .line 569
    new-instance v14, LN0/l;

    .line 570
    .line 571
    const/16 v19, 0x0

    .line 572
    .line 573
    const/16 v16, 0x1

    .line 574
    .line 575
    const/16 v20, 0x0

    .line 576
    .line 577
    const/4 v15, 0x0

    .line 578
    const-string v17, "required_network_type"

    .line 579
    .line 580
    const-string v18, "INTEGER"

    .line 581
    .line 582
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 583
    .line 584
    .line 585
    const-string v8, "required_network_type"

    .line 586
    .line 587
    invoke-virtual {v1, v8, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 588
    .line 589
    .line 590
    new-instance v15, LN0/l;

    .line 591
    .line 592
    const/16 v20, 0x0

    .line 593
    .line 594
    const/16 v17, 0x1

    .line 595
    .line 596
    const/16 v21, 0x1

    .line 597
    .line 598
    const/16 v16, 0x0

    .line 599
    .line 600
    const-string v18, "requires_charging"

    .line 601
    .line 602
    const-string v19, "INTEGER"

    .line 603
    .line 604
    invoke-direct/range {v15 .. v21}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 605
    .line 606
    .line 607
    const-string v8, "requires_charging"

    .line 608
    .line 609
    invoke-virtual {v1, v8, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 610
    .line 611
    .line 612
    new-instance v16, LN0/l;

    .line 613
    .line 614
    const/16 v21, 0x0

    .line 615
    .line 616
    const/16 v18, 0x1

    .line 617
    .line 618
    const/16 v17, 0x0

    .line 619
    .line 620
    const-string v19, "requires_device_idle"

    .line 621
    .line 622
    const-string v20, "INTEGER"

    .line 623
    .line 624
    invoke-direct/range {v16 .. v22}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 625
    .line 626
    .line 627
    move-object/from16 v8, v16

    .line 628
    .line 629
    const-string v9, "requires_device_idle"

    .line 630
    .line 631
    invoke-virtual {v1, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 632
    .line 633
    .line 634
    new-instance v13, LN0/l;

    .line 635
    .line 636
    const/16 v18, 0x0

    .line 637
    .line 638
    const/4 v15, 0x1

    .line 639
    const/16 v19, 0x1

    .line 640
    .line 641
    const/4 v14, 0x0

    .line 642
    const-string v16, "requires_battery_not_low"

    .line 643
    .line 644
    const-string v17, "INTEGER"

    .line 645
    .line 646
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 647
    .line 648
    .line 649
    const-string v8, "requires_battery_not_low"

    .line 650
    .line 651
    invoke-virtual {v1, v8, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 652
    .line 653
    .line 654
    new-instance v14, LN0/l;

    .line 655
    .line 656
    const/16 v19, 0x0

    .line 657
    .line 658
    const/16 v16, 0x1

    .line 659
    .line 660
    const/16 v20, 0x1

    .line 661
    .line 662
    const/4 v15, 0x0

    .line 663
    const-string v17, "requires_storage_not_low"

    .line 664
    .line 665
    const-string v18, "INTEGER"

    .line 666
    .line 667
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 668
    .line 669
    .line 670
    const-string v8, "requires_storage_not_low"

    .line 671
    .line 672
    invoke-virtual {v1, v8, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 673
    .line 674
    .line 675
    new-instance v15, LN0/l;

    .line 676
    .line 677
    const/16 v20, 0x0

    .line 678
    .line 679
    const/16 v17, 0x1

    .line 680
    .line 681
    const/16 v21, 0x1

    .line 682
    .line 683
    const/16 v16, 0x0

    .line 684
    .line 685
    const-string v18, "trigger_content_update_delay"

    .line 686
    .line 687
    const-string v19, "INTEGER"

    .line 688
    .line 689
    invoke-direct/range {v15 .. v21}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 690
    .line 691
    .line 692
    const-string v8, "trigger_content_update_delay"

    .line 693
    .line 694
    invoke-virtual {v1, v8, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 695
    .line 696
    .line 697
    new-instance v16, LN0/l;

    .line 698
    .line 699
    const/16 v21, 0x0

    .line 700
    .line 701
    const/16 v18, 0x1

    .line 702
    .line 703
    const/16 v17, 0x0

    .line 704
    .line 705
    const-string v19, "trigger_max_content_delay"

    .line 706
    .line 707
    const-string v20, "INTEGER"

    .line 708
    .line 709
    invoke-direct/range {v16 .. v22}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 710
    .line 711
    .line 712
    move-object/from16 v8, v16

    .line 713
    .line 714
    const-string v9, "trigger_max_content_delay"

    .line 715
    .line 716
    invoke-virtual {v1, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 717
    .line 718
    .line 719
    new-instance v13, LN0/l;

    .line 720
    .line 721
    const/16 v18, 0x0

    .line 722
    .line 723
    const/4 v15, 0x1

    .line 724
    const/16 v19, 0x0

    .line 725
    .line 726
    const/4 v14, 0x0

    .line 727
    const-string v16, "content_uri_triggers"

    .line 728
    .line 729
    const-string v17, "BLOB"

    .line 730
    .line 731
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 732
    .line 733
    .line 734
    const-string v8, "content_uri_triggers"

    .line 735
    .line 736
    invoke-virtual {v1, v8, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 737
    .line 738
    .line 739
    new-instance v8, Ljava/util/HashSet;

    .line 740
    .line 741
    invoke-direct {v8, v7}, Ljava/util/HashSet;-><init>(I)V

    .line 742
    .line 743
    .line 744
    new-instance v9, Ljava/util/HashSet;

    .line 745
    .line 746
    invoke-direct {v9, v2}, Ljava/util/HashSet;-><init>(I)V

    .line 747
    .line 748
    .line 749
    new-instance v10, LN0/n;

    .line 750
    .line 751
    filled-new-array {v5}, [Ljava/lang/String;

    .line 752
    .line 753
    .line 754
    move-result-object v5

    .line 755
    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 756
    .line 757
    .line 758
    move-result-object v5

    .line 759
    const-string v11, "index_WorkSpec_schedule_requested_at"

    .line 760
    .line 761
    invoke-direct {v10, v11, v5}, LN0/n;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 762
    .line 763
    .line 764
    invoke-virtual {v9, v10}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 765
    .line 766
    .line 767
    new-instance v5, LN0/n;

    .line 768
    .line 769
    filled-new-array {v3}, [Ljava/lang/String;

    .line 770
    .line 771
    .line 772
    move-result-object v3

    .line 773
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 774
    .line 775
    .line 776
    move-result-object v3

    .line 777
    const-string v10, "index_WorkSpec_period_start_time"

    .line 778
    .line 779
    invoke-direct {v5, v10, v3}, LN0/n;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 780
    .line 781
    .line 782
    invoke-virtual {v9, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 783
    .line 784
    .line 785
    new-instance v3, LN0/o;

    .line 786
    .line 787
    const-string v5, "WorkSpec"

    .line 788
    .line 789
    invoke-direct {v3, v5, v1, v8, v9}, LN0/o;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 790
    .line 791
    .line 792
    invoke-static {v0, v5}, LN0/o;->a(LT0/c;Ljava/lang/String;)LN0/o;

    .line 793
    .line 794
    .line 795
    move-result-object v1

    .line 796
    invoke-virtual {v3, v1}, LN0/o;->equals(Ljava/lang/Object;)Z

    .line 797
    .line 798
    .line 799
    move-result v5

    .line 800
    if-nez v5, :cond_1

    .line 801
    .line 802
    new-instance v0, LB3/M;

    .line 803
    .line 804
    new-instance v2, Ljava/lang/StringBuilder;

    .line 805
    .line 806
    const-string v4, "WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n"

    .line 807
    .line 808
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 809
    .line 810
    .line 811
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 812
    .line 813
    .line 814
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 815
    .line 816
    .line 817
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 818
    .line 819
    .line 820
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 821
    .line 822
    .line 823
    move-result-object v1

    .line 824
    const/4 v2, 0x2

    .line 825
    invoke-direct {v0, v7, v1, v2}, LB3/M;-><init>(ZLjava/lang/String;I)V

    .line 826
    .line 827
    .line 828
    return-object v0

    .line 829
    :cond_1
    new-instance v1, Ljava/util/HashMap;

    .line 830
    .line 831
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 832
    .line 833
    .line 834
    new-instance v13, LN0/l;

    .line 835
    .line 836
    const/16 v18, 0x0

    .line 837
    .line 838
    const/4 v15, 0x1

    .line 839
    const/4 v14, 0x1

    .line 840
    const-string v16, "tag"

    .line 841
    .line 842
    const-string v17, "TEXT"

    .line 843
    .line 844
    const/16 v19, 0x1

    .line 845
    .line 846
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 847
    .line 848
    .line 849
    const-string v3, "tag"

    .line 850
    .line 851
    invoke-virtual {v1, v3, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 852
    .line 853
    .line 854
    new-instance v14, LN0/l;

    .line 855
    .line 856
    const/16 v19, 0x0

    .line 857
    .line 858
    const/16 v16, 0x1

    .line 859
    .line 860
    const/4 v15, 0x2

    .line 861
    const-string v17, "work_spec_id"

    .line 862
    .line 863
    const-string v18, "TEXT"

    .line 864
    .line 865
    const/16 v20, 0x1

    .line 866
    .line 867
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 868
    .line 869
    .line 870
    invoke-virtual {v1, v4, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 871
    .line 872
    .line 873
    new-instance v3, Ljava/util/HashSet;

    .line 874
    .line 875
    const/4 v5, 0x1

    .line 876
    invoke-direct {v3, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 877
    .line 878
    .line 879
    new-instance v13, LN0/m;

    .line 880
    .line 881
    filled-new-array {v4}, [Ljava/lang/String;

    .line 882
    .line 883
    .line 884
    move-result-object v8

    .line 885
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 886
    .line 887
    .line 888
    move-result-object v17

    .line 889
    filled-new-array {v12}, [Ljava/lang/String;

    .line 890
    .line 891
    .line 892
    move-result-object v8

    .line 893
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 894
    .line 895
    .line 896
    move-result-object v18

    .line 897
    const-string v14, "WorkSpec"

    .line 898
    .line 899
    const-string v15, "CASCADE"

    .line 900
    .line 901
    const-string v16, "CASCADE"

    .line 902
    .line 903
    invoke-direct/range {v13 .. v18}, LN0/m;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 904
    .line 905
    .line 906
    invoke-virtual {v3, v13}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 907
    .line 908
    .line 909
    new-instance v8, Ljava/util/HashSet;

    .line 910
    .line 911
    invoke-direct {v8, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 912
    .line 913
    .line 914
    new-instance v9, LN0/n;

    .line 915
    .line 916
    filled-new-array {v4}, [Ljava/lang/String;

    .line 917
    .line 918
    .line 919
    move-result-object v10

    .line 920
    invoke-static {v10}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 921
    .line 922
    .line 923
    move-result-object v10

    .line 924
    const-string v11, "index_WorkTag_work_spec_id"

    .line 925
    .line 926
    invoke-direct {v9, v11, v10}, LN0/n;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 927
    .line 928
    .line 929
    invoke-virtual {v8, v9}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 930
    .line 931
    .line 932
    new-instance v9, LN0/o;

    .line 933
    .line 934
    const-string v10, "WorkTag"

    .line 935
    .line 936
    invoke-direct {v9, v10, v1, v3, v8}, LN0/o;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 937
    .line 938
    .line 939
    invoke-static {v0, v10}, LN0/o;->a(LT0/c;Ljava/lang/String;)LN0/o;

    .line 940
    .line 941
    .line 942
    move-result-object v1

    .line 943
    invoke-virtual {v9, v1}, LN0/o;->equals(Ljava/lang/Object;)Z

    .line 944
    .line 945
    .line 946
    move-result v3

    .line 947
    if-nez v3, :cond_2

    .line 948
    .line 949
    new-instance v0, LB3/M;

    .line 950
    .line 951
    new-instance v2, Ljava/lang/StringBuilder;

    .line 952
    .line 953
    const-string v3, "WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n"

    .line 954
    .line 955
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 956
    .line 957
    .line 958
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 959
    .line 960
    .line 961
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 962
    .line 963
    .line 964
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 965
    .line 966
    .line 967
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 968
    .line 969
    .line 970
    move-result-object v1

    .line 971
    const/4 v2, 0x2

    .line 972
    invoke-direct {v0, v7, v1, v2}, LB3/M;-><init>(ZLjava/lang/String;I)V

    .line 973
    .line 974
    .line 975
    return-object v0

    .line 976
    :cond_2
    new-instance v1, Ljava/util/HashMap;

    .line 977
    .line 978
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 979
    .line 980
    .line 981
    new-instance v13, LN0/l;

    .line 982
    .line 983
    const/16 v18, 0x0

    .line 984
    .line 985
    const/4 v15, 0x1

    .line 986
    const/4 v14, 0x1

    .line 987
    const-string v16, "work_spec_id"

    .line 988
    .line 989
    const-string v17, "TEXT"

    .line 990
    .line 991
    const/16 v19, 0x1

    .line 992
    .line 993
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 994
    .line 995
    .line 996
    invoke-virtual {v1, v4, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 997
    .line 998
    .line 999
    new-instance v14, LN0/l;

    .line 1000
    .line 1001
    const/16 v19, 0x0

    .line 1002
    .line 1003
    const/16 v16, 0x1

    .line 1004
    .line 1005
    const/4 v15, 0x0

    .line 1006
    const-string v17, "system_id"

    .line 1007
    .line 1008
    const-string v18, "INTEGER"

    .line 1009
    .line 1010
    const/16 v20, 0x1

    .line 1011
    .line 1012
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 1013
    .line 1014
    .line 1015
    const-string v3, "system_id"

    .line 1016
    .line 1017
    invoke-virtual {v1, v3, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1018
    .line 1019
    .line 1020
    new-instance v3, Ljava/util/HashSet;

    .line 1021
    .line 1022
    invoke-direct {v3, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 1023
    .line 1024
    .line 1025
    new-instance v13, LN0/m;

    .line 1026
    .line 1027
    filled-new-array {v4}, [Ljava/lang/String;

    .line 1028
    .line 1029
    .line 1030
    move-result-object v8

    .line 1031
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1032
    .line 1033
    .line 1034
    move-result-object v17

    .line 1035
    filled-new-array {v12}, [Ljava/lang/String;

    .line 1036
    .line 1037
    .line 1038
    move-result-object v8

    .line 1039
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1040
    .line 1041
    .line 1042
    move-result-object v18

    .line 1043
    const-string v14, "WorkSpec"

    .line 1044
    .line 1045
    const-string v15, "CASCADE"

    .line 1046
    .line 1047
    const-string v16, "CASCADE"

    .line 1048
    .line 1049
    invoke-direct/range {v13 .. v18}, LN0/m;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 1050
    .line 1051
    .line 1052
    invoke-virtual {v3, v13}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 1053
    .line 1054
    .line 1055
    new-instance v8, Ljava/util/HashSet;

    .line 1056
    .line 1057
    invoke-direct {v8, v7}, Ljava/util/HashSet;-><init>(I)V

    .line 1058
    .line 1059
    .line 1060
    new-instance v9, LN0/o;

    .line 1061
    .line 1062
    const-string v10, "SystemIdInfo"

    .line 1063
    .line 1064
    invoke-direct {v9, v10, v1, v3, v8}, LN0/o;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 1065
    .line 1066
    .line 1067
    invoke-static {v0, v10}, LN0/o;->a(LT0/c;Ljava/lang/String;)LN0/o;

    .line 1068
    .line 1069
    .line 1070
    move-result-object v1

    .line 1071
    invoke-virtual {v9, v1}, LN0/o;->equals(Ljava/lang/Object;)Z

    .line 1072
    .line 1073
    .line 1074
    move-result v3

    .line 1075
    if-nez v3, :cond_3

    .line 1076
    .line 1077
    new-instance v0, LB3/M;

    .line 1078
    .line 1079
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1080
    .line 1081
    const-string v3, "SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n"

    .line 1082
    .line 1083
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1084
    .line 1085
    .line 1086
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1087
    .line 1088
    .line 1089
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1090
    .line 1091
    .line 1092
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1093
    .line 1094
    .line 1095
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1096
    .line 1097
    .line 1098
    move-result-object v1

    .line 1099
    const/4 v2, 0x2

    .line 1100
    invoke-direct {v0, v7, v1, v2}, LB3/M;-><init>(ZLjava/lang/String;I)V

    .line 1101
    .line 1102
    .line 1103
    return-object v0

    .line 1104
    :cond_3
    new-instance v1, Ljava/util/HashMap;

    .line 1105
    .line 1106
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 1107
    .line 1108
    .line 1109
    new-instance v13, LN0/l;

    .line 1110
    .line 1111
    const/16 v18, 0x0

    .line 1112
    .line 1113
    const/4 v15, 0x1

    .line 1114
    const/4 v14, 0x1

    .line 1115
    const-string v16, "name"

    .line 1116
    .line 1117
    const-string v17, "TEXT"

    .line 1118
    .line 1119
    const/16 v19, 0x1

    .line 1120
    .line 1121
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 1122
    .line 1123
    .line 1124
    const-string v3, "name"

    .line 1125
    .line 1126
    invoke-virtual {v1, v3, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1127
    .line 1128
    .line 1129
    new-instance v14, LN0/l;

    .line 1130
    .line 1131
    const/16 v19, 0x0

    .line 1132
    .line 1133
    const/16 v16, 0x1

    .line 1134
    .line 1135
    const/4 v15, 0x2

    .line 1136
    const-string v17, "work_spec_id"

    .line 1137
    .line 1138
    const-string v18, "TEXT"

    .line 1139
    .line 1140
    const/16 v20, 0x1

    .line 1141
    .line 1142
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 1143
    .line 1144
    .line 1145
    invoke-virtual {v1, v4, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1146
    .line 1147
    .line 1148
    new-instance v3, Ljava/util/HashSet;

    .line 1149
    .line 1150
    invoke-direct {v3, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 1151
    .line 1152
    .line 1153
    new-instance v13, LN0/m;

    .line 1154
    .line 1155
    filled-new-array {v4}, [Ljava/lang/String;

    .line 1156
    .line 1157
    .line 1158
    move-result-object v8

    .line 1159
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1160
    .line 1161
    .line 1162
    move-result-object v17

    .line 1163
    filled-new-array {v12}, [Ljava/lang/String;

    .line 1164
    .line 1165
    .line 1166
    move-result-object v8

    .line 1167
    invoke-static {v8}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1168
    .line 1169
    .line 1170
    move-result-object v18

    .line 1171
    const-string v14, "WorkSpec"

    .line 1172
    .line 1173
    const-string v15, "CASCADE"

    .line 1174
    .line 1175
    const-string v16, "CASCADE"

    .line 1176
    .line 1177
    invoke-direct/range {v13 .. v18}, LN0/m;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 1178
    .line 1179
    .line 1180
    invoke-virtual {v3, v13}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 1181
    .line 1182
    .line 1183
    new-instance v8, Ljava/util/HashSet;

    .line 1184
    .line 1185
    invoke-direct {v8, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 1186
    .line 1187
    .line 1188
    new-instance v9, LN0/n;

    .line 1189
    .line 1190
    filled-new-array {v4}, [Ljava/lang/String;

    .line 1191
    .line 1192
    .line 1193
    move-result-object v10

    .line 1194
    invoke-static {v10}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1195
    .line 1196
    .line 1197
    move-result-object v10

    .line 1198
    const-string v11, "index_WorkName_work_spec_id"

    .line 1199
    .line 1200
    invoke-direct {v9, v11, v10}, LN0/n;-><init>(Ljava/lang/String;Ljava/util/List;)V

    .line 1201
    .line 1202
    .line 1203
    invoke-virtual {v8, v9}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 1204
    .line 1205
    .line 1206
    new-instance v9, LN0/o;

    .line 1207
    .line 1208
    const-string v10, "WorkName"

    .line 1209
    .line 1210
    invoke-direct {v9, v10, v1, v3, v8}, LN0/o;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 1211
    .line 1212
    .line 1213
    invoke-static {v0, v10}, LN0/o;->a(LT0/c;Ljava/lang/String;)LN0/o;

    .line 1214
    .line 1215
    .line 1216
    move-result-object v1

    .line 1217
    invoke-virtual {v9, v1}, LN0/o;->equals(Ljava/lang/Object;)Z

    .line 1218
    .line 1219
    .line 1220
    move-result v3

    .line 1221
    if-nez v3, :cond_4

    .line 1222
    .line 1223
    new-instance v0, LB3/M;

    .line 1224
    .line 1225
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1226
    .line 1227
    const-string v3, "WorkName(androidx.work.impl.model.WorkName).\n Expected:\n"

    .line 1228
    .line 1229
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1230
    .line 1231
    .line 1232
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1233
    .line 1234
    .line 1235
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1236
    .line 1237
    .line 1238
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1239
    .line 1240
    .line 1241
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1242
    .line 1243
    .line 1244
    move-result-object v1

    .line 1245
    const/4 v2, 0x2

    .line 1246
    invoke-direct {v0, v7, v1, v2}, LB3/M;-><init>(ZLjava/lang/String;I)V

    .line 1247
    .line 1248
    .line 1249
    return-object v0

    .line 1250
    :cond_4
    new-instance v1, Ljava/util/HashMap;

    .line 1251
    .line 1252
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 1253
    .line 1254
    .line 1255
    new-instance v13, LN0/l;

    .line 1256
    .line 1257
    const/16 v18, 0x0

    .line 1258
    .line 1259
    const/4 v15, 0x1

    .line 1260
    const/4 v14, 0x1

    .line 1261
    const-string v16, "work_spec_id"

    .line 1262
    .line 1263
    const-string v17, "TEXT"

    .line 1264
    .line 1265
    const/16 v19, 0x1

    .line 1266
    .line 1267
    invoke-direct/range {v13 .. v19}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 1268
    .line 1269
    .line 1270
    invoke-virtual {v1, v4, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1271
    .line 1272
    .line 1273
    new-instance v14, LN0/l;

    .line 1274
    .line 1275
    const/16 v19, 0x0

    .line 1276
    .line 1277
    const/16 v16, 0x1

    .line 1278
    .line 1279
    const/4 v15, 0x0

    .line 1280
    const-string v17, "progress"

    .line 1281
    .line 1282
    const-string v18, "BLOB"

    .line 1283
    .line 1284
    const/16 v20, 0x1

    .line 1285
    .line 1286
    invoke-direct/range {v14 .. v20}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 1287
    .line 1288
    .line 1289
    const-string v3, "progress"

    .line 1290
    .line 1291
    invoke-virtual {v1, v3, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1292
    .line 1293
    .line 1294
    new-instance v3, Ljava/util/HashSet;

    .line 1295
    .line 1296
    invoke-direct {v3, v5}, Ljava/util/HashSet;-><init>(I)V

    .line 1297
    .line 1298
    .line 1299
    new-instance v13, LN0/m;

    .line 1300
    .line 1301
    filled-new-array {v4}, [Ljava/lang/String;

    .line 1302
    .line 1303
    .line 1304
    move-result-object v4

    .line 1305
    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1306
    .line 1307
    .line 1308
    move-result-object v17

    .line 1309
    filled-new-array {v12}, [Ljava/lang/String;

    .line 1310
    .line 1311
    .line 1312
    move-result-object v4

    .line 1313
    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1314
    .line 1315
    .line 1316
    move-result-object v18

    .line 1317
    const-string v14, "WorkSpec"

    .line 1318
    .line 1319
    const-string v15, "CASCADE"

    .line 1320
    .line 1321
    const-string v16, "CASCADE"

    .line 1322
    .line 1323
    invoke-direct/range {v13 .. v18}, LN0/m;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;)V

    .line 1324
    .line 1325
    .line 1326
    invoke-virtual {v3, v13}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 1327
    .line 1328
    .line 1329
    new-instance v4, Ljava/util/HashSet;

    .line 1330
    .line 1331
    invoke-direct {v4, v7}, Ljava/util/HashSet;-><init>(I)V

    .line 1332
    .line 1333
    .line 1334
    new-instance v8, LN0/o;

    .line 1335
    .line 1336
    const-string v9, "WorkProgress"

    .line 1337
    .line 1338
    invoke-direct {v8, v9, v1, v3, v4}, LN0/o;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 1339
    .line 1340
    .line 1341
    invoke-static {v0, v9}, LN0/o;->a(LT0/c;Ljava/lang/String;)LN0/o;

    .line 1342
    .line 1343
    .line 1344
    move-result-object v1

    .line 1345
    invoke-virtual {v8, v1}, LN0/o;->equals(Ljava/lang/Object;)Z

    .line 1346
    .line 1347
    .line 1348
    move-result v3

    .line 1349
    if-nez v3, :cond_5

    .line 1350
    .line 1351
    new-instance v0, LB3/M;

    .line 1352
    .line 1353
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1354
    .line 1355
    const-string v3, "WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n"

    .line 1356
    .line 1357
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1358
    .line 1359
    .line 1360
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1361
    .line 1362
    .line 1363
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1364
    .line 1365
    .line 1366
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1367
    .line 1368
    .line 1369
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1370
    .line 1371
    .line 1372
    move-result-object v1

    .line 1373
    const/4 v2, 0x2

    .line 1374
    invoke-direct {v0, v7, v1, v2}, LB3/M;-><init>(ZLjava/lang/String;I)V

    .line 1375
    .line 1376
    .line 1377
    return-object v0

    .line 1378
    :cond_5
    new-instance v1, Ljava/util/HashMap;

    .line 1379
    .line 1380
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 1381
    .line 1382
    .line 1383
    new-instance v8, LN0/l;

    .line 1384
    .line 1385
    const/4 v13, 0x0

    .line 1386
    const/4 v10, 0x1

    .line 1387
    const/4 v9, 0x1

    .line 1388
    const-string v11, "key"

    .line 1389
    .line 1390
    const-string v12, "TEXT"

    .line 1391
    .line 1392
    const/4 v14, 0x1

    .line 1393
    invoke-direct/range {v8 .. v14}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 1394
    .line 1395
    .line 1396
    const-string v2, "key"

    .line 1397
    .line 1398
    invoke-virtual {v1, v2, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1399
    .line 1400
    .line 1401
    new-instance v9, LN0/l;

    .line 1402
    .line 1403
    const/4 v14, 0x0

    .line 1404
    const/4 v11, 0x1

    .line 1405
    const/4 v10, 0x0

    .line 1406
    const-string v12, "long_value"

    .line 1407
    .line 1408
    const-string v13, "INTEGER"

    .line 1409
    .line 1410
    const/4 v15, 0x0

    .line 1411
    invoke-direct/range {v9 .. v15}, LN0/l;-><init>(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 1412
    .line 1413
    .line 1414
    const-string v2, "long_value"

    .line 1415
    .line 1416
    invoke-virtual {v1, v2, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1417
    .line 1418
    .line 1419
    new-instance v2, Ljava/util/HashSet;

    .line 1420
    .line 1421
    invoke-direct {v2, v7}, Ljava/util/HashSet;-><init>(I)V

    .line 1422
    .line 1423
    .line 1424
    new-instance v3, Ljava/util/HashSet;

    .line 1425
    .line 1426
    invoke-direct {v3, v7}, Ljava/util/HashSet;-><init>(I)V

    .line 1427
    .line 1428
    .line 1429
    new-instance v4, LN0/o;

    .line 1430
    .line 1431
    const-string v8, "Preference"

    .line 1432
    .line 1433
    invoke-direct {v4, v8, v1, v2, v3}, LN0/o;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 1434
    .line 1435
    .line 1436
    invoke-static {v0, v8}, LN0/o;->a(LT0/c;Ljava/lang/String;)LN0/o;

    .line 1437
    .line 1438
    .line 1439
    move-result-object v0

    .line 1440
    invoke-virtual {v4, v0}, LN0/o;->equals(Ljava/lang/Object;)Z

    .line 1441
    .line 1442
    .line 1443
    move-result v1

    .line 1444
    if-nez v1, :cond_6

    .line 1445
    .line 1446
    new-instance v1, LB3/M;

    .line 1447
    .line 1448
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1449
    .line 1450
    const-string v3, "Preference(androidx.work.impl.model.Preference).\n Expected:\n"

    .line 1451
    .line 1452
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1453
    .line 1454
    .line 1455
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1456
    .line 1457
    .line 1458
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1459
    .line 1460
    .line 1461
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1462
    .line 1463
    .line 1464
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1465
    .line 1466
    .line 1467
    move-result-object v0

    .line 1468
    const/4 v2, 0x2

    .line 1469
    invoke-direct {v1, v7, v0, v2}, LB3/M;-><init>(ZLjava/lang/String;I)V

    .line 1470
    .line 1471
    .line 1472
    return-object v1

    .line 1473
    :cond_6
    new-instance v0, LB3/M;

    .line 1474
    .line 1475
    const/4 v1, 0x0

    .line 1476
    const/4 v2, 0x2

    .line 1477
    invoke-direct {v0, v5, v1, v2}, LB3/M;-><init>(ZLjava/lang/String;I)V

    .line 1478
    .line 1479
    .line 1480
    return-object v0
.end method

.method public static w(Ljava/lang/String;Landroid/os/Bundle;)Ljava/lang/String;
    .locals 5

    .line 1
    new-instance v0, Lorg/json/JSONObject;

    .line 2
    .line 3
    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lorg/json/JSONObject;

    .line 7
    .line 8
    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 12
    .line 13
    .line 14
    move-result-object v2

    .line 15
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_0

    .line 24
    .line 25
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Ljava/lang/String;

    .line 30
    .line 31
    invoke-virtual {p1, v3}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    const-string p1, "name"

    .line 40
    .line 41
    invoke-virtual {v0, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 42
    .line 43
    .line 44
    const-string p0, "parameters"

    .line 45
    .line 46
    invoke-virtual {v0, p0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    return-object p0
.end method


# virtual methods
.method public A(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    return-void
.end method

.method public a(Landroid/view/View;)Z
    .locals 3

    .line 1
    check-cast p1, Landroidx/viewpager2/widget/ViewPager2;

    .line 2
    .line 3
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lcom/google/firebase/messaging/s;

    .line 6
    .line 7
    invoke-virtual {p1}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    const/4 v1, 0x1

    .line 12
    add-int/2addr p1, v1

    .line 13
    iget-object v0, v0, Lcom/google/firebase/messaging/s;->e:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Landroidx/viewpager2/widget/ViewPager2;

    .line 16
    .line 17
    iget-boolean v2, v0, Landroidx/viewpager2/widget/ViewPager2;->r:Z

    .line 18
    .line 19
    if-eqz v2, :cond_0

    .line 20
    .line 21
    invoke-virtual {v0, p1, v1}, Landroidx/viewpager2/widget/ViewPager2;->c(IZ)V

    .line 22
    .line 23
    .line 24
    :cond_0
    return v1
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [Ljava/lang/String;

    .line 4
    .line 5
    check-cast p1, Lu3/q;

    .line 6
    .line 7
    check-cast p2, Lb4/i;

    .line 8
    .line 9
    new-instance v1, Lu3/o;

    .line 10
    .line 11
    const/4 v2, 0x2

    .line 12
    invoke-direct {v1, v2, p2}, Lu3/o;-><init>(ILb4/i;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p1}, LB3/e;->u()Landroid/os/IInterface;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    check-cast p1, Lu3/g;

    .line 20
    .line 21
    invoke-virtual {p1}, LO3/a;->a1()Landroid/os/Parcel;

    .line 22
    .line 23
    .line 24
    move-result-object p2

    .line 25
    invoke-static {p2, v1}, Lcom/google/android/gms/internal/cast/h;->c(Landroid/os/Parcel;Landroid/os/IInterface;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const/4 v0, 0x7

    .line 32
    invoke-virtual {p1, p2, v0}, LO3/a;->e1(Landroid/os/Parcel;I)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public b(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    return-void
.end method

.method public c(Ln/k;Landroid/view/MenuItem;)Z
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Ld5/h;->a:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    packed-switch v1, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    iget-object v1, v0, Ld5/h;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    .line 13
    .line 14
    iget-object v1, v1, Lw4/k;->e:Lw4/i;

    .line 15
    .line 16
    if-eqz v1, :cond_4

    .line 17
    .line 18
    check-cast v1, LH4/j;

    .line 19
    .line 20
    iget-object v1, v1, LH4/j;->b:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v1, Lw0/F;

    .line 23
    .line 24
    const-string v4, "item"

    .line 25
    .line 26
    move-object/from16 v5, p2

    .line 27
    .line 28
    invoke-static {v5, v4}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1}, Lw0/F;->f()Lw0/A;

    .line 32
    .line 33
    .line 34
    move-result-object v4

    .line 35
    const/4 v6, 0x0

    .line 36
    if-eqz v4, :cond_0

    .line 37
    .line 38
    iget-object v4, v4, Lw0/A;->b:Lw0/D;

    .line 39
    .line 40
    if-eqz v4, :cond_0

    .line 41
    .line 42
    invoke-interface {v5}, Landroid/view/MenuItem;->getItemId()I

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    invoke-virtual {v4, v7, v2}, Lw0/D;->n(IZ)Lw0/A;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    goto :goto_0

    .line 51
    :cond_0
    move-object v4, v6

    .line 52
    :goto_0
    instance-of v4, v4, Lw0/b;

    .line 53
    .line 54
    if-eqz v4, :cond_1

    .line 55
    .line 56
    const v4, 0x7f01002c

    .line 57
    .line 58
    .line 59
    const v7, 0x7f01002d

    .line 60
    .line 61
    .line 62
    const v8, 0x7f01002e

    .line 63
    .line 64
    .line 65
    const v9, 0x7f01002f

    .line 66
    .line 67
    .line 68
    :goto_1
    move/from16 v16, v4

    .line 69
    .line 70
    move/from16 v17, v7

    .line 71
    .line 72
    move/from16 v18, v8

    .line 73
    .line 74
    move/from16 v19, v9

    .line 75
    .line 76
    goto :goto_2

    .line 77
    :cond_1
    const v4, 0x7f020022

    .line 78
    .line 79
    .line 80
    const v7, 0x7f020023

    .line 81
    .line 82
    .line 83
    const v8, 0x7f020024

    .line 84
    .line 85
    .line 86
    const v9, 0x7f020025

    .line 87
    .line 88
    .line 89
    goto :goto_1

    .line 90
    :goto_2
    invoke-interface {v5}, Landroid/view/MenuItem;->getOrder()I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    const/high16 v7, 0x30000

    .line 95
    .line 96
    and-int/2addr v4, v7

    .line 97
    const/4 v14, 0x0

    .line 98
    if-nez v4, :cond_2

    .line 99
    .line 100
    sget v4, Lw0/D;->n:I

    .line 101
    .line 102
    invoke-virtual {v1}, Lw0/F;->g()Lw0/D;

    .line 103
    .line 104
    .line 105
    move-result-object v4

    .line 106
    invoke-static {v4}, Lb1/a;->s(Lw0/D;)Lw0/A;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    iget v4, v4, Lw0/A;->h:I

    .line 111
    .line 112
    move v15, v2

    .line 113
    :goto_3
    move v13, v4

    .line 114
    goto :goto_4

    .line 115
    :cond_2
    const/4 v4, -0x1

    .line 116
    move v15, v14

    .line 117
    goto :goto_3

    .line 118
    :goto_4
    new-instance v10, Lw0/H;

    .line 119
    .line 120
    const/4 v11, 0x1

    .line 121
    const/4 v12, 0x1

    .line 122
    invoke-direct/range {v10 .. v19}, Lw0/H;-><init>(ZZIZZIIII)V

    .line 123
    .line 124
    .line 125
    invoke-interface {v5}, Landroid/view/MenuItem;->getItemId()I

    .line 126
    .line 127
    .line 128
    move-result v4

    .line 129
    invoke-virtual {v1, v4, v14}, Lw0/F;->n(IZ)Z

    .line 130
    .line 131
    .line 132
    move-result v4

    .line 133
    if-eqz v4, :cond_3

    .line 134
    .line 135
    goto :goto_5

    .line 136
    :cond_3
    :try_start_0
    invoke-interface {v5}, Landroid/view/MenuItem;->getItemId()I

    .line 137
    .line 138
    .line 139
    move-result v4

    .line 140
    invoke-virtual {v1, v4, v6, v10}, Lw0/F;->j(ILandroid/os/Bundle;Lw0/H;)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v1}, Lw0/F;->f()Lw0/A;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    if-eqz v1, :cond_5

    .line 148
    .line 149
    invoke-interface {v5}, Landroid/view/MenuItem;->getItemId()I

    .line 150
    .line 151
    .line 152
    move-result v4

    .line 153
    invoke-static {v1, v4}, Lr3/e;->A(Lw0/A;I)Z

    .line 154
    .line 155
    .line 156
    move-result v1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 157
    if-ne v1, v2, :cond_5

    .line 158
    .line 159
    :cond_4
    :goto_5
    move v2, v3

    .line 160
    :catch_0
    :cond_5
    return v2

    .line 161
    :pswitch_0
    iget-object v1, v0, Ld5/h;->b:Ljava/lang/Object;

    .line 162
    .line 163
    check-cast v1, Landroidx/appcompat/widget/Toolbar;

    .line 164
    .line 165
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    return v3

    .line 169
    :pswitch_1
    iget-object v1, v0, Ld5/h;->b:Ljava/lang/Object;

    .line 170
    .line 171
    check-cast v1, Landroidx/appcompat/widget/ActionMenuView;

    .line 172
    .line 173
    iget-object v1, v1, Landroidx/appcompat/widget/ActionMenuView;->z:Lo/o;

    .line 174
    .line 175
    if-eqz v1, :cond_7

    .line 176
    .line 177
    check-cast v1, La9/h;

    .line 178
    .line 179
    iget-object v1, v1, La9/h;->b:Ljava/lang/Object;

    .line 180
    .line 181
    check-cast v1, Landroidx/appcompat/widget/Toolbar;

    .line 182
    .line 183
    iget-object v1, v1, Landroidx/appcompat/widget/Toolbar;->f0:Landroid/support/v4/media/session/z;

    .line 184
    .line 185
    iget-object v1, v1, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 186
    .line 187
    check-cast v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 188
    .line 189
    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 190
    .line 191
    .line 192
    move-result-object v1

    .line 193
    :cond_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 194
    .line 195
    .line 196
    move-result v4

    .line 197
    if-eqz v4, :cond_7

    .line 198
    .line 199
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    move-result-object v4

    .line 203
    check-cast v4, Lj0/J;

    .line 204
    .line 205
    iget-object v4, v4, Lj0/J;->a:Lj0/U;

    .line 206
    .line 207
    invoke-virtual {v4}, Lj0/U;->p()Z

    .line 208
    .line 209
    .line 210
    move-result v4

    .line 211
    if-eqz v4, :cond_6

    .line 212
    .line 213
    goto :goto_6

    .line 214
    :cond_7
    move v2, v3

    .line 215
    :goto_6
    return v2

    .line 216
    nop

    .line 217
    :pswitch_data_0
    .packed-switch 0xe
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public d(Ljava/lang/Object;)V
    .locals 5

    .line 1
    check-cast p1, Ljava/util/Map;

    .line 2
    .line 3
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lj0/U;

    .line 6
    .line 7
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const/4 v2, 0x0

    .line 12
    new-array v3, v2, [Ljava/lang/String;

    .line 13
    .line 14
    invoke-interface {v1, v3}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    check-cast v1, [Ljava/lang/String;

    .line 19
    .line 20
    new-instance v1, Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-direct {v1, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    new-array p1, p1, [I

    .line 34
    .line 35
    move v3, v2

    .line 36
    :goto_0
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    if-ge v3, v4, :cond_1

    .line 41
    .line 42
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    check-cast v4, Ljava/lang/Boolean;

    .line 47
    .line 48
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    if-eqz v4, :cond_0

    .line 53
    .line 54
    move v4, v2

    .line 55
    goto :goto_1

    .line 56
    :cond_0
    const/4 v4, -0x1

    .line 57
    :goto_1
    aput v4, p1, v3

    .line 58
    .line 59
    add-int/lit8 v3, v3, 0x1

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_1
    iget-object p1, v0, Lj0/U;->G:Ljava/util/ArrayDeque;

    .line 63
    .line 64
    invoke-virtual {p1}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    check-cast p1, Lj0/N;

    .line 69
    .line 70
    const-string v1, "FragmentManager"

    .line 71
    .line 72
    if-nez p1, :cond_2

    .line 73
    .line 74
    new-instance p1, Ljava/lang/StringBuilder;

    .line 75
    .line 76
    const-string v0, "No permissions were requested for "

    .line 77
    .line 78
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 89
    .line 90
    .line 91
    return-void

    .line 92
    :cond_2
    iget-object p1, p1, Lj0/N;->a:Ljava/lang/String;

    .line 93
    .line 94
    iget-object v0, v0, Lj0/U;->c:Lcom/google/firebase/messaging/s;

    .line 95
    .line 96
    invoke-virtual {v0, p1}, Lcom/google/firebase/messaging/s;->l(Ljava/lang/String;)Lj0/y;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    if-nez v0, :cond_3

    .line 101
    .line 102
    new-instance v0, Ljava/lang/StringBuilder;

    .line 103
    .line 104
    const-string v2, "Permission request result delivered for unknown Fragment "

    .line 105
    .line 106
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 117
    .line 118
    .line 119
    :cond_3
    return-void
.end method

.method public e(Ln/k;Landroid/view/MenuItem;)V
    .locals 0

    .line 1
    iget-object p2, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p2, Ln/e;

    .line 4
    .line 5
    iget-object p2, p2, Ln/e;->f:Landroid/os/Handler;

    .line 6
    .line 7
    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public f(Lcom/google/android/material/chip/ChipGroup;Ljava/util/ArrayList;)V
    .locals 0

    .line 1
    iget-object p1, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, Lcom/google/android/material/chip/ChipGroup;

    .line 4
    .line 5
    iget-object p2, p1, Lcom/google/android/material/chip/ChipGroup;->h:Lt4/a;

    .line 6
    .line 7
    iget-boolean p2, p2, Lt4/a;->d:Z

    .line 8
    .line 9
    if-nez p2, :cond_0

    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    invoke-virtual {p1}, Lcom/google/android/material/chip/ChipGroup;->getCheckedChipId()I

    .line 13
    .line 14
    .line 15
    const/4 p1, 0x0

    .line 16
    throw p1
.end method

.method public g(Ln/k;)V
    .locals 1

    .line 1
    iget v0, p0, Ld5/h;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    iget-object p1, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p1, Landroidx/appcompat/widget/Toolbar;

    .line 10
    .line 11
    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->a:Landroidx/appcompat/widget/ActionMenuView;

    .line 12
    .line 13
    iget-object v0, v0, Landroidx/appcompat/widget/ActionMenuView;->t:Lo/l;

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    invoke-virtual {v0}, Lo/l;->f()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    goto :goto_1

    .line 24
    :cond_0
    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->f0:Landroid/support/v4/media/session/z;

    .line 25
    .line 26
    iget-object p1, p1, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p1, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_1

    .line 39
    .line 40
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    check-cast v0, Lj0/J;

    .line 45
    .line 46
    iget-object v0, v0, Lj0/J;->a:Lj0/U;

    .line 47
    .line 48
    invoke-virtual {v0}, Lj0/U;->t()Z

    .line 49
    .line 50
    .line 51
    goto :goto_0

    .line 52
    :cond_1
    :goto_1
    return-void

    .line 53
    :pswitch_1
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v0, Landroidx/appcompat/widget/ActionMenuView;

    .line 56
    .line 57
    iget-object v0, v0, Landroidx/appcompat/widget/ActionMenuView;->u:Ld5/h;

    .line 58
    .line 59
    if-eqz v0, :cond_2

    .line 60
    .line 61
    invoke-virtual {v0, p1}, Ld5/h;->g(Ln/k;)V

    .line 62
    .line 63
    .line 64
    :cond_2
    return-void

    .line 65
    :pswitch_data_0
    .packed-switch 0xe
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public h(Ljava/lang/Object;)V
    .locals 11

    .line 1
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lq3/b;

    .line 4
    .line 5
    check-cast p1, Landroid/os/Bundle;

    .line 6
    .line 7
    const-string v1, "com.google.android.gms.cast.FLAG_CLIENT_SESSION_ANALYTICS_ENABLED"

    .line 8
    .line 9
    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const-string v2, "com.google.android.gms.cast.FLAG_CLIENT_FEATURE_USAGE_ANALYTICS_ENABLED"

    .line 14
    .line 15
    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    const/4 v3, 0x1

    .line 20
    if-nez v1, :cond_0

    .line 21
    .line 22
    if-eqz v2, :cond_3

    .line 23
    .line 24
    move v2, v3

    .line 25
    :cond_0
    iget-object v4, v0, Lq3/b;->a:Landroid/content/Context;

    .line 26
    .line 27
    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 32
    .line 33
    iget-object v5, v0, Lq3/b;->a:Landroid/content/Context;

    .line 34
    .line 35
    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    const-string v6, ".client_cast_analytics_data"

    .line 40
    .line 41
    invoke-static {v5, v6}, Lr6/a;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v5

    .line 45
    iget-object v6, v0, Lq3/b;->a:Landroid/content/Context;

    .line 46
    .line 47
    invoke-static {v6}, LU1/t;->b(Landroid/content/Context;)V

    .line 48
    .line 49
    .line 50
    invoke-static {}, LU1/t;->a()LU1/t;

    .line 51
    .line 52
    .line 53
    move-result-object v6

    .line 54
    sget-object v7, LS1/a;->e:LS1/a;

    .line 55
    .line 56
    invoke-virtual {v6, v7}, LU1/t;->c(LU1/m;)LU1/s;

    .line 57
    .line 58
    .line 59
    move-result-object v6

    .line 60
    sget-object v7, Lq3/i;->a:Lq3/i;

    .line 61
    .line 62
    const-string v8, "CAST_SENDER_SDK"

    .line 63
    .line 64
    const-string v9, "proto"

    .line 65
    .line 66
    new-instance v10, LR1/c;

    .line 67
    .line 68
    invoke-direct {v10, v9}, LR1/c;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {v6, v8, v10, v7}, LU1/s;->a(Ljava/lang/String;LR1/c;LR1/e;)LC1/b;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    const-string v7, "com.google.android.gms.cast.FLAG_FIRELOG_UPLOAD_MODE"

    .line 76
    .line 77
    invoke-virtual {p1, v7}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 78
    .line 79
    .line 80
    move-result-wide v7

    .line 81
    iget-object p1, v0, Lq3/b;->a:Landroid/content/Context;

    .line 82
    .line 83
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    const/4 v9, 0x0

    .line 88
    invoke-virtual {p1, v5, v9}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    new-instance v5, LE3/a;

    .line 93
    .line 94
    invoke-direct {v5, p1, v6, v7, v8}, LE3/a;-><init>(Landroid/content/SharedPreferences;LC1/b;J)V

    .line 95
    .line 96
    .line 97
    if-eqz v1, :cond_1

    .line 98
    .line 99
    iget-object v1, v0, Lq3/b;->a:Landroid/content/Context;

    .line 100
    .line 101
    new-instance v6, Lu3/p;

    .line 102
    .line 103
    invoke-direct {v6, v1}, Lu3/p;-><init>(Landroid/content/Context;)V

    .line 104
    .line 105
    .line 106
    const-string v1, "com.google.android.gms.cast.DICTIONARY_CAST_STATUS_CODES_TO_APP_SESSION_ERROR"

    .line 107
    .line 108
    const-string v7, "com.google.android.gms.cast.DICTIONARY_CAST_STATUS_CODES_TO_APP_SESSION_CHANGE_REASON"

    .line 109
    .line 110
    filled-new-array {v1, v7}, [Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    invoke-static {}, LD4/h;->g()LD4/h;

    .line 115
    .line 116
    .line 117
    move-result-object v7

    .line 118
    new-instance v8, Ls5/l;

    .line 119
    .line 120
    invoke-direct {v8, v6, v1}, Ls5/l;-><init>(Lu3/p;[Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    iput-object v8, v7, LD4/h;->d:Ljava/lang/Object;

    .line 124
    .line 125
    new-array v1, v3, [Lx3/d;

    .line 126
    .line 127
    sget-object v3, Lp3/y;->c:Lx3/d;

    .line 128
    .line 129
    aput-object v3, v1, v9

    .line 130
    .line 131
    iput-object v1, v7, LD4/h;->e:Ljava/lang/Object;

    .line 132
    .line 133
    iput-boolean v9, v7, LD4/h;->c:Z

    .line 134
    .line 135
    const/16 v1, 0x20ea

    .line 136
    .line 137
    iput v1, v7, LD4/h;->b:I

    .line 138
    .line 139
    invoke-virtual {v7}, LD4/h;->f()LD4/h;

    .line 140
    .line 141
    .line 142
    move-result-object v1

    .line 143
    invoke-virtual {v6, v9, v1}, Ly3/f;->c(ILD4/h;)Lb4/q;

    .line 144
    .line 145
    .line 146
    move-result-object v1

    .line 147
    new-instance v3, LY4/i;

    .line 148
    .line 149
    const/16 v6, 0x16

    .line 150
    .line 151
    invoke-direct {v3, v0, v5, p1, v6}, LY4/i;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 155
    .line 156
    .line 157
    sget-object v0, Lb4/j;->a:LU1/r;

    .line 158
    .line 159
    invoke-virtual {v1, v0, v3}, Lb4/q;->d(Ljava/util/concurrent/Executor;Lb4/e;)Lb4/q;

    .line 160
    .line 161
    .line 162
    :cond_1
    if-eqz v2, :cond_3

    .line 163
    .line 164
    sget-object v0, Lcom/google/android/gms/internal/cast/V;->i:Lcom/google/android/gms/internal/measurement/H1;

    .line 165
    .line 166
    const-class v0, Lcom/google/android/gms/internal/cast/V;

    .line 167
    .line 168
    monitor-enter v0

    .line 169
    :try_start_0
    sget-object v1, Lcom/google/android/gms/internal/cast/V;->k:Lcom/google/android/gms/internal/cast/V;

    .line 170
    .line 171
    if-nez v1, :cond_2

    .line 172
    .line 173
    new-instance v1, Lcom/google/android/gms/internal/cast/V;

    .line 174
    .line 175
    invoke-direct {v1, p1, v5, v4}, Lcom/google/android/gms/internal/cast/V;-><init>(Landroid/content/SharedPreferences;LE3/a;Ljava/lang/String;)V

    .line 176
    .line 177
    .line 178
    sput-object v1, Lcom/google/android/gms/internal/cast/V;->k:Lcom/google/android/gms/internal/cast/V;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 179
    .line 180
    goto :goto_0

    .line 181
    :catchall_0
    move-exception p1

    .line 182
    goto :goto_1

    .line 183
    :cond_2
    :goto_0
    monitor-exit v0

    .line 184
    sget-object p1, Lcom/google/android/gms/internal/cast/D;->g:Lcom/google/android/gms/internal/cast/D;

    .line 185
    .line 186
    invoke-static {p1}, Lcom/google/android/gms/internal/cast/V;->a(Lcom/google/android/gms/internal/cast/D;)V

    .line 187
    .line 188
    .line 189
    return-void

    .line 190
    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 191
    throw p1

    .line 192
    :cond_3
    return-void
.end method

.method public i(Ls5/q;)V
    .locals 2

    .line 1
    iput-object p1, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    const-string p1, "FirebaseCrashlytics"

    .line 4
    .line 5
    const/4 v0, 0x3

    .line 6
    invoke-static {p1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    const-string v0, "Registered Firebase Analytics event receiver for breadcrumbs"

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-static {p1, v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 16
    .line 17
    .line 18
    :cond_0
    return-void
.end method

.method public j(Ljava/lang/String;)Ljava/lang/Object;
    .locals 6

    .line 1
    const-string v0, "AndroidOpenSSL"

    .line 2
    .line 3
    const-string v1, "Conscrypt"

    .line 4
    .line 5
    const-string v2, "GmsCore_OpenSSL"

    .line 6
    .line 7
    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    new-instance v1, Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 14
    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    move v3, v2

    .line 18
    :goto_0
    const/4 v4, 0x3

    .line 19
    if-ge v3, v4, :cond_1

    .line 20
    .line 21
    aget-object v4, v0, v3

    .line 22
    .line 23
    invoke-static {v4}, Ljava/security/Security;->getProvider(Ljava/lang/String;)Ljava/security/Provider;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    if-eqz v4, :cond_0

    .line 28
    .line 29
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    const/4 v3, 0x0

    .line 40
    :cond_2
    :goto_1
    if-ge v2, v0, :cond_3

    .line 41
    .line 42
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    add-int/lit8 v2, v2, 0x1

    .line 47
    .line 48
    check-cast v4, Ljava/security/Provider;

    .line 49
    .line 50
    :try_start_0
    iget-object v5, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 51
    .line 52
    check-cast v5, Ld5/l;

    .line 53
    .line 54
    invoke-interface {v5, p1, v4}, Ld5/l;->e(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 58
    return-object p1

    .line 59
    :catch_0
    move-exception v4

    .line 60
    if-nez v3, :cond_2

    .line 61
    .line 62
    move-object v3, v4

    .line 63
    goto :goto_1

    .line 64
    :cond_3
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 65
    .line 66
    const-string v0, "No good Provider found."

    .line 67
    .line 68
    invoke-direct {p1, v0, v3}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 69
    .line 70
    .line 71
    throw p1
.end method

.method public k(LP8/i;Ljava/io/IOException;)V
    .locals 2

    .line 1
    iget-object p1, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, LO4/q;

    .line 4
    .line 5
    new-instance v0, LO4/c;

    .line 6
    .line 7
    invoke-direct {v0, p2}, LO4/c;-><init>(Ljava/lang/Throwable;)V

    .line 8
    .line 9
    .line 10
    sget-object p2, LO4/n;->f:Lf5/b;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    invoke-virtual {p2, p1, v1, v0}, Lf5/b;->h(LO4/n;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p2

    .line 17
    if-eqz p2, :cond_0

    .line 18
    .line 19
    invoke-static {p1}, LO4/n;->d(LO4/n;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method

.method public l(Landroid/graphics/Bitmap;)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p1, :cond_0

    .line 3
    .line 4
    goto :goto_0

    .line 5
    :cond_0
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    int-to-float v3, v1

    .line 14
    const/high16 v4, 0x41100000    # 9.0f

    .line 15
    .line 16
    mul-float/2addr v4, v3

    .line 17
    const/high16 v5, 0x41800000    # 16.0f

    .line 18
    .line 19
    div-float/2addr v4, v5

    .line 20
    const/high16 v5, 0x3f000000    # 0.5f

    .line 21
    .line 22
    add-float/2addr v4, v5

    .line 23
    float-to-int v4, v4

    .line 24
    sub-int v5, v4, v2

    .line 25
    .line 26
    div-int/lit8 v5, v5, 0x2

    .line 27
    .line 28
    int-to-float v5, v5

    .line 29
    new-instance v6, Landroid/graphics/RectF;

    .line 30
    .line 31
    int-to-float v2, v2

    .line 32
    add-float/2addr v2, v5

    .line 33
    const/4 v7, 0x0

    .line 34
    invoke-direct {v6, v7, v5, v3, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    if-nez v2, :cond_1

    .line 42
    .line 43
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 44
    .line 45
    :cond_1
    invoke-static {v1, v4, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    new-instance v2, Landroid/graphics/Canvas;

    .line 50
    .line 51
    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v2, p1, v0, v6, v0}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 55
    .line 56
    .line 57
    move-object v0, v1

    .line 58
    :goto_0
    iget-object p1, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p1, Ls3/g;

    .line 61
    .line 62
    const/4 v1, 0x0

    .line 63
    invoke-virtual {p1, v0, v1}, Ls3/g;->d(Landroid/graphics/Bitmap;I)V

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public m(Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 9

    .line 1
    const-string v0, "$A$:"

    .line 2
    .line 3
    iget-object v1, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Ls5/q;

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    :try_start_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 10
    .line 11
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-static {p1, p2}, Ld5/h;->w(Ljava/lang/String;Landroid/os/Bundle;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v7

    .line 25
    iget-object v4, v1, Ls5/q;->a:Ls5/s;

    .line 26
    .line 27
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 28
    .line 29
    .line 30
    move-result-wide p1

    .line 31
    iget-wide v0, v4, Ls5/s;->d:J

    .line 32
    .line 33
    sub-long v5, p1, v0

    .line 34
    .line 35
    iget-object p1, v4, Ls5/s;->o:Lt5/d;

    .line 36
    .line 37
    iget-object p1, p1, Lt5/d;->a:Lt5/b;

    .line 38
    .line 39
    new-instance v3, Ls5/r;

    .line 40
    .line 41
    const/4 v8, 0x0

    .line 42
    invoke-direct/range {v3 .. v8}, Ls5/r;-><init>(Ls5/s;JLjava/lang/String;I)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1, v3}, Lt5/b;->a(Ljava/lang/Runnable;)Lb4/q;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :catch_0
    const/4 p1, 0x0

    .line 50
    const-string p2, "FirebaseCrashlytics"

    .line 51
    .line 52
    const-string v0, "Unable to serialize Firebase Analytics event to breadcrumb."

    .line 53
    .line 54
    invoke-static {p2, v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 55
    .line 56
    .line 57
    :cond_0
    return-void
.end method

.method public n(Ln/k;Ln/m;)V
    .locals 10

    .line 1
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ln/e;

    .line 4
    .line 5
    iget-object v1, v0, Ln/e;->f:Landroid/os/Handler;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, v0, Ln/e;->h:Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    const/4 v4, 0x0

    .line 18
    :goto_0
    const/4 v5, -0x1

    .line 19
    if-ge v4, v3, :cond_1

    .line 20
    .line 21
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    check-cast v6, Ln/d;

    .line 26
    .line 27
    iget-object v6, v6, Ln/d;->b:Ln/k;

    .line 28
    .line 29
    if-ne p1, v6, :cond_0

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    move v4, v5

    .line 36
    :goto_1
    if-ne v4, v5, :cond_2

    .line 37
    .line 38
    return-void

    .line 39
    :cond_2
    add-int/lit8 v4, v4, 0x1

    .line 40
    .line 41
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-ge v4, v3, :cond_3

    .line 46
    .line 47
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    move-object v2, v0

    .line 52
    check-cast v2, Ln/d;

    .line 53
    .line 54
    :cond_3
    move-object v5, v2

    .line 55
    new-instance v3, LH0/y;

    .line 56
    .line 57
    const/16 v8, 0xb

    .line 58
    .line 59
    const/4 v9, 0x0

    .line 60
    move-object v4, p0

    .line 61
    move-object v7, p1

    .line 62
    move-object v6, p2

    .line 63
    invoke-direct/range {v3 .. v9}, LH0/y;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 64
    .line 65
    .line 66
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 67
    .line 68
    .line 69
    move-result-wide p1

    .line 70
    const-wide/16 v4, 0xc8

    .line 71
    .line 72
    add-long/2addr p1, v4

    .line 73
    invoke-virtual {v1, v3, v7, p1, p2}, Landroid/os/Handler;->postAtTime(Ljava/lang/Runnable;Ljava/lang/Object;J)Z

    .line 74
    .line 75
    .line 76
    return-void
.end method

.method public o(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 1
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/maertsno/exoplayer/StyledPlayerView;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lcom/maertsno/exoplayer/StyledPlayerView;->setDefaultArtwork(Landroid/graphics/drawable/Drawable;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public p(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, Landroidx/lifecycle/v;

    .line 2
    .line 3
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lj0/q;

    .line 6
    .line 7
    if-eqz p1, :cond_2

    .line 8
    .line 9
    iget-boolean p1, v0, Lj0/q;->B0:Z

    .line 10
    .line 11
    if-eqz p1, :cond_2

    .line 12
    .line 13
    invoke-virtual {v0}, Lj0/y;->b0()Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    if-nez v1, :cond_1

    .line 22
    .line 23
    iget-object v1, v0, Lj0/q;->F0:Landroid/app/Dialog;

    .line 24
    .line 25
    if-eqz v1, :cond_2

    .line 26
    .line 27
    const/4 v1, 0x3

    .line 28
    invoke-static {v1}, Lj0/U;->L(I)Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_0

    .line 33
    .line 34
    new-instance v1, Ljava/lang/StringBuilder;

    .line 35
    .line 36
    const-string v2, "DialogFragment "

    .line 37
    .line 38
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    const-string v2, " setting the content view on "

    .line 45
    .line 46
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    iget-object v2, v0, Lj0/q;->F0:Landroid/app/Dialog;

    .line 50
    .line 51
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    const-string v2, "FragmentManager"

    .line 59
    .line 60
    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 61
    .line 62
    .line 63
    :cond_0
    iget-object v0, v0, Lj0/q;->F0:Landroid/app/Dialog;

    .line 64
    .line 65
    invoke-virtual {v0, p1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 66
    .line 67
    .line 68
    return-void

    .line 69
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 70
    .line 71
    const-string v0, "DialogFragment can not be attached to a container view"

    .line 72
    .line 73
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    throw p1

    .line 77
    :cond_2
    return-void
.end method

.method public q(LL8/H;)V
    .locals 3

    .line 1
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LO4/q;

    .line 4
    .line 5
    sget-object v1, LO4/n;->f:Lf5/b;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-virtual {v1, v0, v2, p1}, Lf5/b;->h(LO4/n;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    invoke-static {v0}, LO4/n;->d(LO4/n;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public r()Lp3/n;
    .locals 3

    .line 1
    new-instance v0, Lp3/n;

    .line 2
    .line 3
    iget-object v1, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lp3/n;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iget-object v2, v1, Lp3/n;->a:Ljava/lang/String;

    .line 11
    .line 12
    iput-object v2, v0, Lp3/n;->a:Ljava/lang/String;

    .line 13
    .line 14
    iget-object v2, v1, Lp3/n;->b:Ljava/lang/String;

    .line 15
    .line 16
    iput-object v2, v0, Lp3/n;->b:Ljava/lang/String;

    .line 17
    .line 18
    iget v2, v1, Lp3/n;->c:I

    .line 19
    .line 20
    iput v2, v0, Lp3/n;->c:I

    .line 21
    .line 22
    iget-object v2, v1, Lp3/n;->d:Ljava/lang/String;

    .line 23
    .line 24
    iput-object v2, v0, Lp3/n;->d:Ljava/lang/String;

    .line 25
    .line 26
    iget-object v2, v1, Lp3/n;->e:Lp3/m;

    .line 27
    .line 28
    iput-object v2, v0, Lp3/n;->e:Lp3/m;

    .line 29
    .line 30
    iget v2, v1, Lp3/n;->f:I

    .line 31
    .line 32
    iput v2, v0, Lp3/n;->f:I

    .line 33
    .line 34
    iget-object v2, v1, Lp3/n;->g:Ljava/util/ArrayList;

    .line 35
    .line 36
    iput-object v2, v0, Lp3/n;->g:Ljava/util/ArrayList;

    .line 37
    .line 38
    iget v2, v1, Lp3/n;->h:I

    .line 39
    .line 40
    iput v2, v0, Lp3/n;->h:I

    .line 41
    .line 42
    iget-wide v1, v1, Lp3/n;->i:J

    .line 43
    .line 44
    iput-wide v1, v0, Lp3/n;->i:J

    .line 45
    .line 46
    return-object v0
.end method

.method public t(Ljava/lang/Exception;)V
    .locals 4

    .line 1
    const-string v0, "MediaCodecAudioRenderer"

    .line 2
    .line 3
    const-string v1, "Audio sink error"

    .line 4
    .line 5
    invoke-static {v0, v1, p1}, Lh3/a;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lh2/H;

    .line 11
    .line 12
    iget-object v0, v0, Lh2/H;->b1:Lh2/m;

    .line 13
    .line 14
    iget-object v1, v0, Lh2/m;->b:Landroid/os/Handler;

    .line 15
    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    new-instance v2, Lh2/k;

    .line 19
    .line 20
    const/4 v3, 0x6

    .line 21
    invoke-direct {v2, v0, p1, v3}, Lh2/k;-><init>(Lh2/m;Ljava/lang/Object;I)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 25
    .line 26
    .line 27
    :cond_0
    return-void
.end method

.method public x(Ljava/lang/Object;)Lb4/q;
    .locals 3

    .line 1
    check-cast p1, LA5/c;

    .line 2
    .line 3
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ls5/k;

    .line 6
    .line 7
    iget-object v0, v0, Ls5/k;->e:Ls5/o;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    if-nez p1, :cond_0

    .line 11
    .line 12
    const-string p1, "Received null app settings, cannot send reports at crash time."

    .line 13
    .line 14
    const-string v0, "FirebaseCrashlytics"

    .line 15
    .line 16
    invoke-static {v0, p1, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 17
    .line 18
    .line 19
    invoke-static {v1}, Lf5/b;->s(Ljava/lang/Object;)Lb4/q;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1

    .line 24
    :cond_0
    invoke-static {v0}, Ls5/o;->a(Ls5/o;)Lb4/q;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    iget-object v2, v0, Ls5/o;->m:Lo/Y0;

    .line 29
    .line 30
    iget-object v0, v0, Ls5/o;->e:Lt5/d;

    .line 31
    .line 32
    iget-object v0, v0, Lt5/d;->a:Lt5/b;

    .line 33
    .line 34
    invoke-virtual {v2, v0, v1}, Lo/Y0;->m(Ljava/util/concurrent/Executor;Ljava/lang/String;)Lb4/q;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    const/4 v1, 0x2

    .line 39
    new-array v1, v1, [Lb4/h;

    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    aput-object p1, v1, v2

    .line 43
    .line 44
    const/4 p1, 0x1

    .line 45
    aput-object v0, v1, p1

    .line 46
    .line 47
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-static {p1}, Lf5/b;->O(Ljava/util/List;)Lb4/q;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    return-object p1
.end method

.method public y(Lorg/json/JSONObject;)V
    .locals 14

    .line 1
    iget-object v0, p0, Ld5/h;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lp3/n;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    iput-object v1, v0, Lp3/n;->a:Ljava/lang/String;

    .line 7
    .line 8
    iput-object v1, v0, Lp3/n;->b:Ljava/lang/String;

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    iput v2, v0, Lp3/n;->c:I

    .line 12
    .line 13
    iput-object v1, v0, Lp3/n;->d:Ljava/lang/String;

    .line 14
    .line 15
    iput v2, v0, Lp3/n;->f:I

    .line 16
    .line 17
    iput-object v1, v0, Lp3/n;->g:Ljava/util/ArrayList;

    .line 18
    .line 19
    iput v2, v0, Lp3/n;->h:I

    .line 20
    .line 21
    const-wide/16 v3, -0x1

    .line 22
    .line 23
    iput-wide v3, v0, Lp3/n;->i:J

    .line 24
    .line 25
    if-nez p1, :cond_0

    .line 26
    .line 27
    goto/16 :goto_7

    .line 28
    .line 29
    :cond_0
    const-string v3, "id"

    .line 30
    .line 31
    invoke-static {p1, v3}, Lu3/a;->a(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    iput-object v3, v0, Lp3/n;->a:Ljava/lang/String;

    .line 36
    .line 37
    const-string v3, "entity"

    .line 38
    .line 39
    invoke-static {p1, v3}, Lu3/a;->a(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    iput-object v3, v0, Lp3/n;->b:Ljava/lang/String;

    .line 44
    .line 45
    const-string v3, "queueType"

    .line 46
    .line 47
    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 52
    .line 53
    .line 54
    move-result v4

    .line 55
    const/4 v5, -0x1

    .line 56
    const/4 v6, 0x4

    .line 57
    const/4 v7, 0x3

    .line 58
    const/4 v8, 0x2

    .line 59
    const/4 v9, 0x5

    .line 60
    const/16 v10, 0x8

    .line 61
    .line 62
    const/4 v11, 0x6

    .line 63
    const/4 v12, 0x7

    .line 64
    const/4 v13, 0x1

    .line 65
    sparse-switch v4, :sswitch_data_0

    .line 66
    .line 67
    .line 68
    goto/16 :goto_0

    .line 69
    .line 70
    :sswitch_0
    const-string v4, "LIVE_TV"

    .line 71
    .line 72
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v3

    .line 76
    if-eqz v3, :cond_1

    .line 77
    .line 78
    move v3, v12

    .line 79
    goto :goto_1

    .line 80
    :sswitch_1
    const-string v4, "VIDEO_PLAYLIST"

    .line 81
    .line 82
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    if-eqz v3, :cond_1

    .line 87
    .line 88
    move v3, v11

    .line 89
    goto :goto_1

    .line 90
    :sswitch_2
    const-string v4, "MOVIE"

    .line 91
    .line 92
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v3

    .line 96
    if-eqz v3, :cond_1

    .line 97
    .line 98
    move v3, v10

    .line 99
    goto :goto_1

    .line 100
    :sswitch_3
    const-string v4, "ALBUM"

    .line 101
    .line 102
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 103
    .line 104
    .line 105
    move-result v3

    .line 106
    if-eqz v3, :cond_1

    .line 107
    .line 108
    move v3, v2

    .line 109
    goto :goto_1

    .line 110
    :sswitch_4
    const-string v4, "TV_SERIES"

    .line 111
    .line 112
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 113
    .line 114
    .line 115
    move-result v3

    .line 116
    if-eqz v3, :cond_1

    .line 117
    .line 118
    move v3, v9

    .line 119
    goto :goto_1

    .line 120
    :sswitch_5
    const-string v4, "AUDIOBOOK"

    .line 121
    .line 122
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v3

    .line 126
    if-eqz v3, :cond_1

    .line 127
    .line 128
    move v3, v8

    .line 129
    goto :goto_1

    .line 130
    :sswitch_6
    const-string v4, "PLAYLIST"

    .line 131
    .line 132
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result v3

    .line 136
    if-eqz v3, :cond_1

    .line 137
    .line 138
    move v3, v13

    .line 139
    goto :goto_1

    .line 140
    :sswitch_7
    const-string v4, "RADIO_STATION"

    .line 141
    .line 142
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 143
    .line 144
    .line 145
    move-result v3

    .line 146
    if-eqz v3, :cond_1

    .line 147
    .line 148
    move v3, v7

    .line 149
    goto :goto_1

    .line 150
    :sswitch_8
    const-string v4, "PODCAST_SERIES"

    .line 151
    .line 152
    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result v3

    .line 156
    if-eqz v3, :cond_1

    .line 157
    .line 158
    move v3, v6

    .line 159
    goto :goto_1

    .line 160
    :cond_1
    :goto_0
    move v3, v5

    .line 161
    :goto_1
    packed-switch v3, :pswitch_data_0

    .line 162
    .line 163
    .line 164
    goto :goto_2

    .line 165
    :pswitch_0
    const/16 v3, 0x9

    .line 166
    .line 167
    iput v3, v0, Lp3/n;->c:I

    .line 168
    .line 169
    goto :goto_2

    .line 170
    :pswitch_1
    iput v10, v0, Lp3/n;->c:I

    .line 171
    .line 172
    goto :goto_2

    .line 173
    :pswitch_2
    iput v12, v0, Lp3/n;->c:I

    .line 174
    .line 175
    goto :goto_2

    .line 176
    :pswitch_3
    iput v11, v0, Lp3/n;->c:I

    .line 177
    .line 178
    goto :goto_2

    .line 179
    :pswitch_4
    iput v9, v0, Lp3/n;->c:I

    .line 180
    .line 181
    goto :goto_2

    .line 182
    :pswitch_5
    iput v6, v0, Lp3/n;->c:I

    .line 183
    .line 184
    goto :goto_2

    .line 185
    :pswitch_6
    iput v7, v0, Lp3/n;->c:I

    .line 186
    .line 187
    goto :goto_2

    .line 188
    :pswitch_7
    iput v8, v0, Lp3/n;->c:I

    .line 189
    .line 190
    goto :goto_2

    .line 191
    :pswitch_8
    iput v13, v0, Lp3/n;->c:I

    .line 192
    .line 193
    :goto_2
    const-string v3, "name"

    .line 194
    .line 195
    invoke-static {p1, v3}, Lu3/a;->a(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v3

    .line 199
    iput-object v3, v0, Lp3/n;->d:Ljava/lang/String;

    .line 200
    .line 201
    const-string v3, "containerMetadata"

    .line 202
    .line 203
    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 204
    .line 205
    .line 206
    move-result v4

    .line 207
    if-eqz v4, :cond_2

    .line 208
    .line 209
    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    .line 210
    .line 211
    .line 212
    move-result-object v3

    .line 213
    goto :goto_3

    .line 214
    :cond_2
    move-object v3, v1

    .line 215
    :goto_3
    if-eqz v3, :cond_c

    .line 216
    .line 217
    const-string v4, "containerType"

    .line 218
    .line 219
    const-string v6, ""

    .line 220
    .line 221
    invoke-virtual {v3, v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object v4

    .line 225
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    .line 226
    .line 227
    .line 228
    move-result v6

    .line 229
    const v7, 0x69a7c1

    .line 230
    .line 231
    .line 232
    if-eq v6, v7, :cond_4

    .line 233
    .line 234
    const v7, 0x316473d9

    .line 235
    .line 236
    .line 237
    if-eq v6, v7, :cond_3

    .line 238
    .line 239
    goto :goto_4

    .line 240
    :cond_3
    const-string v6, "GENERIC_CONTAINER"

    .line 241
    .line 242
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 243
    .line 244
    .line 245
    move-result v4

    .line 246
    if-eqz v4, :cond_5

    .line 247
    .line 248
    move v5, v2

    .line 249
    goto :goto_4

    .line 250
    :cond_4
    const-string v6, "AUDIOBOOK_CONTAINER"

    .line 251
    .line 252
    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 253
    .line 254
    .line 255
    move-result v4

    .line 256
    if-eqz v4, :cond_5

    .line 257
    .line 258
    move v5, v13

    .line 259
    :cond_5
    :goto_4
    if-eqz v5, :cond_6

    .line 260
    .line 261
    if-eq v5, v13, :cond_7

    .line 262
    .line 263
    :cond_6
    move v13, v2

    .line 264
    :cond_7
    const-string v4, "title"

    .line 265
    .line 266
    invoke-static {v3, v4}, Lu3/a;->a(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    .line 267
    .line 268
    .line 269
    move-result-object v4

    .line 270
    const-string v5, "sections"

    .line 271
    .line 272
    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 273
    .line 274
    .line 275
    move-result-object v5

    .line 276
    if-eqz v5, :cond_9

    .line 277
    .line 278
    new-instance v6, Ljava/util/ArrayList;

    .line 279
    .line 280
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 281
    .line 282
    .line 283
    move v7, v2

    .line 284
    :goto_5
    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    .line 285
    .line 286
    .line 287
    move-result v8

    .line 288
    if-ge v7, v8, :cond_a

    .line 289
    .line 290
    invoke-virtual {v5, v7}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    .line 291
    .line 292
    .line 293
    move-result-object v8

    .line 294
    if-eqz v8, :cond_8

    .line 295
    .line 296
    new-instance v9, Lp3/l;

    .line 297
    .line 298
    invoke-direct {v9, v2}, Lp3/l;-><init>(I)V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v9, v8}, Lp3/l;->r(Lorg/json/JSONObject;)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 305
    .line 306
    .line 307
    :cond_8
    add-int/lit8 v7, v7, 0x1

    .line 308
    .line 309
    goto :goto_5

    .line 310
    :cond_9
    move-object v6, v1

    .line 311
    :cond_a
    const-string v5, "containerImages"

    .line 312
    .line 313
    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 314
    .line 315
    .line 316
    move-result-object v5

    .line 317
    if-eqz v5, :cond_b

    .line 318
    .line 319
    new-instance v1, Ljava/util/ArrayList;

    .line 320
    .line 321
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 322
    .line 323
    .line 324
    invoke-static {v1, v5}, Lv3/a;->b(Ljava/util/List;Lorg/json/JSONArray;)V

    .line 325
    .line 326
    .line 327
    :cond_b
    const-string v5, "containerDuration"

    .line 328
    .line 329
    const-wide/16 v7, 0x0

    .line 330
    .line 331
    invoke-virtual {v3, v5, v7, v8}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    .line 332
    .line 333
    .line 334
    move-result-wide v7

    .line 335
    new-instance v3, Lp3/m;

    .line 336
    .line 337
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 338
    .line 339
    .line 340
    iput v13, v3, Lp3/m;->a:I

    .line 341
    .line 342
    iput-object v4, v3, Lp3/m;->b:Ljava/lang/String;

    .line 343
    .line 344
    iput-object v6, v3, Lp3/m;->c:Ljava/util/List;

    .line 345
    .line 346
    iput-object v1, v3, Lp3/m;->d:Ljava/util/List;

    .line 347
    .line 348
    iput-wide v7, v3, Lp3/m;->e:D

    .line 349
    .line 350
    iput-object v3, v0, Lp3/n;->e:Lp3/m;

    .line 351
    .line 352
    :cond_c
    const-string v1, "repeatMode"

    .line 353
    .line 354
    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object v1

    .line 358
    invoke-static {v1}, LT8/d;->o(Ljava/lang/String;)Ljava/lang/Integer;

    .line 359
    .line 360
    .line 361
    move-result-object v1

    .line 362
    if-eqz v1, :cond_d

    .line 363
    .line 364
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 365
    .line 366
    .line 367
    move-result v1

    .line 368
    iput v1, v0, Lp3/n;->f:I

    .line 369
    .line 370
    :cond_d
    const-string v1, "items"

    .line 371
    .line 372
    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    .line 373
    .line 374
    .line 375
    move-result-object v1

    .line 376
    if-eqz v1, :cond_f

    .line 377
    .line 378
    new-instance v3, Ljava/util/ArrayList;

    .line 379
    .line 380
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 381
    .line 382
    .line 383
    iput-object v3, v0, Lp3/n;->g:Ljava/util/ArrayList;

    .line 384
    .line 385
    :goto_6
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    .line 386
    .line 387
    .line 388
    move-result v4

    .line 389
    if-ge v2, v4, :cond_f

    .line 390
    .line 391
    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    .line 392
    .line 393
    .line 394
    move-result-object v4

    .line 395
    if-eqz v4, :cond_e

    .line 396
    .line 397
    :try_start_0
    new-instance v5, Lp3/o;

    .line 398
    .line 399
    invoke-direct {v5, v4}, Lp3/o;-><init>(Lorg/json/JSONObject;)V

    .line 400
    .line 401
    .line 402
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 403
    .line 404
    .line 405
    :catch_0
    :cond_e
    add-int/lit8 v2, v2, 0x1

    .line 406
    .line 407
    goto :goto_6

    .line 408
    :cond_f
    const-string v1, "startIndex"

    .line 409
    .line 410
    iget v2, v0, Lp3/n;->h:I

    .line 411
    .line 412
    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    .line 413
    .line 414
    .line 415
    move-result v1

    .line 416
    iput v1, v0, Lp3/n;->h:I

    .line 417
    .line 418
    const-string v1, "startTime"

    .line 419
    .line 420
    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 421
    .line 422
    .line 423
    move-result v2

    .line 424
    if-eqz v2, :cond_10

    .line 425
    .line 426
    iget-wide v2, v0, Lp3/n;->i:J

    .line 427
    .line 428
    long-to-double v2, v2

    .line 429
    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optDouble(Ljava/lang/String;D)D

    .line 430
    .line 431
    .line 432
    move-result-wide v1

    .line 433
    const-wide v3, 0x408f400000000000L    # 1000.0

    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    mul-double/2addr v1, v3

    .line 439
    double-to-long v1, v1

    .line 440
    iput-wide v1, v0, Lp3/n;->i:J

    .line 441
    .line 442
    :cond_10
    :goto_7
    return-void

    .line 443
    :sswitch_data_0
    .sparse-switch
        -0x6b79e7ce -> :sswitch_8
        -0x68d6bb50 -> :sswitch_7
        -0x61538e2e -> :sswitch_6
        -0x4ea9f461 -> :sswitch_5
        -0x40e1912c -> :sswitch_4
        0x3b7864f -> :sswitch_3
        0x4624710 -> :sswitch_2
        0x176e3d36 -> :sswitch_1
        0x35c80eb5 -> :sswitch_0
    .end sparse-switch

    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
