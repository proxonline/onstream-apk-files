.class public interface abstract Ld5/l;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract e(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
.end method
