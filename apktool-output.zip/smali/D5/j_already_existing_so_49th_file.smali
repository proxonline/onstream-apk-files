.class public final Ld5/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:Ld5/j;

.field public static final c:Ld5/j;


# instance fields
.field public final a:Ld5/i;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Ld5/j;

    .line 2
    .line 3
    new-instance v1, Ld5/k;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v1, v2}, Ld5/k;-><init>(I)V

    .line 7
    .line 8
    .line 9
    invoke-direct {v0, v1}, Ld5/j;-><init>(Ld5/l;)V

    .line 10
    .line 11
    .line 12
    sput-object v0, Ld5/j;->b:Ld5/j;

    .line 13
    .line 14
    new-instance v0, Ld5/j;

    .line 15
    .line 16
    new-instance v1, Ld5/k;

    .line 17
    .line 18
    const/4 v2, 0x2

    .line 19
    invoke-direct {v1, v2}, Ld5/k;-><init>(I)V

    .line 20
    .line 21
    .line 22
    invoke-direct {v0, v1}, Ld5/j;-><init>(Ld5/l;)V

    .line 23
    .line 24
    .line 25
    sput-object v0, Ld5/j;->c:Ld5/j;

    .line 26
    .line 27
    new-instance v0, Ld5/j;

    .line 28
    .line 29
    new-instance v1, Ld5/k;

    .line 30
    .line 31
    const/4 v2, 0x3

    .line 32
    invoke-direct {v1, v2}, Ld5/k;-><init>(I)V

    .line 33
    .line 34
    .line 35
    invoke-direct {v0, v1}, Ld5/j;-><init>(Ld5/l;)V

    .line 36
    .line 37
    .line 38
    new-instance v0, Ld5/j;

    .line 39
    .line 40
    new-instance v1, Ld2/b;

    .line 41
    .line 42
    invoke-direct {v1, v2}, Ld2/b;-><init>(I)V

    .line 43
    .line 44
    .line 45
    invoke-direct {v0, v1}, Ld5/j;-><init>(Ld5/l;)V

    .line 46
    .line 47
    .line 48
    new-instance v0, Ld5/j;

    .line 49
    .line 50
    new-instance v1, Ld2/b;

    .line 51
    .line 52
    const/4 v2, 0x1

    .line 53
    invoke-direct {v1, v2}, Ld2/b;-><init>(I)V

    .line 54
    .line 55
    .line 56
    invoke-direct {v0, v1}, Ld5/j;-><init>(Ld5/l;)V

    .line 57
    .line 58
    .line 59
    new-instance v0, Ld5/j;

    .line 60
    .line 61
    new-instance v1, Ld2/b;

    .line 62
    .line 63
    const/4 v2, 0x2

    .line 64
    invoke-direct {v1, v2}, Ld2/b;-><init>(I)V

    .line 65
    .line 66
    .line 67
    invoke-direct {v0, v1}, Ld5/j;-><init>(Ld5/l;)V

    .line 68
    .line 69
    .line 70
    new-instance v0, Ld5/j;

    .line 71
    .line 72
    new-instance v1, Ld5/k;

    .line 73
    .line 74
    const/4 v2, 0x1

    .line 75
    invoke-direct {v1, v2}, Ld5/k;-><init>(I)V

    .line 76
    .line 77
    .line 78
    invoke-direct {v0, v1}, Ld5/j;-><init>(Ld5/l;)V

    .line 79
    .line 80
    .line 81
    return-void
.end method

.method public constructor <init>(Ld5/l;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {}, LU4/a;->a()Z

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    new-instance v0, Ld5/h;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    invoke-direct {v0, v1, p1}, Ld5/h;-><init>(ILjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Ld5/j;->a:Ld5/i;

    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    const-string v0, "java.vendor"

    .line 20
    .line 21
    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    const-string v1, "The Android Project"

    .line 26
    .line 27
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_1

    .line 32
    .line 33
    new-instance v0, La9/u;

    .line 34
    .line 35
    const/4 v1, 0x7

    .line 36
    invoke-direct {v0, v1, p1}, La9/u;-><init>(ILjava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    iput-object v0, p0, Ld5/j;->a:Ld5/i;

    .line 40
    .line 41
    return-void

    .line 42
    :cond_1
    new-instance v0, La9/h;

    .line 43
    .line 44
    const/16 v1, 0x8

    .line 45
    .line 46
    invoke-direct {v0, v1, p1}, La9/h;-><init>(ILjava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iput-object v0, p0, Ld5/j;->a:Ld5/i;

    .line 50
    .line 51
    return-void
.end method
