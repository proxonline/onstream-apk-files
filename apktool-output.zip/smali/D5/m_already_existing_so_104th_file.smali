.class public interface abstract Ld5/m;
.super Ljava/lang/Object;
.source "SourceFile"
