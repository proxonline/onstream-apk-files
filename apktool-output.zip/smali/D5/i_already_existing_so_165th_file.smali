.class public interface abstract Ld5/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract j(Ljava/lang/String;)Ljava/lang/Object;
.end method
