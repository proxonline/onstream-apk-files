.class public Ld2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld2/a;
.implements Ld5/l;
.implements Lg3/K;
.implements Lj2/o;
.implements Lm5/d;
.implements Lm2/l;
.implements Ln/v;
.implements Lv2/g;
.implements Lx6/l;


# static fields
.field public static final synthetic b:Ld2/b;


# instance fields
.field public final synthetic a:I


# direct methods
.method public static synthetic constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ld2/b;

    .line 2
    .line 3
    const/16 v1, 0x10

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ld2/b;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Ld2/b;->b:Ld2/b;

    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Ld2/b;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ld2/b;)V
    .locals 0

    const/16 p1, 0x1d

    iput p1, p0, Ld2/b;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static v(Lcom/maertsno/data/model/response/ListEpisodeResponse;)Ly6/w;
    .locals 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-string v1, "dto"

    .line 4
    .line 5
    invoke-static {v0, v1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lcom/maertsno/data/model/response/ListEpisodeResponse;->b:Ljava/util/List;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    invoke-static {v1}, Le8/i;->r0(Ljava/util/List;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    check-cast v3, Lcom/maertsno/data/model/response/ContinueWatchResponse;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v3, 0x0

    .line 20
    :goto_0
    iget-object v0, v0, Lcom/maertsno/data/model/response/ListEpisodeResponse;->a:Ljava/util/List;

    .line 21
    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    sget-object v0, Le8/q;->a:Le8/q;

    .line 25
    .line 26
    :cond_1
    new-instance v4, Ljava/util/ArrayList;

    .line 27
    .line 28
    invoke-static {v0}, Le8/k;->Z(Ljava/lang/Iterable;)I

    .line 29
    .line 30
    .line 31
    move-result v5

    .line 32
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 33
    .line 34
    .line 35
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    .line 41
    .line 42
    move-result v5

    .line 43
    if-eqz v5, :cond_12

    .line 44
    .line 45
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    check-cast v5, Lcom/maertsno/data/model/response/EpisodeResponse;

    .line 50
    .line 51
    if-eqz v1, :cond_5

    .line 52
    .line 53
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 54
    .line 55
    .line 56
    move-result-object v6

    .line 57
    :cond_2
    :goto_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    .line 59
    .line 60
    move-result v7

    .line 61
    if-eqz v7, :cond_4

    .line 62
    .line 63
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v7

    .line 67
    move-object v8, v7

    .line 68
    check-cast v8, Lcom/maertsno/data/model/response/ContinueWatchResponse;

    .line 69
    .line 70
    iget-object v8, v8, Lcom/maertsno/data/model/response/ContinueWatchResponse;->e:Ljava/lang/Long;

    .line 71
    .line 72
    iget-wide v9, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->a:J

    .line 73
    .line 74
    if-nez v8, :cond_3

    .line 75
    .line 76
    goto :goto_2

    .line 77
    :cond_3
    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    .line 78
    .line 79
    .line 80
    move-result-wide v11

    .line 81
    cmp-long v8, v11, v9

    .line 82
    .line 83
    if-nez v8, :cond_2

    .line 84
    .line 85
    goto :goto_3

    .line 86
    :cond_4
    const/4 v7, 0x0

    .line 87
    :goto_3
    check-cast v7, Lcom/maertsno/data/model/response/ContinueWatchResponse;

    .line 88
    .line 89
    goto :goto_4

    .line 90
    :cond_5
    const/4 v7, 0x0

    .line 91
    :goto_4
    new-instance v8, Lcom/maertsno/domain/model/Episode;

    .line 92
    .line 93
    iget-wide v9, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->a:J

    .line 94
    .line 95
    iget-object v6, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->b:Ljava/lang/Long;

    .line 96
    .line 97
    if-eqz v6, :cond_6

    .line 98
    .line 99
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 100
    .line 101
    .line 102
    move-result-wide v13

    .line 103
    goto :goto_5

    .line 104
    :cond_6
    const-wide/16 v13, -0x1

    .line 105
    .line 106
    :goto_5
    iget-object v6, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->c:Ljava/lang/String;

    .line 107
    .line 108
    const-string v15, ""

    .line 109
    .line 110
    if-nez v6, :cond_7

    .line 111
    .line 112
    move-object v6, v15

    .line 113
    :cond_7
    const-string v2, "{width}x{height}"

    .line 114
    .line 115
    const-string v11, "500x281"

    .line 116
    .line 117
    invoke-static {v6, v2, v11}, Lz8/m;->Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    iget-object v6, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->d:Ljava/lang/Long;

    .line 122
    .line 123
    if-eqz v6, :cond_8

    .line 124
    .line 125
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 126
    .line 127
    .line 128
    move-result-wide v11

    .line 129
    goto :goto_6

    .line 130
    :cond_8
    const-wide/16 v11, -0x1

    .line 131
    .line 132
    :goto_6
    iget-object v6, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->e:Ljava/lang/String;

    .line 133
    .line 134
    if-nez v6, :cond_9

    .line 135
    .line 136
    move-object/from16 v16, v15

    .line 137
    .line 138
    goto :goto_7

    .line 139
    :cond_9
    move-object/from16 v16, v6

    .line 140
    .line 141
    :goto_7
    iget-object v6, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->f:Ljava/lang/Long;

    .line 142
    .line 143
    const-wide/16 v17, 0x0

    .line 144
    .line 145
    if-eqz v6, :cond_a

    .line 146
    .line 147
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 148
    .line 149
    .line 150
    move-result-wide v19

    .line 151
    goto :goto_8

    .line 152
    :cond_a
    move-wide/from16 v19, v17

    .line 153
    .line 154
    :goto_8
    iget-object v6, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->g:Ljava/lang/String;

    .line 155
    .line 156
    if-nez v6, :cond_b

    .line 157
    .line 158
    goto :goto_9

    .line 159
    :cond_b
    move-object v15, v6

    .line 160
    :goto_9
    iget-object v6, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->h:Ljava/lang/Integer;

    .line 161
    .line 162
    const/16 v21, 0x0

    .line 163
    .line 164
    if-eqz v6, :cond_c

    .line 165
    .line 166
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 167
    .line 168
    .line 169
    move-result v6

    .line 170
    goto :goto_a

    .line 171
    :cond_c
    move/from16 v6, v21

    .line 172
    .line 173
    :goto_a
    move-object/from16 p0, v0

    .line 174
    .line 175
    if-eqz v7, :cond_d

    .line 176
    .line 177
    iget-object v0, v7, Lcom/maertsno/data/model/response/ContinueWatchResponse;->h:Ljava/lang/Long;

    .line 178
    .line 179
    if-eqz v0, :cond_d

    .line 180
    .line 181
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 182
    .line 183
    .line 184
    move-result-wide v17

    .line 185
    :cond_d
    if-eqz v7, :cond_e

    .line 186
    .line 187
    iget-object v0, v7, Lcom/maertsno/data/model/response/ContinueWatchResponse;->i:Ljava/lang/Double;

    .line 188
    .line 189
    if-eqz v0, :cond_e

    .line 190
    .line 191
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 192
    .line 193
    .line 194
    move-result-wide v22

    .line 195
    invoke-static/range {v22 .. v23}, Lf5/b;->I(D)I

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    move/from16 v23, v0

    .line 200
    .line 201
    goto :goto_b

    .line 202
    :cond_e
    move/from16 v23, v21

    .line 203
    .line 204
    :goto_b
    if-eqz v3, :cond_11

    .line 205
    .line 206
    iget-object v0, v3, Lcom/maertsno/data/model/response/ContinueWatchResponse;->e:Ljava/lang/Long;

    .line 207
    .line 208
    move-object/from16 v22, v0

    .line 209
    .line 210
    move-object v7, v1

    .line 211
    iget-wide v0, v5, Lcom/maertsno/data/model/response/EpisodeResponse;->a:J

    .line 212
    .line 213
    if-nez v22, :cond_f

    .line 214
    .line 215
    goto :goto_c

    .line 216
    :cond_f
    invoke-virtual/range {v22 .. v22}, Ljava/lang/Long;->longValue()J

    .line 217
    .line 218
    .line 219
    move-result-wide v25

    .line 220
    cmp-long v0, v25, v0

    .line 221
    .line 222
    if-nez v0, :cond_10

    .line 223
    .line 224
    const/16 v21, 0x1

    .line 225
    .line 226
    :cond_10
    :goto_c
    move/from16 v24, v21

    .line 227
    .line 228
    move-wide/from16 v21, v17

    .line 229
    .line 230
    move-wide/from16 v17, v19

    .line 231
    .line 232
    move/from16 v20, v6

    .line 233
    .line 234
    move-object/from16 v19, v15

    .line 235
    .line 236
    move-wide/from16 v27, v13

    .line 237
    .line 238
    move-object v13, v2

    .line 239
    move-wide v14, v11

    .line 240
    move-wide/from16 v11, v27

    .line 241
    .line 242
    goto :goto_d

    .line 243
    :cond_11
    move-object v7, v1

    .line 244
    goto :goto_c

    .line 245
    :goto_d
    invoke-direct/range {v8 .. v24}, Lcom/maertsno/domain/model/Episode;-><init>(JJLjava/lang/String;JLjava/lang/String;JLjava/lang/String;IJIZ)V

    .line 246
    .line 247
    .line 248
    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 249
    .line 250
    .line 251
    move-object/from16 v0, p0

    .line 252
    .line 253
    move-object v1, v7

    .line 254
    goto/16 :goto_1

    .line 255
    .line 256
    :cond_12
    new-instance v0, Ly6/w;

    .line 257
    .line 258
    invoke-direct {v0, v4}, Ly6/w;-><init>(Ljava/util/ArrayList;)V

    .line 259
    .line 260
    .line 261
    return-object v0
.end method


# virtual methods
.method public synthetic a()V
    .locals 0

    .line 1
    return-void
.end method

.method public synthetic b()V
    .locals 0

    .line 1
    return-void
.end method

.method public c(Ln/k;Z)V
    .locals 0

    .line 1
    return-void
.end method

.method public d()V
    .locals 4

    .line 1
    sget-object v0, Lh3/a;->h:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    sget-object v1, Lh3/a;->i:Ljava/lang/Object;

    .line 5
    .line 6
    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    :try_start_1
    sget-boolean v2, Lh3/a;->j:Z

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 12
    :try_start_2
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 13
    return-void

    .line 14
    :catchall_0
    move-exception v1

    .line 15
    goto :goto_1

    .line 16
    :catchall_1
    move-exception v2

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 19
    :try_start_4
    invoke-static {}, Lh3/a;->a()J

    .line 20
    .line 21
    .line 22
    move-result-wide v2

    .line 23
    monitor-enter v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 24
    :try_start_5
    sput-wide v2, Lh3/a;->k:J

    .line 25
    .line 26
    const/4 v2, 0x1

    .line 27
    sput-boolean v2, Lh3/a;->j:Z

    .line 28
    .line 29
    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 30
    :try_start_6
    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 31
    return-void

    .line 32
    :catchall_2
    move-exception v2

    .line 33
    :try_start_7
    monitor-exit v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 34
    :try_start_8
    throw v2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 35
    :goto_0
    :try_start_9
    monitor-exit v1
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    .line 36
    :try_start_a
    throw v2

    .line 37
    :goto_1
    monitor-exit v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    .line 38
    throw v1
.end method

.method public e(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Ld2/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    if-nez p2, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-static {p1, p2}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/MessageDigest;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    :goto_0
    return-object p1

    .line 18
    :pswitch_0
    if-nez p2, :cond_1

    .line 19
    .line 20
    invoke-static {p1}, Ljava/security/KeyPairGenerator;->getInstance(Ljava/lang/String;)Ljava/security/KeyPairGenerator;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    goto :goto_1

    .line 25
    :cond_1
    invoke-static {p1, p2}, Ljava/security/KeyPairGenerator;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/KeyPairGenerator;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    :goto_1
    return-object p1

    .line 30
    :pswitch_1
    if-nez p2, :cond_2

    .line 31
    .line 32
    invoke-static {p1}, Ljavax/crypto/KeyAgreement;->getInstance(Ljava/lang/String;)Ljavax/crypto/KeyAgreement;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    goto :goto_2

    .line 37
    :cond_2
    invoke-static {p1, p2}, Ljavax/crypto/KeyAgreement;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljavax/crypto/KeyAgreement;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    :goto_2
    return-object p1

    .line 42
    nop

    .line 43
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public f(Lm2/r;)V
    .locals 0

    .line 1
    return-void
.end method

.method public g()V
    .locals 0

    .line 1
    return-void
.end method

.method public h(Lm2/k;)J
    .locals 2

    .line 1
    const-wide/16 v0, -0x1

    .line 2
    .line 3
    return-wide v0
.end method

.method public synthetic i(Lj2/l;Lf2/N;)Lj2/n;
    .locals 0

    .line 1
    sget-object p1, Lj2/n;->W:Lg2/e;

    return-object p1
.end method

.method public j(Landroid/os/Looper;Lg2/m;)V
    .locals 0

    .line 1
    return-void
.end method

.method public k()Lm2/r;
    .locals 3

    .line 1
    new-instance v0, Lm2/m;

    .line 2
    .line 3
    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1, v2}, Lm2/m;-><init>(J)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public synthetic l(LC1/b;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-static {p1}, Lcom/google/firebase/analytics/connector/internal/AnalyticsConnectorRegistrar;->zza(Lm5/c;)Lj5/b;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    return-object p1
.end method

.method public m(Ln/k;)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return p1
.end method

.method public n()J
    .locals 2

    .line 1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    return-wide v0
.end method

.method public o()V
    .locals 0

    .line 1
    return-void
.end method

.method public p(J)V
    .locals 0

    .line 1
    return-void
.end method

.method public q(Lf2/N;)I
    .locals 0

    .line 1
    iget-object p1, p1, Lf2/N;->o:Lj2/g;

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    return p1

    .line 7
    :cond_0
    const/4 p1, 0x0

    .line 8
    return p1
.end method

.method public r(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget v0, p0, Ld2/b;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/maertsno/data/model/response/ListSeasonResponse;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Ld2/b;->x(Lcom/maertsno/data/model/response/ListSeasonResponse;)Ly6/y;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    return-object p1

    .line 13
    :pswitch_0
    check-cast p1, Lcom/maertsno/data/model/response/PlayerResponse;

    .line 14
    .line 15
    const-string v0, "dto"

    .line 16
    .line 17
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    new-instance v1, Ly6/C;

    .line 21
    .line 22
    iget-wide v2, p1, Lcom/maertsno/data/model/response/PlayerResponse;->a:J

    .line 23
    .line 24
    iget-object v0, p1, Lcom/maertsno/data/model/response/PlayerResponse;->b:Ljava/lang/String;

    .line 25
    .line 26
    const-string v4, ""

    .line 27
    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    move-object v0, v4

    .line 31
    :cond_0
    iget-object v5, p1, Lcom/maertsno/data/model/response/PlayerResponse;->c:Ljava/lang/String;

    .line 32
    .line 33
    if-nez v5, :cond_1

    .line 34
    .line 35
    move-object v5, v4

    .line 36
    :cond_1
    iget-object v6, p1, Lcom/maertsno/data/model/response/PlayerResponse;->d:Ljava/lang/Integer;

    .line 37
    .line 38
    const/4 v7, 0x0

    .line 39
    const/4 v8, 0x1

    .line 40
    if-nez v6, :cond_2

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_2
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 44
    .line 45
    .line 46
    move-result v6

    .line 47
    if-ne v6, v8, :cond_3

    .line 48
    .line 49
    move v6, v8

    .line 50
    goto :goto_1

    .line 51
    :cond_3
    :goto_0
    move v6, v7

    .line 52
    :goto_1
    iget-object v9, p1, Lcom/maertsno/data/model/response/PlayerResponse;->e:Ljava/lang/Integer;

    .line 53
    .line 54
    if-nez v9, :cond_4

    .line 55
    .line 56
    goto :goto_2

    .line 57
    :cond_4
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 58
    .line 59
    .line 60
    move-result v9

    .line 61
    if-ne v9, v8, :cond_5

    .line 62
    .line 63
    goto :goto_3

    .line 64
    :cond_5
    :goto_2
    move v8, v7

    .line 65
    :goto_3
    iget-object v9, p1, Lcom/maertsno/data/model/response/PlayerResponse;->f:Ljava/lang/Integer;

    .line 66
    .line 67
    if-eqz v9, :cond_6

    .line 68
    .line 69
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 70
    .line 71
    .line 72
    move-result v7

    .line 73
    :cond_6
    iget-object v9, p1, Lcom/maertsno/data/model/response/PlayerResponse;->h:Ljava/lang/String;

    .line 74
    .line 75
    if-nez v9, :cond_7

    .line 76
    .line 77
    move-object v9, v4

    .line 78
    :cond_7
    iget-object p1, p1, Lcom/maertsno/data/model/response/PlayerResponse;->g:Ljava/lang/String;

    .line 79
    .line 80
    if-nez p1, :cond_8

    .line 81
    .line 82
    move v10, v8

    .line 83
    move v8, v7

    .line 84
    move v7, v10

    .line 85
    move-object v10, v4

    .line 86
    :goto_4
    move-object v4, v0

    .line 87
    goto :goto_5

    .line 88
    :cond_8
    move v4, v8

    .line 89
    move v8, v7

    .line 90
    move v7, v4

    .line 91
    move-object v10, p1

    .line 92
    goto :goto_4

    .line 93
    :goto_5
    invoke-direct/range {v1 .. v10}, Ly6/C;-><init>(JLjava/lang/String;Ljava/lang/String;ZZILjava/lang/String;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    return-object v1

    .line 97
    :pswitch_1
    check-cast p1, Lcom/maertsno/data/model/response/LoginCodeResponse;

    .line 98
    .line 99
    const-string v0, "dto"

    .line 100
    .line 101
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    iget-object p1, p1, Lcom/maertsno/data/model/response/LoginCodeResponse;->a:Ljava/lang/String;

    .line 105
    .line 106
    if-nez p1, :cond_9

    .line 107
    .line 108
    const-string p1, ""

    .line 109
    .line 110
    :cond_9
    return-object p1

    .line 111
    :pswitch_2
    check-cast p1, Lcom/maertsno/data/model/response/ListEpisodeResponse;

    .line 112
    .line 113
    invoke-static {p1}, Ld2/b;->v(Lcom/maertsno/data/model/response/ListEpisodeResponse;)Ly6/w;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    return-object p1

    .line 118
    :pswitch_3
    check-cast p1, Lcom/maertsno/data/model/response/DownloaderResponse;

    .line 119
    .line 120
    const-string v0, "dto"

    .line 121
    .line 122
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    new-instance v0, Ly6/f;

    .line 126
    .line 127
    iget-object v1, p1, Lcom/maertsno/data/model/response/DownloaderResponse;->a:Ljava/lang/Integer;

    .line 128
    .line 129
    if-nez v1, :cond_a

    .line 130
    .line 131
    goto :goto_6

    .line 132
    :cond_a
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 133
    .line 134
    .line 135
    move-result v1

    .line 136
    const/4 v2, 0x1

    .line 137
    if-ne v1, v2, :cond_b

    .line 138
    .line 139
    goto :goto_7

    .line 140
    :cond_b
    :goto_6
    const/4 v2, 0x0

    .line 141
    :goto_7
    iget-object v1, p1, Lcom/maertsno/data/model/response/DownloaderResponse;->b:Ljava/lang/String;

    .line 142
    .line 143
    const-string v3, ""

    .line 144
    .line 145
    if-nez v1, :cond_c

    .line 146
    .line 147
    move-object v1, v3

    .line 148
    :cond_c
    iget-object p1, p1, Lcom/maertsno/data/model/response/DownloaderResponse;->c:Ljava/lang/String;

    .line 149
    .line 150
    if-nez p1, :cond_d

    .line 151
    .line 152
    goto :goto_8

    .line 153
    :cond_d
    move-object v3, p1

    .line 154
    :goto_8
    invoke-direct {v0, v1, v3, v2}, Ly6/f;-><init>(Ljava/lang/String;Ljava/lang/String;Z)V

    .line 155
    .line 156
    .line 157
    return-object v0

    .line 158
    nop

    .line 159
    :pswitch_data_0
    .packed-switch 0x19
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public s(Lj2/l;Lf2/N;)Lj2/i;
    .locals 2

    .line 1
    iget-object p1, p2, Lf2/N;->o:Lj2/g;

    .line 2
    .line 3
    if-nez p1, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    return-object p1

    .line 7
    :cond_0
    new-instance p1, Lj2/s;

    .line 8
    .line 9
    new-instance p2, Lj2/h;

    .line 10
    .line 11
    new-instance v0, Lj2/C;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    .line 14
    .line 15
    .line 16
    const/16 v1, 0x1771

    .line 17
    .line 18
    invoke-direct {p2, v0, v1}, Lj2/h;-><init>(Ljava/lang/Exception;I)V

    .line 19
    .line 20
    .line 21
    invoke-direct {p1, p2}, Lj2/s;-><init>(Lj2/h;)V

    .line 22
    .line 23
    .line 24
    return-object p1
.end method

.method public t(FF)F
    .locals 0

    .line 1
    const/high16 p1, 0x3f800000    # 1.0f

    .line 2
    .line 3
    return p1
.end method

.method public u(Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;
    .locals 1

    .line 1
    const/16 v0, 0x40

    .line 2
    .line 3
    invoke-virtual {p1, p2, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    iget-object p1, p1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    .line 8
    .line 9
    return-object p1
.end method

.method public w(II)Lm2/u;
    .locals 0

    .line 1
    new-instance p1, Lm2/i;

    .line 2
    .line 3
    invoke-direct {p1}, Lm2/i;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object p1
.end method

.method public x(Lcom/maertsno/data/model/response/ListSeasonResponse;)Ly6/y;
    .locals 18

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    const-string v1, "dto"

    .line 4
    .line 5
    invoke-static {v0, v1}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lcom/maertsno/data/model/response/ListSeasonResponse;->b:Ljava/util/List;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    invoke-static {v1}, Le8/i;->r0(Ljava/util/List;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    check-cast v2, Lcom/maertsno/data/model/response/ContinueWatchResponse;

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const/4 v2, 0x0

    .line 20
    :goto_0
    iget-object v0, v0, Lcom/maertsno/data/model/response/ListSeasonResponse;->a:Ljava/util/List;

    .line 21
    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    sget-object v0, Le8/q;->a:Le8/q;

    .line 25
    .line 26
    :cond_1
    new-instance v3, Ljava/util/ArrayList;

    .line 27
    .line 28
    invoke-static {v0}, Le8/k;->Z(Ljava/lang/Iterable;)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 33
    .line 34
    .line 35
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 40
    .line 41
    .line 42
    move-result v4

    .line 43
    if-eqz v4, :cond_9

    .line 44
    .line 45
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    check-cast v4, Lcom/maertsno/data/model/response/SeasonResponse;

    .line 50
    .line 51
    new-instance v5, Ly6/E;

    .line 52
    .line 53
    iget-wide v6, v4, Lcom/maertsno/data/model/response/SeasonResponse;->a:J

    .line 54
    .line 55
    iget-object v8, v4, Lcom/maertsno/data/model/response/SeasonResponse;->f:Ljava/util/List;

    .line 56
    .line 57
    iget-object v9, v4, Lcom/maertsno/data/model/response/SeasonResponse;->d:Ljava/lang/Integer;

    .line 58
    .line 59
    if-eqz v9, :cond_2

    .line 60
    .line 61
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 62
    .line 63
    .line 64
    move-result v9

    .line 65
    goto :goto_2

    .line 66
    :cond_2
    const/4 v9, 0x0

    .line 67
    :goto_2
    iget-object v11, v4, Lcom/maertsno/data/model/response/SeasonResponse;->b:Ljava/lang/String;

    .line 68
    .line 69
    const-string v12, ""

    .line 70
    .line 71
    if-nez v11, :cond_3

    .line 72
    .line 73
    move-object v11, v12

    .line 74
    :cond_3
    if-eqz v8, :cond_4

    .line 75
    .line 76
    invoke-interface {v8}, Ljava/util/List;->size()I

    .line 77
    .line 78
    .line 79
    move-result v13

    .line 80
    goto :goto_3

    .line 81
    :cond_4
    const/4 v13, 0x0

    .line 82
    :goto_3
    iget-object v14, v4, Lcom/maertsno/data/model/response/SeasonResponse;->e:Ljava/lang/String;

    .line 83
    .line 84
    if-nez v14, :cond_5

    .line 85
    .line 86
    goto :goto_4

    .line 87
    :cond_5
    move-object v12, v14

    .line 88
    :goto_4
    if-eqz v2, :cond_8

    .line 89
    .line 90
    iget-object v14, v2, Lcom/maertsno/data/model/response/ContinueWatchResponse;->d:Ljava/lang/Long;

    .line 91
    .line 92
    move-object v15, v11

    .line 93
    iget-wide v10, v4, Lcom/maertsno/data/model/response/SeasonResponse;->a:J

    .line 94
    .line 95
    if-nez v14, :cond_6

    .line 96
    .line 97
    goto :goto_5

    .line 98
    :cond_6
    invoke-virtual {v14}, Ljava/lang/Long;->longValue()J

    .line 99
    .line 100
    .line 101
    move-result-wide v16

    .line 102
    cmp-long v4, v16, v10

    .line 103
    .line 104
    if-nez v4, :cond_7

    .line 105
    .line 106
    const/4 v10, 0x1

    .line 107
    goto :goto_6

    .line 108
    :cond_7
    :goto_5
    const/4 v10, 0x0

    .line 109
    goto :goto_6

    .line 110
    :cond_8
    move-object v15, v11

    .line 111
    goto :goto_5

    .line 112
    :goto_6
    new-instance v4, Lcom/maertsno/data/model/response/ListEpisodeResponse;

    .line 113
    .line 114
    invoke-direct {v4, v8, v1}, Lcom/maertsno/data/model/response/ListEpisodeResponse;-><init>(Ljava/util/List;Ljava/util/List;)V

    .line 115
    .line 116
    .line 117
    invoke-static {v4}, Ld2/b;->v(Lcom/maertsno/data/model/response/ListEpisodeResponse;)Ly6/w;

    .line 118
    .line 119
    .line 120
    move-result-object v4

    .line 121
    iget-object v4, v4, Ly6/w;->a:Ljava/util/ArrayList;

    .line 122
    .line 123
    move v8, v9

    .line 124
    move-object v11, v12

    .line 125
    move-object v9, v15

    .line 126
    move v12, v10

    .line 127
    move v10, v13

    .line 128
    move-object v13, v4

    .line 129
    invoke-direct/range {v5 .. v13}, Ly6/E;-><init>(JILjava/lang/String;ILjava/lang/String;ZLjava/util/List;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    goto :goto_1

    .line 136
    :cond_9
    new-instance v0, Ly6/y;

    .line 137
    .line 138
    invoke-direct {v0, v3}, Ly6/y;-><init>(Ljava/util/ArrayList;)V

    .line 139
    .line 140
    .line 141
    return-object v0
.end method

.method public y(Lcom/google/firebase/components/ComponentRegistrar;)Ljava/util/List;
    .locals 10

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-interface {p1}, Lcom/google/firebase/components/ComponentRegistrar;->getComponents()Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_1

    .line 19
    .line 20
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    check-cast v1, Lm5/b;

    .line 25
    .line 26
    iget-object v3, v1, Lm5/b;->a:Ljava/lang/String;

    .line 27
    .line 28
    if-eqz v3, :cond_0

    .line 29
    .line 30
    new-instance v8, LB7/e;

    .line 31
    .line 32
    const/16 v2, 0x15

    .line 33
    .line 34
    invoke-direct {v8, v3, v2, v1}, LB7/e;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    new-instance v2, Lm5/b;

    .line 38
    .line 39
    iget-object v4, v1, Lm5/b;->b:Ljava/util/Set;

    .line 40
    .line 41
    iget-object v5, v1, Lm5/b;->c:Ljava/util/Set;

    .line 42
    .line 43
    iget v6, v1, Lm5/b;->d:I

    .line 44
    .line 45
    iget v7, v1, Lm5/b;->e:I

    .line 46
    .line 47
    iget-object v9, v1, Lm5/b;->g:Ljava/util/Set;

    .line 48
    .line 49
    invoke-direct/range {v2 .. v9}, Lm5/b;-><init>(Ljava/lang/String;Ljava/util/Set;Ljava/util/Set;IILm5/d;Ljava/util/Set;)V

    .line 50
    .line 51
    .line 52
    move-object v1, v2

    .line 53
    :cond_0
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_1
    return-object v0
.end method
