.class public interface abstract Lh3/m;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lf2/n0;)V
.end method

.method public abstract c()Lf2/n0;
.end method

.method public abstract d()J
.end method
