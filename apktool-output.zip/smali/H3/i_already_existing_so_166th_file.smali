.class public interface abstract Lh3/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract invoke(Ljava/lang/Object;)V
.end method
