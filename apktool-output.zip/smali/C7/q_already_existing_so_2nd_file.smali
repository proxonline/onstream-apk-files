.class public final synthetic LC7/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG4/h;
.implements Lm5/d;
.implements LE2/g;
.implements LH4/B;
.implements Lf2/e;
.implements LX4/b;
.implements LR1/g;
.implements Lb4/g;
.implements LX4/m;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LC7/q;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LX4/p;)LQ4/b;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget v2, v0, LC7/q;->a:I

    .line 6
    .line 7
    const/16 v3, 0xc

    .line 8
    .line 9
    const-string v4, "Invalid key size %d; only 16-byte, 24-byte and 32-byte AES keys are supported"

    .line 10
    .line 11
    const/16 v5, 0x18

    .line 12
    .line 13
    const/16 v6, 0x20

    .line 14
    .line 15
    const/16 v8, 0x10

    .line 16
    .line 17
    const/4 v9, 0x0

    .line 18
    const-string v10, "Unable to parse OutputPrefixType: "

    .line 19
    .line 20
    const/4 v11, 0x4

    .line 21
    const/4 v12, 0x3

    .line 22
    const/4 v13, 0x2

    .line 23
    const-string v14, "Only version 0 keys are accepted"

    .line 24
    .line 25
    const/16 v15, 0x8

    .line 26
    .line 27
    const/16 v16, 0x0

    .line 28
    .line 29
    const/4 v7, 0x1

    .line 30
    packed-switch v2, :pswitch_data_0

    .line 31
    .line 32
    .line 33
    iget-object v2, v1, LX4/p;->a:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v2, Ljava/lang/String;

    .line 36
    .line 37
    const-string v3, "type.googleapis.com/google.crypto.tink.AesCmacKey"

    .line 38
    .line 39
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    if-eqz v2, :cond_2

    .line 44
    .line 45
    :try_start_0
    iget-object v2, v1, LX4/p;->d:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v2, Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 48
    .line 49
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/n;->a()Lcom/google/crypto/tink/shaded/protobuf/n;

    .line 50
    .line 51
    .line 52
    move-result-object v3

    .line 53
    invoke-static {v2, v3}, Lc5/b;->D(Lcom/google/crypto/tink/shaded/protobuf/h;Lcom/google/crypto/tink/shaded/protobuf/n;)Lc5/b;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    invoke-virtual {v2}, Lc5/b;->B()I

    .line 58
    .line 59
    .line 60
    move-result v3

    .line 61
    if-nez v3, :cond_1

    .line 62
    .line 63
    new-instance v3, Landroid/support/v4/media/session/z;

    .line 64
    .line 65
    const/16 v4, 0x1d

    .line 66
    .line 67
    invoke-direct {v3, v4}, Landroid/support/v4/media/session/z;-><init>(I)V

    .line 68
    .line 69
    .line 70
    iput-object v9, v3, Landroid/support/v4/media/session/z;->b:Ljava/lang/Object;

    .line 71
    .line 72
    iput-object v9, v3, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 73
    .line 74
    sget-object v4, LY4/c;->f:LY4/c;

    .line 75
    .line 76
    iput-object v4, v3, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 77
    .line 78
    invoke-virtual {v2}, Lc5/b;->z()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    invoke-virtual {v4}, Lcom/google/crypto/tink/shaded/protobuf/h;->size()I

    .line 83
    .line 84
    .line 85
    move-result v4

    .line 86
    invoke-virtual {v3, v4}, Landroid/support/v4/media/session/z;->K(I)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v2}, Lc5/b;->A()Lc5/f;

    .line 90
    .line 91
    .line 92
    move-result-object v4

    .line 93
    invoke-virtual {v4}, Lc5/f;->y()I

    .line 94
    .line 95
    .line 96
    move-result v4

    .line 97
    const/16 v5, 0xa

    .line 98
    .line 99
    if-lt v4, v5, :cond_0

    .line 100
    .line 101
    if-lt v8, v4, :cond_0

    .line 102
    .line 103
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 104
    .line 105
    .line 106
    move-result-object v4

    .line 107
    iput-object v4, v3, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 108
    .line 109
    iget-object v4, v1, LX4/p;->f:Ljava/lang/Object;

    .line 110
    .line 111
    check-cast v4, Lc5/r0;

    .line 112
    .line 113
    invoke-static {v4}, LY4/e;->a(Lc5/r0;)LY4/c;

    .line 114
    .line 115
    .line 116
    move-result-object v4

    .line 117
    iput-object v4, v3, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 118
    .line 119
    invoke-virtual {v3}, Landroid/support/v4/media/session/z;->q()LY4/d;

    .line 120
    .line 121
    .line 122
    move-result-object v3

    .line 123
    new-instance v4, Landroid/support/v4/media/session/z;

    .line 124
    .line 125
    const/16 v5, 0x1c

    .line 126
    .line 127
    invoke-direct {v4, v5}, Landroid/support/v4/media/session/z;-><init>(I)V

    .line 128
    .line 129
    .line 130
    iput-object v9, v4, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 131
    .line 132
    iput-object v9, v4, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 133
    .line 134
    iput-object v3, v4, Landroid/support/v4/media/session/z;->b:Ljava/lang/Object;

    .line 135
    .line 136
    invoke-virtual {v2}, Lc5/b;->z()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 137
    .line 138
    .line 139
    move-result-object v2

    .line 140
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/h;->l()[B

    .line 141
    .line 142
    .line 143
    move-result-object v2

    .line 144
    new-instance v3, La9/u;

    .line 145
    .line 146
    invoke-static {v2}, Le5/a;->a([B)Le5/a;

    .line 147
    .line 148
    .line 149
    move-result-object v2

    .line 150
    invoke-direct {v3, v15, v2}, La9/u;-><init>(ILjava/lang/Object;)V

    .line 151
    .line 152
    .line 153
    iput-object v3, v4, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 154
    .line 155
    iget-object v1, v1, LX4/p;->b:Ljava/lang/Object;

    .line 156
    .line 157
    check-cast v1, Ljava/lang/Integer;

    .line 158
    .line 159
    iput-object v1, v4, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 160
    .line 161
    invoke-virtual {v4}, Landroid/support/v4/media/session/z;->p()LY4/a;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    return-object v1

    .line 166
    :cond_0
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 167
    .line 168
    const-string v2, "Invalid tag size for AesCmacParameters: "

    .line 169
    .line 170
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/cast/z1;->k(Ljava/lang/String;I)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v2

    .line 174
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    throw v1

    .line 178
    :cond_1
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 179
    .line 180
    invoke-direct {v1, v14}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    throw v1
    :try_end_0
    .catch Lcom/google/crypto/tink/shaded/protobuf/B; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 184
    :catch_0
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 185
    .line 186
    const-string v2, "Parsing AesCmacKey failed"

    .line 187
    .line 188
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    throw v1

    .line 192
    :cond_2
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 193
    .line 194
    const-string v2, "Wrong type URL in call to AesCmacParameters.parseParameters"

    .line 195
    .line 196
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 197
    .line 198
    .line 199
    throw v1

    .line 200
    :pswitch_0
    iget-object v2, v1, LX4/p;->a:Ljava/lang/Object;

    .line 201
    .line 202
    check-cast v2, Ljava/lang/String;

    .line 203
    .line 204
    const-string v3, "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key"

    .line 205
    .line 206
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 207
    .line 208
    .line 209
    move-result v2

    .line 210
    if-eqz v2, :cond_8

    .line 211
    .line 212
    :try_start_1
    iget-object v2, v1, LX4/p;->d:Ljava/lang/Object;

    .line 213
    .line 214
    check-cast v2, Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 215
    .line 216
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/n;->a()Lcom/google/crypto/tink/shaded/protobuf/n;

    .line 217
    .line 218
    .line 219
    move-result-object v3

    .line 220
    invoke-static {v2, v3}, Lc5/u0;->B(Lcom/google/crypto/tink/shaded/protobuf/h;Lcom/google/crypto/tink/shaded/protobuf/n;)Lc5/u0;

    .line 221
    .line 222
    .line 223
    move-result-object v2

    .line 224
    invoke-virtual {v2}, Lc5/u0;->z()I

    .line 225
    .line 226
    .line 227
    move-result v3

    .line 228
    if-nez v3, :cond_7

    .line 229
    .line 230
    iget-object v3, v1, LX4/p;->f:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast v3, Lc5/r0;

    .line 233
    .line 234
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 235
    .line 236
    .line 237
    move-result v4

    .line 238
    if-eq v4, v7, :cond_6

    .line 239
    .line 240
    if-eq v4, v13, :cond_5

    .line 241
    .line 242
    if-eq v4, v12, :cond_4

    .line 243
    .line 244
    if-ne v4, v11, :cond_3

    .line 245
    .line 246
    goto :goto_0

    .line 247
    :cond_3
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 248
    .line 249
    new-instance v2, Ljava/lang/StringBuilder;

    .line 250
    .line 251
    invoke-direct {v2, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v3}, Lc5/r0;->b()I

    .line 255
    .line 256
    .line 257
    move-result v3

    .line 258
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 259
    .line 260
    .line 261
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 262
    .line 263
    .line 264
    move-result-object v2

    .line 265
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 266
    .line 267
    .line 268
    throw v1

    .line 269
    :cond_4
    sget-object v3, LR4/j;->q:LR4/j;

    .line 270
    .line 271
    goto :goto_1

    .line 272
    :cond_5
    :goto_0
    sget-object v3, LR4/j;->p:LR4/j;

    .line 273
    .line 274
    goto :goto_1

    .line 275
    :cond_6
    sget-object v3, LR4/j;->o:LR4/j;

    .line 276
    .line 277
    :goto_1
    invoke-virtual {v2}, Lc5/u0;->y()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 278
    .line 279
    .line 280
    move-result-object v2

    .line 281
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/h;->l()[B

    .line 282
    .line 283
    .line 284
    move-result-object v2

    .line 285
    new-instance v4, La9/u;

    .line 286
    .line 287
    invoke-static {v2}, Le5/a;->a([B)Le5/a;

    .line 288
    .line 289
    .line 290
    move-result-object v2

    .line 291
    invoke-direct {v4, v15, v2}, La9/u;-><init>(ILjava/lang/Object;)V

    .line 292
    .line 293
    .line 294
    iget-object v1, v1, LX4/p;->b:Ljava/lang/Object;

    .line 295
    .line 296
    check-cast v1, Ljava/lang/Integer;

    .line 297
    .line 298
    invoke-static {v3, v4, v1}, LR4/w;->b(LR4/j;La9/u;Ljava/lang/Integer;)LR4/w;

    .line 299
    .line 300
    .line 301
    move-result-object v1

    .line 302
    return-object v1

    .line 303
    :cond_7
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 304
    .line 305
    invoke-direct {v1, v14}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    throw v1
    :try_end_1
    .catch Lcom/google/crypto/tink/shaded/protobuf/B; {:try_start_1 .. :try_end_1} :catch_1

    .line 309
    :catch_1
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 310
    .line 311
    const-string v2, "Parsing XChaCha20Poly1305Key failed"

    .line 312
    .line 313
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 314
    .line 315
    .line 316
    throw v1

    .line 317
    :cond_8
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 318
    .line 319
    const-string v2, "Wrong type URL in call to XChaCha20Poly1305Parameters.parseParameters"

    .line 320
    .line 321
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 322
    .line 323
    .line 324
    throw v1

    .line 325
    :pswitch_1
    iget-object v2, v1, LX4/p;->a:Ljava/lang/Object;

    .line 326
    .line 327
    check-cast v2, Ljava/lang/String;

    .line 328
    .line 329
    const-string v3, "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key"

    .line 330
    .line 331
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 332
    .line 333
    .line 334
    move-result v2

    .line 335
    if-eqz v2, :cond_e

    .line 336
    .line 337
    :try_start_2
    iget-object v2, v1, LX4/p;->d:Ljava/lang/Object;

    .line 338
    .line 339
    check-cast v2, Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 340
    .line 341
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/n;->a()Lcom/google/crypto/tink/shaded/protobuf/n;

    .line 342
    .line 343
    .line 344
    move-result-object v3

    .line 345
    invoke-static {v2, v3}, Lc5/J;->B(Lcom/google/crypto/tink/shaded/protobuf/h;Lcom/google/crypto/tink/shaded/protobuf/n;)Lc5/J;

    .line 346
    .line 347
    .line 348
    move-result-object v2

    .line 349
    invoke-virtual {v2}, Lc5/J;->z()I

    .line 350
    .line 351
    .line 352
    move-result v3

    .line 353
    if-nez v3, :cond_d

    .line 354
    .line 355
    iget-object v3, v1, LX4/p;->f:Ljava/lang/Object;

    .line 356
    .line 357
    check-cast v3, Lc5/r0;

    .line 358
    .line 359
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 360
    .line 361
    .line 362
    move-result v4

    .line 363
    if-eq v4, v7, :cond_c

    .line 364
    .line 365
    if-eq v4, v13, :cond_b

    .line 366
    .line 367
    if-eq v4, v12, :cond_a

    .line 368
    .line 369
    if-ne v4, v11, :cond_9

    .line 370
    .line 371
    goto :goto_2

    .line 372
    :cond_9
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 373
    .line 374
    new-instance v2, Ljava/lang/StringBuilder;

    .line 375
    .line 376
    invoke-direct {v2, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 377
    .line 378
    .line 379
    invoke-virtual {v3}, Lc5/r0;->b()I

    .line 380
    .line 381
    .line 382
    move-result v3

    .line 383
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 384
    .line 385
    .line 386
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 387
    .line 388
    .line 389
    move-result-object v2

    .line 390
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 391
    .line 392
    .line 393
    throw v1

    .line 394
    :cond_a
    sget-object v3, LR4/j;->n:LR4/j;

    .line 395
    .line 396
    goto :goto_3

    .line 397
    :cond_b
    :goto_2
    sget-object v3, LR4/j;->m:LR4/j;

    .line 398
    .line 399
    goto :goto_3

    .line 400
    :cond_c
    sget-object v3, LR4/j;->l:LR4/j;

    .line 401
    .line 402
    :goto_3
    invoke-virtual {v2}, Lc5/J;->y()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 403
    .line 404
    .line 405
    move-result-object v2

    .line 406
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/h;->l()[B

    .line 407
    .line 408
    .line 409
    move-result-object v2

    .line 410
    new-instance v4, La9/u;

    .line 411
    .line 412
    invoke-static {v2}, Le5/a;->a([B)Le5/a;

    .line 413
    .line 414
    .line 415
    move-result-object v2

    .line 416
    invoke-direct {v4, v15, v2}, La9/u;-><init>(ILjava/lang/Object;)V

    .line 417
    .line 418
    .line 419
    iget-object v1, v1, LX4/p;->b:Ljava/lang/Object;

    .line 420
    .line 421
    check-cast v1, Ljava/lang/Integer;

    .line 422
    .line 423
    invoke-static {v3, v4, v1}, LR4/s;->b(LR4/j;La9/u;Ljava/lang/Integer;)LR4/s;

    .line 424
    .line 425
    .line 426
    move-result-object v1

    .line 427
    return-object v1

    .line 428
    :cond_d
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 429
    .line 430
    invoke-direct {v1, v14}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 431
    .line 432
    .line 433
    throw v1
    :try_end_2
    .catch Lcom/google/crypto/tink/shaded/protobuf/B; {:try_start_2 .. :try_end_2} :catch_2

    .line 434
    :catch_2
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 435
    .line 436
    const-string v2, "Parsing ChaCha20Poly1305Key failed"

    .line 437
    .line 438
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 439
    .line 440
    .line 441
    throw v1

    .line 442
    :cond_e
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 443
    .line 444
    const-string v2, "Wrong type URL in call to ChaCha20Poly1305Parameters.parseParameters"

    .line 445
    .line 446
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 447
    .line 448
    .line 449
    throw v1

    .line 450
    :pswitch_2
    iget-object v2, v1, LX4/p;->a:Ljava/lang/Object;

    .line 451
    .line 452
    check-cast v2, Ljava/lang/String;

    .line 453
    .line 454
    const-string v3, "type.googleapis.com/google.crypto.tink.AesGcmSivKey"

    .line 455
    .line 456
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 457
    .line 458
    .line 459
    move-result v2

    .line 460
    if-eqz v2, :cond_16

    .line 461
    .line 462
    :try_start_3
    iget-object v2, v1, LX4/p;->d:Ljava/lang/Object;

    .line 463
    .line 464
    check-cast v2, Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 465
    .line 466
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/n;->a()Lcom/google/crypto/tink/shaded/protobuf/n;

    .line 467
    .line 468
    .line 469
    move-result-object v3

    .line 470
    invoke-static {v2, v3}, Lc5/B;->B(Lcom/google/crypto/tink/shaded/protobuf/h;Lcom/google/crypto/tink/shaded/protobuf/n;)Lc5/B;

    .line 471
    .line 472
    .line 473
    move-result-object v2

    .line 474
    invoke-virtual {v2}, Lc5/B;->z()I

    .line 475
    .line 476
    .line 477
    move-result v3

    .line 478
    if-nez v3, :cond_15

    .line 479
    .line 480
    sget-object v3, LR4/j;->k:LR4/j;

    .line 481
    .line 482
    invoke-virtual {v2}, Lc5/B;->y()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 483
    .line 484
    .line 485
    move-result-object v4

    .line 486
    invoke-virtual {v4}, Lcom/google/crypto/tink/shaded/protobuf/h;->size()I

    .line 487
    .line 488
    .line 489
    move-result v4

    .line 490
    if-eq v4, v8, :cond_10

    .line 491
    .line 492
    if-ne v4, v6, :cond_f

    .line 493
    .line 494
    goto :goto_4

    .line 495
    :cond_f
    new-instance v1, Ljava/security/InvalidAlgorithmParameterException;

    .line 496
    .line 497
    const-string v2, "Invalid key size %d; only 16-byte and 32-byte AES keys are supported"

    .line 498
    .line 499
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 500
    .line 501
    .line 502
    move-result-object v3

    .line 503
    new-array v4, v7, [Ljava/lang/Object;

    .line 504
    .line 505
    aput-object v3, v4, v16

    .line 506
    .line 507
    invoke-static {v2, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 508
    .line 509
    .line 510
    move-result-object v2

    .line 511
    invoke-direct {v1, v2}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    .line 512
    .line 513
    .line 514
    throw v1

    .line 515
    :cond_10
    :goto_4
    iget-object v5, v1, LX4/p;->f:Ljava/lang/Object;

    .line 516
    .line 517
    check-cast v5, Lc5/r0;

    .line 518
    .line 519
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 520
    .line 521
    .line 522
    move-result v6

    .line 523
    if-eq v6, v7, :cond_13

    .line 524
    .line 525
    if-eq v6, v13, :cond_12

    .line 526
    .line 527
    if-eq v6, v12, :cond_14

    .line 528
    .line 529
    if-ne v6, v11, :cond_11

    .line 530
    .line 531
    goto :goto_5

    .line 532
    :cond_11
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 533
    .line 534
    new-instance v2, Ljava/lang/StringBuilder;

    .line 535
    .line 536
    invoke-direct {v2, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 537
    .line 538
    .line 539
    invoke-virtual {v5}, Lc5/r0;->b()I

    .line 540
    .line 541
    .line 542
    move-result v3

    .line 543
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 544
    .line 545
    .line 546
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 547
    .line 548
    .line 549
    move-result-object v2

    .line 550
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 551
    .line 552
    .line 553
    throw v1

    .line 554
    :cond_12
    :goto_5
    sget-object v3, LR4/j;->j:LR4/j;

    .line 555
    .line 556
    goto :goto_6

    .line 557
    :cond_13
    sget-object v3, LR4/j;->i:LR4/j;

    .line 558
    .line 559
    :cond_14
    :goto_6
    new-instance v5, LR4/q;

    .line 560
    .line 561
    invoke-direct {v5, v4, v3}, LR4/q;-><init>(ILR4/j;)V

    .line 562
    .line 563
    .line 564
    new-instance v3, Landroid/support/v4/media/session/z;

    .line 565
    .line 566
    const/16 v4, 0x13

    .line 567
    .line 568
    invoke-direct {v3, v4}, Landroid/support/v4/media/session/z;-><init>(I)V

    .line 569
    .line 570
    .line 571
    iput-object v9, v3, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 572
    .line 573
    iput-object v9, v3, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 574
    .line 575
    iput-object v5, v3, Landroid/support/v4/media/session/z;->b:Ljava/lang/Object;

    .line 576
    .line 577
    invoke-virtual {v2}, Lc5/B;->y()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 578
    .line 579
    .line 580
    move-result-object v2

    .line 581
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/h;->l()[B

    .line 582
    .line 583
    .line 584
    move-result-object v2

    .line 585
    new-instance v4, La9/u;

    .line 586
    .line 587
    invoke-static {v2}, Le5/a;->a([B)Le5/a;

    .line 588
    .line 589
    .line 590
    move-result-object v2

    .line 591
    invoke-direct {v4, v15, v2}, La9/u;-><init>(ILjava/lang/Object;)V

    .line 592
    .line 593
    .line 594
    iput-object v4, v3, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 595
    .line 596
    iget-object v1, v1, LX4/p;->b:Ljava/lang/Object;

    .line 597
    .line 598
    check-cast v1, Ljava/lang/Integer;

    .line 599
    .line 600
    iput-object v1, v3, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 601
    .line 602
    invoke-virtual {v3}, Landroid/support/v4/media/session/z;->m()LR4/p;

    .line 603
    .line 604
    .line 605
    move-result-object v1

    .line 606
    return-object v1

    .line 607
    :cond_15
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 608
    .line 609
    invoke-direct {v1, v14}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 610
    .line 611
    .line 612
    throw v1
    :try_end_3
    .catch Lcom/google/crypto/tink/shaded/protobuf/B; {:try_start_3 .. :try_end_3} :catch_3

    .line 613
    :catch_3
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 614
    .line 615
    const-string v2, "Parsing AesGcmSivKey failed"

    .line 616
    .line 617
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 618
    .line 619
    .line 620
    throw v1

    .line 621
    :cond_16
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 622
    .line 623
    const-string v2, "Wrong type URL in call to AesGcmSivParameters.parseParameters"

    .line 624
    .line 625
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 626
    .line 627
    .line 628
    throw v1

    .line 629
    :pswitch_3
    iget-object v2, v1, LX4/p;->a:Ljava/lang/Object;

    .line 630
    .line 631
    check-cast v2, Ljava/lang/String;

    .line 632
    .line 633
    const-string v15, "type.googleapis.com/google.crypto.tink.AesGcmKey"

    .line 634
    .line 635
    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 636
    .line 637
    .line 638
    move-result v2

    .line 639
    if-eqz v2, :cond_1e

    .line 640
    .line 641
    :try_start_4
    iget-object v2, v1, LX4/p;->d:Ljava/lang/Object;

    .line 642
    .line 643
    check-cast v2, Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 644
    .line 645
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/n;->a()Lcom/google/crypto/tink/shaded/protobuf/n;

    .line 646
    .line 647
    .line 648
    move-result-object v15

    .line 649
    invoke-static {v2, v15}, Lc5/x;->B(Lcom/google/crypto/tink/shaded/protobuf/h;Lcom/google/crypto/tink/shaded/protobuf/n;)Lc5/x;

    .line 650
    .line 651
    .line 652
    move-result-object v2

    .line 653
    invoke-virtual {v2}, Lc5/x;->z()I

    .line 654
    .line 655
    .line 656
    move-result v15

    .line 657
    if-nez v15, :cond_1d

    .line 658
    .line 659
    sget-object v14, LR4/j;->h:LR4/j;

    .line 660
    .line 661
    invoke-virtual {v2}, Lc5/x;->y()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 662
    .line 663
    .line 664
    move-result-object v15

    .line 665
    invoke-virtual {v15}, Lcom/google/crypto/tink/shaded/protobuf/h;->size()I

    .line 666
    .line 667
    .line 668
    move-result v15

    .line 669
    if-eq v15, v8, :cond_18

    .line 670
    .line 671
    if-eq v15, v5, :cond_18

    .line 672
    .line 673
    if-ne v15, v6, :cond_17

    .line 674
    .line 675
    goto :goto_7

    .line 676
    :cond_17
    new-instance v1, Ljava/security/InvalidAlgorithmParameterException;

    .line 677
    .line 678
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 679
    .line 680
    .line 681
    move-result-object v2

    .line 682
    new-array v3, v7, [Ljava/lang/Object;

    .line 683
    .line 684
    aput-object v2, v3, v16

    .line 685
    .line 686
    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 687
    .line 688
    .line 689
    move-result-object v2

    .line 690
    invoke-direct {v1, v2}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    .line 691
    .line 692
    .line 693
    throw v1

    .line 694
    :cond_18
    :goto_7
    iget-object v4, v1, LX4/p;->f:Ljava/lang/Object;

    .line 695
    .line 696
    check-cast v4, Lc5/r0;

    .line 697
    .line 698
    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    .line 699
    .line 700
    .line 701
    move-result v5

    .line 702
    if-eq v5, v7, :cond_1b

    .line 703
    .line 704
    if-eq v5, v13, :cond_1a

    .line 705
    .line 706
    if-eq v5, v12, :cond_1c

    .line 707
    .line 708
    if-ne v5, v11, :cond_19

    .line 709
    .line 710
    goto :goto_8

    .line 711
    :cond_19
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 712
    .line 713
    new-instance v2, Ljava/lang/StringBuilder;

    .line 714
    .line 715
    invoke-direct {v2, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 716
    .line 717
    .line 718
    invoke-virtual {v4}, Lc5/r0;->b()I

    .line 719
    .line 720
    .line 721
    move-result v3

    .line 722
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 723
    .line 724
    .line 725
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 726
    .line 727
    .line 728
    move-result-object v2

    .line 729
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 730
    .line 731
    .line 732
    throw v1

    .line 733
    :cond_1a
    :goto_8
    sget-object v14, LR4/j;->g:LR4/j;

    .line 734
    .line 735
    goto :goto_9

    .line 736
    :cond_1b
    sget-object v14, LR4/j;->f:LR4/j;

    .line 737
    .line 738
    :cond_1c
    :goto_9
    new-instance v4, LR4/n;

    .line 739
    .line 740
    invoke-direct {v4, v15, v3, v8, v14}, LR4/n;-><init>(IIILR4/j;)V

    .line 741
    .line 742
    .line 743
    new-instance v3, Landroid/support/v4/media/session/z;

    .line 744
    .line 745
    const/16 v5, 0x12

    .line 746
    .line 747
    invoke-direct {v3, v5}, Landroid/support/v4/media/session/z;-><init>(I)V

    .line 748
    .line 749
    .line 750
    iput-object v9, v3, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 751
    .line 752
    iput-object v9, v3, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 753
    .line 754
    iput-object v4, v3, Landroid/support/v4/media/session/z;->b:Ljava/lang/Object;

    .line 755
    .line 756
    invoke-virtual {v2}, Lc5/x;->y()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 757
    .line 758
    .line 759
    move-result-object v2

    .line 760
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/h;->l()[B

    .line 761
    .line 762
    .line 763
    move-result-object v2

    .line 764
    new-instance v4, La9/u;

    .line 765
    .line 766
    invoke-static {v2}, Le5/a;->a([B)Le5/a;

    .line 767
    .line 768
    .line 769
    move-result-object v2

    .line 770
    const/16 v5, 0x8

    .line 771
    .line 772
    invoke-direct {v4, v5, v2}, La9/u;-><init>(ILjava/lang/Object;)V

    .line 773
    .line 774
    .line 775
    iput-object v4, v3, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 776
    .line 777
    iget-object v1, v1, LX4/p;->b:Ljava/lang/Object;

    .line 778
    .line 779
    check-cast v1, Ljava/lang/Integer;

    .line 780
    .line 781
    iput-object v1, v3, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 782
    .line 783
    invoke-virtual {v3}, Landroid/support/v4/media/session/z;->l()LR4/m;

    .line 784
    .line 785
    .line 786
    move-result-object v1

    .line 787
    return-object v1

    .line 788
    :cond_1d
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 789
    .line 790
    invoke-direct {v1, v14}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 791
    .line 792
    .line 793
    throw v1
    :try_end_4
    .catch Lcom/google/crypto/tink/shaded/protobuf/B; {:try_start_4 .. :try_end_4} :catch_4

    .line 794
    :catch_4
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 795
    .line 796
    const-string v2, "Parsing AesGcmKey failed"

    .line 797
    .line 798
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 799
    .line 800
    .line 801
    throw v1

    .line 802
    :cond_1e
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 803
    .line 804
    const-string v2, "Wrong type URL in call to AesGcmParameters.parseParameters"

    .line 805
    .line 806
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 807
    .line 808
    .line 809
    throw v1

    .line 810
    :pswitch_4
    iget-object v2, v1, LX4/p;->a:Ljava/lang/Object;

    .line 811
    .line 812
    check-cast v2, Ljava/lang/String;

    .line 813
    .line 814
    const-string v15, "type.googleapis.com/google.crypto.tink.AesEaxKey"

    .line 815
    .line 816
    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 817
    .line 818
    .line 819
    move-result v2

    .line 820
    if-eqz v2, :cond_28

    .line 821
    .line 822
    :try_start_5
    iget-object v2, v1, LX4/p;->d:Ljava/lang/Object;

    .line 823
    .line 824
    check-cast v2, Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 825
    .line 826
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/n;->a()Lcom/google/crypto/tink/shaded/protobuf/n;

    .line 827
    .line 828
    .line 829
    move-result-object v15

    .line 830
    invoke-static {v2, v15}, Lc5/r;->D(Lcom/google/crypto/tink/shaded/protobuf/h;Lcom/google/crypto/tink/shaded/protobuf/n;)Lc5/r;

    .line 831
    .line 832
    .line 833
    move-result-object v2

    .line 834
    invoke-virtual {v2}, Lc5/r;->B()I

    .line 835
    .line 836
    .line 837
    move-result v15

    .line 838
    if-nez v15, :cond_27

    .line 839
    .line 840
    sget-object v14, LR4/j;->e:LR4/j;

    .line 841
    .line 842
    invoke-virtual {v2}, Lc5/r;->z()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 843
    .line 844
    .line 845
    move-result-object v15

    .line 846
    invoke-virtual {v15}, Lcom/google/crypto/tink/shaded/protobuf/h;->size()I

    .line 847
    .line 848
    .line 849
    move-result v15

    .line 850
    if-eq v15, v8, :cond_20

    .line 851
    .line 852
    if-eq v15, v5, :cond_20

    .line 853
    .line 854
    if-ne v15, v6, :cond_1f

    .line 855
    .line 856
    goto :goto_a

    .line 857
    :cond_1f
    new-instance v1, Ljava/security/InvalidAlgorithmParameterException;

    .line 858
    .line 859
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 860
    .line 861
    .line 862
    move-result-object v2

    .line 863
    new-array v3, v7, [Ljava/lang/Object;

    .line 864
    .line 865
    aput-object v2, v3, v16

    .line 866
    .line 867
    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 868
    .line 869
    .line 870
    move-result-object v2

    .line 871
    invoke-direct {v1, v2}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    .line 872
    .line 873
    .line 874
    throw v1

    .line 875
    :cond_20
    :goto_a
    invoke-virtual {v2}, Lc5/r;->A()Lc5/v;

    .line 876
    .line 877
    .line 878
    move-result-object v4

    .line 879
    invoke-virtual {v4}, Lc5/v;->y()I

    .line 880
    .line 881
    .line 882
    move-result v4

    .line 883
    if-eq v4, v3, :cond_22

    .line 884
    .line 885
    if-ne v4, v8, :cond_21

    .line 886
    .line 887
    goto :goto_b

    .line 888
    :cond_21
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 889
    .line 890
    const-string v2, "Invalid IV size in bytes %d; acceptable values have 12 or 16 bytes"

    .line 891
    .line 892
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 893
    .line 894
    .line 895
    move-result-object v3

    .line 896
    new-array v4, v7, [Ljava/lang/Object;

    .line 897
    .line 898
    aput-object v3, v4, v16

    .line 899
    .line 900
    invoke-static {v2, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 901
    .line 902
    .line 903
    move-result-object v2

    .line 904
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 905
    .line 906
    .line 907
    throw v1

    .line 908
    :cond_22
    :goto_b
    iget-object v3, v1, LX4/p;->f:Ljava/lang/Object;

    .line 909
    .line 910
    check-cast v3, Lc5/r0;

    .line 911
    .line 912
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 913
    .line 914
    .line 915
    move-result v5

    .line 916
    if-eq v5, v7, :cond_25

    .line 917
    .line 918
    if-eq v5, v13, :cond_24

    .line 919
    .line 920
    if-eq v5, v12, :cond_26

    .line 921
    .line 922
    if-ne v5, v11, :cond_23

    .line 923
    .line 924
    goto :goto_c

    .line 925
    :cond_23
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 926
    .line 927
    new-instance v2, Ljava/lang/StringBuilder;

    .line 928
    .line 929
    invoke-direct {v2, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 930
    .line 931
    .line 932
    invoke-virtual {v3}, Lc5/r0;->b()I

    .line 933
    .line 934
    .line 935
    move-result v3

    .line 936
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 937
    .line 938
    .line 939
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 940
    .line 941
    .line 942
    move-result-object v2

    .line 943
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 944
    .line 945
    .line 946
    throw v1

    .line 947
    :cond_24
    :goto_c
    sget-object v14, LR4/j;->d:LR4/j;

    .line 948
    .line 949
    goto :goto_d

    .line 950
    :cond_25
    sget-object v14, LR4/j;->c:LR4/j;

    .line 951
    .line 952
    :cond_26
    :goto_d
    new-instance v3, LR4/k;

    .line 953
    .line 954
    invoke-direct {v3, v15, v4, v8, v14}, LR4/k;-><init>(IIILR4/j;)V

    .line 955
    .line 956
    .line 957
    new-instance v4, Landroid/support/v4/media/session/z;

    .line 958
    .line 959
    const/16 v5, 0x11

    .line 960
    .line 961
    invoke-direct {v4, v5}, Landroid/support/v4/media/session/z;-><init>(I)V

    .line 962
    .line 963
    .line 964
    iput-object v9, v4, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 965
    .line 966
    iput-object v9, v4, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 967
    .line 968
    iput-object v3, v4, Landroid/support/v4/media/session/z;->b:Ljava/lang/Object;

    .line 969
    .line 970
    invoke-virtual {v2}, Lc5/r;->z()Lcom/google/crypto/tink/shaded/protobuf/h;

    .line 971
    .line 972
    .line 973
    move-result-object v2

    .line 974
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/h;->l()[B

    .line 975
    .line 976
    .line 977
    move-result-object v2

    .line 978
    new-instance v3, La9/u;

    .line 979
    .line 980
    invoke-static {v2}, Le5/a;->a([B)Le5/a;

    .line 981
    .line 982
    .line 983
    move-result-object v2

    .line 984
    const/16 v5, 0x8

    .line 985
    .line 986
    invoke-direct {v3, v5, v2}, La9/u;-><init>(ILjava/lang/Object;)V

    .line 987
    .line 988
    .line 989
    iput-object v3, v4, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 990
    .line 991
    iget-object v1, v1, LX4/p;->b:Ljava/lang/Object;

    .line 992
    .line 993
    check-cast v1, Ljava/lang/Integer;

    .line 994
    .line 995
    iput-object v1, v4, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 996
    .line 997
    invoke-virtual {v4}, Landroid/support/v4/media/session/z;->k()LR4/i;

    .line 998
    .line 999
    .line 1000
    move-result-object v1

    .line 1001
    return-object v1

    .line 1002
    :cond_27
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 1003
    .line 1004
    invoke-direct {v1, v14}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 1005
    .line 1006
    .line 1007
    throw v1
    :try_end_5
    .catch Lcom/google/crypto/tink/shaded/protobuf/B; {:try_start_5 .. :try_end_5} :catch_5

    .line 1008
    :catch_5
    new-instance v1, Ljava/security/GeneralSecurityException;

    .line 1009
    .line 1010
    const-string v2, "Parsing AesEaxcKey failed"

    .line 1011
    .line 1012
    invoke-direct {v1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 1013
    .line 1014
    .line 1015
    throw v1

    .line 1016
    :cond_28
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 1017
    .line 1018
    const-string v2, "Wrong type URL in call to AesEaxParameters.parseParameters"

    .line 1019
    .line 1020
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 1021
    .line 1022
    .line 1023
    throw v1

    .line 1024
    nop

    .line 1025
    :pswitch_data_0
    .packed-switch 0x12
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public b(IIIII)Z
    .locals 0

    .line 1
    const/4 p1, 0x0

    return p1
.end method

.method public c(LQ4/b;)Ljava/lang/Object;
    .locals 1

    .line 1
    new-instance v0, LZ4/a;

    .line 2
    .line 3
    check-cast p1, LY4/a;

    .line 4
    .line 5
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    const/4 p1, 0x1

    .line 9
    invoke-static {p1}, LB0/a;->d(I)Z

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    if-eqz p1, :cond_0

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 17
    .line 18
    const-string v0, "Can not use AES-CMAC in FIPS-mode."

    .line 19
    .line 20
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    throw p1
.end method

.method public d(LG4/f;I)V
    .locals 1

    .line 1
    iget v0, p0, LC7/q;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {}, LA6/i;->values()[LA6/i;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    aget-object p2, v0, p2

    .line 11
    .line 12
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 13
    .line 14
    .line 15
    move-result p2

    .line 16
    if-eqz p2, :cond_2

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    if-eq p2, v0, :cond_1

    .line 20
    .line 21
    const/4 v0, 0x2

    .line 22
    if-ne p2, v0, :cond_0

    .line 23
    .line 24
    const p2, 0x7f140226

    .line 25
    .line 26
    .line 27
    invoke-virtual {p1, p2}, LG4/f;->a(I)V

    .line 28
    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    new-instance p1, LB8/s;

    .line 32
    .line 33
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 34
    .line 35
    .line 36
    throw p1

    .line 37
    :cond_1
    const p2, 0x7f14022a

    .line 38
    .line 39
    .line 40
    invoke-virtual {p1, p2}, LG4/f;->a(I)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_2
    const p2, 0x7f140205

    .line 45
    .line 46
    .line 47
    invoke-virtual {p1, p2}, LG4/f;->a(I)V

    .line 48
    .line 49
    .line 50
    :goto_0
    return-void

    .line 51
    :pswitch_0
    invoke-static {}, LA6/c;->values()[LA6/c;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    aget-object p2, v0, p2

    .line 56
    .line 57
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 58
    .line 59
    .line 60
    move-result p2

    .line 61
    if-eqz p2, :cond_5

    .line 62
    .line 63
    const/4 v0, 0x1

    .line 64
    if-eq p2, v0, :cond_4

    .line 65
    .line 66
    const/4 v0, 0x2

    .line 67
    if-ne p2, v0, :cond_3

    .line 68
    .line 69
    const p2, 0x7f1400f8

    .line 70
    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_3
    new-instance p1, LB8/s;

    .line 74
    .line 75
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 76
    .line 77
    .line 78
    throw p1

    .line 79
    :cond_4
    const p2, 0x7f140116

    .line 80
    .line 81
    .line 82
    goto :goto_1

    .line 83
    :cond_5
    const p2, 0x7f1400f0

    .line 84
    .line 85
    .line 86
    :goto_1
    invoke-virtual {p1, p2}, LG4/f;->a(I)V

    .line 87
    .line 88
    .line 89
    return-void

    .line 90
    nop

    .line 91
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public e(Ljava/lang/Exception;)V
    .locals 0

    .line 1
    return-void
.end method

.method public f(Landroid/os/Bundle;)Lf2/f;
    .locals 31

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget v2, v0, LC7/q;->a:I

    .line 6
    .line 7
    const/4 v3, 0x5

    .line 8
    const/4 v4, 0x6

    .line 9
    const/4 v5, 0x7

    .line 10
    const/4 v6, 0x3

    .line 11
    const/4 v7, 0x2

    .line 12
    const/4 v8, 0x4

    .line 13
    const/4 v9, 0x1

    .line 14
    const/16 v10, 0x24

    .line 15
    .line 16
    const/4 v11, 0x0

    .line 17
    packed-switch v2, :pswitch_data_0

    .line 18
    .line 19
    .line 20
    invoke-static {v11, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    const/4 v12, 0x0

    .line 29
    if-eqz v2, :cond_0

    .line 30
    .line 31
    move-object v14, v2

    .line 32
    goto :goto_0

    .line 33
    :cond_0
    move-object v14, v12

    .line 34
    :goto_0
    invoke-static {v9, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getSerializable(Ljava/lang/String;)Ljava/io/Serializable;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    check-cast v2, Landroid/text/Layout$Alignment;

    .line 43
    .line 44
    if-eqz v2, :cond_1

    .line 45
    .line 46
    move-object v15, v2

    .line 47
    goto :goto_1

    .line 48
    :cond_1
    move-object v15, v12

    .line 49
    :goto_1
    invoke-static {v7, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getSerializable(Ljava/lang/String;)Ljava/io/Serializable;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    check-cast v2, Landroid/text/Layout$Alignment;

    .line 58
    .line 59
    if-eqz v2, :cond_2

    .line 60
    .line 61
    move-object/from16 v16, v2

    .line 62
    .line 63
    goto :goto_2

    .line 64
    :cond_2
    move-object/from16 v16, v12

    .line 65
    .line 66
    :goto_2
    invoke-static {v6, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v2

    .line 70
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 71
    .line 72
    .line 73
    move-result-object v2

    .line 74
    check-cast v2, Landroid/graphics/Bitmap;

    .line 75
    .line 76
    if-eqz v2, :cond_3

    .line 77
    .line 78
    move-object/from16 v17, v2

    .line 79
    .line 80
    goto :goto_3

    .line 81
    :cond_3
    move-object/from16 v17, v12

    .line 82
    .line 83
    :goto_3
    invoke-static {v8, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    const v6, -0x800001

    .line 92
    .line 93
    .line 94
    const/high16 v7, -0x80000000

    .line 95
    .line 96
    if-eqz v2, :cond_4

    .line 97
    .line 98
    invoke-static {v3, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 103
    .line 104
    .line 105
    move-result v2

    .line 106
    if-eqz v2, :cond_4

    .line 107
    .line 108
    invoke-static {v8, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v2

    .line 112
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 113
    .line 114
    .line 115
    move-result v2

    .line 116
    invoke-static {v3, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 121
    .line 122
    .line 123
    move-result v3

    .line 124
    move/from16 v18, v2

    .line 125
    .line 126
    move/from16 v19, v3

    .line 127
    .line 128
    goto :goto_4

    .line 129
    :cond_4
    move/from16 v18, v6

    .line 130
    .line 131
    move/from16 v19, v7

    .line 132
    .line 133
    :goto_4
    invoke-static {v4, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 138
    .line 139
    .line 140
    move-result v2

    .line 141
    if-eqz v2, :cond_5

    .line 142
    .line 143
    invoke-static {v4, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v2

    .line 147
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 148
    .line 149
    .line 150
    move-result v2

    .line 151
    move/from16 v20, v2

    .line 152
    .line 153
    goto :goto_5

    .line 154
    :cond_5
    move/from16 v20, v7

    .line 155
    .line 156
    :goto_5
    invoke-static {v5, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 161
    .line 162
    .line 163
    move-result v2

    .line 164
    if-eqz v2, :cond_6

    .line 165
    .line 166
    invoke-static {v5, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object v2

    .line 170
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 171
    .line 172
    .line 173
    move-result v2

    .line 174
    move/from16 v21, v2

    .line 175
    .line 176
    goto :goto_6

    .line 177
    :cond_6
    move/from16 v21, v6

    .line 178
    .line 179
    :goto_6
    const/16 v2, 0x8

    .line 180
    .line 181
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v3

    .line 185
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    if-eqz v3, :cond_7

    .line 190
    .line 191
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v2

    .line 195
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 196
    .line 197
    .line 198
    move-result v2

    .line 199
    move/from16 v22, v2

    .line 200
    .line 201
    goto :goto_7

    .line 202
    :cond_7
    move/from16 v22, v7

    .line 203
    .line 204
    :goto_7
    const/16 v2, 0xa

    .line 205
    .line 206
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v3

    .line 210
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 211
    .line 212
    .line 213
    move-result v3

    .line 214
    if-eqz v3, :cond_8

    .line 215
    .line 216
    const/16 v3, 0x9

    .line 217
    .line 218
    invoke-static {v3, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v4

    .line 222
    invoke-virtual {v1, v4}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 223
    .line 224
    .line 225
    move-result v4

    .line 226
    if-eqz v4, :cond_8

    .line 227
    .line 228
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 229
    .line 230
    .line 231
    move-result-object v2

    .line 232
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 233
    .line 234
    .line 235
    move-result v2

    .line 236
    invoke-static {v3, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v3

    .line 240
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 241
    .line 242
    .line 243
    move-result v3

    .line 244
    move/from16 v24, v2

    .line 245
    .line 246
    move/from16 v23, v3

    .line 247
    .line 248
    goto :goto_8

    .line 249
    :cond_8
    move/from16 v24, v6

    .line 250
    .line 251
    move/from16 v23, v7

    .line 252
    .line 253
    :goto_8
    const/16 v2, 0xb

    .line 254
    .line 255
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 256
    .line 257
    .line 258
    move-result-object v3

    .line 259
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 260
    .line 261
    .line 262
    move-result v3

    .line 263
    if-eqz v3, :cond_9

    .line 264
    .line 265
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 266
    .line 267
    .line 268
    move-result-object v2

    .line 269
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 270
    .line 271
    .line 272
    move-result v2

    .line 273
    move/from16 v25, v2

    .line 274
    .line 275
    goto :goto_9

    .line 276
    :cond_9
    move/from16 v25, v6

    .line 277
    .line 278
    :goto_9
    const/16 v2, 0xc

    .line 279
    .line 280
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object v3

    .line 284
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 285
    .line 286
    .line 287
    move-result v3

    .line 288
    if-eqz v3, :cond_a

    .line 289
    .line 290
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object v2

    .line 294
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 295
    .line 296
    .line 297
    move-result v6

    .line 298
    :cond_a
    move/from16 v26, v6

    .line 299
    .line 300
    const/16 v2, 0xd

    .line 301
    .line 302
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    move-result-object v3

    .line 306
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 307
    .line 308
    .line 309
    move-result v3

    .line 310
    if-eqz v3, :cond_b

    .line 311
    .line 312
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v2

    .line 316
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 317
    .line 318
    .line 319
    move-result v2

    .line 320
    :goto_a
    move/from16 v28, v2

    .line 321
    .line 322
    goto :goto_b

    .line 323
    :cond_b
    const/high16 v2, -0x1000000

    .line 324
    .line 325
    move v9, v11

    .line 326
    goto :goto_a

    .line 327
    :goto_b
    const/16 v2, 0xe

    .line 328
    .line 329
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 330
    .line 331
    .line 332
    move-result-object v2

    .line 333
    invoke-virtual {v1, v2, v11}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 334
    .line 335
    .line 336
    move-result v2

    .line 337
    if-nez v2, :cond_c

    .line 338
    .line 339
    move/from16 v27, v11

    .line 340
    .line 341
    goto :goto_c

    .line 342
    :cond_c
    move/from16 v27, v9

    .line 343
    .line 344
    :goto_c
    const/16 v2, 0xf

    .line 345
    .line 346
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object v3

    .line 350
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 351
    .line 352
    .line 353
    move-result v3

    .line 354
    if-eqz v3, :cond_d

    .line 355
    .line 356
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v2

    .line 360
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 361
    .line 362
    .line 363
    move-result v7

    .line 364
    :cond_d
    move/from16 v29, v7

    .line 365
    .line 366
    const/16 v2, 0x10

    .line 367
    .line 368
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 369
    .line 370
    .line 371
    move-result-object v3

    .line 372
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 373
    .line 374
    .line 375
    move-result v3

    .line 376
    if-eqz v3, :cond_e

    .line 377
    .line 378
    invoke-static {v2, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v2

    .line 382
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getFloat(Ljava/lang/String;)F

    .line 383
    .line 384
    .line 385
    move-result v1

    .line 386
    :goto_d
    move/from16 v30, v1

    .line 387
    .line 388
    goto :goto_e

    .line 389
    :cond_e
    const/4 v1, 0x0

    .line 390
    goto :goto_d

    .line 391
    :goto_e
    new-instance v13, LU2/b;

    .line 392
    .line 393
    invoke-direct/range {v13 .. v30}, LU2/b;-><init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFZIIF)V

    .line 394
    .line 395
    .line 396
    return-object v13

    .line 397
    :pswitch_0
    invoke-static {v11, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 398
    .line 399
    .line 400
    move-result-object v2

    .line 401
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 402
    .line 403
    .line 404
    move-result-wide v13

    .line 405
    invoke-static {v9, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 406
    .line 407
    .line 408
    move-result-object v2

    .line 409
    const/4 v9, -0x1

    .line 410
    invoke-virtual {v1, v2, v9}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 411
    .line 412
    .line 413
    move-result v15

    .line 414
    invoke-static {v5, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 415
    .line 416
    .line 417
    move-result-object v2

    .line 418
    invoke-virtual {v1, v2, v9}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 419
    .line 420
    .line 421
    move-result v16

    .line 422
    invoke-static {v7, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 423
    .line 424
    .line 425
    move-result-object v2

    .line 426
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 427
    .line 428
    .line 429
    move-result-object v2

    .line 430
    invoke-static {v6, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 431
    .line 432
    .line 433
    move-result-object v5

    .line 434
    invoke-virtual {v1, v5}, Landroid/os/BaseBundle;->getIntArray(Ljava/lang/String;)[I

    .line 435
    .line 436
    .line 437
    move-result-object v5

    .line 438
    invoke-static {v8, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 439
    .line 440
    .line 441
    move-result-object v6

    .line 442
    invoke-virtual {v1, v6}, Landroid/os/BaseBundle;->getLongArray(Ljava/lang/String;)[J

    .line 443
    .line 444
    .line 445
    move-result-object v6

    .line 446
    invoke-static {v3, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 447
    .line 448
    .line 449
    move-result-object v3

    .line 450
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    .line 451
    .line 452
    .line 453
    move-result-wide v20

    .line 454
    invoke-static {v4, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 455
    .line 456
    .line 457
    move-result-object v3

    .line 458
    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    .line 459
    .line 460
    .line 461
    move-result v22

    .line 462
    new-instance v12, LK2/a;

    .line 463
    .line 464
    if-nez v5, :cond_f

    .line 465
    .line 466
    new-array v5, v11, [I

    .line 467
    .line 468
    :cond_f
    move-object/from16 v17, v5

    .line 469
    .line 470
    new-array v1, v11, [Landroid/net/Uri;

    .line 471
    .line 472
    if-nez v2, :cond_10

    .line 473
    .line 474
    :goto_f
    move-object/from16 v18, v1

    .line 475
    .line 476
    goto :goto_10

    .line 477
    :cond_10
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 478
    .line 479
    .line 480
    move-result-object v1

    .line 481
    check-cast v1, [Landroid/net/Uri;

    .line 482
    .line 483
    goto :goto_f

    .line 484
    :goto_10
    if-nez v6, :cond_11

    .line 485
    .line 486
    new-array v6, v11, [J

    .line 487
    .line 488
    :cond_11
    move-object/from16 v19, v6

    .line 489
    .line 490
    invoke-direct/range {v12 .. v22}, LK2/a;-><init>(JII[I[Landroid/net/Uri;[JJZ)V

    .line 491
    .line 492
    .line 493
    return-object v12

    .line 494
    :pswitch_1
    invoke-static {v9, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 495
    .line 496
    .line 497
    move-result-object v2

    .line 498
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 499
    .line 500
    .line 501
    move-result-object v2

    .line 502
    if-nez v2, :cond_12

    .line 503
    .line 504
    new-array v2, v11, [LK2/a;

    .line 505
    .line 506
    move-object v13, v2

    .line 507
    goto :goto_12

    .line 508
    :cond_12
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 509
    .line 510
    .line 511
    move-result v3

    .line 512
    new-array v3, v3, [LK2/a;

    .line 513
    .line 514
    :goto_11
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 515
    .line 516
    .line 517
    move-result v4

    .line 518
    if-ge v11, v4, :cond_13

    .line 519
    .line 520
    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 521
    .line 522
    .line 523
    move-result-object v4

    .line 524
    check-cast v4, Landroid/os/Bundle;

    .line 525
    .line 526
    sget-object v5, LK2/a;->i:LC7/q;

    .line 527
    .line 528
    invoke-virtual {v5, v4}, LC7/q;->f(Landroid/os/Bundle;)Lf2/f;

    .line 529
    .line 530
    .line 531
    move-result-object v4

    .line 532
    check-cast v4, LK2/a;

    .line 533
    .line 534
    aput-object v4, v3, v11

    .line 535
    .line 536
    add-int/lit8 v11, v11, 0x1

    .line 537
    .line 538
    goto :goto_11

    .line 539
    :cond_13
    move-object v13, v3

    .line 540
    :goto_12
    invoke-static {v7, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 541
    .line 542
    .line 543
    move-result-object v2

    .line 544
    const-wide/16 v3, 0x0

    .line 545
    .line 546
    invoke-virtual {v1, v2, v3, v4}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;J)J

    .line 547
    .line 548
    .line 549
    move-result-wide v14

    .line 550
    invoke-static {v6, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 551
    .line 552
    .line 553
    move-result-object v2

    .line 554
    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    invoke-virtual {v1, v2, v3, v4}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;J)J

    .line 560
    .line 561
    .line 562
    move-result-wide v16

    .line 563
    invoke-static {v8, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 564
    .line 565
    .line 566
    move-result-object v2

    .line 567
    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 568
    .line 569
    .line 570
    move-result v18

    .line 571
    new-instance v12, LK2/b;

    .line 572
    .line 573
    invoke-direct/range {v12 .. v18}, LK2/b;-><init>([LK2/a;JJI)V

    .line 574
    .line 575
    .line 576
    return-object v12

    .line 577
    :pswitch_2
    invoke-static {v11, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 578
    .line 579
    .line 580
    move-result-object v2

    .line 581
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 582
    .line 583
    .line 584
    move-result-object v1

    .line 585
    if-nez v1, :cond_14

    .line 586
    .line 587
    new-instance v1, LJ2/o0;

    .line 588
    .line 589
    new-array v2, v11, [LJ2/n0;

    .line 590
    .line 591
    invoke-direct {v1, v2}, LJ2/o0;-><init>([LJ2/n0;)V

    .line 592
    .line 593
    .line 594
    goto :goto_13

    .line 595
    :cond_14
    new-instance v2, LJ2/o0;

    .line 596
    .line 597
    sget-object v3, LJ2/n0;->f:LC7/q;

    .line 598
    .line 599
    invoke-static {v3, v1}, Lh3/a;->x(Lf2/e;Ljava/util/ArrayList;)LL4/S;

    .line 600
    .line 601
    .line 602
    move-result-object v1

    .line 603
    new-array v3, v11, [LJ2/n0;

    .line 604
    .line 605
    invoke-virtual {v1, v3}, LL4/A;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 606
    .line 607
    .line 608
    move-result-object v1

    .line 609
    check-cast v1, [LJ2/n0;

    .line 610
    .line 611
    invoke-direct {v2, v1}, LJ2/o0;-><init>([LJ2/n0;)V

    .line 612
    .line 613
    .line 614
    move-object v1, v2

    .line 615
    :goto_13
    return-object v1

    .line 616
    :pswitch_3
    invoke-static {v11, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 617
    .line 618
    .line 619
    move-result-object v2

    .line 620
    invoke-virtual {v1, v2}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 621
    .line 622
    .line 623
    move-result-object v2

    .line 624
    if-nez v2, :cond_15

    .line 625
    .line 626
    sget-object v2, LL4/F;->b:LL4/D;

    .line 627
    .line 628
    sget-object v2, LL4/S;->e:LL4/S;

    .line 629
    .line 630
    goto :goto_14

    .line 631
    :cond_15
    sget-object v3, Lf2/N;->d0:LY4/l;

    .line 632
    .line 633
    invoke-static {v3, v2}, Lh3/a;->x(Lf2/e;Ljava/util/ArrayList;)LL4/S;

    .line 634
    .line 635
    .line 636
    move-result-object v2

    .line 637
    :goto_14
    invoke-static {v9, v10}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 638
    .line 639
    .line 640
    move-result-object v3

    .line 641
    const-string v4, ""

    .line 642
    .line 643
    invoke-virtual {v1, v3, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 644
    .line 645
    .line 646
    move-result-object v1

    .line 647
    new-instance v3, LJ2/n0;

    .line 648
    .line 649
    new-array v4, v11, [Lf2/N;

    .line 650
    .line 651
    invoke-virtual {v2, v4}, LL4/A;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 652
    .line 653
    .line 654
    move-result-object v2

    .line 655
    check-cast v2, [Lf2/N;

    .line 656
    .line 657
    invoke-direct {v3, v1, v2}, LJ2/n0;-><init>(Ljava/lang/String;[Lf2/N;)V

    .line 658
    .line 659
    .line 660
    return-object v3

    .line 661
    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public g(Ljava/lang/Object;)V
    .locals 0

    .line 1
    check-cast p1, LJ2/b0;

    .line 2
    .line 3
    iget-object p1, p1, LJ2/b0;->b:Lj2/n;

    .line 4
    .line 5
    invoke-interface {p1}, Lj2/n;->a()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public l(LC1/b;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LC7/q;->a:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, LV5/b;

    .line 7
    .line 8
    const-class v1, LV5/a;

    .line 9
    .line 10
    invoke-virtual {p1, v1}, LC1/b;->K(Ljava/lang/Class;)Ljava/util/Set;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    sget-object v1, LV5/c;->c:LV5/c;

    .line 15
    .line 16
    if-nez v1, :cond_1

    .line 17
    .line 18
    const-class v2, LV5/c;

    .line 19
    .line 20
    monitor-enter v2

    .line 21
    :try_start_0
    sget-object v1, LV5/c;->c:LV5/c;

    .line 22
    .line 23
    if-nez v1, :cond_0

    .line 24
    .line 25
    new-instance v1, LV5/c;

    .line 26
    .line 27
    const/4 v3, 0x0

    .line 28
    invoke-direct {v1, v3}, LV5/c;-><init>(I)V

    .line 29
    .line 30
    .line 31
    sput-object v1, LV5/c;->c:LV5/c;

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :catchall_0
    move-exception p1

    .line 35
    goto :goto_1

    .line 36
    :cond_0
    :goto_0
    monitor-exit v2

    .line 37
    goto :goto_2

    .line 38
    :goto_1
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    throw p1

    .line 40
    :cond_1
    :goto_2
    invoke-direct {v0, p1, v1}, LV5/b;-><init>(Ljava/util/Set;LV5/c;)V

    .line 41
    .line 42
    .line 43
    return-object v0

    .line 44
    :sswitch_0
    invoke-static {p1}, Lcom/google/firebase/installations/FirebaseInstallationsRegistrar;->a(LC1/b;)LN5/e;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    return-object p1

    .line 49
    :sswitch_1
    invoke-static {p1}, Lcom/google/firebase/datatransport/TransportRegistrar;->a(LC1/b;)LR1/f;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    return-object p1

    .line 54
    :sswitch_2
    invoke-static {p1}, Lcom/google/firebase/datatransport/TransportRegistrar;->b(LC1/b;)LR1/f;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    return-object p1

    .line 59
    :sswitch_3
    invoke-static {p1}, Lcom/google/firebase/datatransport/TransportRegistrar;->c(LC1/b;)LR1/f;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    return-object p1

    .line 64
    nop

    .line 65
    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_3
        0x2 -> :sswitch_2
        0x3 -> :sswitch_1
        0xe -> :sswitch_0
    .end sparse-switch
.end method

.method public x(Ljava/lang/Object;)Lb4/q;
    .locals 0

    .line 1
    check-cast p1, LX5/i;

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    invoke-static {p1}, Lf5/b;->s(Ljava/lang/Object;)Lb4/q;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    return-object p1
.end method
