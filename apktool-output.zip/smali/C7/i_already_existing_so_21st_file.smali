.class public final Lc7/i;
.super LG0/K;
.source "SourceFile"


# static fields
.field public static final i:Ljava/util/concurrent/atomic/AtomicInteger;

.field public static final j:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final k:LP6/a;


# instance fields
.field public final e:Lcom/maertsno/m/ui/home/FragmentHome;

.field public final f:Ld8/j;

.field public g:Ld8/g;

.field public h:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lc7/i;->i:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 8
    .line 9
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lc7/i;->j:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 16
    .line 17
    new-instance v0, LP6/a;

    .line 18
    .line 19
    const/16 v1, 0x8

    .line 20
    .line 21
    invoke-direct {v0, v1}, LP6/a;-><init>(I)V

    .line 22
    .line 23
    .line 24
    sput-object v0, Lc7/i;->k:LP6/a;

    .line 25
    .line 26
    return-void
.end method

.method public constructor <init>(Lcom/maertsno/m/ui/home/FragmentHome;)V
    .locals 1

    .line 1
    sget-object v0, Lc7/i;->k:LP6/a;

    .line 2
    .line 3
    invoke-direct {p0, v0}, LG0/K;-><init>(LG0/c;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lc7/i;->e:Lcom/maertsno/m/ui/home/FragmentHome;

    .line 7
    .line 8
    new-instance p1, LC1/f;

    .line 9
    .line 10
    const/16 v0, 0xc

    .line 11
    .line 12
    invoke-direct {p1, v0}, LC1/f;-><init>(I)V

    .line 13
    .line 14
    .line 15
    invoke-static {p1}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    iput-object p1, p0, Lc7/i;->f:Ld8/j;

    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public final c(I)I
    .locals 1

    .line 1
    iget-object v0, p0, LG0/K;->d:LG0/f;

    .line 2
    .line 3
    iget-object v0, v0, LG0/f;->f:Ljava/util/List;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Ly6/v;

    .line 10
    .line 11
    instance-of v0, p1, Ly6/t;

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    const/4 p1, 0x0

    .line 16
    return p1

    .line 17
    :cond_0
    instance-of v0, p1, Ly6/u;

    .line 18
    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    const/4 p1, 0x2

    .line 22
    return p1

    .line 23
    :cond_1
    instance-of p1, p1, Ly6/q;

    .line 24
    .line 25
    if-eqz p1, :cond_2

    .line 26
    .line 27
    const/4 p1, 0x3

    .line 28
    return p1

    .line 29
    :cond_2
    const/4 p1, 0x1

    .line 30
    return p1
.end method

.method public final g(LG0/u0;I)V
    .locals 7

    .line 1
    iget-object v0, p0, LG0/K;->d:LG0/f;

    .line 2
    .line 3
    iget-object v0, v0, LG0/f;->f:Ljava/util/List;

    .line 4
    .line 5
    invoke-interface {v0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p2

    .line 9
    check-cast p2, Ly6/v;

    .line 10
    .line 11
    instance-of v0, p1, Lc7/g;

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    const/4 v2, 0x0

    .line 15
    if-eqz v0, :cond_2

    .line 16
    .line 17
    check-cast p1, Lc7/g;

    .line 18
    .line 19
    iget-object v0, p1, Lc7/g;->v:Ld8/j;

    .line 20
    .line 21
    iget-object v3, p1, Lc7/g;->u:LN6/L0;

    .line 22
    .line 23
    const-string v4, "null cannot be cast to non-null type com.maertsno.domain.model.HomeRow.SliderRow"

    .line 24
    .line 25
    invoke-static {p2, v4}, Lkotlin/jvm/internal/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    check-cast p2, Ly6/t;

    .line 29
    .line 30
    iget-object v4, p1, Lc7/g;->w:Landroid/os/Handler;

    .line 31
    .line 32
    invoke-virtual {v4, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iget-object p2, p2, Ly6/t;->a:Ljava/util/List;

    .line 36
    .line 37
    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    if-nez v4, :cond_0

    .line 42
    .line 43
    invoke-static {p2}, Le8/i;->q0(Ljava/util/List;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    invoke-static {v4}, Lf5/b;->z(Ljava/lang/Object;)Ljava/util/List;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-static {v4, p2}, Le8/i;->u0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    invoke-static {p2}, Le8/i;->j0(Ljava/util/List;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p2

    .line 59
    invoke-static {p2}, Lf5/b;->z(Ljava/lang/Object;)Ljava/util/List;

    .line 60
    .line 61
    .line 62
    move-result-object p2

    .line 63
    invoke-static {v4, p2}, Le8/i;->u0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 64
    .line 65
    .line 66
    move-result-object p2

    .line 67
    :cond_0
    iput-object p2, p1, Lc7/g;->x:Ljava/util/List;

    .line 68
    .line 69
    invoke-virtual {v0}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p2

    .line 73
    check-cast p2, Lc7/b;

    .line 74
    .line 75
    iget-object v4, p1, Lc7/g;->x:Ljava/util/List;

    .line 76
    .line 77
    new-instance v5, LG/j;

    .line 78
    .line 79
    const/16 v6, 0x8

    .line 80
    .line 81
    invoke-direct {v5, p1, v6, v3}, LG/j;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    iget-object p2, p2, LG0/K;->d:LG0/f;

    .line 85
    .line 86
    invoke-virtual {p2, v4, v5}, LG0/f;->b(Ljava/util/List;Ljava/lang/Runnable;)V

    .line 87
    .line 88
    .line 89
    iget-boolean p2, p0, Lc7/i;->h:Z

    .line 90
    .line 91
    if-eqz p2, :cond_1

    .line 92
    .line 93
    iput-boolean v1, p0, Lc7/i;->h:Z

    .line 94
    .line 95
    invoke-virtual {v0}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object p2

    .line 99
    check-cast p2, Lc7/b;

    .line 100
    .line 101
    invoke-virtual {p2}, LG0/K;->a()I

    .line 102
    .line 103
    .line 104
    move-result p2

    .line 105
    if-lez p2, :cond_1

    .line 106
    .line 107
    iget-object p2, v3, LN6/L0;->H:Landroidx/viewpager2/widget/ViewPager2;

    .line 108
    .line 109
    const/4 v0, 0x1

    .line 110
    invoke-virtual {p2, v0, v1}, Landroidx/viewpager2/widget/ViewPager2;->b(IZ)V

    .line 111
    .line 112
    .line 113
    :cond_1
    iget-object p2, p0, Lc7/i;->g:Ld8/g;

    .line 114
    .line 115
    if-eqz p2, :cond_9

    .line 116
    .line 117
    iget-object v0, p2, Ld8/g;->a:Ljava/lang/Object;

    .line 118
    .line 119
    check-cast v0, Ljava/lang/Number;

    .line 120
    .line 121
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 122
    .line 123
    .line 124
    move-result-wide v0

    .line 125
    iget-object p2, p2, Ld8/g;->b:Ljava/lang/Object;

    .line 126
    .line 127
    check-cast p2, Ljava/lang/Boolean;

    .line 128
    .line 129
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 130
    .line 131
    .line 132
    move-result p2

    .line 133
    invoke-virtual {p1, v0, v1, p2}, Lc7/g;->s(JZ)V

    .line 134
    .line 135
    .line 136
    iput-object v2, p0, Lc7/i;->g:Ld8/g;

    .line 137
    .line 138
    return-void

    .line 139
    :cond_2
    instance-of v0, p1, Lc7/c;

    .line 140
    .line 141
    if-eqz v0, :cond_3

    .line 142
    .line 143
    check-cast p1, Lc7/c;

    .line 144
    .line 145
    const-string v0, "null cannot be cast to non-null type com.maertsno.domain.model.HomeRow.ContinueWatchRow"

    .line 146
    .line 147
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    check-cast p2, Ly6/q;

    .line 151
    .line 152
    iget-object v0, p1, Lc7/c;->u:LN6/U0;

    .line 153
    .line 154
    iget-object v0, v0, LN6/U0;->F:Landroid/widget/TextView;

    .line 155
    .line 156
    iget-object v1, p2, Ly6/q;->a:Lcom/maertsno/domain/model/Shortcut;

    .line 157
    .line 158
    iget-object v1, v1, Lcom/maertsno/domain/model/Shortcut;->b:Ljava/lang/String;

    .line 159
    .line 160
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 161
    .line 162
    .line 163
    iget-object v0, p1, Lc7/c;->v:Ld8/j;

    .line 164
    .line 165
    invoke-virtual {v0}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v0

    .line 169
    check-cast v0, Lc7/m;

    .line 170
    .line 171
    iget-object p2, p2, Ly6/q;->b:Ljava/util/List;

    .line 172
    .line 173
    new-instance v1, LD/a;

    .line 174
    .line 175
    const/16 v2, 0xc

    .line 176
    .line 177
    invoke-direct {v1, v2, p1}, LD/a;-><init>(ILjava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    iget-object p1, v0, LG0/K;->d:LG0/f;

    .line 181
    .line 182
    invoke-virtual {p1, p2, v1}, LG0/f;->b(Ljava/util/List;Ljava/lang/Runnable;)V

    .line 183
    .line 184
    .line 185
    return-void

    .line 186
    :cond_3
    instance-of v0, p1, Lc7/d;

    .line 187
    .line 188
    if-eqz v0, :cond_4

    .line 189
    .line 190
    check-cast p1, Lc7/d;

    .line 191
    .line 192
    const-string v0, "null cannot be cast to non-null type com.maertsno.domain.model.HomeRow.MovieRow"

    .line 193
    .line 194
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    check-cast p2, Ly6/r;

    .line 198
    .line 199
    iget-object v0, p1, Lc7/d;->u:LN6/k1;

    .line 200
    .line 201
    iput-object p2, p1, Lc7/d;->w:Ly6/r;

    .line 202
    .line 203
    iget-object v0, v0, LN6/k1;->F:Landroid/widget/TextView;

    .line 204
    .line 205
    iget-object v1, p2, Ly6/r;->a:Lcom/maertsno/domain/model/Shortcut;

    .line 206
    .line 207
    iget-object v1, v1, Lcom/maertsno/domain/model/Shortcut;->b:Ljava/lang/String;

    .line 208
    .line 209
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 210
    .line 211
    .line 212
    iget-object p1, p1, Lc7/d;->v:Ld8/j;

    .line 213
    .line 214
    invoke-virtual {p1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object p1

    .line 218
    check-cast p1, Lc7/o;

    .line 219
    .line 220
    iget-object p2, p2, Ly6/r;->b:Ljava/util/List;

    .line 221
    .line 222
    invoke-virtual {p1, p2}, LG0/K;->n(Ljava/util/List;)V

    .line 223
    .line 224
    .line 225
    return-void

    .line 226
    :cond_4
    instance-of v0, p1, Lc7/h;

    .line 227
    .line 228
    if-eqz v0, :cond_9

    .line 229
    .line 230
    check-cast p1, Lc7/h;

    .line 231
    .line 232
    const-string v0, "null cannot be cast to non-null type com.maertsno.domain.model.HomeRow.TabsRow"

    .line 233
    .line 234
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 235
    .line 236
    .line 237
    check-cast p2, Ly6/u;

    .line 238
    .line 239
    iget-object v0, p1, Lc7/h;->u:LN6/q1;

    .line 240
    .line 241
    iput-object p2, p1, Lc7/h;->w:Ly6/u;

    .line 242
    .line 243
    iget-object p1, v0, LN6/q1;->G:Landroid/widget/TextView;

    .line 244
    .line 245
    iget-object v3, p2, Ly6/u;->a:Lcom/maertsno/domain/model/Shortcut;

    .line 246
    .line 247
    iget-object v3, v3, Lcom/maertsno/domain/model/Shortcut;->b:Ljava/lang/String;

    .line 248
    .line 249
    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 250
    .line 251
    .line 252
    iget-object p1, v0, LN6/q1;->E:Lcom/google/android/material/chip/ChipGroup;

    .line 253
    .line 254
    const-string v0, "chipGroup"

    .line 255
    .line 256
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    iget-object p2, p2, Ly6/u;->b:Ljava/util/List;

    .line 260
    .line 261
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 262
    .line 263
    .line 264
    move-result v0

    .line 265
    if-eqz v0, :cond_5

    .line 266
    .line 267
    invoke-virtual {p1}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 268
    .line 269
    .line 270
    :cond_5
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 271
    .line 272
    .line 273
    move-result-object p2

    .line 274
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 275
    .line 276
    .line 277
    move-result v0

    .line 278
    if-eqz v0, :cond_8

    .line 279
    .line 280
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    check-cast v0, Ly6/I;

    .line 285
    .line 286
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 287
    .line 288
    .line 289
    move-result-object v3

    .line 290
    invoke-static {v3}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 291
    .line 292
    .line 293
    move-result-object v3

    .line 294
    const v4, 0x7f0d006e

    .line 295
    .line 296
    .line 297
    invoke-virtual {v3, v4, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 298
    .line 299
    .line 300
    move-result-object v3

    .line 301
    instance-of v4, v3, Lcom/google/android/material/chip/Chip;

    .line 302
    .line 303
    if-eqz v4, :cond_6

    .line 304
    .line 305
    check-cast v3, Lcom/google/android/material/chip/Chip;

    .line 306
    .line 307
    goto :goto_1

    .line 308
    :cond_6
    move-object v3, v2

    .line 309
    :goto_1
    if-eqz v3, :cond_7

    .line 310
    .line 311
    invoke-static {}, Landroid/view/View;->generateViewId()I

    .line 312
    .line 313
    .line 314
    move-result v4

    .line 315
    invoke-virtual {v3, v4}, Landroid/view/View;->setId(I)V

    .line 316
    .line 317
    .line 318
    iget-object v4, v0, Ly6/I;->a:Ljava/lang/String;

    .line 319
    .line 320
    invoke-virtual {v3, v4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 321
    .line 322
    .line 323
    iget-object v0, v0, Ly6/I;->b:Ljava/lang/String;

    .line 324
    .line 325
    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 326
    .line 327
    .line 328
    :cond_7
    invoke-virtual {p1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 329
    .line 330
    .line 331
    goto :goto_0

    .line 332
    :cond_8
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 333
    .line 334
    .line 335
    move-result p2

    .line 336
    if-eqz p2, :cond_9

    .line 337
    .line 338
    invoke-static {p1}, LT8/d;->h(Landroid/view/ViewGroup;)Landroid/view/View;

    .line 339
    .line 340
    .line 341
    move-result-object p2

    .line 342
    invoke-virtual {p2}, Landroid/view/View;->getId()I

    .line 343
    .line 344
    .line 345
    move-result p2

    .line 346
    invoke-virtual {p1, p2}, Lcom/google/android/material/chip/ChipGroup;->a(I)V

    .line 347
    .line 348
    .line 349
    :cond_9
    return-void
.end method

.method public final h(Landroid/view/ViewGroup;I)LG0/u0;
    .locals 7

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sget-object v1, LA6/b;->b:Lk8/b;

    .line 10
    .line 11
    invoke-virtual {v1, p2}, Lk8/b;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p2

    .line 15
    check-cast p2, LA6/b;

    .line 16
    .line 17
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 18
    .line 19
    .line 20
    move-result p2

    .line 21
    iget-object v1, p0, Lc7/i;->e:Lcom/maertsno/m/ui/home/FragmentHome;

    .line 22
    .line 23
    const-string v2, "inflate(...)"

    .line 24
    .line 25
    const/4 v3, 0x0

    .line 26
    const/4 v4, 0x0

    .line 27
    if-eqz p2, :cond_2

    .line 28
    .line 29
    const/4 v5, 0x2

    .line 30
    iget-object v6, p0, Lc7/i;->f:Ld8/j;

    .line 31
    .line 32
    if-eq p2, v5, :cond_1

    .line 33
    .line 34
    const/4 v5, 0x3

    .line 35
    if-eq p2, v5, :cond_0

    .line 36
    .line 37
    new-instance p2, Lc7/d;

    .line 38
    .line 39
    sget v5, LN6/k1;->H:I

    .line 40
    .line 41
    sget-object v5, LW/c;->a:Landroidx/databinding/DataBinderMapperImpl;

    .line 42
    .line 43
    const v5, 0x7f0d0079

    .line 44
    .line 45
    .line 46
    invoke-static {v0, v5, p1, v4, v3}, LW/g;->X(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;ZLjava/lang/Object;)LW/g;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, LN6/k1;

    .line 51
    .line 52
    invoke-static {p1, v2}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v6}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    check-cast v0, LG0/j0;

    .line 60
    .line 61
    invoke-direct {p2, p1, v0, v1}, Lc7/d;-><init>(LN6/k1;LG0/j0;Lcom/maertsno/m/ui/home/FragmentHome;)V

    .line 62
    .line 63
    .line 64
    return-object p2

    .line 65
    :cond_0
    new-instance p2, Lc7/c;

    .line 66
    .line 67
    sget v5, LN6/U0;->G:I

    .line 68
    .line 69
    sget-object v5, LW/c;->a:Landroidx/databinding/DataBinderMapperImpl;

    .line 70
    .line 71
    const v5, 0x7f0d0070

    .line 72
    .line 73
    .line 74
    invoke-static {v0, v5, p1, v4, v3}, LW/g;->X(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;ZLjava/lang/Object;)LW/g;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    check-cast p1, LN6/U0;

    .line 79
    .line 80
    invoke-static {p1, v2}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    invoke-direct {p2, p1, v1}, Lc7/c;-><init>(LN6/U0;Lcom/maertsno/m/ui/home/FragmentHome;)V

    .line 84
    .line 85
    .line 86
    return-object p2

    .line 87
    :cond_1
    new-instance p2, Lc7/h;

    .line 88
    .line 89
    sget v5, LN6/q1;->H:I

    .line 90
    .line 91
    sget-object v5, LW/c;->a:Landroidx/databinding/DataBinderMapperImpl;

    .line 92
    .line 93
    const v5, 0x7f0d007d

    .line 94
    .line 95
    .line 96
    invoke-static {v0, v5, p1, v4, v3}, LW/g;->X(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;ZLjava/lang/Object;)LW/g;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    check-cast p1, LN6/q1;

    .line 101
    .line 102
    invoke-static {p1, v2}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v6}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    check-cast v0, LG0/j0;

    .line 110
    .line 111
    invoke-direct {p2, p1, v0, v1}, Lc7/h;-><init>(LN6/q1;LG0/j0;Lcom/maertsno/m/ui/home/FragmentHome;)V

    .line 112
    .line 113
    .line 114
    return-object p2

    .line 115
    :cond_2
    new-instance p2, Lc7/g;

    .line 116
    .line 117
    sget v5, LN6/L0;->L:I

    .line 118
    .line 119
    sget-object v5, LW/c;->a:Landroidx/databinding/DataBinderMapperImpl;

    .line 120
    .line 121
    const v5, 0x7f0d0069

    .line 122
    .line 123
    .line 124
    invoke-static {v0, v5, p1, v4, v3}, LW/g;->X(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;ZLjava/lang/Object;)LW/g;

    .line 125
    .line 126
    .line 127
    move-result-object p1

    .line 128
    check-cast p1, LN6/L0;

    .line 129
    .line 130
    invoke-static {p1, v2}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    invoke-direct {p2, p1, v1}, Lc7/g;-><init>(LN6/L0;Lcom/maertsno/m/ui/home/FragmentHome;)V

    .line 134
    .line 135
    .line 136
    return-object p2
.end method

.method public final k(LG0/u0;)V
    .locals 4

    .line 1
    instance-of v0, p1, Lc7/g;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    check-cast p1, Lc7/g;

    .line 6
    .line 7
    iget-object v0, p1, Lc7/g;->w:Landroid/os/Handler;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    new-instance v1, LG0/v;

    .line 14
    .line 15
    const/16 v2, 0x12

    .line 16
    .line 17
    invoke-direct {v1, v2, p1}, LG0/v;-><init>(ILjava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    const-wide/16 v2, 0x1388

    .line 21
    .line 22
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void
.end method

.method public final l(LG0/u0;)V
    .locals 1

    .line 1
    instance-of v0, p1, Lc7/g;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    check-cast p1, Lc7/g;

    .line 6
    .line 7
    iget-object p1, p1, Lc7/g;->w:Landroid/os/Handler;

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    return-void
.end method
