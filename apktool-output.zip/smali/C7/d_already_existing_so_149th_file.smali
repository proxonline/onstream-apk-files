.class public final Lc7/d;
.super LG0/u0;
.source "SourceFile"


# instance fields
.field public final u:LN6/k1;

.field public final v:Ld8/j;

.field public w:Ly6/r;


# direct methods
.method public constructor <init>(LN6/k1;LG0/j0;Lcom/maertsno/m/ui/home/FragmentHome;)V
    .locals 2

    .line 1
    const-string v0, "pool"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "listener"

    .line 7
    .line 8
    invoke-static {p3, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p1, LW/g;->s:Landroid/view/View;

    .line 12
    .line 13
    invoke-direct {p0, v0}, LG0/u0;-><init>(Landroid/view/View;)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lc7/d;->u:LN6/k1;

    .line 17
    .line 18
    new-instance v0, Lb7/a;

    .line 19
    .line 20
    const/4 v1, 0x3

    .line 21
    invoke-direct {v0, p3, v1}, Lb7/a;-><init>(Lcom/maertsno/m/ui/home/FragmentHome;I)V

    .line 22
    .line 23
    .line 24
    invoke-static {v0}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    iput-object v0, p0, Lc7/d;->v:Ld8/j;

    .line 29
    .line 30
    iget-object v1, p1, LN6/k1;->E:Landroidx/recyclerview/widget/RecyclerView;

    .line 31
    .line 32
    invoke-virtual {v1, p2}, Landroidx/recyclerview/widget/RecyclerView;->setRecycledViewPool(LG0/j0;)V

    .line 33
    .line 34
    .line 35
    const/4 p2, 0x1

    .line 36
    invoke-virtual {v1, p2}, Landroidx/recyclerview/widget/RecyclerView;->setHasFixedSize(Z)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    check-cast p2, Lc7/o;

    .line 44
    .line 45
    invoke-virtual {v1, p2}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(LG0/V;)V

    .line 46
    .line 47
    .line 48
    iget-object p1, p1, LN6/k1;->G:Landroid/widget/TextView;

    .line 49
    .line 50
    new-instance p2, LG6/p;

    .line 51
    .line 52
    const/4 v0, 0x7

    .line 53
    invoke-direct {p2, p0, v0, p3}, LG6/p;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 57
    .line 58
    .line 59
    return-void
.end method
