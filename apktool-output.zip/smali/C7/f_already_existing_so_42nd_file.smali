.class public final Lc7/f;
.super Lf1/g;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lc7/g;LN6/L0;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lc7/f;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lc7/f;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc7/f;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lf1/f;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lc7/f;->a:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lc7/f;->b:Ljava/lang/Object;

    return-void
.end method

.method private final d(I)V
    .locals 0

    .line 1
    return-void
.end method

.method private final e(I)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final a(I)V
    .locals 5

    .line 1
    iget v0, p0, Lc7/f;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    iget-object v0, p0, Lc7/f;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, LN6/L0;

    .line 10
    .line 11
    iget-object v0, v0, LN6/L0;->H:Landroidx/viewpager2/widget/ViewPager2;

    .line 12
    .line 13
    if-nez p1, :cond_2

    .line 14
    .line 15
    iget-object p1, p0, Lc7/f;->b:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast p1, Lc7/g;

    .line 18
    .line 19
    iget-object p1, p1, Lc7/g;->x:Ljava/util/List;

    .line 20
    .line 21
    if-nez p1, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    const/4 v2, 0x1

    .line 29
    if-le v1, v2, :cond_2

    .line 30
    .line 31
    invoke-virtual {v0}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    invoke-static {p1}, Le8/j;->U(Ljava/util/List;)I

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    const/4 v4, 0x0

    .line 40
    if-ne v1, v3, :cond_1

    .line 41
    .line 42
    invoke-virtual {v0, v2, v4}, Landroidx/viewpager2/widget/ViewPager2;->b(IZ)V

    .line 43
    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    if-nez v1, :cond_2

    .line 47
    .line 48
    invoke-static {p1}, Le8/j;->U(Ljava/util/List;)I

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    sub-int/2addr p1, v2

    .line 53
    invoke-virtual {v0, p1, v4}, Landroidx/viewpager2/widget/ViewPager2;->b(IZ)V

    .line 54
    .line 55
    .line 56
    :cond_2
    :goto_0
    return-void

    .line 57
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public b(IFI)V
    .locals 5

    .line 1
    iget p3, p0, Lc7/f;->a:I

    .line 2
    .line 3
    packed-switch p3, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    iget-object p3, p0, Lc7/f;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p3, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 10
    .line 11
    iget-object v0, p0, Lc7/f;->c:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lf1/h;

    .line 14
    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    goto :goto_1

    .line 18
    :cond_0
    neg-float p2, p2

    .line 19
    const/4 v0, 0x0

    .line 20
    :goto_0
    invoke-virtual {p3}, Landroidx/recyclerview/widget/a;->w()I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-ge v0, v1, :cond_2

    .line 25
    .line 26
    invoke-virtual {p3, v0}, Landroidx/recyclerview/widget/a;->v(I)Landroid/view/View;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    if-eqz v1, :cond_1

    .line 31
    .line 32
    invoke-static {v1}, Landroidx/recyclerview/widget/a;->L(Landroid/view/View;)I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    sub-int/2addr v2, p1

    .line 37
    int-to-float v2, v2

    .line 38
    add-float/2addr v2, p2

    .line 39
    iget-object v3, p0, Lc7/f;->c:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v3, Lf1/h;

    .line 42
    .line 43
    check-cast v3, LI7/d;

    .line 44
    .line 45
    iget v4, v3, LI7/d;->a:F

    .line 46
    .line 47
    iget v3, v3, LI7/d;->b:F

    .line 48
    .line 49
    neg-float v4, v4

    .line 50
    mul-float/2addr v4, v2

    .line 51
    invoke-virtual {v1, v4}, Landroid/view/View;->setTranslationX(F)V

    .line 52
    .line 53
    .line 54
    const/4 v4, 0x1

    .line 55
    int-to-float v4, v4

    .line 56
    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    mul-float/2addr v2, v3

    .line 61
    sub-float/2addr v4, v2

    .line 62
    invoke-virtual {v1, v4}, Landroid/view/View;->setScaleY(F)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1}, Landroid/view/View;->getScaleY()F

    .line 66
    .line 67
    .line 68
    move-result v2

    .line 69
    invoke-virtual {v1, v2}, Landroid/view/View;->setScaleX(F)V

    .line 70
    .line 71
    .line 72
    add-int/lit8 v0, v0, 0x1

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 76
    .line 77
    sget-object p2, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 78
    .line 79
    invoke-virtual {p3}, Landroidx/recyclerview/widget/a;->w()I

    .line 80
    .line 81
    .line 82
    move-result p2

    .line 83
    new-instance p3, Ljava/lang/StringBuilder;

    .line 84
    .line 85
    const-string v1, "LayoutManager returned a null child at pos "

    .line 86
    .line 87
    invoke-direct {p3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    const-string v0, "/"

    .line 94
    .line 95
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    const-string p2, " while transforming pages"

    .line 102
    .line 103
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 104
    .line 105
    .line 106
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object p2

    .line 110
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    throw p1

    .line 114
    :cond_2
    :goto_1
    return-void

    .line 115
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public final c(I)V
    .locals 1

    .line 1
    iget v0, p0, Lc7/f;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    iget-object v0, p0, Lc7/f;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lc7/g;

    .line 10
    .line 11
    invoke-virtual {v0, p1}, Lc7/g;->r(I)V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
