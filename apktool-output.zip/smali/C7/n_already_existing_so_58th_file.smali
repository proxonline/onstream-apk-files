.class public final Lc7/n;
.super LR6/e;
.source "SourceFile"


# static fields
.field public static final f:LP6/a;


# instance fields
.field public final e:Lb7/b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LP6/a;

    .line 2
    .line 3
    const/16 v1, 0xa

    .line 4
    .line 5
    invoke-direct {v0, v1}, LP6/a;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lc7/n;->f:LP6/a;

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>(Lb7/b;)V
    .locals 1

    .line 1
    sget-object v0, Lc7/n;->f:LP6/a;

    .line 2
    .line 3
    invoke-direct {p0, v0}, LG0/K;-><init>(LG0/c;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lc7/n;->e:Lb7/b;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final o(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;)LR6/o;
    .locals 4

    .line 1
    new-instance v0, LP6/b;

    .line 2
    .line 3
    sget v1, LN6/b1;->G:I

    .line 4
    .line 5
    sget-object v1, LW/c;->a:Landroidx/databinding/DataBinderMapperImpl;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const v2, 0x7f0d0074

    .line 9
    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    invoke-static {p1, v2, p2, v3, v1}, LW/g;->X(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;ZLjava/lang/Object;)LW/g;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, LN6/b1;

    .line 17
    .line 18
    const-string p2, "inflate(...)"

    .line 19
    .line 20
    invoke-static {p1, p2}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget-object p2, p0, Lc7/n;->e:Lb7/b;

    .line 24
    .line 25
    invoke-direct {v0, p1, p2}, LP6/b;-><init>(LN6/b1;Lb7/b;)V

    .line 26
    .line 27
    .line 28
    return-object v0
.end method
