.class public final synthetic Lc7/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc7/l;

.field public final synthetic c:La9/u;


# direct methods
.method public synthetic constructor <init>(Lc7/l;La9/u;I)V
    .locals 0

    .line 1
    iput p3, p0, Lc7/j;->a:I

    iput-object p1, p0, Lc7/j;->b:Lc7/l;

    iput-object p2, p0, Lc7/j;->c:La9/u;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    .line 1
    iget p1, p0, Lc7/j;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lc7/j;->b:Lc7/l;

    .line 7
    .line 8
    iget-object p1, p1, Lc7/l;->v:Ly6/c;

    .line 9
    .line 10
    if-eqz p1, :cond_0

    .line 11
    .line 12
    iget-object v0, p1, Ly6/c;->k:Lcom/maertsno/domain/model/Movie;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    iget-object v0, p0, Lc7/j;->c:La9/u;

    .line 17
    .line 18
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    iget-object v0, v0, La9/u;->b:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lcom/maertsno/m/ui/home/FragmentHome;

    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Lcom/maertsno/m/ui/home/FragmentHome;->u0()Lb7/O;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    new-instance v1, Lb7/K;

    .line 33
    .line 34
    const/4 v2, 0x0

    .line 35
    invoke-direct {v1, p1, v0, v2}, Lb7/K;-><init>(Ly6/c;Lb7/O;Lh8/d;)V

    .line 36
    .line 37
    .line 38
    const/4 p1, 0x0

    .line 39
    invoke-virtual {v0, p1, v1}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 40
    .line 41
    .line 42
    :cond_0
    return-void

    .line 43
    :pswitch_0
    iget-object p1, p0, Lc7/j;->b:Lc7/l;

    .line 44
    .line 45
    iget-object p1, p1, Lc7/l;->v:Ly6/c;

    .line 46
    .line 47
    if-eqz p1, :cond_1

    .line 48
    .line 49
    iget-object p1, p1, Ly6/c;->k:Lcom/maertsno/domain/model/Movie;

    .line 50
    .line 51
    if-eqz p1, :cond_1

    .line 52
    .line 53
    iget-object v0, p0, Lc7/j;->c:La9/u;

    .line 54
    .line 55
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    iget-object v0, v0, La9/u;->b:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v0, Lcom/maertsno/m/ui/home/FragmentHome;

    .line 61
    .line 62
    invoke-virtual {v0, p1}, Lcom/maertsno/m/ui/home/FragmentHome;->v0(Lcom/maertsno/domain/model/Movie;)V

    .line 63
    .line 64
    .line 65
    :cond_1
    return-void

    .line 66
    nop

    .line 67
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
