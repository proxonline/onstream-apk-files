.class public final Lc7/m;
.super LR6/e;
.source "SourceFile"


# static fields
.field public static final f:LP6/a;


# instance fields
.field public final e:La9/u;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LP6/a;

    .line 2
    .line 3
    const/16 v1, 0x9

    .line 4
    .line 5
    invoke-direct {v0, v1}, LP6/a;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lc7/m;->f:LP6/a;

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>(La9/u;)V
    .locals 1

    .line 1
    sget-object v0, Lc7/m;->f:LP6/a;

    .line 2
    .line 3
    invoke-direct {p0, v0}, LG0/K;-><init>(LG0/c;)V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, Lc7/m;->e:La9/u;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final g(LG0/u0;I)V
    .locals 2

    .line 1
    check-cast p1, Lc7/l;

    .line 2
    .line 3
    invoke-super {p0, p1, p2}, LR6/e;->p(LR6/o;I)V

    .line 4
    .line 5
    .line 6
    iget-object p2, p1, Lc7/l;->u:LN6/S0;

    .line 7
    .line 8
    iget-object p2, p2, LN6/S0;->F:Lcom/google/android/material/button/MaterialButton;

    .line 9
    .line 10
    new-instance v0, LG6/p;

    .line 11
    .line 12
    const/16 v1, 0x8

    .line 13
    .line 14
    invoke-direct {v0, p0, v1, p1}, LG6/p;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p2, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final o(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;)LR6/o;
    .locals 4

    .line 1
    new-instance v0, Lc7/l;

    .line 2
    .line 3
    sget v1, LN6/S0;->J:I

    .line 4
    .line 5
    sget-object v1, LW/c;->a:Landroidx/databinding/DataBinderMapperImpl;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const v2, 0x7f0d006f

    .line 9
    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    invoke-static {p1, v2, p2, v3, v1}, LW/g;->X(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;ZLjava/lang/Object;)LW/g;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, LN6/S0;

    .line 17
    .line 18
    const-string p2, "inflate(...)"

    .line 19
    .line 20
    invoke-static {p1, p2}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget-object p2, p0, Lc7/m;->e:La9/u;

    .line 24
    .line 25
    invoke-direct {v0, p1, p2}, Lc7/l;-><init>(LN6/S0;La9/u;)V

    .line 26
    .line 27
    .line 28
    return-object v0
.end method

.method public final p(LR6/o;I)V
    .locals 2

    .line 1
    check-cast p1, Lc7/l;

    .line 2
    .line 3
    invoke-super {p0, p1, p2}, LR6/e;->p(LR6/o;I)V

    .line 4
    .line 5
    .line 6
    iget-object p2, p1, Lc7/l;->u:LN6/S0;

    .line 7
    .line 8
    iget-object p2, p2, LN6/S0;->F:Lcom/google/android/material/button/MaterialButton;

    .line 9
    .line 10
    new-instance v0, LG6/p;

    .line 11
    .line 12
    const/16 v1, 0x8

    .line 13
    .line 14
    invoke-direct {v0, p0, v1, p1}, LG6/p;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p2, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method
