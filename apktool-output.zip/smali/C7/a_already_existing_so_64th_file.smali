.class public final Lc7/a;
.super LR6/a;
.source "SourceFile"


# instance fields
.field public final synthetic v:I

.field public final w:LW/g;

.field public final x:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LN6/O0;Lb7/b;)V
    .locals 2

    const/4 v0, 0x0

    iput v0, p0, Lc7/a;->v:I

    const-string v0, "listener"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 1
    invoke-direct {p0, p1}, LR6/o;-><init>(LW/g;)V

    .line 2
    iput-object p1, p0, Lc7/a;->w:LW/g;

    .line 3
    new-instance v0, LD1/c;

    const/16 v1, 0xb

    invoke-direct {v0, v1, p0}, LD1/c;-><init>(ILjava/lang/Object;)V

    invoke-static {v0}, Lr3/e;->x(Lr8/a;)Ld8/j;

    move-result-object v0

    iput-object v0, p0, Lc7/a;->x:Ljava/lang/Object;

    .line 4
    iget-object p1, p1, LN6/O0;->E:Landroidx/appcompat/widget/AppCompatImageView;

    new-instance v0, LG6/p;

    const/4 v1, 0x6

    invoke-direct {v0, p0, v1, p2}, LG6/p;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public constructor <init>(LN6/a1;LB7/f;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lc7/a;->v:I

    const-string v0, "listener"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    invoke-direct {p0, p1}, LR6/o;-><init>(LW/g;)V

    .line 6
    iput-object p1, p0, Lc7/a;->w:LW/g;

    iput-object p2, p0, Lc7/a;->x:Ljava/lang/Object;

    .line 7
    iget-object p1, p1, LW/g;->s:Landroid/view/View;

    .line 8
    new-instance p2, LG6/n;

    const/16 v0, 0xc

    invoke-direct {p2, v0, p0}, LG6/n;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method


# virtual methods
.method public final r(Ljava/lang/Object;)V
    .locals 6

    .line 1
    iget v0, p0, Lc7/a;->v:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lcom/maertsno/domain/model/Episode;

    .line 7
    .line 8
    iput-object p1, p0, LR6/a;->u:Ljava/lang/Object;

    .line 9
    .line 10
    iget-object v0, p0, Lc7/a;->w:LW/g;

    .line 11
    .line 12
    check-cast v0, LN6/a1;

    .line 13
    .line 14
    iput-object p1, v0, LN6/a1;->J:Lcom/maertsno/domain/model/Episode;

    .line 15
    .line 16
    monitor-enter v0

    .line 17
    :try_start_0
    iget-wide v1, v0, LN6/a1;->M:J

    .line 18
    .line 19
    const-wide/16 v3, 0x1

    .line 20
    .line 21
    or-long/2addr v1, v3

    .line 22
    iput-wide v1, v0, LN6/a1;->M:J

    .line 23
    .line 24
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    const/4 p1, 0x2

    .line 26
    invoke-virtual {v0, p1}, Lf5/b;->A(I)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0}, LW/g;->c0()V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :catchall_0
    move-exception p1

    .line 34
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 35
    throw p1

    .line 36
    :pswitch_0
    const-string v0, "300x450"

    .line 37
    .line 38
    const-string v1, "200x300"

    .line 39
    .line 40
    check-cast p1, Lcom/maertsno/domain/model/Movie;

    .line 41
    .line 42
    iget-object v2, p1, Lcom/maertsno/domain/model/Movie;->c:Ljava/lang/String;

    .line 43
    .line 44
    const-string v3, "imageThumbnail"

    .line 45
    .line 46
    iget-object v4, p0, Lc7/a;->w:LW/g;

    .line 47
    .line 48
    check-cast v4, LN6/O0;

    .line 49
    .line 50
    iput-object p1, p0, LR6/a;->u:Ljava/lang/Object;

    .line 51
    .line 52
    iget-object v5, p0, Lc7/a;->x:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v5, Ld8/j;

    .line 55
    .line 56
    invoke-virtual {v5}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v5

    .line 60
    check-cast v5, Ljava/lang/Boolean;

    .line 61
    .line 62
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 63
    .line 64
    .line 65
    move-result v5

    .line 66
    if-eqz v5, :cond_1

    .line 67
    .line 68
    iget-object v4, v4, LN6/O0;->E:Landroidx/appcompat/widget/AppCompatImageView;

    .line 69
    .line 70
    invoke-static {v4, v3}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    iget-object p1, p1, Lcom/maertsno/domain/model/Movie;->b:Ljava/lang/String;

    .line 74
    .line 75
    invoke-static {p1}, Lz8/e;->j0(Ljava/lang/CharSequence;)Z

    .line 76
    .line 77
    .line 78
    move-result v3

    .line 79
    if-eqz v3, :cond_0

    .line 80
    .line 81
    invoke-static {v2, v1, v0}, Lz8/m;->Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    :cond_0
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-static {v0}, LC1/a;->a(Landroid/content/Context;)LC1/l;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    new-instance v1, LM1/i;

    .line 94
    .line 95
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    invoke-direct {v1, v2}, LM1/i;-><init>(Landroid/content/Context;)V

    .line 100
    .line 101
    .line 102
    iput-object p1, v1, LM1/i;->c:Ljava/lang/Object;

    .line 103
    .line 104
    invoke-virtual {v1, v4}, LM1/i;->b(Landroid/widget/ImageView;)V

    .line 105
    .line 106
    .line 107
    invoke-virtual {v1}, LM1/i;->a()LM1/j;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    invoke-virtual {v0, p1}, LC1/l;->b(LM1/j;)LM1/e;

    .line 112
    .line 113
    .line 114
    goto :goto_0

    .line 115
    :cond_1
    iget-object p1, v4, LN6/O0;->E:Landroidx/appcompat/widget/AppCompatImageView;

    .line 116
    .line 117
    invoke-static {p1, v3}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    invoke-static {v2, v1, v0}, Lz8/m;->Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-static {v1}, LC1/a;->a(Landroid/content/Context;)LC1/l;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    new-instance v2, LM1/i;

    .line 133
    .line 134
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 135
    .line 136
    .line 137
    move-result-object v3

    .line 138
    invoke-direct {v2, v3}, LM1/i;-><init>(Landroid/content/Context;)V

    .line 139
    .line 140
    .line 141
    iput-object v0, v2, LM1/i;->c:Ljava/lang/Object;

    .line 142
    .line 143
    invoke-virtual {v2, p1}, LM1/i;->b(Landroid/widget/ImageView;)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v2}, LM1/i;->a()LM1/j;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    invoke-virtual {v1, p1}, LC1/l;->b(LM1/j;)LM1/e;

    .line 151
    .line 152
    .line 153
    :goto_0
    return-void

    .line 154
    nop

    .line 155
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
