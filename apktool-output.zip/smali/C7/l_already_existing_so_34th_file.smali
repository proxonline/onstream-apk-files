.class public final Lc7/l;
.super LR6/o;
.source "SourceFile"


# instance fields
.field public final u:LN6/S0;

.field public v:Ly6/c;


# direct methods
.method public constructor <init>(LN6/S0;La9/u;)V
    .locals 3

    .line 1
    const-string v0, "listener"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0, p1}, LR6/o;-><init>(LW/g;)V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lc7/l;->u:LN6/S0;

    .line 10
    .line 11
    iget-object v0, p1, LN6/S0;->G:Lcom/google/android/material/imageview/ShapeableImageView;

    .line 12
    .line 13
    new-instance v1, Lc7/j;

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    invoke-direct {v1, p0, p2, v2}, Lc7/j;-><init>(Lc7/l;La9/u;I)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 20
    .line 21
    .line 22
    iget-object p1, p1, LN6/S0;->E:Lcom/google/android/material/button/MaterialButton;

    .line 23
    .line 24
    new-instance v0, Lc7/j;

    .line 25
    .line 26
    const/4 v1, 0x1

    .line 27
    invoke-direct {v0, p0, p2, v1}, Lc7/j;-><init>(Lc7/l;La9/u;I)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public final r(Ljava/lang/Object;)V
    .locals 10

    .line 1
    check-cast p1, Ly6/c;

    .line 2
    .line 3
    iput-object p1, p0, Lc7/l;->v:Ly6/c;

    .line 4
    .line 5
    iget-object v0, p1, Ly6/c;->k:Lcom/maertsno/domain/model/Movie;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    iget-object v2, v0, Lcom/maertsno/domain/model/Movie;->h:Lcom/maertsno/domain/type/MediaType;

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    move-object v2, v1

    .line 14
    :goto_0
    if-nez v2, :cond_1

    .line 15
    .line 16
    const/4 v2, -0x1

    .line 17
    goto :goto_1

    .line 18
    :cond_1
    sget-object v3, Lc7/k;->a:[I

    .line 19
    .line 20
    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    aget v2, v3, v2

    .line 25
    .line 26
    :goto_1
    const/4 v3, 0x0

    .line 27
    const/4 v4, 0x1

    .line 28
    iget-object v5, p0, Lc7/l;->u:LN6/S0;

    .line 29
    .line 30
    if-eq v2, v4, :cond_3

    .line 31
    .line 32
    const/4 v6, 0x2

    .line 33
    if-eq v2, v6, :cond_2

    .line 34
    .line 35
    goto :goto_2

    .line 36
    :cond_2
    iget-object v2, v5, LN6/S0;->E:Lcom/google/android/material/button/MaterialButton;

    .line 37
    .line 38
    iget-object v7, v5, LW/g;->s:Landroid/view/View;

    .line 39
    .line 40
    invoke-virtual {v7}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 41
    .line 42
    .line 43
    move-result-object v7

    .line 44
    iget v8, p1, Ly6/c;->f:I

    .line 45
    .line 46
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 47
    .line 48
    .line 49
    move-result-object v8

    .line 50
    iget v9, p1, Ly6/c;->g:I

    .line 51
    .line 52
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 53
    .line 54
    .line 55
    move-result-object v9

    .line 56
    new-array v6, v6, [Ljava/lang/Object;

    .line 57
    .line 58
    aput-object v8, v6, v3

    .line 59
    .line 60
    aput-object v9, v6, v4

    .line 61
    .line 62
    const v4, 0x7f1400be

    .line 63
    .line 64
    .line 65
    invoke-virtual {v7, v4, v6}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 70
    .line 71
    .line 72
    goto :goto_2

    .line 73
    :cond_3
    iget-object v2, v5, LN6/S0;->E:Lcom/google/android/material/button/MaterialButton;

    .line 74
    .line 75
    const v4, 0x7f1401e3

    .line 76
    .line 77
    .line 78
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(I)V

    .line 79
    .line 80
    .line 81
    :goto_2
    iget-object v2, v5, LN6/S0;->H:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    .line 82
    .line 83
    iget-object v4, v5, LN6/S0;->I:Landroid/widget/TextView;

    .line 84
    .line 85
    iget p1, p1, Ly6/c;->i:I

    .line 86
    .line 87
    invoke-virtual {v2, p1}, Lx4/d;->setProgress(I)V

    .line 88
    .line 89
    .line 90
    iget-object p1, v5, LN6/S0;->G:Lcom/google/android/material/imageview/ShapeableImageView;

    .line 91
    .line 92
    const-string v2, "imageThumbnail"

    .line 93
    .line 94
    invoke-static {p1, v2}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    if-eqz v0, :cond_4

    .line 98
    .line 99
    iget-object v2, v0, Lcom/maertsno/domain/model/Movie;->c:Ljava/lang/String;

    .line 100
    .line 101
    goto :goto_3

    .line 102
    :cond_4
    move-object v2, v1

    .line 103
    :goto_3
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 104
    .line 105
    .line 106
    move-result-object v5

    .line 107
    invoke-static {v5}, LC1/a;->a(Landroid/content/Context;)LC1/l;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    new-instance v6, LM1/i;

    .line 112
    .line 113
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 114
    .line 115
    .line 116
    move-result-object v7

    .line 117
    invoke-direct {v6, v7}, LM1/i;-><init>(Landroid/content/Context;)V

    .line 118
    .line 119
    .line 120
    iput-object v2, v6, LM1/i;->c:Ljava/lang/Object;

    .line 121
    .line 122
    invoke-virtual {v6, p1}, LM1/i;->b(Landroid/widget/ImageView;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v6}, LM1/i;->a()LM1/j;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    invoke-virtual {v5, p1}, LC1/l;->b(LM1/j;)LM1/e;

    .line 130
    .line 131
    .line 132
    const-string p1, "textTag"

    .line 133
    .line 134
    invoke-static {v4, p1}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    const/16 p1, 0x8

    .line 138
    .line 139
    invoke-virtual {v4, p1}, Landroid/view/View;->setVisibility(I)V

    .line 140
    .line 141
    .line 142
    if-eqz v0, :cond_5

    .line 143
    .line 144
    iget-object v1, v0, Lcom/maertsno/domain/model/Movie;->h:Lcom/maertsno/domain/type/MediaType;

    .line 145
    .line 146
    :cond_5
    sget-object v2, Lcom/maertsno/domain/type/MediaType;->c:Lcom/maertsno/domain/type/MediaType;

    .line 147
    .line 148
    if-ne v1, v2, :cond_7

    .line 149
    .line 150
    iget-object v1, v0, Lcom/maertsno/domain/model/Movie;->n:Ljava/lang/String;

    .line 151
    .line 152
    invoke-static {v1}, Lz8/e;->j0(Ljava/lang/CharSequence;)Z

    .line 153
    .line 154
    .line 155
    move-result v1

    .line 156
    if-nez v1, :cond_6

    .line 157
    .line 158
    goto :goto_4

    .line 159
    :cond_6
    move v3, p1

    .line 160
    :goto_4
    invoke-virtual {v4, v3}, Landroid/view/View;->setVisibility(I)V

    .line 161
    .line 162
    .line 163
    iget-object p1, v0, Lcom/maertsno/domain/model/Movie;->n:Ljava/lang/String;

    .line 164
    .line 165
    invoke-virtual {v4, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 166
    .line 167
    .line 168
    :cond_7
    return-void
.end method
