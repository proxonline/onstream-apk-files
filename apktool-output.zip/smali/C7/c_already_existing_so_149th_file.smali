.class public final Lc7/c;
.super LG0/u0;
.source "SourceFile"


# instance fields
.field public final u:LN6/U0;

.field public final v:Ld8/j;


# direct methods
.method public constructor <init>(LN6/U0;Lcom/maertsno/m/ui/home/FragmentHome;)V
    .locals 2

    .line 1
    const-string v0, "listener"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p1, LW/g;->s:Landroid/view/View;

    .line 7
    .line 8
    invoke-direct {p0, v0}, LG0/u0;-><init>(Landroid/view/View;)V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lc7/c;->u:LN6/U0;

    .line 12
    .line 13
    new-instance v0, Lb7/a;

    .line 14
    .line 15
    const/4 v1, 0x2

    .line 16
    invoke-direct {v0, p2, v1}, Lb7/a;-><init>(Lcom/maertsno/m/ui/home/FragmentHome;I)V

    .line 17
    .line 18
    .line 19
    invoke-static {v0}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    iput-object p2, p0, Lc7/c;->v:Ld8/j;

    .line 24
    .line 25
    iget-object p1, p1, LN6/U0;->E:Landroidx/recyclerview/widget/RecyclerView;

    .line 26
    .line 27
    const/4 v0, 0x1

    .line 28
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setHasFixedSize(Z)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p2}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p2

    .line 35
    check-cast p2, Lc7/m;

    .line 36
    .line 37
    invoke-virtual {p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(LG0/V;)V

    .line 38
    .line 39
    .line 40
    return-void
.end method
