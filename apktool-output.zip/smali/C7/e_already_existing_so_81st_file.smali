.class public final synthetic Lc7/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc7/g;

.field public final synthetic c:Lcom/maertsno/m/ui/home/FragmentHome;


# direct methods
.method public synthetic constructor <init>(Lc7/g;Lcom/maertsno/m/ui/home/FragmentHome;I)V
    .locals 0

    .line 1
    iput p3, p0, Lc7/e;->a:I

    iput-object p1, p0, Lc7/e;->b:Lc7/g;

    iput-object p2, p0, Lc7/e;->c:Lcom/maertsno/m/ui/home/FragmentHome;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 5

    .line 1
    iget p1, p0, Lc7/e;->a:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p0, Lc7/e;->b:Lc7/g;

    .line 7
    .line 8
    iget-object v0, p1, Lc7/g;->y:Lcom/maertsno/domain/model/Movie;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    goto :goto_1

    .line 13
    :cond_0
    iget-object v1, p0, Lc7/e;->c:Lcom/maertsno/m/ui/home/FragmentHome;

    .line 14
    .line 15
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1}, Lcom/maertsno/m/ui/home/FragmentHome;->u0()Lb7/O;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    iget-object v2, v2, LR6/s;->c:LE8/U;

    .line 23
    .line 24
    invoke-interface {v2}, LE8/S;->getValue()Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    check-cast v2, Ljava/lang/Boolean;

    .line 29
    .line 30
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    const/4 v3, 0x1

    .line 35
    if-eqz v2, :cond_1

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_1
    iget-boolean v2, v0, Lcom/maertsno/domain/model/Movie;->v:Z

    .line 39
    .line 40
    const/4 v4, 0x0

    .line 41
    if-eqz v2, :cond_2

    .line 42
    .line 43
    invoke-virtual {v1}, Lcom/maertsno/m/ui/home/FragmentHome;->u0()Lb7/O;

    .line 44
    .line 45
    .line 46
    move-result-object v1

    .line 47
    new-instance v2, Lb7/N;

    .line 48
    .line 49
    invoke-direct {v2, v1, v0, v4}, Lb7/N;-><init>(Lb7/O;Lcom/maertsno/domain/model/Movie;Lh8/d;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v1, v3, v2}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 53
    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_2
    invoke-virtual {v1}, Lcom/maertsno/m/ui/home/FragmentHome;->u0()Lb7/O;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    new-instance v2, Lb7/D;

    .line 61
    .line 62
    invoke-direct {v2, v1, v0, v4}, Lb7/D;-><init>(Lb7/O;Lcom/maertsno/domain/model/Movie;Lh8/d;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1, v3, v2}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 66
    .line 67
    .line 68
    :goto_0
    iget-wide v1, v0, Lcom/maertsno/domain/model/Movie;->a:J

    .line 69
    .line 70
    iget-boolean v0, v0, Lcom/maertsno/domain/model/Movie;->v:Z

    .line 71
    .line 72
    xor-int/2addr v0, v3

    .line 73
    invoke-virtual {p1, v1, v2, v0}, Lc7/g;->s(JZ)V

    .line 74
    .line 75
    .line 76
    :goto_1
    return-void

    .line 77
    :pswitch_0
    iget-object p1, p0, Lc7/e;->b:Lc7/g;

    .line 78
    .line 79
    iget-object p1, p1, Lc7/g;->y:Lcom/maertsno/domain/model/Movie;

    .line 80
    .line 81
    if-eqz p1, :cond_3

    .line 82
    .line 83
    iget-object v0, p0, Lc7/e;->c:Lcom/maertsno/m/ui/home/FragmentHome;

    .line 84
    .line 85
    invoke-virtual {v0, p1}, Lcom/maertsno/m/ui/home/FragmentHome;->v0(Lcom/maertsno/domain/model/Movie;)V

    .line 86
    .line 87
    .line 88
    :cond_3
    return-void

    .line 89
    :pswitch_1
    iget-object p1, p0, Lc7/e;->b:Lc7/g;

    .line 90
    .line 91
    iget-object p1, p1, Lc7/g;->y:Lcom/maertsno/domain/model/Movie;

    .line 92
    .line 93
    if-eqz p1, :cond_4

    .line 94
    .line 95
    iget-object v0, p0, Lc7/e;->c:Lcom/maertsno/m/ui/home/FragmentHome;

    .line 96
    .line 97
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 98
    .line 99
    .line 100
    invoke-virtual {v0}, Lcom/maertsno/m/ui/home/FragmentHome;->u0()Lb7/O;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    new-instance v1, Lb7/J;

    .line 105
    .line 106
    const/4 v2, 0x0

    .line 107
    invoke-direct {v1, v0, p1, v2}, Lb7/J;-><init>(Lb7/O;Lcom/maertsno/domain/model/Movie;Lh8/d;)V

    .line 108
    .line 109
    .line 110
    const/4 p1, 0x0

    .line 111
    invoke-virtual {v0, p1, v1}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 112
    .line 113
    .line 114
    :cond_4
    return-void

    .line 115
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
