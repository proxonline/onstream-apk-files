.class public final Lc7/g;
.super LG0/u0;
.source "SourceFile"


# instance fields
.field public final u:LN6/L0;

.field public final v:Ld8/j;

.field public final w:Landroid/os/Handler;

.field public x:Ljava/util/List;

.field public y:Lcom/maertsno/domain/model/Movie;


# direct methods
.method public constructor <init>(LN6/L0;Lcom/maertsno/m/ui/home/FragmentHome;)V
    .locals 5

    .line 1
    const-string v0, "listener"

    .line 2
    .line 3
    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p1, LW/g;->s:Landroid/view/View;

    .line 7
    .line 8
    invoke-direct {p0, v0}, LG0/u0;-><init>(Landroid/view/View;)V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lc7/g;->u:LN6/L0;

    .line 12
    .line 13
    new-instance v0, Lb7/a;

    .line 14
    .line 15
    const/4 v1, 0x4

    .line 16
    invoke-direct {v0, p2, v1}, Lb7/a;-><init>(Lcom/maertsno/m/ui/home/FragmentHome;I)V

    .line 17
    .line 18
    .line 19
    invoke-static {v0}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, Lc7/g;->v:Ld8/j;

    .line 24
    .line 25
    new-instance v1, Landroid/os/Handler;

    .line 26
    .line 27
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 32
    .line 33
    .line 34
    iput-object v1, p0, Lc7/g;->w:Landroid/os/Handler;

    .line 35
    .line 36
    iget-object v1, p1, LN6/L0;->H:Landroidx/viewpager2/widget/ViewPager2;

    .line 37
    .line 38
    invoke-virtual {v0}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, Lc7/b;

    .line 43
    .line 44
    invoke-virtual {v1, v0}, Landroidx/viewpager2/widget/ViewPager2;->setAdapter(LG0/V;)V

    .line 45
    .line 46
    .line 47
    invoke-static {v1}, LI7/f;->d(Landroid/view/View;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eqz v0, :cond_0

    .line 52
    .line 53
    const v2, 0x7f0701e5

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_0
    const v2, 0x7f0700c8

    .line 58
    .line 59
    .line 60
    :goto_0
    if-eqz v0, :cond_1

    .line 61
    .line 62
    const v3, 0x7f0701c4

    .line 63
    .line 64
    .line 65
    goto :goto_1

    .line 66
    :cond_1
    const v3, 0x7f0701da

    .line 67
    .line 68
    .line 69
    :goto_1
    if-eqz v0, :cond_2

    .line 70
    .line 71
    const v0, 0x3e4ccccd    # 0.2f

    .line 72
    .line 73
    .line 74
    goto :goto_2

    .line 75
    :cond_2
    const v0, 0x3e99999a    # 0.3f

    .line 76
    .line 77
    .line 78
    :goto_2
    const/4 v4, 0x1

    .line 79
    invoke-virtual {v1, v4}, Landroidx/viewpager2/widget/ViewPager2;->setOffscreenPageLimit(I)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    invoke-virtual {v4, v2}, Landroid/content/res/Resources;->getDimension(I)F

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    invoke-virtual {v1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 91
    .line 92
    .line 93
    move-result-object v4

    .line 94
    invoke-virtual {v4, v3}, Landroid/content/res/Resources;->getDimension(I)F

    .line 95
    .line 96
    .line 97
    move-result v4

    .line 98
    add-float/2addr v4, v2

    .line 99
    new-instance v2, LI7/d;

    .line 100
    .line 101
    invoke-direct {v2, v4, v0}, LI7/d;-><init>(FF)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v1, v2}, Landroidx/viewpager2/widget/ViewPager2;->setPageTransformer(Lf1/h;)V

    .line 105
    .line 106
    .line 107
    new-instance v0, LI7/c;

    .line 108
    .line 109
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    const-string v4, "getContext(...)"

    .line 114
    .line 115
    invoke-static {v2, v4}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 116
    .line 117
    .line 118
    invoke-direct {v0, v2, v3}, LI7/c;-><init>(Landroid/content/Context;I)V

    .line 119
    .line 120
    .line 121
    iget-object v2, v1, Landroidx/viewpager2/widget/ViewPager2;->j:Lf1/j;

    .line 122
    .line 123
    invoke-virtual {v2, v0}, Landroidx/recyclerview/widget/RecyclerView;->i(LG0/d0;)V

    .line 124
    .line 125
    .line 126
    new-instance v0, Lc7/f;

    .line 127
    .line 128
    invoke-direct {v0, p0, p1}, Lc7/f;-><init>(Lc7/g;LN6/L0;)V

    .line 129
    .line 130
    .line 131
    iget-object v1, v1, Landroidx/viewpager2/widget/ViewPager2;->c:Le1/b;

    .line 132
    .line 133
    iget-object v1, v1, Le1/b;->b:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast v1, Ljava/util/ArrayList;

    .line 136
    .line 137
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    iget-object v0, p1, LN6/L0;->G:Lcom/google/android/material/button/MaterialButton;

    .line 141
    .line 142
    new-instance v1, Lc7/e;

    .line 143
    .line 144
    const/4 v2, 0x0

    .line 145
    invoke-direct {v1, p0, p2, v2}, Lc7/e;-><init>(Lc7/g;Lcom/maertsno/m/ui/home/FragmentHome;I)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 149
    .line 150
    .line 151
    iget-object v0, p1, LN6/L0;->F:Lcom/google/android/material/button/MaterialButton;

    .line 152
    .line 153
    new-instance v1, Lc7/e;

    .line 154
    .line 155
    const/4 v2, 0x1

    .line 156
    invoke-direct {v1, p0, p2, v2}, Lc7/e;-><init>(Lc7/g;Lcom/maertsno/m/ui/home/FragmentHome;I)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 160
    .line 161
    .line 162
    iget-object p1, p1, LN6/L0;->E:Lcom/google/android/material/button/MaterialButton;

    .line 163
    .line 164
    new-instance v0, Lc7/e;

    .line 165
    .line 166
    const/4 v1, 0x2

    .line 167
    invoke-direct {v0, p0, p2, v1}, Lc7/e;-><init>(Lc7/g;Lcom/maertsno/m/ui/home/FragmentHome;I)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 171
    .line 172
    .line 173
    return-void
.end method


# virtual methods
.method public final r(I)V
    .locals 4

    .line 1
    sget-object v0, Lc7/i;->i:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lc7/g;->x:Ljava/util/List;

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-static {p1, v0}, Le8/i;->m0(ILjava/util/List;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lcom/maertsno/domain/model/Movie;

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 p1, 0x0

    .line 18
    :goto_0
    iput-object p1, p0, Lc7/g;->y:Lcom/maertsno/domain/model/Movie;

    .line 19
    .line 20
    if-nez p1, :cond_1

    .line 21
    .line 22
    return-void

    .line 23
    :cond_1
    iget-object v0, p0, Lc7/g;->u:LN6/L0;

    .line 24
    .line 25
    iget-object v1, v0, LN6/L0;->J:Landroid/widget/TextView;

    .line 26
    .line 27
    iget-object v2, p1, Lcom/maertsno/domain/model/Movie;->d:Ljava/lang/String;

    .line 28
    .line 29
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 30
    .line 31
    .line 32
    iget-object v1, v0, LN6/L0;->I:Landroid/widget/TextView;

    .line 33
    .line 34
    invoke-virtual {p1}, Lcom/maertsno/domain/model/Movie;->b()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 39
    .line 40
    .line 41
    iget-object v1, v0, LN6/L0;->K:Landroid/widget/TextView;

    .line 42
    .line 43
    iget-object v2, p1, Lcom/maertsno/domain/model/Movie;->h:Lcom/maertsno/domain/type/MediaType;

    .line 44
    .line 45
    sget-object v3, Lcom/maertsno/domain/type/MediaType;->c:Lcom/maertsno/domain/type/MediaType;

    .line 46
    .line 47
    if-ne v2, v3, :cond_2

    .line 48
    .line 49
    const v2, 0x7f140205

    .line 50
    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_2
    const v2, 0x7f14022a

    .line 54
    .line 55
    .line 56
    :goto_1
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    .line 57
    .line 58
    .line 59
    iget-object v0, v0, LN6/L0;->E:Lcom/google/android/material/button/MaterialButton;

    .line 60
    .line 61
    iget-boolean p1, p1, Lcom/maertsno/domain/model/Movie;->v:Z

    .line 62
    .line 63
    if-eqz p1, :cond_3

    .line 64
    .line 65
    const p1, 0x7f080159

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0, p1}, Lcom/google/android/material/button/MaterialButton;->setIconResource(I)V

    .line 69
    .line 70
    .line 71
    const p1, 0x7f1401d9

    .line 72
    .line 73
    .line 74
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(I)V

    .line 75
    .line 76
    .line 77
    const p1, 0x7f060044

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0, p1}, Lcom/google/android/material/button/MaterialButton;->setIconTintResource(I)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_3
    const p1, 0x7f080158

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0, p1}, Lcom/google/android/material/button/MaterialButton;->setIconResource(I)V

    .line 88
    .line 89
    .line 90
    const p1, 0x7f1400cf

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(I)V

    .line 94
    .line 95
    .line 96
    const p1, 0x7f06005b

    .line 97
    .line 98
    .line 99
    invoke-virtual {v0, p1}, Lcom/google/android/material/button/MaterialButton;->setIconTintResource(I)V

    .line 100
    .line 101
    .line 102
    return-void
.end method

.method public final s(JZ)V
    .locals 6

    .line 1
    iget-object v0, p0, Lc7/g;->x:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    const/4 v1, 0x0

    .line 10
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v2

    .line 14
    if-eqz v2, :cond_2

    .line 15
    .line 16
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    add-int/lit8 v3, v1, 0x1

    .line 21
    .line 22
    if-ltz v1, :cond_1

    .line 23
    .line 24
    check-cast v2, Lcom/maertsno/domain/model/Movie;

    .line 25
    .line 26
    iget-wide v4, v2, Lcom/maertsno/domain/model/Movie;->a:J

    .line 27
    .line 28
    cmp-long v4, p1, v4

    .line 29
    .line 30
    if-nez v4, :cond_0

    .line 31
    .line 32
    iput-boolean p3, v2, Lcom/maertsno/domain/model/Movie;->v:Z

    .line 33
    .line 34
    iget-object p1, p0, Lc7/g;->v:Ld8/j;

    .line 35
    .line 36
    invoke-virtual {p1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Lc7/b;

    .line 41
    .line 42
    invoke-virtual {p1, v1, v2}, LG0/V;->e(ILjava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p0, v1}, Lc7/g;->r(I)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :cond_0
    move v1, v3

    .line 50
    goto :goto_0

    .line 51
    :cond_1
    invoke-static {}, Le8/j;->Y()V

    .line 52
    .line 53
    .line 54
    const/4 p1, 0x0

    .line 55
    throw p1

    .line 56
    :cond_2
    return-void
.end method
