.class public final LC7/s;
.super LR6/s;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, LR6/s;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
