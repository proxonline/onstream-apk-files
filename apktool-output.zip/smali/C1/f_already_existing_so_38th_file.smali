.class public final synthetic LC1/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr8/a;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LC1/f;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LH0/h;)V
    .locals 0

    .line 2
    const/4 p1, 0x1

    iput p1, p0, LC1/f;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LC1/f;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x4

    .line 5
    const/4 v3, 0x2

    .line 6
    const/4 v4, 0x3

    .line 7
    const/4 v5, 0x0

    .line 8
    sget-object v6, Ld8/l;->a:Ld8/l;

    .line 9
    .line 10
    const/4 v7, 0x1

    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    new-instance v0, Lz7/b;

    .line 15
    .line 16
    invoke-direct {v0}, Lz7/b;-><init>()V

    .line 17
    .line 18
    .line 19
    return-object v0

    .line 20
    :pswitch_0
    return-object v6

    .line 21
    :pswitch_1
    new-instance v0, Ls7/b;

    .line 22
    .line 23
    sget-object v1, Ls7/b;->f:LP6/a;

    .line 24
    .line 25
    invoke-direct {v0, v1}, LG0/K;-><init>(LG0/c;)V

    .line 26
    .line 27
    .line 28
    return-object v0

    .line 29
    :pswitch_2
    new-instance v0, Lr7/a;

    .line 30
    .line 31
    sget-object v1, Lr7/a;->f:LP6/a;

    .line 32
    .line 33
    invoke-direct {v0, v1}, LG0/K;-><init>(LG0/c;)V

    .line 34
    .line 35
    .line 36
    const/4 v1, -0x1

    .line 37
    iput v1, v0, Lr7/a;->e:I

    .line 38
    .line 39
    return-object v0

    .line 40
    :pswitch_3
    new-instance v0, Lp7/p;

    .line 41
    .line 42
    invoke-direct {v0}, Lp7/p;-><init>()V

    .line 43
    .line 44
    .line 45
    return-object v0

    .line 46
    :pswitch_4
    new-instance v0, Lz7/b;

    .line 47
    .line 48
    invoke-direct {v0}, Lz7/b;-><init>()V

    .line 49
    .line 50
    .line 51
    return-object v0

    .line 52
    :pswitch_5
    sget v0, Lcom/maertsno/m/ui/main/MainActivity;->h0:I

    .line 53
    .line 54
    new-instance v0, Landroid/net/NetworkRequest$Builder;

    .line 55
    .line 56
    invoke-direct {v0}, Landroid/net/NetworkRequest$Builder;-><init>()V

    .line 57
    .line 58
    .line 59
    const/16 v1, 0xc

    .line 60
    .line 61
    invoke-virtual {v0, v1}, Landroid/net/NetworkRequest$Builder;->addCapability(I)Landroid/net/NetworkRequest$Builder;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-virtual {v0, v7}, Landroid/net/NetworkRequest$Builder;->addTransportType(I)Landroid/net/NetworkRequest$Builder;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    invoke-virtual {v0, v5}, Landroid/net/NetworkRequest$Builder;->addTransportType(I)Landroid/net/NetworkRequest$Builder;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-virtual {v0, v4}, Landroid/net/NetworkRequest$Builder;->addTransportType(I)Landroid/net/NetworkRequest$Builder;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-virtual {v0, v3}, Landroid/net/NetworkRequest$Builder;->addTransportType(I)Landroid/net/NetworkRequest$Builder;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-virtual {v0, v2}, Landroid/net/NetworkRequest$Builder;->addTransportType(I)Landroid/net/NetworkRequest$Builder;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-virtual {v0}, Landroid/net/NetworkRequest$Builder;->build()Landroid/net/NetworkRequest;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    return-object v0

    .line 90
    :pswitch_6
    new-instance v0, LG0/j0;

    .line 91
    .line 92
    invoke-direct {v0}, LG0/j0;-><init>()V

    .line 93
    .line 94
    .line 95
    return-object v0

    .line 96
    :pswitch_7
    new-instance v0, LX6/b;

    .line 97
    .line 98
    sget-object v1, LX6/b;->e:LP6/a;

    .line 99
    .line 100
    invoke-direct {v0, v1}, LG0/K;-><init>(LG0/c;)V

    .line 101
    .line 102
    .line 103
    return-object v0

    .line 104
    :pswitch_8
    new-instance v0, LX6/g;

    .line 105
    .line 106
    invoke-direct {v0}, LX6/g;-><init>()V

    .line 107
    .line 108
    .line 109
    return-object v0

    .line 110
    :pswitch_9
    new-instance v0, LX6/g;

    .line 111
    .line 112
    invoke-direct {v0}, LX6/g;-><init>()V

    .line 113
    .line 114
    .line 115
    return-object v0

    .line 116
    :pswitch_a
    new-instance v0, LX6/g;

    .line 117
    .line 118
    invoke-direct {v0}, LX6/g;-><init>()V

    .line 119
    .line 120
    .line 121
    return-object v0

    .line 122
    :pswitch_b
    new-instance v0, LX6/g;

    .line 123
    .line 124
    invoke-direct {v0}, LX6/g;-><init>()V

    .line 125
    .line 126
    .line 127
    return-object v0

    .line 128
    :pswitch_c
    :try_start_0
    sget-object v0, LT0/c;->c:Ljava/lang/Object;

    .line 129
    .line 130
    invoke-interface {v0}, Ld8/d;->getValue()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    check-cast v0, Ljava/lang/reflect/Method;

    .line 135
    .line 136
    if-eqz v0, :cond_0

    .line 137
    .line 138
    invoke-virtual {v0}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    if-eqz v0, :cond_0

    .line 143
    .line 144
    const-string v6, "beginTransaction"

    .line 145
    .line 146
    new-array v2, v2, [Ljava/lang/Class;

    .line 147
    .line 148
    sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 149
    .line 150
    aput-object v8, v2, v5

    .line 151
    .line 152
    const-class v5, Landroid/database/sqlite/SQLiteTransactionListener;

    .line 153
    .line 154
    aput-object v5, v2, v7

    .line 155
    .line 156
    aput-object v8, v2, v3

    .line 157
    .line 158
    const-class v3, Landroid/os/CancellationSignal;

    .line 159
    .line 160
    aput-object v3, v2, v4

    .line 161
    .line 162
    invoke-virtual {v0, v6, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 163
    .line 164
    .line 165
    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 166
    :catchall_0
    :cond_0
    return-object v1

    .line 167
    :pswitch_d
    :try_start_1
    const-class v0, Landroid/database/sqlite/SQLiteDatabase;

    .line 168
    .line 169
    const-string v2, "getThreadSession"

    .line 170
    .line 171
    invoke-virtual {v0, v2, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    invoke-virtual {v0, v7}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 176
    .line 177
    .line 178
    move-object v1, v0

    .line 179
    :catchall_1
    return-object v1

    .line 180
    :pswitch_e
    new-instance v0, LS6/a;

    .line 181
    .line 182
    sget-object v1, LS6/a;->e:LP6/a;

    .line 183
    .line 184
    invoke-direct {v0, v1}, LG0/K;-><init>(LG0/c;)V

    .line 185
    .line 186
    .line 187
    return-object v0

    .line 188
    :pswitch_f
    new-instance v0, LO6/f;

    .line 189
    .line 190
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 191
    .line 192
    .line 193
    return-object v0

    .line 194
    :pswitch_10
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 195
    .line 196
    return-object v0

    .line 197
    :pswitch_11
    return-object v6

    .line 198
    :pswitch_12
    new-instance v0, LL8/A;

    .line 199
    .line 200
    invoke-direct {v0}, LL8/A;-><init>()V

    .line 201
    .line 202
    .line 203
    return-object v0

    .line 204
    nop

    .line 205
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
