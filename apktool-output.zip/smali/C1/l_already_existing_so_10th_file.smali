.class public final LC1/l;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:LM1/c;

.field public final c:Ld8/j;

.field public final d:LQ1/j;

.field public final e:LG8/e;

.field public final f:Landroid/support/v4/media/session/z;

.field public final g:LC1/c;

.field public final h:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroid/content/Context;LM1/c;Ld8/j;Ld8/j;Ld8/j;LC1/c;LQ1/j;)V
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p6

    .line 4
    .line 5
    move-object/from16 v2, p7

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    move-object/from16 v3, p1

    .line 11
    .line 12
    iput-object v3, v0, LC1/l;->a:Landroid/content/Context;

    .line 13
    .line 14
    move-object/from16 v3, p2

    .line 15
    .line 16
    iput-object v3, v0, LC1/l;->b:LM1/c;

    .line 17
    .line 18
    move-object/from16 v3, p3

    .line 19
    .line 20
    iput-object v3, v0, LC1/l;->c:Ld8/j;

    .line 21
    .line 22
    iput-object v2, v0, LC1/l;->d:LQ1/j;

    .line 23
    .line 24
    invoke-static {}, LB8/D;->b()LB8/C0;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    sget-object v4, LB8/M;->a:LI8/e;

    .line 29
    .line 30
    sget-object v4, LG8/o;->a:LC8/d;

    .line 31
    .line 32
    iget-object v4, v4, LC8/d;->d:LC8/d;

    .line 33
    .line 34
    invoke-static {v3, v4}, Lcom/google/android/gms/internal/measurement/z1;->f0(Lh8/g;Lh8/i;)Lh8/i;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    new-instance v4, LC1/k;

    .line 39
    .line 40
    invoke-direct {v4, v0}, LC1/k;-><init>(LC1/l;)V

    .line 41
    .line 42
    .line 43
    invoke-interface {v3, v4}, Lh8/i;->plus(Lh8/i;)Lh8/i;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    invoke-static {v3}, LB8/D;->a(Lh8/i;)LG8/e;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    iput-object v3, v0, LC1/l;->e:LG8/e;

    .line 52
    .line 53
    new-instance v3, LQ1/m;

    .line 54
    .line 55
    invoke-direct {v3, v0}, LQ1/m;-><init>(LC1/l;)V

    .line 56
    .line 57
    .line 58
    new-instance v4, Landroid/support/v4/media/session/z;

    .line 59
    .line 60
    invoke-direct {v4, v0, v3}, Landroid/support/v4/media/session/z;-><init>(LC1/l;LQ1/m;)V

    .line 61
    .line 62
    .line 63
    iput-object v4, v0, LC1/l;->f:Landroid/support/v4/media/session/z;

    .line 64
    .line 65
    new-instance v5, LC1/b;

    .line 66
    .line 67
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 68
    .line 69
    .line 70
    iget-object v6, v1, LC1/c;->a:Ljava/util/List;

    .line 71
    .line 72
    invoke-static {v6}, Le8/i;->E0(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 73
    .line 74
    .line 75
    move-result-object v6

    .line 76
    iput-object v6, v5, LC1/b;->a:Ljava/lang/Object;

    .line 77
    .line 78
    iget-object v6, v1, LC1/c;->b:Ljava/util/List;

    .line 79
    .line 80
    invoke-static {v6}, Le8/i;->E0(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 81
    .line 82
    .line 83
    move-result-object v6

    .line 84
    iput-object v6, v5, LC1/b;->b:Ljava/lang/Object;

    .line 85
    .line 86
    iget-object v6, v1, LC1/c;->c:Ljava/util/List;

    .line 87
    .line 88
    invoke-static {v6}, Le8/i;->E0(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 89
    .line 90
    .line 91
    move-result-object v6

    .line 92
    iput-object v6, v5, LC1/b;->c:Ljava/lang/Object;

    .line 93
    .line 94
    iget-object v6, v1, LC1/c;->d:Ljava/util/List;

    .line 95
    .line 96
    invoke-static {v6}, Le8/i;->E0(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 97
    .line 98
    .line 99
    move-result-object v6

    .line 100
    iput-object v6, v5, LC1/b;->d:Ljava/lang/Object;

    .line 101
    .line 102
    iget-object v1, v1, LC1/c;->e:Ljava/util/List;

    .line 103
    .line 104
    invoke-static {v1}, Le8/i;->E0(Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    iput-object v1, v5, LC1/b;->e:Ljava/lang/Object;

    .line 109
    .line 110
    new-instance v1, LJ1/a;

    .line 111
    .line 112
    const/4 v6, 0x2

    .line 113
    invoke-direct {v1, v6}, LJ1/a;-><init>(I)V

    .line 114
    .line 115
    .line 116
    const-class v7, LL8/u;

    .line 117
    .line 118
    invoke-virtual {v5, v1, v7}, LC1/b;->i(LJ1/a;Ljava/lang/Class;)V

    .line 119
    .line 120
    .line 121
    new-instance v1, LJ1/a;

    .line 122
    .line 123
    const/4 v7, 0x5

    .line 124
    invoke-direct {v1, v7}, LJ1/a;-><init>(I)V

    .line 125
    .line 126
    .line 127
    const-class v8, Ljava/lang/String;

    .line 128
    .line 129
    invoke-virtual {v5, v1, v8}, LC1/b;->i(LJ1/a;Ljava/lang/Class;)V

    .line 130
    .line 131
    .line 132
    new-instance v1, LJ1/a;

    .line 133
    .line 134
    const/4 v8, 0x1

    .line 135
    invoke-direct {v1, v8}, LJ1/a;-><init>(I)V

    .line 136
    .line 137
    .line 138
    const-class v9, Landroid/net/Uri;

    .line 139
    .line 140
    invoke-virtual {v5, v1, v9}, LC1/b;->i(LJ1/a;Ljava/lang/Class;)V

    .line 141
    .line 142
    .line 143
    new-instance v1, LJ1/a;

    .line 144
    .line 145
    const/4 v10, 0x4

    .line 146
    invoke-direct {v1, v10}, LJ1/a;-><init>(I)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v5, v1, v9}, LC1/b;->i(LJ1/a;Ljava/lang/Class;)V

    .line 150
    .line 151
    .line 152
    new-instance v1, LJ1/a;

    .line 153
    .line 154
    const/4 v11, 0x3

    .line 155
    invoke-direct {v1, v11}, LJ1/a;-><init>(I)V

    .line 156
    .line 157
    .line 158
    const-class v12, Ljava/lang/Integer;

    .line 159
    .line 160
    invoke-virtual {v5, v1, v12}, LC1/b;->i(LJ1/a;Ljava/lang/Class;)V

    .line 161
    .line 162
    .line 163
    new-instance v1, LJ1/a;

    .line 164
    .line 165
    const/4 v12, 0x0

    .line 166
    invoke-direct {v1, v12}, LJ1/a;-><init>(I)V

    .line 167
    .line 168
    .line 169
    const-class v13, [B

    .line 170
    .line 171
    invoke-virtual {v5, v1, v13}, LC1/b;->i(LJ1/a;Ljava/lang/Class;)V

    .line 172
    .line 173
    .line 174
    new-instance v1, LI1/c;

    .line 175
    .line 176
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 177
    .line 178
    .line 179
    iget-object v13, v5, LC1/b;->c:Ljava/lang/Object;

    .line 180
    .line 181
    check-cast v13, Ljava/util/ArrayList;

    .line 182
    .line 183
    new-instance v14, Ld8/g;

    .line 184
    .line 185
    invoke-direct {v14, v1, v9}, Ld8/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v13, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 189
    .line 190
    .line 191
    new-instance v1, LI1/a;

    .line 192
    .line 193
    iget-boolean v14, v2, LQ1/j;->a:Z

    .line 194
    .line 195
    invoke-direct {v1, v14}, LI1/a;-><init>(Z)V

    .line 196
    .line 197
    .line 198
    new-instance v14, Ld8/g;

    .line 199
    .line 200
    const-class v15, Ljava/io/File;

    .line 201
    .line 202
    invoke-direct {v14, v1, v15}, Ld8/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 203
    .line 204
    .line 205
    invoke-virtual {v13, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    new-instance v1, LG1/i;

    .line 209
    .line 210
    iget-boolean v14, v2, LQ1/j;->c:Z

    .line 211
    .line 212
    move-object/from16 v6, p4

    .line 213
    .line 214
    move-object/from16 v8, p5

    .line 215
    .line 216
    invoke-direct {v1, v8, v6, v14}, LG1/i;-><init>(Ld8/j;Ld8/j;Z)V

    .line 217
    .line 218
    .line 219
    invoke-virtual {v5, v1, v9}, LC1/b;->h(LG1/f;Ljava/lang/Class;)V

    .line 220
    .line 221
    .line 222
    new-instance v1, LG1/a;

    .line 223
    .line 224
    invoke-direct {v1, v7}, LG1/a;-><init>(I)V

    .line 225
    .line 226
    .line 227
    invoke-virtual {v5, v1, v15}, LC1/b;->h(LG1/f;Ljava/lang/Class;)V

    .line 228
    .line 229
    .line 230
    new-instance v1, LG1/a;

    .line 231
    .line 232
    invoke-direct {v1, v12}, LG1/a;-><init>(I)V

    .line 233
    .line 234
    .line 235
    invoke-virtual {v5, v1, v9}, LC1/b;->h(LG1/f;Ljava/lang/Class;)V

    .line 236
    .line 237
    .line 238
    new-instance v1, LG1/a;

    .line 239
    .line 240
    invoke-direct {v1, v11}, LG1/a;-><init>(I)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v5, v1, v9}, LC1/b;->h(LG1/f;Ljava/lang/Class;)V

    .line 244
    .line 245
    .line 246
    new-instance v1, LG1/a;

    .line 247
    .line 248
    const/4 v6, 0x6

    .line 249
    invoke-direct {v1, v6}, LG1/a;-><init>(I)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v5, v1, v9}, LC1/b;->h(LG1/f;Ljava/lang/Class;)V

    .line 253
    .line 254
    .line 255
    new-instance v1, LG1/a;

    .line 256
    .line 257
    invoke-direct {v1, v10}, LG1/a;-><init>(I)V

    .line 258
    .line 259
    .line 260
    const-class v6, Landroid/graphics/drawable/Drawable;

    .line 261
    .line 262
    invoke-virtual {v5, v1, v6}, LC1/b;->h(LG1/f;Ljava/lang/Class;)V

    .line 263
    .line 264
    .line 265
    new-instance v1, LG1/a;

    .line 266
    .line 267
    const/4 v6, 0x1

    .line 268
    invoke-direct {v1, v6}, LG1/a;-><init>(I)V

    .line 269
    .line 270
    .line 271
    const-class v6, Landroid/graphics/Bitmap;

    .line 272
    .line 273
    invoke-virtual {v5, v1, v6}, LC1/b;->h(LG1/f;Ljava/lang/Class;)V

    .line 274
    .line 275
    .line 276
    new-instance v1, LG1/a;

    .line 277
    .line 278
    const/4 v6, 0x2

    .line 279
    invoke-direct {v1, v6}, LG1/a;-><init>(I)V

    .line 280
    .line 281
    .line 282
    const-class v6, Ljava/nio/ByteBuffer;

    .line 283
    .line 284
    invoke-virtual {v5, v1, v6}, LC1/b;->h(LG1/f;Ljava/lang/Class;)V

    .line 285
    .line 286
    .line 287
    new-instance v1, LD1/e;

    .line 288
    .line 289
    iget v6, v2, LQ1/j;->d:I

    .line 290
    .line 291
    iget-object v2, v2, LQ1/j;->e:LD1/l;

    .line 292
    .line 293
    invoke-direct {v1, v6, v2}, LD1/e;-><init>(ILD1/l;)V

    .line 294
    .line 295
    .line 296
    iget-object v2, v5, LC1/b;->e:Ljava/lang/Object;

    .line 297
    .line 298
    check-cast v2, Ljava/util/ArrayList;

    .line 299
    .line 300
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 301
    .line 302
    .line 303
    new-instance v1, LC1/c;

    .line 304
    .line 305
    iget-object v6, v5, LC1/b;->a:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast v6, Ljava/util/ArrayList;

    .line 308
    .line 309
    invoke-static {v6}, Lf5/b;->L(Ljava/util/ArrayList;)Ljava/util/List;

    .line 310
    .line 311
    .line 312
    move-result-object v6

    .line 313
    iget-object v7, v5, LC1/b;->b:Ljava/lang/Object;

    .line 314
    .line 315
    check-cast v7, Ljava/util/ArrayList;

    .line 316
    .line 317
    invoke-static {v7}, Lf5/b;->L(Ljava/util/ArrayList;)Ljava/util/List;

    .line 318
    .line 319
    .line 320
    move-result-object v7

    .line 321
    invoke-static {v13}, Lf5/b;->L(Ljava/util/ArrayList;)Ljava/util/List;

    .line 322
    .line 323
    .line 324
    move-result-object v8

    .line 325
    iget-object v5, v5, LC1/b;->d:Ljava/lang/Object;

    .line 326
    .line 327
    check-cast v5, Ljava/util/ArrayList;

    .line 328
    .line 329
    invoke-static {v5}, Lf5/b;->L(Ljava/util/ArrayList;)Ljava/util/List;

    .line 330
    .line 331
    .line 332
    move-result-object v5

    .line 333
    invoke-static {v2}, Lf5/b;->L(Ljava/util/ArrayList;)Ljava/util/List;

    .line 334
    .line 335
    .line 336
    move-result-object v2

    .line 337
    move-object/from16 p1, v1

    .line 338
    .line 339
    move-object/from16 p6, v2

    .line 340
    .line 341
    move-object/from16 p5, v5

    .line 342
    .line 343
    move-object/from16 p2, v6

    .line 344
    .line 345
    move-object/from16 p3, v7

    .line 346
    .line 347
    move-object/from16 p4, v8

    .line 348
    .line 349
    invoke-direct/range {p1 .. p6}, LC1/c;-><init>(Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    .line 350
    .line 351
    .line 352
    move-object/from16 v2, p2

    .line 353
    .line 354
    iput-object v1, v0, LC1/l;->g:LC1/c;

    .line 355
    .line 356
    new-instance v1, LH1/i;

    .line 357
    .line 358
    invoke-direct {v1, v0, v3, v4}, LH1/i;-><init>(LC1/l;LQ1/m;Landroid/support/v4/media/session/z;)V

    .line 359
    .line 360
    .line 361
    invoke-static {v2, v1}, Le8/i;->t0(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 362
    .line 363
    .line 364
    move-result-object v1

    .line 365
    iput-object v1, v0, LC1/l;->h:Ljava/util/ArrayList;

    .line 366
    .line 367
    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 368
    .line 369
    invoke-direct {v1, v12}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 370
    .line 371
    .line 372
    return-void
.end method

.method public static final a(LC1/l;LM1/j;Lj8/c;)Ljava/lang/Object;
    .locals 21

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v4, p1

    .line 4
    .line 5
    move-object/from16 v0, p2

    .line 6
    .line 7
    instance-of v2, v0, LC1/i;

    .line 8
    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    move-object v2, v0

    .line 12
    check-cast v2, LC1/i;

    .line 13
    .line 14
    iget v3, v2, LC1/i;->y:I

    .line 15
    .line 16
    const/high16 v5, -0x80000000

    .line 17
    .line 18
    and-int v6, v3, v5

    .line 19
    .line 20
    if-eqz v6, :cond_0

    .line 21
    .line 22
    sub-int/2addr v3, v5

    .line 23
    iput v3, v2, LC1/i;->y:I

    .line 24
    .line 25
    :goto_0
    move-object v0, v2

    .line 26
    goto :goto_1

    .line 27
    :cond_0
    new-instance v2, LC1/i;

    .line 28
    .line 29
    invoke-direct {v2, v1, v0}, LC1/i;-><init>(LC1/l;Lj8/c;)V

    .line 30
    .line 31
    .line 32
    goto :goto_0

    .line 33
    :goto_1
    iget-object v2, v0, LC1/i;->w:Ljava/lang/Object;

    .line 34
    .line 35
    iget v3, v0, LC1/i;->y:I

    .line 36
    .line 37
    const/4 v8, 0x3

    .line 38
    const/4 v9, 0x2

    .line 39
    const/4 v10, 0x1

    .line 40
    const/4 v11, 0x0

    .line 41
    sget-object v12, Li8/a;->a:Li8/a;

    .line 42
    .line 43
    if-eqz v3, :cond_4

    .line 44
    .line 45
    if-eq v3, v10, :cond_3

    .line 46
    .line 47
    if-eq v3, v9, :cond_2

    .line 48
    .line 49
    if-ne v3, v8, :cond_1

    .line 50
    .line 51
    iget-object v1, v0, LC1/i;->u:LC1/d;

    .line 52
    .line 53
    iget-object v3, v0, LC1/i;->t:LM1/j;

    .line 54
    .line 55
    iget-object v4, v0, LC1/i;->s:LM1/p;

    .line 56
    .line 57
    iget-object v5, v0, LC1/i;->r:LC1/l;

    .line 58
    .line 59
    :try_start_0
    invoke-static {v2}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 60
    .line 61
    .line 62
    move-object v15, v5

    .line 63
    goto/16 :goto_7

    .line 64
    .line 65
    :catchall_0
    move-exception v0

    .line 66
    move-object v2, v4

    .line 67
    move-object v4, v1

    .line 68
    move-object v1, v5

    .line 69
    goto/16 :goto_c

    .line 70
    .line 71
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 72
    .line 73
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 74
    .line 75
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    throw v0

    .line 79
    :cond_2
    iget-object v1, v0, LC1/i;->v:Landroid/graphics/Bitmap;

    .line 80
    .line 81
    iget-object v3, v0, LC1/i;->u:LC1/d;

    .line 82
    .line 83
    iget-object v4, v0, LC1/i;->t:LM1/j;

    .line 84
    .line 85
    iget-object v5, v0, LC1/i;->s:LM1/p;

    .line 86
    .line 87
    iget-object v6, v0, LC1/i;->r:LC1/l;

    .line 88
    .line 89
    :try_start_1
    invoke-static {v2}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 90
    .line 91
    .line 92
    move-object/from16 v18, v1

    .line 93
    .line 94
    move-object/from16 v17, v3

    .line 95
    .line 96
    move-object v14, v4

    .line 97
    move-object v4, v5

    .line 98
    move-object v15, v6

    .line 99
    goto/16 :goto_5

    .line 100
    .line 101
    :catchall_1
    move-exception v0

    .line 102
    move-object v1, v4

    .line 103
    move-object v4, v3

    .line 104
    move-object v3, v1

    .line 105
    move-object v2, v5

    .line 106
    move-object v1, v6

    .line 107
    goto/16 :goto_c

    .line 108
    .line 109
    :cond_3
    iget-object v1, v0, LC1/i;->u:LC1/d;

    .line 110
    .line 111
    iget-object v3, v0, LC1/i;->t:LM1/j;

    .line 112
    .line 113
    iget-object v4, v0, LC1/i;->s:LM1/p;

    .line 114
    .line 115
    iget-object v5, v0, LC1/i;->r:LC1/l;

    .line 116
    .line 117
    :try_start_2
    invoke-static {v2}, Lv5/u0;->F(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 118
    .line 119
    .line 120
    move-object v2, v4

    .line 121
    move-object v4, v1

    .line 122
    move-object v1, v5

    .line 123
    goto :goto_3

    .line 124
    :cond_4
    invoke-static {v2}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    iget-object v2, v1, LC1/l;->f:Landroid/support/v4/media/session/z;

    .line 128
    .line 129
    invoke-interface {v0}, Lh8/d;->getContext()Lh8/i;

    .line 130
    .line 131
    .line 132
    move-result-object v3

    .line 133
    invoke-static {v3}, LB8/D;->m(Lh8/i;)LB8/j0;

    .line 134
    .line 135
    .line 136
    move-result-object v7

    .line 137
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 138
    .line 139
    .line 140
    iget-object v6, v4, LM1/j;->u:LD/o;

    .line 141
    .line 142
    iget-object v3, v4, LM1/j;->c:LO1/b;

    .line 143
    .line 144
    instance-of v5, v3, LO1/a;

    .line 145
    .line 146
    if-eqz v5, :cond_5

    .line 147
    .line 148
    new-instance v5, LM1/s;

    .line 149
    .line 150
    iget-object v2, v2, Landroid/support/v4/media/session/z;->b:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v2, LC1/l;

    .line 153
    .line 154
    check-cast v3, LO1/a;

    .line 155
    .line 156
    move-object/from16 v20, v3

    .line 157
    .line 158
    move-object v3, v2

    .line 159
    move-object v2, v5

    .line 160
    move-object/from16 v5, v20

    .line 161
    .line 162
    invoke-direct/range {v2 .. v7}, LM1/s;-><init>(LC1/l;LM1/j;LO1/a;LD/o;LB8/j0;)V

    .line 163
    .line 164
    .line 165
    goto :goto_2

    .line 166
    :cond_5
    new-instance v2, LM1/a;

    .line 167
    .line 168
    invoke-direct {v2, v6, v7}, LM1/a;-><init>(LD/o;LB8/j0;)V

    .line 169
    .line 170
    .line 171
    :goto_2
    invoke-interface {v2}, LM1/p;->z()V

    .line 172
    .line 173
    .line 174
    iget-object v3, v4, LM1/j;->a:Landroid/content/Context;

    .line 175
    .line 176
    new-instance v5, LM1/i;

    .line 177
    .line 178
    invoke-direct {v5, v4, v3}, LM1/i;-><init>(LM1/j;Landroid/content/Context;)V

    .line 179
    .line 180
    .line 181
    iget-object v3, v1, LC1/l;->b:LM1/c;

    .line 182
    .line 183
    iput-object v3, v5, LM1/i;->b:LM1/c;

    .line 184
    .line 185
    iput-object v11, v5, LM1/i;->p:LN1/g;

    .line 186
    .line 187
    invoke-virtual {v5}, LM1/i;->a()LM1/j;

    .line 188
    .line 189
    .line 190
    move-result-object v3

    .line 191
    sget-object v4, LC1/d;->a:LC1/d;

    .line 192
    .line 193
    :try_start_3
    iget-object v5, v3, LM1/j;->b:Ljava/lang/Object;

    .line 194
    .line 195
    sget-object v6, LM1/l;->b:LM1/l;

    .line 196
    .line 197
    if-eq v5, v6, :cond_10

    .line 198
    .line 199
    invoke-interface {v2}, LM1/p;->start()V

    .line 200
    .line 201
    .line 202
    iget-object v5, v3, LM1/j;->u:LD/o;

    .line 203
    .line 204
    iput-object v1, v0, LC1/i;->r:LC1/l;

    .line 205
    .line 206
    iput-object v2, v0, LC1/i;->s:LM1/p;

    .line 207
    .line 208
    iput-object v3, v0, LC1/i;->t:LM1/j;

    .line 209
    .line 210
    iput-object v4, v0, LC1/i;->u:LC1/d;

    .line 211
    .line 212
    iput v10, v0, LC1/i;->y:I

    .line 213
    .line 214
    invoke-static {v5, v0}, LI3/a;->b(LD/o;Lj8/c;)Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v5

    .line 218
    if-ne v5, v12, :cond_6

    .line 219
    .line 220
    goto :goto_6

    .line 221
    :cond_6
    :goto_3
    iget-object v5, v1, LC1/l;->c:Ld8/j;

    .line 222
    .line 223
    invoke-virtual {v5}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v5

    .line 227
    check-cast v5, LK1/c;

    .line 228
    .line 229
    if-eqz v5, :cond_7

    .line 230
    .line 231
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 232
    .line 233
    .line 234
    goto :goto_4

    .line 235
    :catchall_2
    move-exception v0

    .line 236
    goto/16 :goto_c

    .line 237
    .line 238
    :cond_7
    :goto_4
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 239
    .line 240
    .line 241
    iget-object v5, v3, LM1/j;->A:LM1/c;

    .line 242
    .line 243
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 244
    .line 245
    .line 246
    sget-object v5, LQ1/d;->a:LM1/c;

    .line 247
    .line 248
    iget-object v5, v3, LM1/j;->c:LO1/b;

    .line 249
    .line 250
    if-eqz v5, :cond_8

    .line 251
    .line 252
    invoke-interface {v5, v11}, LO1/b;->b(Landroid/graphics/drawable/Drawable;)V

    .line 253
    .line 254
    .line 255
    :cond_8
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 256
    .line 257
    .line 258
    iget-object v5, v3, LM1/j;->v:LN1/i;

    .line 259
    .line 260
    iput-object v1, v0, LC1/i;->r:LC1/l;

    .line 261
    .line 262
    iput-object v2, v0, LC1/i;->s:LM1/p;

    .line 263
    .line 264
    iput-object v3, v0, LC1/i;->t:LM1/j;

    .line 265
    .line 266
    iput-object v4, v0, LC1/i;->u:LC1/d;

    .line 267
    .line 268
    iput-object v11, v0, LC1/i;->v:Landroid/graphics/Bitmap;

    .line 269
    .line 270
    iput v9, v0, LC1/i;->y:I

    .line 271
    .line 272
    invoke-interface {v5, v0}, LN1/i;->a(LC1/i;)Ljava/lang/Object;

    .line 273
    .line 274
    .line 275
    move-result-object v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 276
    if-ne v5, v12, :cond_9

    .line 277
    .line 278
    goto :goto_6

    .line 279
    :cond_9
    move-object v15, v1

    .line 280
    move-object v14, v3

    .line 281
    move-object/from16 v17, v4

    .line 282
    .line 283
    move-object/from16 v18, v11

    .line 284
    .line 285
    move-object v4, v2

    .line 286
    move-object v2, v5

    .line 287
    :goto_5
    :try_start_4
    move-object/from16 v16, v2

    .line 288
    .line 289
    check-cast v16, LN1/h;

    .line 290
    .line 291
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 292
    .line 293
    .line 294
    iget-object v1, v14, LM1/j;->q:LB8/w;

    .line 295
    .line 296
    new-instance v13, LC1/j;

    .line 297
    .line 298
    const/16 v19, 0x0

    .line 299
    .line 300
    invoke-direct/range {v13 .. v19}, LC1/j;-><init>(LM1/j;LC1/l;LN1/h;LC1/d;Landroid/graphics/Bitmap;Lh8/d;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    .line 301
    .line 302
    .line 303
    move-object/from16 v3, v17

    .line 304
    .line 305
    :try_start_5
    iput-object v15, v0, LC1/i;->r:LC1/l;

    .line 306
    .line 307
    iput-object v4, v0, LC1/i;->s:LM1/p;

    .line 308
    .line 309
    iput-object v14, v0, LC1/i;->t:LM1/j;

    .line 310
    .line 311
    iput-object v3, v0, LC1/i;->u:LC1/d;

    .line 312
    .line 313
    iput-object v11, v0, LC1/i;->v:Landroid/graphics/Bitmap;

    .line 314
    .line 315
    iput v8, v0, LC1/i;->y:I

    .line 316
    .line 317
    invoke-static {v1, v13, v0}, LB8/D;->C(Lh8/i;Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    move-result-object v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 321
    if-ne v2, v12, :cond_a

    .line 322
    .line 323
    :goto_6
    return-object v12

    .line 324
    :cond_a
    move-object v1, v3

    .line 325
    move-object v3, v14

    .line 326
    :goto_7
    :try_start_6
    check-cast v2, LM1/k;

    .line 327
    .line 328
    instance-of v0, v2, LM1/q;

    .line 329
    .line 330
    if-eqz v0, :cond_e

    .line 331
    .line 332
    move-object v0, v2

    .line 333
    check-cast v0, LM1/q;

    .line 334
    .line 335
    iget-object v5, v3, LM1/j;->c:LO1/b;

    .line 336
    .line 337
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 338
    .line 339
    .line 340
    iget-object v6, v0, LM1/q;->b:LM1/j;

    .line 341
    .line 342
    iget-object v7, v0, LM1/q;->a:Landroid/graphics/drawable/Drawable;

    .line 343
    .line 344
    instance-of v8, v5, LO1/a;

    .line 345
    .line 346
    if-nez v8, :cond_b

    .line 347
    .line 348
    if-eqz v5, :cond_d

    .line 349
    .line 350
    invoke-interface {v5, v7}, LO1/b;->o(Landroid/graphics/drawable/Drawable;)V

    .line 351
    .line 352
    .line 353
    goto :goto_8

    .line 354
    :cond_b
    iget-object v8, v6, LM1/j;->g:LP1/d;

    .line 355
    .line 356
    move-object v9, v5

    .line 357
    check-cast v9, LO1/a;

    .line 358
    .line 359
    invoke-interface {v8, v9, v0}, LP1/d;->a(LO1/a;LM1/k;)LP1/e;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    instance-of v8, v0, LP1/c;

    .line 364
    .line 365
    if-eqz v8, :cond_c

    .line 366
    .line 367
    check-cast v5, LO1/a;

    .line 368
    .line 369
    invoke-virtual {v5, v7}, LO1/a;->d(Landroid/graphics/drawable/Drawable;)V

    .line 370
    .line 371
    .line 372
    goto :goto_8

    .line 373
    :cond_c
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 374
    .line 375
    .line 376
    invoke-interface {v0}, LP1/e;->b()V

    .line 377
    .line 378
    .line 379
    :cond_d
    :goto_8
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 380
    .line 381
    .line 382
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 383
    .line 384
    .line 385
    goto :goto_a

    .line 386
    :goto_9
    move-object v2, v4

    .line 387
    move-object v4, v1

    .line 388
    move-object v1, v15

    .line 389
    goto :goto_c

    .line 390
    :catchall_3
    move-exception v0

    .line 391
    goto :goto_9

    .line 392
    :cond_e
    instance-of v0, v2, LM1/f;

    .line 393
    .line 394
    if-eqz v0, :cond_f

    .line 395
    .line 396
    move-object v0, v2

    .line 397
    check-cast v0, LM1/f;

    .line 398
    .line 399
    iget-object v5, v3, LM1/j;->c:LO1/b;

    .line 400
    .line 401
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 402
    .line 403
    .line 404
    invoke-static {v0, v5, v1}, LC1/l;->c(LM1/f;LO1/b;LC1/d;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 405
    .line 406
    .line 407
    :goto_a
    invoke-interface {v4}, LM1/p;->w()V

    .line 408
    .line 409
    .line 410
    return-object v2

    .line 411
    :cond_f
    :try_start_7
    new-instance v0, LB8/s;

    .line 412
    .line 413
    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    .line 414
    .line 415
    .line 416
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 417
    :catchall_4
    move-exception v0

    .line 418
    :goto_b
    move-object v2, v4

    .line 419
    move-object v1, v15

    .line 420
    move-object v4, v3

    .line 421
    move-object v3, v14

    .line 422
    goto :goto_c

    .line 423
    :catchall_5
    move-exception v0

    .line 424
    move-object/from16 v3, v17

    .line 425
    .line 426
    goto :goto_b

    .line 427
    :cond_10
    :try_start_8
    new-instance v0, LM1/m;

    .line 428
    .line 429
    const-string v5, "The request\'s data is null."

    .line 430
    .line 431
    invoke-direct {v0, v5}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 432
    .line 433
    .line 434
    throw v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 435
    :goto_c
    :try_start_9
    instance-of v5, v0, Ljava/util/concurrent/CancellationException;

    .line 436
    .line 437
    if-nez v5, :cond_11

    .line 438
    .line 439
    iget-object v1, v1, LC1/l;->f:Landroid/support/v4/media/session/z;

    .line 440
    .line 441
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 442
    .line 443
    .line 444
    invoke-static {v3, v0}, Landroid/support/v4/media/session/z;->t(LM1/j;Ljava/lang/Throwable;)LM1/f;

    .line 445
    .line 446
    .line 447
    move-result-object v0

    .line 448
    iget-object v1, v3, LM1/j;->c:LO1/b;

    .line 449
    .line 450
    invoke-static {v0, v1, v4}, LC1/l;->c(LM1/f;LO1/b;LC1/d;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_6

    .line 451
    .line 452
    .line 453
    invoke-interface {v2}, LM1/p;->w()V

    .line 454
    .line 455
    .line 456
    return-object v0

    .line 457
    :catchall_6
    move-exception v0

    .line 458
    goto :goto_d

    .line 459
    :cond_11
    :try_start_a
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 460
    .line 461
    .line 462
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 463
    .line 464
    .line 465
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 466
    .line 467
    .line 468
    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    .line 469
    :goto_d
    invoke-interface {v2}, LM1/p;->w()V

    .line 470
    .line 471
    .line 472
    throw v0
.end method

.method public static c(LM1/f;LO1/b;LC1/d;)V
    .locals 4

    .line 1
    iget-object v0, p0, LM1/f;->b:LM1/j;

    .line 2
    .line 3
    iget-object v1, p0, LM1/f;->a:Landroid/graphics/drawable/Drawable;

    .line 4
    .line 5
    instance-of v2, p1, LO1/a;

    .line 6
    .line 7
    if-nez v2, :cond_0

    .line 8
    .line 9
    if-eqz p1, :cond_2

    .line 10
    .line 11
    invoke-interface {p1, v1}, LO1/b;->A(Landroid/graphics/drawable/Drawable;)V

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    iget-object v2, v0, LM1/j;->g:LP1/d;

    .line 16
    .line 17
    move-object v3, p1

    .line 18
    check-cast v3, LO1/a;

    .line 19
    .line 20
    invoke-interface {v2, v3, p0}, LP1/d;->a(LO1/a;LM1/k;)LP1/e;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    instance-of v2, p0, LP1/c;

    .line 25
    .line 26
    if-eqz v2, :cond_1

    .line 27
    .line 28
    check-cast p1, LO1/a;

    .line 29
    .line 30
    invoke-virtual {p1, v1}, LO1/a;->d(Landroid/graphics/drawable/Drawable;)V

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    invoke-interface {p0}, LP1/e;->b()V

    .line 38
    .line 39
    .line 40
    :cond_2
    :goto_0
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public final b(LM1/j;)LM1/e;
    .locals 4

    .line 1
    iget-object v0, p0, LC1/l;->e:LG8/e;

    .line 2
    .line 3
    new-instance v1, LC1/h;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v1, p0, p1, v2}, LC1/h;-><init>(LC1/l;LM1/j;Lh8/d;)V

    .line 7
    .line 8
    .line 9
    invoke-static {v0, v1}, LB8/D;->c(LB8/A;Lr8/p;)LB8/H;

    .line 10
    .line 11
    .line 12
    iget-object p1, p1, LM1/j;->c:LO1/b;

    .line 13
    .line 14
    instance-of v0, p1, LO1/a;

    .line 15
    .line 16
    if-eqz v0, :cond_2

    .line 17
    .line 18
    check-cast p1, LO1/a;

    .line 19
    .line 20
    iget-object p1, p1, LO1/a;->b:Landroid/widget/ImageView;

    .line 21
    .line 22
    invoke-static {p1}, LQ1/f;->c(Landroid/widget/ImageView;)LM1/u;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    monitor-enter p1

    .line 27
    :try_start_0
    iget-object v0, p1, LM1/u;->b:LA5/g;

    .line 28
    .line 29
    if-eqz v0, :cond_0

    .line 30
    .line 31
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    invoke-static {v1, v3}, Lkotlin/jvm/internal/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    if-eqz v1, :cond_0

    .line 44
    .line 45
    iget-boolean v1, p1, LM1/u;->e:Z

    .line 46
    .line 47
    if-eqz v1, :cond_0

    .line 48
    .line 49
    const/4 v1, 0x0

    .line 50
    iput-boolean v1, p1, LM1/u;->e:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 51
    .line 52
    monitor-exit p1

    .line 53
    return-object v0

    .line 54
    :catchall_0
    move-exception v0

    .line 55
    goto :goto_0

    .line 56
    :cond_0
    :try_start_1
    iget-object v0, p1, LM1/u;->c:LB8/B0;

    .line 57
    .line 58
    if-eqz v0, :cond_1

    .line 59
    .line 60
    invoke-virtual {v0, v2}, LB8/u0;->f(Ljava/util/concurrent/CancellationException;)V

    .line 61
    .line 62
    .line 63
    :cond_1
    iput-object v2, p1, LM1/u;->c:LB8/B0;

    .line 64
    .line 65
    new-instance v0, LA5/g;

    .line 66
    .line 67
    iget-object v1, p1, LM1/u;->a:Landroid/view/View;

    .line 68
    .line 69
    const/16 v2, 0xd

    .line 70
    .line 71
    invoke-direct {v0, v2, v1}, LA5/g;-><init>(ILjava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    iput-object v0, p1, LM1/u;->b:LA5/g;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 75
    .line 76
    monitor-exit p1

    .line 77
    return-object v0

    .line 78
    :goto_0
    :try_start_2
    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 79
    throw v0

    .line 80
    :cond_2
    new-instance p1, LM1/l;

    .line 81
    .line 82
    const/4 v0, 0x1

    .line 83
    invoke-direct {p1, v0}, LM1/l;-><init>(I)V

    .line 84
    .line 85
    .line 86
    return-object p1
.end method
