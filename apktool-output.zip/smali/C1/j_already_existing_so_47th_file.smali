.class public final LC1/j;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:I

.field public final synthetic s:LM1/j;

.field public final synthetic t:LC1/l;

.field public final synthetic u:LN1/h;

.field public final synthetic v:LC1/d;

.field public final synthetic w:Landroid/graphics/Bitmap;


# direct methods
.method public constructor <init>(LM1/j;LC1/l;LN1/h;LC1/d;Landroid/graphics/Bitmap;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC1/j;->s:LM1/j;

    .line 2
    .line 3
    iput-object p2, p0, LC1/j;->t:LC1/l;

    .line 4
    .line 5
    iput-object p3, p0, LC1/j;->u:LN1/h;

    .line 6
    .line 7
    iput-object p4, p0, LC1/j;->v:LC1/d;

    .line 8
    .line 9
    iput-object p5, p0, LC1/j;->w:Landroid/graphics/Bitmap;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p6}, Lj8/i;-><init>(ILh8/d;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 7

    .line 1
    new-instance v0, LC1/j;

    .line 2
    .line 3
    iget-object v4, p0, LC1/j;->v:LC1/d;

    .line 4
    .line 5
    iget-object v5, p0, LC1/j;->w:Landroid/graphics/Bitmap;

    .line 6
    .line 7
    iget-object v1, p0, LC1/j;->s:LM1/j;

    .line 8
    .line 9
    iget-object v2, p0, LC1/j;->t:LC1/l;

    .line 10
    .line 11
    iget-object v3, p0, LC1/j;->u:LN1/h;

    .line 12
    .line 13
    move-object v6, p2

    .line 14
    invoke-direct/range {v0 .. v6}, LC1/j;-><init>(LM1/j;LC1/l;LN1/h;LC1/d;Landroid/graphics/Bitmap;Lh8/d;)V

    .line 15
    .line 16
    .line 17
    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LC1/j;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LC1/j;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LC1/j;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    .line 1
    iget v0, p0, LC1/j;->r:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-object p1

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p1

    .line 20
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    new-instance v2, LH1/k;

    .line 24
    .line 25
    iget-object p1, p0, LC1/j;->t:LC1/l;

    .line 26
    .line 27
    iget-object v4, p1, LC1/l;->h:Ljava/util/ArrayList;

    .line 28
    .line 29
    iget-object p1, p0, LC1/j;->w:Landroid/graphics/Bitmap;

    .line 30
    .line 31
    if-eqz p1, :cond_2

    .line 32
    .line 33
    move v9, v1

    .line 34
    goto :goto_0

    .line 35
    :cond_2
    const/4 p1, 0x0

    .line 36
    move v9, p1

    .line 37
    :goto_0
    iget-object v3, p0, LC1/j;->s:LM1/j;

    .line 38
    .line 39
    const/4 v5, 0x0

    .line 40
    iget-object v7, p0, LC1/j;->u:LN1/h;

    .line 41
    .line 42
    iget-object v8, p0, LC1/j;->v:LC1/d;

    .line 43
    .line 44
    move-object v6, v3

    .line 45
    invoke-direct/range {v2 .. v9}, LH1/k;-><init>(LM1/j;Ljava/util/List;ILM1/j;LN1/h;LC1/d;Z)V

    .line 46
    .line 47
    .line 48
    iput v1, p0, LC1/j;->r:I

    .line 49
    .line 50
    invoke-virtual {v2, v3, p0}, LH1/k;->b(LM1/j;Lj8/c;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    sget-object v0, Li8/a;->a:Li8/a;

    .line 55
    .line 56
    if-ne p1, v0, :cond_3

    .line 57
    .line 58
    return-object v0

    .line 59
    :cond_3
    return-object p1
.end method
