.class public final LC1/i;
.super Lj8/c;
.source "SourceFile"


# instance fields
.field public r:LC1/l;

.field public s:LM1/p;

.field public t:LM1/j;

.field public u:LC1/d;

.field public v:Landroid/graphics/Bitmap;

.field public synthetic w:Ljava/lang/Object;

.field public final synthetic x:LC1/l;

.field public y:I


# direct methods
.method public constructor <init>(LC1/l;Lj8/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC1/i;->x:LC1/l;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lj8/c;-><init>(Lh8/d;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iput-object p1, p0, LC1/i;->w:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, LC1/i;->y:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, LC1/i;->y:I

    .line 9
    .line 10
    iget-object p1, p0, LC1/i;->x:LC1/l;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, v0, p0}, LC1/l;->a(LC1/l;LM1/j;Lj8/c;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method
