.class public interface abstract LC1/g;
.super Ljava/lang/Object;
.source "SourceFile"
