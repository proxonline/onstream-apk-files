.class public final LC1/k;
.super Lh8/a;
.source "SourceFile"

# interfaces
.implements LB8/y;


# instance fields
.field public final synthetic a:LC1/l;


# direct methods
.method public constructor <init>(LC1/l;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC1/k;->a:LC1/l;

    .line 2
    .line 3
    sget-object p1, LB8/x;->a:LB8/x;

    .line 4
    .line 5
    invoke-direct {p0, p1}, Lh8/a;-><init>(Lh8/h;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final handleException(Lh8/i;Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    iget-object p1, p0, LC1/k;->a:LC1/l;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    return-void
.end method
