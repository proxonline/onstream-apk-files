.class public final LC1/h;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:I

.field public final synthetic s:LC1/l;

.field public final synthetic t:LM1/j;


# direct methods
.method public constructor <init>(LC1/l;LM1/j;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, LC1/h;->s:LC1/l;

    .line 2
    .line 3
    iput-object p2, p0, LC1/h;->t:LM1/j;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lj8/i;-><init>(ILh8/d;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 2

    .line 1
    new-instance p1, LC1/h;

    .line 2
    .line 3
    iget-object v0, p0, LC1/h;->s:LC1/l;

    .line 4
    .line 5
    iget-object v1, p0, LC1/h;->t:LM1/j;

    .line 6
    .line 7
    invoke-direct {p1, v0, v1, p2}, LC1/h;-><init>(LC1/l;LM1/j;Lh8/d;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, LC1/h;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LC1/h;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, LC1/h;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LC1/h;->r:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_1

    .line 5
    .line 6
    if-ne v0, v1, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 13
    .line 14
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    .line 16
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    throw p1

    .line 20
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iput v1, p0, LC1/h;->r:I

    .line 24
    .line 25
    iget-object p1, p0, LC1/h;->s:LC1/l;

    .line 26
    .line 27
    iget-object v0, p0, LC1/h;->t:LM1/j;

    .line 28
    .line 29
    invoke-static {p1, v0, p0}, LC1/l;->a(LC1/l;LM1/j;Lj8/c;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    sget-object v0, Li8/a;->a:Li8/a;

    .line 34
    .line 35
    if-ne p1, v0, :cond_2

    .line 36
    .line 37
    return-object v0

    .line 38
    :cond_2
    :goto_0
    move-object v0, p1

    .line 39
    check-cast v0, LM1/k;

    .line 40
    .line 41
    return-object p1
.end method
