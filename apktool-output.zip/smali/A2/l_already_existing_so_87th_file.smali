.class public final La2/l;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/concurrent/Executor;

.field public final b:Lb2/d;

.field public final c:La2/d;

.field public final d:Lc2/c;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Executor;Lb2/d;La2/d;Lc2/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La2/l;->a:Ljava/util/concurrent/Executor;

    .line 5
    .line 6
    iput-object p2, p0, La2/l;->b:Lb2/d;

    .line 7
    .line 8
    iput-object p3, p0, La2/l;->c:La2/d;

    .line 9
    .line 10
    iput-object p4, p0, La2/l;->d:Lc2/c;

    .line 11
    .line 12
    return-void
.end method
