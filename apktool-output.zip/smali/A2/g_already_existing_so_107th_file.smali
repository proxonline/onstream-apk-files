.class public final synthetic La2/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc2/b;
.implements Lh3/i;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILf2/r0;Lf2/r0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, La2/g;->a:I

    iput-object p2, p0, La2/g;->b:Ljava/lang/Object;

    iput-object p3, p0, La2/g;->c:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(La2/j;LU1/j;I)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La2/g;->b:Ljava/lang/Object;

    iput-object p2, p0, La2/g;->c:Ljava/lang/Object;

    iput p3, p0, La2/g;->a:I

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, La2/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, La2/j;

    .line 4
    .line 5
    iget-object v1, p0, La2/g;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LU1/j;

    .line 8
    .line 9
    iget-object v0, v0, La2/j;->d:La2/d;

    .line 10
    .line 11
    iget v2, p0, La2/g;->a:I

    .line 12
    .line 13
    add-int/lit8 v2, v2, 0x1

    .line 14
    .line 15
    const/4 v3, 0x0

    .line 16
    invoke-virtual {v0, v1, v2, v3}, La2/d;->a(LU1/j;IZ)V

    .line 17
    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    return-object v0
.end method

.method public invoke(Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget-object v0, p0, La2/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lf2/r0;

    .line 4
    .line 5
    iget-object v1, p0, La2/g;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lf2/r0;

    .line 8
    .line 9
    check-cast p1, Lf2/q0;

    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget v2, p0, La2/g;->a:I

    .line 15
    .line 16
    invoke-interface {p1, v2, v0, v1}, Lf2/q0;->j(ILf2/r0;Lf2/r0;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method
