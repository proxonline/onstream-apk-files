.class public final La2/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LW1/b;


# instance fields
.field public final a:Lc8/a;

.field public final b:Lc8/a;

.field public final c:Lc8/a;

.field public final d:LU1/u;

.field public final e:Lc8/a;

.field public final f:Lc8/a;

.field public final g:Lc8/a;


# direct methods
.method public constructor <init>(Lc8/a;Lc8/a;Lc8/a;LU1/u;Lc8/a;Lc8/a;Lc8/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La2/k;->a:Lc8/a;

    .line 5
    .line 6
    iput-object p2, p0, La2/k;->b:Lc8/a;

    .line 7
    .line 8
    iput-object p3, p0, La2/k;->c:Lc8/a;

    .line 9
    .line 10
    iput-object p4, p0, La2/k;->d:LU1/u;

    .line 11
    .line 12
    iput-object p5, p0, La2/k;->e:Lc8/a;

    .line 13
    .line 14
    iput-object p6, p0, La2/k;->f:Lc8/a;

    .line 15
    .line 16
    iput-object p7, p0, La2/k;->g:Lc8/a;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 11

    .line 1
    iget-object v0, p0, La2/k;->a:Lc8/a;

    .line 2
    .line 3
    invoke-interface {v0}, Lc8/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    move-object v2, v0

    .line 8
    check-cast v2, Landroid/content/Context;

    .line 9
    .line 10
    iget-object v0, p0, La2/k;->b:Lc8/a;

    .line 11
    .line 12
    invoke-interface {v0}, Lc8/a;->get()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    move-object v3, v0

    .line 17
    check-cast v3, LV1/f;

    .line 18
    .line 19
    iget-object v0, p0, La2/k;->c:Lc8/a;

    .line 20
    .line 21
    invoke-interface {v0}, Lc8/a;->get()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    move-object v4, v0

    .line 26
    check-cast v4, Lb2/d;

    .line 27
    .line 28
    iget-object v0, p0, La2/k;->d:LU1/u;

    .line 29
    .line 30
    invoke-virtual {v0}, LU1/u;->get()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    move-object v5, v0

    .line 35
    check-cast v5, La2/d;

    .line 36
    .line 37
    iget-object v0, p0, La2/k;->e:Lc8/a;

    .line 38
    .line 39
    invoke-interface {v0}, Lc8/a;->get()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    move-object v6, v0

    .line 44
    check-cast v6, Ljava/util/concurrent/Executor;

    .line 45
    .line 46
    iget-object v0, p0, La2/k;->f:Lc8/a;

    .line 47
    .line 48
    invoke-interface {v0}, Lc8/a;->get()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    move-object v7, v0

    .line 53
    check-cast v7, Lc2/c;

    .line 54
    .line 55
    new-instance v8, Ld2/b;

    .line 56
    .line 57
    const/4 v0, 0x0

    .line 58
    invoke-direct {v8, v0}, Ld2/b;-><init>(I)V

    .line 59
    .line 60
    .line 61
    new-instance v9, LX3/A;

    .line 62
    .line 63
    const/16 v0, 0x1d

    .line 64
    .line 65
    invoke-direct {v9, v0}, LX3/A;-><init>(I)V

    .line 66
    .line 67
    .line 68
    iget-object v0, p0, La2/k;->g:Lc8/a;

    .line 69
    .line 70
    invoke-interface {v0}, Lc8/a;->get()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    move-object v10, v0

    .line 75
    check-cast v10, Lb2/c;

    .line 76
    .line 77
    new-instance v1, La2/j;

    .line 78
    .line 79
    invoke-direct/range {v1 .. v10}, La2/j;-><init>(Landroid/content/Context;LV1/f;Lb2/d;La2/d;Ljava/util/concurrent/Executor;Lc2/c;Ld2/a;Ld2/a;Lb2/c;)V

    .line 80
    .line 81
    .line 82
    return-object v1
.end method
