.class public final La2/j;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:LV1/f;

.field public final c:Lb2/d;

.field public final d:La2/d;

.field public final e:Ljava/util/concurrent/Executor;

.field public final f:Lc2/c;

.field public final g:Ld2/a;

.field public final h:Ld2/a;

.field public final i:Lb2/c;


# direct methods
.method public constructor <init>(Landroid/content/Context;LV1/f;Lb2/d;La2/d;Ljava/util/concurrent/Executor;Lc2/c;Ld2/a;Ld2/a;Lb2/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La2/j;->a:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p2, p0, La2/j;->b:LV1/f;

    .line 7
    .line 8
    iput-object p3, p0, La2/j;->c:Lb2/d;

    .line 9
    .line 10
    iput-object p4, p0, La2/j;->d:La2/d;

    .line 11
    .line 12
    iput-object p5, p0, La2/j;->e:Ljava/util/concurrent/Executor;

    .line 13
    .line 14
    iput-object p6, p0, La2/j;->f:Lc2/c;

    .line 15
    .line 16
    iput-object p7, p0, La2/j;->g:Ld2/a;

    .line 17
    .line 18
    iput-object p8, p0, La2/j;->h:Ld2/a;

    .line 19
    .line 20
    iput-object p9, p0, La2/j;->i:Lb2/c;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final a(LU1/j;I)V
    .locals 47

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v3, p1

    .line 4
    .line 5
    iget-object v2, v3, LU1/j;->b:[B

    .line 6
    .line 7
    iget-object v0, v1, La2/j;->b:LV1/f;

    .line 8
    .line 9
    iget-object v4, v3, LU1/j;->a:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {v0, v4}, LV1/f;->a(Ljava/lang/String;)LV1/h;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    const-wide/16 v5, 0x0

    .line 16
    .line 17
    move-wide v7, v5

    .line 18
    move-object v6, v4

    .line 19
    move-wide v4, v7

    .line 20
    :goto_0
    new-instance v0, La2/h;

    .line 21
    .line 22
    const/4 v9, 0x0

    .line 23
    invoke-direct {v0, v1, v3, v9}, La2/h;-><init>(La2/j;LU1/j;I)V

    .line 24
    .line 25
    .line 26
    iget-object v10, v1, La2/j;->f:Lc2/c;

    .line 27
    .line 28
    check-cast v10, Lb2/i;

    .line 29
    .line 30
    invoke-virtual {v10, v0}, Lb2/i;->w(Lc2/b;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    check-cast v0, Ljava/lang/Boolean;

    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_25

    .line 41
    .line 42
    new-instance v0, La2/h;

    .line 43
    .line 44
    const/4 v11, 0x1

    .line 45
    invoke-direct {v0, v1, v3, v11}, La2/h;-><init>(La2/j;LU1/j;I)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v10, v0}, Lb2/i;->w(Lc2/b;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    move-object v12, v0

    .line 53
    check-cast v12, Ljava/lang/Iterable;

    .line 54
    .line 55
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_0

    .line 64
    .line 65
    return-void

    .line 66
    :cond_0
    const/4 v0, 0x3

    .line 67
    const-wide/16 v14, -0x1

    .line 68
    .line 69
    if-nez v6, :cond_1

    .line 70
    .line 71
    const-string v8, "Uploader"

    .line 72
    .line 73
    const-string v9, "Unknown backend for %s, deleting event batch for it..."

    .line 74
    .line 75
    invoke-static {v8, v9, v3}, Lf5/b;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    new-instance v8, LV1/a;

    .line 79
    .line 80
    invoke-direct {v8, v14, v15, v0}, LV1/a;-><init>(JI)V

    .line 81
    .line 82
    .line 83
    move-object/from16 v31, v2

    .line 84
    .line 85
    move-wide/from16 v32, v4

    .line 86
    .line 87
    :goto_1
    const/4 v1, 0x2

    .line 88
    goto/16 :goto_14

    .line 89
    .line 90
    :cond_1
    new-instance v8, Ljava/util/ArrayList;

    .line 91
    .line 92
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 93
    .line 94
    .line 95
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 96
    .line 97
    .line 98
    move-result-object v16

    .line 99
    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 100
    .line 101
    .line 102
    move-result v17

    .line 103
    if-eqz v17, :cond_2

    .line 104
    .line 105
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v17

    .line 109
    move-object/from16 v13, v17

    .line 110
    .line 111
    check-cast v13, Lb2/b;

    .line 112
    .line 113
    iget-object v13, v13, Lb2/b;->c:LU1/i;

    .line 114
    .line 115
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    goto :goto_2

    .line 119
    :cond_2
    const-string v13, "proto"

    .line 120
    .line 121
    if-eqz v2, :cond_3

    .line 122
    .line 123
    iget-object v7, v1, La2/j;->i:Lb2/c;

    .line 124
    .line 125
    invoke-static {v7}, Lj$/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    new-instance v11, LH4/j;

    .line 129
    .line 130
    const/16 v0, 0x8

    .line 131
    .line 132
    invoke-direct {v11, v0, v7}, LH4/j;-><init>(ILjava/lang/Object;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v10, v11}, Lb2/i;->w(Lc2/b;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    check-cast v0, LX1/a;

    .line 140
    .line 141
    new-instance v7, LU1/h;

    .line 142
    .line 143
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 144
    .line 145
    .line 146
    new-instance v11, Ljava/util/HashMap;

    .line 147
    .line 148
    invoke-direct {v11}, Ljava/util/HashMap;-><init>()V

    .line 149
    .line 150
    .line 151
    iput-object v11, v7, LU1/h;->h:Ljava/lang/Object;

    .line 152
    .line 153
    iget-object v11, v1, La2/j;->g:Ld2/a;

    .line 154
    .line 155
    invoke-interface {v11}, Ld2/a;->n()J

    .line 156
    .line 157
    .line 158
    move-result-wide v18

    .line 159
    invoke-static/range {v18 .. v19}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 160
    .line 161
    .line 162
    move-result-object v11

    .line 163
    iput-object v11, v7, LU1/h;->f:Ljava/lang/Object;

    .line 164
    .line 165
    iget-object v11, v1, La2/j;->h:Ld2/a;

    .line 166
    .line 167
    invoke-interface {v11}, Ld2/a;->n()J

    .line 168
    .line 169
    .line 170
    move-result-wide v18

    .line 171
    invoke-static/range {v18 .. v19}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 172
    .line 173
    .line 174
    move-result-object v11

    .line 175
    iput-object v11, v7, LU1/h;->g:Ljava/io/Serializable;

    .line 176
    .line 177
    const-string v11, "GDT_CLIENT_METRICS"

    .line 178
    .line 179
    iput-object v11, v7, LU1/h;->a:Ljava/lang/String;

    .line 180
    .line 181
    new-instance v11, LU1/n;

    .line 182
    .line 183
    new-instance v14, LR1/c;

    .line 184
    .line 185
    invoke-direct {v14, v13}, LR1/c;-><init>(Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 189
    .line 190
    .line 191
    sget-object v15, LU1/q;->a:Landroid/support/v4/media/session/z;

    .line 192
    .line 193
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    .line 195
    .line 196
    new-instance v9, Ljava/io/ByteArrayOutputStream;

    .line 197
    .line 198
    invoke-direct {v9}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 199
    .line 200
    .line 201
    :try_start_0
    invoke-virtual {v15, v0, v9}, Landroid/support/v4/media/session/z;->r(Ljava/lang/Object;Ljava/io/ByteArrayOutputStream;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 202
    .line 203
    .line 204
    :catch_0
    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    invoke-direct {v11, v14, v0}, LU1/n;-><init>(LR1/c;[B)V

    .line 209
    .line 210
    .line 211
    iput-object v11, v7, LU1/h;->e:Ljava/lang/Object;

    .line 212
    .line 213
    invoke-virtual {v7}, LU1/h;->b()LU1/i;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    move-object v7, v6

    .line 218
    check-cast v7, LS1/b;

    .line 219
    .line 220
    invoke-virtual {v7, v0}, LS1/b;->a(LU1/i;)LU1/i;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    invoke-virtual {v8, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 225
    .line 226
    .line 227
    :cond_3
    move-object v0, v6

    .line 228
    check-cast v0, LS1/b;

    .line 229
    .line 230
    new-instance v7, Ljava/util/HashMap;

    .line 231
    .line 232
    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    .line 233
    .line 234
    .line 235
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 236
    .line 237
    .line 238
    move-result v9

    .line 239
    const/4 v11, 0x0

    .line 240
    :goto_3
    if-ge v11, v9, :cond_5

    .line 241
    .line 242
    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v14

    .line 246
    add-int/lit8 v11, v11, 0x1

    .line 247
    .line 248
    check-cast v14, LU1/i;

    .line 249
    .line 250
    iget-object v15, v14, LU1/i;->a:Ljava/lang/String;

    .line 251
    .line 252
    invoke-virtual {v7, v15}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 253
    .line 254
    .line 255
    move-result v21

    .line 256
    if-nez v21, :cond_4

    .line 257
    .line 258
    new-instance v1, Ljava/util/ArrayList;

    .line 259
    .line 260
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 261
    .line 262
    .line 263
    invoke-virtual {v1, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    invoke-virtual {v7, v15, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    goto :goto_4

    .line 270
    :cond_4
    invoke-virtual {v7, v15}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    move-result-object v1

    .line 274
    check-cast v1, Ljava/util/List;

    .line 275
    .line 276
    invoke-interface {v1, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 277
    .line 278
    .line 279
    :goto_4
    move-object/from16 v1, p0

    .line 280
    .line 281
    goto :goto_3

    .line 282
    :cond_5
    new-instance v1, Ljava/util/ArrayList;

    .line 283
    .line 284
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 285
    .line 286
    .line 287
    invoke-virtual {v7}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 288
    .line 289
    .line 290
    move-result-object v7

    .line 291
    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 292
    .line 293
    .line 294
    move-result-object v7

    .line 295
    :goto_5
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 296
    .line 297
    .line 298
    move-result v8

    .line 299
    const-string v14, "CctTransportBackend"

    .line 300
    .line 301
    if-eqz v8, :cond_15

    .line 302
    .line 303
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    move-result-object v8

    .line 307
    check-cast v8, Ljava/util/Map$Entry;

    .line 308
    .line 309
    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 310
    .line 311
    .line 312
    move-result-object v15

    .line 313
    check-cast v15, Ljava/util/List;

    .line 314
    .line 315
    const/4 v11, 0x0

    .line 316
    invoke-interface {v15, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 317
    .line 318
    .line 319
    move-result-object v15

    .line 320
    check-cast v15, LU1/i;

    .line 321
    .line 322
    sget-object v20, LT1/J;->a:LT1/J;

    .line 323
    .line 324
    iget-object v11, v0, LS1/b;->f:Ld2/a;

    .line 325
    .line 326
    invoke-interface {v11}, Ld2/a;->n()J

    .line 327
    .line 328
    .line 329
    move-result-wide v23

    .line 330
    iget-object v11, v0, LS1/b;->e:Ld2/a;

    .line 331
    .line 332
    invoke-interface {v11}, Ld2/a;->n()J

    .line 333
    .line 334
    .line 335
    move-result-wide v25

    .line 336
    const-string v11, "sdk-version"

    .line 337
    .line 338
    invoke-virtual {v15, v11}, LU1/i;->b(Ljava/lang/String;)I

    .line 339
    .line 340
    .line 341
    move-result v11

    .line 342
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 343
    .line 344
    .line 345
    move-result-object v28

    .line 346
    const-string v11, "model"

    .line 347
    .line 348
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object v29

    .line 352
    const-string v11, "hardware"

    .line 353
    .line 354
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object v30

    .line 358
    const-string v11, "device"

    .line 359
    .line 360
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v31

    .line 364
    const-string v11, "product"

    .line 365
    .line 366
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 367
    .line 368
    .line 369
    move-result-object v32

    .line 370
    const-string v11, "os-uild"

    .line 371
    .line 372
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 373
    .line 374
    .line 375
    move-result-object v33

    .line 376
    const-string v11, "manufacturer"

    .line 377
    .line 378
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v34

    .line 382
    const-string v11, "fingerprint"

    .line 383
    .line 384
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 385
    .line 386
    .line 387
    move-result-object v35

    .line 388
    const-string v11, "country"

    .line 389
    .line 390
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 391
    .line 392
    .line 393
    move-result-object v37

    .line 394
    const-string v11, "locale"

    .line 395
    .line 396
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 397
    .line 398
    .line 399
    move-result-object v36

    .line 400
    const-string v11, "mcc_mnc"

    .line 401
    .line 402
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 403
    .line 404
    .line 405
    move-result-object v38

    .line 406
    const-string v11, "application_build"

    .line 407
    .line 408
    invoke-virtual {v15, v11}, LU1/i;->a(Ljava/lang/String;)Ljava/lang/String;

    .line 409
    .line 410
    .line 411
    move-result-object v39

    .line 412
    new-instance v27, LT1/l;

    .line 413
    .line 414
    invoke-direct/range {v27 .. v39}, LT1/l;-><init>(Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 415
    .line 416
    .line 417
    move-object/from16 v11, v27

    .line 418
    .line 419
    new-instance v15, LT1/n;

    .line 420
    .line 421
    invoke-direct {v15, v11}, LT1/n;-><init>(LT1/l;)V

    .line 422
    .line 423
    .line 424
    :try_start_1
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 425
    .line 426
    .line 427
    move-result-object v11

    .line 428
    check-cast v11, Ljava/lang/String;

    .line 429
    .line 430
    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 431
    .line 432
    .line 433
    move-result v11

    .line 434
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 435
    .line 436
    .line 437
    move-result-object v11
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    .line 438
    move-object/from16 v28, v11

    .line 439
    .line 440
    const/16 v29, 0x0

    .line 441
    .line 442
    goto :goto_6

    .line 443
    :catch_1
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 444
    .line 445
    .line 446
    move-result-object v11

    .line 447
    check-cast v11, Ljava/lang/String;

    .line 448
    .line 449
    move-object/from16 v29, v11

    .line 450
    .line 451
    const/16 v28, 0x0

    .line 452
    .line 453
    :goto_6
    new-instance v11, Ljava/util/ArrayList;

    .line 454
    .line 455
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 456
    .line 457
    .line 458
    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 459
    .line 460
    .line 461
    move-result-object v8

    .line 462
    check-cast v8, Ljava/util/List;

    .line 463
    .line 464
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 465
    .line 466
    .line 467
    move-result-object v8

    .line 468
    :goto_7
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 469
    .line 470
    .line 471
    move-result v22

    .line 472
    if-eqz v22, :cond_14

    .line 473
    .line 474
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 475
    .line 476
    .line 477
    move-result-object v22

    .line 478
    move-object/from16 v9, v22

    .line 479
    .line 480
    check-cast v9, LU1/i;

    .line 481
    .line 482
    move-object/from16 v31, v2

    .line 483
    .line 484
    iget-object v2, v9, LU1/i;->c:LU1/n;

    .line 485
    .line 486
    iget-object v3, v9, LU1/i;->j:[B

    .line 487
    .line 488
    move-object/from16 v22, v3

    .line 489
    .line 490
    iget-object v3, v2, LU1/n;->a:LR1/c;

    .line 491
    .line 492
    iget-object v2, v2, LU1/n;->b:[B

    .line 493
    .line 494
    move-wide/from16 v32, v4

    .line 495
    .line 496
    new-instance v4, LR1/c;

    .line 497
    .line 498
    invoke-direct {v4, v13}, LR1/c;-><init>(Ljava/lang/String;)V

    .line 499
    .line 500
    .line 501
    invoke-virtual {v3, v4}, LR1/c;->equals(Ljava/lang/Object;)Z

    .line 502
    .line 503
    .line 504
    move-result v4

    .line 505
    if-eqz v4, :cond_6

    .line 506
    .line 507
    new-instance v3, LA5/f;

    .line 508
    .line 509
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 510
    .line 511
    .line 512
    iput-object v2, v3, LA5/f;->e:Ljava/lang/Object;

    .line 513
    .line 514
    goto :goto_8

    .line 515
    :cond_6
    new-instance v4, LR1/c;

    .line 516
    .line 517
    const-string v5, "json"

    .line 518
    .line 519
    invoke-direct {v4, v5}, LR1/c;-><init>(Ljava/lang/String;)V

    .line 520
    .line 521
    .line 522
    invoke-virtual {v3, v4}, LR1/c;->equals(Ljava/lang/Object;)Z

    .line 523
    .line 524
    .line 525
    move-result v4

    .line 526
    if-eqz v4, :cond_13

    .line 527
    .line 528
    new-instance v3, Ljava/lang/String;

    .line 529
    .line 530
    const-string v4, "UTF-8"

    .line 531
    .line 532
    invoke-static {v4}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 533
    .line 534
    .line 535
    move-result-object v4

    .line 536
    invoke-direct {v3, v2, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    .line 537
    .line 538
    .line 539
    new-instance v2, LA5/f;

    .line 540
    .line 541
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 542
    .line 543
    .line 544
    iput-object v3, v2, LA5/f;->f:Ljava/lang/Object;

    .line 545
    .line 546
    move-object v3, v2

    .line 547
    :goto_8
    iget-wide v4, v9, LU1/i;->d:J

    .line 548
    .line 549
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 550
    .line 551
    .line 552
    move-result-object v2

    .line 553
    iput-object v2, v3, LA5/f;->a:Ljava/lang/Object;

    .line 554
    .line 555
    iget-wide v4, v9, LU1/i;->e:J

    .line 556
    .line 557
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 558
    .line 559
    .line 560
    move-result-object v2

    .line 561
    iput-object v2, v3, LA5/f;->d:Ljava/lang/Object;

    .line 562
    .line 563
    const-string v2, "tz-offset"

    .line 564
    .line 565
    iget-object v4, v9, LU1/i;->f:Ljava/util/Map;

    .line 566
    .line 567
    invoke-interface {v4, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 568
    .line 569
    .line 570
    move-result-object v2

    .line 571
    check-cast v2, Ljava/lang/String;

    .line 572
    .line 573
    if-nez v2, :cond_7

    .line 574
    .line 575
    const-wide/16 v4, 0x0

    .line 576
    .line 577
    goto :goto_9

    .line 578
    :cond_7
    invoke-static {v2}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    .line 579
    .line 580
    .line 581
    move-result-object v2

    .line 582
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 583
    .line 584
    .line 585
    move-result-wide v4

    .line 586
    :goto_9
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 587
    .line 588
    .line 589
    move-result-object v2

    .line 590
    iput-object v2, v3, LA5/f;->g:Ljava/lang/Object;

    .line 591
    .line 592
    const-string v2, "net-type"

    .line 593
    .line 594
    invoke-virtual {v9, v2}, LU1/i;->b(Ljava/lang/String;)I

    .line 595
    .line 596
    .line 597
    move-result v2

    .line 598
    sget-object v4, LT1/H;->a:Landroid/util/SparseArray;

    .line 599
    .line 600
    invoke-virtual {v4, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 601
    .line 602
    .line 603
    move-result-object v2

    .line 604
    check-cast v2, LT1/H;

    .line 605
    .line 606
    const-string v4, "mobile-subtype"

    .line 607
    .line 608
    invoke-virtual {v9, v4}, LU1/i;->b(Ljava/lang/String;)I

    .line 609
    .line 610
    .line 611
    move-result v4

    .line 612
    sget-object v5, LT1/G;->a:Landroid/util/SparseArray;

    .line 613
    .line 614
    invoke-virtual {v5, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 615
    .line 616
    .line 617
    move-result-object v4

    .line 618
    check-cast v4, LT1/G;

    .line 619
    .line 620
    new-instance v5, LT1/v;

    .line 621
    .line 622
    invoke-direct {v5, v2, v4}, LT1/v;-><init>(LT1/H;LT1/G;)V

    .line 623
    .line 624
    .line 625
    iput-object v5, v3, LA5/f;->h:Ljava/lang/Object;

    .line 626
    .line 627
    iget-object v2, v9, LU1/i;->b:Ljava/lang/Integer;

    .line 628
    .line 629
    if-eqz v2, :cond_8

    .line 630
    .line 631
    iput-object v2, v3, LA5/f;->b:Ljava/lang/Object;

    .line 632
    .line 633
    :cond_8
    iget-object v2, v9, LU1/i;->g:Ljava/lang/Integer;

    .line 634
    .line 635
    if-eqz v2, :cond_9

    .line 636
    .line 637
    new-instance v4, LT1/q;

    .line 638
    .line 639
    invoke-direct {v4, v2}, LT1/q;-><init>(Ljava/lang/Integer;)V

    .line 640
    .line 641
    .line 642
    new-instance v2, LT1/r;

    .line 643
    .line 644
    invoke-direct {v2, v4}, LT1/r;-><init>(LT1/q;)V

    .line 645
    .line 646
    .line 647
    sget-object v4, LT1/z;->a:LT1/z;

    .line 648
    .line 649
    new-instance v4, LT1/o;

    .line 650
    .line 651
    invoke-direct {v4, v2}, LT1/o;-><init>(LT1/r;)V

    .line 652
    .line 653
    .line 654
    iput-object v4, v3, LA5/f;->c:Ljava/lang/Object;

    .line 655
    .line 656
    :cond_9
    iget-object v2, v9, LU1/i;->i:[B

    .line 657
    .line 658
    if-nez v2, :cond_a

    .line 659
    .line 660
    if-eqz v22, :cond_d

    .line 661
    .line 662
    :cond_a
    if-eqz v2, :cond_b

    .line 663
    .line 664
    goto :goto_a

    .line 665
    :cond_b
    const/4 v2, 0x0

    .line 666
    :goto_a
    if-eqz v22, :cond_c

    .line 667
    .line 668
    move-object/from16 v4, v22

    .line 669
    .line 670
    goto :goto_b

    .line 671
    :cond_c
    const/4 v4, 0x0

    .line 672
    :goto_b
    new-instance v5, LT1/p;

    .line 673
    .line 674
    invoke-direct {v5, v2, v4}, LT1/p;-><init>([B[B)V

    .line 675
    .line 676
    .line 677
    iput-object v5, v3, LA5/f;->i:Ljava/lang/Object;

    .line 678
    .line 679
    :cond_d
    iget-object v2, v3, LA5/f;->a:Ljava/lang/Object;

    .line 680
    .line 681
    check-cast v2, Ljava/lang/Long;

    .line 682
    .line 683
    if-nez v2, :cond_e

    .line 684
    .line 685
    const-string v2, " eventTimeMs"

    .line 686
    .line 687
    goto :goto_c

    .line 688
    :cond_e
    const-string v2, ""

    .line 689
    .line 690
    :goto_c
    iget-object v4, v3, LA5/f;->d:Ljava/lang/Object;

    .line 691
    .line 692
    check-cast v4, Ljava/lang/Long;

    .line 693
    .line 694
    if-nez v4, :cond_f

    .line 695
    .line 696
    const-string v4, " eventUptimeMs"

    .line 697
    .line 698
    invoke-virtual {v2, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 699
    .line 700
    .line 701
    move-result-object v2

    .line 702
    :cond_f
    iget-object v4, v3, LA5/f;->g:Ljava/lang/Object;

    .line 703
    .line 704
    check-cast v4, Ljava/lang/Long;

    .line 705
    .line 706
    if-nez v4, :cond_10

    .line 707
    .line 708
    const-string v4, " timezoneOffsetSeconds"

    .line 709
    .line 710
    invoke-static {v2, v4}, Lr6/a;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 711
    .line 712
    .line 713
    move-result-object v2

    .line 714
    :cond_10
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    .line 715
    .line 716
    .line 717
    move-result v4

    .line 718
    if-eqz v4, :cond_12

    .line 719
    .line 720
    new-instance v34, LT1/s;

    .line 721
    .line 722
    iget-object v2, v3, LA5/f;->a:Ljava/lang/Object;

    .line 723
    .line 724
    check-cast v2, Ljava/lang/Long;

    .line 725
    .line 726
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 727
    .line 728
    .line 729
    move-result-wide v35

    .line 730
    iget-object v2, v3, LA5/f;->b:Ljava/lang/Object;

    .line 731
    .line 732
    move-object/from16 v37, v2

    .line 733
    .line 734
    check-cast v37, Ljava/lang/Integer;

    .line 735
    .line 736
    iget-object v2, v3, LA5/f;->c:Ljava/lang/Object;

    .line 737
    .line 738
    move-object/from16 v38, v2

    .line 739
    .line 740
    check-cast v38, LT1/o;

    .line 741
    .line 742
    iget-object v2, v3, LA5/f;->d:Ljava/lang/Object;

    .line 743
    .line 744
    check-cast v2, Ljava/lang/Long;

    .line 745
    .line 746
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 747
    .line 748
    .line 749
    move-result-wide v39

    .line 750
    iget-object v2, v3, LA5/f;->e:Ljava/lang/Object;

    .line 751
    .line 752
    move-object/from16 v41, v2

    .line 753
    .line 754
    check-cast v41, [B

    .line 755
    .line 756
    iget-object v2, v3, LA5/f;->f:Ljava/lang/Object;

    .line 757
    .line 758
    move-object/from16 v42, v2

    .line 759
    .line 760
    check-cast v42, Ljava/lang/String;

    .line 761
    .line 762
    iget-object v2, v3, LA5/f;->g:Ljava/lang/Object;

    .line 763
    .line 764
    check-cast v2, Ljava/lang/Long;

    .line 765
    .line 766
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 767
    .line 768
    .line 769
    move-result-wide v43

    .line 770
    iget-object v2, v3, LA5/f;->h:Ljava/lang/Object;

    .line 771
    .line 772
    move-object/from16 v45, v2

    .line 773
    .line 774
    check-cast v45, LT1/v;

    .line 775
    .line 776
    iget-object v2, v3, LA5/f;->i:Ljava/lang/Object;

    .line 777
    .line 778
    move-object/from16 v46, v2

    .line 779
    .line 780
    check-cast v46, LT1/p;

    .line 781
    .line 782
    invoke-direct/range {v34 .. v46}, LT1/s;-><init>(JLjava/lang/Integer;LT1/A;J[BLjava/lang/String;JLT1/I;LT1/B;)V

    .line 783
    .line 784
    .line 785
    move-object/from16 v2, v34

    .line 786
    .line 787
    invoke-virtual {v11, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 788
    .line 789
    .line 790
    :cond_11
    :goto_d
    move-object/from16 v3, p1

    .line 791
    .line 792
    move-object/from16 v2, v31

    .line 793
    .line 794
    move-wide/from16 v4, v32

    .line 795
    .line 796
    goto/16 :goto_7

    .line 797
    .line 798
    :cond_12
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 799
    .line 800
    const-string v1, "Missing required properties:"

    .line 801
    .line 802
    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 803
    .line 804
    .line 805
    move-result-object v1

    .line 806
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 807
    .line 808
    .line 809
    throw v0

    .line 810
    :cond_13
    invoke-static {v14}, Lf5/b;->x(Ljava/lang/String;)Ljava/lang/String;

    .line 811
    .line 812
    .line 813
    move-result-object v2

    .line 814
    const/4 v4, 0x5

    .line 815
    invoke-static {v2, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 816
    .line 817
    .line 818
    move-result v5

    .line 819
    if-eqz v5, :cond_11

    .line 820
    .line 821
    new-instance v4, Ljava/lang/StringBuilder;

    .line 822
    .line 823
    const-string v5, "Received event of unsupported encoding "

    .line 824
    .line 825
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 826
    .line 827
    .line 828
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 829
    .line 830
    .line 831
    const-string v3, ". Skipping..."

    .line 832
    .line 833
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 834
    .line 835
    .line 836
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 837
    .line 838
    .line 839
    move-result-object v3

    .line 840
    invoke-static {v2, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 841
    .line 842
    .line 843
    goto :goto_d

    .line 844
    :cond_14
    move-object/from16 v31, v2

    .line 845
    .line 846
    move-wide/from16 v32, v4

    .line 847
    .line 848
    new-instance v22, LT1/t;

    .line 849
    .line 850
    move-object/from16 v30, v11

    .line 851
    .line 852
    move-object/from16 v27, v15

    .line 853
    .line 854
    invoke-direct/range {v22 .. v30}, LT1/t;-><init>(JJLT1/n;Ljava/lang/Integer;Ljava/lang/String;Ljava/util/ArrayList;)V

    .line 855
    .line 856
    .line 857
    move-object/from16 v2, v22

    .line 858
    .line 859
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 860
    .line 861
    .line 862
    move-object/from16 v3, p1

    .line 863
    .line 864
    move-object/from16 v2, v31

    .line 865
    .line 866
    goto/16 :goto_5

    .line 867
    .line 868
    :cond_15
    move-object/from16 v31, v2

    .line 869
    .line 870
    move-wide/from16 v32, v4

    .line 871
    .line 872
    new-instance v2, LT1/m;

    .line 873
    .line 874
    invoke-direct {v2, v1}, LT1/m;-><init>(Ljava/util/ArrayList;)V

    .line 875
    .line 876
    .line 877
    iget-object v1, v0, LS1/b;->d:Ljava/net/URL;

    .line 878
    .line 879
    if-eqz v31, :cond_17

    .line 880
    .line 881
    :try_start_2
    invoke-static/range {v31 .. v31}, LS1/a;->a([B)LS1/a;

    .line 882
    .line 883
    .line 884
    move-result-object v3

    .line 885
    iget-object v4, v3, LS1/a;->b:Ljava/lang/String;

    .line 886
    .line 887
    if-eqz v4, :cond_16

    .line 888
    .line 889
    goto :goto_e

    .line 890
    :cond_16
    const/4 v4, 0x0

    .line 891
    :goto_e
    iget-object v3, v3, LS1/a;->a:Ljava/lang/String;

    .line 892
    .line 893
    if-eqz v3, :cond_18

    .line 894
    .line 895
    invoke-static {v3}, LS1/b;->b(Ljava/lang/String;)Ljava/net/URL;

    .line 896
    .line 897
    .line 898
    move-result-object v1
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_2

    .line 899
    goto :goto_10

    .line 900
    :catch_2
    new-instance v0, LV1/a;

    .line 901
    .line 902
    const/4 v1, 0x3

    .line 903
    const-wide/16 v2, -0x1

    .line 904
    .line 905
    invoke-direct {v0, v2, v3, v1}, LV1/a;-><init>(JI)V

    .line 906
    .line 907
    .line 908
    :goto_f
    move-object v8, v0

    .line 909
    goto/16 :goto_1

    .line 910
    .line 911
    :cond_17
    const/4 v4, 0x0

    .line 912
    :cond_18
    :goto_10
    :try_start_3
    new-instance v3, Landroid/support/v4/media/session/z;

    .line 913
    .line 914
    const/16 v5, 0x14

    .line 915
    .line 916
    invoke-direct {v3, v1, v2, v4, v5}, Landroid/support/v4/media/session/z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 917
    .line 918
    .line 919
    new-instance v1, LH4/j;

    .line 920
    .line 921
    const/4 v4, 0x5

    .line 922
    invoke-direct {v1, v4, v0}, LH4/j;-><init>(ILjava/lang/Object;)V

    .line 923
    .line 924
    .line 925
    move v9, v4

    .line 926
    :cond_19
    invoke-virtual {v1, v3}, LH4/j;->b(Landroid/support/v4/media/session/z;)LJ2/a0;

    .line 927
    .line 928
    .line 929
    move-result-object v0

    .line 930
    iget-object v2, v0, LJ2/a0;->c:Ljava/lang/Object;

    .line 931
    .line 932
    check-cast v2, Ljava/net/URL;

    .line 933
    .line 934
    if-eqz v2, :cond_1a

    .line 935
    .line 936
    const-string v4, "Following redirect to: %s"

    .line 937
    .line 938
    invoke-static {v14, v4, v2}, Lf5/b;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 939
    .line 940
    .line 941
    new-instance v4, Landroid/support/v4/media/session/z;

    .line 942
    .line 943
    iget-object v7, v3, Landroid/support/v4/media/session/z;->c:Ljava/lang/Object;

    .line 944
    .line 945
    check-cast v7, LT1/m;

    .line 946
    .line 947
    iget-object v3, v3, Landroid/support/v4/media/session/z;->d:Ljava/lang/Object;

    .line 948
    .line 949
    check-cast v3, Ljava/lang/String;

    .line 950
    .line 951
    invoke-direct {v4, v2, v7, v3, v5}, Landroid/support/v4/media/session/z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 952
    .line 953
    .line 954
    move-object v3, v4

    .line 955
    goto :goto_11

    .line 956
    :cond_1a
    const/4 v3, 0x0

    .line 957
    :goto_11
    if-eqz v3, :cond_1b

    .line 958
    .line 959
    add-int/lit8 v9, v9, -0x1

    .line 960
    .line 961
    const/4 v2, 0x1

    .line 962
    if-ge v9, v2, :cond_19

    .line 963
    .line 964
    :cond_1b
    iget v1, v0, LJ2/a0;->a:I

    .line 965
    .line 966
    const/16 v2, 0xc8

    .line 967
    .line 968
    if-ne v1, v2, :cond_1c

    .line 969
    .line 970
    iget-wide v0, v0, LJ2/a0;->b:J

    .line 971
    .line 972
    new-instance v2, LV1/a;

    .line 973
    .line 974
    const/4 v3, 0x1

    .line 975
    invoke-direct {v2, v0, v1, v3}, LV1/a;-><init>(JI)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3

    .line 976
    .line 977
    .line 978
    move-object v8, v2

    .line 979
    goto/16 :goto_1

    .line 980
    .line 981
    :catch_3
    move-exception v0

    .line 982
    goto :goto_13

    .line 983
    :cond_1c
    const/16 v0, 0x1f4

    .line 984
    .line 985
    if-ge v1, v0, :cond_1d

    .line 986
    .line 987
    const/16 v0, 0x194

    .line 988
    .line 989
    if-ne v1, v0, :cond_1e

    .line 990
    .line 991
    :cond_1d
    const-wide/16 v2, -0x1

    .line 992
    .line 993
    goto :goto_12

    .line 994
    :cond_1e
    const/16 v0, 0x190

    .line 995
    .line 996
    if-ne v1, v0, :cond_1f

    .line 997
    .line 998
    :try_start_4
    new-instance v0, LV1/a;
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_4

    .line 999
    .line 1000
    const/4 v1, 0x4

    .line 1001
    const-wide/16 v2, -0x1

    .line 1002
    .line 1003
    :try_start_5
    invoke-direct {v0, v2, v3, v1}, LV1/a;-><init>(JI)V

    .line 1004
    .line 1005
    .line 1006
    goto :goto_f

    .line 1007
    :catch_4
    move-exception v0

    .line 1008
    const-wide/16 v2, -0x1

    .line 1009
    .line 1010
    goto :goto_13

    .line 1011
    :cond_1f
    const-wide/16 v2, -0x1

    .line 1012
    .line 1013
    new-instance v0, LV1/a;

    .line 1014
    .line 1015
    const/4 v1, 0x3

    .line 1016
    invoke-direct {v0, v2, v3, v1}, LV1/a;-><init>(JI)V

    .line 1017
    .line 1018
    .line 1019
    goto :goto_f

    .line 1020
    :goto_12
    new-instance v0, LV1/a;

    .line 1021
    .line 1022
    const/4 v1, 0x2

    .line 1023
    invoke-direct {v0, v2, v3, v1}, LV1/a;-><init>(JI)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_3

    .line 1024
    .line 1025
    .line 1026
    goto :goto_f

    .line 1027
    :goto_13
    const-string v1, "Could not make request to the backend"

    .line 1028
    .line 1029
    invoke-static {v14, v1, v0}, Lf5/b;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    .line 1030
    .line 1031
    .line 1032
    new-instance v0, LV1/a;

    .line 1033
    .line 1034
    const/4 v1, 0x2

    .line 1035
    const-wide/16 v2, -0x1

    .line 1036
    .line 1037
    invoke-direct {v0, v2, v3, v1}, LV1/a;-><init>(JI)V

    .line 1038
    .line 1039
    .line 1040
    move-object v8, v0

    .line 1041
    :goto_14
    iget v0, v8, LV1/a;->a:I

    .line 1042
    .line 1043
    if-ne v0, v1, :cond_20

    .line 1044
    .line 1045
    new-instance v0, La2/i;

    .line 1046
    .line 1047
    move-object/from16 v1, p0

    .line 1048
    .line 1049
    move-object/from16 v3, p1

    .line 1050
    .line 1051
    move-object v2, v12

    .line 1052
    move-wide/from16 v4, v32

    .line 1053
    .line 1054
    invoke-direct/range {v0 .. v5}, La2/i;-><init>(La2/j;Ljava/lang/Iterable;LU1/j;J)V

    .line 1055
    .line 1056
    .line 1057
    invoke-virtual {v10, v0}, Lb2/i;->w(Lc2/b;)Ljava/lang/Object;

    .line 1058
    .line 1059
    .line 1060
    const/4 v2, 0x1

    .line 1061
    add-int/lit8 v0, p2, 0x1

    .line 1062
    .line 1063
    iget-object v4, v1, La2/j;->d:La2/d;

    .line 1064
    .line 1065
    invoke-virtual {v4, v3, v0, v2}, La2/d;->a(LU1/j;IZ)V

    .line 1066
    .line 1067
    .line 1068
    return-void

    .line 1069
    :cond_20
    move-object/from16 v1, p0

    .line 1070
    .line 1071
    move-object/from16 v3, p1

    .line 1072
    .line 1073
    move-object v7, v12

    .line 1074
    move-wide/from16 v4, v32

    .line 1075
    .line 1076
    const/4 v2, 0x1

    .line 1077
    new-instance v9, LB7/e;

    .line 1078
    .line 1079
    const/16 v11, 0x9

    .line 1080
    .line 1081
    invoke-direct {v9, v1, v11, v7}, LB7/e;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1082
    .line 1083
    .line 1084
    invoke-virtual {v10, v9}, Lb2/i;->w(Lc2/b;)Ljava/lang/Object;

    .line 1085
    .line 1086
    .line 1087
    const/16 v9, 0xa

    .line 1088
    .line 1089
    if-ne v0, v2, :cond_21

    .line 1090
    .line 1091
    iget-wide v7, v8, LV1/a;->b:J

    .line 1092
    .line 1093
    invoke-static {v4, v5, v7, v8}, Ljava/lang/Math;->max(JJ)J

    .line 1094
    .line 1095
    .line 1096
    move-result-wide v4

    .line 1097
    if-eqz v31, :cond_24

    .line 1098
    .line 1099
    new-instance v0, LH4/j;

    .line 1100
    .line 1101
    invoke-direct {v0, v9, v1}, LH4/j;-><init>(ILjava/lang/Object;)V

    .line 1102
    .line 1103
    .line 1104
    invoke-virtual {v10, v0}, Lb2/i;->w(Lc2/b;)Ljava/lang/Object;

    .line 1105
    .line 1106
    .line 1107
    goto :goto_16

    .line 1108
    :cond_21
    const/4 v2, 0x4

    .line 1109
    if-ne v0, v2, :cond_24

    .line 1110
    .line 1111
    new-instance v0, Ljava/util/HashMap;

    .line 1112
    .line 1113
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 1114
    .line 1115
    .line 1116
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1117
    .line 1118
    .line 1119
    move-result-object v2

    .line 1120
    :goto_15
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1121
    .line 1122
    .line 1123
    move-result v7

    .line 1124
    if-eqz v7, :cond_23

    .line 1125
    .line 1126
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1127
    .line 1128
    .line 1129
    move-result-object v7

    .line 1130
    check-cast v7, Lb2/b;

    .line 1131
    .line 1132
    iget-object v7, v7, Lb2/b;->c:LU1/i;

    .line 1133
    .line 1134
    iget-object v7, v7, LU1/i;->a:Ljava/lang/String;

    .line 1135
    .line 1136
    invoke-virtual {v0, v7}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 1137
    .line 1138
    .line 1139
    move-result v8

    .line 1140
    if-nez v8, :cond_22

    .line 1141
    .line 1142
    const/16 v17, 0x1

    .line 1143
    .line 1144
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1145
    .line 1146
    .line 1147
    move-result-object v8

    .line 1148
    invoke-virtual {v0, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1149
    .line 1150
    .line 1151
    goto :goto_15

    .line 1152
    :cond_22
    const/16 v17, 0x1

    .line 1153
    .line 1154
    invoke-virtual {v0, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1155
    .line 1156
    .line 1157
    move-result-object v8

    .line 1158
    check-cast v8, Ljava/lang/Integer;

    .line 1159
    .line 1160
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 1161
    .line 1162
    .line 1163
    move-result v8

    .line 1164
    add-int/lit8 v8, v8, 0x1

    .line 1165
    .line 1166
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1167
    .line 1168
    .line 1169
    move-result-object v8

    .line 1170
    invoke-virtual {v0, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1171
    .line 1172
    .line 1173
    goto :goto_15

    .line 1174
    :cond_23
    new-instance v2, LB7/e;

    .line 1175
    .line 1176
    invoke-direct {v2, v1, v9, v0}, LB7/e;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1177
    .line 1178
    .line 1179
    invoke-virtual {v10, v2}, Lb2/i;->w(Lc2/b;)Ljava/lang/Object;

    .line 1180
    .line 1181
    .line 1182
    :cond_24
    :goto_16
    move-object/from16 v2, v31

    .line 1183
    .line 1184
    const-wide/16 v7, 0x0

    .line 1185
    .line 1186
    goto/16 :goto_0

    .line 1187
    .line 1188
    :cond_25
    new-instance v0, LX5/g;

    .line 1189
    .line 1190
    invoke-direct {v0, v1, v3, v4, v5}, LX5/g;-><init>(Ljava/lang/Object;Ljava/lang/Object;J)V

    .line 1191
    .line 1192
    .line 1193
    invoke-virtual {v10, v0}, Lb2/i;->w(Lc2/b;)Ljava/lang/Object;

    .line 1194
    .line 1195
    .line 1196
    return-void
.end method
