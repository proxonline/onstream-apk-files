.class public final La2/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LW1/b;


# instance fields
.field public final a:Lc8/a;

.field public final b:Lc8/a;

.field public final c:LU1/u;

.field public final d:Lc8/a;


# direct methods
.method public constructor <init>(Lc8/a;Lc8/a;LU1/u;Lc8/a;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La2/m;->a:Lc8/a;

    .line 5
    .line 6
    iput-object p2, p0, La2/m;->b:Lc8/a;

    .line 7
    .line 8
    iput-object p3, p0, La2/m;->c:LU1/u;

    .line 9
    .line 10
    iput-object p4, p0, La2/m;->d:Lc8/a;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, La2/m;->a:Lc8/a;

    .line 2
    .line 3
    invoke-interface {v0}, Lc8/a;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/util/concurrent/Executor;

    .line 8
    .line 9
    iget-object v1, p0, La2/m;->b:Lc8/a;

    .line 10
    .line 11
    invoke-interface {v1}, Lc8/a;->get()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lb2/d;

    .line 16
    .line 17
    iget-object v2, p0, La2/m;->c:LU1/u;

    .line 18
    .line 19
    invoke-virtual {v2}, LU1/u;->get()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    check-cast v2, La2/d;

    .line 24
    .line 25
    iget-object v3, p0, La2/m;->d:Lc8/a;

    .line 26
    .line 27
    invoke-interface {v3}, Lc8/a;->get()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    check-cast v3, Lc2/c;

    .line 32
    .line 33
    new-instance v4, La2/l;

    .line 34
    .line 35
    invoke-direct {v4, v0, v1, v2, v3}, La2/l;-><init>(Ljava/util/concurrent/Executor;Lb2/d;La2/d;Lc2/c;)V

    .line 36
    .line 37
    .line 38
    return-object v4
.end method
