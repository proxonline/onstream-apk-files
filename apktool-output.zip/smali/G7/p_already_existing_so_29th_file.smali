.class public final Lg7/p;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:Ljava/lang/Object;

.field public s:I

.field public final synthetic t:Lg7/q;

.field public final synthetic u:I


# direct methods
.method public constructor <init>(Lg7/q;ILh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lg7/p;->t:Lg7/q;

    .line 2
    .line 3
    iput p2, p0, Lg7/p;->u:I

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p3}, Lj8/i;-><init>(ILh8/d;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 2

    .line 1
    new-instance p1, Lg7/p;

    .line 2
    .line 3
    iget-object v0, p0, Lg7/p;->t:Lg7/q;

    .line 4
    .line 5
    iget v1, p0, Lg7/p;->u:I

    .line 6
    .line 7
    invoke-direct {p1, v0, v1, p2}, Lg7/p;-><init>(Lg7/q;ILh8/d;)V

    .line 8
    .line 9
    .line 10
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lg7/p;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lg7/p;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lg7/p;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    iget-object v0, p0, Lg7/p;->t:Lg7/q;

    .line 2
    .line 3
    iget-object v1, v0, Lg7/q;->e:LE8/U;

    .line 4
    .line 5
    iget v2, p0, Lg7/p;->s:I

    .line 6
    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x1

    .line 9
    sget-object v5, Li8/a;->a:Li8/a;

    .line 10
    .line 11
    if-eqz v2, :cond_2

    .line 12
    .line 13
    if-eq v2, v4, :cond_1

    .line 14
    .line 15
    if-ne v2, v3, :cond_0

    .line 16
    .line 17
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    move-object v10, p0

    .line 21
    goto :goto_2

    .line 22
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 23
    .line 24
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 25
    .line 26
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    throw p1

    .line 30
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    check-cast p1, Ld8/i;

    .line 34
    .line 35
    iget-object p1, p1, Ld8/i;->a:Ljava/lang/Object;

    .line 36
    .line 37
    move-object v10, p0

    .line 38
    goto :goto_0

    .line 39
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    iget-object v6, v0, Lg7/q;->d:LC6/l;

    .line 43
    .line 44
    iget-object v8, v0, Lg7/q;->h:LA6/c;

    .line 45
    .line 46
    iput v4, p0, Lg7/p;->s:I

    .line 47
    .line 48
    sget-object v7, Lcom/maertsno/domain/type/MediaType;->c:Lcom/maertsno/domain/type/MediaType;

    .line 49
    .line 50
    iget v9, p0, Lg7/p;->u:I

    .line 51
    .line 52
    const/16 v11, 0x8

    .line 53
    .line 54
    move-object v10, p0

    .line 55
    invoke-static/range {v6 .. v11}, LC6/l;->f(LC6/l;Lcom/maertsno/domain/type/MediaType;LA6/c;ILj8/i;I)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    if-ne p1, v5, :cond_3

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_3
    :goto_0
    instance-of v2, p1, Ld8/h;

    .line 63
    .line 64
    const/4 v4, 0x0

    .line 65
    if-nez v2, :cond_4

    .line 66
    .line 67
    move-object v2, p1

    .line 68
    check-cast v2, Ly6/A;

    .line 69
    .line 70
    invoke-interface {v1}, LE8/S;->getValue()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v6

    .line 74
    check-cast v6, Ljava/util/List;

    .line 75
    .line 76
    iget-object v2, v2, Ly6/A;->c:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v2, Ljava/util/List;

    .line 79
    .line 80
    invoke-static {v6, v2}, Le8/i;->u0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v1, v4, v2}, LE8/U;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    :cond_4
    invoke-static {p1}, Ld8/i;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    if-eqz v1, :cond_5

    .line 95
    .line 96
    iget-object v2, v0, Lg7/q;->f:LE8/U;

    .line 97
    .line 98
    new-instance v6, LR6/w;

    .line 99
    .line 100
    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 101
    .line 102
    invoke-direct {v6, v7}, LR6/w;-><init>(Ljava/lang/Object;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v2, v4, v6}, LE8/U;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    iput-object p1, v10, Lg7/p;->r:Ljava/lang/Object;

    .line 112
    .line 113
    iput v3, v10, Lg7/p;->s:I

    .line 114
    .line 115
    invoke-virtual {v0, v1, p0}, LR6/s;->h(Ljava/lang/Throwable;Lh8/d;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    if-ne p1, v5, :cond_5

    .line 120
    .line 121
    :goto_1
    return-object v5

    .line 122
    :cond_5
    :goto_2
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 123
    .line 124
    return-object p1
.end method
