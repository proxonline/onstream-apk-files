.class public final Lg7/q;
.super LR6/s;
.source "SourceFile"


# instance fields
.field public final d:LC6/l;

.field public final e:LE8/U;

.field public final f:LE8/U;

.field public g:LB8/B0;

.field public h:LA6/c;


# direct methods
.method public constructor <init>(LC6/l;)V
    .locals 1

    .line 1
    invoke-direct {p0}, LR6/s;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lg7/q;->d:LC6/l;

    .line 5
    .line 6
    sget-object p1, Le8/q;->a:Le8/q;

    .line 7
    .line 8
    invoke-static {p1}, LE8/P;->b(Ljava/lang/Object;)LE8/U;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    iput-object p1, p0, Lg7/q;->e:LE8/U;

    .line 13
    .line 14
    new-instance p1, LR6/w;

    .line 15
    .line 16
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 17
    .line 18
    invoke-direct {p1, v0}, LR6/w;-><init>(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-static {p1}, LE8/P;->b(Ljava/lang/Object;)LE8/U;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iput-object p1, p0, Lg7/q;->f:LE8/U;

    .line 26
    .line 27
    sget-object p1, LA6/c;->a:LA6/c;

    .line 28
    .line 29
    iput-object p1, p0, Lg7/q;->h:LA6/c;

    .line 30
    .line 31
    return-void
.end method
