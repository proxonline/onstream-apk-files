.class public final Lg7/m;
.super Lg7/b;
.source "SourceFile"

# interfaces
.implements LX0/i;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lg7/b<",
        "Lg7/q;",
        "LN6/y1;",
        ">;",
        "LX0/i;"
    }
.end annotation


# instance fields
.field public final B0:LC1/b;

.field public final C0:Ld8/j;

.field public final D0:Ld8/j;


# direct methods
.method public constructor <init>()V
    .locals 6

    .line 1
    invoke-direct {p0}, Lg7/b;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, LY6/d;

    .line 5
    .line 6
    const/16 v1, 0xd

    .line 7
    .line 8
    invoke-direct {v0, v1, p0}, LY6/d;-><init>(ILjava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    new-instance v1, LY6/d;

    .line 12
    .line 13
    const/16 v2, 0xe

    .line 14
    .line 15
    invoke-direct {v1, v2, v0}, LY6/d;-><init>(ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-static {v1}, Lr3/e;->w(Lr8/a;)Ld8/d;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    const-class v1, Lg7/q;

    .line 23
    .line 24
    invoke-static {v1}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    new-instance v2, LX6/C;

    .line 29
    .line 30
    const/16 v3, 0x12

    .line 31
    .line 32
    invoke-direct {v2, v0, v3}, LX6/C;-><init>(Ld8/d;I)V

    .line 33
    .line 34
    .line 35
    new-instance v3, LX6/C;

    .line 36
    .line 37
    const/16 v4, 0x13

    .line 38
    .line 39
    invoke-direct {v3, v0, v4}, LX6/C;-><init>(Ld8/d;I)V

    .line 40
    .line 41
    .line 42
    new-instance v4, LB7/r;

    .line 43
    .line 44
    const/16 v5, 0x16

    .line 45
    .line 46
    invoke-direct {v4, p0, v0, v5}, LB7/r;-><init>(Lj0/y;Ld8/d;I)V

    .line 47
    .line 48
    .line 49
    new-instance v0, LC1/b;

    .line 50
    .line 51
    invoke-direct {v0, v1, v2, v4, v3}, LC1/b;-><init>(Lkotlin/jvm/internal/d;Lr8/a;Lr8/a;Lr8/a;)V

    .line 52
    .line 53
    .line 54
    iput-object v0, p0, Lg7/m;->B0:LC1/b;

    .line 55
    .line 56
    new-instance v0, Lg7/e;

    .line 57
    .line 58
    const/4 v1, 0x0

    .line 59
    invoke-direct {v0, p0, v1}, Lg7/e;-><init>(Lg7/m;I)V

    .line 60
    .line 61
    .line 62
    invoke-static {v0}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    iput-object v0, p0, Lg7/m;->C0:Ld8/j;

    .line 67
    .line 68
    new-instance v0, Lg7/e;

    .line 69
    .line 70
    const/4 v1, 0x1

    .line 71
    invoke-direct {v0, p0, v1}, Lg7/e;-><init>(Lg7/m;I)V

    .line 72
    .line 73
    .line 74
    invoke-static {v0}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    iput-object v0, p0, Lg7/m;->D0:Ld8/j;

    .line 79
    .line 80
    return-void
.end method


# virtual methods
.method public final H(Landroid/os/Bundle;)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, Lj0/y;->H(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    const-class p1, LA6/c;

    .line 5
    .line 6
    invoke-static {p1}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    const-string v0, "ARGS_PAGE_TYPE"

    .line 11
    .line 12
    invoke-static {p0, v0, p1}, Lr3/e;->r(LR6/n;Ljava/lang/String;Lkotlin/jvm/internal/d;)Ljava/io/Serializable;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    check-cast p1, LA6/c;

    .line 17
    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    invoke-virtual {p0}, Lg7/m;->u0()Lg7/q;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    iput-object p1, v0, Lg7/q;->h:LA6/c;

    .line 25
    .line 26
    :cond_0
    return-void
.end method

.method public final e()V
    .locals 3

    .line 1
    invoke-virtual {p0}, LR6/n;->f0()LW/g;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, LN6/y1;

    .line 6
    .line 7
    iget-object v0, v0, LN6/y1;->E:Landroidx/recyclerview/widget/RecyclerView;

    .line 8
    .line 9
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->p0()V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0}, LR6/n;->f0()LW/g;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    check-cast v0, LN6/y1;

    .line 17
    .line 18
    iget-object v0, v0, LN6/y1;->F:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-virtual {v0, v1}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setRefreshing(Z)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p0, Lg7/m;->D0:Ld8/j;

    .line 25
    .line 26
    invoke-virtual {v0}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    check-cast v0, Lg7/f;

    .line 31
    .line 32
    invoke-virtual {v0}, LR6/u;->d()V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, Lg7/m;->u0()Lg7/q;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    iget-object v1, v0, Lg7/q;->g:LB8/B0;

    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    if-eqz v1, :cond_0

    .line 43
    .line 44
    invoke-virtual {v1, v2}, LB8/u0;->f(Ljava/util/concurrent/CancellationException;)V

    .line 45
    .line 46
    .line 47
    :cond_0
    new-instance v1, Lg7/o;

    .line 48
    .line 49
    invoke-direct {v1, v0, v2}, Lg7/o;-><init>(Lg7/q;Lh8/d;)V

    .line 50
    .line 51
    .line 52
    const/4 v2, 0x1

    .line 53
    invoke-virtual {v0, v2, v1}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    iput-object v1, v0, Lg7/q;->g:LB8/B0;

    .line 58
    .line 59
    return-void
.end method

.method public final g0()I
    .locals 1

    .line 1
    const v0, 0x7f0d00d9

    .line 2
    .line 3
    .line 4
    return v0
.end method

.method public final h0()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public final bridge synthetic i0()LR6/s;
    .locals 1

    .line 1
    invoke-virtual {p0}, Lg7/m;->u0()Lg7/q;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final m0()V
    .locals 4

    .line 1
    invoke-virtual {p0}, Lj0/y;->v()Lj0/c0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Landroidx/lifecycle/V;->e(Landroidx/lifecycle/v;)Landroidx/lifecycle/q;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    new-instance v1, Lg7/l;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-direct {v1, p0, v2}, Lg7/l;-><init>(Lg7/m;Lh8/d;)V

    .line 13
    .line 14
    .line 15
    const/4 v3, 0x3

    .line 16
    invoke-static {v0, v2, v1, v3}, LB8/D;->r(LB8/A;Lh8/i;Lr8/p;I)LB8/B0;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Lg7/m;->u0()Lg7/q;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-object v0, v0, Lg7/q;->e:LE8/U;

    .line 24
    .line 25
    invoke-interface {v0}, LE8/S;->getValue()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Ljava/util/List;

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    invoke-virtual {p0}, Lg7/m;->u0()Lg7/q;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    iget-object v1, v0, Lg7/q;->g:LB8/B0;

    .line 42
    .line 43
    if-eqz v1, :cond_0

    .line 44
    .line 45
    invoke-virtual {v1, v2}, LB8/u0;->f(Ljava/util/concurrent/CancellationException;)V

    .line 46
    .line 47
    .line 48
    :cond_0
    new-instance v1, Lg7/o;

    .line 49
    .line 50
    invoke-direct {v1, v0, v2}, Lg7/o;-><init>(Lg7/q;Lh8/d;)V

    .line 51
    .line 52
    .line 53
    const/4 v2, 0x1

    .line 54
    invoke-virtual {v0, v2, v1}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    iput-object v1, v0, Lg7/q;->g:LB8/B0;

    .line 59
    .line 60
    :cond_1
    return-void
.end method

.method public final r0()V
    .locals 4

    .line 1
    invoke-virtual {p0}, LR6/n;->f0()LW/g;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, LN6/y1;

    .line 6
    .line 7
    iget-object v1, v0, LN6/y1;->F:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    .line 8
    .line 9
    invoke-virtual {v1, p0}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setOnRefreshListener(LX0/i;)V

    .line 10
    .line 11
    .line 12
    iget-object v0, v0, LN6/y1;->E:Landroidx/recyclerview/widget/RecyclerView;

    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setHasFixedSize(Z)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lg7/m;->D0:Ld8/j;

    .line 19
    .line 20
    invoke-virtual {v1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Lg7/f;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/a;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    invoke-static {v3}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    iput-object v3, v2, LR6/u;->i:Landroidx/recyclerview/widget/a;

    .line 37
    .line 38
    invoke-virtual {v1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    check-cast v1, Lg7/f;

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->j(LG0/h0;)V

    .line 45
    .line 46
    .line 47
    iget-object v1, p0, Lg7/m;->C0:Ld8/j;

    .line 48
    .line 49
    invoke-virtual {v1}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, LP6/d;

    .line 54
    .line 55
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(LG0/V;)V

    .line 56
    .line 57
    .line 58
    return-void
.end method

.method public final u0()Lg7/q;
    .locals 1

    .line 1
    iget-object v0, p0, Lg7/m;->B0:LC1/b;

    .line 2
    .line 3
    invoke-virtual {v0}, LC1/b;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lg7/q;

    .line 8
    .line 9
    return-object v0
.end method
