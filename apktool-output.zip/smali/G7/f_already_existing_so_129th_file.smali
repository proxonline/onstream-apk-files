.class public final Lg7/f;
.super LR6/u;
.source "SourceFile"


# instance fields
.field public final synthetic j:Lg7/m;


# direct methods
.method public constructor <init>(Lg7/m;Landroidx/recyclerview/widget/a;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lg7/f;->j:Lg7/m;

    .line 2
    .line 3
    invoke-direct {p0, p2}, LR6/u;-><init>(Landroidx/recyclerview/widget/a;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c(I)V
    .locals 3

    .line 1
    iget-object v0, p0, Lg7/f;->j:Lg7/m;

    .line 2
    .line 3
    invoke-virtual {v0}, Lg7/m;->u0()Lg7/q;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, v0, Lg7/q;->g:LB8/B0;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    invoke-virtual {v1, v2}, LB8/u0;->f(Ljava/util/concurrent/CancellationException;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    new-instance v1, Lg7/p;

    .line 16
    .line 17
    invoke-direct {v1, v0, p1, v2}, Lg7/p;-><init>(Lg7/q;ILh8/d;)V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x1

    .line 21
    invoke-virtual {v0, p1, v1}, LR6/s;->f(ZLr8/p;)LB8/B0;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iput-object p1, v0, Lg7/q;->g:LB8/B0;

    .line 26
    .line 27
    return-void
.end method
