.class public final Lg7/o;
.super Lj8/i;
.source "SourceFile"

# interfaces
.implements Lr8/p;


# instance fields
.field public r:Ljava/lang/Object;

.field public s:I

.field public final synthetic t:Lg7/q;


# direct methods
.method public constructor <init>(Lg7/q;Lh8/d;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lg7/o;->t:Lg7/q;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1, p2}, Lj8/i;-><init>(ILh8/d;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lh8/d;)Lh8/d;
    .locals 1

    .line 1
    new-instance p1, Lg7/o;

    .line 2
    .line 3
    iget-object v0, p0, Lg7/o;->t:Lg7/q;

    .line 4
    .line 5
    invoke-direct {p1, v0, p2}, Lg7/o;-><init>(Lg7/q;Lh8/d;)V

    .line 6
    .line 7
    .line 8
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, LB8/A;

    .line 2
    .line 3
    check-cast p2, Lh8/d;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lg7/o;->create(Ljava/lang/Object;Lh8/d;)Lh8/d;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lg7/o;

    .line 10
    .line 11
    sget-object p2, Ld8/l;->a:Ld8/l;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lg7/o;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11

    .line 1
    iget v0, p0, Lg7/o;->s:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    iget-object v3, p0, Lg7/o;->t:Lg7/q;

    .line 6
    .line 7
    sget-object v4, Li8/a;->a:Li8/a;

    .line 8
    .line 9
    if-eqz v0, :cond_2

    .line 10
    .line 11
    if-eq v0, v2, :cond_1

    .line 12
    .line 13
    if-ne v0, v1, :cond_0

    .line 14
    .line 15
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    move-object v9, p0

    .line 19
    goto :goto_2

    .line 20
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 21
    .line 22
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 23
    .line 24
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    throw p1

    .line 28
    :cond_1
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    check-cast p1, Ld8/i;

    .line 32
    .line 33
    iget-object p1, p1, Ld8/i;->a:Ljava/lang/Object;

    .line 34
    .line 35
    move-object v9, p0

    .line 36
    goto :goto_0

    .line 37
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iget-object v5, v3, Lg7/q;->d:LC6/l;

    .line 41
    .line 42
    iget-object v7, v3, Lg7/q;->h:LA6/c;

    .line 43
    .line 44
    iput v2, p0, Lg7/o;->s:I

    .line 45
    .line 46
    sget-object v6, Lcom/maertsno/domain/type/MediaType;->c:Lcom/maertsno/domain/type/MediaType;

    .line 47
    .line 48
    const/4 v8, 0x0

    .line 49
    const/16 v10, 0xc

    .line 50
    .line 51
    move-object v9, p0

    .line 52
    invoke-static/range {v5 .. v10}, LC6/l;->f(LC6/l;Lcom/maertsno/domain/type/MediaType;LA6/c;ILj8/i;I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    if-ne p1, v4, :cond_3

    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_3
    :goto_0
    instance-of v0, p1, Ld8/h;

    .line 60
    .line 61
    if-nez v0, :cond_4

    .line 62
    .line 63
    move-object v0, p1

    .line 64
    check-cast v0, Ly6/A;

    .line 65
    .line 66
    iget-object v2, v3, Lg7/q;->e:LE8/U;

    .line 67
    .line 68
    iget-object v0, v0, Ly6/A;->c:Ljava/lang/Object;

    .line 69
    .line 70
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    const/4 v5, 0x0

    .line 74
    invoke-virtual {v2, v5, v0}, LE8/U;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    :cond_4
    invoke-static {p1}, Ld8/i;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    if-eqz v0, :cond_5

    .line 82
    .line 83
    iput-object p1, v9, Lg7/o;->r:Ljava/lang/Object;

    .line 84
    .line 85
    iput v1, v9, Lg7/o;->s:I

    .line 86
    .line 87
    invoke-virtual {v3, v0, p0}, LR6/s;->h(Ljava/lang/Throwable;Lh8/d;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    if-ne p1, v4, :cond_5

    .line 92
    .line 93
    :goto_1
    return-object v4

    .line 94
    :cond_5
    :goto_2
    sget-object p1, Ld8/l;->a:Ld8/l;

    .line 95
    .line 96
    return-object p1
.end method
