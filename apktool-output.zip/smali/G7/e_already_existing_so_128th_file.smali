.class public final synthetic Lg7/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lr8/a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lg7/m;


# direct methods
.method public synthetic constructor <init>(Lg7/m;I)V
    .locals 0

    .line 1
    iput p2, p0, Lg7/e;->a:I

    iput-object p1, p0, Lg7/e;->b:Lg7/m;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, Lg7/e;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lg7/e;->b:Lg7/m;

    .line 7
    .line 8
    invoke-virtual {v0}, LR6/n;->f0()LW/g;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    check-cast v1, LN6/y1;

    .line 13
    .line 14
    iget-object v1, v1, LN6/y1;->E:Landroidx/recyclerview/widget/RecyclerView;

    .line 15
    .line 16
    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/a;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-static {v1}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    new-instance v2, Lg7/f;

    .line 24
    .line 25
    invoke-direct {v2, v0, v1}, Lg7/f;-><init>(Lg7/m;Landroidx/recyclerview/widget/a;)V

    .line 26
    .line 27
    .line 28
    return-object v2

    .line 29
    :pswitch_0
    new-instance v0, LP6/d;

    .line 30
    .line 31
    new-instance v1, LB7/f;

    .line 32
    .line 33
    const/4 v2, 0x6

    .line 34
    iget-object v3, p0, Lg7/e;->b:Lg7/m;

    .line 35
    .line 36
    invoke-direct {v1, v2, v3}, LB7/f;-><init>(ILjava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    invoke-direct {v0, v1}, LP6/d;-><init>(LR6/v;)V

    .line 40
    .line 41
    .line 42
    return-object v0

    .line 43
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
