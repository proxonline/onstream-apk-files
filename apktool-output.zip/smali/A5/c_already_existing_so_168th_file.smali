.class public final LA5/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lg1/q;

.field public final b:LA5/b;

.field public final c:J

.field public final d:D

.field public final e:D

.field public final f:I


# direct methods
.method public constructor <init>(JLg1/q;LA5/b;DDI)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, LA5/c;->c:J

    .line 5
    .line 6
    iput-object p3, p0, LA5/c;->a:Lg1/q;

    .line 7
    .line 8
    iput-object p4, p0, LA5/c;->b:LA5/b;

    .line 9
    .line 10
    iput-wide p5, p0, LA5/c;->d:D

    .line 11
    .line 12
    iput-wide p7, p0, LA5/c;->e:D

    .line 13
    .line 14
    iput p9, p0, LA5/c;->f:I

    .line 15
    .line 16
    return-void
.end method
