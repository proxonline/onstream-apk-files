.class public final LA5/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb4/g;
.implements LB5/a;
.implements LR0/b;
.implements Lg3/P;
.implements LK1/h;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 1

    iput p1, p0, LA5/e;->a:I

    sparse-switch p1, :sswitch_data_0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    new-instance p1, Ljava/io/ByteArrayOutputStream;

    const/16 v0, 0x200

    invoke-direct {p1, v0}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 33
    new-instance v0, Ljava/io/DataOutputStream;

    invoke-direct {v0, p1}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    iput-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    return-void

    .line 34
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    new-instance p1, Lr/i;

    const/4 v0, 0x0

    .line 36
    invoke-direct {p1, v0}, Lr/i;-><init>(I)V

    .line 37
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 38
    new-instance p1, Lr/g;

    invoke-direct {p1}, Lr/g;-><init>()V

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void

    .line 39
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void

    .line 40
    :sswitch_2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 41
    new-instance p1, Landroid/util/SparseIntArray;

    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 42
    new-instance p1, Landroid/util/SparseIntArray;

    invoke-direct {p1}, Landroid/util/SparseIntArray;-><init>()V

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void

    .line 43
    :sswitch_3
    sget-object p1, Lx3/e;->d:Lx3/e;

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/util/SparseIntArray;

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    iput-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 45
    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x4 -> :sswitch_3
        0x15 -> :sswitch_2
        0x16 -> :sswitch_1
        0x18 -> :sswitch_0
    .end sparse-switch
.end method

.method public constructor <init>(II)V
    .locals 1

    const/16 v0, 0x13

    iput v0, p0, LA5/e;->a:I

    .line 70
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 71
    filled-new-array {p1, p2}, [I

    move-result-object p1

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    .line 72
    new-array p1, p1, [F

    fill-array-data p1, :array_0

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public constructor <init>(III)V
    .locals 1

    const/16 v0, 0x13

    iput v0, p0, LA5/e;->a:I

    .line 73
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 74
    filled-new-array {p1, p2, p3}, [I

    move-result-object p1

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    const/4 p1, 0x3

    .line 75
    new-array p1, p1, [F

    fill-array-data p1, :array_0

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f000000    # 0.5f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public constructor <init>(ILK1/g;)V
    .locals 1

    const/16 v0, 0x1d

    iput v0, p0, LA5/e;->a:I

    .line 54
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 55
    iput-object p2, p0, LA5/e;->b:Ljava/lang/Object;

    .line 56
    new-instance p2, LK1/e;

    invoke-direct {p2, p1, p0}, LK1/e;-><init>(ILA5/e;)V

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LA5/f;Lt5/d;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LA5/e;->a:I

    .line 63
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LG0/E0;)V
    .locals 1

    const/16 v0, 0x17

    iput v0, p0, LA5/e;->a:I

    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 58
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 59
    new-instance p1, LG0/D0;

    .line 60
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 61
    iput v0, p1, LG0/D0;->a:I

    .line 62
    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LH0/q;LR0/b;)V
    .locals 1

    const/16 v0, 0x19

    iput v0, p0, LA5/e;->a:I

    .line 51
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 52
    const-string v0, "actual"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LH0/v;)V
    .locals 1

    const/16 p1, 0x1a

    iput p1, p0, LA5/e;->a:I

    .line 48
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 49
    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 50
    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, LA5/e;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, LB3/z;->h(Ljava/lang/Object;)V

    .line 3
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    const v0, 0x7f140068

    .line 4
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getResourcePackageName(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LA5/e;->a:I

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    .line 6
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p2, p0, LA5/e;->a:I

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p3, p0, LA5/e;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    const/16 v0, 0x1b

    iput v0, p0, LA5/e;->a:I

    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 47
    const-string v0, ".lck"

    invoke-virtual {p1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .locals 4

    const/16 v0, 0x13

    iput v0, p0, LA5/e;->a:I

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 65
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    .line 66
    new-array v1, v0, [I

    iput-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 67
    new-array v1, v0, [F

    iput-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    .line 68
    iget-object v2, p0, LA5/e;->b:Ljava/lang/Object;

    check-cast v2, [I

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    aput v3, v2, v1

    .line 69
    iget-object v2, p0, LA5/e;->c:Ljava/lang/Object;

    check-cast v2, [F

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Float;

    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public constructor <init>(Lt6/J;Ld2/b;)V
    .locals 1

    const/16 v0, 0x8

    iput v0, p0, LA5/e;->a:I

    const-string v0, "movieRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/J;Ld5/k;)V
    .locals 1

    const/4 v0, 0x7

    iput v0, p0, LA5/e;->a:I

    const-string v0, "movieRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/J;Ld5/k;B)V
    .locals 0

    const/16 p3, 0x9

    iput p3, p0, LA5/e;->a:I

    const-string p3, "movieRepository"

    invoke-static {p1, p3}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/J;Lt6/s0;)V
    .locals 1

    const/16 v0, 0x11

    iput v0, p0, LA5/e;->a:I

    const-string v0, "userRepository"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "movieRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/J;Lx6/n;)V
    .locals 1

    const/16 v0, 0xa

    iput v0, p0, LA5/e;->a:I

    const-string v0, "movieRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "pageDataMapper"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 22
    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/U;Ld2/b;)V
    .locals 1

    const/16 v0, 0xb

    iput v0, p0, LA5/e;->a:I

    const-string v0, "settingRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/U;Ls5/l;)V
    .locals 1

    const/16 v0, 0xc

    iput v0, p0, LA5/e;->a:I

    const-string v0, "settingRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/d0;Ld5/k;)V
    .locals 1

    const/16 v0, 0xe

    iput v0, p0, LA5/e;->a:I

    const-string v0, "traktRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 13
    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/s0;Ld2/b;)V
    .locals 1

    const/16 v0, 0x12

    iput v0, p0, LA5/e;->a:I

    const-string v0, "userRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/s0;Lx6/m;)V
    .locals 1

    const/16 v0, 0xd

    iput v0, p0, LA5/e;->a:I

    const-string v0, "userRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "movieMapper"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 17
    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/s0;Lx6/n;)V
    .locals 1

    const/16 v0, 0x10

    iput v0, p0, LA5/e;->a:I

    const-string v0, "userRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "moviePageMapper"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/s0;Lx6/r;)V
    .locals 1

    const/16 v0, 0xf

    iput v0, p0, LA5/e;->a:I

    const-string v0, "userRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    iput-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>([LB5/a;)V
    .locals 1

    const/4 v0, 0x5

    iput v0, p0, LA5/e;->a:I

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 28
    new-instance p1, LC4/e;

    const/4 v0, 0x3

    .line 29
    invoke-direct {p1, v0}, LC4/e;-><init>(I)V

    .line 30
    iput-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public static l(II)I
    .locals 5

    .line 1
    const/4 v0, 0x0

    .line 2
    move v1, v0

    .line 3
    move v2, v1

    .line 4
    move v3, v2

    .line 5
    :goto_0
    const/4 v4, 0x1

    .line 6
    if-ge v1, p0, :cond_2

    .line 7
    .line 8
    add-int/lit8 v2, v2, 0x1

    .line 9
    .line 10
    if-ne v2, p1, :cond_0

    .line 11
    .line 12
    add-int/lit8 v3, v3, 0x1

    .line 13
    .line 14
    move v2, v0

    .line 15
    goto :goto_1

    .line 16
    :cond_0
    if-le v2, p1, :cond_1

    .line 17
    .line 18
    add-int/lit8 v3, v3, 0x1

    .line 19
    .line 20
    move v2, v4

    .line 21
    :cond_1
    :goto_1
    add-int/lit8 v1, v1, 0x1

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_2
    add-int/2addr v2, v4

    .line 25
    if-le v2, p1, :cond_3

    .line 26
    .line 27
    add-int/2addr v3, v4

    .line 28
    :cond_3
    return v3
.end method


# virtual methods
.method public A()V
    .locals 5

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    iget-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/nio/channels/FileChannel;

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    goto :goto_1

    .line 12
    :cond_0
    :try_start_0
    new-instance v1, Ljava/io/File;

    .line 13
    .line 14
    invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v1}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    if-eqz v2, :cond_1

    .line 22
    .line 23
    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :catchall_0
    move-exception v1

    .line 28
    goto :goto_2

    .line 29
    :cond_1
    :goto_0
    new-instance v2, Ljava/io/FileOutputStream;

    .line 30
    .line 31
    invoke-direct {v2, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v2}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    iput-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 39
    .line 40
    if-eqz v1, :cond_2

    .line 41
    .line 42
    invoke-virtual {v1}, Ljava/nio/channels/FileChannel;->lock()Ljava/nio/channels/FileLock;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    .line 44
    .line 45
    :cond_2
    :goto_1
    return-void

    .line 46
    :goto_2
    iget-object v2, p0, LA5/e;->c:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v2, Ljava/nio/channels/FileChannel;

    .line 49
    .line 50
    if-eqz v2, :cond_3

    .line 51
    .line 52
    invoke-virtual {v2}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V

    .line 53
    .line 54
    .line 55
    :cond_3
    const/4 v2, 0x0

    .line 56
    iput-object v2, p0, LA5/e;->c:Ljava/lang/Object;

    .line 57
    .line 58
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 59
    .line 60
    const-string v3, "Unable to lock file: \'"

    .line 61
    .line 62
    const-string v4, "\'."

    .line 63
    .line 64
    invoke-static {v3, v0, v4}, LB0/a;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-direct {v2, v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 69
    .line 70
    .line 71
    throw v2
.end method

.method public B(II)V
    .locals 3

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [I

    .line 4
    .line 5
    if-eqz v0, :cond_3

    .line 6
    .line 7
    array-length v0, v0

    .line 8
    if-lt p1, v0, :cond_0

    .line 9
    .line 10
    goto :goto_2

    .line 11
    :cond_0
    add-int v0, p1, p2

    .line 12
    .line 13
    invoke-virtual {p0, v0}, LA5/e;->i(I)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v1, [I

    .line 19
    .line 20
    array-length v2, v1

    .line 21
    sub-int/2addr v2, p1

    .line 22
    sub-int/2addr v2, p2

    .line 23
    invoke-static {v1, p1, v1, v0, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, [I

    .line 29
    .line 30
    const/4 v2, -0x1

    .line 31
    invoke-static {v1, p1, v0, v2}, Ljava/util/Arrays;->fill([IIII)V

    .line 32
    .line 33
    .line 34
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v0, Ljava/util/ArrayList;

    .line 37
    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    goto :goto_2

    .line 41
    :cond_1
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    add-int/lit8 v0, v0, -0x1

    .line 46
    .line 47
    :goto_0
    if-ltz v0, :cond_3

    .line 48
    .line 49
    iget-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v1, Ljava/util/ArrayList;

    .line 52
    .line 53
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    check-cast v1, LG0/A0;

    .line 58
    .line 59
    iget v2, v1, LG0/A0;->a:I

    .line 60
    .line 61
    if-ge v2, p1, :cond_2

    .line 62
    .line 63
    goto :goto_1

    .line 64
    :cond_2
    add-int/2addr v2, p2

    .line 65
    iput v2, v1, LG0/A0;->a:I

    .line 66
    .line 67
    :goto_1
    add-int/lit8 v0, v0, -0x1

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_3
    :goto_2
    return-void
.end method

.method public C(II)V
    .locals 5

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [I

    .line 4
    .line 5
    if-eqz v0, :cond_4

    .line 6
    .line 7
    array-length v0, v0

    .line 8
    if-lt p1, v0, :cond_0

    .line 9
    .line 10
    goto :goto_2

    .line 11
    :cond_0
    add-int v0, p1, p2

    .line 12
    .line 13
    invoke-virtual {p0, v0}, LA5/e;->i(I)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v1, [I

    .line 19
    .line 20
    array-length v2, v1

    .line 21
    sub-int/2addr v2, p1

    .line 22
    sub-int/2addr v2, p2

    .line 23
    invoke-static {v1, v0, v1, p1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 24
    .line 25
    .line 26
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, [I

    .line 29
    .line 30
    array-length v2, v1

    .line 31
    sub-int/2addr v2, p2

    .line 32
    array-length v3, v1

    .line 33
    const/4 v4, -0x1

    .line 34
    invoke-static {v1, v2, v3, v4}, Ljava/util/Arrays;->fill([IIII)V

    .line 35
    .line 36
    .line 37
    iget-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v1, Ljava/util/ArrayList;

    .line 40
    .line 41
    if-nez v1, :cond_1

    .line 42
    .line 43
    goto :goto_2

    .line 44
    :cond_1
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    add-int/lit8 v1, v1, -0x1

    .line 49
    .line 50
    :goto_0
    if-ltz v1, :cond_4

    .line 51
    .line 52
    iget-object v2, p0, LA5/e;->c:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v2, Ljava/util/ArrayList;

    .line 55
    .line 56
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    check-cast v2, LG0/A0;

    .line 61
    .line 62
    iget v3, v2, LG0/A0;->a:I

    .line 63
    .line 64
    if-ge v3, p1, :cond_2

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :cond_2
    if-ge v3, v0, :cond_3

    .line 68
    .line 69
    iget-object v2, p0, LA5/e;->c:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v2, Ljava/util/ArrayList;

    .line 72
    .line 73
    invoke-interface {v2, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_3
    sub-int/2addr v3, p2

    .line 78
    iput v3, v2, LG0/A0;->a:I

    .line 79
    .line 80
    :goto_1
    add-int/lit8 v1, v1, -0x1

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_4
    :goto_2
    return-void
.end method

.method public D(LG0/u0;I)LG0/b0;
    .locals 5

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lr/i;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lr/i;->d(Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    const/4 v1, 0x0

    .line 10
    if-gez p1, :cond_0

    .line 11
    .line 12
    goto :goto_1

    .line 13
    :cond_0
    invoke-virtual {v0, p1}, Lr/i;->i(I)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, LG0/F0;

    .line 18
    .line 19
    if-eqz v2, :cond_4

    .line 20
    .line 21
    iget v3, v2, LG0/F0;->a:I

    .line 22
    .line 23
    and-int v4, v3, p2

    .line 24
    .line 25
    if-eqz v4, :cond_4

    .line 26
    .line 27
    not-int v4, p2

    .line 28
    and-int/2addr v3, v4

    .line 29
    iput v3, v2, LG0/F0;->a:I

    .line 30
    .line 31
    const/4 v4, 0x4

    .line 32
    if-ne p2, v4, :cond_1

    .line 33
    .line 34
    iget-object p2, v2, LG0/F0;->b:LG0/b0;

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    const/16 v4, 0x8

    .line 38
    .line 39
    if-ne p2, v4, :cond_3

    .line 40
    .line 41
    iget-object p2, v2, LG0/F0;->c:LG0/b0;

    .line 42
    .line 43
    :goto_0
    and-int/lit8 v3, v3, 0xc

    .line 44
    .line 45
    if-nez v3, :cond_2

    .line 46
    .line 47
    invoke-virtual {v0, p1}, Lr/i;->g(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    const/4 p1, 0x0

    .line 51
    iput p1, v2, LG0/F0;->a:I

    .line 52
    .line 53
    iput-object v1, v2, LG0/F0;->b:LG0/b0;

    .line 54
    .line 55
    iput-object v1, v2, LG0/F0;->c:LG0/b0;

    .line 56
    .line 57
    sget-object p1, LG0/F0;->d:LO/c;

    .line 58
    .line 59
    invoke-virtual {p1, v2}, LO/c;->c(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    :cond_2
    return-object p2

    .line 63
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 64
    .line 65
    const-string p2, "Must provide flag PRE or POST"

    .line 66
    .line 67
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    throw p1

    .line 71
    :cond_4
    :goto_1
    return-object v1
.end method

.method public E(LG0/u0;)V
    .locals 1

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lr/i;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lr/i;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LG0/F0;

    .line 10
    .line 11
    if-nez p1, :cond_0

    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    iget v0, p1, LG0/F0;->a:I

    .line 15
    .line 16
    and-int/lit8 v0, v0, -0x2

    .line 17
    .line 18
    iput v0, p1, LG0/F0;->a:I

    .line 19
    .line 20
    return-void
.end method

.method public F(LG0/u0;)V
    .locals 6

    .line 1
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lr/g;

    .line 4
    .line 5
    invoke-virtual {v0}, Lr/g;->l()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x1

    .line 10
    sub-int/2addr v1, v2

    .line 11
    :goto_0
    if-ltz v1, :cond_1

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Lr/g;->m(I)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    if-ne p1, v3, :cond_0

    .line 18
    .line 19
    iget-object v3, v0, Lr/g;->c:[Ljava/lang/Object;

    .line 20
    .line 21
    aget-object v4, v3, v1

    .line 22
    .line 23
    sget-object v5, Lr/h;->a:Ljava/lang/Object;

    .line 24
    .line 25
    if-eq v4, v5, :cond_1

    .line 26
    .line 27
    aput-object v5, v3, v1

    .line 28
    .line 29
    iput-boolean v2, v0, Lr/g;->a:Z

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_0
    add-int/lit8 v1, v1, -0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    :goto_1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v0, Lr/i;

    .line 38
    .line 39
    invoke-virtual {v0, p1}, Lr/i;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    check-cast p1, LG0/F0;

    .line 44
    .line 45
    if-eqz p1, :cond_2

    .line 46
    .line 47
    const/4 v0, 0x0

    .line 48
    iput v0, p1, LG0/F0;->a:I

    .line 49
    .line 50
    const/4 v0, 0x0

    .line 51
    iput-object v0, p1, LG0/F0;->b:LG0/b0;

    .line 52
    .line 53
    iput-object v0, p1, LG0/F0;->c:LG0/b0;

    .line 54
    .line 55
    sget-object v0, LG0/F0;->d:LO/c;

    .line 56
    .line 57
    invoke-virtual {v0, p1}, LO/c;->c(Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    :cond_2
    return-void
.end method

.method public G()V
    .locals 2

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 14
    .line 15
    .line 16
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 17
    if-ltz v0, :cond_0

    .line 18
    .line 19
    monitor-exit p0

    .line 20
    return-void

    .line 21
    :cond_0
    :try_start_1
    const-string v0, "Unbalanced call to unblock() detected."

    .line 22
    .line 23
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 24
    .line 25
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 29
    :catchall_0
    move-exception v0

    .line 30
    monitor-exit p0

    .line 31
    throw v0
.end method

.method public H(Ljava/lang/Integer;Lj8/c;)Ljava/io/Serializable;
    .locals 4

    .line 1
    instance-of v0, p2, LE6/g;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, LE6/g;

    .line 7
    .line 8
    iget v1, v0, LE6/g;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LE6/g;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LE6/g;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, LE6/g;-><init>(LA5/e;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, LE6/g;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LE6/g;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p2, p0, LA5/e;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p2, Lt6/d0;

    .line 52
    .line 53
    iput v2, v0, LE6/g;->t:I

    .line 54
    .line 55
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    sget-object v1, Lv6/b;->a:LP7/x;

    .line 59
    .line 60
    new-instance v1, Lt6/c0;

    .line 61
    .line 62
    const/4 v2, 0x0

    .line 63
    invoke-direct {v1, p1, p2, v2}, Lt6/c0;-><init>(Ljava/lang/Integer;Lt6/d0;Lh8/d;)V

    .line 64
    .line 65
    .line 66
    invoke-static {v1, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p2

    .line 70
    sget-object p1, Li8/a;->a:Li8/a;

    .line 71
    .line 72
    if-ne p2, p1, :cond_3

    .line 73
    .line 74
    return-object p1

    .line 75
    :cond_3
    :goto_1
    check-cast p2, Lk6/c;

    .line 76
    .line 77
    instance-of p1, p2, Lk6/b;

    .line 78
    .line 79
    if-eqz p1, :cond_4

    .line 80
    .line 81
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast p1, Ld5/k;

    .line 84
    .line 85
    check-cast p2, Lk6/b;

    .line 86
    .line 87
    iget-object p2, p2, Lk6/b;->a:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast p2, Ljava/util/List;

    .line 90
    .line 91
    invoke-static {p1, p2}, Lr6/a;->a(Lx6/l;Ljava/util/List;)Ljava/util/List;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    check-cast p1, Ljava/io/Serializable;

    .line 96
    .line 97
    return-object p1

    .line 98
    :cond_4
    instance-of p1, p2, Lk6/a;

    .line 99
    .line 100
    if-eqz p1, :cond_5

    .line 101
    .line 102
    check-cast p2, Lk6/a;

    .line 103
    .line 104
    iget-object p1, p2, Lk6/a;->a:Ljava/lang/Throwable;

    .line 105
    .line 106
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    return-object p1

    .line 111
    :cond_5
    new-instance p1, LB8/s;

    .line 112
    .line 113
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 114
    .line 115
    .line 116
    throw p1
.end method

.method public M(Landroid/net/Uri;Lg3/o;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lg3/P;

    .line 4
    .line 5
    invoke-interface {v0, p1, p2}, Lg3/P;->M(Landroid/net/Uri;Lg3/o;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LI2/a;

    .line 10
    .line 11
    iget-object p2, p0, LA5/e;->c:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p2, Ljava/util/List;

    .line 14
    .line 15
    if-eqz p2, :cond_1

    .line 16
    .line 17
    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-interface {p1, p2}, LI2/a;->a(Ljava/util/List;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    check-cast p1, LI2/a;

    .line 29
    .line 30
    :cond_1
    :goto_0
    return-object p1
.end method

.method public a(Ljava/lang/String;)LR0/a;
    .locals 8

    .line 1
    const-string v0, "fileName"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LH0/q;

    .line 9
    .line 10
    const-string v1, ":memory:"

    .line 11
    .line 12
    invoke-virtual {p1, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-nez v2, :cond_0

    .line 17
    .line 18
    iget-object v2, v0, LH0/q;->c:LH0/a;

    .line 19
    .line 20
    iget-object v2, v2, LH0/a;->a:Landroid/content/Context;

    .line 21
    .line 22
    invoke-virtual {v2, p1}, Landroid/content/Context;->getDatabasePath(Ljava/lang/String;)Ljava/io/File;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-static {p1}, Lkotlin/jvm/internal/h;->b(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_0
    new-instance v2, LI0/a;

    .line 34
    .line 35
    iget-boolean v3, v0, LH0/q;->a:Z

    .line 36
    .line 37
    const/4 v4, 0x1

    .line 38
    const/4 v5, 0x0

    .line 39
    if-nez v3, :cond_1

    .line 40
    .line 41
    iget-boolean v3, v0, LH0/q;->b:Z

    .line 42
    .line 43
    if-nez v3, :cond_1

    .line 44
    .line 45
    invoke-virtual {p1, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v1

    .line 49
    if-nez v1, :cond_1

    .line 50
    .line 51
    move v1, v4

    .line 52
    goto :goto_0

    .line 53
    :cond_1
    move v1, v5

    .line 54
    :goto_0
    invoke-direct {v2, p1, v1}, LI0/a;-><init>(Ljava/lang/String;Z)V

    .line 55
    .line 56
    .line 57
    iget-object v1, v2, LI0/a;->a:Ljava/util/concurrent/locks/ReentrantLock;

    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 60
    .line 61
    .line 62
    iget-object v2, v2, LI0/a;->b:LA5/e;

    .line 63
    .line 64
    if-eqz v2, :cond_2

    .line 65
    .line 66
    :try_start_0
    invoke-virtual {v2}, LA5/e;->A()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 67
    .line 68
    .line 69
    goto :goto_1

    .line 70
    :catchall_0
    move-exception v0

    .line 71
    move v4, v5

    .line 72
    goto/16 :goto_6

    .line 73
    .line 74
    :cond_2
    :goto_1
    const/4 v3, 0x0

    .line 75
    :try_start_1
    iget-boolean v6, v0, LH0/q;->b:Z

    .line 76
    .line 77
    if-nez v6, :cond_7

    .line 78
    .line 79
    iget-object v6, p0, LA5/e;->b:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v6, LR0/b;

    .line 82
    .line 83
    invoke-interface {v6, p1}, LR0/b;->a(Ljava/lang/String;)LR0/a;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    iget-boolean v7, v0, LH0/q;->a:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    .line 88
    .line 89
    if-nez v7, :cond_3

    .line 90
    .line 91
    :try_start_2
    iput-boolean v4, v0, LH0/q;->b:Z

    .line 92
    .line 93
    invoke-static {v0, v6}, LH0/q;->a(LH0/q;LR0/a;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 94
    .line 95
    .line 96
    :try_start_3
    iput-boolean v5, v0, LH0/q;->b:Z

    .line 97
    .line 98
    goto :goto_3

    .line 99
    :catchall_1
    move-exception v6

    .line 100
    iput-boolean v5, v0, LH0/q;->b:Z

    .line 101
    .line 102
    throw v6

    .line 103
    :cond_3
    iget-object v5, v0, LH0/q;->c:LH0/a;

    .line 104
    .line 105
    iget-object v5, v5, LH0/a;->g:LH0/t;

    .line 106
    .line 107
    sget-object v7, LH0/t;->c:LH0/t;

    .line 108
    .line 109
    if-ne v5, v7, :cond_4

    .line 110
    .line 111
    const-string v5, "PRAGMA synchronous = NORMAL"

    .line 112
    .line 113
    invoke-static {v6, v5}, Lcom/google/android/gms/internal/measurement/I1;->v(LR0/a;Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_4
    const-string v5, "PRAGMA synchronous = FULL"

    .line 118
    .line 119
    invoke-static {v6, v5}, Lcom/google/android/gms/internal/measurement/I1;->v(LR0/a;Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    :goto_2
    invoke-static {v6}, LH0/q;->b(LR0/a;)V

    .line 123
    .line 124
    .line 125
    iget-object v0, v0, LH0/q;->d:LG0/N;

    .line 126
    .line 127
    invoke-virtual {v0, v6}, LG0/N;->t(LR0/a;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 128
    .line 129
    .line 130
    :goto_3
    if-eqz v2, :cond_6

    .line 131
    .line 132
    :try_start_4
    iget-object v0, v2, LA5/e;->c:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v0, Ljava/nio/channels/FileChannel;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    .line 135
    .line 136
    if-nez v0, :cond_5

    .line 137
    .line 138
    goto :goto_4

    .line 139
    :cond_5
    :try_start_5
    invoke-virtual {v0}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 140
    .line 141
    .line 142
    :try_start_6
    iput-object v3, v2, LA5/e;->c:Ljava/lang/Object;

    .line 143
    .line 144
    goto :goto_4

    .line 145
    :catchall_2
    move-exception v0

    .line 146
    iput-object v3, v2, LA5/e;->c:Ljava/lang/Object;

    .line 147
    .line 148
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_5

    .line 149
    :cond_6
    :goto_4
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 150
    .line 151
    .line 152
    return-object v6

    .line 153
    :cond_7
    :try_start_7
    const-string v0, "Recursive database initialization detected. Did you try to use the database instance during initialization? Maybe in one of the callbacks?"

    .line 154
    .line 155
    new-instance v5, Ljava/lang/IllegalStateException;

    .line 156
    .line 157
    invoke-direct {v5, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    throw v5
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    .line 161
    :catchall_3
    move-exception v0

    .line 162
    if-eqz v2, :cond_9

    .line 163
    .line 164
    :try_start_8
    iget-object v5, v2, LA5/e;->c:Ljava/lang/Object;

    .line 165
    .line 166
    check-cast v5, Ljava/nio/channels/FileChannel;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    .line 167
    .line 168
    if-nez v5, :cond_8

    .line 169
    .line 170
    goto :goto_5

    .line 171
    :cond_8
    :try_start_9
    invoke-virtual {v5}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    .line 172
    .line 173
    .line 174
    :try_start_a
    iput-object v3, v2, LA5/e;->c:Ljava/lang/Object;

    .line 175
    .line 176
    goto :goto_5

    .line 177
    :catchall_4
    move-exception v0

    .line 178
    iput-object v3, v2, LA5/e;->c:Ljava/lang/Object;

    .line 179
    .line 180
    throw v0

    .line 181
    :cond_9
    :goto_5
    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_5

    .line 182
    :catchall_5
    move-exception v0

    .line 183
    :goto_6
    if-eqz v4, :cond_a

    .line 184
    .line 185
    :try_start_b
    throw v0

    .line 186
    :catchall_6
    move-exception p1

    .line 187
    goto :goto_7

    .line 188
    :cond_a
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 189
    .line 190
    new-instance v3, Ljava/lang/StringBuilder;

    .line 191
    .line 192
    const-string v4, "Unable to open database \'"

    .line 193
    .line 194
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 198
    .line 199
    .line 200
    const-string p1, "\'. Was a proper path / name used in Room\'s database builder?"

    .line 201
    .line 202
    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 203
    .line 204
    .line 205
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object p1

    .line 209
    invoke-direct {v2, p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 210
    .line 211
    .line 212
    throw v2
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_6

    .line 213
    :goto_7
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 214
    .line 215
    .line 216
    throw p1
.end method

.method public b(LK1/a;Landroid/graphics/Bitmap;Ljava/util/Map;)V
    .locals 3

    .line 1
    invoke-static {p2}, Lcom/google/android/gms/internal/measurement/e2;->i(Landroid/graphics/Bitmap;)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LK1/e;

    .line 8
    .line 9
    iget-object v2, v1, LG0/C0;->g:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Ld2/b;

    .line 12
    .line 13
    monitor-enter v2

    .line 14
    :try_start_0
    iget v1, v1, LG0/C0;->b:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 15
    .line 16
    monitor-exit v2

    .line 17
    if-gt v0, v1, :cond_0

    .line 18
    .line 19
    iget-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v1, LK1/e;

    .line 22
    .line 23
    new-instance v2, LK1/d;

    .line 24
    .line 25
    invoke-direct {v2, p2, p3, v0}, LK1/d;-><init>(Landroid/graphics/Bitmap;Ljava/util/Map;I)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1, p1, v2}, LG0/C0;->l(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :cond_0
    iget-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v1, LK1/e;

    .line 35
    .line 36
    invoke-virtual {v1, p1}, LG0/C0;->m(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast v1, LK1/g;

    .line 42
    .line 43
    invoke-virtual {v1, p1, p2, p3, v0}, LK1/g;->o(LK1/a;Landroid/graphics/Bitmap;Ljava/util/Map;I)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :catchall_0
    move-exception p1

    .line 48
    monitor-exit v2

    .line 49
    throw p1
.end method

.method public c(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string p2, "="

    .line 14
    .line 15
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iget-object p2, p0, LA5/e;->b:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast p2, Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public d(LG0/u0;LG0/b0;)V
    .locals 2

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lr/i;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Lr/i;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, LG0/F0;

    .line 10
    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    invoke-static {}, LG0/F0;->a()LG0/F0;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {v0, p1, v1}, Lr/i;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    :cond_0
    iput-object p2, v1, LG0/F0;->c:LG0/b0;

    .line 21
    .line 22
    iget p1, v1, LG0/F0;->a:I

    .line 23
    .line 24
    or-int/lit8 p1, p1, 0x8

    .line 25
    .line 26
    iput p1, v1, LG0/F0;->a:I

    .line 27
    .line 28
    return-void
.end method

.method public e()Z
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 7
    .line 8
    .line 9
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    monitor-exit p0

    .line 13
    const/4 v0, 0x0

    .line 14
    return v0

    .line 15
    :cond_0
    :try_start_1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Ljava/util/concurrent/atomic/AtomicInteger;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 20
    .line 21
    .line 22
    monitor-exit p0

    .line 23
    const/4 v0, 0x1

    .line 24
    return v0

    .line 25
    :catchall_0
    move-exception v0

    .line 26
    monitor-exit p0

    .line 27
    throw v0
.end method

.method public f()V
    .locals 2

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [I

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    const/4 v1, -0x1

    .line 8
    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    .line 9
    .line 10
    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    iput-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 13
    .line 14
    return-void
.end method

.method public g(LK1/a;)LK1/b;
    .locals 2

    .line 1
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LK1/e;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LG0/C0;->h(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LK1/d;

    .line 10
    .line 11
    if-eqz p1, :cond_0

    .line 12
    .line 13
    new-instance v0, LK1/b;

    .line 14
    .line 15
    iget-object v1, p1, LK1/d;->a:Landroid/graphics/Bitmap;

    .line 16
    .line 17
    iget-object p1, p1, LK1/d;->b:Ljava/util/Map;

    .line 18
    .line 19
    invoke-direct {v0, v1, p1}, LK1/b;-><init>(Landroid/graphics/Bitmap;Ljava/util/Map;)V

    .line 20
    .line 21
    .line 22
    return-object v0

    .line 23
    :cond_0
    const/4 p1, 0x0

    .line 24
    return-object p1
.end method

.method public h(LB2/a;)[B
    .locals 4

    .line 1
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/io/DataOutputStream;

    .line 4
    .line 5
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/io/ByteArrayOutputStream;

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->reset()V

    .line 10
    .line 11
    .line 12
    :try_start_0
    iget-object v2, p1, LB2/a;->a:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {v0, v2}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-virtual {v0, v2}, Ljava/io/DataOutputStream;->writeByte(I)V

    .line 19
    .line 20
    .line 21
    iget-object v3, p1, LB2/a;->b:Ljava/lang/String;

    .line 22
    .line 23
    if-eqz v3, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const-string v3, ""

    .line 27
    .line 28
    :goto_0
    invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v0, v2}, Ljava/io/DataOutputStream;->writeByte(I)V

    .line 32
    .line 33
    .line 34
    iget-wide v2, p1, LB2/a;->c:J

    .line 35
    .line 36
    invoke-virtual {v0, v2, v3}, Ljava/io/DataOutputStream;->writeLong(J)V

    .line 37
    .line 38
    .line 39
    iget-wide v2, p1, LB2/a;->d:J

    .line 40
    .line 41
    invoke-virtual {v0, v2, v3}, Ljava/io/DataOutputStream;->writeLong(J)V

    .line 42
    .line 43
    .line 44
    iget-object p1, p1, LB2/a;->e:[B

    .line 45
    .line 46
    invoke-virtual {v0, p1}, Ljava/io/OutputStream;->write([B)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/io/DataOutputStream;->flush()V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 53
    .line 54
    .line 55
    move-result-object p1
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 56
    return-object p1

    .line 57
    :catch_0
    move-exception p1

    .line 58
    new-instance v0, Ljava/lang/RuntimeException;

    .line 59
    .line 60
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 61
    .line 62
    .line 63
    throw v0
.end method

.method public i(I)V
    .locals 4

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [I

    .line 4
    .line 5
    const/4 v1, -0x1

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    const/16 v0, 0xa

    .line 9
    .line 10
    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    add-int/lit8 p1, p1, 0x1

    .line 15
    .line 16
    new-array p1, p1, [I

    .line 17
    .line 18
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 19
    .line 20
    invoke-static {p1, v1}, Ljava/util/Arrays;->fill([II)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    array-length v2, v0

    .line 25
    if-lt p1, v2, :cond_2

    .line 26
    .line 27
    array-length v2, v0

    .line 28
    :goto_0
    if-gt v2, p1, :cond_1

    .line 29
    .line 30
    mul-int/lit8 v2, v2, 0x2

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    new-array p1, v2, [I

    .line 34
    .line 35
    iput-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 36
    .line 37
    array-length v2, v0

    .line 38
    const/4 v3, 0x0

    .line 39
    invoke-static {v0, v3, p1, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 40
    .line 41
    .line 42
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast p1, [I

    .line 45
    .line 46
    array-length v0, v0

    .line 47
    array-length v2, p1

    .line 48
    invoke-static {p1, v0, v2, v1}, Ljava/util/Arrays;->fill([IIII)V

    .line 49
    .line 50
    .line 51
    :cond_2
    return-void
.end method

.method public j(Lj8/c;)Ljava/io/Serializable;
    .locals 4

    .line 1
    instance-of v0, p1, LE6/e;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, LE6/e;

    .line 7
    .line 8
    iget v1, v0, LE6/e;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LE6/e;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LE6/e;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, LE6/e;-><init>(LA5/e;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, LE6/e;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LE6/e;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p1, Lt6/d0;

    .line 52
    .line 53
    iput v2, v0, LE6/e;->t:I

    .line 54
    .line 55
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    sget-object v1, Lv6/b;->a:LP7/x;

    .line 59
    .line 60
    new-instance v1, Lt6/W;

    .line 61
    .line 62
    const/4 v2, 0x0

    .line 63
    invoke-direct {v1, p1, v2}, Lt6/W;-><init>(Lt6/d0;Lh8/d;)V

    .line 64
    .line 65
    .line 66
    invoke-static {v1, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    sget-object v0, Li8/a;->a:Li8/a;

    .line 71
    .line 72
    if-ne p1, v0, :cond_3

    .line 73
    .line 74
    return-object v0

    .line 75
    :cond_3
    :goto_1
    check-cast p1, Lk6/c;

    .line 76
    .line 77
    instance-of v0, p1, Lk6/b;

    .line 78
    .line 79
    if-eqz v0, :cond_4

    .line 80
    .line 81
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v0, Ld5/k;

    .line 84
    .line 85
    check-cast p1, Lk6/b;

    .line 86
    .line 87
    iget-object p1, p1, Lk6/b;->a:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast p1, Ljava/util/List;

    .line 90
    .line 91
    invoke-static {v0, p1}, Lr6/a;->a(Lx6/l;Ljava/util/List;)Ljava/util/List;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    check-cast p1, Ljava/io/Serializable;

    .line 96
    .line 97
    return-object p1

    .line 98
    :cond_4
    instance-of v0, p1, Lk6/a;

    .line 99
    .line 100
    if-eqz v0, :cond_5

    .line 101
    .line 102
    check-cast p1, Lk6/a;

    .line 103
    .line 104
    iget-object p1, p1, Lk6/a;->a:Ljava/lang/Throwable;

    .line 105
    .line 106
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    return-object p1

    .line 111
    :cond_5
    new-instance p1, LB8/s;

    .line 112
    .line 113
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 114
    .line 115
    .line 116
    throw p1
.end method

.method public k(IIII)Landroid/view/View;
    .locals 9

    .line 1
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LG0/D0;

    .line 4
    .line 5
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LG0/E0;

    .line 8
    .line 9
    invoke-interface {v1}, LG0/E0;->H()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    invoke-interface {v1}, LG0/E0;->m()I

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    if-le p2, p1, :cond_0

    .line 18
    .line 19
    const/4 v4, 0x1

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v4, -0x1

    .line 22
    :goto_0
    const/4 v5, 0x0

    .line 23
    :goto_1
    if-eq p1, p2, :cond_3

    .line 24
    .line 25
    invoke-interface {v1, p1}, LG0/E0;->A(I)Landroid/view/View;

    .line 26
    .line 27
    .line 28
    move-result-object v6

    .line 29
    invoke-interface {v1, v6}, LG0/E0;->o(Landroid/view/View;)I

    .line 30
    .line 31
    .line 32
    move-result v7

    .line 33
    invoke-interface {v1, v6}, LG0/E0;->J(Landroid/view/View;)I

    .line 34
    .line 35
    .line 36
    move-result v8

    .line 37
    iput v2, v0, LG0/D0;->b:I

    .line 38
    .line 39
    iput v3, v0, LG0/D0;->c:I

    .line 40
    .line 41
    iput v7, v0, LG0/D0;->d:I

    .line 42
    .line 43
    iput v8, v0, LG0/D0;->e:I

    .line 44
    .line 45
    if-eqz p3, :cond_1

    .line 46
    .line 47
    iput p3, v0, LG0/D0;->a:I

    .line 48
    .line 49
    invoke-virtual {v0}, LG0/D0;->a()Z

    .line 50
    .line 51
    .line 52
    move-result v7

    .line 53
    if-eqz v7, :cond_1

    .line 54
    .line 55
    return-object v6

    .line 56
    :cond_1
    if-eqz p4, :cond_2

    .line 57
    .line 58
    iput p4, v0, LG0/D0;->a:I

    .line 59
    .line 60
    invoke-virtual {v0}, LG0/D0;->a()Z

    .line 61
    .line 62
    .line 63
    move-result v7

    .line 64
    if-eqz v7, :cond_2

    .line 65
    .line 66
    move-object v5, v6

    .line 67
    :cond_2
    add-int/2addr p1, v4

    .line 68
    goto :goto_1

    .line 69
    :cond_3
    return-object v5
.end method

.method public m(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    .line 1
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Landroid/content/res/Resources;

    .line 8
    .line 9
    const-string v2, "string"

    .line 10
    .line 11
    invoke-virtual {v1, p1, v2, v0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    if-nez p1, :cond_0

    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    return-object p1

    .line 19
    :cond_0
    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1
.end method

.method public n([Ljava/lang/StackTraceElement;)[Ljava/lang/StackTraceElement;
    .locals 6

    .line 1
    array-length v0, p1

    .line 2
    const/16 v1, 0x400

    .line 3
    .line 4
    if-gt v0, v1, :cond_0

    .line 5
    .line 6
    return-object p1

    .line 7
    :cond_0
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, [LB5/a;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    move-object v3, p1

    .line 13
    :goto_0
    const/4 v4, 0x1

    .line 14
    if-ge v2, v4, :cond_2

    .line 15
    .line 16
    aget-object v4, v0, v2

    .line 17
    .line 18
    array-length v5, v3

    .line 19
    if-gt v5, v1, :cond_1

    .line 20
    .line 21
    goto :goto_1

    .line 22
    :cond_1
    invoke-interface {v4, p1}, LB5/a;->n([Ljava/lang/StackTraceElement;)[Ljava/lang/StackTraceElement;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    add-int/lit8 v2, v2, 0x1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_2
    :goto_1
    array-length p1, v3

    .line 30
    if-le p1, v1, :cond_3

    .line 31
    .line 32
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p1, LC4/e;

    .line 35
    .line 36
    invoke-virtual {p1, v3}, LC4/e;->n([Ljava/lang/StackTraceElement;)[Ljava/lang/StackTraceElement;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    return-object p1

    .line 41
    :cond_3
    return-object v3
.end method

.method public o(Lj8/c;)Ljava/io/Serializable;
    .locals 4

    .line 1
    instance-of v0, p1, LE6/f;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, LE6/f;

    .line 7
    .line 8
    iget v1, v0, LE6/f;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LE6/f;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LE6/f;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, LE6/f;-><init>(LA5/e;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, LE6/f;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LE6/f;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p1, Lt6/d0;

    .line 52
    .line 53
    iput v2, v0, LE6/f;->t:I

    .line 54
    .line 55
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    sget-object v1, Lv6/b;->a:LP7/x;

    .line 59
    .line 60
    new-instance v1, Lt6/X;

    .line 61
    .line 62
    const/4 v2, 0x0

    .line 63
    invoke-direct {v1, p1, v2}, Lt6/X;-><init>(Lt6/d0;Lh8/d;)V

    .line 64
    .line 65
    .line 66
    invoke-static {v1, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    sget-object v0, Li8/a;->a:Li8/a;

    .line 71
    .line 72
    if-ne p1, v0, :cond_3

    .line 73
    .line 74
    return-object v0

    .line 75
    :cond_3
    :goto_1
    check-cast p1, Lk6/c;

    .line 76
    .line 77
    instance-of v0, p1, Lk6/b;

    .line 78
    .line 79
    if-eqz v0, :cond_4

    .line 80
    .line 81
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v0, Ld5/k;

    .line 84
    .line 85
    check-cast p1, Lk6/b;

    .line 86
    .line 87
    iget-object p1, p1, Lk6/b;->a:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast p1, Ljava/util/List;

    .line 90
    .line 91
    invoke-static {v0, p1}, Lr6/a;->a(Lx6/l;Ljava/util/List;)Ljava/util/List;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    check-cast p1, Ljava/io/Serializable;

    .line 96
    .line 97
    return-object p1

    .line 98
    :cond_4
    instance-of v0, p1, Lk6/a;

    .line 99
    .line 100
    if-eqz v0, :cond_5

    .line 101
    .line 102
    check-cast p1, Lk6/a;

    .line 103
    .line 104
    iget-object p1, p1, Lk6/a;->a:Ljava/lang/Throwable;

    .line 105
    .line 106
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    return-object p1

    .line 111
    :cond_5
    new-instance p1, LB8/s;

    .line 112
    .line 113
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 114
    .line 115
    .line 116
    throw p1
.end method

.method public p()V
    .locals 1

    .line 1
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/util/SparseIntArray;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/util/SparseIntArray;->clear()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public q(LA6/a;ILj8/c;)Ljava/io/Serializable;
    .locals 7

    .line 1
    instance-of v0, p3, LC6/r;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, LC6/r;

    .line 7
    .line 8
    iget v1, v0, LC6/r;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LC6/r;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LC6/r;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, LC6/r;-><init>(LA5/e;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p3, v0, LC6/r;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LC6/r;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p3}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p3}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 50
    .line 51
    .line 52
    move-result p1

    .line 53
    const/4 p3, 0x0

    .line 54
    if-eqz p1, :cond_5

    .line 55
    .line 56
    if-eq p1, v2, :cond_4

    .line 57
    .line 58
    const/4 v1, 0x2

    .line 59
    if-ne p1, v1, :cond_3

    .line 60
    .line 61
    new-instance p1, Ljava/util/Date;

    .line 62
    .line 63
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 64
    .line 65
    .line 66
    move-result-wide v3

    .line 67
    const-wide/32 v5, 0x5265c00

    .line 68
    .line 69
    .line 70
    sub-long/2addr v3, v5

    .line 71
    invoke-direct {p1, v3, v4}, Ljava/util/Date;-><init>(J)V

    .line 72
    .line 73
    .line 74
    invoke-static {p1}, LI3/a;->L(Ljava/util/Date;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    goto :goto_1

    .line 79
    :cond_3
    new-instance p1, LB8/s;

    .line 80
    .line 81
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 82
    .line 83
    .line 84
    throw p1

    .line 85
    :cond_4
    new-instance p1, Ljava/util/Date;

    .line 86
    .line 87
    invoke-direct {p1}, Ljava/util/Date;-><init>()V

    .line 88
    .line 89
    .line 90
    invoke-static {p1}, LI3/a;->L(Ljava/util/Date;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    goto :goto_1

    .line 95
    :cond_5
    move-object p1, p3

    .line 96
    :goto_1
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v1, Lt6/J;

    .line 99
    .line 100
    iput v2, v0, LC6/r;->t:I

    .line 101
    .line 102
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 103
    .line 104
    .line 105
    sget-object v2, Lv6/b;->a:LP7/x;

    .line 106
    .line 107
    new-instance v2, Lt6/n;

    .line 108
    .line 109
    invoke-direct {v2, p1, v1, p2, p3}, Lt6/n;-><init>(Ljava/lang/String;Lt6/J;ILh8/d;)V

    .line 110
    .line 111
    .line 112
    invoke-static {v2, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object p3

    .line 116
    sget-object p1, Li8/a;->a:Li8/a;

    .line 117
    .line 118
    if-ne p3, p1, :cond_6

    .line 119
    .line 120
    return-object p1

    .line 121
    :cond_6
    :goto_2
    check-cast p3, Lk6/c;

    .line 122
    .line 123
    instance-of p1, p3, Lk6/b;

    .line 124
    .line 125
    if-eqz p1, :cond_7

    .line 126
    .line 127
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 128
    .line 129
    check-cast p1, Ld5/k;

    .line 130
    .line 131
    check-cast p3, Lk6/b;

    .line 132
    .line 133
    iget-object p2, p3, Lk6/b;->a:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast p2, Ljava/util/List;

    .line 136
    .line 137
    invoke-static {p1, p2}, Lr6/a;->a(Lx6/l;Ljava/util/List;)Ljava/util/List;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    check-cast p1, Ljava/io/Serializable;

    .line 142
    .line 143
    return-object p1

    .line 144
    :cond_7
    instance-of p1, p3, Lk6/a;

    .line 145
    .line 146
    if-eqz p1, :cond_8

    .line 147
    .line 148
    check-cast p3, Lk6/a;

    .line 149
    .line 150
    iget-object p1, p3, Lk6/a;->a:Ljava/lang/Throwable;

    .line 151
    .line 152
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    return-object p1

    .line 157
    :cond_8
    new-instance p1, LB8/s;

    .line 158
    .line 159
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 160
    .line 161
    .line 162
    throw p1
.end method

.method public r(ILjava/util/List;Lj8/c;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p3, LC6/y;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, LC6/y;

    .line 7
    .line 8
    iget v1, v0, LC6/y;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LC6/y;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LC6/y;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, LC6/y;-><init>(LA5/e;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p3, v0, LC6/y;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LC6/y;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p3}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p3}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p3, p0, LA5/e;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p3, Lt6/J;

    .line 52
    .line 53
    iput v2, v0, LC6/y;->t:I

    .line 54
    .line 55
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    sget-object v1, Lv6/b;->a:LP7/x;

    .line 59
    .line 60
    new-instance v1, Lt6/x;

    .line 61
    .line 62
    const/4 v2, 0x0

    .line 63
    invoke-direct {v1, p3, p1, p2, v2}, Lt6/x;-><init>(Lt6/J;ILjava/util/List;Lh8/d;)V

    .line 64
    .line 65
    .line 66
    invoke-static {v1, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p3

    .line 70
    sget-object p1, Li8/a;->a:Li8/a;

    .line 71
    .line 72
    if-ne p3, p1, :cond_3

    .line 73
    .line 74
    return-object p1

    .line 75
    :cond_3
    :goto_1
    check-cast p3, Lk6/c;

    .line 76
    .line 77
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast p1, Lx6/n;

    .line 80
    .line 81
    invoke-static {p3, p1}, LK3/h;->k(Lk6/c;Lx6/l;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object p1

    .line 85
    return-object p1
.end method

.method public s(JLcom/maertsno/domain/type/MediaType;Lj8/c;)Ljava/lang/Object;
    .locals 9

    .line 1
    instance-of v0, p4, LC6/t;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p4

    .line 6
    check-cast v0, LC6/t;

    .line 7
    .line 8
    iget v1, v0, LC6/t;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LC6/t;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LC6/t;

    .line 21
    .line 22
    invoke-direct {v0, p0, p4}, LC6/t;-><init>(LA5/e;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p4, v0, LC6/t;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LC6/t;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p4}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p4}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p4, p0, LA5/e;->b:Ljava/lang/Object;

    .line 50
    .line 51
    move-object v4, p4

    .line 52
    check-cast v4, Lt6/J;

    .line 53
    .line 54
    sget-object p4, Lcom/maertsno/domain/type/MediaType;->c:Lcom/maertsno/domain/type/MediaType;

    .line 55
    .line 56
    if-ne p3, p4, :cond_3

    .line 57
    .line 58
    move v7, v2

    .line 59
    goto :goto_1

    .line 60
    :cond_3
    const/4 p3, 0x2

    .line 61
    move v7, p3

    .line 62
    :goto_1
    iput v2, v0, LC6/t;->t:I

    .line 63
    .line 64
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    sget-object p3, Lv6/b;->a:LP7/x;

    .line 68
    .line 69
    new-instance v3, Lt6/s;

    .line 70
    .line 71
    const/4 v8, 0x0

    .line 72
    move-wide v5, p1

    .line 73
    invoke-direct/range {v3 .. v8}, Lt6/s;-><init>(Lt6/J;JILh8/d;)V

    .line 74
    .line 75
    .line 76
    invoke-static {v3, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p4

    .line 80
    sget-object p1, Li8/a;->a:Li8/a;

    .line 81
    .line 82
    if-ne p4, p1, :cond_4

    .line 83
    .line 84
    return-object p1

    .line 85
    :cond_4
    :goto_2
    check-cast p4, Lk6/c;

    .line 86
    .line 87
    instance-of p1, p4, Lk6/b;

    .line 88
    .line 89
    if-eqz p1, :cond_5

    .line 90
    .line 91
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast p1, Ld2/b;

    .line 94
    .line 95
    check-cast p4, Lk6/b;

    .line 96
    .line 97
    iget-object p2, p4, Lk6/b;->a:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast p2, Lcom/maertsno/data/model/response/ListSeasonResponse;

    .line 100
    .line 101
    invoke-virtual {p1, p2}, Ld2/b;->x(Lcom/maertsno/data/model/response/ListSeasonResponse;)Ly6/y;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    iget-object p1, p1, Ly6/y;->a:Ljava/util/ArrayList;

    .line 106
    .line 107
    return-object p1

    .line 108
    :cond_5
    instance-of p1, p4, Lk6/a;

    .line 109
    .line 110
    if-eqz p1, :cond_6

    .line 111
    .line 112
    check-cast p4, Lk6/a;

    .line 113
    .line 114
    iget-object p1, p4, Lk6/a;->a:Ljava/lang/Throwable;

    .line 115
    .line 116
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    return-object p1

    .line 121
    :cond_6
    new-instance p1, LB8/s;

    .line 122
    .line 123
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 124
    .line 125
    .line 126
    throw p1
.end method

.method public t(Lcom/maertsno/domain/type/MediaType;ILj8/c;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p3, LF6/h;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, LF6/h;

    .line 7
    .line 8
    iget v1, v0, LF6/h;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LF6/h;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LF6/h;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, LF6/h;-><init>(LA5/e;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p3, v0, LF6/h;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LF6/h;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p3}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p3}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p3, p0, LA5/e;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p3, Lt6/s0;

    .line 52
    .line 53
    iget-object p1, p1, Lcom/maertsno/domain/type/MediaType;->a:Ljava/lang/String;

    .line 54
    .line 55
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    const-string v3, "getDefault(...)"

    .line 60
    .line 61
    invoke-static {v1, v3}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {p1, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    const-string v1, "toLowerCase(...)"

    .line 69
    .line 70
    invoke-static {p1, v1}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    iput v2, v0, LF6/h;->t:I

    .line 74
    .line 75
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 76
    .line 77
    .line 78
    sget-object v1, Lv6/b;->a:LP7/x;

    .line 79
    .line 80
    new-instance v1, Lt6/i0;

    .line 81
    .line 82
    const/4 v2, 0x0

    .line 83
    invoke-direct {v1, p3, p1, p2, v2}, Lt6/i0;-><init>(Lt6/s0;Ljava/lang/String;ILh8/d;)V

    .line 84
    .line 85
    .line 86
    invoke-static {v1, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p3

    .line 90
    sget-object p1, Li8/a;->a:Li8/a;

    .line 91
    .line 92
    if-ne p3, p1, :cond_3

    .line 93
    .line 94
    return-object p1

    .line 95
    :cond_3
    :goto_1
    check-cast p3, Lk6/c;

    .line 96
    .line 97
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast p1, Lx6/n;

    .line 100
    .line 101
    invoke-static {p3, p1}, LK3/h;->k(Lk6/c;Lx6/l;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    .line 1
    iget v0, p0, LA5/e;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const/16 v1, 0x64

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const/16 v1, 0x7b

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v1, Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    const/4 v3, 0x0

    .line 45
    :goto_0
    if-ge v3, v2, :cond_1

    .line 46
    .line 47
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    check-cast v4, Ljava/lang/String;

    .line 52
    .line 53
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    add-int/lit8 v4, v2, -0x1

    .line 57
    .line 58
    if-ge v3, v4, :cond_0

    .line 59
    .line 60
    const-string v4, ", "

    .line 61
    .line 62
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_1
    const/16 v1, 0x7d

    .line 69
    .line 70
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    return-object v0

    .line 78
    nop

    .line 79
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method public u(Lj8/c;)Ljava/io/Serializable;
    .locals 8

    .line 1
    iget v0, p0, LA5/e;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 5
    .line 6
    sget-object v3, Li8/a;->a:Li8/a;

    .line 7
    .line 8
    const/high16 v4, -0x80000000

    .line 9
    .line 10
    const/4 v5, 0x1

    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    instance-of v0, p1, LC6/x;

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    move-object v0, p1

    .line 19
    check-cast v0, LC6/x;

    .line 20
    .line 21
    iget v6, v0, LC6/x;->t:I

    .line 22
    .line 23
    and-int v7, v6, v4

    .line 24
    .line 25
    if-eqz v7, :cond_0

    .line 26
    .line 27
    sub-int/2addr v6, v4

    .line 28
    iput v6, v0, LC6/x;->t:I

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    new-instance v0, LC6/x;

    .line 32
    .line 33
    invoke-direct {v0, p0, p1}, LC6/x;-><init>(LA5/e;Lj8/c;)V

    .line 34
    .line 35
    .line 36
    :goto_0
    iget-object p1, v0, LC6/x;->r:Ljava/lang/Object;

    .line 37
    .line 38
    iget v4, v0, LC6/x;->t:I

    .line 39
    .line 40
    if-eqz v4, :cond_2

    .line 41
    .line 42
    if-ne v4, v5, :cond_1

    .line 43
    .line 44
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    throw p1

    .line 54
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast p1, Lt6/J;

    .line 60
    .line 61
    iput v5, v0, LC6/x;->t:I

    .line 62
    .line 63
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    sget-object v2, Lv6/b;->a:LP7/x;

    .line 67
    .line 68
    new-instance v2, Lt6/y;

    .line 69
    .line 70
    invoke-direct {v2, p1, v1}, Lt6/y;-><init>(Lt6/J;Lh8/d;)V

    .line 71
    .line 72
    .line 73
    invoke-static {v2, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    if-ne p1, v3, :cond_3

    .line 78
    .line 79
    goto :goto_2

    .line 80
    :cond_3
    :goto_1
    check-cast p1, Lk6/c;

    .line 81
    .line 82
    instance-of v0, p1, Lk6/b;

    .line 83
    .line 84
    if-eqz v0, :cond_4

    .line 85
    .line 86
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v0, Ld5/k;

    .line 89
    .line 90
    check-cast p1, Lk6/b;

    .line 91
    .line 92
    iget-object p1, p1, Lk6/b;->a:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast p1, Lcom/maertsno/data/model/response/ListTopicReportResponse;

    .line 95
    .line 96
    iget-object p1, p1, Lcom/maertsno/data/model/response/ListTopicReportResponse;->a:Ljava/util/List;

    .line 97
    .line 98
    invoke-static {v0, p1}, Lr6/a;->a(Lx6/l;Ljava/util/List;)Ljava/util/List;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    move-object v3, p1

    .line 103
    check-cast v3, Ljava/io/Serializable;

    .line 104
    .line 105
    goto :goto_2

    .line 106
    :cond_4
    instance-of v0, p1, Lk6/a;

    .line 107
    .line 108
    if-eqz v0, :cond_5

    .line 109
    .line 110
    check-cast p1, Lk6/a;

    .line 111
    .line 112
    iget-object p1, p1, Lk6/a;->a:Ljava/lang/Throwable;

    .line 113
    .line 114
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    :goto_2
    return-object v3

    .line 119
    :cond_5
    new-instance p1, LB8/s;

    .line 120
    .line 121
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 122
    .line 123
    .line 124
    throw p1

    .line 125
    :pswitch_0
    instance-of v0, p1, LB6/a;

    .line 126
    .line 127
    if-eqz v0, :cond_6

    .line 128
    .line 129
    move-object v0, p1

    .line 130
    check-cast v0, LB6/a;

    .line 131
    .line 132
    iget v6, v0, LB6/a;->t:I

    .line 133
    .line 134
    and-int v7, v6, v4

    .line 135
    .line 136
    if-eqz v7, :cond_6

    .line 137
    .line 138
    sub-int/2addr v6, v4

    .line 139
    iput v6, v0, LB6/a;->t:I

    .line 140
    .line 141
    goto :goto_3

    .line 142
    :cond_6
    new-instance v0, LB6/a;

    .line 143
    .line 144
    invoke-direct {v0, p0, p1}, LB6/a;-><init>(LA5/e;Lj8/c;)V

    .line 145
    .line 146
    .line 147
    :goto_3
    iget-object p1, v0, LB6/a;->r:Ljava/lang/Object;

    .line 148
    .line 149
    iget v4, v0, LB6/a;->t:I

    .line 150
    .line 151
    if-eqz v4, :cond_8

    .line 152
    .line 153
    if-ne v4, v5, :cond_7

    .line 154
    .line 155
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    goto :goto_4

    .line 159
    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 160
    .line 161
    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    throw p1

    .line 165
    :cond_8
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 166
    .line 167
    .line 168
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 169
    .line 170
    check-cast p1, Ls5/m;

    .line 171
    .line 172
    iput v5, v0, LB6/a;->t:I

    .line 173
    .line 174
    sget-object v2, Lv6/b;->a:LP7/x;

    .line 175
    .line 176
    new-instance v2, Lt6/a;

    .line 177
    .line 178
    invoke-direct {v2, p1, v1}, Lt6/a;-><init>(Ls5/m;Lh8/d;)V

    .line 179
    .line 180
    .line 181
    invoke-static {v2, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    if-ne p1, v3, :cond_9

    .line 186
    .line 187
    goto :goto_5

    .line 188
    :cond_9
    :goto_4
    check-cast p1, Lk6/c;

    .line 189
    .line 190
    instance-of v0, p1, Lk6/b;

    .line 191
    .line 192
    if-eqz v0, :cond_a

    .line 193
    .line 194
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 195
    .line 196
    check-cast v0, Ld5/k;

    .line 197
    .line 198
    check-cast p1, Lk6/b;

    .line 199
    .line 200
    iget-object p1, p1, Lk6/b;->a:Ljava/lang/Object;

    .line 201
    .line 202
    check-cast p1, Lcom/maertsno/data/model/response/ListAvatarsResponse;

    .line 203
    .line 204
    iget-object p1, p1, Lcom/maertsno/data/model/response/ListAvatarsResponse;->a:Ljava/util/List;

    .line 205
    .line 206
    invoke-static {v0, p1}, Lr6/a;->a(Lx6/l;Ljava/util/List;)Ljava/util/List;

    .line 207
    .line 208
    .line 209
    move-result-object p1

    .line 210
    move-object v3, p1

    .line 211
    check-cast v3, Ljava/io/Serializable;

    .line 212
    .line 213
    goto :goto_5

    .line 214
    :cond_a
    instance-of v0, p1, Lk6/a;

    .line 215
    .line 216
    if-eqz v0, :cond_b

    .line 217
    .line 218
    check-cast p1, Lk6/a;

    .line 219
    .line 220
    iget-object p1, p1, Lk6/a;->a:Ljava/lang/Throwable;

    .line 221
    .line 222
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 223
    .line 224
    .line 225
    move-result-object v3

    .line 226
    :goto_5
    return-object v3

    .line 227
    :cond_b
    new-instance p1, LB8/s;

    .line 228
    .line 229
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 230
    .line 231
    .line 232
    throw p1

    .line 233
    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_0
    .end packed-switch
.end method

.method public v(Lj8/c;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget v0, p0, LA5/e;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 5
    .line 6
    sget-object v3, Li8/a;->a:Li8/a;

    .line 7
    .line 8
    const/high16 v4, -0x80000000

    .line 9
    .line 10
    const/4 v5, 0x1

    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    :pswitch_0
    instance-of v0, p1, LF6/q;

    .line 15
    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    move-object v0, p1

    .line 19
    check-cast v0, LF6/q;

    .line 20
    .line 21
    iget v6, v0, LF6/q;->t:I

    .line 22
    .line 23
    and-int v7, v6, v4

    .line 24
    .line 25
    if-eqz v7, :cond_0

    .line 26
    .line 27
    sub-int/2addr v6, v4

    .line 28
    iput v6, v0, LF6/q;->t:I

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_0
    new-instance v0, LF6/q;

    .line 32
    .line 33
    invoke-direct {v0, p0, p1}, LF6/q;-><init>(LA5/e;Lj8/c;)V

    .line 34
    .line 35
    .line 36
    :goto_0
    iget-object p1, v0, LF6/q;->r:Ljava/lang/Object;

    .line 37
    .line 38
    iget v4, v0, LF6/q;->t:I

    .line 39
    .line 40
    if-eqz v4, :cond_2

    .line 41
    .line 42
    if-ne v4, v5, :cond_1

    .line 43
    .line 44
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    goto :goto_1

    .line 48
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    throw p1

    .line 54
    :cond_2
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast p1, Lt6/s0;

    .line 60
    .line 61
    iput v5, v0, LF6/q;->t:I

    .line 62
    .line 63
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    sget-object v2, Lv6/b;->a:LP7/x;

    .line 67
    .line 68
    new-instance v2, Lt6/q0;

    .line 69
    .line 70
    invoke-direct {v2, p1, v1}, Lt6/q0;-><init>(Lt6/s0;Lh8/d;)V

    .line 71
    .line 72
    .line 73
    invoke-static {v2, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    if-ne p1, v3, :cond_3

    .line 78
    .line 79
    goto :goto_2

    .line 80
    :cond_3
    :goto_1
    check-cast p1, Lk6/c;

    .line 81
    .line 82
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast v0, Ld2/b;

    .line 85
    .line 86
    invoke-static {p1, v0}, LK3/h;->k(Lk6/c;Lx6/l;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    :goto_2
    return-object v3

    .line 91
    :pswitch_1
    instance-of v0, p1, LF6/n;

    .line 92
    .line 93
    if-eqz v0, :cond_4

    .line 94
    .line 95
    move-object v0, p1

    .line 96
    check-cast v0, LF6/n;

    .line 97
    .line 98
    iget v6, v0, LF6/n;->u:I

    .line 99
    .line 100
    and-int v7, v6, v4

    .line 101
    .line 102
    if-eqz v7, :cond_4

    .line 103
    .line 104
    sub-int/2addr v6, v4

    .line 105
    iput v6, v0, LF6/n;->u:I

    .line 106
    .line 107
    goto :goto_3

    .line 108
    :cond_4
    new-instance v0, LF6/n;

    .line 109
    .line 110
    invoke-direct {v0, p0, p1}, LF6/n;-><init>(LA5/e;Lj8/c;)V

    .line 111
    .line 112
    .line 113
    :goto_3
    iget-object p1, v0, LF6/n;->s:Ljava/lang/Object;

    .line 114
    .line 115
    iget v4, v0, LF6/n;->u:I

    .line 116
    .line 117
    const/4 v6, 0x2

    .line 118
    if-eqz v4, :cond_7

    .line 119
    .line 120
    if-eq v4, v5, :cond_6

    .line 121
    .line 122
    if-ne v4, v6, :cond_5

    .line 123
    .line 124
    iget-object v3, v0, LF6/n;->r:Ljava/lang/Object;

    .line 125
    .line 126
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    goto :goto_5

    .line 130
    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 131
    .line 132
    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    throw p1

    .line 136
    :cond_6
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    goto :goto_4

    .line 140
    :cond_7
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast p1, Lt6/s0;

    .line 146
    .line 147
    iput v5, v0, LF6/n;->u:I

    .line 148
    .line 149
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 150
    .line 151
    .line 152
    sget-object v2, Lv6/b;->a:LP7/x;

    .line 153
    .line 154
    new-instance v2, Lt6/n0;

    .line 155
    .line 156
    invoke-direct {v2, p1, v1}, Lt6/n0;-><init>(Lt6/s0;Lh8/d;)V

    .line 157
    .line 158
    .line 159
    invoke-static {v2, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    if-ne p1, v3, :cond_8

    .line 164
    .line 165
    goto :goto_5

    .line 166
    :cond_8
    :goto_4
    check-cast p1, Lk6/c;

    .line 167
    .line 168
    invoke-static {p1}, LK3/h;->i(Lk6/c;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    instance-of v2, p1, Ld8/h;

    .line 173
    .line 174
    if-nez v2, :cond_9

    .line 175
    .line 176
    iget-object v2, p0, LA5/e;->c:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v2, Lt6/J;

    .line 179
    .line 180
    iput-object p1, v0, LF6/n;->r:Ljava/lang/Object;

    .line 181
    .line 182
    iput v6, v0, LF6/n;->u:I

    .line 183
    .line 184
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 185
    .line 186
    .line 187
    sget-object v4, Lv6/b;->a:LP7/x;

    .line 188
    .line 189
    new-instance v4, Lt6/f;

    .line 190
    .line 191
    invoke-direct {v4, v2, v1}, Lt6/f;-><init>(Lt6/J;Lh8/d;)V

    .line 192
    .line 193
    .line 194
    invoke-static {v4, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v0

    .line 198
    if-ne v0, v3, :cond_9

    .line 199
    .line 200
    goto :goto_5

    .line 201
    :cond_9
    move-object v3, p1

    .line 202
    :goto_5
    return-object v3

    .line 203
    :pswitch_2
    instance-of v0, p1, LF6/g;

    .line 204
    .line 205
    if-eqz v0, :cond_a

    .line 206
    .line 207
    move-object v0, p1

    .line 208
    check-cast v0, LF6/g;

    .line 209
    .line 210
    iget v6, v0, LF6/g;->t:I

    .line 211
    .line 212
    and-int v7, v6, v4

    .line 213
    .line 214
    if-eqz v7, :cond_a

    .line 215
    .line 216
    sub-int/2addr v6, v4

    .line 217
    iput v6, v0, LF6/g;->t:I

    .line 218
    .line 219
    goto :goto_6

    .line 220
    :cond_a
    new-instance v0, LF6/g;

    .line 221
    .line 222
    invoke-direct {v0, p0, p1}, LF6/g;-><init>(LA5/e;Lj8/c;)V

    .line 223
    .line 224
    .line 225
    :goto_6
    iget-object p1, v0, LF6/g;->r:Ljava/lang/Object;

    .line 226
    .line 227
    iget v4, v0, LF6/g;->t:I

    .line 228
    .line 229
    if-eqz v4, :cond_c

    .line 230
    .line 231
    if-ne v4, v5, :cond_b

    .line 232
    .line 233
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    goto :goto_7

    .line 237
    :cond_b
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 238
    .line 239
    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 240
    .line 241
    .line 242
    throw p1

    .line 243
    :cond_c
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 244
    .line 245
    .line 246
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 247
    .line 248
    check-cast p1, Lt6/s0;

    .line 249
    .line 250
    iput v5, v0, LF6/g;->t:I

    .line 251
    .line 252
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 253
    .line 254
    .line 255
    sget-object v2, Lv6/b;->a:LP7/x;

    .line 256
    .line 257
    new-instance v2, Lt6/h0;

    .line 258
    .line 259
    invoke-direct {v2, p1, v1}, Lt6/h0;-><init>(Lt6/s0;Lh8/d;)V

    .line 260
    .line 261
    .line 262
    invoke-static {v2, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object p1

    .line 266
    if-ne p1, v3, :cond_d

    .line 267
    .line 268
    goto :goto_8

    .line 269
    :cond_d
    :goto_7
    check-cast p1, Lk6/c;

    .line 270
    .line 271
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 272
    .line 273
    check-cast v0, Lx6/r;

    .line 274
    .line 275
    invoke-static {p1, v0}, LK3/h;->k(Lk6/c;Lx6/l;)Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    move-result-object v3

    .line 279
    :goto_8
    return-object v3

    .line 280
    :pswitch_3
    instance-of v0, p1, LD6/m;

    .line 281
    .line 282
    if-eqz v0, :cond_e

    .line 283
    .line 284
    move-object v0, p1

    .line 285
    check-cast v0, LD6/m;

    .line 286
    .line 287
    iget v6, v0, LD6/m;->t:I

    .line 288
    .line 289
    and-int v7, v6, v4

    .line 290
    .line 291
    if-eqz v7, :cond_e

    .line 292
    .line 293
    sub-int/2addr v6, v4

    .line 294
    iput v6, v0, LD6/m;->t:I

    .line 295
    .line 296
    goto :goto_9

    .line 297
    :cond_e
    new-instance v0, LD6/m;

    .line 298
    .line 299
    invoke-direct {v0, p0, p1}, LD6/m;-><init>(LA5/e;Lj8/c;)V

    .line 300
    .line 301
    .line 302
    :goto_9
    iget-object p1, v0, LD6/m;->r:Ljava/lang/Object;

    .line 303
    .line 304
    iget v4, v0, LD6/m;->t:I

    .line 305
    .line 306
    if-eqz v4, :cond_10

    .line 307
    .line 308
    if-ne v4, v5, :cond_f

    .line 309
    .line 310
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 311
    .line 312
    .line 313
    goto :goto_a

    .line 314
    :cond_f
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 315
    .line 316
    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 317
    .line 318
    .line 319
    throw p1

    .line 320
    :cond_10
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 321
    .line 322
    .line 323
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 324
    .line 325
    check-cast p1, Lt6/U;

    .line 326
    .line 327
    iput v5, v0, LD6/m;->t:I

    .line 328
    .line 329
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 330
    .line 331
    .line 332
    sget-object v2, Lv6/b;->a:LP7/x;

    .line 333
    .line 334
    new-instance v2, Lt6/Q;

    .line 335
    .line 336
    invoke-direct {v2, p1, v1}, Lt6/Q;-><init>(Lt6/U;Lh8/d;)V

    .line 337
    .line 338
    .line 339
    invoke-static {v2, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 340
    .line 341
    .line 342
    move-result-object p1

    .line 343
    if-ne p1, v3, :cond_11

    .line 344
    .line 345
    goto :goto_b

    .line 346
    :cond_11
    :goto_a
    check-cast p1, Lk6/c;

    .line 347
    .line 348
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 349
    .line 350
    check-cast v0, Ls5/l;

    .line 351
    .line 352
    invoke-static {p1, v0}, LK3/h;->k(Lk6/c;Lx6/l;)Ljava/lang/Object;

    .line 353
    .line 354
    .line 355
    move-result-object v3

    .line 356
    :goto_b
    return-object v3

    .line 357
    :pswitch_4
    instance-of v0, p1, LD6/l;

    .line 358
    .line 359
    if-eqz v0, :cond_12

    .line 360
    .line 361
    move-object v0, p1

    .line 362
    check-cast v0, LD6/l;

    .line 363
    .line 364
    iget v6, v0, LD6/l;->t:I

    .line 365
    .line 366
    and-int v7, v6, v4

    .line 367
    .line 368
    if-eqz v7, :cond_12

    .line 369
    .line 370
    sub-int/2addr v6, v4

    .line 371
    iput v6, v0, LD6/l;->t:I

    .line 372
    .line 373
    goto :goto_c

    .line 374
    :cond_12
    new-instance v0, LD6/l;

    .line 375
    .line 376
    invoke-direct {v0, p0, p1}, LD6/l;-><init>(LA5/e;Lj8/c;)V

    .line 377
    .line 378
    .line 379
    :goto_c
    iget-object p1, v0, LD6/l;->r:Ljava/lang/Object;

    .line 380
    .line 381
    iget v4, v0, LD6/l;->t:I

    .line 382
    .line 383
    if-eqz v4, :cond_14

    .line 384
    .line 385
    if-ne v4, v5, :cond_13

    .line 386
    .line 387
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 388
    .line 389
    .line 390
    goto :goto_d

    .line 391
    :cond_13
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 392
    .line 393
    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 394
    .line 395
    .line 396
    throw p1

    .line 397
    :cond_14
    invoke-static {p1}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 398
    .line 399
    .line 400
    iget-object p1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 401
    .line 402
    check-cast p1, Lt6/U;

    .line 403
    .line 404
    iput v5, v0, LD6/l;->t:I

    .line 405
    .line 406
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 407
    .line 408
    .line 409
    sget-object v2, Lv6/b;->a:LP7/x;

    .line 410
    .line 411
    new-instance v2, Lt6/P;

    .line 412
    .line 413
    invoke-direct {v2, p1, v1}, Lt6/P;-><init>(Lt6/U;Lh8/d;)V

    .line 414
    .line 415
    .line 416
    invoke-static {v2, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 417
    .line 418
    .line 419
    move-result-object p1

    .line 420
    if-ne p1, v3, :cond_15

    .line 421
    .line 422
    goto :goto_e

    .line 423
    :cond_15
    :goto_d
    check-cast p1, Lk6/c;

    .line 424
    .line 425
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 426
    .line 427
    check-cast v0, Ld2/b;

    .line 428
    .line 429
    invoke-static {p1, v0}, LK3/h;->k(Lk6/c;Lx6/l;)Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v3

    .line 433
    :goto_e
    return-object v3

    .line 434
    nop

    .line 435
    :pswitch_data_0
    .packed-switch 0xb
        :pswitch_4
        :pswitch_3
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public w(Ljava/util/List;Lj8/c;)Ljava/io/Serializable;
    .locals 4

    .line 1
    instance-of v0, p2, LE6/a;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, LE6/a;

    .line 7
    .line 8
    iget v1, v0, LE6/a;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LE6/a;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LE6/a;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, LE6/a;-><init>(LA5/e;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, LE6/a;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LE6/a;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p2}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p2, p0, LA5/e;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p2, Lt6/s0;

    .line 52
    .line 53
    iput v2, v0, LE6/a;->t:I

    .line 54
    .line 55
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    sget-object v1, Lv6/b;->a:LP7/x;

    .line 59
    .line 60
    new-instance v1, Lt6/j0;

    .line 61
    .line 62
    const/4 v2, 0x0

    .line 63
    invoke-direct {v1, p2, p1, v2}, Lt6/j0;-><init>(Lt6/s0;Ljava/util/List;Lh8/d;)V

    .line 64
    .line 65
    .line 66
    invoke-static {v1, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p2

    .line 70
    sget-object p1, Li8/a;->a:Li8/a;

    .line 71
    .line 72
    if-ne p2, p1, :cond_3

    .line 73
    .line 74
    return-object p1

    .line 75
    :cond_3
    :goto_1
    check-cast p2, Lk6/c;

    .line 76
    .line 77
    instance-of p1, p2, Lk6/b;

    .line 78
    .line 79
    if-eqz p1, :cond_4

    .line 80
    .line 81
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast p1, Lx6/m;

    .line 84
    .line 85
    check-cast p2, Lk6/b;

    .line 86
    .line 87
    iget-object p2, p2, Lk6/b;->a:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast p2, Ljava/util/List;

    .line 90
    .line 91
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 92
    .line 93
    .line 94
    invoke-static {p1, p2}, Lr6/a;->a(Lx6/l;Ljava/util/List;)Ljava/util/List;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    check-cast p1, Ljava/io/Serializable;

    .line 99
    .line 100
    return-object p1

    .line 101
    :cond_4
    instance-of p1, p2, Lk6/a;

    .line 102
    .line 103
    if-eqz p1, :cond_5

    .line 104
    .line 105
    check-cast p2, Lk6/a;

    .line 106
    .line 107
    iget-object p1, p2, Lk6/a;->a:Ljava/lang/Throwable;

    .line 108
    .line 109
    invoke-static {p1}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    return-object p1

    .line 114
    :cond_5
    new-instance p1, LB8/s;

    .line 115
    .line 116
    invoke-direct {p1}, Ljava/lang/RuntimeException;-><init>()V

    .line 117
    .line 118
    .line 119
    throw p1
.end method

.method public x(Ljava/lang/Object;)Lb4/q;
    .locals 9

    .line 1
    check-cast p1, Ljava/lang/Void;

    .line 2
    .line 3
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p1, LA5/f;

    .line 6
    .line 7
    iget-object v0, p0, LA5/e;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lt5/d;

    .line 10
    .line 11
    iget-object v0, v0, Lt5/d;->c:Lt5/b;

    .line 12
    .line 13
    iget-object v0, v0, Lt5/b;->a:Ljava/util/concurrent/ExecutorService;

    .line 14
    .line 15
    new-instance v1, LA5/d;

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-direct {v1, v2, p0}, LA5/d;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-interface {v0, v1}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-interface {v0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Lorg/json/JSONObject;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    if-eqz v0, :cond_1

    .line 33
    .line 34
    iget-object v2, p1, LA5/f;->c:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v2, LA5/g;

    .line 37
    .line 38
    invoke-virtual {v2, v0}, LA5/g;->V(Lorg/json/JSONObject;)LA5/c;

    .line 39
    .line 40
    .line 41
    move-result-object v2

    .line 42
    iget-object v3, p1, LA5/f;->e:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v3, LV5/c;

    .line 45
    .line 46
    iget-wide v4, v2, LA5/c;->c:J

    .line 47
    .line 48
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    const-string v6, "Failed to close settings writer."

    .line 52
    .line 53
    const-string v7, "FirebaseCrashlytics"

    .line 54
    .line 55
    const/4 v8, 0x2

    .line 56
    invoke-static {v7, v8}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 57
    .line 58
    .line 59
    move-result v8

    .line 60
    if-eqz v8, :cond_0

    .line 61
    .line 62
    const-string v8, "Writing settings to cache file..."

    .line 63
    .line 64
    invoke-static {v7, v8, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 65
    .line 66
    .line 67
    :cond_0
    :try_start_0
    const-string v8, "expires_at"

    .line 68
    .line 69
    invoke-virtual {v0, v8, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 70
    .line 71
    .line 72
    new-instance v4, Ljava/io/FileWriter;

    .line 73
    .line 74
    iget-object v3, v3, LV5/c;->b:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast v3, Ljava/io/File;

    .line 77
    .line 78
    invoke-direct {v4, v3}, Ljava/io/FileWriter;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 79
    .line 80
    .line 81
    :try_start_1
    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    invoke-virtual {v4, v3}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v4}, Ljava/io/Writer;->flush()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 89
    .line 90
    .line 91
    :goto_0
    invoke-static {v4, v6}, Ls5/g;->b(Ljava/io/Closeable;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    goto :goto_2

    .line 95
    :catchall_0
    move-exception p1

    .line 96
    move-object v1, v4

    .line 97
    goto :goto_3

    .line 98
    :catch_0
    move-exception v3

    .line 99
    goto :goto_1

    .line 100
    :catchall_1
    move-exception p1

    .line 101
    goto :goto_3

    .line 102
    :catch_1
    move-exception v3

    .line 103
    move-object v4, v1

    .line 104
    :goto_1
    :try_start_2
    const-string v5, "Failed to cache settings"

    .line 105
    .line 106
    invoke-static {v7, v5, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 107
    .line 108
    .line 109
    goto :goto_0

    .line 110
    :goto_2
    const-string v3, "Loaded settings: "

    .line 111
    .line 112
    invoke-static {v0, v3}, LA5/f;->n(Lorg/json/JSONObject;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    iget-object v0, p1, LA5/f;->b:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast v0, LA5/i;

    .line 118
    .line 119
    iget-object v0, v0, LA5/i;->f:Ljava/lang/String;

    .line 120
    .line 121
    iget-object v3, p1, LA5/f;->a:Ljava/lang/Object;

    .line 122
    .line 123
    check-cast v3, Landroid/content/Context;

    .line 124
    .line 125
    const-string v4, "com.google.firebase.crashlytics"

    .line 126
    .line 127
    const/4 v5, 0x0

    .line 128
    invoke-virtual {v3, v4, v5}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 133
    .line 134
    .line 135
    move-result-object v3

    .line 136
    const-string v4, "existing_instance_identifier"

    .line 137
    .line 138
    invoke-interface {v3, v4, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 139
    .line 140
    .line 141
    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 142
    .line 143
    .line 144
    iget-object v0, p1, LA5/f;->h:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 147
    .line 148
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    iget-object p1, p1, LA5/f;->i:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast p1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 154
    .line 155
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    check-cast p1, Lb4/i;

    .line 160
    .line 161
    invoke-virtual {p1, v2}, Lb4/i;->d(Ljava/lang/Object;)V

    .line 162
    .line 163
    .line 164
    goto :goto_4

    .line 165
    :goto_3
    invoke-static {v1, v6}, Ls5/g;->b(Ljava/io/Closeable;Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    throw p1

    .line 169
    :cond_1
    :goto_4
    invoke-static {v1}, Lf5/b;->s(Ljava/lang/Object;)Lb4/q;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    return-object p1
.end method

.method public y(I)V
    .locals 2

    .line 1
    const/16 v0, 0x28

    .line 2
    .line 3
    if-lt p1, v0, :cond_0

    .line 4
    .line 5
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p1, LK1/e;

    .line 8
    .line 9
    const/4 v0, -0x1

    .line 10
    invoke-virtual {p1, v0}, LG0/C0;->p(I)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    const/16 v0, 0xa

    .line 15
    .line 16
    if-gt v0, p1, :cond_1

    .line 17
    .line 18
    const/16 v0, 0x14

    .line 19
    .line 20
    if-ge p1, v0, :cond_1

    .line 21
    .line 22
    iget-object p1, p0, LA5/e;->c:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast p1, LK1/e;

    .line 25
    .line 26
    iget-object v0, p1, LG0/C0;->g:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v0, Ld2/b;

    .line 29
    .line 30
    monitor-enter v0

    .line 31
    :try_start_0
    iget v1, p1, LG0/C0;->c:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 32
    .line 33
    monitor-exit v0

    .line 34
    div-int/lit8 v1, v1, 0x2

    .line 35
    .line 36
    invoke-virtual {p1, v1}, LG0/C0;->p(I)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    :catchall_0
    move-exception p1

    .line 41
    monitor-exit v0

    .line 42
    throw p1

    .line 43
    :cond_1
    return-void
.end method

.method public z(Landroid/view/View;)Z
    .locals 5

    .line 1
    iget-object v0, p0, LA5/e;->c:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LG0/D0;

    .line 4
    .line 5
    iget-object v1, p0, LA5/e;->b:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LG0/E0;

    .line 8
    .line 9
    invoke-interface {v1}, LG0/E0;->H()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    invoke-interface {v1}, LG0/E0;->m()I

    .line 14
    .line 15
    .line 16
    move-result v3

    .line 17
    invoke-interface {v1, p1}, LG0/E0;->o(Landroid/view/View;)I

    .line 18
    .line 19
    .line 20
    move-result v4

    .line 21
    invoke-interface {v1, p1}, LG0/E0;->J(Landroid/view/View;)I

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    iput v2, v0, LG0/D0;->b:I

    .line 26
    .line 27
    iput v3, v0, LG0/D0;->c:I

    .line 28
    .line 29
    iput v4, v0, LG0/D0;->d:I

    .line 30
    .line 31
    iput p1, v0, LG0/D0;->e:I

    .line 32
    .line 33
    const/16 p1, 0x6003

    .line 34
    .line 35
    iput p1, v0, LG0/D0;->a:I

    .line 36
    .line 37
    invoke-virtual {v0}, LG0/D0;->a()Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    return p1
.end method
