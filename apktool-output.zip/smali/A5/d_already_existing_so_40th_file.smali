.class public final synthetic LA5/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA5/d;->a:I

    iput-object p2, p0, LA5/d;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 12

    .line 1
    iget v0, p0, LA5/d;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ls5/s;

    .line 9
    .line 10
    iget-object v0, v0, Ls5/s;->g:Ls5/o;

    .line 11
    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    const-string v1, "FirebaseCrashlytics"

    .line 16
    .line 17
    invoke-static {}, Lt5/d;->a()V

    .line 18
    .line 19
    .line 20
    iget-object v2, v0, Ls5/o;->c:Ls5/m;

    .line 21
    .line 22
    iget-object v3, v2, Ls5/m;->c:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v3, Ly5/c;

    .line 25
    .line 26
    iget-object v4, v2, Ls5/m;->b:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v4, Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    new-instance v5, Ljava/io/File;

    .line 34
    .line 35
    iget-object v3, v3, Ly5/c;->c:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v3, Ljava/io/File;

    .line 38
    .line 39
    invoke-direct {v5, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v5}, Ljava/io/File;->exists()Z

    .line 43
    .line 44
    .line 45
    move-result v3

    .line 46
    const/4 v5, 0x1

    .line 47
    if-nez v3, :cond_1

    .line 48
    .line 49
    invoke-virtual {v0}, Ls5/o;->e()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    if-eqz v1, :cond_0

    .line 54
    .line 55
    iget-object v0, v0, Ls5/o;->j:Lp5/a;

    .line 56
    .line 57
    invoke-virtual {v0, v1}, Lp5/a;->c(Ljava/lang/String;)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_0

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_0
    const/4 v5, 0x0

    .line 65
    goto :goto_0

    .line 66
    :cond_1
    const-string v0, "Found previous crash marker."

    .line 67
    .line 68
    const/4 v3, 0x2

    .line 69
    invoke-static {v1, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 70
    .line 71
    .line 72
    move-result v3

    .line 73
    if-eqz v3, :cond_2

    .line 74
    .line 75
    const/4 v3, 0x0

    .line 76
    invoke-static {v1, v0, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 77
    .line 78
    .line 79
    :cond_2
    iget-object v0, v2, Ls5/m;->c:Ljava/lang/Object;

    .line 80
    .line 81
    check-cast v0, Ly5/c;

    .line 82
    .line 83
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    .line 85
    .line 86
    new-instance v1, Ljava/io/File;

    .line 87
    .line 88
    iget-object v0, v0, Ly5/c;->c:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v0, Ljava/io/File;

    .line 91
    .line 92
    invoke-direct {v1, v0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    .line 96
    .line 97
    .line 98
    :goto_0
    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 99
    .line 100
    .line 101
    move-result-object v0

    .line 102
    return-object v0

    .line 103
    :pswitch_0
    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    .line 104
    .line 105
    check-cast v0, LX5/p;

    .line 106
    .line 107
    monitor-enter v0

    .line 108
    const/4 v1, 0x0

    .line 109
    :try_start_0
    iget-object v2, v0, LX5/p;->a:Landroid/content/Context;

    .line 110
    .line 111
    iget-object v3, v0, LX5/p;->b:Ljava/lang/String;

    .line 112
    .line 113
    invoke-virtual {v2, v3}, Landroid/content/Context;->openFileInput(Ljava/lang/String;)Ljava/io/FileInputStream;

    .line 114
    .line 115
    .line 116
    move-result-object v2
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 117
    :try_start_1
    invoke-virtual {v2}, Ljava/io/FileInputStream;->available()I

    .line 118
    .line 119
    .line 120
    move-result v3

    .line 121
    new-array v4, v3, [B

    .line 122
    .line 123
    const/4 v5, 0x0

    .line 124
    invoke-virtual {v2, v4, v5, v3}, Ljava/io/FileInputStream;->read([BII)I

    .line 125
    .line 126
    .line 127
    new-instance v3, Ljava/lang/String;

    .line 128
    .line 129
    const-string v5, "UTF-8"

    .line 130
    .line 131
    invoke-direct {v3, v4, v5}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    .line 132
    .line 133
    .line 134
    new-instance v4, Lorg/json/JSONObject;

    .line 135
    .line 136
    invoke-direct {v4, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    invoke-static {v4}, LX5/f;->a(Lorg/json/JSONObject;)LX5/f;

    .line 140
    .line 141
    .line 142
    move-result-object v1
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 143
    :try_start_2
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 144
    .line 145
    .line 146
    monitor-exit v0

    .line 147
    goto :goto_5

    .line 148
    :catchall_0
    move-exception v1

    .line 149
    goto :goto_3

    .line 150
    :catchall_1
    move-exception v1

    .line 151
    goto :goto_1

    .line 152
    :catchall_2
    move-exception v2

    .line 153
    move-object v11, v2

    .line 154
    move-object v2, v1

    .line 155
    move-object v1, v11

    .line 156
    goto :goto_1

    .line 157
    :catch_0
    move-object v2, v1

    .line 158
    goto :goto_2

    .line 159
    :goto_1
    if-eqz v2, :cond_3

    .line 160
    .line 161
    :try_start_3
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 162
    .line 163
    .line 164
    :cond_3
    throw v1

    .line 165
    :catch_1
    :goto_2
    if-eqz v2, :cond_4

    .line 166
    .line 167
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 168
    .line 169
    .line 170
    goto :goto_4

    .line 171
    :goto_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 172
    throw v1

    .line 173
    :cond_4
    :goto_4
    monitor-exit v0

    .line 174
    :goto_5
    return-object v1

    .line 175
    :pswitch_1
    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    .line 176
    .line 177
    check-cast v0, LW5/o;

    .line 178
    .line 179
    invoke-virtual {v0}, LW5/o;->a()LW5/f;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    return-object v0

    .line 184
    :pswitch_2
    iget-object v0, p0, LA5/d;->b:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast v0, LA5/e;

    .line 187
    .line 188
    iget-object v0, v0, LA5/e;->c:Ljava/lang/Object;

    .line 189
    .line 190
    check-cast v0, LA5/f;

    .line 191
    .line 192
    iget-object v1, v0, LA5/f;->f:Ljava/lang/Object;

    .line 193
    .line 194
    check-cast v1, LA5/a;

    .line 195
    .line 196
    iget-object v0, v0, LA5/f;->b:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast v0, LA5/i;

    .line 199
    .line 200
    iget-object v2, v1, LA5/a;->a:Ljava/lang/String;

    .line 201
    .line 202
    const-string v3, "FirebaseCrashlytics"

    .line 203
    .line 204
    const-string v4, "Settings query params were: "

    .line 205
    .line 206
    const-string v5, "Requesting settings from "

    .line 207
    .line 208
    invoke-static {}, Lt5/d;->b()V

    .line 209
    .line 210
    .line 211
    const/4 v6, 0x0

    .line 212
    :try_start_4
    invoke-static {v0}, LA5/a;->b(LA5/i;)Ljava/util/HashMap;

    .line 213
    .line 214
    .line 215
    move-result-object v7

    .line 216
    new-instance v8, Lw0/h;

    .line 217
    .line 218
    invoke-direct {v8, v2, v7}, Lw0/h;-><init>(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 219
    .line 220
    .line 221
    const-string v9, "User-Agent"

    .line 222
    .line 223
    const-string v10, "Crashlytics Android SDK/19.4.4"

    .line 224
    .line 225
    invoke-virtual {v8, v9, v10}, Lw0/h;->t(Ljava/lang/String;Ljava/lang/String;)V

    .line 226
    .line 227
    .line 228
    const-string v9, "X-CRASHLYTICS-DEVELOPER-TOKEN"

    .line 229
    .line 230
    const-string v10, "470fa2b4ae81cd56ecbcda9735803434cec591fa"

    .line 231
    .line 232
    invoke-virtual {v8, v9, v10}, Lw0/h;->t(Ljava/lang/String;Ljava/lang/String;)V

    .line 233
    .line 234
    .line 235
    invoke-static {v8, v0}, LA5/a;->a(Lw0/h;LA5/i;)V

    .line 236
    .line 237
    .line 238
    new-instance v0, Ljava/lang/StringBuilder;

    .line 239
    .line 240
    invoke-direct {v0, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 244
    .line 245
    .line 246
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    const/4 v2, 0x3

    .line 251
    invoke-static {v3, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 252
    .line 253
    .line 254
    move-result v2

    .line 255
    if-eqz v2, :cond_5

    .line 256
    .line 257
    invoke-static {v3, v0, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 258
    .line 259
    .line 260
    :cond_5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 261
    .line 262
    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 266
    .line 267
    .line 268
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 269
    .line 270
    .line 271
    move-result-object v0

    .line 272
    const/4 v2, 0x2

    .line 273
    invoke-static {v3, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 274
    .line 275
    .line 276
    move-result v2

    .line 277
    if-eqz v2, :cond_6

    .line 278
    .line 279
    invoke-static {v3, v0, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 280
    .line 281
    .line 282
    :cond_6
    invoke-virtual {v8}, Lw0/h;->s()LK1/g;

    .line 283
    .line 284
    .line 285
    move-result-object v0

    .line 286
    invoke-virtual {v1, v0}, LA5/a;->c(LK1/g;)Lorg/json/JSONObject;

    .line 287
    .line 288
    .line 289
    move-result-object v6
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_2

    .line 290
    goto :goto_6

    .line 291
    :catch_2
    move-exception v0

    .line 292
    const-string v1, "Settings request failed."

    .line 293
    .line 294
    invoke-static {v3, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 295
    .line 296
    .line 297
    :goto_6
    return-object v6

    .line 298
    nop

    .line 299
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
