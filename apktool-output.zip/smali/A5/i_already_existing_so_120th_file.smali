.class public final LA5/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:Ls5/y;

.field public final f:Ljava/lang/String;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ls5/y;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LA5/i;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, LA5/i;->b:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, LA5/i;->c:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, LA5/i;->d:Ljava/lang/String;

    .line 11
    .line 12
    iput-object p5, p0, LA5/i;->e:Ls5/y;

    .line 13
    .line 14
    iput-object p6, p0, LA5/i;->f:Ljava/lang/String;

    .line 15
    .line 16
    iput-object p7, p0, LA5/i;->g:Ljava/lang/String;

    .line 17
    .line 18
    iput-object p8, p0, LA5/i;->h:Ljava/lang/String;

    .line 19
    .line 20
    iput p9, p0, LA5/i;->i:I

    .line 21
    .line 22
    return-void
.end method
