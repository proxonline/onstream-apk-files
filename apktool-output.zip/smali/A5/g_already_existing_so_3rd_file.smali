.class public final LA5/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz3/l;
.implements LP/p;
.implements LG0/L;
.implements LG0/E0;
.implements LJ2/g0;
.implements LK1/h;
.implements LM/a;
.implements LM1/e;
.implements Lg3/I;
.implements LP/f;
.implements Lg3/P;
.implements LU2/f;
.implements La9/g;
.implements La9/f;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 2

    iput p1, p0, LA5/g;->a:I

    sparse-switch p1, :sswitch_data_0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    return-void

    .line 9
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    return-void

    .line 11
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/EnumMap;

    const-class v0, LX3/z0;

    invoke-direct {p1, v0}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    return-void

    .line 12
    :sswitch_2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    :try_start_0
    invoke-static {}, Lorg/xmlpull/v1/XmlPullParserFactory;->newInstance()Lorg/xmlpull/v1/XmlPullParserFactory;

    move-result-object p1

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    .line 14
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Couldn\'t create XmlPullParserFactory instance"

    invoke-direct {v0, v1, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :sswitch_data_0
    .sparse-switch
        0x14 -> :sswitch_2
        0x16 -> :sswitch_1
        0x1a -> :sswitch_0
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA5/g;->a:I

    iput-object p2, p0, LA5/g;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LX3/D0;LX3/n0;)V
    .locals 0

    const/16 p1, 0x18

    iput p1, p0, LA5/g;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LA5/g;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/net/Uri;)V
    .locals 1

    const/16 v0, 0xc

    iput v0, p0, LA5/g;->a:I

    .line 24
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/content/ContentResolver;->acquireUnstableContentProviderClient(Landroid/net/Uri;)Landroid/content/ContentProviderClient;

    move-result-object p1

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/ContentInfo;)V
    .locals 1

    const/16 v0, 0x10

    iput v0, p0, LA5/g;->a:I

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    invoke-static {p1}, LG3/g;->o(Ljava/lang/Object;)Landroid/view/ContentInfo;

    move-result-object p1

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .locals 2

    const/16 v0, 0x11

    iput v0, p0, LA5/g;->a:I

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    .line 19
    new-instance v0, LP/x;

    .line 20
    invoke-direct {v0, p1}, LP/v;-><init>(Landroid/view/View;)V

    .line 21
    iput-object p1, v0, LP/x;->b:Landroid/view/View;

    .line 22
    iput-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    goto :goto_0

    .line 23
    :cond_0
    new-instance v0, LP/v;

    invoke-direct {v0, p1}, LP/v;-><init>(Landroid/view/View;)V

    iput-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    :goto_0
    return-void
.end method

.method public constructor <init>(Ljava/util/EnumMap;)V
    .locals 2

    const/16 v0, 0x16

    iput v0, p0, LA5/g;->a:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/EnumMap;

    const-class v1, LX3/z0;

    invoke-direct {v0, v1}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 4
    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->putAll(Ljava/util/Map;)V

    return-void
.end method

.method public constructor <init>(Ln6/d;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LA5/g;->a:I

    const-string v0, "encryptedPreference"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lr8/l;)V
    .locals 1

    const/16 v0, 0x1b

    iput v0, p0, LA5/g;->a:I

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    check-cast p1, Lkotlin/jvm/internal/i;

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lt6/s0;)V
    .locals 1

    const/4 v0, 0x5

    iput v0, p0, LA5/g;->a:I

    const-string v0, "userRepository"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    return-void
.end method

.method public static U(III)LA5/g;
    .locals 2

    .line 1
    new-instance v0, LA5/g;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-static {p0, p1, v1, p2}, Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;->obtain(IIZI)Landroid/view/accessibility/AccessibilityNodeInfo$CollectionInfo;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    const/16 p1, 0x12

    .line 9
    .line 10
    invoke-direct {v0, p1, p0}, LA5/g;-><init>(ILjava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method


# virtual methods
.method public A(I)Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/a;->v(I)Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public B(II)V
    .locals 2

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LG0/K;

    .line 4
    .line 5
    iget-object v0, v0, LG0/V;->a:LG0/W;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-virtual {v0, p1, p2, v1}, LG0/W;->d(IILjava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public C(II)V
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LG0/K;

    .line 4
    .line 5
    iget-object v0, v0, LG0/V;->a:LG0/W;

    .line 6
    .line 7
    invoke-virtual {v0, p1, p2}, LG0/W;->e(II)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public D()J
    .locals 11

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [LJ2/g0;

    .line 4
    .line 5
    array-length v1, v0

    .line 6
    const-wide v2, 0x7fffffffffffffffL

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    move-wide v5, v2

    .line 13
    :goto_0
    const-wide/high16 v7, -0x8000000000000000L

    .line 14
    .line 15
    if-ge v4, v1, :cond_1

    .line 16
    .line 17
    aget-object v9, v0, v4

    .line 18
    .line 19
    invoke-interface {v9}, LJ2/g0;->D()J

    .line 20
    .line 21
    .line 22
    move-result-wide v9

    .line 23
    cmp-long v7, v9, v7

    .line 24
    .line 25
    if-eqz v7, :cond_0

    .line 26
    .line 27
    invoke-static {v5, v6, v9, v10}, Ljava/lang/Math;->min(JJ)J

    .line 28
    .line 29
    .line 30
    move-result-wide v5

    .line 31
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    cmp-long v0, v5, v2

    .line 35
    .line 36
    if-nez v0, :cond_2

    .line 37
    .line 38
    return-wide v7

    .line 39
    :cond_2
    return-wide v5
.end method

.method public E(Lg3/K;Ljava/io/IOException;I)Lg3/H;
    .locals 7

    .line 1
    check-cast p1, Lg3/Q;

    .line 2
    .line 3
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, LM2/h;

    .line 6
    .line 7
    new-instance v1, LJ2/q;

    .line 8
    .line 9
    iget-wide v2, p1, Lg3/Q;->a:J

    .line 10
    .line 11
    iget-object v2, p1, Lg3/Q;->d:Lg3/W;

    .line 12
    .line 13
    iget-object v2, v2, Lg3/W;->c:Landroid/net/Uri;

    .line 14
    .line 15
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    iget p1, p1, Lg3/Q;->c:I

    .line 19
    .line 20
    iget-object v2, v0, LM2/h;->n:Lg1/q;

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    instance-of v2, p2, Lf2/j0;

    .line 26
    .line 27
    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    if-nez v2, :cond_2

    .line 33
    .line 34
    instance-of v2, p2, Ljava/io/FileNotFoundException;

    .line 35
    .line 36
    if-nez v2, :cond_2

    .line 37
    .line 38
    instance-of v2, p2, Lg3/B;

    .line 39
    .line 40
    if-nez v2, :cond_2

    .line 41
    .line 42
    instance-of v2, p2, Lg3/M;

    .line 43
    .line 44
    if-nez v2, :cond_2

    .line 45
    .line 46
    sget v2, Lg3/n;->b:I

    .line 47
    .line 48
    move-object v2, p2

    .line 49
    :goto_0
    if-eqz v2, :cond_1

    .line 50
    .line 51
    instance-of v5, v2, Lg3/n;

    .line 52
    .line 53
    if-eqz v5, :cond_0

    .line 54
    .line 55
    move-object v5, v2

    .line 56
    check-cast v5, Lg3/n;

    .line 57
    .line 58
    iget v5, v5, Lg3/n;->a:I

    .line 59
    .line 60
    const/16 v6, 0x7d8

    .line 61
    .line 62
    if-ne v5, v6, :cond_0

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_0
    invoke-virtual {v2}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 66
    .line 67
    .line 68
    move-result-object v2

    .line 69
    goto :goto_0

    .line 70
    :cond_1
    add-int/lit8 p3, p3, -0x1

    .line 71
    .line 72
    mul-int/lit16 p3, p3, 0x3e8

    .line 73
    .line 74
    const/16 v2, 0x1388

    .line 75
    .line 76
    invoke-static {p3, v2}, Ljava/lang/Math;->min(II)I

    .line 77
    .line 78
    .line 79
    move-result p3

    .line 80
    int-to-long v5, p3

    .line 81
    goto :goto_2

    .line 82
    :cond_2
    :goto_1
    move-wide v5, v3

    .line 83
    :goto_2
    cmp-long p3, v5, v3

    .line 84
    .line 85
    if-nez p3, :cond_3

    .line 86
    .line 87
    sget-object p3, Lg3/N;->f:Lg3/H;

    .line 88
    .line 89
    goto :goto_3

    .line 90
    :cond_3
    new-instance p3, Lg3/H;

    .line 91
    .line 92
    const/4 v2, 0x0

    .line 93
    invoke-direct {p3, v2, v5, v6, v2}, Lg3/H;-><init>(IJZ)V

    .line 94
    .line 95
    .line 96
    :goto_3
    invoke-virtual {p3}, Lg3/H;->a()Z

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    xor-int/lit8 v2, v2, 0x1

    .line 101
    .line 102
    iget-object v0, v0, LM2/h;->q:LJ2/H;

    .line 103
    .line 104
    invoke-virtual {v0, v1, p1, p2, v2}, LJ2/H;->j(LJ2/q;ILjava/io/IOException;Z)V

    .line 105
    .line 106
    .line 107
    return-object p3
.end method

.method public F(Lg3/K;JJ)V
    .locals 21

    .line 1
    move-wide/from16 v0, p2

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    check-cast v2, Lg3/Q;

    .line 6
    .line 7
    move-object/from16 v3, p0

    .line 8
    .line 9
    iget-object v4, v3, LA5/g;->b:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v4, LM2/h;

    .line 12
    .line 13
    new-instance v5, LJ2/q;

    .line 14
    .line 15
    iget-wide v6, v2, Lg3/Q;->a:J

    .line 16
    .line 17
    iget-object v6, v2, Lg3/Q;->d:Lg3/W;

    .line 18
    .line 19
    iget-object v6, v6, Lg3/W;->c:Landroid/net/Uri;

    .line 20
    .line 21
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iget-object v6, v4, LM2/h;->n:Lg1/q;

    .line 25
    .line 26
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    iget-object v6, v4, LM2/h;->q:LJ2/H;

    .line 30
    .line 31
    iget v7, v2, Lg3/Q;->c:I

    .line 32
    .line 33
    invoke-virtual {v6, v5, v7}, LJ2/H;->f(LJ2/q;I)V

    .line 34
    .line 35
    .line 36
    iget-object v5, v2, Lg3/Q;->f:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v5, LN2/c;

    .line 39
    .line 40
    iget-object v6, v4, LM2/h;->d0:LN2/c;

    .line 41
    .line 42
    const/4 v7, 0x0

    .line 43
    if-nez v6, :cond_0

    .line 44
    .line 45
    move v6, v7

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    iget-object v6, v6, LN2/c;->m:Ljava/util/List;

    .line 48
    .line 49
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    :goto_0
    invoke-virtual {v5, v7}, LN2/c;->b(I)LN2/h;

    .line 54
    .line 55
    .line 56
    move-result-object v8

    .line 57
    iget-wide v8, v8, LN2/h;->b:J

    .line 58
    .line 59
    move v10, v7

    .line 60
    :goto_1
    if-ge v10, v6, :cond_1

    .line 61
    .line 62
    iget-object v11, v4, LM2/h;->d0:LN2/c;

    .line 63
    .line 64
    invoke-virtual {v11, v10}, LN2/c;->b(I)LN2/h;

    .line 65
    .line 66
    .line 67
    move-result-object v11

    .line 68
    iget-wide v11, v11, LN2/h;->b:J

    .line 69
    .line 70
    cmp-long v11, v11, v8

    .line 71
    .line 72
    if-gez v11, :cond_1

    .line 73
    .line 74
    add-int/lit8 v10, v10, 0x1

    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_1
    iget-boolean v8, v5, LN2/c;->d:Z

    .line 78
    .line 79
    const/4 v9, 0x1

    .line 80
    if-eqz v8, :cond_5

    .line 81
    .line 82
    sub-int v8, v6, v10

    .line 83
    .line 84
    iget-object v11, v5, LN2/c;->m:Ljava/util/List;

    .line 85
    .line 86
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 87
    .line 88
    .line 89
    move-result v11

    .line 90
    if-le v8, v11, :cond_2

    .line 91
    .line 92
    const-string v0, "DashMediaSource"

    .line 93
    .line 94
    const-string v1, "Loaded out of sync manifest"

    .line 95
    .line 96
    invoke-static {v0, v1}, Lh3/a;->P(Ljava/lang/String;Ljava/lang/String;)V

    .line 97
    .line 98
    .line 99
    goto :goto_2

    .line 100
    :cond_2
    iget-wide v11, v4, LM2/h;->j0:J

    .line 101
    .line 102
    const-wide v13, -0x7fffffffffffffffL    # -4.9E-324

    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    cmp-long v8, v11, v13

    .line 108
    .line 109
    if-eqz v8, :cond_4

    .line 110
    .line 111
    iget-wide v13, v5, LN2/c;->h:J

    .line 112
    .line 113
    const-wide/16 v15, 0x3e8

    .line 114
    .line 115
    mul-long/2addr v13, v15

    .line 116
    cmp-long v8, v13, v11

    .line 117
    .line 118
    if-gtz v8, :cond_4

    .line 119
    .line 120
    const-string v0, "DashMediaSource"

    .line 121
    .line 122
    new-instance v1, Ljava/lang/StringBuilder;

    .line 123
    .line 124
    const-string v6, "Loaded stale dynamic manifest: "

    .line 125
    .line 126
    invoke-direct {v1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    iget-wide v5, v5, LN2/c;->h:J

    .line 130
    .line 131
    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    const-string v5, ", "

    .line 135
    .line 136
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    .line 138
    .line 139
    iget-wide v5, v4, LM2/h;->j0:J

    .line 140
    .line 141
    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    invoke-static {v0, v1}, Lh3/a;->P(Ljava/lang/String;Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    :goto_2
    iget v0, v4, LM2/h;->i0:I

    .line 152
    .line 153
    add-int/lit8 v1, v0, 0x1

    .line 154
    .line 155
    iput v1, v4, LM2/h;->i0:I

    .line 156
    .line 157
    iget-object v1, v4, LM2/h;->n:Lg1/q;

    .line 158
    .line 159
    iget v2, v2, Lg3/Q;->c:I

    .line 160
    .line 161
    invoke-virtual {v1, v2}, Lg1/q;->e(I)I

    .line 162
    .line 163
    .line 164
    move-result v1

    .line 165
    if-ge v0, v1, :cond_3

    .line 166
    .line 167
    iget v0, v4, LM2/h;->i0:I

    .line 168
    .line 169
    sub-int/2addr v0, v9

    .line 170
    mul-int/lit16 v0, v0, 0x3e8

    .line 171
    .line 172
    const/16 v1, 0x1388

    .line 173
    .line 174
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    int-to-long v0, v0

    .line 179
    iget-object v2, v4, LM2/h;->D:Landroid/os/Handler;

    .line 180
    .line 181
    iget-object v4, v4, LM2/h;->v:LM2/c;

    .line 182
    .line 183
    invoke-virtual {v2, v4, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 184
    .line 185
    .line 186
    return-void

    .line 187
    :cond_3
    new-instance v0, LJ2/N;

    .line 188
    .line 189
    invoke-direct {v0}, Ljava/io/IOException;-><init>()V

    .line 190
    .line 191
    .line 192
    iput-object v0, v4, LM2/h;->C:LJ2/N;

    .line 193
    .line 194
    return-void

    .line 195
    :cond_4
    iput v7, v4, LM2/h;->i0:I

    .line 196
    .line 197
    :cond_5
    iput-object v5, v4, LM2/h;->d0:LN2/c;

    .line 198
    .line 199
    iget-boolean v7, v4, LM2/h;->e0:Z

    .line 200
    .line 201
    iget-boolean v5, v5, LN2/c;->d:Z

    .line 202
    .line 203
    and-int/2addr v5, v7

    .line 204
    iput-boolean v5, v4, LM2/h;->e0:Z

    .line 205
    .line 206
    sub-long v7, v0, p4

    .line 207
    .line 208
    iput-wide v7, v4, LM2/h;->f0:J

    .line 209
    .line 210
    iput-wide v0, v4, LM2/h;->g0:J

    .line 211
    .line 212
    iget-object v1, v4, LM2/h;->t:Ljava/lang/Object;

    .line 213
    .line 214
    monitor-enter v1

    .line 215
    :try_start_0
    iget-object v0, v2, Lg3/Q;->b:Lg3/q;

    .line 216
    .line 217
    iget-object v0, v0, Lg3/q;->a:Landroid/net/Uri;

    .line 218
    .line 219
    iget-object v5, v4, LM2/h;->Y:Landroid/net/Uri;

    .line 220
    .line 221
    if-ne v0, v5, :cond_7

    .line 222
    .line 223
    iget-object v0, v4, LM2/h;->d0:LN2/c;

    .line 224
    .line 225
    iget-object v0, v0, LN2/c;->k:Landroid/net/Uri;

    .line 226
    .line 227
    if-eqz v0, :cond_6

    .line 228
    .line 229
    goto :goto_3

    .line 230
    :cond_6
    iget-object v0, v2, Lg3/Q;->d:Lg3/W;

    .line 231
    .line 232
    iget-object v0, v0, Lg3/W;->c:Landroid/net/Uri;

    .line 233
    .line 234
    :goto_3
    iput-object v0, v4, LM2/h;->Y:Landroid/net/Uri;

    .line 235
    .line 236
    goto :goto_4

    .line 237
    :catchall_0
    move-exception v0

    .line 238
    goto/16 :goto_a

    .line 239
    .line 240
    :cond_7
    :goto_4
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 241
    if-nez v6, :cond_12

    .line 242
    .line 243
    iget-object v0, v4, LM2/h;->d0:LN2/c;

    .line 244
    .line 245
    iget-boolean v1, v0, LN2/c;->d:Z

    .line 246
    .line 247
    if-eqz v1, :cond_11

    .line 248
    .line 249
    iget-object v0, v0, LN2/c;->i:LN2/u;

    .line 250
    .line 251
    if-eqz v0, :cond_10

    .line 252
    .line 253
    iget-object v1, v0, LN2/u;->b:Ljava/lang/String;

    .line 254
    .line 255
    const-string v2, "urn:mpeg:dash:utc:direct:2014"

    .line 256
    .line 257
    invoke-static {v1, v2}, Lh3/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 258
    .line 259
    .line 260
    move-result v2

    .line 261
    if-nez v2, :cond_f

    .line 262
    .line 263
    const-string v2, "urn:mpeg:dash:utc:direct:2012"

    .line 264
    .line 265
    invoke-static {v1, v2}, Lh3/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 266
    .line 267
    .line 268
    move-result v2

    .line 269
    if-eqz v2, :cond_8

    .line 270
    .line 271
    goto/16 :goto_8

    .line 272
    .line 273
    :cond_8
    const-string v2, "urn:mpeg:dash:utc:http-iso:2014"

    .line 274
    .line 275
    invoke-static {v1, v2}, Lh3/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 276
    .line 277
    .line 278
    move-result v2

    .line 279
    const/4 v5, 0x5

    .line 280
    if-nez v2, :cond_e

    .line 281
    .line 282
    const-string v2, "urn:mpeg:dash:utc:http-iso:2012"

    .line 283
    .line 284
    invoke-static {v1, v2}, Lh3/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 285
    .line 286
    .line 287
    move-result v2

    .line 288
    if-eqz v2, :cond_9

    .line 289
    .line 290
    goto :goto_7

    .line 291
    :cond_9
    const-string v2, "urn:mpeg:dash:utc:http-xsdate:2014"

    .line 292
    .line 293
    invoke-static {v1, v2}, Lh3/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 294
    .line 295
    .line 296
    move-result v2

    .line 297
    if-nez v2, :cond_d

    .line 298
    .line 299
    const-string v2, "urn:mpeg:dash:utc:http-xsdate:2012"

    .line 300
    .line 301
    invoke-static {v1, v2}, Lh3/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    move-result v2

    .line 305
    if-eqz v2, :cond_a

    .line 306
    .line 307
    goto :goto_6

    .line 308
    :cond_a
    const-string v0, "urn:mpeg:dash:utc:ntp:2014"

    .line 309
    .line 310
    invoke-static {v1, v0}, Lh3/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 311
    .line 312
    .line 313
    move-result v0

    .line 314
    if-nez v0, :cond_c

    .line 315
    .line 316
    const-string v0, "urn:mpeg:dash:utc:ntp:2012"

    .line 317
    .line 318
    invoke-static {v1, v0}, Lh3/y;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v0

    .line 322
    if-eqz v0, :cond_b

    .line 323
    .line 324
    goto :goto_5

    .line 325
    :cond_b
    new-instance v0, Ljava/io/IOException;

    .line 326
    .line 327
    const-string v1, "Unsupported UTC timing scheme"

    .line 328
    .line 329
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    const-string v1, "DashMediaSource"

    .line 333
    .line 334
    const-string v2, "Failed to resolve time offset."

    .line 335
    .line 336
    invoke-static {v1, v2, v0}, Lh3/a;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 337
    .line 338
    .line 339
    invoke-virtual {v4, v9}, LM2/h;->v(Z)V

    .line 340
    .line 341
    .line 342
    return-void

    .line 343
    :cond_c
    :goto_5
    invoke-virtual {v4}, LM2/h;->u()V

    .line 344
    .line 345
    .line 346
    return-void

    .line 347
    :cond_d
    :goto_6
    new-instance v1, LK5/f;

    .line 348
    .line 349
    const/16 v2, 0xf

    .line 350
    .line 351
    invoke-direct {v1, v2}, LK5/f;-><init>(I)V

    .line 352
    .line 353
    .line 354
    new-instance v2, Lg3/Q;

    .line 355
    .line 356
    iget-object v6, v4, LM2/h;->z:Lg3/m;

    .line 357
    .line 358
    iget-object v0, v0, LN2/u;->c:Ljava/lang/String;

    .line 359
    .line 360
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 361
    .line 362
    .line 363
    move-result-object v0

    .line 364
    invoke-direct {v2, v6, v0, v5, v1}, Lg3/Q;-><init>(Lg3/m;Landroid/net/Uri;ILg3/P;)V

    .line 365
    .line 366
    .line 367
    new-instance v0, LM2/f;

    .line 368
    .line 369
    invoke-direct {v0, v4}, LM2/f;-><init>(LM2/h;)V

    .line 370
    .line 371
    .line 372
    iget-object v1, v4, LM2/h;->A:Lg3/N;

    .line 373
    .line 374
    invoke-virtual {v1, v2, v0, v9}, Lg3/N;->f(Lg3/K;Lg3/I;I)J

    .line 375
    .line 376
    .line 377
    iget-object v10, v4, LM2/h;->q:LJ2/H;

    .line 378
    .line 379
    new-instance v11, LJ2/q;

    .line 380
    .line 381
    iget-object v0, v2, Lg3/Q;->b:Lg3/q;

    .line 382
    .line 383
    invoke-direct {v11, v0}, LJ2/q;-><init>(Lg3/q;)V

    .line 384
    .line 385
    .line 386
    iget v12, v2, Lg3/Q;->c:I

    .line 387
    .line 388
    const-wide v17, -0x7fffffffffffffffL    # -4.9E-324

    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    const-wide v19, -0x7fffffffffffffffL    # -4.9E-324

    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    const/4 v13, -0x1

    .line 399
    const/4 v14, 0x0

    .line 400
    const/4 v15, 0x0

    .line 401
    const/16 v16, 0x0

    .line 402
    .line 403
    invoke-virtual/range {v10 .. v20}, LJ2/H;->l(LJ2/q;IILf2/N;ILjava/lang/Object;JJ)V

    .line 404
    .line 405
    .line 406
    return-void

    .line 407
    :cond_e
    :goto_7
    new-instance v1, LM2/g;

    .line 408
    .line 409
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 410
    .line 411
    .line 412
    new-instance v2, Lg3/Q;

    .line 413
    .line 414
    iget-object v6, v4, LM2/h;->z:Lg3/m;

    .line 415
    .line 416
    iget-object v0, v0, LN2/u;->c:Ljava/lang/String;

    .line 417
    .line 418
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 419
    .line 420
    .line 421
    move-result-object v0

    .line 422
    invoke-direct {v2, v6, v0, v5, v1}, Lg3/Q;-><init>(Lg3/m;Landroid/net/Uri;ILg3/P;)V

    .line 423
    .line 424
    .line 425
    new-instance v0, LM2/f;

    .line 426
    .line 427
    invoke-direct {v0, v4}, LM2/f;-><init>(LM2/h;)V

    .line 428
    .line 429
    .line 430
    iget-object v1, v4, LM2/h;->A:Lg3/N;

    .line 431
    .line 432
    invoke-virtual {v1, v2, v0, v9}, Lg3/N;->f(Lg3/K;Lg3/I;I)J

    .line 433
    .line 434
    .line 435
    iget-object v10, v4, LM2/h;->q:LJ2/H;

    .line 436
    .line 437
    new-instance v11, LJ2/q;

    .line 438
    .line 439
    iget-object v0, v2, Lg3/Q;->b:Lg3/q;

    .line 440
    .line 441
    invoke-direct {v11, v0}, LJ2/q;-><init>(Lg3/q;)V

    .line 442
    .line 443
    .line 444
    iget v12, v2, Lg3/Q;->c:I

    .line 445
    .line 446
    const-wide v17, -0x7fffffffffffffffL    # -4.9E-324

    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    const-wide v19, -0x7fffffffffffffffL    # -4.9E-324

    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    const/4 v13, -0x1

    .line 457
    const/4 v14, 0x0

    .line 458
    const/4 v15, 0x0

    .line 459
    const/16 v16, 0x0

    .line 460
    .line 461
    invoke-virtual/range {v10 .. v20}, LJ2/H;->l(LJ2/q;IILf2/N;ILjava/lang/Object;JJ)V

    .line 462
    .line 463
    .line 464
    return-void

    .line 465
    :cond_f
    :goto_8
    :try_start_1
    iget-object v0, v0, LN2/u;->c:Ljava/lang/String;

    .line 466
    .line 467
    invoke-static {v0}, Lh3/y;->K(Ljava/lang/String;)J

    .line 468
    .line 469
    .line 470
    move-result-wide v0

    .line 471
    iget-wide v5, v4, LM2/h;->g0:J

    .line 472
    .line 473
    sub-long/2addr v0, v5

    .line 474
    iput-wide v0, v4, LM2/h;->h0:J

    .line 475
    .line 476
    invoke-virtual {v4, v9}, LM2/h;->v(Z)V
    :try_end_1
    .catch Lf2/j0; {:try_start_1 .. :try_end_1} :catch_0

    .line 477
    .line 478
    .line 479
    goto :goto_9

    .line 480
    :catch_0
    move-exception v0

    .line 481
    const-string v1, "DashMediaSource"

    .line 482
    .line 483
    const-string v2, "Failed to resolve time offset."

    .line 484
    .line 485
    invoke-static {v1, v2, v0}, Lh3/a;->u(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 486
    .line 487
    .line 488
    invoke-virtual {v4, v9}, LM2/h;->v(Z)V

    .line 489
    .line 490
    .line 491
    :goto_9
    return-void

    .line 492
    :cond_10
    invoke-virtual {v4}, LM2/h;->u()V

    .line 493
    .line 494
    .line 495
    return-void

    .line 496
    :cond_11
    invoke-virtual {v4, v9}, LM2/h;->v(Z)V

    .line 497
    .line 498
    .line 499
    return-void

    .line 500
    :cond_12
    iget v0, v4, LM2/h;->k0:I

    .line 501
    .line 502
    add-int/2addr v0, v10

    .line 503
    iput v0, v4, LM2/h;->k0:I

    .line 504
    .line 505
    invoke-virtual {v4, v9}, LM2/h;->v(Z)V

    .line 506
    .line 507
    .line 508
    return-void

    .line 509
    :goto_a
    :try_start_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 510
    throw v0
.end method

.method public H()I
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/recyclerview/widget/a;->K()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public I()I
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/ContentInfo;

    .line 4
    .line 5
    invoke-static {v0}, LG3/g;->y(Landroid/view/ContentInfo;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public J(Landroid/view/View;)I
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, LG0/f0;

    .line 6
    .line 7
    invoke-static {p1}, Landroidx/recyclerview/widget/a;->z(Landroid/view/View;)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 12
    .line 13
    add-int/2addr p1, v0

    .line 14
    return p1
.end method

.method public M(Landroid/net/Uri;Lg3/o;)Ljava/lang/Object;
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    iget-object v1, p0, LA5/g;->b:Ljava/lang/Object;

    .line 3
    .line 4
    check-cast v1, Lorg/xmlpull/v1/XmlPullParserFactory;

    .line 5
    .line 6
    invoke-virtual {v1}, Lorg/xmlpull/v1/XmlPullParserFactory;->newPullParser()Lorg/xmlpull/v1/XmlPullParser;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-interface {v1, p2, v0}, Lorg/xmlpull/v1/XmlPullParser;->setInput(Ljava/io/InputStream;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    new-instance p2, LT2/g;

    .line 14
    .line 15
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-direct {p2, p1}, LT2/g;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p2, v1}, LT2/d;->e(Lorg/xmlpull/v1/XmlPullParser;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    check-cast p1, LT2/c;
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_0

    .line 27
    .line 28
    return-object p1

    .line 29
    :catch_0
    move-exception p1

    .line 30
    invoke-static {v0, p1}, Lf2/j0;->b(Ljava/lang/String;Ljava/lang/Exception;)Lf2/j0;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    throw p1
.end method

.method public N(J)Z
    .locals 17

    .line 1
    move-wide/from16 v0, p1

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    move v3, v2

    .line 5
    :cond_0
    invoke-virtual/range {p0 .. p0}, LA5/g;->p()J

    .line 6
    .line 7
    .line 8
    move-result-wide v4

    .line 9
    const-wide/high16 v6, -0x8000000000000000L

    .line 10
    .line 11
    cmp-long v8, v4, v6

    .line 12
    .line 13
    if-nez v8, :cond_1

    .line 14
    .line 15
    return v3

    .line 16
    :cond_1
    move-object/from16 v8, p0

    .line 17
    .line 18
    iget-object v9, v8, LA5/g;->b:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v9, [LJ2/g0;

    .line 21
    .line 22
    array-length v10, v9

    .line 23
    move v11, v2

    .line 24
    move v12, v11

    .line 25
    :goto_0
    if-ge v11, v10, :cond_5

    .line 26
    .line 27
    aget-object v13, v9, v11

    .line 28
    .line 29
    invoke-interface {v13}, LJ2/g0;->p()J

    .line 30
    .line 31
    .line 32
    move-result-wide v14

    .line 33
    cmp-long v16, v14, v6

    .line 34
    .line 35
    if-eqz v16, :cond_2

    .line 36
    .line 37
    cmp-long v16, v14, v0

    .line 38
    .line 39
    if-gtz v16, :cond_2

    .line 40
    .line 41
    const/16 v16, 0x1

    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_2
    move/from16 v16, v2

    .line 45
    .line 46
    :goto_1
    cmp-long v14, v14, v4

    .line 47
    .line 48
    if-eqz v14, :cond_3

    .line 49
    .line 50
    if-eqz v16, :cond_4

    .line 51
    .line 52
    :cond_3
    invoke-interface {v13, v0, v1}, LJ2/g0;->N(J)Z

    .line 53
    .line 54
    .line 55
    move-result v13

    .line 56
    or-int/2addr v12, v13

    .line 57
    :cond_4
    add-int/lit8 v11, v11, 0x1

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_5
    or-int/2addr v3, v12

    .line 61
    if-nez v12, :cond_0

    .line 62
    .line 63
    return v3
.end method

.method public P(J)V
    .locals 4

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [LJ2/g0;

    .line 4
    .line 5
    array-length v1, v0

    .line 6
    const/4 v2, 0x0

    .line 7
    :goto_0
    if-ge v2, v1, :cond_0

    .line 8
    .line 9
    aget-object v3, v0, v2

    .line 10
    .line 11
    invoke-interface {v3, p1, p2}, LJ2/g0;->P(J)V

    .line 12
    .line 13
    .line 14
    add-int/lit8 v2, v2, 0x1

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    return-void
.end method

.method public Q()I
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    return v0
.end method

.method public R()LE1/i;
    .locals 3

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LE1/b;

    .line 4
    .line 5
    iget-object v1, v0, LE1/b;->d:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LE1/g;

    .line 8
    .line 9
    monitor-enter v1

    .line 10
    const/4 v2, 0x1

    .line 11
    :try_start_0
    invoke-virtual {v0, v2}, LE1/b;->b(Z)V

    .line 12
    .line 13
    .line 14
    iget-object v0, v0, LE1/b;->c:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, LE1/c;

    .line 17
    .line 18
    iget-object v0, v0, LE1/c;->a:Ljava/lang/String;

    .line 19
    .line 20
    invoke-virtual {v1, v0}, LE1/g;->k(Ljava/lang/String;)LE1/d;

    .line 21
    .line 22
    .line 23
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 24
    monitor-exit v1

    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    new-instance v1, LE1/i;

    .line 28
    .line 29
    invoke-direct {v1, v0}, LE1/i;-><init>(LE1/d;)V

    .line 30
    .line 31
    .line 32
    return-object v1

    .line 33
    :cond_0
    const/4 v0, 0x0

    .line 34
    return-object v0

    .line 35
    :catchall_0
    move-exception v0

    .line 36
    monitor-exit v1

    .line 37
    throw v0
.end method

.method public S()Ly6/o;
    .locals 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget-object v0, v1, LA5/g;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ln6/d;

    .line 6
    .line 7
    sget-object v2, Lg6/o;->a:Lg6/o;

    .line 8
    .line 9
    invoke-virtual {v2}, Lg6/o;->Q()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    const-class v3, Lcom/maertsno/data/model/preference/GeneralPreference;

    .line 14
    .line 15
    invoke-static {v3}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    sget-object v5, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    .line 20
    .line 21
    invoke-static {v5}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/d;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    if-eqz v5, :cond_0

    .line 30
    .line 31
    iget-object v0, v0, Ln6/d;->a:Landroid/content/SharedPreferences;

    .line 32
    .line 33
    const/4 v3, 0x0

    .line 34
    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    check-cast v0, Lcom/maertsno/data/model/preference/GeneralPreference;

    .line 43
    .line 44
    goto/16 :goto_2

    .line 45
    .line 46
    :cond_0
    sget-object v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 47
    .line 48
    invoke-static {v5}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 49
    .line 50
    .line 51
    move-result-object v5

    .line 52
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/d;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v5

    .line 56
    const/4 v6, 0x0

    .line 57
    if-eqz v5, :cond_1

    .line 58
    .line 59
    iget-object v0, v0, Ln6/d;->a:Landroid/content/SharedPreferences;

    .line 60
    .line 61
    invoke-interface {v0, v2, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Lcom/maertsno/data/model/preference/GeneralPreference;

    .line 70
    .line 71
    goto/16 :goto_2

    .line 72
    .line 73
    :cond_1
    sget-object v5, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    .line 74
    .line 75
    invoke-static {v5}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 76
    .line 77
    .line 78
    move-result-object v5

    .line 79
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/d;->equals(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    if-eqz v5, :cond_2

    .line 84
    .line 85
    iget-object v0, v0, Ln6/d;->a:Landroid/content/SharedPreferences;

    .line 86
    .line 87
    const-wide/16 v3, 0x0

    .line 88
    .line 89
    invoke-interface {v0, v2, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    .line 90
    .line 91
    .line 92
    move-result-wide v2

    .line 93
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    check-cast v0, Lcom/maertsno/data/model/preference/GeneralPreference;

    .line 98
    .line 99
    goto :goto_2

    .line 100
    :cond_2
    const-class v5, Ljava/lang/String;

    .line 101
    .line 102
    invoke-static {v5}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/d;->equals(Ljava/lang/Object;)Z

    .line 107
    .line 108
    .line 109
    move-result v5

    .line 110
    const-string v7, ""

    .line 111
    .line 112
    if-eqz v5, :cond_4

    .line 113
    .line 114
    iget-object v0, v0, Ln6/d;->a:Landroid/content/SharedPreferences;

    .line 115
    .line 116
    invoke-interface {v0, v2, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    if-eqz v0, :cond_3

    .line 121
    .line 122
    check-cast v0, Lcom/maertsno/data/model/preference/GeneralPreference;

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :cond_3
    new-instance v0, Ljava/lang/NullPointerException;

    .line 126
    .line 127
    const-string v2, "null cannot be cast to non-null type com.maertsno.data.model.preference.GeneralPreference"

    .line 128
    .line 129
    invoke-direct {v0, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    throw v0

    .line 133
    :cond_4
    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    .line 134
    .line 135
    invoke-static {v5}, Lkotlin/jvm/internal/p;->a(Ljava/lang/Class;)Lkotlin/jvm/internal/d;

    .line 136
    .line 137
    .line 138
    move-result-object v5

    .line 139
    invoke-virtual {v4, v5}, Lkotlin/jvm/internal/d;->equals(Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    move-result v4

    .line 143
    if-eqz v4, :cond_5

    .line 144
    .line 145
    iget-object v0, v0, Ln6/d;->a:Landroid/content/SharedPreferences;

    .line 146
    .line 147
    invoke-interface {v0, v2, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    check-cast v0, Lcom/maertsno/data/model/preference/GeneralPreference;

    .line 156
    .line 157
    goto :goto_2

    .line 158
    :cond_5
    iget-object v4, v0, Ln6/d;->a:Landroid/content/SharedPreferences;

    .line 159
    .line 160
    invoke-interface {v4, v2, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v2

    .line 164
    const/4 v4, 0x0

    .line 165
    if-eqz v2, :cond_7

    .line 166
    .line 167
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 168
    .line 169
    .line 170
    move-result v5

    .line 171
    if-nez v5, :cond_6

    .line 172
    .line 173
    goto :goto_1

    .line 174
    :cond_6
    :try_start_0
    iget-object v0, v0, Ln6/d;->b:LP7/x;

    .line 175
    .line 176
    invoke-virtual {v0, v3}, LP7/x;->a(Ljava/lang/Class;)LP7/k;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    invoke-virtual {v0, v2}, LP7/k;->b(Ljava/lang/String;)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 184
    goto :goto_0

    .line 185
    :catchall_0
    move-exception v0

    .line 186
    invoke-static {v0}, Lv5/u0;->m(Ljava/lang/Throwable;)Ld8/h;

    .line 187
    .line 188
    .line 189
    move-result-object v0

    .line 190
    :goto_0
    instance-of v2, v0, Ld8/h;

    .line 191
    .line 192
    if-eqz v2, :cond_8

    .line 193
    .line 194
    :cond_7
    :goto_1
    move-object v0, v4

    .line 195
    :cond_8
    :goto_2
    check-cast v0, Lcom/maertsno/data/model/preference/GeneralPreference;

    .line 196
    .line 197
    sget-object v8, LA6/d;->a:LA6/d;

    .line 198
    .line 199
    sget-object v7, LA6/h;->a:LA6/h;

    .line 200
    .line 201
    if-nez v0, :cond_9

    .line 202
    .line 203
    new-instance v2, Ly6/o;

    .line 204
    .line 205
    const/4 v9, 0x0

    .line 206
    const-string v10, ""

    .line 207
    .line 208
    const/4 v3, 0x0

    .line 209
    const/4 v4, -0x1

    .line 210
    const/16 v5, 0x10

    .line 211
    .line 212
    const/16 v6, 0x16

    .line 213
    .line 214
    invoke-direct/range {v2 .. v10}, Ly6/o;-><init>(IIIILA6/h;LA6/d;ILjava/lang/String;)V

    .line 215
    .line 216
    .line 217
    goto :goto_3

    .line 218
    :cond_9
    iget v10, v0, Lcom/maertsno/data/model/preference/GeneralPreference;->a:I

    .line 219
    .line 220
    iget v11, v0, Lcom/maertsno/data/model/preference/GeneralPreference;->b:I

    .line 221
    .line 222
    iget v12, v0, Lcom/maertsno/data/model/preference/GeneralPreference;->c:I

    .line 223
    .line 224
    iget v13, v0, Lcom/maertsno/data/model/preference/GeneralPreference;->d:I

    .line 225
    .line 226
    iget v2, v0, Lcom/maertsno/data/model/preference/GeneralPreference;->e:I

    .line 227
    .line 228
    if-ltz v2, :cond_a

    .line 229
    .line 230
    sget-object v3, LA6/h;->c:Lk8/b;

    .line 231
    .line 232
    invoke-virtual {v3}, Lk8/b;->e()I

    .line 233
    .line 234
    .line 235
    move-result v4

    .line 236
    if-ge v2, v4, :cond_a

    .line 237
    .line 238
    invoke-virtual {v3, v2}, Lk8/b;->get(I)Ljava/lang/Object;

    .line 239
    .line 240
    .line 241
    move-result-object v7

    .line 242
    :cond_a
    move-object v14, v7

    .line 243
    check-cast v14, LA6/h;

    .line 244
    .line 245
    iget v2, v0, Lcom/maertsno/data/model/preference/GeneralPreference;->f:I

    .line 246
    .line 247
    if-ltz v2, :cond_b

    .line 248
    .line 249
    sget-object v3, LA6/d;->g:Lk8/b;

    .line 250
    .line 251
    invoke-virtual {v3}, Lk8/b;->e()I

    .line 252
    .line 253
    .line 254
    move-result v4

    .line 255
    if-ge v2, v4, :cond_b

    .line 256
    .line 257
    invoke-virtual {v3, v2}, Lk8/b;->get(I)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object v8

    .line 261
    :cond_b
    move-object v15, v8

    .line 262
    check-cast v15, LA6/d;

    .line 263
    .line 264
    iget v2, v0, Lcom/maertsno/data/model/preference/GeneralPreference;->g:I

    .line 265
    .line 266
    iget-object v0, v0, Lcom/maertsno/data/model/preference/GeneralPreference;->h:Ljava/lang/String;

    .line 267
    .line 268
    new-instance v9, Ly6/o;

    .line 269
    .line 270
    move-object/from16 v17, v0

    .line 271
    .line 272
    move/from16 v16, v2

    .line 273
    .line 274
    invoke-direct/range {v9 .. v17}, Ly6/o;-><init>(IIIILA6/h;LA6/d;ILjava/lang/String;)V

    .line 275
    .line 276
    .line 277
    move-object v2, v9

    .line 278
    :goto_3
    return-object v2
.end method

.method public T(Ljava/lang/String;Ljava/lang/String;Lj8/c;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p3, LF6/a;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, LF6/a;

    .line 7
    .line 8
    iget v1, v0, LF6/a;->t:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, LF6/a;->t:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, LF6/a;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, LF6/a;-><init>(LA5/g;Lj8/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p3, v0, LF6/a;->r:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, LF6/a;->t:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p3}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :cond_2
    invoke-static {p3}, Lv5/u0;->F(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object p3, p0, LA5/g;->b:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p3, Lt6/s0;

    .line 52
    .line 53
    iput v2, v0, LF6/a;->t:I

    .line 54
    .line 55
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    sget-object v1, Lv6/b;->a:LP7/x;

    .line 59
    .line 60
    new-instance v1, Lt6/e0;

    .line 61
    .line 62
    const/4 v2, 0x0

    .line 63
    invoke-direct {v1, p3, p1, p2, v2}, Lt6/e0;-><init>(Lt6/s0;Ljava/lang/String;Ljava/lang/String;Lh8/d;)V

    .line 64
    .line 65
    .line 66
    invoke-static {v1, v0}, Lv6/b;->a(Lr8/p;Lh8/d;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object p3

    .line 70
    sget-object p1, Li8/a;->a:Li8/a;

    .line 71
    .line 72
    if-ne p3, p1, :cond_3

    .line 73
    .line 74
    return-object p1

    .line 75
    :cond_3
    :goto_1
    check-cast p3, Lk6/c;

    .line 76
    .line 77
    invoke-static {p3}, LK3/h;->i(Lk6/c;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    return-object p1
.end method

.method public V(Lorg/json/JSONObject;)LA5/c;
    .locals 3

    .line 1
    const-string v0, "settings_version"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x3

    .line 8
    if-eq v0, v1, :cond_0

    .line 9
    .line 10
    new-instance v1, Ljava/lang/StringBuilder;

    .line 11
    .line 12
    const-string v2, "Could not determine SettingsJsonTransform for settings version "

    .line 13
    .line 14
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    const-string v0, ". Using default settings values."

    .line 21
    .line 22
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    const/4 v1, 0x0

    .line 30
    const-string v2, "FirebaseCrashlytics"

    .line 31
    .line 32
    invoke-static {v2, v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 33
    .line 34
    .line 35
    new-instance v0, LK5/f;

    .line 36
    .line 37
    const/4 v1, 0x1

    .line 38
    invoke-direct {v0, v1}, LK5/f;-><init>(I)V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    new-instance v0, LC4/e;

    .line 43
    .line 44
    const/4 v1, 0x2

    .line 45
    invoke-direct {v0, v1}, LC4/e;-><init>(I)V

    .line 46
    .line 47
    .line 48
    :goto_0
    iget-object v1, p0, LA5/g;->b:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v1, Ld2/b;

    .line 51
    .line 52
    invoke-interface {v0, v1, p1}, LA5/h;->f(Ld2/b;Lorg/json/JSONObject;)LA5/c;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    return-object p1
.end method

.method public W()V
    .locals 5

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LX3/s1;

    .line 4
    .line 5
    invoke-virtual {v0}, LX3/B;->r0()V

    .line 6
    .line 7
    .line 8
    iget-object v0, v0, LD/o;->a:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LX3/n0;

    .line 11
    .line 12
    iget-object v1, v0, LX3/n0;->e:LX3/d0;

    .line 13
    .line 14
    invoke-static {v1}, LX3/n0;->e(LD/o;)V

    .line 15
    .line 16
    .line 17
    iget-object v2, v0, LX3/n0;->k:LG3/a;

    .line 18
    .line 19
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 23
    .line 24
    .line 25
    move-result-wide v3

    .line 26
    invoke-virtual {v1, v3, v4}, LX3/d0;->B0(J)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_0

    .line 31
    .line 32
    iget-object v1, v0, LX3/n0;->e:LX3/d0;

    .line 33
    .line 34
    invoke-static {v1}, LX3/n0;->e(LD/o;)V

    .line 35
    .line 36
    .line 37
    iget-object v1, v1, LX3/d0;->l:LX3/a0;

    .line 38
    .line 39
    const/4 v3, 0x1

    .line 40
    invoke-virtual {v1, v3}, LX3/a0;->b(Z)V

    .line 41
    .line 42
    .line 43
    new-instance v1, Landroid/app/ActivityManager$RunningAppProcessInfo;

    .line 44
    .line 45
    invoke-direct {v1}, Landroid/app/ActivityManager$RunningAppProcessInfo;-><init>()V

    .line 46
    .line 47
    .line 48
    invoke-static {v1}, Landroid/app/ActivityManager;->getMyMemoryState(Landroid/app/ActivityManager$RunningAppProcessInfo;)V

    .line 49
    .line 50
    .line 51
    iget v1, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    .line 52
    .line 53
    const/16 v3, 0x64

    .line 54
    .line 55
    if-ne v1, v3, :cond_0

    .line 56
    .line 57
    iget-object v0, v0, LX3/n0;->f:LX3/U;

    .line 58
    .line 59
    invoke-static {v0}, LX3/n0;->g(LX3/v0;)V

    .line 60
    .line 61
    .line 62
    iget-object v0, v0, LX3/U;->n:LP8/b;

    .line 63
    .line 64
    const-string v1, "Detected application was in foreground"

    .line 65
    .line 66
    invoke-virtual {v0, v1}, LP8/b;->b(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 73
    .line 74
    .line 75
    move-result-wide v0

    .line 76
    invoke-virtual {p0, v0, v1}, LA5/g;->a0(J)V

    .line 77
    .line 78
    .line 79
    :cond_0
    return-void
.end method

.method public X()Z
    .locals 2

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LX3/n0;

    .line 4
    .line 5
    iget-object v0, v0, LX3/n0;->f:LX3/U;

    .line 6
    .line 7
    invoke-static {v0}, LX3/n0;->g(LX3/v0;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0}, LX3/U;->B0()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const/4 v1, 0x3

    .line 15
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    return v0
.end method

.method public Y(J)V
    .locals 4

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LX3/s1;

    .line 4
    .line 5
    invoke-virtual {v0}, LX3/B;->r0()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, LX3/s1;->v0()V

    .line 9
    .line 10
    .line 11
    iget-object v0, v0, LD/o;->a:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, LX3/n0;

    .line 14
    .line 15
    iget-object v1, v0, LX3/n0;->e:LX3/d0;

    .line 16
    .line 17
    invoke-static {v1}, LX3/n0;->e(LD/o;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, p1, p2}, LX3/d0;->B0(J)Z

    .line 21
    .line 22
    .line 23
    move-result v2

    .line 24
    if-eqz v2, :cond_0

    .line 25
    .line 26
    invoke-static {v1}, LX3/n0;->e(LD/o;)V

    .line 27
    .line 28
    .line 29
    iget-object v2, v1, LX3/d0;->l:LX3/a0;

    .line 30
    .line 31
    const/4 v3, 0x1

    .line 32
    invoke-virtual {v2, v3}, LX3/a0;->b(Z)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0}, LX3/n0;->l()LX3/M;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v0}, LX3/M;->w0()V

    .line 40
    .line 41
    .line 42
    :cond_0
    invoke-static {v1}, LX3/n0;->e(LD/o;)V

    .line 43
    .line 44
    .line 45
    iget-object v0, v1, LX3/d0;->p:LX3/b0;

    .line 46
    .line 47
    invoke-virtual {v0, p1, p2}, LX3/b0;->g(J)V

    .line 48
    .line 49
    .line 50
    iget-object v0, v1, LX3/d0;->l:LX3/a0;

    .line 51
    .line 52
    invoke-virtual {v0}, LX3/a0;->a()Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_1

    .line 57
    .line 58
    invoke-virtual {p0, p1, p2}, LA5/g;->a0(J)V

    .line 59
    .line 60
    .line 61
    :cond_1
    return-void
.end method

.method public Z(LX3/z0;I)V
    .locals 1

    .line 1
    const/16 v0, -0x1e

    .line 2
    .line 3
    if-eq p2, v0, :cond_3

    .line 4
    .line 5
    const/16 v0, -0x14

    .line 6
    .line 7
    if-eq p2, v0, :cond_2

    .line 8
    .line 9
    const/16 v0, -0xa

    .line 10
    .line 11
    if-eq p2, v0, :cond_1

    .line 12
    .line 13
    if-eqz p2, :cond_2

    .line 14
    .line 15
    const/16 v0, 0x1e

    .line 16
    .line 17
    if-eq p2, v0, :cond_0

    .line 18
    .line 19
    sget-object p2, LX3/h;->b:LX3/h;

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    sget-object p2, LX3/h;->f:LX3/h;

    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_1
    sget-object p2, LX3/h;->e:LX3/h;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_2
    sget-object p2, LX3/h;->g:LX3/h;

    .line 29
    .line 30
    goto :goto_0

    .line 31
    :cond_3
    sget-object p2, LX3/h;->h:LX3/h;

    .line 32
    .line 33
    :goto_0
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v0, Ljava/util/EnumMap;

    .line 36
    .line 37
    invoke-virtual {v0, p1, p2}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public a(J)I
    .locals 0

    .line 1
    const/4 p1, -0x1

    .line 2
    return p1
.end method

.method public a0(J)V
    .locals 9

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LX3/s1;

    .line 4
    .line 5
    invoke-virtual {v0}, LX3/B;->r0()V

    .line 6
    .line 7
    .line 8
    iget-object v0, v0, LD/o;->a:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LX3/n0;

    .line 11
    .line 12
    invoke-virtual {v0}, LX3/n0;->a()Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    if-nez v3, :cond_0

    .line 17
    .line 18
    goto/16 :goto_0

    .line 19
    .line 20
    :cond_0
    iget-object v6, v0, LX3/n0;->e:LX3/d0;

    .line 21
    .line 22
    invoke-static {v6}, LX3/n0;->e(LD/o;)V

    .line 23
    .line 24
    .line 25
    iget-object v3, v6, LX3/d0;->p:LX3/b0;

    .line 26
    .line 27
    invoke-virtual {v3, p1, p2}, LX3/b0;->g(J)V

    .line 28
    .line 29
    .line 30
    iget-object v3, v0, LX3/n0;->k:LG3/a;

    .line 31
    .line 32
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 36
    .line 37
    .line 38
    move-result-wide v3

    .line 39
    iget-object v5, v0, LX3/n0;->f:LX3/U;

    .line 40
    .line 41
    invoke-static {v5}, LX3/n0;->g(LX3/v0;)V

    .line 42
    .line 43
    .line 44
    iget-object v5, v5, LX3/U;->n:LP8/b;

    .line 45
    .line 46
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    const-string v4, "Session started, time"

    .line 51
    .line 52
    invoke-virtual {v5, v3, v4}, LP8/b;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    const-wide/16 v3, 0x3e8

    .line 56
    .line 57
    div-long v7, p1, v3

    .line 58
    .line 59
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    iget-object v0, v0, LX3/n0;->m:LX3/P0;

    .line 64
    .line 65
    invoke-static {v0}, LX3/n0;->f(LX3/G;)V

    .line 66
    .line 67
    .line 68
    const-string v4, "auto"

    .line 69
    .line 70
    const-string v5, "_sid"

    .line 71
    .line 72
    move-wide v1, p1

    .line 73
    invoke-virtual/range {v0 .. v5}, LX3/P0;->C0(JLjava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    invoke-static {v6}, LX3/n0;->e(LD/o;)V

    .line 77
    .line 78
    .line 79
    iget-object v1, v6, LX3/d0;->q:LX3/b0;

    .line 80
    .line 81
    invoke-virtual {v1, v7, v8}, LX3/b0;->g(J)V

    .line 82
    .line 83
    .line 84
    iget-object v1, v6, LX3/d0;->l:LX3/a0;

    .line 85
    .line 86
    const/4 v2, 0x0

    .line 87
    invoke-virtual {v1, v2}, LX3/a0;->b(Z)V

    .line 88
    .line 89
    .line 90
    new-instance v3, Landroid/os/Bundle;

    .line 91
    .line 92
    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    .line 93
    .line 94
    .line 95
    const-string v1, "_sid"

    .line 96
    .line 97
    invoke-virtual {v3, v1, v7, v8}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 98
    .line 99
    .line 100
    invoke-static {v0}, LX3/n0;->f(LX3/G;)V

    .line 101
    .line 102
    .line 103
    const-string v4, "auto"

    .line 104
    .line 105
    const-string v5, "_s"

    .line 106
    .line 107
    move-wide v1, p1

    .line 108
    invoke-virtual/range {v0 .. v5}, LX3/P0;->z0(JLandroid/os/Bundle;Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    iget-object v1, v6, LX3/d0;->v:LE1/b;

    .line 112
    .line 113
    invoke-virtual {v1}, LE1/b;->i()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 118
    .line 119
    .line 120
    move-result v2

    .line 121
    if-nez v2, :cond_1

    .line 122
    .line 123
    new-instance v3, Landroid/os/Bundle;

    .line 124
    .line 125
    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    .line 126
    .line 127
    .line 128
    const-string v2, "_ffr"

    .line 129
    .line 130
    invoke-virtual {v3, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v0}, LX3/n0;->f(LX3/G;)V

    .line 134
    .line 135
    .line 136
    const-string v4, "auto"

    .line 137
    .line 138
    const-string v5, "_ssr"

    .line 139
    .line 140
    move-wide v1, p1

    .line 141
    invoke-virtual/range {v0 .. v5}, LX3/P0;->z0(JLandroid/os/Bundle;Ljava/lang/String;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    :cond_1
    :goto_0
    return-void
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p1, LD3/d;

    .line 2
    .line 3
    check-cast p2, Lb4/i;

    .line 4
    .line 5
    invoke-virtual {p1}, LB3/e;->u()Landroid/os/IInterface;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, LD3/a;

    .line 10
    .line 11
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, LB3/m;

    .line 14
    .line 15
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    iget-object v2, p1, LO3/a;->g:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    sget v2, LP3/a;->a:I

    .line 25
    .line 26
    const/4 v2, 0x1

    .line 27
    const/4 v3, 0x0

    .line 28
    if-nez v0, :cond_0

    .line 29
    .line 30
    invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInt(I)V

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    invoke-virtual {v1, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0, v1, v3}, LB3/m;->writeToParcel(Landroid/os/Parcel;I)V

    .line 38
    .line 39
    .line 40
    :goto_0
    :try_start_0
    iget-object p1, p1, LO3/a;->f:Landroid/os/IBinder;

    .line 41
    .line 42
    const/4 v0, 0x0

    .line 43
    invoke-interface {p1, v2, v1, v0, v2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 44
    .line 45
    .line 46
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p2, v0}, Lb4/i;->b(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :catchall_0
    move-exception p1

    .line 54
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 55
    .line 56
    .line 57
    throw p1
.end method

.method public b(LK1/a;Landroid/graphics/Bitmap;Ljava/util/Map;)V
    .locals 2

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LK1/g;

    .line 4
    .line 5
    invoke-static {p2}, Lcom/google/android/gms/internal/measurement/e2;->i(Landroid/graphics/Bitmap;)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    invoke-virtual {v0, p1, p2, p3, v1}, LK1/g;->o(LK1/a;Landroid/graphics/Bitmap;Ljava/util/Map;I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public b0(LX3/z0;LX3/h;)V
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/EnumMap;

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public close()V
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/ContentProviderClient;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/content/ContentProviderClient;->release()Z

    .line 8
    .line 9
    .line 10
    :cond_0
    return-void
.end method

.method public d()Z
    .locals 5

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [LJ2/g0;

    .line 4
    .line 5
    array-length v1, v0

    .line 6
    const/4 v2, 0x0

    .line 7
    move v3, v2

    .line 8
    :goto_0
    if-ge v3, v1, :cond_1

    .line 9
    .line 10
    aget-object v4, v0, v3

    .line 11
    .line 12
    invoke-interface {v4}, LJ2/g0;->d()Z

    .line 13
    .line 14
    .line 15
    move-result v4

    .line 16
    if-eqz v4, :cond_0

    .line 17
    .line 18
    const/4 v0, 0x1

    .line 19
    return v0

    .line 20
    :cond_0
    add-int/lit8 v3, v3, 0x1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    return v2
.end method

.method public e(La9/x;)Ljava/lang/Object;
    .locals 3

    .line 1
    new-instance v0, La9/i;

    .line 2
    .line 3
    invoke-direct {v0, p1}, La9/i;-><init>(La9/x;)V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lo3/i;

    .line 7
    .line 8
    const/16 v2, 0x1a

    .line 9
    .line 10
    invoke-direct {v1, v2, v0}, Lo3/i;-><init>(ILjava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p1, v1}, La9/x;->f(La9/g;)V

    .line 14
    .line 15
    .line 16
    return-object v0
.end method

.method public f(Landroid/net/Uri;[Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    .locals 8

    .line 1
    const-string v3, "query = ?"

    .line 2
    .line 3
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Landroid/content/ContentProviderClient;

    .line 6
    .line 7
    const/4 v7, 0x0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    return-object v7

    .line 11
    :cond_0
    const/4 v5, 0x0

    .line 12
    const/4 v6, 0x0

    .line 13
    move-object v1, p1

    .line 14
    move-object v2, p2

    .line 15
    move-object v4, p3

    .line 16
    :try_start_0
    invoke-virtual/range {v0 .. v6}, Landroid/content/ContentProviderClient;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    .line 17
    .line 18
    .line 19
    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 20
    return-object p1

    .line 21
    :catch_0
    move-exception v0

    .line 22
    move-object p1, v0

    .line 23
    const-string p2, "FontsProvider"

    .line 24
    .line 25
    const-string p3, "Unable to query the content provider"

    .line 26
    .line 27
    invoke-static {p2, p3, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 28
    .line 29
    .line 30
    return-object v7
.end method

.method public g(LK1/a;)LK1/b;
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    return-object p1
.end method

.method public h(II)V
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LG0/K;

    .line 4
    .line 5
    iget-object v0, v0, LG0/V;->a:LG0/W;

    .line 6
    .line 7
    invoke-virtual {v0, p1, p2}, LG0/W;->f(II)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public i(La9/d;La9/N;)V
    .locals 1

    .line 1
    iget-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, La9/i;

    .line 4
    .line 5
    iget-object v0, p2, La9/N;->a:LL8/H;

    .line 6
    .line 7
    invoke-virtual {v0}, LL8/H;->f()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    iget-object p2, p2, La9/N;->b:Ljava/lang/Object;

    .line 14
    .line 15
    invoke-static {p1, p2}, LE0/a;->q(La9/i;Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    new-instance v0, La9/o;

    .line 20
    .line 21
    invoke-direct {v0, p2}, La9/o;-><init>(La9/N;)V

    .line 22
    .line 23
    .line 24
    invoke-static {p1, v0}, LE0/a;->o(La9/i;La9/o;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public j(II)V
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LG0/K;

    .line 4
    .line 5
    iget-object v0, v0, LG0/V;->a:LG0/W;

    .line 6
    .line 7
    invoke-virtual {v0, p1, p2}, LG0/W;->c(II)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public k()I
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/ContentInfo;

    .line 4
    .line 5
    invoke-static {v0}, LG3/g;->a(Landroid/view/ContentInfo;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    return v0
.end method

.method public l()Landroid/content/ClipData;
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/ContentInfo;

    .line 4
    .line 5
    invoke-static {v0}, LG3/g;->b(Landroid/view/ContentInfo;)Landroid/content/ClipData;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0
.end method

.method public m()I
    .locals 2

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/recyclerview/widget/a;

    .line 4
    .line 5
    iget v1, v0, Landroidx/recyclerview/widget/a;->o:I

    .line 6
    .line 7
    invoke-virtual {v0}, Landroidx/recyclerview/widget/a;->H()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    sub-int/2addr v1, v0

    .line 12
    return v1
.end method

.method public n(I)J
    .locals 2

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    return-wide v0
.end method

.method public o(Landroid/view/View;)I
    .locals 1

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, LG0/f0;

    .line 6
    .line 7
    invoke-static {p1}, Landroidx/recyclerview/widget/a;->F(Landroid/view/View;)I

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 12
    .line 13
    sub-int/2addr p1, v0

    .line 14
    return p1
.end method

.method public p()J
    .locals 11

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [LJ2/g0;

    .line 4
    .line 5
    array-length v1, v0

    .line 6
    const-wide v2, 0x7fffffffffffffffL

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    move-wide v5, v2

    .line 13
    :goto_0
    const-wide/high16 v7, -0x8000000000000000L

    .line 14
    .line 15
    if-ge v4, v1, :cond_1

    .line 16
    .line 17
    aget-object v9, v0, v4

    .line 18
    .line 19
    invoke-interface {v9}, LJ2/g0;->p()J

    .line 20
    .line 21
    .line 22
    move-result-wide v9

    .line 23
    cmp-long v7, v9, v7

    .line 24
    .line 25
    if-eqz v7, :cond_0

    .line 26
    .line 27
    invoke-static {v5, v6, v9, v10}, Ljava/lang/Math;->min(JJ)J

    .line 28
    .line 29
    .line 30
    move-result-wide v5

    .line 31
    :cond_0
    add-int/lit8 v4, v4, 0x1

    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_1
    cmp-long v0, v5, v2

    .line 35
    .line 36
    if-nez v0, :cond_2

    .line 37
    .line 38
    return-wide v7

    .line 39
    :cond_2
    return-wide v5
.end method

.method public r(Lg3/K;JJZ)V
    .locals 12

    .line 1
    check-cast p1, Lg3/Q;

    .line 2
    .line 3
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, LM2/h;

    .line 6
    .line 7
    new-instance v2, LJ2/q;

    .line 8
    .line 9
    iget-wide v3, p1, Lg3/Q;->a:J

    .line 10
    .line 11
    iget-object v1, p1, Lg3/Q;->d:Lg3/W;

    .line 12
    .line 13
    iget-object v1, v1, Lg3/W;->c:Landroid/net/Uri;

    .line 14
    .line 15
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    iget-object v1, v0, LM2/h;->n:Lg1/q;

    .line 19
    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    iget-object v1, v0, LM2/h;->q:LJ2/H;

    .line 24
    .line 25
    iget v3, p1, Lg3/Q;->c:I

    .line 26
    .line 27
    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    const-wide v10, -0x7fffffffffffffffL    # -4.9E-324

    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    const/4 v4, -0x1

    .line 38
    const/4 v5, 0x0

    .line 39
    const/4 v6, 0x0

    .line 40
    const/4 v7, 0x0

    .line 41
    invoke-virtual/range {v1 .. v11}, LJ2/H;->d(LJ2/q;IILf2/N;ILjava/lang/Object;JJ)V

    .line 42
    .line 43
    .line 44
    return-void
.end method

.method public s()Ljava/lang/reflect/Type;
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/reflect/Type;

    .line 4
    .line 5
    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    .line 1
    iget v0, p0, LA5/g;->a:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :sswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "1"

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-static {}, LX3/z0;->values()[LX3/z0;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    array-length v2, v1

    .line 23
    const/4 v3, 0x0

    .line 24
    :goto_0
    if-ge v3, v2, :cond_1

    .line 25
    .line 26
    aget-object v4, v1, v3

    .line 27
    .line 28
    iget-object v5, p0, LA5/g;->b:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v5, Ljava/util/EnumMap;

    .line 31
    .line 32
    invoke-virtual {v5, v4}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    check-cast v4, LX3/h;

    .line 37
    .line 38
    if-nez v4, :cond_0

    .line 39
    .line 40
    sget-object v4, LX3/h;->b:LX3/h;

    .line 41
    .line 42
    :cond_0
    iget-char v4, v4, LX3/h;->a:C

    .line 43
    .line 44
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    add-int/lit8 v3, v3, 0x1

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    return-object v0

    .line 55
    :sswitch_1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 56
    .line 57
    const-string v1, "ContentInfoCompat{"

    .line 58
    .line 59
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    iget-object v1, p0, LA5/g;->b:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast v1, Landroid/view/ContentInfo;

    .line 65
    .line 66
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    const-string v1, "}"

    .line 70
    .line 71
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    return-object v0

    .line 79
    :sswitch_data_0
    .sparse-switch
        0x10 -> :sswitch_1
        0x16 -> :sswitch_0
    .end sparse-switch
.end method

.method public u(Landroid/view/View;LP/x0;)LP/x0;
    .locals 1

    .line 1
    iget-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, LF4/i;

    .line 4
    .line 5
    invoke-virtual {p2}, LP/x0;->a()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    iput v0, p1, LF4/i;->l:I

    .line 10
    .line 11
    invoke-virtual {p2}, LP/x0;->b()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    iput v0, p1, LF4/i;->m:I

    .line 16
    .line 17
    invoke-virtual {p2}, LP/x0;->c()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    iput v0, p1, LF4/i;->n:I

    .line 22
    .line 23
    invoke-virtual {p1}, LF4/i;->e()V

    .line 24
    .line 25
    .line 26
    return-object p2
.end method

.method public v(La9/d;Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    iget-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, La9/i;

    .line 4
    .line 5
    invoke-static {p1, p2}, LE0/a;->r(La9/i;Ljava/lang/Throwable;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public w()Landroid/view/ContentInfo;
    .locals 1

    .line 1
    iget-object v0, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/view/ContentInfo;

    .line 4
    .line 5
    return-object v0
.end method

.method public y(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public z(J)Ljava/util/List;
    .locals 0

    .line 1
    iget-object p1, p0, LA5/g;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, Ljava/util/List;

    .line 4
    .line 5
    return-object p1
.end method
