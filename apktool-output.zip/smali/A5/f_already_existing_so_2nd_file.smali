.class public final LA5/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;

.field public h:Ljava/lang/Object;

.field public i:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroidx/work/impl/WorkDatabase_Impl;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LA5/f;->a:Ljava/lang/Object;

    .line 5
    .line 6
    new-instance v0, Lp1/b;

    .line 7
    .line 8
    const/4 v1, 0x5

    .line 9
    invoke-direct {v0, p1, v1}, Lp1/b;-><init>(LH0/w;I)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, LA5/f;->b:Ljava/lang/Object;

    .line 13
    .line 14
    new-instance v0, Lp1/e;

    .line 15
    .line 16
    const/4 v1, 0x3

    .line 17
    invoke-direct {v0, p1, v1}, Lp1/e;-><init>(LH0/w;I)V

    .line 18
    .line 19
    .line 20
    iput-object v0, p0, LA5/f;->c:Ljava/lang/Object;

    .line 21
    .line 22
    new-instance v0, Lp1/e;

    .line 23
    .line 24
    const/4 v1, 0x4

    .line 25
    invoke-direct {v0, p1, v1}, Lp1/e;-><init>(LH0/w;I)V

    .line 26
    .line 27
    .line 28
    iput-object v0, p0, LA5/f;->d:Ljava/lang/Object;

    .line 29
    .line 30
    new-instance v0, Lp1/e;

    .line 31
    .line 32
    const/4 v1, 0x5

    .line 33
    invoke-direct {v0, p1, v1}, Lp1/e;-><init>(LH0/w;I)V

    .line 34
    .line 35
    .line 36
    iput-object v0, p0, LA5/f;->e:Ljava/lang/Object;

    .line 37
    .line 38
    new-instance v0, Lp1/e;

    .line 39
    .line 40
    const/4 v1, 0x6

    .line 41
    invoke-direct {v0, p1, v1}, Lp1/e;-><init>(LH0/w;I)V

    .line 42
    .line 43
    .line 44
    iput-object v0, p0, LA5/f;->f:Ljava/lang/Object;

    .line 45
    .line 46
    new-instance v0, Lp1/e;

    .line 47
    .line 48
    const/4 v1, 0x7

    .line 49
    invoke-direct {v0, p1, v1}, Lp1/e;-><init>(LH0/w;I)V

    .line 50
    .line 51
    .line 52
    iput-object v0, p0, LA5/f;->g:Ljava/lang/Object;

    .line 53
    .line 54
    new-instance v0, Lp1/e;

    .line 55
    .line 56
    const/16 v1, 0x8

    .line 57
    .line 58
    invoke-direct {v0, p1, v1}, Lp1/e;-><init>(LH0/w;I)V

    .line 59
    .line 60
    .line 61
    iput-object v0, p0, LA5/f;->h:Ljava/lang/Object;

    .line 62
    .line 63
    new-instance v0, Lp1/e;

    .line 64
    .line 65
    const/16 v1, 0x9

    .line 66
    .line 67
    invoke-direct {v0, p1, v1}, Lp1/e;-><init>(LH0/w;I)V

    .line 68
    .line 69
    .line 70
    iput-object v0, p0, LA5/f;->i:Ljava/lang/Object;

    .line 71
    .line 72
    new-instance v0, Lp1/e;

    .line 73
    .line 74
    const/16 v1, 0xa

    .line 75
    .line 76
    invoke-direct {v0, p1, v1}, Lp1/e;-><init>(LH0/w;I)V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public static n(Lorg/json/JSONObject;Ljava/lang/String;)V
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    const-string p1, "FirebaseCrashlytics"

    .line 21
    .line 22
    const/4 v0, 0x3

    .line 23
    invoke-static {p1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_0

    .line 28
    .line 29
    const/4 v0, 0x0

    .line 30
    invoke-static {p1, p0, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 31
    .line 32
    .line 33
    :cond_0
    return-void
.end method


# virtual methods
.method public a(Lr/e;)V
    .locals 8

    .line 1
    invoke-virtual {p1}, Lr/e;->keySet()Ljava/util/Set;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lr/b;

    .line 6
    .line 7
    iget-object v1, v0, Lr/b;->a:Lr/e;

    .line 8
    .line 9
    invoke-virtual {v1}, Lr/i;->isEmpty()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    if-eqz v2, :cond_0

    .line 14
    .line 15
    goto :goto_1

    .line 16
    :cond_0
    iget v2, p1, Lr/i;->c:I

    .line 17
    .line 18
    const/16 v3, 0x3e7

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    if-le v2, v3, :cond_4

    .line 22
    .line 23
    new-instance v0, Lr/e;

    .line 24
    .line 25
    invoke-direct {v0, v3}, Lr/i;-><init>(I)V

    .line 26
    .line 27
    .line 28
    iget v1, p1, Lr/i;->c:I

    .line 29
    .line 30
    move v2, v4

    .line 31
    move v5, v2

    .line 32
    :cond_1
    :goto_0
    if-ge v2, v1, :cond_2

    .line 33
    .line 34
    invoke-virtual {p1, v2}, Lr/i;->f(I)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v6

    .line 38
    check-cast v6, Ljava/lang/String;

    .line 39
    .line 40
    invoke-virtual {p1, v2}, Lr/i;->i(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v7

    .line 44
    check-cast v7, Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-virtual {v0, v6, v7}, Lr/i;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    add-int/lit8 v2, v2, 0x1

    .line 50
    .line 51
    add-int/lit8 v5, v5, 0x1

    .line 52
    .line 53
    if-ne v5, v3, :cond_1

    .line 54
    .line 55
    invoke-virtual {p0, v0}, LA5/f;->a(Lr/e;)V

    .line 56
    .line 57
    .line 58
    new-instance v0, Lr/e;

    .line 59
    .line 60
    invoke-direct {v0, v3}, Lr/i;-><init>(I)V

    .line 61
    .line 62
    .line 63
    move v5, v4

    .line 64
    goto :goto_0

    .line 65
    :cond_2
    if-lez v5, :cond_3

    .line 66
    .line 67
    invoke-virtual {p0, v0}, LA5/f;->a(Lr/e;)V

    .line 68
    .line 69
    .line 70
    :cond_3
    :goto_1
    return-void

    .line 71
    :cond_4
    new-instance v2, Ljava/lang/StringBuilder;

    .line 72
    .line 73
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 74
    .line 75
    .line 76
    const-string v3, "SELECT `progress`,`work_spec_id` FROM `WorkProgress` WHERE `work_spec_id` IN ("

    .line 77
    .line 78
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    iget v1, v1, Lr/i;->c:I

    .line 82
    .line 83
    invoke-static {v1, v2}, LK3/h;->a(ILjava/lang/StringBuilder;)V

    .line 84
    .line 85
    .line 86
    const-string v3, ")"

    .line 87
    .line 88
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v2

    .line 95
    invoke-static {v1, v2}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-virtual {v0}, Lr/b;->iterator()Ljava/util/Iterator;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    const/4 v2, 0x1

    .line 104
    :goto_2
    move-object v3, v0

    .line 105
    check-cast v3, Lr/a;

    .line 106
    .line 107
    invoke-virtual {v3}, Lr/a;->hasNext()Z

    .line 108
    .line 109
    .line 110
    move-result v5

    .line 111
    if-eqz v5, :cond_6

    .line 112
    .line 113
    invoke-virtual {v3}, Lr/a;->next()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v3

    .line 117
    check-cast v3, Ljava/lang/String;

    .line 118
    .line 119
    if-nez v3, :cond_5

    .line 120
    .line 121
    invoke-virtual {v1, v2}, LH0/B;->b(I)V

    .line 122
    .line 123
    .line 124
    goto :goto_3

    .line 125
    :cond_5
    invoke-virtual {v1, v2, v3}, LH0/B;->p(ILjava/lang/String;)V

    .line 126
    .line 127
    .line 128
    :goto_3
    add-int/lit8 v2, v2, 0x1

    .line 129
    .line 130
    goto :goto_2

    .line 131
    :cond_6
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 134
    .line 135
    invoke-static {v0, v1, v4}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    :try_start_0
    const-string v1, "work_spec_id"

    .line 140
    .line 141
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/measurement/e2;->m(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 142
    .line 143
    .line 144
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 145
    const/4 v2, -0x1

    .line 146
    if-ne v1, v2, :cond_7

    .line 147
    .line 148
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 149
    .line 150
    .line 151
    return-void

    .line 152
    :cond_7
    :goto_4
    :try_start_1
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    .line 153
    .line 154
    .line 155
    move-result v2

    .line 156
    if-eqz v2, :cond_8

    .line 157
    .line 158
    invoke-interface {v0, v1}, Landroid/database/Cursor;->isNull(I)Z

    .line 159
    .line 160
    .line 161
    move-result v2

    .line 162
    if-nez v2, :cond_7

    .line 163
    .line 164
    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    invoke-virtual {p1, v2}, Lr/i;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    check-cast v2, Ljava/util/ArrayList;

    .line 173
    .line 174
    if-eqz v2, :cond_7

    .line 175
    .line 176
    invoke-interface {v0, v4}, Landroid/database/Cursor;->getBlob(I)[B

    .line 177
    .line 178
    .line 179
    move-result-object v3

    .line 180
    invoke-static {v3}, Lg1/h;->a([B)Lg1/h;

    .line 181
    .line 182
    .line 183
    move-result-object v3

    .line 184
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 185
    .line 186
    .line 187
    goto :goto_4

    .line 188
    :catchall_0
    move-exception p1

    .line 189
    goto :goto_5

    .line 190
    :cond_8
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 191
    .line 192
    .line 193
    return-void

    .line 194
    :goto_5
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 195
    .line 196
    .line 197
    throw p1
.end method

.method public b(Lr/e;)V
    .locals 8

    .line 1
    invoke-virtual {p1}, Lr/e;->keySet()Ljava/util/Set;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lr/b;

    .line 6
    .line 7
    iget-object v1, v0, Lr/b;->a:Lr/e;

    .line 8
    .line 9
    invoke-virtual {v1}, Lr/i;->isEmpty()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    if-eqz v2, :cond_0

    .line 14
    .line 15
    goto :goto_1

    .line 16
    :cond_0
    iget v2, p1, Lr/i;->c:I

    .line 17
    .line 18
    const/16 v3, 0x3e7

    .line 19
    .line 20
    const/4 v4, 0x0

    .line 21
    if-le v2, v3, :cond_4

    .line 22
    .line 23
    new-instance v0, Lr/e;

    .line 24
    .line 25
    invoke-direct {v0, v3}, Lr/i;-><init>(I)V

    .line 26
    .line 27
    .line 28
    iget v1, p1, Lr/i;->c:I

    .line 29
    .line 30
    move v2, v4

    .line 31
    move v5, v2

    .line 32
    :cond_1
    :goto_0
    if-ge v2, v1, :cond_2

    .line 33
    .line 34
    invoke-virtual {p1, v2}, Lr/i;->f(I)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v6

    .line 38
    check-cast v6, Ljava/lang/String;

    .line 39
    .line 40
    invoke-virtual {p1, v2}, Lr/i;->i(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v7

    .line 44
    check-cast v7, Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-virtual {v0, v6, v7}, Lr/i;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    add-int/lit8 v2, v2, 0x1

    .line 50
    .line 51
    add-int/lit8 v5, v5, 0x1

    .line 52
    .line 53
    if-ne v5, v3, :cond_1

    .line 54
    .line 55
    invoke-virtual {p0, v0}, LA5/f;->b(Lr/e;)V

    .line 56
    .line 57
    .line 58
    new-instance v0, Lr/e;

    .line 59
    .line 60
    invoke-direct {v0, v3}, Lr/i;-><init>(I)V

    .line 61
    .line 62
    .line 63
    move v5, v4

    .line 64
    goto :goto_0

    .line 65
    :cond_2
    if-lez v5, :cond_3

    .line 66
    .line 67
    invoke-virtual {p0, v0}, LA5/f;->b(Lr/e;)V

    .line 68
    .line 69
    .line 70
    :cond_3
    :goto_1
    return-void

    .line 71
    :cond_4
    new-instance v2, Ljava/lang/StringBuilder;

    .line 72
    .line 73
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 74
    .line 75
    .line 76
    const-string v3, "SELECT `tag`,`work_spec_id` FROM `WorkTag` WHERE `work_spec_id` IN ("

    .line 77
    .line 78
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    iget v1, v1, Lr/i;->c:I

    .line 82
    .line 83
    invoke-static {v1, v2}, LK3/h;->a(ILjava/lang/StringBuilder;)V

    .line 84
    .line 85
    .line 86
    const-string v3, ")"

    .line 87
    .line 88
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v2

    .line 95
    invoke-static {v1, v2}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 96
    .line 97
    .line 98
    move-result-object v1

    .line 99
    invoke-virtual {v0}, Lr/b;->iterator()Ljava/util/Iterator;

    .line 100
    .line 101
    .line 102
    move-result-object v0

    .line 103
    const/4 v2, 0x1

    .line 104
    :goto_2
    move-object v3, v0

    .line 105
    check-cast v3, Lr/a;

    .line 106
    .line 107
    invoke-virtual {v3}, Lr/a;->hasNext()Z

    .line 108
    .line 109
    .line 110
    move-result v5

    .line 111
    if-eqz v5, :cond_6

    .line 112
    .line 113
    invoke-virtual {v3}, Lr/a;->next()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v3

    .line 117
    check-cast v3, Ljava/lang/String;

    .line 118
    .line 119
    if-nez v3, :cond_5

    .line 120
    .line 121
    invoke-virtual {v1, v2}, LH0/B;->b(I)V

    .line 122
    .line 123
    .line 124
    goto :goto_3

    .line 125
    :cond_5
    invoke-virtual {v1, v2, v3}, LH0/B;->p(ILjava/lang/String;)V

    .line 126
    .line 127
    .line 128
    :goto_3
    add-int/lit8 v2, v2, 0x1

    .line 129
    .line 130
    goto :goto_2

    .line 131
    :cond_6
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 134
    .line 135
    invoke-static {v0, v1, v4}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    :try_start_0
    const-string v1, "work_spec_id"

    .line 140
    .line 141
    invoke-static {v0, v1}, Lcom/google/android/gms/internal/measurement/e2;->m(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 142
    .line 143
    .line 144
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 145
    const/4 v2, -0x1

    .line 146
    if-ne v1, v2, :cond_7

    .line 147
    .line 148
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 149
    .line 150
    .line 151
    return-void

    .line 152
    :cond_7
    :goto_4
    :try_start_1
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    .line 153
    .line 154
    .line 155
    move-result v2

    .line 156
    if-eqz v2, :cond_8

    .line 157
    .line 158
    invoke-interface {v0, v1}, Landroid/database/Cursor;->isNull(I)Z

    .line 159
    .line 160
    .line 161
    move-result v2

    .line 162
    if-nez v2, :cond_7

    .line 163
    .line 164
    invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v2

    .line 168
    invoke-virtual {p1, v2}, Lr/i;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v2

    .line 172
    check-cast v2, Ljava/util/ArrayList;

    .line 173
    .line 174
    if-eqz v2, :cond_7

    .line 175
    .line 176
    invoke-interface {v0, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v3

    .line 180
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 181
    .line 182
    .line 183
    goto :goto_4

    .line 184
    :catchall_0
    move-exception p1

    .line 185
    goto :goto_5

    .line 186
    :cond_8
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 187
    .line 188
    .line 189
    return-void

    .line 190
    :goto_5
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 191
    .line 192
    .line 193
    throw p1
.end method

.method public c(Ljava/lang/String;)V
    .locals 4

    .line 1
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, LH0/w;->b()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LA5/f;->c:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lp1/e;

    .line 11
    .line 12
    invoke-virtual {v1}, LH0/C;->a()LT0/j;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x1

    .line 17
    if-nez p1, :cond_0

    .line 18
    .line 19
    invoke-interface {v2, v3}, LS0/e;->b(I)V

    .line 20
    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    invoke-interface {v2, v3, p1}, LS0/e;->p(ILjava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :goto_0
    invoke-virtual {v0}, LH0/w;->c()V

    .line 27
    .line 28
    .line 29
    :try_start_0
    invoke-virtual {v2}, LT0/j;->a()I

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, LH0/w;->q()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 33
    .line 34
    .line 35
    invoke-virtual {v0}, LH0/w;->n()V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v1, v2}, LH0/C;->i(LT0/j;)V

    .line 39
    .line 40
    .line 41
    return-void

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    invoke-virtual {v0}, LH0/w;->n()V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v1, v2}, LH0/C;->i(LT0/j;)V

    .line 47
    .line 48
    .line 49
    throw p1
.end method

.method public d()Ljava/util/ArrayList;
    .locals 33

    .line 1
    const/4 v0, 0x1

    .line 2
    const-string v1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 ORDER BY period_start_time LIMIT ?"

    .line 3
    .line 4
    invoke-static {v0, v1}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    const/16 v2, 0xc8

    .line 9
    .line 10
    int-to-long v2, v2

    .line 11
    invoke-virtual {v1, v2, v3, v0}, LH0/B;->d(JI)V

    .line 12
    .line 13
    .line 14
    move-object/from16 v2, p0

    .line 15
    .line 16
    iget-object v3, v2, LA5/f;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v3, Landroidx/work/impl/WorkDatabase_Impl;

    .line 19
    .line 20
    invoke-virtual {v3}, LH0/w;->b()V

    .line 21
    .line 22
    .line 23
    const/4 v4, 0x0

    .line 24
    invoke-static {v3, v1, v4}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    :try_start_0
    const-string v5, "required_network_type"

    .line 29
    .line 30
    invoke-static {v3, v5}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    const-string v6, "requires_charging"

    .line 35
    .line 36
    invoke-static {v3, v6}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 37
    .line 38
    .line 39
    move-result v6

    .line 40
    const-string v7, "requires_device_idle"

    .line 41
    .line 42
    invoke-static {v3, v7}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    const-string v8, "requires_battery_not_low"

    .line 47
    .line 48
    invoke-static {v3, v8}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 49
    .line 50
    .line 51
    move-result v8

    .line 52
    const-string v9, "requires_storage_not_low"

    .line 53
    .line 54
    invoke-static {v3, v9}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 55
    .line 56
    .line 57
    move-result v9

    .line 58
    const-string v10, "trigger_content_update_delay"

    .line 59
    .line 60
    invoke-static {v3, v10}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 61
    .line 62
    .line 63
    move-result v10

    .line 64
    const-string v11, "trigger_max_content_delay"

    .line 65
    .line 66
    invoke-static {v3, v11}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 67
    .line 68
    .line 69
    move-result v11

    .line 70
    const-string v12, "content_uri_triggers"

    .line 71
    .line 72
    invoke-static {v3, v12}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 73
    .line 74
    .line 75
    move-result v12

    .line 76
    const-string v13, "id"

    .line 77
    .line 78
    invoke-static {v3, v13}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 79
    .line 80
    .line 81
    move-result v13

    .line 82
    const-string v14, "state"

    .line 83
    .line 84
    invoke-static {v3, v14}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 85
    .line 86
    .line 87
    move-result v14

    .line 88
    const-string v15, "worker_class_name"

    .line 89
    .line 90
    invoke-static {v3, v15}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 91
    .line 92
    .line 93
    move-result v15

    .line 94
    const-string v0, "input_merger_class_name"

    .line 95
    .line 96
    invoke-static {v3, v0}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    const-string v4, "input"

    .line 101
    .line 102
    invoke-static {v3, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 103
    .line 104
    .line 105
    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 106
    move-object/from16 v16, v1

    .line 107
    .line 108
    :try_start_1
    const-string v1, "output"

    .line 109
    .line 110
    invoke-static {v3, v1}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    const-string v2, "initial_delay"

    .line 115
    .line 116
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    move/from16 v17, v2

    .line 121
    .line 122
    const-string v2, "interval_duration"

    .line 123
    .line 124
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 125
    .line 126
    .line 127
    move-result v2

    .line 128
    move/from16 v18, v2

    .line 129
    .line 130
    const-string v2, "flex_duration"

    .line 131
    .line 132
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 133
    .line 134
    .line 135
    move-result v2

    .line 136
    move/from16 v19, v2

    .line 137
    .line 138
    const-string v2, "run_attempt_count"

    .line 139
    .line 140
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 141
    .line 142
    .line 143
    move-result v2

    .line 144
    move/from16 v20, v2

    .line 145
    .line 146
    const-string v2, "backoff_policy"

    .line 147
    .line 148
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 149
    .line 150
    .line 151
    move-result v2

    .line 152
    move/from16 v21, v2

    .line 153
    .line 154
    const-string v2, "backoff_delay_duration"

    .line 155
    .line 156
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 157
    .line 158
    .line 159
    move-result v2

    .line 160
    move/from16 v22, v2

    .line 161
    .line 162
    const-string v2, "period_start_time"

    .line 163
    .line 164
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    move/from16 v23, v2

    .line 169
    .line 170
    const-string v2, "minimum_retention_duration"

    .line 171
    .line 172
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 173
    .line 174
    .line 175
    move-result v2

    .line 176
    move/from16 v24, v2

    .line 177
    .line 178
    const-string v2, "schedule_requested_at"

    .line 179
    .line 180
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 181
    .line 182
    .line 183
    move-result v2

    .line 184
    move/from16 v25, v2

    .line 185
    .line 186
    const-string v2, "run_in_foreground"

    .line 187
    .line 188
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 189
    .line 190
    .line 191
    move-result v2

    .line 192
    move/from16 v26, v2

    .line 193
    .line 194
    const-string v2, "out_of_quota_policy"

    .line 195
    .line 196
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 197
    .line 198
    .line 199
    move-result v2

    .line 200
    move/from16 v27, v2

    .line 201
    .line 202
    new-instance v2, Ljava/util/ArrayList;

    .line 203
    .line 204
    move/from16 v28, v1

    .line 205
    .line 206
    invoke-interface {v3}, Landroid/database/Cursor;->getCount()I

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 211
    .line 212
    .line 213
    :goto_0
    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    .line 214
    .line 215
    .line 216
    move-result v1

    .line 217
    if-eqz v1, :cond_5

    .line 218
    .line 219
    invoke-interface {v3, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object v1

    .line 223
    move/from16 v29, v13

    .line 224
    .line 225
    invoke-interface {v3, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object v13

    .line 229
    move/from16 v30, v15

    .line 230
    .line 231
    new-instance v15, Lg1/c;

    .line 232
    .line 233
    invoke-direct {v15}, Lg1/c;-><init>()V

    .line 234
    .line 235
    .line 236
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 237
    .line 238
    .line 239
    move-result v31

    .line 240
    move/from16 v32, v5

    .line 241
    .line 242
    invoke-static/range {v31 .. v31}, La/a;->y(I)I

    .line 243
    .line 244
    .line 245
    move-result v5

    .line 246
    iput v5, v15, Lg1/c;->a:I

    .line 247
    .line 248
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 249
    .line 250
    .line 251
    move-result v5

    .line 252
    if-eqz v5, :cond_0

    .line 253
    .line 254
    const/4 v5, 0x1

    .line 255
    goto :goto_1

    .line 256
    :cond_0
    const/4 v5, 0x0

    .line 257
    :goto_1
    iput-boolean v5, v15, Lg1/c;->b:Z

    .line 258
    .line 259
    invoke-interface {v3, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 260
    .line 261
    .line 262
    move-result v5

    .line 263
    if-eqz v5, :cond_1

    .line 264
    .line 265
    const/4 v5, 0x1

    .line 266
    goto :goto_2

    .line 267
    :cond_1
    const/4 v5, 0x0

    .line 268
    :goto_2
    iput-boolean v5, v15, Lg1/c;->c:Z

    .line 269
    .line 270
    invoke-interface {v3, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 271
    .line 272
    .line 273
    move-result v5

    .line 274
    if-eqz v5, :cond_2

    .line 275
    .line 276
    const/4 v5, 0x1

    .line 277
    goto :goto_3

    .line 278
    :cond_2
    const/4 v5, 0x0

    .line 279
    :goto_3
    iput-boolean v5, v15, Lg1/c;->d:Z

    .line 280
    .line 281
    invoke-interface {v3, v9}, Landroid/database/Cursor;->getInt(I)I

    .line 282
    .line 283
    .line 284
    move-result v5

    .line 285
    if-eqz v5, :cond_3

    .line 286
    .line 287
    const/4 v5, 0x1

    .line 288
    goto :goto_4

    .line 289
    :cond_3
    const/4 v5, 0x0

    .line 290
    :goto_4
    iput-boolean v5, v15, Lg1/c;->e:Z

    .line 291
    .line 292
    move/from16 v31, v6

    .line 293
    .line 294
    invoke-interface {v3, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 295
    .line 296
    .line 297
    move-result-wide v5

    .line 298
    iput-wide v5, v15, Lg1/c;->f:J

    .line 299
    .line 300
    invoke-interface {v3, v11}, Landroid/database/Cursor;->getLong(I)J

    .line 301
    .line 302
    .line 303
    move-result-wide v5

    .line 304
    iput-wide v5, v15, Lg1/c;->g:J

    .line 305
    .line 306
    invoke-interface {v3, v12}, Landroid/database/Cursor;->getBlob(I)[B

    .line 307
    .line 308
    .line 309
    move-result-object v5

    .line 310
    invoke-static {v5}, La/a;->b([B)Lg1/e;

    .line 311
    .line 312
    .line 313
    move-result-object v5

    .line 314
    iput-object v5, v15, Lg1/c;->h:Lg1/e;

    .line 315
    .line 316
    new-instance v5, Lp1/j;

    .line 317
    .line 318
    invoke-direct {v5, v1, v13}, Lp1/j;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 319
    .line 320
    .line 321
    invoke-interface {v3, v14}, Landroid/database/Cursor;->getInt(I)I

    .line 322
    .line 323
    .line 324
    move-result v1

    .line 325
    invoke-static {v1}, La/a;->A(I)I

    .line 326
    .line 327
    .line 328
    move-result v1

    .line 329
    iput v1, v5, Lp1/j;->b:I

    .line 330
    .line 331
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object v1

    .line 335
    iput-object v1, v5, Lp1/j;->d:Ljava/lang/String;

    .line 336
    .line 337
    invoke-interface {v3, v4}, Landroid/database/Cursor;->getBlob(I)[B

    .line 338
    .line 339
    .line 340
    move-result-object v1

    .line 341
    invoke-static {v1}, Lg1/h;->a([B)Lg1/h;

    .line 342
    .line 343
    .line 344
    move-result-object v1

    .line 345
    iput-object v1, v5, Lp1/j;->e:Lg1/h;

    .line 346
    .line 347
    move/from16 v1, v28

    .line 348
    .line 349
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 350
    .line 351
    .line 352
    move-result-object v6

    .line 353
    invoke-static {v6}, Lg1/h;->a([B)Lg1/h;

    .line 354
    .line 355
    .line 356
    move-result-object v6

    .line 357
    iput-object v6, v5, Lp1/j;->f:Lg1/h;

    .line 358
    .line 359
    move v13, v0

    .line 360
    move/from16 v28, v1

    .line 361
    .line 362
    move/from16 v6, v17

    .line 363
    .line 364
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 365
    .line 366
    .line 367
    move-result-wide v0

    .line 368
    iput-wide v0, v5, Lp1/j;->g:J

    .line 369
    .line 370
    move/from16 v17, v6

    .line 371
    .line 372
    move v1, v7

    .line 373
    move/from16 v0, v18

    .line 374
    .line 375
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 376
    .line 377
    .line 378
    move-result-wide v6

    .line 379
    iput-wide v6, v5, Lp1/j;->h:J

    .line 380
    .line 381
    move/from16 v18, v0

    .line 382
    .line 383
    move v7, v1

    .line 384
    move/from16 v6, v19

    .line 385
    .line 386
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 387
    .line 388
    .line 389
    move-result-wide v0

    .line 390
    iput-wide v0, v5, Lp1/j;->i:J

    .line 391
    .line 392
    move/from16 v0, v20

    .line 393
    .line 394
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 395
    .line 396
    .line 397
    move-result v1

    .line 398
    iput v1, v5, Lp1/j;->k:I

    .line 399
    .line 400
    move/from16 v1, v21

    .line 401
    .line 402
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 403
    .line 404
    .line 405
    move-result v19

    .line 406
    move/from16 v20, v0

    .line 407
    .line 408
    invoke-static/range {v19 .. v19}, La/a;->x(I)I

    .line 409
    .line 410
    .line 411
    move-result v0

    .line 412
    iput v0, v5, Lp1/j;->l:I

    .line 413
    .line 414
    move/from16 v19, v6

    .line 415
    .line 416
    move/from16 v21, v7

    .line 417
    .line 418
    move/from16 v0, v22

    .line 419
    .line 420
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 421
    .line 422
    .line 423
    move-result-wide v6

    .line 424
    iput-wide v6, v5, Lp1/j;->m:J

    .line 425
    .line 426
    move/from16 v22, v0

    .line 427
    .line 428
    move v7, v1

    .line 429
    move/from16 v6, v23

    .line 430
    .line 431
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 432
    .line 433
    .line 434
    move-result-wide v0

    .line 435
    iput-wide v0, v5, Lp1/j;->n:J

    .line 436
    .line 437
    move/from16 v23, v6

    .line 438
    .line 439
    move v1, v7

    .line 440
    move/from16 v0, v24

    .line 441
    .line 442
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 443
    .line 444
    .line 445
    move-result-wide v6

    .line 446
    iput-wide v6, v5, Lp1/j;->o:J

    .line 447
    .line 448
    move/from16 v24, v0

    .line 449
    .line 450
    move v7, v1

    .line 451
    move/from16 v6, v25

    .line 452
    .line 453
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 454
    .line 455
    .line 456
    move-result-wide v0

    .line 457
    iput-wide v0, v5, Lp1/j;->p:J

    .line 458
    .line 459
    move/from16 v0, v26

    .line 460
    .line 461
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 462
    .line 463
    .line 464
    move-result v1

    .line 465
    if-eqz v1, :cond_4

    .line 466
    .line 467
    const/4 v1, 0x1

    .line 468
    goto :goto_5

    .line 469
    :cond_4
    const/4 v1, 0x0

    .line 470
    :goto_5
    iput-boolean v1, v5, Lp1/j;->q:Z

    .line 471
    .line 472
    move/from16 v1, v27

    .line 473
    .line 474
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 475
    .line 476
    .line 477
    move-result v25

    .line 478
    move/from16 v26, v0

    .line 479
    .line 480
    invoke-static/range {v25 .. v25}, La/a;->z(I)I

    .line 481
    .line 482
    .line 483
    move-result v0

    .line 484
    iput v0, v5, Lp1/j;->r:I

    .line 485
    .line 486
    iput-object v15, v5, Lp1/j;->j:Lg1/c;

    .line 487
    .line 488
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 489
    .line 490
    .line 491
    move/from16 v0, v21

    .line 492
    .line 493
    move/from16 v21, v7

    .line 494
    .line 495
    move v7, v0

    .line 496
    move/from16 v27, v1

    .line 497
    .line 498
    move/from16 v25, v6

    .line 499
    .line 500
    move v0, v13

    .line 501
    move/from16 v13, v29

    .line 502
    .line 503
    move/from16 v15, v30

    .line 504
    .line 505
    move/from16 v6, v31

    .line 506
    .line 507
    move/from16 v5, v32

    .line 508
    .line 509
    goto/16 :goto_0

    .line 510
    .line 511
    :catchall_0
    move-exception v0

    .line 512
    goto :goto_6

    .line 513
    :cond_5
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 514
    .line 515
    .line 516
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 517
    .line 518
    .line 519
    return-object v2

    .line 520
    :catchall_1
    move-exception v0

    .line 521
    move-object/from16 v16, v1

    .line 522
    .line 523
    :goto_6
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 524
    .line 525
    .line 526
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 527
    .line 528
    .line 529
    throw v0
.end method

.method public e(I)LA5/c;
    .locals 8

    .line 1
    const-string v0, "FirebaseCrashlytics"

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    :try_start_0
    invoke-static {v1, p1}, Lu/e;->a(II)Z

    .line 6
    .line 7
    .line 8
    move-result v3

    .line 9
    if-nez v3, :cond_3

    .line 10
    .line 11
    iget-object v3, p0, LA5/f;->e:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v3, LV5/c;

    .line 14
    .line 15
    invoke-virtual {v3}, LV5/c;->x()Lorg/json/JSONObject;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    const/4 v4, 0x3

    .line 20
    if-eqz v3, :cond_2

    .line 21
    .line 22
    iget-object v5, p0, LA5/f;->c:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v5, LA5/g;

    .line 25
    .line 26
    invoke-virtual {v5, v3}, LA5/g;->V(Lorg/json/JSONObject;)LA5/c;

    .line 27
    .line 28
    .line 29
    move-result-object v5

    .line 30
    const-string v6, "Loaded cached settings: "

    .line 31
    .line 32
    invoke-static {v3, v6}, LA5/f;->n(Lorg/json/JSONObject;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    iget-object v3, p0, LA5/f;->d:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v3, Ld2/b;

    .line 38
    .line 39
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 43
    .line 44
    .line 45
    move-result-wide v6

    .line 46
    invoke-static {v4, p1}, Lu/e;->a(II)Z

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    if-nez p1, :cond_0

    .line 51
    .line 52
    iget-wide v3, v5, LA5/c;->c:J

    .line 53
    .line 54
    cmp-long p1, v3, v6

    .line 55
    .line 56
    if-gez p1, :cond_0

    .line 57
    .line 58
    const-string p1, "Cached settings have expired."

    .line 59
    .line 60
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 61
    .line 62
    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_3

    .line 65
    .line 66
    invoke-static {v0, p1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 67
    .line 68
    .line 69
    return-object v2

    .line 70
    :catch_0
    move-exception p1

    .line 71
    goto :goto_1

    .line 72
    :cond_0
    :try_start_1
    const-string p1, "Returning cached settings."

    .line 73
    .line 74
    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-eqz v1, :cond_1

    .line 79
    .line 80
    invoke-static {v0, p1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 81
    .line 82
    .line 83
    :cond_1
    return-object v5

    .line 84
    :goto_0
    move-object v2, v5

    .line 85
    goto :goto_1

    .line 86
    :catch_1
    move-exception p1

    .line 87
    goto :goto_0

    .line 88
    :cond_2
    :try_start_2
    const-string p1, "No cached settings data found."

    .line 89
    .line 90
    invoke-static {v0, v4}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    if-eqz v1, :cond_3

    .line 95
    .line 96
    invoke-static {v0, p1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 97
    .line 98
    .line 99
    :cond_3
    return-object v2

    .line 100
    :goto_1
    const-string v1, "Failed to get cached settings"

    .line 101
    .line 102
    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 103
    .line 104
    .line 105
    return-object v2
.end method

.method public f(I)Ljava/util/ArrayList;
    .locals 33

    .line 1
    const/4 v0, 0x1

    .line 2
    const-string v1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY period_start_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND state NOT IN (2, 3, 5))"

    .line 3
    .line 4
    invoke-static {v0, v1}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    move/from16 v2, p1

    .line 9
    .line 10
    int-to-long v2, v2

    .line 11
    invoke-virtual {v1, v2, v3, v0}, LH0/B;->d(JI)V

    .line 12
    .line 13
    .line 14
    move-object/from16 v2, p0

    .line 15
    .line 16
    iget-object v3, v2, LA5/f;->a:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v3, Landroidx/work/impl/WorkDatabase_Impl;

    .line 19
    .line 20
    invoke-virtual {v3}, LH0/w;->b()V

    .line 21
    .line 22
    .line 23
    const/4 v4, 0x0

    .line 24
    invoke-static {v3, v1, v4}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    :try_start_0
    const-string v5, "required_network_type"

    .line 29
    .line 30
    invoke-static {v3, v5}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    move-result v5

    .line 34
    const-string v6, "requires_charging"

    .line 35
    .line 36
    invoke-static {v3, v6}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 37
    .line 38
    .line 39
    move-result v6

    .line 40
    const-string v7, "requires_device_idle"

    .line 41
    .line 42
    invoke-static {v3, v7}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    const-string v8, "requires_battery_not_low"

    .line 47
    .line 48
    invoke-static {v3, v8}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 49
    .line 50
    .line 51
    move-result v8

    .line 52
    const-string v9, "requires_storage_not_low"

    .line 53
    .line 54
    invoke-static {v3, v9}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 55
    .line 56
    .line 57
    move-result v9

    .line 58
    const-string v10, "trigger_content_update_delay"

    .line 59
    .line 60
    invoke-static {v3, v10}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 61
    .line 62
    .line 63
    move-result v10

    .line 64
    const-string v11, "trigger_max_content_delay"

    .line 65
    .line 66
    invoke-static {v3, v11}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 67
    .line 68
    .line 69
    move-result v11

    .line 70
    const-string v12, "content_uri_triggers"

    .line 71
    .line 72
    invoke-static {v3, v12}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 73
    .line 74
    .line 75
    move-result v12

    .line 76
    const-string v13, "id"

    .line 77
    .line 78
    invoke-static {v3, v13}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 79
    .line 80
    .line 81
    move-result v13

    .line 82
    const-string v14, "state"

    .line 83
    .line 84
    invoke-static {v3, v14}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 85
    .line 86
    .line 87
    move-result v14

    .line 88
    const-string v15, "worker_class_name"

    .line 89
    .line 90
    invoke-static {v3, v15}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 91
    .line 92
    .line 93
    move-result v15

    .line 94
    const-string v0, "input_merger_class_name"

    .line 95
    .line 96
    invoke-static {v3, v0}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    const-string v4, "input"

    .line 101
    .line 102
    invoke-static {v3, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 103
    .line 104
    .line 105
    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 106
    move-object/from16 v16, v1

    .line 107
    .line 108
    :try_start_1
    const-string v1, "output"

    .line 109
    .line 110
    invoke-static {v3, v1}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    const-string v2, "initial_delay"

    .line 115
    .line 116
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 117
    .line 118
    .line 119
    move-result v2

    .line 120
    move/from16 v17, v2

    .line 121
    .line 122
    const-string v2, "interval_duration"

    .line 123
    .line 124
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 125
    .line 126
    .line 127
    move-result v2

    .line 128
    move/from16 v18, v2

    .line 129
    .line 130
    const-string v2, "flex_duration"

    .line 131
    .line 132
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 133
    .line 134
    .line 135
    move-result v2

    .line 136
    move/from16 v19, v2

    .line 137
    .line 138
    const-string v2, "run_attempt_count"

    .line 139
    .line 140
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 141
    .line 142
    .line 143
    move-result v2

    .line 144
    move/from16 v20, v2

    .line 145
    .line 146
    const-string v2, "backoff_policy"

    .line 147
    .line 148
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 149
    .line 150
    .line 151
    move-result v2

    .line 152
    move/from16 v21, v2

    .line 153
    .line 154
    const-string v2, "backoff_delay_duration"

    .line 155
    .line 156
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 157
    .line 158
    .line 159
    move-result v2

    .line 160
    move/from16 v22, v2

    .line 161
    .line 162
    const-string v2, "period_start_time"

    .line 163
    .line 164
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 165
    .line 166
    .line 167
    move-result v2

    .line 168
    move/from16 v23, v2

    .line 169
    .line 170
    const-string v2, "minimum_retention_duration"

    .line 171
    .line 172
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 173
    .line 174
    .line 175
    move-result v2

    .line 176
    move/from16 v24, v2

    .line 177
    .line 178
    const-string v2, "schedule_requested_at"

    .line 179
    .line 180
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 181
    .line 182
    .line 183
    move-result v2

    .line 184
    move/from16 v25, v2

    .line 185
    .line 186
    const-string v2, "run_in_foreground"

    .line 187
    .line 188
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 189
    .line 190
    .line 191
    move-result v2

    .line 192
    move/from16 v26, v2

    .line 193
    .line 194
    const-string v2, "out_of_quota_policy"

    .line 195
    .line 196
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 197
    .line 198
    .line 199
    move-result v2

    .line 200
    move/from16 v27, v2

    .line 201
    .line 202
    new-instance v2, Ljava/util/ArrayList;

    .line 203
    .line 204
    move/from16 v28, v1

    .line 205
    .line 206
    invoke-interface {v3}, Landroid/database/Cursor;->getCount()I

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 211
    .line 212
    .line 213
    :goto_0
    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    .line 214
    .line 215
    .line 216
    move-result v1

    .line 217
    if-eqz v1, :cond_5

    .line 218
    .line 219
    invoke-interface {v3, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 220
    .line 221
    .line 222
    move-result-object v1

    .line 223
    move/from16 v29, v13

    .line 224
    .line 225
    invoke-interface {v3, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object v13

    .line 229
    move/from16 v30, v15

    .line 230
    .line 231
    new-instance v15, Lg1/c;

    .line 232
    .line 233
    invoke-direct {v15}, Lg1/c;-><init>()V

    .line 234
    .line 235
    .line 236
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 237
    .line 238
    .line 239
    move-result v31

    .line 240
    move/from16 v32, v5

    .line 241
    .line 242
    invoke-static/range {v31 .. v31}, La/a;->y(I)I

    .line 243
    .line 244
    .line 245
    move-result v5

    .line 246
    iput v5, v15, Lg1/c;->a:I

    .line 247
    .line 248
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 249
    .line 250
    .line 251
    move-result v5

    .line 252
    if-eqz v5, :cond_0

    .line 253
    .line 254
    const/4 v5, 0x1

    .line 255
    goto :goto_1

    .line 256
    :cond_0
    const/4 v5, 0x0

    .line 257
    :goto_1
    iput-boolean v5, v15, Lg1/c;->b:Z

    .line 258
    .line 259
    invoke-interface {v3, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 260
    .line 261
    .line 262
    move-result v5

    .line 263
    if-eqz v5, :cond_1

    .line 264
    .line 265
    const/4 v5, 0x1

    .line 266
    goto :goto_2

    .line 267
    :cond_1
    const/4 v5, 0x0

    .line 268
    :goto_2
    iput-boolean v5, v15, Lg1/c;->c:Z

    .line 269
    .line 270
    invoke-interface {v3, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 271
    .line 272
    .line 273
    move-result v5

    .line 274
    if-eqz v5, :cond_2

    .line 275
    .line 276
    const/4 v5, 0x1

    .line 277
    goto :goto_3

    .line 278
    :cond_2
    const/4 v5, 0x0

    .line 279
    :goto_3
    iput-boolean v5, v15, Lg1/c;->d:Z

    .line 280
    .line 281
    invoke-interface {v3, v9}, Landroid/database/Cursor;->getInt(I)I

    .line 282
    .line 283
    .line 284
    move-result v5

    .line 285
    if-eqz v5, :cond_3

    .line 286
    .line 287
    const/4 v5, 0x1

    .line 288
    goto :goto_4

    .line 289
    :cond_3
    const/4 v5, 0x0

    .line 290
    :goto_4
    iput-boolean v5, v15, Lg1/c;->e:Z

    .line 291
    .line 292
    move/from16 v31, v6

    .line 293
    .line 294
    invoke-interface {v3, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 295
    .line 296
    .line 297
    move-result-wide v5

    .line 298
    iput-wide v5, v15, Lg1/c;->f:J

    .line 299
    .line 300
    invoke-interface {v3, v11}, Landroid/database/Cursor;->getLong(I)J

    .line 301
    .line 302
    .line 303
    move-result-wide v5

    .line 304
    iput-wide v5, v15, Lg1/c;->g:J

    .line 305
    .line 306
    invoke-interface {v3, v12}, Landroid/database/Cursor;->getBlob(I)[B

    .line 307
    .line 308
    .line 309
    move-result-object v5

    .line 310
    invoke-static {v5}, La/a;->b([B)Lg1/e;

    .line 311
    .line 312
    .line 313
    move-result-object v5

    .line 314
    iput-object v5, v15, Lg1/c;->h:Lg1/e;

    .line 315
    .line 316
    new-instance v5, Lp1/j;

    .line 317
    .line 318
    invoke-direct {v5, v1, v13}, Lp1/j;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 319
    .line 320
    .line 321
    invoke-interface {v3, v14}, Landroid/database/Cursor;->getInt(I)I

    .line 322
    .line 323
    .line 324
    move-result v1

    .line 325
    invoke-static {v1}, La/a;->A(I)I

    .line 326
    .line 327
    .line 328
    move-result v1

    .line 329
    iput v1, v5, Lp1/j;->b:I

    .line 330
    .line 331
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object v1

    .line 335
    iput-object v1, v5, Lp1/j;->d:Ljava/lang/String;

    .line 336
    .line 337
    invoke-interface {v3, v4}, Landroid/database/Cursor;->getBlob(I)[B

    .line 338
    .line 339
    .line 340
    move-result-object v1

    .line 341
    invoke-static {v1}, Lg1/h;->a([B)Lg1/h;

    .line 342
    .line 343
    .line 344
    move-result-object v1

    .line 345
    iput-object v1, v5, Lp1/j;->e:Lg1/h;

    .line 346
    .line 347
    move/from16 v1, v28

    .line 348
    .line 349
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 350
    .line 351
    .line 352
    move-result-object v6

    .line 353
    invoke-static {v6}, Lg1/h;->a([B)Lg1/h;

    .line 354
    .line 355
    .line 356
    move-result-object v6

    .line 357
    iput-object v6, v5, Lp1/j;->f:Lg1/h;

    .line 358
    .line 359
    move v13, v0

    .line 360
    move/from16 v28, v1

    .line 361
    .line 362
    move/from16 v6, v17

    .line 363
    .line 364
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 365
    .line 366
    .line 367
    move-result-wide v0

    .line 368
    iput-wide v0, v5, Lp1/j;->g:J

    .line 369
    .line 370
    move/from16 v17, v6

    .line 371
    .line 372
    move v1, v7

    .line 373
    move/from16 v0, v18

    .line 374
    .line 375
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 376
    .line 377
    .line 378
    move-result-wide v6

    .line 379
    iput-wide v6, v5, Lp1/j;->h:J

    .line 380
    .line 381
    move/from16 v18, v0

    .line 382
    .line 383
    move v7, v1

    .line 384
    move/from16 v6, v19

    .line 385
    .line 386
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 387
    .line 388
    .line 389
    move-result-wide v0

    .line 390
    iput-wide v0, v5, Lp1/j;->i:J

    .line 391
    .line 392
    move/from16 v0, v20

    .line 393
    .line 394
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 395
    .line 396
    .line 397
    move-result v1

    .line 398
    iput v1, v5, Lp1/j;->k:I

    .line 399
    .line 400
    move/from16 v1, v21

    .line 401
    .line 402
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 403
    .line 404
    .line 405
    move-result v19

    .line 406
    move/from16 v20, v0

    .line 407
    .line 408
    invoke-static/range {v19 .. v19}, La/a;->x(I)I

    .line 409
    .line 410
    .line 411
    move-result v0

    .line 412
    iput v0, v5, Lp1/j;->l:I

    .line 413
    .line 414
    move/from16 v19, v6

    .line 415
    .line 416
    move/from16 v21, v7

    .line 417
    .line 418
    move/from16 v0, v22

    .line 419
    .line 420
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 421
    .line 422
    .line 423
    move-result-wide v6

    .line 424
    iput-wide v6, v5, Lp1/j;->m:J

    .line 425
    .line 426
    move/from16 v22, v0

    .line 427
    .line 428
    move v7, v1

    .line 429
    move/from16 v6, v23

    .line 430
    .line 431
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 432
    .line 433
    .line 434
    move-result-wide v0

    .line 435
    iput-wide v0, v5, Lp1/j;->n:J

    .line 436
    .line 437
    move/from16 v23, v6

    .line 438
    .line 439
    move v1, v7

    .line 440
    move/from16 v0, v24

    .line 441
    .line 442
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 443
    .line 444
    .line 445
    move-result-wide v6

    .line 446
    iput-wide v6, v5, Lp1/j;->o:J

    .line 447
    .line 448
    move/from16 v24, v0

    .line 449
    .line 450
    move v7, v1

    .line 451
    move/from16 v6, v25

    .line 452
    .line 453
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 454
    .line 455
    .line 456
    move-result-wide v0

    .line 457
    iput-wide v0, v5, Lp1/j;->p:J

    .line 458
    .line 459
    move/from16 v0, v26

    .line 460
    .line 461
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 462
    .line 463
    .line 464
    move-result v1

    .line 465
    if-eqz v1, :cond_4

    .line 466
    .line 467
    const/4 v1, 0x1

    .line 468
    goto :goto_5

    .line 469
    :cond_4
    const/4 v1, 0x0

    .line 470
    :goto_5
    iput-boolean v1, v5, Lp1/j;->q:Z

    .line 471
    .line 472
    move/from16 v1, v27

    .line 473
    .line 474
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 475
    .line 476
    .line 477
    move-result v25

    .line 478
    move/from16 v26, v0

    .line 479
    .line 480
    invoke-static/range {v25 .. v25}, La/a;->z(I)I

    .line 481
    .line 482
    .line 483
    move-result v0

    .line 484
    iput v0, v5, Lp1/j;->r:I

    .line 485
    .line 486
    iput-object v15, v5, Lp1/j;->j:Lg1/c;

    .line 487
    .line 488
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 489
    .line 490
    .line 491
    move/from16 v0, v21

    .line 492
    .line 493
    move/from16 v21, v7

    .line 494
    .line 495
    move v7, v0

    .line 496
    move/from16 v27, v1

    .line 497
    .line 498
    move/from16 v25, v6

    .line 499
    .line 500
    move v0, v13

    .line 501
    move/from16 v13, v29

    .line 502
    .line 503
    move/from16 v15, v30

    .line 504
    .line 505
    move/from16 v6, v31

    .line 506
    .line 507
    move/from16 v5, v32

    .line 508
    .line 509
    goto/16 :goto_0

    .line 510
    .line 511
    :catchall_0
    move-exception v0

    .line 512
    goto :goto_6

    .line 513
    :cond_5
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 514
    .line 515
    .line 516
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 517
    .line 518
    .line 519
    return-object v2

    .line 520
    :catchall_1
    move-exception v0

    .line 521
    move-object/from16 v16, v1

    .line 522
    .line 523
    :goto_6
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 524
    .line 525
    .line 526
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 527
    .line 528
    .line 529
    throw v0
.end method

.method public g()Ljava/util/ArrayList;
    .locals 34

    .line 1
    const/4 v0, 0x0

    .line 2
    const-string v1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=1"

    .line 3
    .line 4
    invoke-static {v0, v1}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    move-object/from16 v2, p0

    .line 9
    .line 10
    iget-object v3, v2, LA5/f;->a:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v3, Landroidx/work/impl/WorkDatabase_Impl;

    .line 13
    .line 14
    invoke-virtual {v3}, LH0/w;->b()V

    .line 15
    .line 16
    .line 17
    invoke-static {v3, v1, v0}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    :try_start_0
    const-string v4, "required_network_type"

    .line 22
    .line 23
    invoke-static {v3, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    const-string v5, "requires_charging"

    .line 28
    .line 29
    invoke-static {v3, v5}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    const-string v6, "requires_device_idle"

    .line 34
    .line 35
    invoke-static {v3, v6}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v6

    .line 39
    const-string v7, "requires_battery_not_low"

    .line 40
    .line 41
    invoke-static {v3, v7}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    const-string v8, "requires_storage_not_low"

    .line 46
    .line 47
    invoke-static {v3, v8}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result v8

    .line 51
    const-string v9, "trigger_content_update_delay"

    .line 52
    .line 53
    invoke-static {v3, v9}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 54
    .line 55
    .line 56
    move-result v9

    .line 57
    const-string v10, "trigger_max_content_delay"

    .line 58
    .line 59
    invoke-static {v3, v10}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 60
    .line 61
    .line 62
    move-result v10

    .line 63
    const-string v11, "content_uri_triggers"

    .line 64
    .line 65
    invoke-static {v3, v11}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    move-result v11

    .line 69
    const-string v12, "id"

    .line 70
    .line 71
    invoke-static {v3, v12}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 72
    .line 73
    .line 74
    move-result v12

    .line 75
    const-string v13, "state"

    .line 76
    .line 77
    invoke-static {v3, v13}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 78
    .line 79
    .line 80
    move-result v13

    .line 81
    const-string v14, "worker_class_name"

    .line 82
    .line 83
    invoke-static {v3, v14}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 84
    .line 85
    .line 86
    move-result v14

    .line 87
    const-string v15, "input_merger_class_name"

    .line 88
    .line 89
    invoke-static {v3, v15}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 90
    .line 91
    .line 92
    move-result v15

    .line 93
    const-string v0, "input"

    .line 94
    .line 95
    invoke-static {v3, v0}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 96
    .line 97
    .line 98
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 99
    move-object/from16 v16, v1

    .line 100
    .line 101
    :try_start_1
    const-string v1, "output"

    .line 102
    .line 103
    invoke-static {v3, v1}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    const-string v2, "initial_delay"

    .line 108
    .line 109
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    move/from16 v17, v2

    .line 114
    .line 115
    const-string v2, "interval_duration"

    .line 116
    .line 117
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 118
    .line 119
    .line 120
    move-result v2

    .line 121
    move/from16 v18, v2

    .line 122
    .line 123
    const-string v2, "flex_duration"

    .line 124
    .line 125
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 126
    .line 127
    .line 128
    move-result v2

    .line 129
    move/from16 v19, v2

    .line 130
    .line 131
    const-string v2, "run_attempt_count"

    .line 132
    .line 133
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 134
    .line 135
    .line 136
    move-result v2

    .line 137
    move/from16 v20, v2

    .line 138
    .line 139
    const-string v2, "backoff_policy"

    .line 140
    .line 141
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 142
    .line 143
    .line 144
    move-result v2

    .line 145
    move/from16 v21, v2

    .line 146
    .line 147
    const-string v2, "backoff_delay_duration"

    .line 148
    .line 149
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    move/from16 v22, v2

    .line 154
    .line 155
    const-string v2, "period_start_time"

    .line 156
    .line 157
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 158
    .line 159
    .line 160
    move-result v2

    .line 161
    move/from16 v23, v2

    .line 162
    .line 163
    const-string v2, "minimum_retention_duration"

    .line 164
    .line 165
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 166
    .line 167
    .line 168
    move-result v2

    .line 169
    move/from16 v24, v2

    .line 170
    .line 171
    const-string v2, "schedule_requested_at"

    .line 172
    .line 173
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 174
    .line 175
    .line 176
    move-result v2

    .line 177
    move/from16 v25, v2

    .line 178
    .line 179
    const-string v2, "run_in_foreground"

    .line 180
    .line 181
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 182
    .line 183
    .line 184
    move-result v2

    .line 185
    move/from16 v26, v2

    .line 186
    .line 187
    const-string v2, "out_of_quota_policy"

    .line 188
    .line 189
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 190
    .line 191
    .line 192
    move-result v2

    .line 193
    move/from16 v27, v2

    .line 194
    .line 195
    new-instance v2, Ljava/util/ArrayList;

    .line 196
    .line 197
    move/from16 v28, v1

    .line 198
    .line 199
    invoke-interface {v3}, Landroid/database/Cursor;->getCount()I

    .line 200
    .line 201
    .line 202
    move-result v1

    .line 203
    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 204
    .line 205
    .line 206
    :goto_0
    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    if-eqz v1, :cond_5

    .line 211
    .line 212
    invoke-interface {v3, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    move/from16 v29, v12

    .line 217
    .line 218
    invoke-interface {v3, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v12

    .line 222
    move/from16 v30, v14

    .line 223
    .line 224
    new-instance v14, Lg1/c;

    .line 225
    .line 226
    invoke-direct {v14}, Lg1/c;-><init>()V

    .line 227
    .line 228
    .line 229
    invoke-interface {v3, v4}, Landroid/database/Cursor;->getInt(I)I

    .line 230
    .line 231
    .line 232
    move-result v31

    .line 233
    move/from16 v32, v4

    .line 234
    .line 235
    invoke-static/range {v31 .. v31}, La/a;->y(I)I

    .line 236
    .line 237
    .line 238
    move-result v4

    .line 239
    iput v4, v14, Lg1/c;->a:I

    .line 240
    .line 241
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 242
    .line 243
    .line 244
    move-result v4

    .line 245
    const/16 v31, 0x1

    .line 246
    .line 247
    if-eqz v4, :cond_0

    .line 248
    .line 249
    move/from16 v4, v31

    .line 250
    .line 251
    goto :goto_1

    .line 252
    :cond_0
    const/4 v4, 0x0

    .line 253
    :goto_1
    iput-boolean v4, v14, Lg1/c;->b:Z

    .line 254
    .line 255
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 256
    .line 257
    .line 258
    move-result v4

    .line 259
    if-eqz v4, :cond_1

    .line 260
    .line 261
    move/from16 v4, v31

    .line 262
    .line 263
    goto :goto_2

    .line 264
    :cond_1
    const/4 v4, 0x0

    .line 265
    :goto_2
    iput-boolean v4, v14, Lg1/c;->c:Z

    .line 266
    .line 267
    invoke-interface {v3, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 268
    .line 269
    .line 270
    move-result v4

    .line 271
    if-eqz v4, :cond_2

    .line 272
    .line 273
    move/from16 v4, v31

    .line 274
    .line 275
    goto :goto_3

    .line 276
    :cond_2
    const/4 v4, 0x0

    .line 277
    :goto_3
    iput-boolean v4, v14, Lg1/c;->d:Z

    .line 278
    .line 279
    invoke-interface {v3, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 280
    .line 281
    .line 282
    move-result v4

    .line 283
    if-eqz v4, :cond_3

    .line 284
    .line 285
    move/from16 v4, v31

    .line 286
    .line 287
    goto :goto_4

    .line 288
    :cond_3
    const/4 v4, 0x0

    .line 289
    :goto_4
    iput-boolean v4, v14, Lg1/c;->e:Z

    .line 290
    .line 291
    move/from16 v33, v5

    .line 292
    .line 293
    invoke-interface {v3, v9}, Landroid/database/Cursor;->getLong(I)J

    .line 294
    .line 295
    .line 296
    move-result-wide v4

    .line 297
    iput-wide v4, v14, Lg1/c;->f:J

    .line 298
    .line 299
    invoke-interface {v3, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 300
    .line 301
    .line 302
    move-result-wide v4

    .line 303
    iput-wide v4, v14, Lg1/c;->g:J

    .line 304
    .line 305
    invoke-interface {v3, v11}, Landroid/database/Cursor;->getBlob(I)[B

    .line 306
    .line 307
    .line 308
    move-result-object v4

    .line 309
    invoke-static {v4}, La/a;->b([B)Lg1/e;

    .line 310
    .line 311
    .line 312
    move-result-object v4

    .line 313
    iput-object v4, v14, Lg1/c;->h:Lg1/e;

    .line 314
    .line 315
    new-instance v4, Lp1/j;

    .line 316
    .line 317
    invoke-direct {v4, v1, v12}, Lp1/j;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 318
    .line 319
    .line 320
    invoke-interface {v3, v13}, Landroid/database/Cursor;->getInt(I)I

    .line 321
    .line 322
    .line 323
    move-result v1

    .line 324
    invoke-static {v1}, La/a;->A(I)I

    .line 325
    .line 326
    .line 327
    move-result v1

    .line 328
    iput v1, v4, Lp1/j;->b:I

    .line 329
    .line 330
    invoke-interface {v3, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 331
    .line 332
    .line 333
    move-result-object v1

    .line 334
    iput-object v1, v4, Lp1/j;->d:Ljava/lang/String;

    .line 335
    .line 336
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getBlob(I)[B

    .line 337
    .line 338
    .line 339
    move-result-object v1

    .line 340
    invoke-static {v1}, Lg1/h;->a([B)Lg1/h;

    .line 341
    .line 342
    .line 343
    move-result-object v1

    .line 344
    iput-object v1, v4, Lp1/j;->e:Lg1/h;

    .line 345
    .line 346
    move/from16 v1, v28

    .line 347
    .line 348
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 349
    .line 350
    .line 351
    move-result-object v5

    .line 352
    invoke-static {v5}, Lg1/h;->a([B)Lg1/h;

    .line 353
    .line 354
    .line 355
    move-result-object v5

    .line 356
    iput-object v5, v4, Lp1/j;->f:Lg1/h;

    .line 357
    .line 358
    move v12, v0

    .line 359
    move/from16 v28, v1

    .line 360
    .line 361
    move/from16 v5, v17

    .line 362
    .line 363
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 364
    .line 365
    .line 366
    move-result-wide v0

    .line 367
    iput-wide v0, v4, Lp1/j;->g:J

    .line 368
    .line 369
    move/from16 v17, v5

    .line 370
    .line 371
    move v1, v6

    .line 372
    move/from16 v0, v18

    .line 373
    .line 374
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 375
    .line 376
    .line 377
    move-result-wide v5

    .line 378
    iput-wide v5, v4, Lp1/j;->h:J

    .line 379
    .line 380
    move/from16 v18, v0

    .line 381
    .line 382
    move v6, v1

    .line 383
    move/from16 v5, v19

    .line 384
    .line 385
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 386
    .line 387
    .line 388
    move-result-wide v0

    .line 389
    iput-wide v0, v4, Lp1/j;->i:J

    .line 390
    .line 391
    move/from16 v0, v20

    .line 392
    .line 393
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 394
    .line 395
    .line 396
    move-result v1

    .line 397
    iput v1, v4, Lp1/j;->k:I

    .line 398
    .line 399
    move/from16 v1, v21

    .line 400
    .line 401
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 402
    .line 403
    .line 404
    move-result v19

    .line 405
    move/from16 v20, v0

    .line 406
    .line 407
    invoke-static/range {v19 .. v19}, La/a;->x(I)I

    .line 408
    .line 409
    .line 410
    move-result v0

    .line 411
    iput v0, v4, Lp1/j;->l:I

    .line 412
    .line 413
    move/from16 v19, v5

    .line 414
    .line 415
    move/from16 v21, v6

    .line 416
    .line 417
    move/from16 v0, v22

    .line 418
    .line 419
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 420
    .line 421
    .line 422
    move-result-wide v5

    .line 423
    iput-wide v5, v4, Lp1/j;->m:J

    .line 424
    .line 425
    move/from16 v22, v0

    .line 426
    .line 427
    move v6, v1

    .line 428
    move/from16 v5, v23

    .line 429
    .line 430
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 431
    .line 432
    .line 433
    move-result-wide v0

    .line 434
    iput-wide v0, v4, Lp1/j;->n:J

    .line 435
    .line 436
    move/from16 v23, v5

    .line 437
    .line 438
    move v1, v6

    .line 439
    move/from16 v0, v24

    .line 440
    .line 441
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 442
    .line 443
    .line 444
    move-result-wide v5

    .line 445
    iput-wide v5, v4, Lp1/j;->o:J

    .line 446
    .line 447
    move/from16 v24, v0

    .line 448
    .line 449
    move v6, v1

    .line 450
    move/from16 v5, v25

    .line 451
    .line 452
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 453
    .line 454
    .line 455
    move-result-wide v0

    .line 456
    iput-wide v0, v4, Lp1/j;->p:J

    .line 457
    .line 458
    move/from16 v0, v26

    .line 459
    .line 460
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 461
    .line 462
    .line 463
    move-result v1

    .line 464
    if-eqz v1, :cond_4

    .line 465
    .line 466
    move/from16 v1, v31

    .line 467
    .line 468
    goto :goto_5

    .line 469
    :cond_4
    const/4 v1, 0x0

    .line 470
    :goto_5
    iput-boolean v1, v4, Lp1/j;->q:Z

    .line 471
    .line 472
    move/from16 v1, v27

    .line 473
    .line 474
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 475
    .line 476
    .line 477
    move-result v25

    .line 478
    move/from16 v26, v0

    .line 479
    .line 480
    invoke-static/range {v25 .. v25}, La/a;->z(I)I

    .line 481
    .line 482
    .line 483
    move-result v0

    .line 484
    iput v0, v4, Lp1/j;->r:I

    .line 485
    .line 486
    iput-object v14, v4, Lp1/j;->j:Lg1/c;

    .line 487
    .line 488
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 489
    .line 490
    .line 491
    move/from16 v0, v21

    .line 492
    .line 493
    move/from16 v21, v6

    .line 494
    .line 495
    move v6, v0

    .line 496
    move/from16 v27, v1

    .line 497
    .line 498
    move/from16 v25, v5

    .line 499
    .line 500
    move v0, v12

    .line 501
    move/from16 v12, v29

    .line 502
    .line 503
    move/from16 v14, v30

    .line 504
    .line 505
    move/from16 v4, v32

    .line 506
    .line 507
    move/from16 v5, v33

    .line 508
    .line 509
    goto/16 :goto_0

    .line 510
    .line 511
    :catchall_0
    move-exception v0

    .line 512
    goto :goto_6

    .line 513
    :cond_5
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 514
    .line 515
    .line 516
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 517
    .line 518
    .line 519
    return-object v2

    .line 520
    :catchall_1
    move-exception v0

    .line 521
    move-object/from16 v16, v1

    .line 522
    .line 523
    :goto_6
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 524
    .line 525
    .line 526
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 527
    .line 528
    .line 529
    throw v0
.end method

.method public h()Ljava/util/ArrayList;
    .locals 34

    .line 1
    const/4 v0, 0x0

    .line 2
    const-string v1, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at<>-1"

    .line 3
    .line 4
    invoke-static {v0, v1}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    move-object/from16 v2, p0

    .line 9
    .line 10
    iget-object v3, v2, LA5/f;->a:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v3, Landroidx/work/impl/WorkDatabase_Impl;

    .line 13
    .line 14
    invoke-virtual {v3}, LH0/w;->b()V

    .line 15
    .line 16
    .line 17
    invoke-static {v3, v1, v0}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    :try_start_0
    const-string v4, "required_network_type"

    .line 22
    .line 23
    invoke-static {v3, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    const-string v5, "requires_charging"

    .line 28
    .line 29
    invoke-static {v3, v5}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    const-string v6, "requires_device_idle"

    .line 34
    .line 35
    invoke-static {v3, v6}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v6

    .line 39
    const-string v7, "requires_battery_not_low"

    .line 40
    .line 41
    invoke-static {v3, v7}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 42
    .line 43
    .line 44
    move-result v7

    .line 45
    const-string v8, "requires_storage_not_low"

    .line 46
    .line 47
    invoke-static {v3, v8}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result v8

    .line 51
    const-string v9, "trigger_content_update_delay"

    .line 52
    .line 53
    invoke-static {v3, v9}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 54
    .line 55
    .line 56
    move-result v9

    .line 57
    const-string v10, "trigger_max_content_delay"

    .line 58
    .line 59
    invoke-static {v3, v10}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 60
    .line 61
    .line 62
    move-result v10

    .line 63
    const-string v11, "content_uri_triggers"

    .line 64
    .line 65
    invoke-static {v3, v11}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    move-result v11

    .line 69
    const-string v12, "id"

    .line 70
    .line 71
    invoke-static {v3, v12}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 72
    .line 73
    .line 74
    move-result v12

    .line 75
    const-string v13, "state"

    .line 76
    .line 77
    invoke-static {v3, v13}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 78
    .line 79
    .line 80
    move-result v13

    .line 81
    const-string v14, "worker_class_name"

    .line 82
    .line 83
    invoke-static {v3, v14}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 84
    .line 85
    .line 86
    move-result v14

    .line 87
    const-string v15, "input_merger_class_name"

    .line 88
    .line 89
    invoke-static {v3, v15}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 90
    .line 91
    .line 92
    move-result v15

    .line 93
    const-string v0, "input"

    .line 94
    .line 95
    invoke-static {v3, v0}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 96
    .line 97
    .line 98
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 99
    move-object/from16 v16, v1

    .line 100
    .line 101
    :try_start_1
    const-string v1, "output"

    .line 102
    .line 103
    invoke-static {v3, v1}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    const-string v2, "initial_delay"

    .line 108
    .line 109
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    move/from16 v17, v2

    .line 114
    .line 115
    const-string v2, "interval_duration"

    .line 116
    .line 117
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 118
    .line 119
    .line 120
    move-result v2

    .line 121
    move/from16 v18, v2

    .line 122
    .line 123
    const-string v2, "flex_duration"

    .line 124
    .line 125
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 126
    .line 127
    .line 128
    move-result v2

    .line 129
    move/from16 v19, v2

    .line 130
    .line 131
    const-string v2, "run_attempt_count"

    .line 132
    .line 133
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 134
    .line 135
    .line 136
    move-result v2

    .line 137
    move/from16 v20, v2

    .line 138
    .line 139
    const-string v2, "backoff_policy"

    .line 140
    .line 141
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 142
    .line 143
    .line 144
    move-result v2

    .line 145
    move/from16 v21, v2

    .line 146
    .line 147
    const-string v2, "backoff_delay_duration"

    .line 148
    .line 149
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    move/from16 v22, v2

    .line 154
    .line 155
    const-string v2, "period_start_time"

    .line 156
    .line 157
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 158
    .line 159
    .line 160
    move-result v2

    .line 161
    move/from16 v23, v2

    .line 162
    .line 163
    const-string v2, "minimum_retention_duration"

    .line 164
    .line 165
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 166
    .line 167
    .line 168
    move-result v2

    .line 169
    move/from16 v24, v2

    .line 170
    .line 171
    const-string v2, "schedule_requested_at"

    .line 172
    .line 173
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 174
    .line 175
    .line 176
    move-result v2

    .line 177
    move/from16 v25, v2

    .line 178
    .line 179
    const-string v2, "run_in_foreground"

    .line 180
    .line 181
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 182
    .line 183
    .line 184
    move-result v2

    .line 185
    move/from16 v26, v2

    .line 186
    .line 187
    const-string v2, "out_of_quota_policy"

    .line 188
    .line 189
    invoke-static {v3, v2}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 190
    .line 191
    .line 192
    move-result v2

    .line 193
    move/from16 v27, v2

    .line 194
    .line 195
    new-instance v2, Ljava/util/ArrayList;

    .line 196
    .line 197
    move/from16 v28, v1

    .line 198
    .line 199
    invoke-interface {v3}, Landroid/database/Cursor;->getCount()I

    .line 200
    .line 201
    .line 202
    move-result v1

    .line 203
    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 204
    .line 205
    .line 206
    :goto_0
    invoke-interface {v3}, Landroid/database/Cursor;->moveToNext()Z

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    if-eqz v1, :cond_5

    .line 211
    .line 212
    invoke-interface {v3, v12}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    move/from16 v29, v12

    .line 217
    .line 218
    invoke-interface {v3, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v12

    .line 222
    move/from16 v30, v14

    .line 223
    .line 224
    new-instance v14, Lg1/c;

    .line 225
    .line 226
    invoke-direct {v14}, Lg1/c;-><init>()V

    .line 227
    .line 228
    .line 229
    invoke-interface {v3, v4}, Landroid/database/Cursor;->getInt(I)I

    .line 230
    .line 231
    .line 232
    move-result v31

    .line 233
    move/from16 v32, v4

    .line 234
    .line 235
    invoke-static/range {v31 .. v31}, La/a;->y(I)I

    .line 236
    .line 237
    .line 238
    move-result v4

    .line 239
    iput v4, v14, Lg1/c;->a:I

    .line 240
    .line 241
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 242
    .line 243
    .line 244
    move-result v4

    .line 245
    const/16 v31, 0x1

    .line 246
    .line 247
    if-eqz v4, :cond_0

    .line 248
    .line 249
    move/from16 v4, v31

    .line 250
    .line 251
    goto :goto_1

    .line 252
    :cond_0
    const/4 v4, 0x0

    .line 253
    :goto_1
    iput-boolean v4, v14, Lg1/c;->b:Z

    .line 254
    .line 255
    invoke-interface {v3, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 256
    .line 257
    .line 258
    move-result v4

    .line 259
    if-eqz v4, :cond_1

    .line 260
    .line 261
    move/from16 v4, v31

    .line 262
    .line 263
    goto :goto_2

    .line 264
    :cond_1
    const/4 v4, 0x0

    .line 265
    :goto_2
    iput-boolean v4, v14, Lg1/c;->c:Z

    .line 266
    .line 267
    invoke-interface {v3, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 268
    .line 269
    .line 270
    move-result v4

    .line 271
    if-eqz v4, :cond_2

    .line 272
    .line 273
    move/from16 v4, v31

    .line 274
    .line 275
    goto :goto_3

    .line 276
    :cond_2
    const/4 v4, 0x0

    .line 277
    :goto_3
    iput-boolean v4, v14, Lg1/c;->d:Z

    .line 278
    .line 279
    invoke-interface {v3, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 280
    .line 281
    .line 282
    move-result v4

    .line 283
    if-eqz v4, :cond_3

    .line 284
    .line 285
    move/from16 v4, v31

    .line 286
    .line 287
    goto :goto_4

    .line 288
    :cond_3
    const/4 v4, 0x0

    .line 289
    :goto_4
    iput-boolean v4, v14, Lg1/c;->e:Z

    .line 290
    .line 291
    move/from16 v33, v5

    .line 292
    .line 293
    invoke-interface {v3, v9}, Landroid/database/Cursor;->getLong(I)J

    .line 294
    .line 295
    .line 296
    move-result-wide v4

    .line 297
    iput-wide v4, v14, Lg1/c;->f:J

    .line 298
    .line 299
    invoke-interface {v3, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 300
    .line 301
    .line 302
    move-result-wide v4

    .line 303
    iput-wide v4, v14, Lg1/c;->g:J

    .line 304
    .line 305
    invoke-interface {v3, v11}, Landroid/database/Cursor;->getBlob(I)[B

    .line 306
    .line 307
    .line 308
    move-result-object v4

    .line 309
    invoke-static {v4}, La/a;->b([B)Lg1/e;

    .line 310
    .line 311
    .line 312
    move-result-object v4

    .line 313
    iput-object v4, v14, Lg1/c;->h:Lg1/e;

    .line 314
    .line 315
    new-instance v4, Lp1/j;

    .line 316
    .line 317
    invoke-direct {v4, v1, v12}, Lp1/j;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 318
    .line 319
    .line 320
    invoke-interface {v3, v13}, Landroid/database/Cursor;->getInt(I)I

    .line 321
    .line 322
    .line 323
    move-result v1

    .line 324
    invoke-static {v1}, La/a;->A(I)I

    .line 325
    .line 326
    .line 327
    move-result v1

    .line 328
    iput v1, v4, Lp1/j;->b:I

    .line 329
    .line 330
    invoke-interface {v3, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 331
    .line 332
    .line 333
    move-result-object v1

    .line 334
    iput-object v1, v4, Lp1/j;->d:Ljava/lang/String;

    .line 335
    .line 336
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getBlob(I)[B

    .line 337
    .line 338
    .line 339
    move-result-object v1

    .line 340
    invoke-static {v1}, Lg1/h;->a([B)Lg1/h;

    .line 341
    .line 342
    .line 343
    move-result-object v1

    .line 344
    iput-object v1, v4, Lp1/j;->e:Lg1/h;

    .line 345
    .line 346
    move/from16 v1, v28

    .line 347
    .line 348
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 349
    .line 350
    .line 351
    move-result-object v5

    .line 352
    invoke-static {v5}, Lg1/h;->a([B)Lg1/h;

    .line 353
    .line 354
    .line 355
    move-result-object v5

    .line 356
    iput-object v5, v4, Lp1/j;->f:Lg1/h;

    .line 357
    .line 358
    move v12, v0

    .line 359
    move/from16 v28, v1

    .line 360
    .line 361
    move/from16 v5, v17

    .line 362
    .line 363
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 364
    .line 365
    .line 366
    move-result-wide v0

    .line 367
    iput-wide v0, v4, Lp1/j;->g:J

    .line 368
    .line 369
    move/from16 v17, v5

    .line 370
    .line 371
    move v1, v6

    .line 372
    move/from16 v0, v18

    .line 373
    .line 374
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 375
    .line 376
    .line 377
    move-result-wide v5

    .line 378
    iput-wide v5, v4, Lp1/j;->h:J

    .line 379
    .line 380
    move/from16 v18, v0

    .line 381
    .line 382
    move v6, v1

    .line 383
    move/from16 v5, v19

    .line 384
    .line 385
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 386
    .line 387
    .line 388
    move-result-wide v0

    .line 389
    iput-wide v0, v4, Lp1/j;->i:J

    .line 390
    .line 391
    move/from16 v0, v20

    .line 392
    .line 393
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 394
    .line 395
    .line 396
    move-result v1

    .line 397
    iput v1, v4, Lp1/j;->k:I

    .line 398
    .line 399
    move/from16 v1, v21

    .line 400
    .line 401
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 402
    .line 403
    .line 404
    move-result v19

    .line 405
    move/from16 v20, v0

    .line 406
    .line 407
    invoke-static/range {v19 .. v19}, La/a;->x(I)I

    .line 408
    .line 409
    .line 410
    move-result v0

    .line 411
    iput v0, v4, Lp1/j;->l:I

    .line 412
    .line 413
    move/from16 v19, v5

    .line 414
    .line 415
    move/from16 v21, v6

    .line 416
    .line 417
    move/from16 v0, v22

    .line 418
    .line 419
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 420
    .line 421
    .line 422
    move-result-wide v5

    .line 423
    iput-wide v5, v4, Lp1/j;->m:J

    .line 424
    .line 425
    move/from16 v22, v0

    .line 426
    .line 427
    move v6, v1

    .line 428
    move/from16 v5, v23

    .line 429
    .line 430
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 431
    .line 432
    .line 433
    move-result-wide v0

    .line 434
    iput-wide v0, v4, Lp1/j;->n:J

    .line 435
    .line 436
    move/from16 v23, v5

    .line 437
    .line 438
    move v1, v6

    .line 439
    move/from16 v0, v24

    .line 440
    .line 441
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 442
    .line 443
    .line 444
    move-result-wide v5

    .line 445
    iput-wide v5, v4, Lp1/j;->o:J

    .line 446
    .line 447
    move/from16 v24, v0

    .line 448
    .line 449
    move v6, v1

    .line 450
    move/from16 v5, v25

    .line 451
    .line 452
    invoke-interface {v3, v5}, Landroid/database/Cursor;->getLong(I)J

    .line 453
    .line 454
    .line 455
    move-result-wide v0

    .line 456
    iput-wide v0, v4, Lp1/j;->p:J

    .line 457
    .line 458
    move/from16 v0, v26

    .line 459
    .line 460
    invoke-interface {v3, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 461
    .line 462
    .line 463
    move-result v1

    .line 464
    if-eqz v1, :cond_4

    .line 465
    .line 466
    move/from16 v1, v31

    .line 467
    .line 468
    goto :goto_5

    .line 469
    :cond_4
    const/4 v1, 0x0

    .line 470
    :goto_5
    iput-boolean v1, v4, Lp1/j;->q:Z

    .line 471
    .line 472
    move/from16 v1, v27

    .line 473
    .line 474
    invoke-interface {v3, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 475
    .line 476
    .line 477
    move-result v25

    .line 478
    move/from16 v26, v0

    .line 479
    .line 480
    invoke-static/range {v25 .. v25}, La/a;->z(I)I

    .line 481
    .line 482
    .line 483
    move-result v0

    .line 484
    iput v0, v4, Lp1/j;->r:I

    .line 485
    .line 486
    iput-object v14, v4, Lp1/j;->j:Lg1/c;

    .line 487
    .line 488
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 489
    .line 490
    .line 491
    move/from16 v0, v21

    .line 492
    .line 493
    move/from16 v21, v6

    .line 494
    .line 495
    move v6, v0

    .line 496
    move/from16 v27, v1

    .line 497
    .line 498
    move/from16 v25, v5

    .line 499
    .line 500
    move v0, v12

    .line 501
    move/from16 v12, v29

    .line 502
    .line 503
    move/from16 v14, v30

    .line 504
    .line 505
    move/from16 v4, v32

    .line 506
    .line 507
    move/from16 v5, v33

    .line 508
    .line 509
    goto/16 :goto_0

    .line 510
    .line 511
    :catchall_0
    move-exception v0

    .line 512
    goto :goto_6

    .line 513
    :cond_5
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 514
    .line 515
    .line 516
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 517
    .line 518
    .line 519
    return-object v2

    .line 520
    :catchall_1
    move-exception v0

    .line 521
    move-object/from16 v16, v1

    .line 522
    .line 523
    :goto_6
    invoke-interface {v3}, Landroid/database/Cursor;->close()V

    .line 524
    .line 525
    .line 526
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 527
    .line 528
    .line 529
    throw v0
.end method

.method public i()LA5/c;
    .locals 1

    .line 1
    iget-object v0, p0, LA5/f;->h:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, LA5/c;

    .line 10
    .line 11
    return-object v0
.end method

.method public j(Ljava/lang/String;)I
    .locals 3

    .line 1
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    const-string v2, "SELECT state FROM workspec WHERE id=?"

    .line 7
    .line 8
    invoke-static {v1, v2}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    if-nez p1, :cond_0

    .line 13
    .line 14
    invoke-virtual {v2, v1}, LH0/B;->b(I)V

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-virtual {v2, v1, p1}, LH0/B;->p(ILjava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :goto_0
    invoke-virtual {v0}, LH0/w;->b()V

    .line 22
    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    invoke-static {v0, v2, p1}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    :try_start_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_1

    .line 34
    .line 35
    invoke-interface {v0, p1}, Landroid/database/Cursor;->getInt(I)I

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    invoke-static {p1}, La/a;->A(I)I

    .line 40
    .line 41
    .line 42
    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 43
    goto :goto_1

    .line 44
    :catchall_0
    move-exception p1

    .line 45
    goto :goto_2

    .line 46
    :cond_1
    :goto_1
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v2}, LH0/B;->k()V

    .line 50
    .line 51
    .line 52
    return p1

    .line 53
    :goto_2
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v2}, LH0/B;->k()V

    .line 57
    .line 58
    .line 59
    throw p1
.end method

.method public k(Ljava/lang/String;)Ljava/util/ArrayList;
    .locals 4

    .line 1
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    const-string v2, "SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)"

    .line 7
    .line 8
    invoke-static {v1, v2}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    if-nez p1, :cond_0

    .line 13
    .line 14
    invoke-virtual {v2, v1}, LH0/B;->b(I)V

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-virtual {v2, v1, p1}, LH0/B;->p(ILjava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :goto_0
    invoke-virtual {v0}, LH0/w;->b()V

    .line 22
    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    invoke-static {v0, v2, p1}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    :try_start_0
    new-instance v1, Ljava/util/ArrayList;

    .line 30
    .line 31
    invoke-interface {v0}, Landroid/database/Cursor;->getCount()I

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 36
    .line 37
    .line 38
    :goto_1
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    if-eqz v3, :cond_1

    .line 43
    .line 44
    invoke-interface {v0, p1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v3

    .line 48
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    .line 50
    .line 51
    goto :goto_1

    .line 52
    :catchall_0
    move-exception p1

    .line 53
    goto :goto_2

    .line 54
    :cond_1
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v2}, LH0/B;->k()V

    .line 58
    .line 59
    .line 60
    return-object v1

    .line 61
    :goto_2
    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v2}, LH0/B;->k()V

    .line 65
    .line 66
    .line 67
    throw p1
.end method

.method public l(Ljava/lang/String;)Lp1/j;
    .locals 28

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iget-object v2, v1, LA5/f;->a:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v2, Landroidx/work/impl/WorkDatabase_Impl;

    .line 8
    .line 9
    const/4 v3, 0x1

    .line 10
    const-string v4, "SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE id=?"

    .line 11
    .line 12
    invoke-static {v3, v4}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 13
    .line 14
    .line 15
    move-result-object v4

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    invoke-virtual {v4, v3}, LH0/B;->b(I)V

    .line 19
    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    invoke-virtual {v4, v3, v0}, LH0/B;->p(ILjava/lang/String;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    invoke-virtual {v2}, LH0/w;->b()V

    .line 26
    .line 27
    .line 28
    const/4 v0, 0x0

    .line 29
    invoke-static {v2, v4, v0}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    :try_start_0
    const-string v5, "required_network_type"

    .line 34
    .line 35
    invoke-static {v2, v5}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    const-string v6, "requires_charging"

    .line 40
    .line 41
    invoke-static {v2, v6}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 42
    .line 43
    .line 44
    move-result v6

    .line 45
    const-string v7, "requires_device_idle"

    .line 46
    .line 47
    invoke-static {v2, v7}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result v7

    .line 51
    const-string v8, "requires_battery_not_low"

    .line 52
    .line 53
    invoke-static {v2, v8}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 54
    .line 55
    .line 56
    move-result v8

    .line 57
    const-string v9, "requires_storage_not_low"

    .line 58
    .line 59
    invoke-static {v2, v9}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 60
    .line 61
    .line 62
    move-result v9

    .line 63
    const-string v10, "trigger_content_update_delay"

    .line 64
    .line 65
    invoke-static {v2, v10}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    move-result v10

    .line 69
    const-string v11, "trigger_max_content_delay"

    .line 70
    .line 71
    invoke-static {v2, v11}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 72
    .line 73
    .line 74
    move-result v11

    .line 75
    const-string v12, "content_uri_triggers"

    .line 76
    .line 77
    invoke-static {v2, v12}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 78
    .line 79
    .line 80
    move-result v12

    .line 81
    const-string v13, "id"

    .line 82
    .line 83
    invoke-static {v2, v13}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 84
    .line 85
    .line 86
    move-result v13

    .line 87
    const-string v14, "state"

    .line 88
    .line 89
    invoke-static {v2, v14}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 90
    .line 91
    .line 92
    move-result v14

    .line 93
    const-string v15, "worker_class_name"

    .line 94
    .line 95
    invoke-static {v2, v15}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 96
    .line 97
    .line 98
    move-result v15

    .line 99
    const-string v0, "input_merger_class_name"

    .line 100
    .line 101
    invoke-static {v2, v0}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    const-string v3, "input"

    .line 106
    .line 107
    invoke-static {v2, v3}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    const-string v1, "output"

    .line 112
    .line 113
    invoke-static {v2, v1}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 114
    .line 115
    .line 116
    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 117
    move-object/from16 v16, v4

    .line 118
    .line 119
    :try_start_1
    const-string v4, "initial_delay"

    .line 120
    .line 121
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 122
    .line 123
    .line 124
    move-result v4

    .line 125
    move/from16 v17, v4

    .line 126
    .line 127
    const-string v4, "interval_duration"

    .line 128
    .line 129
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 130
    .line 131
    .line 132
    move-result v4

    .line 133
    move/from16 v18, v4

    .line 134
    .line 135
    const-string v4, "flex_duration"

    .line 136
    .line 137
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 138
    .line 139
    .line 140
    move-result v4

    .line 141
    move/from16 v19, v4

    .line 142
    .line 143
    const-string v4, "run_attempt_count"

    .line 144
    .line 145
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 146
    .line 147
    .line 148
    move-result v4

    .line 149
    move/from16 v20, v4

    .line 150
    .line 151
    const-string v4, "backoff_policy"

    .line 152
    .line 153
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 154
    .line 155
    .line 156
    move-result v4

    .line 157
    move/from16 v21, v4

    .line 158
    .line 159
    const-string v4, "backoff_delay_duration"

    .line 160
    .line 161
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 162
    .line 163
    .line 164
    move-result v4

    .line 165
    move/from16 v22, v4

    .line 166
    .line 167
    const-string v4, "period_start_time"

    .line 168
    .line 169
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 170
    .line 171
    .line 172
    move-result v4

    .line 173
    move/from16 v23, v4

    .line 174
    .line 175
    const-string v4, "minimum_retention_duration"

    .line 176
    .line 177
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 178
    .line 179
    .line 180
    move-result v4

    .line 181
    move/from16 v24, v4

    .line 182
    .line 183
    const-string v4, "schedule_requested_at"

    .line 184
    .line 185
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 186
    .line 187
    .line 188
    move-result v4

    .line 189
    move/from16 v25, v4

    .line 190
    .line 191
    const-string v4, "run_in_foreground"

    .line 192
    .line 193
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 194
    .line 195
    .line 196
    move-result v4

    .line 197
    move/from16 v26, v4

    .line 198
    .line 199
    const-string v4, "out_of_quota_policy"

    .line 200
    .line 201
    invoke-static {v2, v4}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 202
    .line 203
    .line 204
    move-result v4

    .line 205
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 206
    .line 207
    .line 208
    move-result v27

    .line 209
    if-eqz v27, :cond_6

    .line 210
    .line 211
    invoke-interface {v2, v13}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v13

    .line 215
    invoke-interface {v2, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 216
    .line 217
    .line 218
    move-result-object v15

    .line 219
    move/from16 v27, v4

    .line 220
    .line 221
    new-instance v4, Lg1/c;

    .line 222
    .line 223
    invoke-direct {v4}, Lg1/c;-><init>()V

    .line 224
    .line 225
    .line 226
    invoke-interface {v2, v5}, Landroid/database/Cursor;->getInt(I)I

    .line 227
    .line 228
    .line 229
    move-result v5

    .line 230
    invoke-static {v5}, La/a;->y(I)I

    .line 231
    .line 232
    .line 233
    move-result v5

    .line 234
    iput v5, v4, Lg1/c;->a:I

    .line 235
    .line 236
    invoke-interface {v2, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 237
    .line 238
    .line 239
    move-result v5

    .line 240
    if-eqz v5, :cond_1

    .line 241
    .line 242
    const/4 v5, 0x1

    .line 243
    goto :goto_1

    .line 244
    :cond_1
    const/4 v5, 0x0

    .line 245
    :goto_1
    iput-boolean v5, v4, Lg1/c;->b:Z

    .line 246
    .line 247
    invoke-interface {v2, v7}, Landroid/database/Cursor;->getInt(I)I

    .line 248
    .line 249
    .line 250
    move-result v5

    .line 251
    if-eqz v5, :cond_2

    .line 252
    .line 253
    const/4 v5, 0x1

    .line 254
    goto :goto_2

    .line 255
    :cond_2
    const/4 v5, 0x0

    .line 256
    :goto_2
    iput-boolean v5, v4, Lg1/c;->c:Z

    .line 257
    .line 258
    invoke-interface {v2, v8}, Landroid/database/Cursor;->getInt(I)I

    .line 259
    .line 260
    .line 261
    move-result v5

    .line 262
    if-eqz v5, :cond_3

    .line 263
    .line 264
    const/4 v5, 0x1

    .line 265
    goto :goto_3

    .line 266
    :cond_3
    const/4 v5, 0x0

    .line 267
    :goto_3
    iput-boolean v5, v4, Lg1/c;->d:Z

    .line 268
    .line 269
    invoke-interface {v2, v9}, Landroid/database/Cursor;->getInt(I)I

    .line 270
    .line 271
    .line 272
    move-result v5

    .line 273
    if-eqz v5, :cond_4

    .line 274
    .line 275
    const/4 v5, 0x1

    .line 276
    goto :goto_4

    .line 277
    :cond_4
    const/4 v5, 0x0

    .line 278
    :goto_4
    iput-boolean v5, v4, Lg1/c;->e:Z

    .line 279
    .line 280
    invoke-interface {v2, v10}, Landroid/database/Cursor;->getLong(I)J

    .line 281
    .line 282
    .line 283
    move-result-wide v5

    .line 284
    iput-wide v5, v4, Lg1/c;->f:J

    .line 285
    .line 286
    invoke-interface {v2, v11}, Landroid/database/Cursor;->getLong(I)J

    .line 287
    .line 288
    .line 289
    move-result-wide v5

    .line 290
    iput-wide v5, v4, Lg1/c;->g:J

    .line 291
    .line 292
    invoke-interface {v2, v12}, Landroid/database/Cursor;->getBlob(I)[B

    .line 293
    .line 294
    .line 295
    move-result-object v5

    .line 296
    invoke-static {v5}, La/a;->b([B)Lg1/e;

    .line 297
    .line 298
    .line 299
    move-result-object v5

    .line 300
    iput-object v5, v4, Lg1/c;->h:Lg1/e;

    .line 301
    .line 302
    new-instance v5, Lp1/j;

    .line 303
    .line 304
    invoke-direct {v5, v13, v15}, Lp1/j;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 305
    .line 306
    .line 307
    invoke-interface {v2, v14}, Landroid/database/Cursor;->getInt(I)I

    .line 308
    .line 309
    .line 310
    move-result v6

    .line 311
    invoke-static {v6}, La/a;->A(I)I

    .line 312
    .line 313
    .line 314
    move-result v6

    .line 315
    iput v6, v5, Lp1/j;->b:I

    .line 316
    .line 317
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 318
    .line 319
    .line 320
    move-result-object v0

    .line 321
    iput-object v0, v5, Lp1/j;->d:Ljava/lang/String;

    .line 322
    .line 323
    invoke-interface {v2, v3}, Landroid/database/Cursor;->getBlob(I)[B

    .line 324
    .line 325
    .line 326
    move-result-object v0

    .line 327
    invoke-static {v0}, Lg1/h;->a([B)Lg1/h;

    .line 328
    .line 329
    .line 330
    move-result-object v0

    .line 331
    iput-object v0, v5, Lp1/j;->e:Lg1/h;

    .line 332
    .line 333
    invoke-interface {v2, v1}, Landroid/database/Cursor;->getBlob(I)[B

    .line 334
    .line 335
    .line 336
    move-result-object v0

    .line 337
    invoke-static {v0}, Lg1/h;->a([B)Lg1/h;

    .line 338
    .line 339
    .line 340
    move-result-object v0

    .line 341
    iput-object v0, v5, Lp1/j;->f:Lg1/h;

    .line 342
    .line 343
    move/from16 v0, v17

    .line 344
    .line 345
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 346
    .line 347
    .line 348
    move-result-wide v0

    .line 349
    iput-wide v0, v5, Lp1/j;->g:J

    .line 350
    .line 351
    move/from16 v0, v18

    .line 352
    .line 353
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 354
    .line 355
    .line 356
    move-result-wide v0

    .line 357
    iput-wide v0, v5, Lp1/j;->h:J

    .line 358
    .line 359
    move/from16 v0, v19

    .line 360
    .line 361
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 362
    .line 363
    .line 364
    move-result-wide v0

    .line 365
    iput-wide v0, v5, Lp1/j;->i:J

    .line 366
    .line 367
    move/from16 v0, v20

    .line 368
    .line 369
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 370
    .line 371
    .line 372
    move-result v0

    .line 373
    iput v0, v5, Lp1/j;->k:I

    .line 374
    .line 375
    move/from16 v0, v21

    .line 376
    .line 377
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 378
    .line 379
    .line 380
    move-result v0

    .line 381
    invoke-static {v0}, La/a;->x(I)I

    .line 382
    .line 383
    .line 384
    move-result v0

    .line 385
    iput v0, v5, Lp1/j;->l:I

    .line 386
    .line 387
    move/from16 v0, v22

    .line 388
    .line 389
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 390
    .line 391
    .line 392
    move-result-wide v0

    .line 393
    iput-wide v0, v5, Lp1/j;->m:J

    .line 394
    .line 395
    move/from16 v0, v23

    .line 396
    .line 397
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 398
    .line 399
    .line 400
    move-result-wide v0

    .line 401
    iput-wide v0, v5, Lp1/j;->n:J

    .line 402
    .line 403
    move/from16 v0, v24

    .line 404
    .line 405
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 406
    .line 407
    .line 408
    move-result-wide v0

    .line 409
    iput-wide v0, v5, Lp1/j;->o:J

    .line 410
    .line 411
    move/from16 v0, v25

    .line 412
    .line 413
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getLong(I)J

    .line 414
    .line 415
    .line 416
    move-result-wide v0

    .line 417
    iput-wide v0, v5, Lp1/j;->p:J

    .line 418
    .line 419
    move/from16 v0, v26

    .line 420
    .line 421
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 422
    .line 423
    .line 424
    move-result v0

    .line 425
    if-eqz v0, :cond_5

    .line 426
    .line 427
    const/4 v3, 0x1

    .line 428
    goto :goto_5

    .line 429
    :cond_5
    const/4 v3, 0x0

    .line 430
    :goto_5
    iput-boolean v3, v5, Lp1/j;->q:Z

    .line 431
    .line 432
    move/from16 v0, v27

    .line 433
    .line 434
    invoke-interface {v2, v0}, Landroid/database/Cursor;->getInt(I)I

    .line 435
    .line 436
    .line 437
    move-result v0

    .line 438
    invoke-static {v0}, La/a;->z(I)I

    .line 439
    .line 440
    .line 441
    move-result v0

    .line 442
    iput v0, v5, Lp1/j;->r:I

    .line 443
    .line 444
    iput-object v4, v5, Lp1/j;->j:Lg1/c;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 445
    .line 446
    goto :goto_6

    .line 447
    :catchall_0
    move-exception v0

    .line 448
    goto :goto_7

    .line 449
    :cond_6
    const/4 v5, 0x0

    .line 450
    :goto_6
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 451
    .line 452
    .line 453
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 454
    .line 455
    .line 456
    return-object v5

    .line 457
    :catchall_1
    move-exception v0

    .line 458
    move-object/from16 v16, v4

    .line 459
    .line 460
    :goto_7
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 461
    .line 462
    .line 463
    invoke-virtual/range {v16 .. v16}, LH0/B;->k()V

    .line 464
    .line 465
    .line 466
    throw v0
.end method

.method public m(Ljava/lang/String;)Ljava/util/ArrayList;
    .locals 6

    .line 1
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    const-string v2, "SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)"

    .line 7
    .line 8
    invoke-static {v1, v2}, LH0/B;->f(ILjava/lang/String;)LH0/B;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    if-nez p1, :cond_0

    .line 13
    .line 14
    invoke-virtual {v2, v1}, LH0/B;->b(I)V

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-virtual {v2, v1, p1}, LH0/B;->p(ILjava/lang/String;)V

    .line 19
    .line 20
    .line 21
    :goto_0
    invoke-virtual {v0}, LH0/w;->b()V

    .line 22
    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    invoke-static {v0, v2, p1}, Lf5/b;->G(LH0/w;LH0/B;Z)Landroid/database/Cursor;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    :try_start_0
    const-string v0, "id"

    .line 30
    .line 31
    invoke-static {p1, v0}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    const-string v1, "state"

    .line 36
    .line 37
    invoke-static {p1, v1}, Lcom/google/android/gms/internal/measurement/e2;->n(Landroid/database/Cursor;Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    move-result v1

    .line 41
    new-instance v3, Ljava/util/ArrayList;

    .line 42
    .line 43
    invoke-interface {p1}, Landroid/database/Cursor;->getCount()I

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 48
    .line 49
    .line 50
    :goto_1
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    .line 51
    .line 52
    .line 53
    move-result v4

    .line 54
    if-eqz v4, :cond_1

    .line 55
    .line 56
    new-instance v4, Lp1/h;

    .line 57
    .line 58
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 59
    .line 60
    .line 61
    invoke-interface {p1, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    iput-object v5, v4, Lp1/h;->a:Ljava/lang/String;

    .line 66
    .line 67
    invoke-interface {p1, v1}, Landroid/database/Cursor;->getInt(I)I

    .line 68
    .line 69
    .line 70
    move-result v5

    .line 71
    invoke-static {v5}, La/a;->A(I)I

    .line 72
    .line 73
    .line 74
    move-result v5

    .line 75
    iput v5, v4, Lp1/h;->b:I

    .line 76
    .line 77
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 78
    .line 79
    .line 80
    goto :goto_1

    .line 81
    :catchall_0
    move-exception v0

    .line 82
    goto :goto_2

    .line 83
    :cond_1
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v2}, LH0/B;->k()V

    .line 87
    .line 88
    .line 89
    return-object v3

    .line 90
    :goto_2
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v2}, LH0/B;->k()V

    .line 94
    .line 95
    .line 96
    throw v0
.end method

.method public o(JLjava/lang/String;)V
    .locals 4

    .line 1
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, LH0/w;->b()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LA5/f;->h:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lp1/e;

    .line 11
    .line 12
    invoke-virtual {v1}, LH0/C;->a()LT0/j;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x1

    .line 17
    invoke-interface {v2, p1, p2, v3}, LS0/e;->d(JI)V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x2

    .line 21
    if-nez p3, :cond_0

    .line 22
    .line 23
    invoke-interface {v2, p1}, LS0/e;->b(I)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    invoke-interface {v2, p1, p3}, LS0/e;->p(ILjava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :goto_0
    invoke-virtual {v0}, LH0/w;->c()V

    .line 31
    .line 32
    .line 33
    :try_start_0
    invoke-virtual {v2}, LT0/j;->a()I

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0}, LH0/w;->q()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, LH0/w;->n()V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1, v2}, LH0/C;->i(LT0/j;)V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :catchall_0
    move-exception p1

    .line 47
    invoke-virtual {v0}, LH0/w;->n()V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v1, v2}, LH0/C;->i(LT0/j;)V

    .line 51
    .line 52
    .line 53
    throw p1
.end method

.method public p(Ljava/lang/String;Lg1/h;)V
    .locals 4

    .line 1
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, LH0/w;->b()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LA5/f;->d:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lp1/e;

    .line 11
    .line 12
    invoke-virtual {v1}, LH0/C;->a()LT0/j;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    invoke-static {p2}, Lg1/h;->b(Lg1/h;)[B

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    const/4 v3, 0x1

    .line 21
    if-nez p2, :cond_0

    .line 22
    .line 23
    invoke-interface {v2, v3}, LS0/e;->b(I)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    invoke-interface {v2, v3, p2}, LS0/e;->U(I[B)V

    .line 28
    .line 29
    .line 30
    :goto_0
    const/4 p2, 0x2

    .line 31
    if-nez p1, :cond_1

    .line 32
    .line 33
    invoke-interface {v2, p2}, LS0/e;->b(I)V

    .line 34
    .line 35
    .line 36
    goto :goto_1

    .line 37
    :cond_1
    invoke-interface {v2, p2, p1}, LS0/e;->p(ILjava/lang/String;)V

    .line 38
    .line 39
    .line 40
    :goto_1
    invoke-virtual {v0}, LH0/w;->c()V

    .line 41
    .line 42
    .line 43
    :try_start_0
    invoke-virtual {v2}, LT0/j;->a()I

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0}, LH0/w;->q()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, LH0/w;->n()V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v1, v2}, LH0/C;->i(LT0/j;)V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :catchall_0
    move-exception p1

    .line 57
    invoke-virtual {v0}, LH0/w;->n()V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v1, v2}, LH0/C;->i(LT0/j;)V

    .line 61
    .line 62
    .line 63
    throw p1
.end method

.method public q(JLjava/lang/String;)V
    .locals 4

    .line 1
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, LH0/w;->b()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LA5/f;->e:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lp1/e;

    .line 11
    .line 12
    invoke-virtual {v1}, LH0/C;->a()LT0/j;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x1

    .line 17
    invoke-interface {v2, p1, p2, v3}, LS0/e;->d(JI)V

    .line 18
    .line 19
    .line 20
    const/4 p1, 0x2

    .line 21
    if-nez p3, :cond_0

    .line 22
    .line 23
    invoke-interface {v2, p1}, LS0/e;->b(I)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :cond_0
    invoke-interface {v2, p1, p3}, LS0/e;->p(ILjava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :goto_0
    invoke-virtual {v0}, LH0/w;->c()V

    .line 31
    .line 32
    .line 33
    :try_start_0
    invoke-virtual {v2}, LT0/j;->a()I

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0}, LH0/w;->q()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, LH0/w;->n()V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1, v2}, LH0/C;->i(LT0/j;)V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :catchall_0
    move-exception p1

    .line 47
    invoke-virtual {v0}, LH0/w;->n()V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v1, v2}, LH0/C;->i(LT0/j;)V

    .line 51
    .line 52
    .line 53
    throw p1
.end method

.method public varargs r(I[Ljava/lang/String;)V
    .locals 5

    .line 1
    iget-object v0, p0, LA5/f;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/WorkDatabase_Impl;

    .line 4
    .line 5
    invoke-virtual {v0}, LH0/w;->b()V

    .line 6
    .line 7
    .line 8
    new-instance v1, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 11
    .line 12
    .line 13
    const-string v2, "UPDATE workspec SET state=? WHERE id IN ("

    .line 14
    .line 15
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    array-length v2, p2

    .line 19
    invoke-static {v2, v1}, LK3/h;->a(ILjava/lang/StringBuilder;)V

    .line 20
    .line 21
    .line 22
    const-string v2, ")"

    .line 23
    .line 24
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    const-string v2, "sql"

    .line 32
    .line 33
    invoke-static {v1, v2}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v0}, LH0/w;->a()V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, LH0/w;->b()V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, LH0/w;->i()LS0/d;

    .line 43
    .line 44
    .line 45
    move-result-object v2

    .line 46
    invoke-interface {v2}, LS0/d;->a0()LS0/a;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-interface {v2, v1}, LS0/a;->v(Ljava/lang/String;)LT0/j;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-static {p1}, La/a;->J(I)I

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    int-to-long v2, p1

    .line 59
    const/4 p1, 0x1

    .line 60
    invoke-interface {v1, v2, v3, p1}, LS0/e;->d(JI)V

    .line 61
    .line 62
    .line 63
    array-length p1, p2

    .line 64
    const/4 v2, 0x2

    .line 65
    const/4 v3, 0x0

    .line 66
    :goto_0
    if-ge v3, p1, :cond_1

    .line 67
    .line 68
    aget-object v4, p2, v3

    .line 69
    .line 70
    if-nez v4, :cond_0

    .line 71
    .line 72
    invoke-interface {v1, v2}, LS0/e;->b(I)V

    .line 73
    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_0
    invoke-interface {v1, v2, v4}, LS0/e;->p(ILjava/lang/String;)V

    .line 77
    .line 78
    .line 79
    :goto_1
    add-int/lit8 v2, v2, 0x1

    .line 80
    .line 81
    add-int/lit8 v3, v3, 0x1

    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_1
    invoke-virtual {v0}, LH0/w;->c()V

    .line 85
    .line 86
    .line 87
    :try_start_0
    invoke-virtual {v1}, LT0/j;->a()I

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0}, LH0/w;->q()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0}, LH0/w;->n()V

    .line 94
    .line 95
    .line 96
    return-void

    .line 97
    :catchall_0
    move-exception p1

    .line 98
    invoke-virtual {v0}, LH0/w;->n()V

    .line 99
    .line 100
    .line 101
    throw p1
.end method
