.class public interface abstract LA5/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f(Ld2/b;Lorg/json/JSONObject;)LA5/c;
.end method
