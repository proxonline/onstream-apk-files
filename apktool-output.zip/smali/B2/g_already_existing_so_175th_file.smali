.class public interface abstract Lb2/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract apply(Ljava/lang/Object;)Ljava/lang/Object;
.end method
