.class public final LI6/c;
.super LU2/e;
.source "SourceFile"


# instance fields
.field public final synthetic m:I

.field public final n:LS8/y;

.field public final o:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .locals 2

    .line 1
    iput p1, p0, LI6/c;->m:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, LU2/e;-><init>()V

    .line 7
    .line 8
    .line 9
    new-instance p1, LS8/y;

    .line 10
    .line 11
    const/4 v0, 0x5

    .line 12
    const/4 v1, 0x0

    .line 13
    invoke-direct {p1, v0, v1}, LS8/y;-><init>(IZ)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, LI6/c;->n:LS8/y;

    .line 17
    .line 18
    new-instance p1, LI6/b;

    .line 19
    .line 20
    invoke-direct {p1}, LI6/b;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, LI6/c;->o:Ljava/lang/Object;

    .line 24
    .line 25
    return-void

    .line 26
    :pswitch_0
    invoke-direct {p0}, LU2/e;-><init>()V

    .line 27
    .line 28
    .line 29
    new-instance p1, LS8/y;

    .line 30
    .line 31
    const/4 v0, 0x5

    .line 32
    const/4 v1, 0x0

    .line 33
    invoke-direct {p1, v0, v1}, LS8/y;-><init>(IZ)V

    .line 34
    .line 35
    .line 36
    iput-object p1, p0, LI6/c;->n:LS8/y;

    .line 37
    .line 38
    new-instance p1, Ld3/a;

    .line 39
    .line 40
    invoke-direct {p1}, Ld3/a;-><init>()V

    .line 41
    .line 42
    .line 43
    iput-object p1, p0, LI6/c;->o:Ljava/lang/Object;

    .line 44
    .line 45
    return-void

    .line 46
    nop

    .line 47
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final f(IZ[B)LU2/f;
    .locals 28

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move/from16 v0, p1

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    iget v3, v1, LI6/c;->m:I

    .line 8
    .line 9
    const-string v4, ";"

    .line 10
    .line 11
    const-string v6, "\\."

    .line 12
    .line 13
    const-string v8, ")"

    .line 14
    .line 15
    const-string v10, "("

    .line 16
    .line 17
    const-string v11, "::cue"

    .line 18
    .line 19
    const-string v14, ""

    .line 20
    .line 21
    const-string v15, "}"

    .line 22
    .line 23
    const-string v13, "{"

    .line 24
    .line 25
    iget-object v5, v1, LI6/c;->o:Ljava/lang/Object;

    .line 26
    .line 27
    const-string v7, "NOTE"

    .line 28
    .line 29
    const-string v9, "STYLE"

    .line 30
    .line 31
    iget-object v12, v1, LI6/c;->n:LS8/y;

    .line 32
    .line 33
    packed-switch v3, :pswitch_data_0

    .line 34
    .line 35
    .line 36
    invoke-virtual {v12, v0, v2}, LS8/y;->F(I[B)V

    .line 37
    .line 38
    .line 39
    new-instance v0, Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 42
    .line 43
    .line 44
    :try_start_0
    invoke-static {v12}, Ld3/i;->c(LS8/y;)V
    :try_end_0
    .catch Lf2/j0; {:try_start_0 .. :try_end_0} :catch_0

    .line 45
    .line 46
    .line 47
    :goto_0
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    if-nez v2, :cond_0

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_0
    new-instance v2, Ljava/util/ArrayList;

    .line 59
    .line 60
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 61
    .line 62
    .line 63
    :goto_1
    move-object/from16 v20, v5

    .line 64
    .line 65
    const/4 v1, 0x0

    .line 66
    const/4 v3, -0x1

    .line 67
    :goto_2
    const/4 v5, -0x1

    .line 68
    if-ne v3, v5, :cond_4

    .line 69
    .line 70
    iget v1, v12, LS8/y;->a:I

    .line 71
    .line 72
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    if-nez v3, :cond_1

    .line 77
    .line 78
    const/4 v3, 0x0

    .line 79
    goto :goto_2

    .line 80
    :cond_1
    invoke-virtual {v9, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    move-result v5

    .line 84
    if-eqz v5, :cond_2

    .line 85
    .line 86
    const/4 v3, 0x2

    .line 87
    goto :goto_2

    .line 88
    :cond_2
    invoke-virtual {v3, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 89
    .line 90
    .line 91
    move-result v3

    .line 92
    if-eqz v3, :cond_3

    .line 93
    .line 94
    const/4 v3, 0x1

    .line 95
    goto :goto_2

    .line 96
    :cond_3
    const/4 v3, 0x3

    .line 97
    goto :goto_2

    .line 98
    :cond_4
    invoke-virtual {v12, v1}, LS8/y;->H(I)V

    .line 99
    .line 100
    .line 101
    if-eqz v3, :cond_38

    .line 102
    .line 103
    const/4 v1, 0x1

    .line 104
    if-ne v3, v1, :cond_6

    .line 105
    .line 106
    :goto_3
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    if-nez v1, :cond_5

    .line 115
    .line 116
    goto :goto_3

    .line 117
    :cond_5
    move-object/from16 v5, v20

    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_6
    const/4 v1, 0x2

    .line 121
    if-ne v3, v1, :cond_37

    .line 122
    .line 123
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 124
    .line 125
    .line 126
    move-result v1

    .line 127
    if-eqz v1, :cond_36

    .line 128
    .line 129
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-object/from16 v5, v20

    .line 133
    .line 134
    check-cast v5, Ld3/a;

    .line 135
    .line 136
    iget-object v1, v5, Ld3/a;->a:LS8/y;

    .line 137
    .line 138
    iget-object v3, v5, Ld3/a;->b:Ljava/lang/StringBuilder;

    .line 139
    .line 140
    const/4 v5, 0x0

    .line 141
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 142
    .line 143
    .line 144
    iget v5, v12, LS8/y;->a:I

    .line 145
    .line 146
    :cond_7
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v21

    .line 150
    invoke-static/range {v21 .. v21}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 151
    .line 152
    .line 153
    move-result v21

    .line 154
    if-eqz v21, :cond_7

    .line 155
    .line 156
    move-object/from16 v21, v7

    .line 157
    .line 158
    iget-object v7, v12, LS8/y;->c:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v7, [B

    .line 161
    .line 162
    move-object/from16 v22, v9

    .line 163
    .line 164
    iget v9, v12, LS8/y;->a:I

    .line 165
    .line 166
    invoke-virtual {v1, v9, v7}, LS8/y;->F(I[B)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v1, v5}, LS8/y;->H(I)V

    .line 170
    .line 171
    .line 172
    new-instance v5, Ljava/util/ArrayList;

    .line 173
    .line 174
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 175
    .line 176
    .line 177
    :goto_4
    invoke-static {v1}, Ld3/a;->c(LS8/y;)V

    .line 178
    .line 179
    .line 180
    invoke-virtual {v1}, LS8/y;->e()I

    .line 181
    .line 182
    .line 183
    move-result v7

    .line 184
    const/4 v9, 0x5

    .line 185
    if-ge v7, v9, :cond_8

    .line 186
    .line 187
    :goto_5
    const/4 v7, 0x0

    .line 188
    goto/16 :goto_9

    .line 189
    .line 190
    :cond_8
    sget-object v7, LK4/e;->c:Ljava/nio/charset/Charset;

    .line 191
    .line 192
    invoke-virtual {v1, v9, v7}, LS8/y;->v(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 193
    .line 194
    .line 195
    move-result-object v7

    .line 196
    invoke-virtual {v11, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 197
    .line 198
    .line 199
    move-result v7

    .line 200
    if-nez v7, :cond_9

    .line 201
    .line 202
    goto :goto_5

    .line 203
    :cond_9
    iget v7, v1, LS8/y;->a:I

    .line 204
    .line 205
    invoke-static {v1, v3}, Ld3/a;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object v9

    .line 209
    if-nez v9, :cond_a

    .line 210
    .line 211
    goto :goto_5

    .line 212
    :cond_a
    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result v23

    .line 216
    if-eqz v23, :cond_b

    .line 217
    .line 218
    invoke-virtual {v1, v7}, LS8/y;->H(I)V

    .line 219
    .line 220
    .line 221
    move-object v7, v14

    .line 222
    goto :goto_9

    .line 223
    :cond_b
    invoke-virtual {v10, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 224
    .line 225
    .line 226
    move-result v7

    .line 227
    if-eqz v7, :cond_e

    .line 228
    .line 229
    iget v7, v1, LS8/y;->a:I

    .line 230
    .line 231
    iget v9, v1, LS8/y;->b:I

    .line 232
    .line 233
    const/16 v23, 0x0

    .line 234
    .line 235
    :goto_6
    if-ge v7, v9, :cond_d

    .line 236
    .line 237
    if-nez v23, :cond_d

    .line 238
    .line 239
    move/from16 v23, v7

    .line 240
    .line 241
    iget-object v7, v1, LS8/y;->c:Ljava/lang/Object;

    .line 242
    .line 243
    check-cast v7, [B

    .line 244
    .line 245
    add-int/lit8 v24, v23, 0x1

    .line 246
    .line 247
    aget-byte v7, v7, v23

    .line 248
    .line 249
    int-to-char v7, v7

    .line 250
    move/from16 p1, v9

    .line 251
    .line 252
    const/16 v9, 0x29

    .line 253
    .line 254
    if-ne v7, v9, :cond_c

    .line 255
    .line 256
    const/16 v23, 0x1

    .line 257
    .line 258
    goto :goto_7

    .line 259
    :cond_c
    const/16 v23, 0x0

    .line 260
    .line 261
    :goto_7
    move/from16 v9, p1

    .line 262
    .line 263
    move/from16 v7, v24

    .line 264
    .line 265
    goto :goto_6

    .line 266
    :cond_d
    move/from16 v23, v7

    .line 267
    .line 268
    add-int/lit8 v7, v23, -0x1

    .line 269
    .line 270
    iget v9, v1, LS8/y;->a:I

    .line 271
    .line 272
    sub-int/2addr v7, v9

    .line 273
    sget-object v9, LK4/e;->c:Ljava/nio/charset/Charset;

    .line 274
    .line 275
    invoke-virtual {v1, v7, v9}, LS8/y;->v(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 276
    .line 277
    .line 278
    move-result-object v7

    .line 279
    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    move-result-object v7

    .line 283
    goto :goto_8

    .line 284
    :cond_e
    const/4 v7, 0x0

    .line 285
    :goto_8
    invoke-static {v1, v3}, Ld3/a;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 286
    .line 287
    .line 288
    move-result-object v9

    .line 289
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 290
    .line 291
    .line 292
    move-result v9

    .line 293
    if-nez v9, :cond_f

    .line 294
    .line 295
    goto :goto_5

    .line 296
    :cond_f
    :goto_9
    if-eqz v7, :cond_10

    .line 297
    .line 298
    invoke-static {v1, v3}, Ld3/a;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 299
    .line 300
    .line 301
    move-result-object v9

    .line 302
    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 303
    .line 304
    .line 305
    move-result v9

    .line 306
    if-nez v9, :cond_11

    .line 307
    .line 308
    :cond_10
    move-object/from16 v26, v6

    .line 309
    .line 310
    move-object/from16 v23, v8

    .line 311
    .line 312
    move-object/from16 v24, v10

    .line 313
    .line 314
    move-object/from16 v25, v13

    .line 315
    .line 316
    goto/16 :goto_1c

    .line 317
    .line 318
    :cond_11
    new-instance v9, Ld3/b;

    .line 319
    .line 320
    invoke-direct {v9}, Ld3/b;-><init>()V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v14, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 324
    .line 325
    .line 326
    move-result v23

    .line 327
    if-eqz v23, :cond_12

    .line 328
    .line 329
    move-object/from16 v26, v6

    .line 330
    .line 331
    move-object/from16 v23, v8

    .line 332
    .line 333
    move-object/from16 v24, v10

    .line 334
    .line 335
    move-object/from16 v25, v13

    .line 336
    .line 337
    goto/16 :goto_d

    .line 338
    .line 339
    :cond_12
    move-object/from16 v23, v8

    .line 340
    .line 341
    move-object/from16 v24, v10

    .line 342
    .line 343
    const/16 v8, 0x5b

    .line 344
    .line 345
    invoke-virtual {v7, v8}, Ljava/lang/String;->indexOf(I)I

    .line 346
    .line 347
    .line 348
    move-result v10

    .line 349
    const/4 v8, -0x1

    .line 350
    if-eq v10, v8, :cond_14

    .line 351
    .line 352
    sget-object v8, Ld3/a;->c:Ljava/util/regex/Pattern;

    .line 353
    .line 354
    move-object/from16 v25, v13

    .line 355
    .line 356
    invoke-virtual {v7, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v13

    .line 360
    invoke-virtual {v8, v13}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 361
    .line 362
    .line 363
    move-result-object v8

    .line 364
    invoke-virtual {v8}, Ljava/util/regex/Matcher;->matches()Z

    .line 365
    .line 366
    .line 367
    move-result v13

    .line 368
    if-eqz v13, :cond_13

    .line 369
    .line 370
    const/4 v13, 0x1

    .line 371
    invoke-virtual {v8, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v8

    .line 375
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 376
    .line 377
    .line 378
    iput-object v8, v9, Ld3/b;->d:Ljava/lang/String;

    .line 379
    .line 380
    :cond_13
    const/4 v8, 0x0

    .line 381
    invoke-virtual {v7, v8, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 382
    .line 383
    .line 384
    move-result-object v7

    .line 385
    goto :goto_a

    .line 386
    :cond_14
    move-object/from16 v25, v13

    .line 387
    .line 388
    const/4 v8, 0x0

    .line 389
    :goto_a
    sget v10, Lh3/y;->a:I

    .line 390
    .line 391
    const/4 v10, -0x1

    .line 392
    invoke-virtual {v7, v6, v10}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 393
    .line 394
    .line 395
    move-result-object v7

    .line 396
    aget-object v13, v7, v8

    .line 397
    .line 398
    move-object/from16 v26, v6

    .line 399
    .line 400
    const/16 v8, 0x23

    .line 401
    .line 402
    invoke-virtual {v13, v8}, Ljava/lang/String;->indexOf(I)I

    .line 403
    .line 404
    .line 405
    move-result v6

    .line 406
    if-eq v6, v10, :cond_15

    .line 407
    .line 408
    const/4 v8, 0x0

    .line 409
    invoke-virtual {v13, v8, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 410
    .line 411
    .line 412
    move-result-object v10

    .line 413
    iput-object v10, v9, Ld3/b;->b:Ljava/lang/String;

    .line 414
    .line 415
    add-int/lit8 v6, v6, 0x1

    .line 416
    .line 417
    invoke-virtual {v13, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 418
    .line 419
    .line 420
    move-result-object v6

    .line 421
    iput-object v6, v9, Ld3/b;->a:Ljava/lang/String;

    .line 422
    .line 423
    goto :goto_b

    .line 424
    :cond_15
    iput-object v13, v9, Ld3/b;->b:Ljava/lang/String;

    .line 425
    .line 426
    :goto_b
    array-length v6, v7

    .line 427
    const/4 v13, 0x1

    .line 428
    if-le v6, v13, :cond_17

    .line 429
    .line 430
    array-length v6, v7

    .line 431
    array-length v8, v7

    .line 432
    if-gt v6, v8, :cond_16

    .line 433
    .line 434
    move/from16 v18, v13

    .line 435
    .line 436
    goto :goto_c

    .line 437
    :cond_16
    const/16 v18, 0x0

    .line 438
    .line 439
    :goto_c
    invoke-static/range {v18 .. v18}, Lh3/a;->h(Z)V

    .line 440
    .line 441
    .line 442
    invoke-static {v7, v13, v6}, Ljava/util/Arrays;->copyOfRange([Ljava/lang/Object;II)[Ljava/lang/Object;

    .line 443
    .line 444
    .line 445
    move-result-object v6

    .line 446
    check-cast v6, [Ljava/lang/String;

    .line 447
    .line 448
    new-instance v7, Ljava/util/HashSet;

    .line 449
    .line 450
    invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 451
    .line 452
    .line 453
    move-result-object v6

    .line 454
    invoke-direct {v7, v6}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 455
    .line 456
    .line 457
    iput-object v7, v9, Ld3/b;->c:Ljava/util/Set;

    .line 458
    .line 459
    :cond_17
    :goto_d
    const/4 v6, 0x0

    .line 460
    const/4 v7, 0x0

    .line 461
    :goto_e
    if-nez v6, :cond_33

    .line 462
    .line 463
    iget v6, v1, LS8/y;->a:I

    .line 464
    .line 465
    invoke-static {v1, v3}, Ld3/a;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 466
    .line 467
    .line 468
    move-result-object v7

    .line 469
    if-eqz v7, :cond_19

    .line 470
    .line 471
    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 472
    .line 473
    .line 474
    move-result v8

    .line 475
    if-eqz v8, :cond_18

    .line 476
    .line 477
    goto :goto_f

    .line 478
    :cond_18
    const/4 v8, 0x0

    .line 479
    goto :goto_10

    .line 480
    :cond_19
    :goto_f
    const/4 v8, 0x1

    .line 481
    :goto_10
    if-nez v8, :cond_31

    .line 482
    .line 483
    invoke-virtual {v1, v6}, LS8/y;->H(I)V

    .line 484
    .line 485
    .line 486
    invoke-static {v1}, Ld3/a;->c(LS8/y;)V

    .line 487
    .line 488
    .line 489
    invoke-static {v1, v3}, Ld3/a;->a(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 490
    .line 491
    .line 492
    move-result-object v6

    .line 493
    invoke-virtual {v14, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 494
    .line 495
    .line 496
    move-result v10

    .line 497
    if-eqz v10, :cond_1a

    .line 498
    .line 499
    goto/16 :goto_1a

    .line 500
    .line 501
    :cond_1a
    const-string v10, ":"

    .line 502
    .line 503
    invoke-static {v1, v3}, Ld3/a;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 504
    .line 505
    .line 506
    move-result-object v13

    .line 507
    invoke-virtual {v10, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 508
    .line 509
    .line 510
    move-result v10

    .line 511
    if-nez v10, :cond_1b

    .line 512
    .line 513
    goto/16 :goto_1a

    .line 514
    .line 515
    :cond_1b
    invoke-static {v1}, Ld3/a;->c(LS8/y;)V

    .line 516
    .line 517
    .line 518
    new-instance v10, Ljava/lang/StringBuilder;

    .line 519
    .line 520
    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    .line 521
    .line 522
    .line 523
    const/4 v13, 0x0

    .line 524
    :goto_11
    if-nez v13, :cond_1f

    .line 525
    .line 526
    move-object/from16 p1, v7

    .line 527
    .line 528
    iget v7, v1, LS8/y;->a:I

    .line 529
    .line 530
    move/from16 p3, v8

    .line 531
    .line 532
    invoke-static {v1, v3}, Ld3/a;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 533
    .line 534
    .line 535
    move-result-object v8

    .line 536
    if-nez v8, :cond_1c

    .line 537
    .line 538
    const/4 v7, 0x0

    .line 539
    goto :goto_13

    .line 540
    :cond_1c
    invoke-virtual {v15, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 541
    .line 542
    .line 543
    move-result v27

    .line 544
    if-nez v27, :cond_1e

    .line 545
    .line 546
    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 547
    .line 548
    .line 549
    move-result v27

    .line 550
    if-eqz v27, :cond_1d

    .line 551
    .line 552
    goto :goto_12

    .line 553
    :cond_1d
    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 554
    .line 555
    .line 556
    move-object/from16 v7, p1

    .line 557
    .line 558
    move/from16 v8, p3

    .line 559
    .line 560
    goto :goto_11

    .line 561
    :cond_1e
    :goto_12
    invoke-virtual {v1, v7}, LS8/y;->H(I)V

    .line 562
    .line 563
    .line 564
    move-object/from16 v7, p1

    .line 565
    .line 566
    move/from16 v8, p3

    .line 567
    .line 568
    const/4 v13, 0x1

    .line 569
    goto :goto_11

    .line 570
    :cond_1f
    move-object/from16 p1, v7

    .line 571
    .line 572
    move/from16 p3, v8

    .line 573
    .line 574
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 575
    .line 576
    .line 577
    move-result-object v7

    .line 578
    :goto_13
    if-eqz v7, :cond_32

    .line 579
    .line 580
    invoke-virtual {v14, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 581
    .line 582
    .line 583
    move-result v8

    .line 584
    if-eqz v8, :cond_20

    .line 585
    .line 586
    goto/16 :goto_1b

    .line 587
    .line 588
    :cond_20
    iget v8, v1, LS8/y;->a:I

    .line 589
    .line 590
    invoke-static {v1, v3}, Ld3/a;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 591
    .line 592
    .line 593
    move-result-object v10

    .line 594
    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 595
    .line 596
    .line 597
    move-result v13

    .line 598
    if-eqz v13, :cond_21

    .line 599
    .line 600
    goto :goto_14

    .line 601
    :cond_21
    invoke-virtual {v15, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 602
    .line 603
    .line 604
    move-result v10

    .line 605
    if-eqz v10, :cond_32

    .line 606
    .line 607
    invoke-virtual {v1, v8}, LS8/y;->H(I)V

    .line 608
    .line 609
    .line 610
    :goto_14
    const-string v8, "color"

    .line 611
    .line 612
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 613
    .line 614
    .line 615
    move-result v8

    .line 616
    if-eqz v8, :cond_22

    .line 617
    .line 618
    const/4 v13, 0x1

    .line 619
    invoke-static {v7, v13}, Lh3/b;->a(Ljava/lang/String;Z)I

    .line 620
    .line 621
    .line 622
    move-result v6

    .line 623
    iput v6, v9, Ld3/b;->f:I

    .line 624
    .line 625
    iput-boolean v13, v9, Ld3/b;->g:Z

    .line 626
    .line 627
    goto/16 :goto_1b

    .line 628
    .line 629
    :cond_22
    const/4 v13, 0x1

    .line 630
    const-string v8, "background-color"

    .line 631
    .line 632
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 633
    .line 634
    .line 635
    move-result v8

    .line 636
    if-eqz v8, :cond_23

    .line 637
    .line 638
    invoke-static {v7, v13}, Lh3/b;->a(Ljava/lang/String;Z)I

    .line 639
    .line 640
    .line 641
    move-result v6

    .line 642
    iput v6, v9, Ld3/b;->h:I

    .line 643
    .line 644
    iput-boolean v13, v9, Ld3/b;->i:Z

    .line 645
    .line 646
    goto/16 :goto_1b

    .line 647
    .line 648
    :cond_23
    const-string v8, "ruby-position"

    .line 649
    .line 650
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 651
    .line 652
    .line 653
    move-result v8

    .line 654
    if-eqz v8, :cond_25

    .line 655
    .line 656
    const-string v6, "over"

    .line 657
    .line 658
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 659
    .line 660
    .line 661
    move-result v6

    .line 662
    if-eqz v6, :cond_24

    .line 663
    .line 664
    iput v13, v9, Ld3/b;->p:I

    .line 665
    .line 666
    goto/16 :goto_1b

    .line 667
    .line 668
    :cond_24
    const-string v6, "under"

    .line 669
    .line 670
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 671
    .line 672
    .line 673
    move-result v6

    .line 674
    if-eqz v6, :cond_32

    .line 675
    .line 676
    const/4 v6, 0x2

    .line 677
    iput v6, v9, Ld3/b;->p:I

    .line 678
    .line 679
    goto/16 :goto_1b

    .line 680
    .line 681
    :cond_25
    const-string v8, "text-combine-upright"

    .line 682
    .line 683
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 684
    .line 685
    .line 686
    move-result v8

    .line 687
    if-eqz v8, :cond_28

    .line 688
    .line 689
    const-string v6, "all"

    .line 690
    .line 691
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 692
    .line 693
    .line 694
    move-result v6

    .line 695
    if-nez v6, :cond_27

    .line 696
    .line 697
    const-string v6, "digits"

    .line 698
    .line 699
    invoke-virtual {v7, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 700
    .line 701
    .line 702
    move-result v6

    .line 703
    if-eqz v6, :cond_26

    .line 704
    .line 705
    goto :goto_15

    .line 706
    :cond_26
    const/4 v6, 0x0

    .line 707
    goto :goto_16

    .line 708
    :cond_27
    :goto_15
    const/4 v6, 0x1

    .line 709
    :goto_16
    iput-boolean v6, v9, Ld3/b;->q:Z

    .line 710
    .line 711
    goto/16 :goto_1b

    .line 712
    .line 713
    :cond_28
    const-string v8, "text-decoration"

    .line 714
    .line 715
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 716
    .line 717
    .line 718
    move-result v8

    .line 719
    if-eqz v8, :cond_29

    .line 720
    .line 721
    const-string v6, "underline"

    .line 722
    .line 723
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 724
    .line 725
    .line 726
    move-result v6

    .line 727
    if-eqz v6, :cond_32

    .line 728
    .line 729
    const/4 v13, 0x1

    .line 730
    iput v13, v9, Ld3/b;->k:I

    .line 731
    .line 732
    goto/16 :goto_1b

    .line 733
    .line 734
    :cond_29
    const-string v8, "font-family"

    .line 735
    .line 736
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 737
    .line 738
    .line 739
    move-result v8

    .line 740
    if-eqz v8, :cond_2a

    .line 741
    .line 742
    invoke-static {v7}, LK3/h;->v(Ljava/lang/String;)Ljava/lang/String;

    .line 743
    .line 744
    .line 745
    move-result-object v6

    .line 746
    iput-object v6, v9, Ld3/b;->e:Ljava/lang/String;

    .line 747
    .line 748
    goto/16 :goto_1b

    .line 749
    .line 750
    :cond_2a
    const-string v8, "font-weight"

    .line 751
    .line 752
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 753
    .line 754
    .line 755
    move-result v8

    .line 756
    if-eqz v8, :cond_2b

    .line 757
    .line 758
    const-string v6, "bold"

    .line 759
    .line 760
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 761
    .line 762
    .line 763
    move-result v6

    .line 764
    if-eqz v6, :cond_32

    .line 765
    .line 766
    const/4 v13, 0x1

    .line 767
    iput v13, v9, Ld3/b;->l:I

    .line 768
    .line 769
    goto/16 :goto_1b

    .line 770
    .line 771
    :cond_2b
    const/4 v13, 0x1

    .line 772
    const-string v8, "font-style"

    .line 773
    .line 774
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 775
    .line 776
    .line 777
    move-result v8

    .line 778
    if-eqz v8, :cond_2c

    .line 779
    .line 780
    const-string v6, "italic"

    .line 781
    .line 782
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 783
    .line 784
    .line 785
    move-result v6

    .line 786
    if-eqz v6, :cond_32

    .line 787
    .line 788
    iput v13, v9, Ld3/b;->m:I

    .line 789
    .line 790
    goto/16 :goto_1b

    .line 791
    .line 792
    :cond_2c
    const-string v8, "font-size"

    .line 793
    .line 794
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 795
    .line 796
    .line 797
    move-result v6

    .line 798
    if-eqz v6, :cond_32

    .line 799
    .line 800
    sget-object v6, Ld3/a;->d:Ljava/util/regex/Pattern;

    .line 801
    .line 802
    invoke-static {v7}, LK3/h;->v(Ljava/lang/String;)Ljava/lang/String;

    .line 803
    .line 804
    .line 805
    move-result-object v8

    .line 806
    invoke-virtual {v6, v8}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 807
    .line 808
    .line 809
    move-result-object v6

    .line 810
    invoke-virtual {v6}, Ljava/util/regex/Matcher;->matches()Z

    .line 811
    .line 812
    .line 813
    move-result v8

    .line 814
    if-nez v8, :cond_2d

    .line 815
    .line 816
    new-instance v6, Ljava/lang/StringBuilder;

    .line 817
    .line 818
    const-string v8, "Invalid font-size: \'"

    .line 819
    .line 820
    invoke-direct {v6, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 821
    .line 822
    .line 823
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 824
    .line 825
    .line 826
    const-string v7, "\'."

    .line 827
    .line 828
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 829
    .line 830
    .line 831
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 832
    .line 833
    .line 834
    move-result-object v6

    .line 835
    const-string v7, "WebvttCssParser"

    .line 836
    .line 837
    invoke-static {v7, v6}, Lh3/a;->P(Ljava/lang/String;Ljava/lang/String;)V

    .line 838
    .line 839
    .line 840
    goto :goto_1b

    .line 841
    :cond_2d
    const/4 v7, 0x2

    .line 842
    invoke-virtual {v6, v7}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 843
    .line 844
    .line 845
    move-result-object v8

    .line 846
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 847
    .line 848
    .line 849
    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    .line 850
    .line 851
    .line 852
    move-result v7

    .line 853
    sparse-switch v7, :sswitch_data_0

    .line 854
    .line 855
    .line 856
    :goto_17
    const/4 v7, -0x1

    .line 857
    goto :goto_18

    .line 858
    :sswitch_0
    const-string v7, "px"

    .line 859
    .line 860
    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 861
    .line 862
    .line 863
    move-result v7

    .line 864
    if-nez v7, :cond_2e

    .line 865
    .line 866
    goto :goto_17

    .line 867
    :cond_2e
    const/4 v7, 0x2

    .line 868
    goto :goto_18

    .line 869
    :sswitch_1
    const-string v7, "em"

    .line 870
    .line 871
    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 872
    .line 873
    .line 874
    move-result v7

    .line 875
    if-nez v7, :cond_2f

    .line 876
    .line 877
    goto :goto_17

    .line 878
    :cond_2f
    const/4 v7, 0x1

    .line 879
    goto :goto_18

    .line 880
    :sswitch_2
    const-string v7, "%"

    .line 881
    .line 882
    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 883
    .line 884
    .line 885
    move-result v7

    .line 886
    if-nez v7, :cond_30

    .line 887
    .line 888
    goto :goto_17

    .line 889
    :cond_30
    const/4 v7, 0x0

    .line 890
    :goto_18
    packed-switch v7, :pswitch_data_1

    .line 891
    .line 892
    .line 893
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 894
    .line 895
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 896
    .line 897
    .line 898
    throw v0

    .line 899
    :pswitch_0
    const/4 v13, 0x1

    .line 900
    iput v13, v9, Ld3/b;->n:I

    .line 901
    .line 902
    goto :goto_19

    .line 903
    :pswitch_1
    const/4 v7, 0x2

    .line 904
    const/4 v13, 0x1

    .line 905
    iput v7, v9, Ld3/b;->n:I

    .line 906
    .line 907
    goto :goto_19

    .line 908
    :pswitch_2
    const/4 v7, 0x3

    .line 909
    const/4 v13, 0x1

    .line 910
    iput v7, v9, Ld3/b;->n:I

    .line 911
    .line 912
    :goto_19
    invoke-virtual {v6, v13}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 913
    .line 914
    .line 915
    move-result-object v6

    .line 916
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 917
    .line 918
    .line 919
    invoke-static {v6}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 920
    .line 921
    .line 922
    move-result v6

    .line 923
    iput v6, v9, Ld3/b;->o:F

    .line 924
    .line 925
    goto :goto_1b

    .line 926
    :cond_31
    :goto_1a
    move-object/from16 p1, v7

    .line 927
    .line 928
    move/from16 p3, v8

    .line 929
    .line 930
    :cond_32
    :goto_1b
    move-object/from16 v7, p1

    .line 931
    .line 932
    move/from16 v6, p3

    .line 933
    .line 934
    goto/16 :goto_e

    .line 935
    .line 936
    :cond_33
    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 937
    .line 938
    .line 939
    move-result v6

    .line 940
    if-eqz v6, :cond_34

    .line 941
    .line 942
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 943
    .line 944
    .line 945
    :cond_34
    move-object/from16 v8, v23

    .line 946
    .line 947
    move-object/from16 v10, v24

    .line 948
    .line 949
    move-object/from16 v13, v25

    .line 950
    .line 951
    move-object/from16 v6, v26

    .line 952
    .line 953
    goto/16 :goto_4

    .line 954
    .line 955
    :goto_1c
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 956
    .line 957
    .line 958
    :cond_35
    :goto_1d
    move-object/from16 v5, v20

    .line 959
    .line 960
    move-object/from16 v7, v21

    .line 961
    .line 962
    move-object/from16 v9, v22

    .line 963
    .line 964
    move-object/from16 v8, v23

    .line 965
    .line 966
    move-object/from16 v10, v24

    .line 967
    .line 968
    move-object/from16 v13, v25

    .line 969
    .line 970
    move-object/from16 v6, v26

    .line 971
    .line 972
    goto/16 :goto_1

    .line 973
    .line 974
    :cond_36
    new-instance v0, LU2/h;

    .line 975
    .line 976
    const-string v1, "A style block was found after the first cue."

    .line 977
    .line 978
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 979
    .line 980
    .line 981
    throw v0

    .line 982
    :cond_37
    move-object/from16 v26, v6

    .line 983
    .line 984
    move-object/from16 v21, v7

    .line 985
    .line 986
    move-object/from16 v23, v8

    .line 987
    .line 988
    move-object/from16 v22, v9

    .line 989
    .line 990
    move-object/from16 v24, v10

    .line 991
    .line 992
    move-object/from16 v25, v13

    .line 993
    .line 994
    const/4 v7, 0x3

    .line 995
    if-ne v3, v7, :cond_35

    .line 996
    .line 997
    invoke-static {v12, v0}, Ld3/h;->d(LS8/y;Ljava/util/ArrayList;)Ld3/c;

    .line 998
    .line 999
    .line 1000
    move-result-object v1

    .line 1001
    if-eqz v1, :cond_35

    .line 1002
    .line 1003
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1004
    .line 1005
    .line 1006
    goto :goto_1d

    .line 1007
    :cond_38
    new-instance v0, LY4/i;

    .line 1008
    .line 1009
    invoke-direct {v0, v2}, LY4/i;-><init>(Ljava/util/ArrayList;)V

    .line 1010
    .line 1011
    .line 1012
    return-object v0

    .line 1013
    :catch_0
    move-exception v0

    .line 1014
    new-instance v1, LU2/h;

    .line 1015
    .line 1016
    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 1017
    .line 1018
    .line 1019
    throw v1

    .line 1020
    :pswitch_3
    move-object/from16 v20, v5

    .line 1021
    .line 1022
    move-object/from16 v26, v6

    .line 1023
    .line 1024
    move-object/from16 v21, v7

    .line 1025
    .line 1026
    move-object/from16 v23, v8

    .line 1027
    .line 1028
    move-object/from16 v22, v9

    .line 1029
    .line 1030
    move-object/from16 v24, v10

    .line 1031
    .line 1032
    move-object/from16 v25, v13

    .line 1033
    .line 1034
    invoke-virtual {v12, v0, v2}, LS8/y;->F(I[B)V

    .line 1035
    .line 1036
    .line 1037
    new-instance v0, Ljava/util/ArrayList;

    .line 1038
    .line 1039
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1040
    .line 1041
    .line 1042
    :try_start_1
    invoke-static {v12}, Ld3/i;->c(LS8/y;)V
    :try_end_1
    .catch Lf2/j0; {:try_start_1 .. :try_end_1} :catch_1

    .line 1043
    .line 1044
    .line 1045
    :goto_1e
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 1046
    .line 1047
    .line 1048
    move-result-object v1

    .line 1049
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1050
    .line 1051
    .line 1052
    move-result v1

    .line 1053
    if-nez v1, :cond_39

    .line 1054
    .line 1055
    goto :goto_1e

    .line 1056
    :cond_39
    new-instance v1, Ljava/util/ArrayList;

    .line 1057
    .line 1058
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 1059
    .line 1060
    .line 1061
    :goto_1f
    const/4 v2, 0x0

    .line 1062
    const/4 v5, -0x1

    .line 1063
    :goto_20
    const/4 v8, -0x1

    .line 1064
    if-ne v5, v8, :cond_3d

    .line 1065
    .line 1066
    iget v2, v12, LS8/y;->a:I

    .line 1067
    .line 1068
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 1069
    .line 1070
    .line 1071
    move-result-object v3

    .line 1072
    if-nez v3, :cond_3a

    .line 1073
    .line 1074
    move-object/from16 v7, v21

    .line 1075
    .line 1076
    move-object/from16 v6, v22

    .line 1077
    .line 1078
    const/4 v5, 0x0

    .line 1079
    goto :goto_21

    .line 1080
    :cond_3a
    move-object/from16 v6, v22

    .line 1081
    .line 1082
    invoke-virtual {v6, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1083
    .line 1084
    .line 1085
    move-result v5

    .line 1086
    if-eqz v5, :cond_3b

    .line 1087
    .line 1088
    move-object/from16 v7, v21

    .line 1089
    .line 1090
    const/4 v5, 0x2

    .line 1091
    goto :goto_21

    .line 1092
    :cond_3b
    move-object/from16 v7, v21

    .line 1093
    .line 1094
    invoke-virtual {v3, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1095
    .line 1096
    .line 1097
    move-result v3

    .line 1098
    if-eqz v3, :cond_3c

    .line 1099
    .line 1100
    const/4 v5, 0x1

    .line 1101
    goto :goto_21

    .line 1102
    :cond_3c
    const/4 v5, 0x3

    .line 1103
    :goto_21
    move-object/from16 v22, v6

    .line 1104
    .line 1105
    move-object/from16 v21, v7

    .line 1106
    .line 1107
    goto :goto_20

    .line 1108
    :cond_3d
    move-object/from16 v7, v21

    .line 1109
    .line 1110
    move-object/from16 v6, v22

    .line 1111
    .line 1112
    invoke-virtual {v12, v2}, LS8/y;->H(I)V

    .line 1113
    .line 1114
    .line 1115
    if-eqz v5, :cond_72

    .line 1116
    .line 1117
    const/4 v13, 0x1

    .line 1118
    if-ne v5, v13, :cond_3f

    .line 1119
    .line 1120
    :goto_22
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 1121
    .line 1122
    .line 1123
    move-result-object v2

    .line 1124
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1125
    .line 1126
    .line 1127
    move-result v2

    .line 1128
    if-nez v2, :cond_3e

    .line 1129
    .line 1130
    goto :goto_22

    .line 1131
    :cond_3e
    move-object/from16 v22, v6

    .line 1132
    .line 1133
    move-object/from16 v21, v7

    .line 1134
    .line 1135
    goto :goto_1f

    .line 1136
    :cond_3f
    const/4 v2, 0x2

    .line 1137
    if-ne v5, v2, :cond_71

    .line 1138
    .line 1139
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1140
    .line 1141
    .line 1142
    move-result v2

    .line 1143
    if-eqz v2, :cond_70

    .line 1144
    .line 1145
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 1146
    .line 1147
    .line 1148
    move-object/from16 v5, v20

    .line 1149
    .line 1150
    check-cast v5, LI6/b;

    .line 1151
    .line 1152
    iget-object v2, v5, LI6/b;->a:LS8/y;

    .line 1153
    .line 1154
    iget-object v3, v5, LI6/b;->b:Ljava/lang/StringBuilder;

    .line 1155
    .line 1156
    const/4 v8, 0x0

    .line 1157
    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->setLength(I)V

    .line 1158
    .line 1159
    .line 1160
    iget v5, v12, LS8/y;->a:I

    .line 1161
    .line 1162
    :goto_23
    invoke-virtual {v12}, LS8/y;->j()Ljava/lang/String;

    .line 1163
    .line 1164
    .line 1165
    move-result-object v8

    .line 1166
    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 1167
    .line 1168
    .line 1169
    move-result v8

    .line 1170
    if-eqz v8, :cond_6f

    .line 1171
    .line 1172
    iget-object v8, v12, LS8/y;->c:Ljava/lang/Object;

    .line 1173
    .line 1174
    check-cast v8, [B

    .line 1175
    .line 1176
    iget v9, v12, LS8/y;->a:I

    .line 1177
    .line 1178
    invoke-virtual {v2, v9, v8}, LS8/y;->F(I[B)V

    .line 1179
    .line 1180
    .line 1181
    invoke-virtual {v2, v5}, LS8/y;->H(I)V

    .line 1182
    .line 1183
    .line 1184
    new-instance v5, Ljava/util/ArrayList;

    .line 1185
    .line 1186
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 1187
    .line 1188
    .line 1189
    :goto_24
    invoke-static {v2}, LI6/b;->c(LS8/y;)V

    .line 1190
    .line 1191
    .line 1192
    invoke-virtual {v2}, LS8/y;->e()I

    .line 1193
    .line 1194
    .line 1195
    move-result v8

    .line 1196
    const/4 v9, 0x5

    .line 1197
    if-ge v8, v9, :cond_40

    .line 1198
    .line 1199
    :goto_25
    move-object/from16 v22, v6

    .line 1200
    .line 1201
    move-object/from16 v10, v23

    .line 1202
    .line 1203
    move-object/from16 v8, v24

    .line 1204
    .line 1205
    move-object/from16 v13, v25

    .line 1206
    .line 1207
    :goto_26
    const/4 v6, 0x0

    .line 1208
    goto/16 :goto_2a

    .line 1209
    .line 1210
    :cond_40
    sget-object v8, LK4/e;->c:Ljava/nio/charset/Charset;

    .line 1211
    .line 1212
    invoke-virtual {v2, v9, v8}, LS8/y;->v(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 1213
    .line 1214
    .line 1215
    move-result-object v8

    .line 1216
    invoke-virtual {v11, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1217
    .line 1218
    .line 1219
    move-result v8

    .line 1220
    if-nez v8, :cond_41

    .line 1221
    .line 1222
    goto :goto_25

    .line 1223
    :cond_41
    iget v8, v2, LS8/y;->a:I

    .line 1224
    .line 1225
    invoke-static {v2, v3}, LI6/b;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1226
    .line 1227
    .line 1228
    move-result-object v10

    .line 1229
    if-nez v10, :cond_42

    .line 1230
    .line 1231
    goto :goto_25

    .line 1232
    :cond_42
    move-object/from16 v13, v25

    .line 1233
    .line 1234
    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1235
    .line 1236
    .line 1237
    move-result v17

    .line 1238
    if-eqz v17, :cond_43

    .line 1239
    .line 1240
    invoke-virtual {v2, v8}, LS8/y;->H(I)V

    .line 1241
    .line 1242
    .line 1243
    move-object/from16 v22, v6

    .line 1244
    .line 1245
    move-object v6, v14

    .line 1246
    move-object/from16 v10, v23

    .line 1247
    .line 1248
    move-object/from16 v8, v24

    .line 1249
    .line 1250
    goto :goto_2a

    .line 1251
    :cond_43
    move-object/from16 v8, v24

    .line 1252
    .line 1253
    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1254
    .line 1255
    .line 1256
    move-result v10

    .line 1257
    if-eqz v10, :cond_46

    .line 1258
    .line 1259
    iget v10, v2, LS8/y;->a:I

    .line 1260
    .line 1261
    iget v9, v2, LS8/y;->b:I

    .line 1262
    .line 1263
    move-object/from16 v22, v6

    .line 1264
    .line 1265
    move v6, v10

    .line 1266
    const/4 v10, 0x0

    .line 1267
    :goto_27
    if-ge v6, v9, :cond_45

    .line 1268
    .line 1269
    if-nez v10, :cond_45

    .line 1270
    .line 1271
    iget-object v10, v2, LS8/y;->c:Ljava/lang/Object;

    .line 1272
    .line 1273
    check-cast v10, [B

    .line 1274
    .line 1275
    add-int/lit8 v21, v6, 0x1

    .line 1276
    .line 1277
    aget-byte v6, v10, v6

    .line 1278
    .line 1279
    int-to-char v6, v6

    .line 1280
    const/16 v10, 0x29

    .line 1281
    .line 1282
    if-ne v6, v10, :cond_44

    .line 1283
    .line 1284
    const/4 v6, 0x1

    .line 1285
    goto :goto_28

    .line 1286
    :cond_44
    const/4 v6, 0x0

    .line 1287
    :goto_28
    move v10, v6

    .line 1288
    move/from16 v6, v21

    .line 1289
    .line 1290
    goto :goto_27

    .line 1291
    :cond_45
    const/16 v10, 0x29

    .line 1292
    .line 1293
    add-int/lit8 v6, v6, -0x1

    .line 1294
    .line 1295
    iget v9, v2, LS8/y;->a:I

    .line 1296
    .line 1297
    sub-int/2addr v6, v9

    .line 1298
    sget-object v9, LK4/e;->c:Ljava/nio/charset/Charset;

    .line 1299
    .line 1300
    invoke-virtual {v2, v6, v9}, LS8/y;->v(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 1301
    .line 1302
    .line 1303
    move-result-object v6

    .line 1304
    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 1305
    .line 1306
    .line 1307
    move-result-object v6

    .line 1308
    goto :goto_29

    .line 1309
    :cond_46
    move-object/from16 v22, v6

    .line 1310
    .line 1311
    const/16 v10, 0x29

    .line 1312
    .line 1313
    const/4 v6, 0x0

    .line 1314
    :goto_29
    invoke-static {v2, v3}, LI6/b;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1315
    .line 1316
    .line 1317
    move-result-object v9

    .line 1318
    move-object/from16 v10, v23

    .line 1319
    .line 1320
    invoke-virtual {v10, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1321
    .line 1322
    .line 1323
    move-result v9

    .line 1324
    if-nez v9, :cond_47

    .line 1325
    .line 1326
    goto :goto_26

    .line 1327
    :cond_47
    :goto_2a
    if-eqz v6, :cond_48

    .line 1328
    .line 1329
    invoke-static {v2, v3}, LI6/b;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1330
    .line 1331
    .line 1332
    move-result-object v9

    .line 1333
    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1334
    .line 1335
    .line 1336
    move-result v9

    .line 1337
    if-nez v9, :cond_49

    .line 1338
    .line 1339
    :cond_48
    move-object/from16 v21, v7

    .line 1340
    .line 1341
    move-object/from16 v24, v8

    .line 1342
    .line 1343
    move-object/from16 v23, v10

    .line 1344
    .line 1345
    move-object/from16 v16, v11

    .line 1346
    .line 1347
    const/4 v8, 0x2

    .line 1348
    const/4 v10, 0x1

    .line 1349
    goto/16 :goto_40

    .line 1350
    .line 1351
    :cond_49
    new-instance v9, Ld3/b;

    .line 1352
    .line 1353
    invoke-direct {v9}, Ld3/b;-><init>()V

    .line 1354
    .line 1355
    .line 1356
    invoke-virtual {v14, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1357
    .line 1358
    .line 1359
    move-result v21

    .line 1360
    if-eqz v21, :cond_4a

    .line 1361
    .line 1362
    move-object/from16 v21, v7

    .line 1363
    .line 1364
    move-object/from16 v24, v8

    .line 1365
    .line 1366
    move-object/from16 v23, v10

    .line 1367
    .line 1368
    move-object/from16 v16, v11

    .line 1369
    .line 1370
    const/4 v8, 0x0

    .line 1371
    goto/16 :goto_2e

    .line 1372
    .line 1373
    :cond_4a
    move-object/from16 v21, v7

    .line 1374
    .line 1375
    move-object/from16 v24, v8

    .line 1376
    .line 1377
    const/16 v7, 0x5b

    .line 1378
    .line 1379
    invoke-virtual {v6, v7}, Ljava/lang/String;->indexOf(I)I

    .line 1380
    .line 1381
    .line 1382
    move-result v8

    .line 1383
    const/4 v7, -0x1

    .line 1384
    if-eq v8, v7, :cond_4c

    .line 1385
    .line 1386
    sget-object v7, LI6/b;->c:Ljava/util/regex/Pattern;

    .line 1387
    .line 1388
    move-object/from16 v23, v10

    .line 1389
    .line 1390
    invoke-virtual {v6, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1391
    .line 1392
    .line 1393
    move-result-object v10

    .line 1394
    invoke-virtual {v7, v10}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1395
    .line 1396
    .line 1397
    move-result-object v7

    .line 1398
    invoke-virtual {v7}, Ljava/util/regex/Matcher;->matches()Z

    .line 1399
    .line 1400
    .line 1401
    move-result v10

    .line 1402
    if-eqz v10, :cond_4b

    .line 1403
    .line 1404
    const/4 v10, 0x1

    .line 1405
    invoke-virtual {v7, v10}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 1406
    .line 1407
    .line 1408
    move-result-object v7

    .line 1409
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1410
    .line 1411
    .line 1412
    iput-object v7, v9, Ld3/b;->d:Ljava/lang/String;

    .line 1413
    .line 1414
    :cond_4b
    const/4 v7, 0x0

    .line 1415
    invoke-virtual {v6, v7, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1416
    .line 1417
    .line 1418
    move-result-object v6

    .line 1419
    goto :goto_2b

    .line 1420
    :cond_4c
    move-object/from16 v23, v10

    .line 1421
    .line 1422
    const/4 v7, 0x0

    .line 1423
    :goto_2b
    sget v8, Lh3/y;->a:I

    .line 1424
    .line 1425
    move-object/from16 v10, v26

    .line 1426
    .line 1427
    const/4 v8, -0x1

    .line 1428
    invoke-virtual {v6, v10, v8}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 1429
    .line 1430
    .line 1431
    move-result-object v6

    .line 1432
    move/from16 v19, v7

    .line 1433
    .line 1434
    aget-object v7, v6, v19

    .line 1435
    .line 1436
    move-object/from16 v16, v11

    .line 1437
    .line 1438
    const/16 v10, 0x23

    .line 1439
    .line 1440
    invoke-virtual {v7, v10}, Ljava/lang/String;->indexOf(I)I

    .line 1441
    .line 1442
    .line 1443
    move-result v11

    .line 1444
    if-eq v11, v8, :cond_4d

    .line 1445
    .line 1446
    move/from16 v8, v19

    .line 1447
    .line 1448
    invoke-virtual {v7, v8, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1449
    .line 1450
    .line 1451
    move-result-object v10

    .line 1452
    iput-object v10, v9, Ld3/b;->b:Ljava/lang/String;

    .line 1453
    .line 1454
    add-int/lit8 v11, v11, 0x1

    .line 1455
    .line 1456
    invoke-virtual {v7, v11}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1457
    .line 1458
    .line 1459
    move-result-object v7

    .line 1460
    iput-object v7, v9, Ld3/b;->a:Ljava/lang/String;

    .line 1461
    .line 1462
    goto :goto_2c

    .line 1463
    :cond_4d
    move/from16 v8, v19

    .line 1464
    .line 1465
    iput-object v7, v9, Ld3/b;->b:Ljava/lang/String;

    .line 1466
    .line 1467
    :goto_2c
    array-length v7, v6

    .line 1468
    const/4 v10, 0x1

    .line 1469
    if-le v7, v10, :cond_4f

    .line 1470
    .line 1471
    array-length v7, v6

    .line 1472
    array-length v11, v6

    .line 1473
    if-gt v7, v11, :cond_4e

    .line 1474
    .line 1475
    move/from16 v18, v10

    .line 1476
    .line 1477
    goto :goto_2d

    .line 1478
    :cond_4e
    move/from16 v18, v8

    .line 1479
    .line 1480
    :goto_2d
    invoke-static/range {v18 .. v18}, Lh3/a;->h(Z)V

    .line 1481
    .line 1482
    .line 1483
    invoke-static {v6, v10, v7}, Ljava/util/Arrays;->copyOfRange([Ljava/lang/Object;II)[Ljava/lang/Object;

    .line 1484
    .line 1485
    .line 1486
    move-result-object v6

    .line 1487
    check-cast v6, [Ljava/lang/String;

    .line 1488
    .line 1489
    new-instance v7, Ljava/util/HashSet;

    .line 1490
    .line 1491
    invoke-static {v6}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1492
    .line 1493
    .line 1494
    move-result-object v6

    .line 1495
    invoke-direct {v7, v6}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 1496
    .line 1497
    .line 1498
    iput-object v7, v9, Ld3/b;->c:Ljava/util/Set;

    .line 1499
    .line 1500
    :cond_4f
    :goto_2e
    move v6, v8

    .line 1501
    const/4 v7, 0x0

    .line 1502
    :goto_2f
    if-nez v6, :cond_6c

    .line 1503
    .line 1504
    iget v6, v2, LS8/y;->a:I

    .line 1505
    .line 1506
    invoke-static {v2, v3}, LI6/b;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1507
    .line 1508
    .line 1509
    move-result-object v7

    .line 1510
    if-eqz v7, :cond_51

    .line 1511
    .line 1512
    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1513
    .line 1514
    .line 1515
    move-result v10

    .line 1516
    if-eqz v10, :cond_50

    .line 1517
    .line 1518
    goto :goto_30

    .line 1519
    :cond_50
    move v10, v8

    .line 1520
    goto :goto_31

    .line 1521
    :cond_51
    :goto_30
    const/4 v10, 0x1

    .line 1522
    :goto_31
    if-nez v10, :cond_6a

    .line 1523
    .line 1524
    invoke-virtual {v2, v6}, LS8/y;->H(I)V

    .line 1525
    .line 1526
    .line 1527
    invoke-static {v2}, LI6/b;->c(LS8/y;)V

    .line 1528
    .line 1529
    .line 1530
    invoke-static {v2, v3}, LI6/b;->a(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1531
    .line 1532
    .line 1533
    move-result-object v6

    .line 1534
    invoke-virtual {v14, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1535
    .line 1536
    .line 1537
    move-result v11

    .line 1538
    if-eqz v11, :cond_52

    .line 1539
    .line 1540
    goto/16 :goto_3c

    .line 1541
    .line 1542
    :cond_52
    const-string v11, ":"

    .line 1543
    .line 1544
    invoke-static {v2, v3}, LI6/b;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1545
    .line 1546
    .line 1547
    move-result-object v8

    .line 1548
    invoke-virtual {v11, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1549
    .line 1550
    .line 1551
    move-result v8

    .line 1552
    if-nez v8, :cond_53

    .line 1553
    .line 1554
    goto/16 :goto_3c

    .line 1555
    .line 1556
    :cond_53
    invoke-static {v2}, LI6/b;->c(LS8/y;)V

    .line 1557
    .line 1558
    .line 1559
    new-instance v8, Ljava/lang/StringBuilder;

    .line 1560
    .line 1561
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 1562
    .line 1563
    .line 1564
    const/4 v11, 0x0

    .line 1565
    :goto_32
    if-nez v11, :cond_57

    .line 1566
    .line 1567
    move-object/from16 p1, v7

    .line 1568
    .line 1569
    iget v7, v2, LS8/y;->a:I

    .line 1570
    .line 1571
    move/from16 p3, v10

    .line 1572
    .line 1573
    invoke-static {v2, v3}, LI6/b;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1574
    .line 1575
    .line 1576
    move-result-object v10

    .line 1577
    if-nez v10, :cond_54

    .line 1578
    .line 1579
    const/4 v7, 0x0

    .line 1580
    goto :goto_34

    .line 1581
    :cond_54
    invoke-virtual {v15, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1582
    .line 1583
    .line 1584
    move-result v27

    .line 1585
    if-nez v27, :cond_56

    .line 1586
    .line 1587
    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1588
    .line 1589
    .line 1590
    move-result v27

    .line 1591
    if-eqz v27, :cond_55

    .line 1592
    .line 1593
    goto :goto_33

    .line 1594
    :cond_55
    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1595
    .line 1596
    .line 1597
    move-object/from16 v7, p1

    .line 1598
    .line 1599
    move/from16 v10, p3

    .line 1600
    .line 1601
    goto :goto_32

    .line 1602
    :cond_56
    :goto_33
    invoke-virtual {v2, v7}, LS8/y;->H(I)V

    .line 1603
    .line 1604
    .line 1605
    move-object/from16 v7, p1

    .line 1606
    .line 1607
    move/from16 v10, p3

    .line 1608
    .line 1609
    const/4 v11, 0x1

    .line 1610
    goto :goto_32

    .line 1611
    :cond_57
    move-object/from16 p1, v7

    .line 1612
    .line 1613
    move/from16 p3, v10

    .line 1614
    .line 1615
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1616
    .line 1617
    .line 1618
    move-result-object v7

    .line 1619
    :goto_34
    if-eqz v7, :cond_6b

    .line 1620
    .line 1621
    invoke-virtual {v14, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1622
    .line 1623
    .line 1624
    move-result v8

    .line 1625
    if-eqz v8, :cond_58

    .line 1626
    .line 1627
    goto/16 :goto_3d

    .line 1628
    .line 1629
    :cond_58
    iget v8, v2, LS8/y;->a:I

    .line 1630
    .line 1631
    invoke-static {v2, v3}, LI6/b;->b(LS8/y;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1632
    .line 1633
    .line 1634
    move-result-object v10

    .line 1635
    invoke-virtual {v4, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1636
    .line 1637
    .line 1638
    move-result v11

    .line 1639
    if-eqz v11, :cond_59

    .line 1640
    .line 1641
    goto :goto_35

    .line 1642
    :cond_59
    invoke-virtual {v15, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1643
    .line 1644
    .line 1645
    move-result v10

    .line 1646
    if-eqz v10, :cond_6b

    .line 1647
    .line 1648
    invoke-virtual {v2, v8}, LS8/y;->H(I)V

    .line 1649
    .line 1650
    .line 1651
    :goto_35
    const-string v8, "color"

    .line 1652
    .line 1653
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1654
    .line 1655
    .line 1656
    move-result v8

    .line 1657
    if-eqz v8, :cond_5a

    .line 1658
    .line 1659
    const/4 v10, 0x1

    .line 1660
    invoke-static {v7, v10}, Lh3/b;->a(Ljava/lang/String;Z)I

    .line 1661
    .line 1662
    .line 1663
    move-result v6

    .line 1664
    iput v6, v9, Ld3/b;->f:I

    .line 1665
    .line 1666
    iput-boolean v10, v9, Ld3/b;->g:Z

    .line 1667
    .line 1668
    goto/16 :goto_38

    .line 1669
    .line 1670
    :cond_5a
    const/4 v10, 0x1

    .line 1671
    const-string v8, "background-color"

    .line 1672
    .line 1673
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1674
    .line 1675
    .line 1676
    move-result v8

    .line 1677
    if-eqz v8, :cond_5b

    .line 1678
    .line 1679
    invoke-static {v7, v10}, Lh3/b;->a(Ljava/lang/String;Z)I

    .line 1680
    .line 1681
    .line 1682
    move-result v6

    .line 1683
    iput v6, v9, Ld3/b;->h:I

    .line 1684
    .line 1685
    iput-boolean v10, v9, Ld3/b;->i:Z

    .line 1686
    .line 1687
    goto/16 :goto_38

    .line 1688
    .line 1689
    :cond_5b
    const-string v8, "ruby-position"

    .line 1690
    .line 1691
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1692
    .line 1693
    .line 1694
    move-result v8

    .line 1695
    if-eqz v8, :cond_5d

    .line 1696
    .line 1697
    const-string v6, "over"

    .line 1698
    .line 1699
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1700
    .line 1701
    .line 1702
    move-result v6

    .line 1703
    if-eqz v6, :cond_5c

    .line 1704
    .line 1705
    iput v10, v9, Ld3/b;->p:I

    .line 1706
    .line 1707
    goto/16 :goto_38

    .line 1708
    .line 1709
    :cond_5c
    const-string v6, "under"

    .line 1710
    .line 1711
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1712
    .line 1713
    .line 1714
    move-result v6

    .line 1715
    if-eqz v6, :cond_6b

    .line 1716
    .line 1717
    const/4 v7, 0x2

    .line 1718
    iput v7, v9, Ld3/b;->p:I

    .line 1719
    .line 1720
    move v8, v7

    .line 1721
    goto/16 :goto_3e

    .line 1722
    .line 1723
    :cond_5d
    const-string v8, "text-combine-upright"

    .line 1724
    .line 1725
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1726
    .line 1727
    .line 1728
    move-result v8

    .line 1729
    if-eqz v8, :cond_60

    .line 1730
    .line 1731
    const-string v6, "all"

    .line 1732
    .line 1733
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1734
    .line 1735
    .line 1736
    move-result v6

    .line 1737
    if-nez v6, :cond_5f

    .line 1738
    .line 1739
    const-string v6, "digits"

    .line 1740
    .line 1741
    invoke-virtual {v7, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 1742
    .line 1743
    .line 1744
    move-result v6

    .line 1745
    if-eqz v6, :cond_5e

    .line 1746
    .line 1747
    goto :goto_36

    .line 1748
    :cond_5e
    const/4 v6, 0x0

    .line 1749
    goto :goto_37

    .line 1750
    :cond_5f
    :goto_36
    const/4 v6, 0x1

    .line 1751
    :goto_37
    iput-boolean v6, v9, Ld3/b;->q:Z

    .line 1752
    .line 1753
    goto/16 :goto_3d

    .line 1754
    .line 1755
    :cond_60
    const-string v8, "text-decoration"

    .line 1756
    .line 1757
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1758
    .line 1759
    .line 1760
    move-result v8

    .line 1761
    if-eqz v8, :cond_61

    .line 1762
    .line 1763
    const-string v6, "underline"

    .line 1764
    .line 1765
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1766
    .line 1767
    .line 1768
    move-result v6

    .line 1769
    if-eqz v6, :cond_6b

    .line 1770
    .line 1771
    const/4 v10, 0x1

    .line 1772
    iput v10, v9, Ld3/b;->k:I

    .line 1773
    .line 1774
    goto :goto_38

    .line 1775
    :cond_61
    const-string v8, "font-family"

    .line 1776
    .line 1777
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1778
    .line 1779
    .line 1780
    move-result v8

    .line 1781
    if-eqz v8, :cond_62

    .line 1782
    .line 1783
    invoke-static {v7}, LK3/h;->v(Ljava/lang/String;)Ljava/lang/String;

    .line 1784
    .line 1785
    .line 1786
    move-result-object v6

    .line 1787
    iput-object v6, v9, Ld3/b;->e:Ljava/lang/String;

    .line 1788
    .line 1789
    goto/16 :goto_3d

    .line 1790
    .line 1791
    :cond_62
    const-string v8, "font-weight"

    .line 1792
    .line 1793
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1794
    .line 1795
    .line 1796
    move-result v8

    .line 1797
    if-eqz v8, :cond_63

    .line 1798
    .line 1799
    const-string v6, "bold"

    .line 1800
    .line 1801
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1802
    .line 1803
    .line 1804
    move-result v6

    .line 1805
    if-eqz v6, :cond_6b

    .line 1806
    .line 1807
    const/4 v10, 0x1

    .line 1808
    iput v10, v9, Ld3/b;->l:I

    .line 1809
    .line 1810
    goto :goto_38

    .line 1811
    :cond_63
    const/4 v10, 0x1

    .line 1812
    const-string v8, "font-style"

    .line 1813
    .line 1814
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1815
    .line 1816
    .line 1817
    move-result v8

    .line 1818
    if-eqz v8, :cond_65

    .line 1819
    .line 1820
    const-string v6, "italic"

    .line 1821
    .line 1822
    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1823
    .line 1824
    .line 1825
    move-result v6

    .line 1826
    if-eqz v6, :cond_64

    .line 1827
    .line 1828
    iput v10, v9, Ld3/b;->m:I

    .line 1829
    .line 1830
    :cond_64
    :goto_38
    const/4 v8, 0x2

    .line 1831
    goto/16 :goto_3f

    .line 1832
    .line 1833
    :cond_65
    const-string v8, "font-size"

    .line 1834
    .line 1835
    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1836
    .line 1837
    .line 1838
    move-result v6

    .line 1839
    if-eqz v6, :cond_6b

    .line 1840
    .line 1841
    sget-object v6, LI6/b;->d:Ljava/util/regex/Pattern;

    .line 1842
    .line 1843
    invoke-static {v7}, LK3/h;->v(Ljava/lang/String;)Ljava/lang/String;

    .line 1844
    .line 1845
    .line 1846
    move-result-object v8

    .line 1847
    invoke-virtual {v6, v8}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1848
    .line 1849
    .line 1850
    move-result-object v6

    .line 1851
    invoke-virtual {v6}, Ljava/util/regex/Matcher;->matches()Z

    .line 1852
    .line 1853
    .line 1854
    move-result v8

    .line 1855
    if-nez v8, :cond_66

    .line 1856
    .line 1857
    new-instance v6, Ljava/lang/StringBuilder;

    .line 1858
    .line 1859
    const-string v8, "Invalid font-size: \'"

    .line 1860
    .line 1861
    invoke-direct {v6, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1862
    .line 1863
    .line 1864
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1865
    .line 1866
    .line 1867
    const-string v7, "\'."

    .line 1868
    .line 1869
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1870
    .line 1871
    .line 1872
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1873
    .line 1874
    .line 1875
    move-result-object v6

    .line 1876
    const-string v7, "WebvttCssParser"

    .line 1877
    .line 1878
    invoke-static {v7, v6}, Lh3/a;->P(Ljava/lang/String;Ljava/lang/String;)V

    .line 1879
    .line 1880
    .line 1881
    goto :goto_3d

    .line 1882
    :cond_66
    const/4 v7, 0x2

    .line 1883
    invoke-virtual {v6, v7}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 1884
    .line 1885
    .line 1886
    move-result-object v8

    .line 1887
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1888
    .line 1889
    .line 1890
    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    .line 1891
    .line 1892
    .line 1893
    move-result v7

    .line 1894
    sparse-switch v7, :sswitch_data_1

    .line 1895
    .line 1896
    .line 1897
    :goto_39
    const/4 v7, -0x1

    .line 1898
    goto :goto_3a

    .line 1899
    :sswitch_3
    const-string v7, "px"

    .line 1900
    .line 1901
    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1902
    .line 1903
    .line 1904
    move-result v7

    .line 1905
    if-nez v7, :cond_67

    .line 1906
    .line 1907
    goto :goto_39

    .line 1908
    :cond_67
    const/4 v7, 0x2

    .line 1909
    goto :goto_3a

    .line 1910
    :sswitch_4
    const-string v7, "em"

    .line 1911
    .line 1912
    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1913
    .line 1914
    .line 1915
    move-result v7

    .line 1916
    if-nez v7, :cond_68

    .line 1917
    .line 1918
    goto :goto_39

    .line 1919
    :cond_68
    const/4 v7, 0x1

    .line 1920
    goto :goto_3a

    .line 1921
    :sswitch_5
    const-string v7, "%"

    .line 1922
    .line 1923
    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1924
    .line 1925
    .line 1926
    move-result v7

    .line 1927
    if-nez v7, :cond_69

    .line 1928
    .line 1929
    goto :goto_39

    .line 1930
    :cond_69
    const/4 v7, 0x0

    .line 1931
    :goto_3a
    packed-switch v7, :pswitch_data_2

    .line 1932
    .line 1933
    .line 1934
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1935
    .line 1936
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 1937
    .line 1938
    .line 1939
    throw v0

    .line 1940
    :pswitch_4
    const/4 v10, 0x1

    .line 1941
    iput v10, v9, Ld3/b;->n:I

    .line 1942
    .line 1943
    const/4 v8, 0x2

    .line 1944
    goto :goto_3b

    .line 1945
    :pswitch_5
    const/4 v8, 0x2

    .line 1946
    const/4 v10, 0x1

    .line 1947
    iput v8, v9, Ld3/b;->n:I

    .line 1948
    .line 1949
    goto :goto_3b

    .line 1950
    :pswitch_6
    const/4 v7, 0x3

    .line 1951
    const/4 v8, 0x2

    .line 1952
    const/4 v10, 0x1

    .line 1953
    iput v7, v9, Ld3/b;->n:I

    .line 1954
    .line 1955
    :goto_3b
    invoke-virtual {v6, v10}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 1956
    .line 1957
    .line 1958
    move-result-object v6

    .line 1959
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1960
    .line 1961
    .line 1962
    invoke-static {v6}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 1963
    .line 1964
    .line 1965
    move-result v6

    .line 1966
    iput v6, v9, Ld3/b;->o:F

    .line 1967
    .line 1968
    goto :goto_3f

    .line 1969
    :cond_6a
    :goto_3c
    move-object/from16 p1, v7

    .line 1970
    .line 1971
    move/from16 p3, v10

    .line 1972
    .line 1973
    :cond_6b
    :goto_3d
    const/4 v8, 0x2

    .line 1974
    :goto_3e
    const/4 v10, 0x1

    .line 1975
    :goto_3f
    move-object/from16 v7, p1

    .line 1976
    .line 1977
    move/from16 v6, p3

    .line 1978
    .line 1979
    const/4 v8, 0x0

    .line 1980
    goto/16 :goto_2f

    .line 1981
    .line 1982
    :cond_6c
    const/4 v8, 0x2

    .line 1983
    const/4 v10, 0x1

    .line 1984
    invoke-virtual {v15, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1985
    .line 1986
    .line 1987
    move-result v6

    .line 1988
    if-eqz v6, :cond_6d

    .line 1989
    .line 1990
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1991
    .line 1992
    .line 1993
    :cond_6d
    move-object/from16 v25, v13

    .line 1994
    .line 1995
    move-object/from16 v11, v16

    .line 1996
    .line 1997
    move-object/from16 v7, v21

    .line 1998
    .line 1999
    move-object/from16 v6, v22

    .line 2000
    .line 2001
    goto/16 :goto_24

    .line 2002
    .line 2003
    :goto_40
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 2004
    .line 2005
    .line 2006
    :cond_6e
    :goto_41
    move-object/from16 v25, v13

    .line 2007
    .line 2008
    move-object/from16 v11, v16

    .line 2009
    .line 2010
    goto/16 :goto_1f

    .line 2011
    .line 2012
    :cond_6f
    move-object/from16 v13, v25

    .line 2013
    .line 2014
    goto/16 :goto_23

    .line 2015
    .line 2016
    :cond_70
    new-instance v0, LU2/h;

    .line 2017
    .line 2018
    const-string v1, "A style block was found after the first cue."

    .line 2019
    .line 2020
    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 2021
    .line 2022
    .line 2023
    throw v0

    .line 2024
    :cond_71
    move v8, v2

    .line 2025
    move-object/from16 v22, v6

    .line 2026
    .line 2027
    move-object/from16 v21, v7

    .line 2028
    .line 2029
    move-object/from16 v16, v11

    .line 2030
    .line 2031
    move-object/from16 v13, v25

    .line 2032
    .line 2033
    const/4 v7, 0x3

    .line 2034
    const/4 v10, 0x1

    .line 2035
    if-ne v5, v7, :cond_6e

    .line 2036
    .line 2037
    invoke-static {v12, v0}, Ld3/h;->d(LS8/y;Ljava/util/ArrayList;)Ld3/c;

    .line 2038
    .line 2039
    .line 2040
    move-result-object v2

    .line 2041
    if-eqz v2, :cond_6e

    .line 2042
    .line 2043
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2044
    .line 2045
    .line 2046
    goto :goto_41

    .line 2047
    :cond_72
    new-instance v0, Landroid/support/v4/media/session/z;

    .line 2048
    .line 2049
    invoke-direct {v0, v1}, Landroid/support/v4/media/session/z;-><init>(Ljava/util/ArrayList;)V

    .line 2050
    .line 2051
    .line 2052
    return-object v0

    .line 2053
    :catch_1
    move-exception v0

    .line 2054
    new-instance v1, LU2/h;

    .line 2055
    .line 2056
    invoke-direct {v1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 2057
    .line 2058
    .line 2059
    throw v1

    .line 2060
    nop

    .line 2061
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
    .end packed-switch

    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    :sswitch_data_0
    .sparse-switch
        0x25 -> :sswitch_2
        0xca8 -> :sswitch_1
        0xe08 -> :sswitch_0
    .end sparse-switch

    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    :sswitch_data_1
    .sparse-switch
        0x25 -> :sswitch_5
        0xca8 -> :sswitch_4
        0xe08 -> :sswitch_3
    .end sparse-switch

    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
    .end packed-switch
.end method
