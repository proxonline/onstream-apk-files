.class public final synthetic Lf5/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lf5/f;


# direct methods
.method public synthetic constructor <init>(Lf5/f;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lf5/c;->a:Lf5/f;

    return-void
.end method
