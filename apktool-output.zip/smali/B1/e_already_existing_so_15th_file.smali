.class public abstract LB1/e;
.super Lo/B;
.source "SourceFile"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# instance fields
.field public final b:Lz1/d;

.field public c:Z

.field public d:Z

.field public e:Z

.field public final f:Ljava/util/HashSet;

.field public final g:Landroid/graphics/drawable/GradientDrawable;

.field public final h:Landroid/animation/ObjectAnimator;

.field public final i:Ljava/util/HashSet;

.field public final j:Ld8/j;

.field public final k:LC4/e;


# direct methods
.method public constructor <init>(LC4/e;Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 9

    .line 1
    invoke-direct {p0, p2, p3}, Lo/B;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LB1/e;->k:LC4/e;

    .line 5
    .line 6
    new-instance p1, Lz1/d;

    .line 7
    .line 8
    invoke-direct {p1}, Lz1/d;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, LB1/e;->b:Lz1/d;

    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    iput-boolean p1, p0, LB1/e;->c:Z

    .line 15
    .line 16
    new-instance p2, Ljava/util/HashSet;

    .line 17
    .line 18
    invoke-direct {p2}, Ljava/util/HashSet;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object p2, p0, LB1/e;->f:Ljava/util/HashSet;

    .line 22
    .line 23
    new-instance p2, Ljava/util/HashSet;

    .line 24
    .line 25
    invoke-direct {p2}, Ljava/util/HashSet;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object p2, p0, LB1/e;->i:Ljava/util/HashSet;

    .line 29
    .line 30
    new-instance p2, LB1/d;

    .line 31
    .line 32
    const/4 p3, 0x0

    .line 33
    invoke-direct {p2, p3, p0}, LB1/d;-><init>(ILjava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    invoke-static {p2}, Lr3/e;->x(Lr8/a;)Ld8/j;

    .line 37
    .line 38
    .line 39
    move-result-object p2

    .line 40
    iput-object p2, p0, LB1/e;->j:Ld8/j;

    .line 41
    .line 42
    const/4 p2, 0x0

    .line 43
    invoke-virtual {p0, p2}, Landroid/widget/AbsSeekBar;->setSplitTrack(Z)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0, p0}, LB1/e;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 50
    .line 51
    .line 52
    move-result-object p3

    .line 53
    if-eqz p3, :cond_1

    .line 54
    .line 55
    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    .line 56
    .line 57
    .line 58
    move-result-object p3

    .line 59
    instance-of v0, p3, Landroid/graphics/drawable/RippleDrawable;

    .line 60
    .line 61
    if-eqz v0, :cond_0

    .line 62
    .line 63
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    const v1, 0x7f070054

    .line 68
    .line 69
    .line 70
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    move-object v1, p3

    .line 75
    check-cast v1, Landroid/graphics/drawable/RippleDrawable;

    .line 76
    .line 77
    invoke-virtual {v1, v0}, Landroid/graphics/drawable/RippleDrawable;->setRadius(I)V

    .line 78
    .line 79
    .line 80
    :cond_0
    invoke-virtual {p0, p3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 81
    .line 82
    .line 83
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 84
    .line 85
    .line 86
    move-result-object p3

    .line 87
    const v0, 0x7f070053

    .line 88
    .line 89
    .line 90
    invoke-virtual {p3, v0}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 95
    .line 96
    .line 97
    move-result-object p3

    .line 98
    const v1, 0x7f070052

    .line 99
    .line 100
    .line 101
    invoke-virtual {p3, v1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 102
    .line 103
    .line 104
    new-array p3, p2, [Landroid/graphics/drawable/Drawable;

    .line 105
    .line 106
    invoke-virtual {p0, p3}, LB1/e;->j([Landroid/graphics/drawable/Drawable;)[Landroid/graphics/drawable/Drawable;

    .line 107
    .line 108
    .line 109
    move-result-object p3

    .line 110
    new-instance v1, Landroid/graphics/drawable/LayerDrawable;

    .line 111
    .line 112
    invoke-direct {v1, p3}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 113
    .line 114
    .line 115
    array-length v7, p3

    .line 116
    move v2, p2

    .line 117
    :goto_0
    if-ge p2, v7, :cond_2

    .line 118
    .line 119
    aget-object v4, p3, p2

    .line 120
    .line 121
    add-int/lit8 v8, v2, 0x1

    .line 122
    .line 123
    move v4, v3

    .line 124
    move v5, v3

    .line 125
    move v6, v3

    .line 126
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/drawable/LayerDrawable;->setLayerInset(IIIII)V

    .line 127
    .line 128
    .line 129
    add-int/lit8 p2, p2, 0x1

    .line 130
    .line 131
    move v2, v8

    .line 132
    goto :goto_0

    .line 133
    :cond_2
    invoke-virtual {p0, v1}, Landroid/widget/ProgressBar;->setProgressDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 134
    .line 135
    .line 136
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 137
    .line 138
    .line 139
    move-result-object p2

    .line 140
    invoke-virtual {p2, v0}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 141
    .line 142
    .line 143
    move-result p2

    .line 144
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 145
    .line 146
    .line 147
    move-result-object p3

    .line 148
    const v0, 0x7f070056

    .line 149
    .line 150
    .line 151
    invoke-virtual {p3, v0}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 152
    .line 153
    .line 154
    move-result p3

    .line 155
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    .line 156
    .line 157
    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 158
    .line 159
    .line 160
    const/4 v1, -0x1

    .line 161
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v0, p3, p3}, Landroid/graphics/drawable/GradientDrawable;->setSize(II)V

    .line 168
    .line 169
    .line 170
    iput-object v0, p0, LB1/e;->g:Landroid/graphics/drawable/GradientDrawable;

    .line 171
    .line 172
    iget-object p1, p0, LB1/e;->i:Ljava/util/HashSet;

    .line 173
    .line 174
    invoke-virtual {p1, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 175
    .line 176
    .line 177
    new-instance p1, Landroid/graphics/drawable/StateListDrawable;

    .line 178
    .line 179
    invoke-direct {p1}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    .line 180
    .line 181
    .line 182
    sget-object p3, Landroid/util/StateSet;->WILD_CARD:[I

    .line 183
    .line 184
    iget-object v0, p0, LB1/e;->g:Landroid/graphics/drawable/GradientDrawable;

    .line 185
    .line 186
    if-eqz v0, :cond_4

    .line 187
    .line 188
    invoke-virtual {p1, p3, v0}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 189
    .line 190
    .line 191
    new-instance p3, Landroid/graphics/drawable/ScaleDrawable;

    .line 192
    .line 193
    const/16 v0, 0x11

    .line 194
    .line 195
    const/high16 v1, 0x3f800000    # 1.0f

    .line 196
    .line 197
    invoke-direct {p3, p1, v0, v1, v1}, Landroid/graphics/drawable/ScaleDrawable;-><init>(Landroid/graphics/drawable/Drawable;IFF)V

    .line 198
    .line 199
    .line 200
    const/16 p1, 0x1f40

    .line 201
    .line 202
    invoke-virtual {p3, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 203
    .line 204
    .line 205
    invoke-virtual {p0, p3}, Landroid/widget/AbsSeekBar;->setThumb(Landroid/graphics/drawable/Drawable;)V

    .line 206
    .line 207
    .line 208
    invoke-virtual {p0}, Landroid/widget/AbsSeekBar;->getThumb()Landroid/graphics/drawable/Drawable;

    .line 209
    .line 210
    .line 211
    move-result-object p3

    .line 212
    const/16 v0, 0x2710

    .line 213
    .line 214
    filled-new-array {p1, v0}, [I

    .line 215
    .line 216
    .line 217
    move-result-object p1

    .line 218
    const-string v0, "level"

    .line 219
    .line 220
    invoke-static {p3, v0, p1}, Landroid/animation/ObjectAnimator;->ofInt(Ljava/lang/Object;Ljava/lang/String;[I)Landroid/animation/ObjectAnimator;

    .line 221
    .line 222
    .line 223
    move-result-object p1

    .line 224
    const-string p3, "it"

    .line 225
    .line 226
    invoke-static {p1, p3}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    const-wide/16 v0, 0x96

    .line 230
    .line 231
    invoke-virtual {p1, v0, v1}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    .line 232
    .line 233
    .line 234
    iput-object p1, p0, LB1/e;->h:Landroid/animation/ObjectAnimator;

    .line 235
    .line 236
    invoke-virtual {p0}, Landroid/widget/AbsSeekBar;->getThumbOffset()I

    .line 237
    .line 238
    .line 239
    move-result p1

    .line 240
    div-int/lit8 p2, p2, 0x2

    .line 241
    .line 242
    sub-int/2addr p1, p2

    .line 243
    invoke-virtual {p0, p1}, Landroid/widget/AbsSeekBar;->setThumbOffset(I)V

    .line 244
    .line 245
    .line 246
    invoke-virtual {p0}, LB1/e;->h()V

    .line 247
    .line 248
    .line 249
    invoke-virtual {p0}, LB1/e;->getInternalPickedColor()Lz1/a;

    .line 250
    .line 251
    .line 252
    move-result-object p1

    .line 253
    invoke-virtual {p0, p1}, LB1/e;->g(Lz1/a;)Ljava/lang/Integer;

    .line 254
    .line 255
    .line 256
    move-result-object p1

    .line 257
    if-eqz p1, :cond_3

    .line 258
    .line 259
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 260
    .line 261
    .line 262
    move-result p1

    .line 263
    invoke-virtual {p0, p1}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 264
    .line 265
    .line 266
    :cond_3
    invoke-virtual {p0}, LB1/e;->l()V

    .line 267
    .line 268
    .line 269
    iget-object p1, p0, LB1/e;->i:Ljava/util/HashSet;

    .line 270
    .line 271
    invoke-virtual {p0, p1}, LB1/e;->i(Ljava/util/HashSet;)V

    .line 272
    .line 273
    .line 274
    return-void

    .line 275
    :cond_4
    const-string p1, "thumbDrawable"

    .line 276
    .line 277
    invoke-static {p1}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 278
    .line 279
    .line 280
    const/4 p1, 0x0

    .line 281
    throw p1
.end method

.method public static final synthetic a(LB1/e;I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/SeekBar;->setMax(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static final synthetic b(LB1/e;I)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/SeekBar;->setMin(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final c()V
    .locals 4

    .line 1
    iget-boolean v0, p0, LB1/e;->c:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_1

    .line 6
    :cond_0
    iget-object v0, p0, LB1/e;->f:Ljava/util/HashSet;

    .line 7
    .line 8
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, LB1/a;

    .line 23
    .line 24
    invoke-virtual {p0}, LB1/e;->getPickedColor()Lz1/a;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-virtual {p0}, Landroid/widget/ProgressBar;->getProgress()I

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    invoke-interface {v1, p0, v2, v3}, LB1/a;->g(LB1/e;Lz1/a;I)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    :goto_1
    return-void
.end method

.method public final d(Z)V
    .locals 4

    .line 1
    iget-boolean v0, p0, LB1/e;->c:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_1

    .line 6
    :cond_0
    iget-object v0, p0, LB1/e;->f:Ljava/util/HashSet;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, LB1/a;

    .line 23
    .line 24
    invoke-virtual {p0}, LB1/e;->getPickedColor()Lz1/a;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-virtual {p0}, Landroid/widget/ProgressBar;->getProgress()I

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    invoke-interface {v1, p0, v2, v3, p1}, LB1/a;->e(LB1/e;Lz1/a;IZ)V

    .line 33
    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    :goto_1
    return-void
.end method

.method public abstract e(Lz1/a;I)Z
.end method

.method public abstract f(Landroid/graphics/drawable/LayerDrawable;)V
.end method

.method public abstract g(Lz1/a;)Ljava/lang/Integer;
.end method

.method public getColorConverter()Lw1/a;
    .locals 1

    .line 1
    sget-object v0, Lw1/b;->a:Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-virtual {p0}, LB1/e;->getInternalPickedColor()Lz1/a;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lz1/d;

    .line 8
    .line 9
    iget-object v0, v0, Lz1/d;->b:Lz1/b;

    .line 10
    .line 11
    invoke-static {v0}, Lw1/b;->a(Lz1/b;)Lw1/a;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0
.end method

.method public final getInternalPickedColor()Lz1/a;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lz1/a;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, LB1/e;->b:Lz1/d;

    .line 2
    .line 3
    return-object v0
.end method

.method public final getNotifyListeners()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LB1/e;->c:Z

    .line 2
    .line 3
    return v0
.end method

.method public final getPickedColor()Lz1/a;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lz1/a;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, LB1/e;->k:LC4/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const-string v0, "color"

    .line 7
    .line 8
    iget-object v1, p0, LB1/e;->b:Lz1/d;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    new-instance v0, Lz1/d;

    .line 14
    .line 15
    invoke-direct {v0}, Lz1/d;-><init>()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, v1}, Lz1/c;->b(Lz1/d;)V

    .line 19
    .line 20
    .line 21
    return-object v0
.end method

.method public final getThumbStrokeWidthPx()I
    .locals 1

    .line 1
    iget-object v0, p0, LB1/e;->j:Ld8/j;

    .line 2
    .line 3
    invoke-virtual {v0}, Ld8/j;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/Number;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    return v0
.end method

.method public abstract h()V
.end method

.method public abstract i(Ljava/util/HashSet;)V
.end method

.method public abstract j([Landroid/graphics/drawable/Drawable;)[Landroid/graphics/drawable/Drawable;
.end method

.method public abstract k(Lz1/a;Lz1/a;)V
.end method

.method public final l()V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/widget/ProgressBar;->getProgressDrawable()Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    check-cast v0, Landroid/graphics/drawable/LayerDrawable;

    .line 8
    .line 9
    invoke-virtual {p0, v0}, LB1/e;->f(Landroid/graphics/drawable/LayerDrawable;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    new-instance v0, Ljava/lang/NullPointerException;

    .line 14
    .line 15
    const-string v1, "null cannot be cast to non-null type android.graphics.drawable.LayerDrawable"

    .line 16
    .line 17
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    throw v0
.end method

.method public final onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 2

    .line 1
    const-string p2, "seekBar"

    .line 2
    .line 3
    invoke-static {p1, p2}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-boolean p1, p0, LB1/e;->d:Z

    .line 7
    .line 8
    if-nez p1, :cond_4

    .line 9
    .line 10
    iget-boolean p1, p0, LB1/e;->e:Z

    .line 11
    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    goto :goto_2

    .line 15
    :cond_0
    invoke-virtual {p0}, LB1/e;->getInternalPickedColor()Lz1/a;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-virtual {p0}, Landroid/widget/ProgressBar;->getProgress()I

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    invoke-virtual {p0, p1, p2}, LB1/e;->e(Lz1/a;I)Z

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    if-eqz p1, :cond_1

    .line 28
    .line 29
    invoke-virtual {p0}, LB1/e;->c()V

    .line 30
    .line 31
    .line 32
    :cond_1
    invoke-virtual {p0}, LB1/e;->l()V

    .line 33
    .line 34
    .line 35
    iget-object p1, p0, LB1/e;->i:Ljava/util/HashSet;

    .line 36
    .line 37
    invoke-virtual {p0, p1}, LB1/e;->i(Ljava/util/HashSet;)V

    .line 38
    .line 39
    .line 40
    iget-boolean p1, p0, LB1/e;->c:Z

    .line 41
    .line 42
    if-nez p1, :cond_2

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_2
    iget-object p1, p0, LB1/e;->f:Ljava/util/HashSet;

    .line 46
    .line 47
    invoke-virtual {p1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    .line 53
    .line 54
    move-result p2

    .line 55
    if-eqz p2, :cond_3

    .line 56
    .line 57
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object p2

    .line 61
    check-cast p2, LB1/a;

    .line 62
    .line 63
    invoke-virtual {p0}, LB1/e;->getPickedColor()Lz1/a;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-virtual {p0}, Landroid/widget/ProgressBar;->getProgress()I

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    invoke-interface {p2, p0, v0, v1, p3}, LB1/a;->i(LB1/e;Lz1/a;IZ)V

    .line 72
    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_3
    :goto_1
    if-nez p3, :cond_4

    .line 76
    .line 77
    invoke-virtual {p0, p3}, LB1/e;->d(Z)V

    .line 78
    .line 79
    .line 80
    :cond_4
    :goto_2
    return-void
.end method

.method public final onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 4

    .line 1
    const-string v0, "seekBar"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    const-string v0, "thumbObjectAnimator"

    .line 8
    .line 9
    iget-object v1, p0, LB1/e;->h:Landroid/animation/ObjectAnimator;

    .line 10
    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    invoke-virtual {p0}, Landroid/widget/AbsSeekBar;->getThumb()Landroid/graphics/drawable/Drawable;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    const-string v3, "thumb"

    .line 18
    .line 19
    invoke-static {v2, v3}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getLevel()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/16 v3, 0x2710

    .line 27
    .line 28
    filled-new-array {v2, v3}, [I

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    invoke-virtual {v1, v2}, Landroid/animation/ObjectAnimator;->setIntValues([I)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, LB1/e;->h:Landroid/animation/ObjectAnimator;

    .line 36
    .line 37
    if-eqz v1, :cond_0

    .line 38
    .line 39
    invoke-virtual {v1}, Landroid/animation/ObjectAnimator;->start()V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :cond_0
    invoke-static {v0}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw p1

    .line 47
    :cond_1
    invoke-static {v0}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw p1
.end method

.method public final onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 4

    .line 1
    const-string v0, "seekBar"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    const-string v0, "thumbObjectAnimator"

    .line 8
    .line 9
    iget-object v1, p0, LB1/e;->h:Landroid/animation/ObjectAnimator;

    .line 10
    .line 11
    if-eqz v1, :cond_1

    .line 12
    .line 13
    invoke-virtual {p0}, Landroid/widget/AbsSeekBar;->getThumb()Landroid/graphics/drawable/Drawable;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    const-string v3, "thumb"

    .line 18
    .line 19
    invoke-static {v2, v3}, Lkotlin/jvm/internal/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getLevel()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    const/16 v3, 0x1f40

    .line 27
    .line 28
    filled-new-array {v2, v3}, [I

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    invoke-virtual {v1, v2}, Landroid/animation/ObjectAnimator;->setIntValues([I)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, LB1/e;->h:Landroid/animation/ObjectAnimator;

    .line 36
    .line 37
    if-eqz v1, :cond_0

    .line 38
    .line 39
    invoke-virtual {v1}, Landroid/animation/ObjectAnimator;->start()V

    .line 40
    .line 41
    .line 42
    const/4 p1, 0x1

    .line 43
    invoke-virtual {p0, p1}, LB1/e;->d(Z)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_0
    invoke-static {v0}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw p1

    .line 51
    :cond_1
    invoke-static {v0}, Lkotlin/jvm/internal/h;->j(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    throw p1
.end method

.method public setMax(I)V
    .locals 7

    .line 1
    new-instance v0, LB1/b;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    const-class v3, LB1/e;

    .line 6
    .line 7
    const-string v5, "maxUpdating"

    .line 8
    .line 9
    const-string v6, "getMaxUpdating()Z"

    .line 10
    .line 11
    move-object v4, p0

    .line 12
    invoke-direct/range {v0 .. v6}, LB1/b;-><init>(IILjava/lang/Class;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    new-instance v1, LB1/c;

    .line 16
    .line 17
    invoke-direct {v1, p0, p1, v2}, LB1/c;-><init>(LB1/e;II)V

    .line 18
    .line 19
    .line 20
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 21
    .line 22
    invoke-interface {v0, p1}, Lx8/f;->set(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1}, LB1/c;->invoke()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 29
    .line 30
    invoke-interface {v0, p1}, Lx8/f;->set(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public setMin(I)V
    .locals 7

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    new-instance v0, LB1/b;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    const-class v3, LB1/e;

    .line 8
    .line 9
    const-string v5, "minUpdating"

    .line 10
    .line 11
    const-string v6, "getMinUpdating()Z"

    .line 12
    .line 13
    move-object v4, p0

    .line 14
    invoke-direct/range {v0 .. v6}, LB1/b;-><init>(IILjava/lang/Class;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    new-instance v1, LB1/c;

    .line 18
    .line 19
    invoke-direct {v1, p0, p1, v2}, LB1/c;-><init>(LB1/e;II)V

    .line 20
    .line 21
    .line 22
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 23
    .line 24
    invoke-interface {v0, p1}, Lx8/f;->set(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1}, LB1/c;->invoke()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 31
    .line 32
    invoke-interface {v0, p1}, Lx8/f;->set(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :cond_0
    move-object v4, p0

    .line 37
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 38
    .line 39
    const-string v1, "Current mode supports 0 min value only, was "

    .line 40
    .line 41
    invoke-static {v1, p1}, Lcom/google/android/gms/internal/cast/z1;->k(Ljava/lang/String;I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    throw v0
.end method

.method public final setNotifyListeners(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, LB1/e;->c:Z

    .line 2
    .line 3
    return-void
.end method

.method public final setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V
    .locals 1

    .line 1
    invoke-static {p1, p0}, Lkotlin/jvm/internal/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 12
    .line 13
    const-string v0, "Custom OnSeekBarChangeListener not supported yet"

    .line 14
    .line 15
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    throw p1
.end method

.method public final setPickedColor(Lz1/a;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lz1/a;",
            ")V"
        }
    .end annotation

    .line 1
    const-string v0, "value"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LB1/e;->b:Lz1/d;

    .line 7
    .line 8
    invoke-static {v0, p1}, Lkotlin/jvm/internal/h;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    return-void

    .line 15
    :cond_0
    invoke-virtual {p0}, LB1/e;->getInternalPickedColor()Lz1/a;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {p0, v0, p1}, LB1/e;->k(Lz1/a;Lz1/a;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0}, LB1/e;->getInternalPickedColor()Lz1/a;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p0, p1}, LB1/e;->g(Lz1/a;)Ljava/lang/Integer;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    if-eqz p1, :cond_1

    .line 31
    .line 32
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    invoke-virtual {p0, p1}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 37
    .line 38
    .line 39
    :cond_1
    invoke-virtual {p0}, LB1/e;->l()V

    .line 40
    .line 41
    .line 42
    iget-object p1, p0, LB1/e;->i:Ljava/util/HashSet;

    .line 43
    .line 44
    invoke-virtual {p0, p1}, LB1/e;->i(Ljava/util/HashSet;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {p0}, LB1/e;->c()V

    .line 48
    .line 49
    .line 50
    return-void
.end method
